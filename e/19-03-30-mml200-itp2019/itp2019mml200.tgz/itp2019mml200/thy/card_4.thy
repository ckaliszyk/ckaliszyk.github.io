theory card_4
  imports domain_1 newton card_3 orders_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve X, Y, Z, x, y, y1, y2 for "setHIDDENM2"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve k, n, n1, n2, m2, m1 for "NatNAT-1M1"
reserve L, K, M, N for "CardinalCARD-1M1"
reserve f, g for "FunctionFUNCT-1M1"
mtheorem card_4_th_1:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies X be countableCARD-3V4"
   sorry

mtheorem card_4_th_2:
"omegaORDINAL1K4 be countableCARD-3V4"
   sorry

reserve r for "RealXREAL-0M1"
mtheorem card_4_th_3:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 or n =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  not ( not (r <>HIDDENR2 0NUMBERSK6 &  not n =XBOOLE-0R4 0NUMBERSK6) & r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6) &  not (( not r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6 & r <>HIDDENR2 0NUMBERSK6) &  not n =XBOOLE-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?P = "\<lambda>Lamb1. r <>HIDDENR2 0NUMBERSK6 or Lamb1 =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 Lamb1 <>HIDDENR2 0NUMBERSK6"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (r <>HIDDENR2 0NUMBERSK6 or k =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 k <>HIDDENR2 0NUMBERSK6) implies (r <>HIDDENR2 0NUMBERSK6 or k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have A2: "r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 r  |^NEWTONK1 k *XCMPLX-0K3 r"
          using newton_th_6 sorry
        assume "?P(k)"
        thus "r <>HIDDENR2 0NUMBERSK6 or k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 iff r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
          using A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?P(0NUMBERSK6)"
      using newton_th_4 sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A3 A1 sorry
    thus " not ( not (r <>HIDDENR2 0NUMBERSK6 &  not n =XBOOLE-0R4 0NUMBERSK6) & r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6) &  not (( not r  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6 & r <>HIDDENR2 0NUMBERSK6) &  not n =XBOOLE-0R4 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_4_lm_1:
" for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 <=XXREAL-0R1 n2"
proof-
  have " for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies (n1 >XXREAL-0R4 n2 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix n1 assume [ty]: "n1 be NatNAT-1M1"
    fix n2 assume [ty]: "n2 be NatNAT-1M1"
    fix m2 assume [ty]: "m2 be NatNAT-1M1"
    fix m1 assume [ty]: "m1 be NatNAT-1M1"
    assume A1: "\<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M)"
    assume A2: "n1 >XXREAL-0R4 n2"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A3: "n1 =XBOOLE-0R4 n2 +XCMPLX-0K2 n"
      using nat_1_th_10 sorry
    have "n <>HIDDENR2 0NUMBERSK6"
      using A2 A3 sorry
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have A5: "\<two>\<^sub>M  |^NEWTONK1 n2 <>HIDDENR2 0NUMBERSK6"
      using card_4_th_3 sorry
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "\<two>\<^sub>M  |^NEWTONK1 n1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M)"
      using A3 A4 newton_th_8 sorry
    then have "\<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M))"
       sorry
    then have "\<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M"
      using A1 A5 xcmplx_1_th_5 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 k *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M)*NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M)"
      using newton_th_8 sorry
    also have "... = (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 k)*NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = \<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M  |^NEWTONK11 k *NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M))"
       sorry
    finally have "\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M  |^NEWTONK11 k *NAT-1K2 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M))"
       sorry
    then have A6: "\<two>\<^sub>M dividesNAT-DR1 \<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M"
      using nat_d_def_3 sorry
    have "\<two>\<^sub>M dividesNAT-DR1 \<two>\<^sub>M *XCMPLX-0K3 m2"
      using nat_d_def_3 sorry
    thus " False "
      using A6 nat_d_th_7 nat_d_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_4:
" for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 =XBOOLE-0R4 n2 & m1 =XBOOLE-0R4 m2"
proof-
  have " for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds  for m2 be NatNAT-1M1 holds  for m1 be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M) implies n1 =XBOOLE-0R4 n2 & m1 =XBOOLE-0R4 m2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix n1 assume [ty]: "n1 be NatNAT-1M1"
    fix n2 assume [ty]: "n2 be NatNAT-1M1"
    fix m2 assume [ty]: "m2 be NatNAT-1M1"
    fix m1 assume [ty]: "m1 be NatNAT-1M1"
    have A1: "\<two>\<^sub>M  |^NEWTONK1 n1 <>HIDDENR2 0NUMBERSK6"
      using card_4_th_3 sorry
    assume A2: "\<two>\<^sub>M  |^NEWTONK1 n1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n2 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M)"
    then have "n1 <=XXREAL-0R1 n2 & n2 <=XXREAL-0R1 n1"
      using card_4_lm_1 sorry
    thus "n1 =XBOOLE-0R4 n2"
      using xxreal_0_th_1 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M"
      using A2 A1 xcmplx_1_th_5 sorry
    thus "m1 =XBOOLE-0R4 m2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_4_lm_2:
" for x be setHIDDENM2 holds x inTARSKIR2 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] implies ( ex n1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex n2 be ElementSUBSET-1M1-of NATNUMBERSK1 st x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2 ])"
proof-
  have " for x be setHIDDENM2 holds x inTARSKIR2 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] implies ( ex tVar1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex tVar2 be ElementSUBSET-1M1-of NATNUMBERSK1 st x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> tVar1,tVar2 ])"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    assume A1: "x inTARSKIR2 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]"
    then obtain n1 n2 where 
      [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and n1Def:"n1 = x `1XTUPLE-0K1" and
      [ty]:"n2 be ElementSUBSET-1M1-of NATNUMBERSK1" and n2Def:"n2 = x `2XTUPLE-0K2"
      using mcart_1_th_10 sorry
    show " ex tVar1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex tVar2 be ElementSUBSET-1M1-of NATNUMBERSK1 st x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> tVar1,tVar2 ]"
    proof(rule bexI[of _ "n1"])
      show " ex tVar2 be ElementSUBSET-1M1-of NATNUMBERSK1 st x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,tVar2 ]"
      proof(rule bexI[of _ "n2"])
        show "x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2 ]"
          using A1 mcart_1_th_21 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_5:
"([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1)are-equipotentWELLORD2R2 & cardCARD-1K1 NATNUMBERSK1 =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
proof-
  have "[:ZFMISC-1K2 NATNUMBERSK1,{DOMAIN-1K6\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 } :] c=RELAT-1R2 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]"
    using zfmisc_1_th_95 sorry
  then have "cardCARD-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,{DOMAIN-1K6\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 } :]) c=ORDINAL1R1 cardCARD-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
    using card_1_th_11 sorry
  then have A1: "cardCARD-1K1 NATNUMBERSK1 c=ORDINAL1R1 cardCARD-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
    using card_1_th_69 sorry
  let ?f = "\<lambda>Lamb1. \<lambda>Lamb2. \<two>\<^sub>M  |^NEWTONK11 Lamb1 *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 Lamb2 +NAT-1K1 \<one>\<^sub>M)"
  obtain f where
    [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1)" and 
    A2: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(n,m) =XBOOLE-0R4 ?f(n,m)"
    using binop_1_sch_4 sorry
  have A3: "f be one-to-oneFUNCT-1V2"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> f implies (y inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> f implies (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y))"
    proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> f"
      then obtain n1 m1 where
        [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" "m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A4: "x =HIDDENR1 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,m1 ]"
        using card_4_lm_2 sorry
      assume "y inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> f"
      then obtain n2 m2 where
        [ty]:"n2 be ElementSUBSET-1M1-of NATNUMBERSK1" "m2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A5: "y =HIDDENR1 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> n2,m2 ]"
        using card_4_lm_2 sorry
      assume A6: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
      have A7: "\<two>\<^sub>M  |^NEWTONK11 n1 *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 m1 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(n1,m1)"
        using A2 sorry
      also have "... = f .BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(n2,m2)"
        using A4 A5 A6 sorry
      also have "... = \<two>\<^sub>M  |^NEWTONK11 n2 *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 m2 +NAT-1K1 \<one>\<^sub>M)"
        using A2 sorry
      finally have "\<two>\<^sub>M  |^NEWTONK11 n1 *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 m1 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 n2 *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 m2 +NAT-1K1 \<one>\<^sub>M)"
         sorry
      then have "n1 =XBOOLE-0R4 n2"
        using card_4_th_4 sorry
      thus "x =HIDDENR1 y"
        using A4 A5 A7 card_4_th_4 sorry
    qed "sorry"
    thus "f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed
  have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> f =RELAT-1R1 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] & rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> f c=TARSKIR1 NATNUMBERSK1"
    using funct_2_def_1 sorry
  then have "cardCARD-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]) c=ORDINAL1R1 cardCARD-1K1 NATNUMBERSK1"
    using A3 card_1_th_10 sorry
  then have "cardCARD-1K1 NATNUMBERSK1 =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
    using A1 sorry
  thus "([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1)are-equipotentWELLORD2R2 & cardCARD-1K1 NATNUMBERSK1 =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
    using card_1_th_5 sorry
qed

mtheorem card_4_th_6:
"omegaORDINAL1K4 *`CARD-2K2 omegaORDINAL1K4 =XBOOLE-0R4 omegaORDINAL1K4"
  using card_4_th_5 card_2_def_2 sorry

mtheorem card_4_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be countableCARD-3V4 & Y be countableCARD-3V4 implies [:ZFMISC-1K2 X,Y :] be countableCARD-3V4"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X be countableCARD-3V4 & Y be countableCARD-3V4) &  not [:ZFMISC-1K2 X,Y :] be countableCARD-3V4)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4 & cardCARD-1K1 Y c=ORDINAL1R1 omegaORDINAL1K4 implies [:ZFMISC-1K2 X,Y :] be countableCARD-3V4"
    proof(rule impI)
      assume "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4 & cardCARD-1K1 Y c=ORDINAL1R1 omegaORDINAL1K4"
      then have "[:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :] c=RELAT-1R2 [:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :]"
        using zfmisc_1_th_96 sorry
      then have "cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :]) c=ORDINAL1R1 cardCARD-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :])"
        using card_1_th_11 sorry
      then have Cut162: "cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :]) c=ORDINAL1R1 omegaORDINAL1K4 *`CARD-2K2 omegaORDINAL1K4"
        using card_2_def_2 sorry
      have "cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) c=ORDINAL1R1 omegaORDINAL1K4"
      proof-
        show "cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) c=ORDINAL1R1 omegaORDINAL1K4"
          using card_4_th_6 card_2_th_7 Cut162 sorry
      qed
      thus "[:ZFMISC-1K2 X,Y :] be countableCARD-3V4"
        using card_3_def_14 sorry
    qed
    thus " not ((X be countableCARD-3V4 & Y be countableCARD-3V4) &  not [:ZFMISC-1K2 X,Y :] be countableCARD-3V4)"
      using card_3_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D,D)are-equipotentWELLORD2R2 & cardCARD-1K1 (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D,D)are-equipotentWELLORD2R2 & cardCARD-1K1 (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
  proof(rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?f = "\<lambda>Lamb1. <*FINSEQ-1K10 Lamb1*>"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 D & ( for x be objectHIDDENM1 holds x inHIDDENR3 D implies f .FUNCT-1K1 x =XBOOLE-0R4 ?f(x))"
      using funct_1_sch_3 sorry
    have "(D,\<one>\<^sub>M -tuples-onFINSEQ-2K4 D)are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 D & rngRELAT-1K2 f =HIDDENR1 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D)"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies  not (f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y &  not x =HIDDENR1 y)"
          proof(rule ballI,rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
            then have A2: "f .FUNCT-1K1 x =XBOOLE-0R4 <*FINSEQ-1K10 x*> & f .FUNCT-1K1 y =XBOOLE-0R4 <*FINSEQ-1K10 y*>"
              using A1 sorry
            have "(<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
              using finseq_1_def_8 sorry
            thus " not (f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y &  not x =HIDDENR1 y)"
              using A2 finseq_1_def_8 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 D"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D & \<one>\<^sub>M -tuples-onFINSEQ-2K4 D c=TARSKIR1 rngRELAT-1K2 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A3: "y inHIDDENR3 domRELAT-1K1 f"and A4: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have 
                [ty]:"y be ElementSUBSET-1M1-of D"
                using A1 A3 sorry
              have "x =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> y*>"
                using A1 A4 sorry
              then have "x inHIDDENR3 {<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*> where d be ElementSUBSET-1M1-of D :  True  }"
                 sorry
              thus "x inHIDDENR3 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D"
                using finseq_2_th_96 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D implies x inHIDDENR3 rngRELAT-1K2 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D"
            then obtain y where 
              [ty]:"y be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of \<one>\<^sub>M -tuples-onFINSEQ-2K4 D" and yDef:"y = x"
               sorry
            obtain z where
              [ty]:"z be ElementSUBSET-1M1-of D" and 
              A5: "y =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> <*FINSEQ-1K13\<^bsub>(D)\<^esub> z*>"
              using finseq_2_th_97 sorry
            have "x =HIDDENR1 f .FUNCT-1K1 z"
              using A1 A5 sorry
            thus "x inHIDDENR3 rngRELAT-1K2 f"
              using A1 funct_1_def_3 sorry
          qed "sorry"
          thus "\<one>\<^sub>M -tuples-onFINSEQ-2K4 D c=TARSKIR1 rngRELAT-1K2 f"
            using tarski_def_3 sorry
        qed
        thus "rngRELAT-1K2 f =HIDDENR1 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D"
          using xboole_0_def_10 sorry
      qed
      thus "(D,\<one>\<^sub>M -tuples-onFINSEQ-2K4 D)are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "(\<one>\<^sub>M -tuples-onFINSEQ-2K4 D,D)are-equipotentWELLORD2R2 & cardCARD-1K1 (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve p, q for "FinSequenceFINSEQ-1M1"
reserve k, m, n, n1, n2, n3 for "NatNAT-1M1"
mtheorem card_4_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds ([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :],(n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :]) =XBOOLE-0R4 cardCARD-1K1 ((n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds ([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :],(n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :]) =XBOOLE-0R4 cardCARD-1K1 ((n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex p be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D st  ex q be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D st Lamb1 =HIDDENR1 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p,q ] & Lamb2 =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q"
    let ?A = "[:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :]"
    let ?B = "(n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 ?A implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :] implies ( ex tVar4 be objectHIDDENM1 st  ex p be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D st  ex q be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D st x =HIDDENR1 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p,q ] & tVar4 =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 ?A"
        then obtain p where 
          [ty]:"p be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D" and pDef:"p = x `1XTUPLE-0K1"
          using mcart_1_th_10 sorry
        obtain q where 
          [ty]:"q be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D" and qDef:"q = x `2XTUPLE-0K2"
          using A2 mcart_1_th_10 sorry
        obtain y where 
          [ty]:"y be setHIDDENM2" and yDef:"y = p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q"
           sorry
        show " ex tVar4 be objectHIDDENM1 st  ex p be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D st  ex q be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D st x =HIDDENR1 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p,q ] & tVar4 =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q"
        proof(rule bexI[of _ "y"])
          have "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
            using A2 mcart_1_th_21 sorry
          thus " ex p be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D st  ex q be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D st x =HIDDENR1 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p,q ] & y =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q"
             sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 f =XBOOLE-0R4 ?A & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?A implies ?P(x,f .FUNCT-1K1 x))"
      using classes1_sch_1 A1 sorry
    show "([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :],(n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :] & rngRELAT-1K2 f =HIDDENR1 (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y))"
          proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "x inHIDDENR3 domRELAT-1K1 f"
            then obtain p1 q1 where
              [ty]:"p1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D" "q1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D" and 
              A4: "x =HIDDENR1 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p1,q1 ]"and A5: "f .FUNCT-1K1 x =XBOOLE-0R4 p1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> q1"
              using A3 sorry
            assume "y inHIDDENR3 domRELAT-1K1 f"
            then obtain p2 q2 where
              [ty]:"p2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D" "q2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D" and 
              A6: "y =HIDDENR1 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p2,q2 ]"and A7: "f .FUNCT-1K1 y =XBOOLE-0R4 p2 ^FINSEQ-1K9\<^bsub>(D)\<^esub> q2"
              using A3 sorry
            assume A8: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
            have A9: "lenFINSEQ-1K4 p1 =XBOOLE-0R4 n & lenFINSEQ-1K4 p2 =XBOOLE-0R4 n"
              using card_1_def_7 sorry
            then obtain p where
              [ty]:"p be FinSequenceFINSEQ-1M1" and 
              A10: "p1 ^FINSEQ-1K8 p =FINSEQ-1R1 p2"
              using A5 A7 A8 finseq_1_th_47 sorry
            obtain q where
              [ty]:"q be FinSequenceFINSEQ-1M1" and 
              A11: "p2 ^FINSEQ-1K8 q =FINSEQ-1R1 p1"
              using A5 A7 A8 A9 finseq_1_th_47 sorry
            have "lenFINSEQ-1K4 p1 +NAT-1K1 0NUMBERSK6 =HIDDENR1 lenFINSEQ-1K4 (p1 ^FINSEQ-1K8 p) +NAT-1K1 lenFINSEQ-1K4 q"
              using A10 A11 finseq_1_th_22 sorry
            also have "... = (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p)+NAT-1K1 lenFINSEQ-1K4 q"
              using finseq_1_th_22 sorry
            also have "... = lenFINSEQ-1K4 p1 +NAT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
               sorry
            finally have "lenFINSEQ-1K4 p1 +NAT-1K1 0NUMBERSK6 =HIDDENR1 lenFINSEQ-1K4 p1 +NAT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 q)"
               sorry
            then have "p =FINSEQ-1R1 {}XBOOLE-0K1"
               sorry
            then have "p1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> p2"
              using A10 finseq_1_th_34 sorry
            thus "x =HIDDENR1 y"
              using A4 A5 A6 A7 A8 finseq_1_th_33 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :]"
          using A3 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D & (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D c=TARSKIR1 rngRELAT-1K2 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A12: "y inHIDDENR3 domRELAT-1K1 f & x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have " ex p be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D st  ex q be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D st y =HIDDENR1 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p,q ] & x =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q"
                using A3 A12 sorry
              then have "x be TupleFINSEQ-2M3-of(n +XCMPLX-0K2 m,D)"
                 sorry
              then have "x be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D"
                using finseq_2_th_131 sorry
              thus "x inHIDDENR3 (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D"
                 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D implies x inHIDDENR3 rngRELAT-1K2 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?B"
            then have 
              [ty]:"x be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of ?B"
               sorry
            obtain p q where
              [ty]:"p be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D" "q be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D" and 
              A13: "x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q"
              using finseq_2_th_106 sorry
            obtain p1 q1 where
              [ty]:"p1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D" "q1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of m -tuples-onFINSEQ-2K4 D" and 
              A14: "[DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p,q ] =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p1,q1 ]"and A15: "f .FUNCT-1K1 [DOMAIN-1K1\<^bsub>(n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D)\<^esub> p,q ] =XBOOLE-0R4 p1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> q1"
              using A3 sorry
            have "p1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> p & q1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,D)\<^esub> q"
              using A14 xtuple_0_th_1 sorry
            thus "x inHIDDENR3 rngRELAT-1K2 f"
              using A3 A13 A15 funct_1_def_3 sorry
          qed "sorry"
          thus "(n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D c=TARSKIR1 rngRELAT-1K2 f"
            using tarski_def_3 sorry
        qed
        thus "rngRELAT-1K2 f =HIDDENR1 (n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D"
          using xboole_0_def_10 sorry
      qed
      thus "([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :],(n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 ([:ZFMISC-1K2 n -tuples-onFINSEQ-2K4 D,m -tuples-onFINSEQ-2K4 D :]) =XBOOLE-0R4 cardCARD-1K1 ((n +XCMPLX-0K2 m)-tuples-onFINSEQ-2K4 D)"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds D be countableCARD-3V4 implies n -tuples-onFINSEQ-2K4 D be countableCARD-3V4"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  not (D be countableCARD-3V4 &  not n -tuples-onFINSEQ-2K4 D be countableCARD-3V4)"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 -tuples-onFINSEQ-2K4 D be countableCARD-3V4"
    have "cardCARD-1K1 D c=ORDINAL1R1 omegaORDINAL1K4 implies n -tuples-onFINSEQ-2K4 D be countableCARD-3V4"
    proof(rule impI)
      assume "cardCARD-1K1 D c=ORDINAL1R1 omegaORDINAL1K4"
      then have "cardCARD-1K1 (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D) c=ORDINAL1R1 omegaORDINAL1K4"
        using card_4_th_8 sorry
      then have A1: "\<one>\<^sub>M -tuples-onFINSEQ-2K4 D be countableCARD-3V4"
         sorry
      have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds k -tuples-onFINSEQ-2K4 D be countableCARD-3V4 implies (k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 D be countableCARD-3V4"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "?P(k)"
          then have "[:ZFMISC-1K2 k -tuples-onFINSEQ-2K4 D,\<one>\<^sub>M -tuples-onFINSEQ-2K4 D :] be countableCARD-3V4"
            using A1 card_4_th_7 sorry
          then have A3: "cardCARD-1K1 ([:ZFMISC-1K2 k -tuples-onFINSEQ-2K4 D,\<one>\<^sub>M -tuples-onFINSEQ-2K4 D :]) c=ORDINAL1R1 omegaORDINAL1K4"
             sorry
          have "cardCARD-1K1 ([:ZFMISC-1K2 k -tuples-onFINSEQ-2K4 D,\<one>\<^sub>M -tuples-onFINSEQ-2K4 D :]) =XBOOLE-0R4 cardCARD-1K1 ((k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 D)"
            using card_4_th_9 sorry
          thus "(k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 D be countableCARD-3V4"
            using A3 card_3_def_14 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "{DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,D :]))\<^esub> <*>FINSEQ-1K7 D } be countableCARD-3V4"
         sorry
      then have A4: "?P(0NUMBERSK6)"
        using finseq_2_th_94 sorry
      have " for k be NatNAT-1M1 holds ?P(k)"
        using nat_1_sch_2 A4 A2 sorry
      thus "n -tuples-onFINSEQ-2K4 D be countableCARD-3V4"
         sorry
    qed
    thus " not (D be countableCARD-3V4 &  not n -tuples-onFINSEQ-2K4 D be countableCARD-3V4)"
      using card_3_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_11:
" for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f be countableCARD-3V4 & ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 x be countableCARD-3V4) implies UnionCARD-3K3 f be countableCARD-3V4"
proof-
  have " for f be FunctionFUNCT-1M1 holds  not ((domRELAT-1K1 f be countableCARD-3V4 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f &  not f .FUNCT-1K1 x be countableCARD-3V4))) &  not UnionCARD-3K3 f be countableCARD-3V4)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "cardCARD-1K1 (domRELAT-1K1 f) c=ORDINAL1R1 omegaORDINAL1K4 & ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 x be countableCARD-3V4) implies UnionCARD-3K3 f be countableCARD-3V4"
    proof(rule impMI ,rule impI)
      assume A1: "cardCARD-1K1 (domRELAT-1K1 f) c=ORDINAL1R1 omegaORDINAL1K4"
        and A2: " for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 x be countableCARD-3V4"
      have Cut331: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies cardCARD-1K1 (f .FUNCT-1K1 x) c=ORDINAL1R1 omegaORDINAL1K4"
        using A2 card_3_def_14 sorry
      have "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 omegaORDINAL1K4"
      proof-
        show "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 omegaORDINAL1K4"
          using A1 card_4_th_6 card_2_th_86 Cut331 sorry
      qed
      thus "UnionCARD-3K3 f be countableCARD-3V4"
        using card_3_def_14 sorry
    qed
    thus " not ((domRELAT-1K1 f be countableCARD-3V4 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f &  not f .FUNCT-1K1 x be countableCARD-3V4))) &  not UnionCARD-3K3 f be countableCARD-3V4)"
      using card_3_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_12:
" for X be setHIDDENM2 holds X be countableCARD-3V4 & ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies Y be countableCARD-3V4) implies unionTARSKIK3 X be countableCARD-3V4"
proof-
  have " for X be setHIDDENM2 holds  not ((X be countableCARD-3V4 & ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not Y be countableCARD-3V4))) &  not unionTARSKIK3 X be countableCARD-3V4)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4 & ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies Y be countableCARD-3V4) implies unionTARSKIK3 X be countableCARD-3V4"
    proof(rule impMI ,rule impI)
      assume A1: "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4"
        and A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies Y be countableCARD-3V4"
      have Cut343: " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies cardCARD-1K1 Y c=ORDINAL1R1 omegaORDINAL1K4"
        using A2 card_3_def_14 sorry
      have "cardCARD-1K1 (unionTARSKIK3 X) c=ORDINAL1R1 omegaORDINAL1K4"
      proof-
        show "cardCARD-1K1 (unionTARSKIK3 X) c=ORDINAL1R1 omegaORDINAL1K4"
          using A1 card_4_th_6 card_2_th_87 Cut343 sorry
      qed
      thus "unionTARSKIK3 X be countableCARD-3V4"
        using card_3_def_14 sorry
    qed
    thus " not ((X be countableCARD-3V4 & ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not Y be countableCARD-3V4))) &  not unionTARSKIK3 X be countableCARD-3V4)"
      using card_3_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds D be countableCARD-3V4 implies D * FINSEQ-2K3 be countableCARD-3V4"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds D be countableCARD-3V4 implies D * FINSEQ-2K3 be countableCARD-3V4"
  proof(rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be NatNAT-1M1 st Lamb1 =HIDDENR1 n & Lamb2 =HIDDENR1 n -tuples-onFINSEQ-2K4 D"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex tVar6 be objectHIDDENM1 st  ex tVar7 be NatNAT-1M1 st x =HIDDENR1 tVar7 & tVar6 =HIDDENR1 tVar7 -tuples-onFINSEQ-2K4 D)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then obtain n where 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x"
           sorry
        obtain y where 
          [ty]:"y be setHIDDENM2" and yDef:"y = n -tuples-onFINSEQ-2K4 D"
           sorry
        show " ex tVar6 be objectHIDDENM1 st  ex tVar7 be NatNAT-1M1 st x =HIDDENR1 tVar7 & tVar6 =HIDDENR1 tVar7 -tuples-onFINSEQ-2K4 D"
        proof(rule bexI[of _ "y"])
          show " ex tVar7 be NatNAT-1M1 st x =HIDDENR1 tVar7 & y =HIDDENR1 tVar7 -tuples-onFINSEQ-2K4 D"
          proof(rule bexI[of _ "n"])
            show "x =HIDDENR1 n & y =HIDDENR1 n -tuples-onFINSEQ-2K4 D"
               sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A2: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,f .FUNCT-1K1 x))"
      using classes1_sch_1 A1 sorry
    have A3: "D * FINSEQ-2K3 =XBOOLE-0R4 unionTARSKIK3 ({k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  })"
      using finseq_2_th_108 sorry
    have A4: "UnionCARD-3K3 f =XBOOLE-0R4 D * FINSEQ-2K3"
    proof-
      have "UnionCARD-3K3 f c=TARSKIR1 D * FINSEQ-2K3 & D * FINSEQ-2K3 c=TARSKIR1 UnionCARD-3K3 f"
      proof(rule conjMI)
        show "UnionCARD-3K3 f c=TARSKIR1 D * FINSEQ-2K3"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 f implies x inHIDDENR3 D * FINSEQ-2K3"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 UnionCARD-3K3 f"
            then obtain X where
              [ty]:"X be setHIDDENM2" and 
              A5: "x inHIDDENR3 X"and A6: "X inTARSKIR2 rngFUNCT-1K2 f"
              using tarski_def_4 sorry
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A7: "y inHIDDENR3 domRELAT-1K1 f"and A8: "X =XBOOLE-0R4 f .FUNCT-1K1 y"
              using A6 funct_1_def_3 sorry
            have 
              [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A2 A7 sorry
            have " ex n be NatNAT-1M1 st y =XBOOLE-0R4 n & X =XBOOLE-0R4 n -tuples-onFINSEQ-2K4 D"
              using A2 A8 sorry
            then have "X inTARSKIR2 {k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  }"
               sorry
            thus "x inHIDDENR3 D * FINSEQ-2K3"
              using A3 A5 tarski_def_4 sorry
          qed "sorry"
          thus "UnionCARD-3K3 f c=TARSKIR1 D * FINSEQ-2K3"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 D * FINSEQ-2K3 implies x inHIDDENR3 UnionCARD-3K3 f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 D * FINSEQ-2K3"
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A9: "x inHIDDENR3 X & X inTARSKIR2 {k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  }"
            using A3 tarski_def_4 sorry
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A10: "X =XBOOLE-0R4 n -tuples-onFINSEQ-2K4 D"
            using A9 sorry
          have A11: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have " ex k be NatNAT-1M1 st n =XBOOLE-0R4 k & f .FUNCT-1K1 n =XBOOLE-0R4 k -tuples-onFINSEQ-2K4 D"
            using A2 sorry
          then have "X inTARSKIR2 rngFUNCT-1K2 f"
            using A2 A10 funct_1_def_3 A11 sorry
          thus "x inHIDDENR3 UnionCARD-3K3 f"
            using A9 tarski_def_4 sorry
        qed "sorry"
        thus "D * FINSEQ-2K3 c=TARSKIR1 UnionCARD-3K3 f"
          using tarski_def_3 sorry
      qed
      thus "UnionCARD-3K3 f =XBOOLE-0R4 D * FINSEQ-2K3"
        using xboole_0_def_10 sorry
    qed
    assume A12: "D be countableCARD-3V4"
    have " for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 x be countableCARD-3V4"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      assume "x inTARSKIR2 domRELAT-1K1 f"
      then have " ex n be NatNAT-1M1 st x =XBOOLE-0R4 n & f .FUNCT-1K1 x =XBOOLE-0R4 n -tuples-onFINSEQ-2K4 D"
        using A2 sorry
      thus "f .FUNCT-1K1 x be countableCARD-3V4"
        using A12 card_4_th_10 sorry
    qed "sorry"
    thus "D * FINSEQ-2K3 be countableCARD-3V4"
      using A2 A4 card_4_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_14:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds omegaORDINAL1K4 c=ORDINAL1R1 cardCARD-1K1 (D * FINSEQ-2K3)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds omegaORDINAL1K4 c=ORDINAL1R1 cardCARD-1K1 (D * FINSEQ-2K3)"
  proof(rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex p be FinSequenceFINSEQ-1M1 st Lamb1 =HIDDENR1 p & Lamb2 =HIDDENR1 lenFINSEQ-1K4 p"
    have A1: "{}XBOOLE-0K1 inTARSKIR2 D * FINSEQ-2K3 & lenFINSEQ-1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 0NUMBERSK6"
      using finseq_1_th_49 sorry
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 D * FINSEQ-2K3 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 D * FINSEQ-2K3 implies ( ex tVar8 be objectHIDDENM1 st  ex tVar9 be FinSequenceFINSEQ-1M1 st x =HIDDENR1 tVar9 & tVar8 =HIDDENR1 lenFINSEQ-1K4 tVar9)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 D * FINSEQ-2K3"
        then obtain p where 
          [ty]:"p be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of D * FINSEQ-2K3" and pDef:"p = x"
           sorry
        have 
          [ty]:"p be FinSequenceFINSEQ-1M1"
           sorry
        obtain y where 
          [ty]:"y be setHIDDENM2" and yDef:"y = lenFINSEQ-1K4 p"
           sorry
        show " ex tVar8 be objectHIDDENM1 st  ex tVar9 be FinSequenceFINSEQ-1M1 st x =HIDDENR1 tVar9 & tVar8 =HIDDENR1 lenFINSEQ-1K4 tVar9"
        proof(rule bexI[of _ "y"])
          show " ex tVar9 be FinSequenceFINSEQ-1M1 st x =HIDDENR1 tVar9 & y =HIDDENR1 lenFINSEQ-1K4 tVar9"
          proof(rule bexI[of _ "p"])
            show "x =HIDDENR1 p & y =HIDDENR1 lenFINSEQ-1K4 p"
               sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 f =XBOOLE-0R4 D * FINSEQ-2K3 & ( for x be objectHIDDENM1 holds x inHIDDENR3 D * FINSEQ-2K3 implies ?P(x,f .FUNCT-1K1 x))"
      using classes1_sch_1 A2 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 f .:FUNCT-1K5 (D * FINSEQ-2K3)"
    have A4: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n inTARSKIR2 f .:FUNCT-1K5 (D * FINSEQ-2K3) implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 f .:FUNCT-1K5 (D * FINSEQ-2K3)"
      proof(rule ballI,rule impI)
        let ?y = "the ElementSUBSET-1M1-of D"
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n inTARSKIR2 f .:FUNCT-1K5 (D * FINSEQ-2K3)"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A5: "x inHIDDENR3 domRELAT-1K1 f"and A6: "x inHIDDENR3 D * FINSEQ-2K3"and A7: "n =XBOOLE-0R4 f .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M1" and 
          A8: "x =HIDDENR1 p"and A9: "n =XBOOLE-0R4 lenFINSEQ-1K4 p"
          using A3 A5 A7 sorry
        have 
          [ty]:"p be FinSequenceFINSEQ-1M3-of D"
          using A6 A8 finseq_1_def_11 sorry
        have A10: "lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?y*>)) =HIDDENR1 n +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?y*>)"
          using A9 finseq_1_th_22 sorry
        also have "... = n +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        finally have "lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?y*>)) =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
           sorry
        have A11: "p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?y*>) inTARSKIR2 D * FINSEQ-2K3"
          using finseq_1_def_11 sorry
        then have " ex q be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?y*>) =FINSEQ-1R1 q & f .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?y*>)) =XBOOLE-0R4 lenFINSEQ-1K4 q"
          using A3 sorry
        thus "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 f .:FUNCT-1K5 (D * FINSEQ-2K3)"
          using A3 A11 A10 funct_1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " ex p be FinSequenceFINSEQ-1M1 st {}XBOOLE-0K1 =FINSEQ-1R1 p & f .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 lenFINSEQ-1K4 p"
      using A3 finseq_1_th_49 sorry
    then have A12: "?P(0NUMBERSK6)"
      using A3 A1 funct_1_def_6 sorry
    have A13: " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A12 A4 sorry
    have "NATNUMBERSK1 c=TARSKIR1 f .:FUNCT-1K5 (D * FINSEQ-2K3)"
      using A13 sorry
    thus "omegaORDINAL1K4 c=ORDINAL1R1 cardCARD-1K1 (D * FINSEQ-2K3)"
      using card_1_th_47 card_1_th_66 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem card_4_sch_1:
  fixes ff1 Pp1 
  assumes
[ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> ff1(x1) be setHIDDENM2"
  shows "{ff1(n) where n be NatNAT-1M1 : Pp1(n) } be countableCARD-3V4"
  proof-
    have "{ff1(n) where n be NatNAT-1M1 : Pp1(n) } be countableCARD-3V4"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x =XBOOLE-0R4 ff1(x))"
        using funct_1_sch_3 sorry
      have "{ff1(n) where n be NatNAT-1M1 : Pp1(n) } c=TARSKIR1 rngFUNCT-1K2 f"
      proof-
        have "{ff1(n) where n be NatNAT-1M1 : Pp1(n) } c=TARSKIR1 rngFUNCT-1K2 f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {ff1(n) where n be NatNAT-1M1 : Pp1(n) } implies x inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 {ff1(n) where n be NatNAT-1M1 : Pp1(n) }"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A2: "x =HIDDENR1 ff1(n)"and "Pp1(n)"
               sorry
            have A3: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "f .FUNCT-1K1 n =HIDDENR1 x"
              using A1 A2 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 f"
              using A1 funct_1_def_3 A3 sorry
          qed "sorry"
          thus "{ff1(n) where n be NatNAT-1M1 : Pp1(n) } c=TARSKIR1 rngFUNCT-1K2 f"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{ff1(n) where n be NatNAT-1M1 : Pp1(n) } be countableCARD-3V4"
        using A1 card_3_th_93 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem card_4_sch_2:
  fixes ff2 Pp2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> ff2(x1,x2) be setHIDDENM2"
  shows "{ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) } be countableCARD-3V4"
  proof-
    have "{ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) } be countableCARD-3V4"
    proof-
      obtain N where
        [ty]:"N be FunctionFUNCT-1M1" and 
        "N be one-to-oneFUNCT-1V2"and A1: "domRELAT-1K1 N =XBOOLE-0R4 NATNUMBERSK1"and A2: "rngFUNCT-1K2 N =XBOOLE-0R4 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]"
        using card_4_th_5 wellord2_def_4 sorry
      let ?g = "\<lambda>Lamb1. ff2((N .FUNCT-1K1 Lamb1)`1XTUPLE-0K1,(N .FUNCT-1K1 Lamb1)`2XTUPLE-0K2)"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x =XBOOLE-0R4 ?g(x))"
        using funct_1_sch_3 sorry
      have "{ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) } c=TARSKIR1 rngFUNCT-1K2 f"
      proof-
        have "{ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) } c=TARSKIR1 rngFUNCT-1K2 f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) } implies x inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 {ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) }"
            then obtain n1 n2 where
              [ty]:"n1 be NatNAT-1M1" "n2 be NatNAT-1M1" and 
              A4: "x =HIDDENR1 ff2(n1,n2)"and "Pp2(n1,n2)"
               sorry
            have "n1 inTARSKIR2 NATNUMBERSK1 & n2 inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "[TARSKIK4 n1,n2 ] inHIDDENR3 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]"
              using zfmisc_1_th_87 sorry
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A5: "y inHIDDENR3 domRELAT-1K1 N"and A6: "[TARSKIK4 n1,n2 ] =HIDDENR1 N .FUNCT-1K1 y"
              using A2 funct_1_def_3 sorry
            have "[TARSKIK4 n1,n2 ] `1XTUPLE-0K1 =HIDDENR1 n1 & [TARSKIK4 n1,n2 ] `2XTUPLE-0K2 =HIDDENR1 n2"
               sorry
            then have "x =HIDDENR1 f .FUNCT-1K1 y"
              using A1 A3 A4 A5 A6 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 f"
              using A1 A3 A5 funct_1_def_3 sorry
          qed "sorry"
          thus "{ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) } c=TARSKIR1 rngFUNCT-1K2 f"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{ff2(n1,n2) where n1 be NatNAT-1M1, n2 be NatNAT-1M1 : Pp2(n1,n2) } be countableCARD-3V4"
        using A3 card_3_th_93 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem card_4_sch_3:
  fixes ff3 Pp3 
  assumes
[ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> ff3(x1,x2,x3) be setHIDDENM2"
  shows "{ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) } be countableCARD-3V4"
  proof-
    have "{ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) } be countableCARD-3V4"
    proof-
      have "([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],[:ZFMISC-1K2 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1 :])are-equipotentWELLORD2R2"
        using card_4_th_5 card_2_th_8 sorry
      then have A1: "(NATNUMBERSK1,[:ZFMISC-1K2 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1 :])are-equipotentWELLORD2R2"
        using card_4_th_5 wellord2_th_15 sorry
      have "[:ZFMISC-1K2 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :],NATNUMBERSK1 :] =XBOOLE-0R4 [:ZFMISC-1K3 NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1 :]"
        using zfmisc_1_def_3 sorry
      then obtain N where
        [ty]:"N be FunctionFUNCT-1M1" and 
        "N be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 N =XBOOLE-0R4 NATNUMBERSK1"and A3: "rngFUNCT-1K2 N =XBOOLE-0R4 [:ZFMISC-1K3 NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1 :]"
        using A1 sorry
      let ?g = "\<lambda>Lamb1. ff3(((N .FUNCT-1K1 Lamb1)`1XTUPLE-0K1)`1XTUPLE-0K1,((N .FUNCT-1K1 Lamb1)`1XTUPLE-0K1)`2XTUPLE-0K2,(N .FUNCT-1K1 Lamb1)`2XTUPLE-0K2)"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A4: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x =XBOOLE-0R4 ?g(x))"
        using funct_1_sch_3 sorry
      have "{ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) } c=TARSKIR1 rngFUNCT-1K2 f"
      proof-
        have "{ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) } c=TARSKIR1 rngFUNCT-1K2 f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) } implies x inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 {ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) }"
            then obtain n1 n2 n3 where
              [ty]:"n1 be NatNAT-1M1" "n2 be NatNAT-1M1" "n3 be NatNAT-1M1" and 
              A5: "x =HIDDENR1 ff3(n1,n2,n3)"and "Pp3(n1,n2,n3)"
               sorry
            have 
              [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and
              [ty]:"n2 be ElementSUBSET-1M1-of NATNUMBERSK1" and
              [ty]:"n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have A6: "[DOMAIN-1K4\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2,n3 ] `3-3MCART-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> =XBOOLE-0R4 n3 & [DOMAIN-1K4\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2,n3 ] `1-3MCART-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> =HIDDENR1 ([DOMAIN-1K4\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2,n3 ] `1XTUPLE-0K1)`1XTUPLE-0K1"
               sorry
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A7: "y inHIDDENR3 domRELAT-1K1 N"and A8: "[DOMAIN-1K4\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2,n3 ] =XBOOLE-0R4 N .FUNCT-1K1 y"
              using A3 funct_1_def_3 sorry
            have "[DOMAIN-1K4\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2,n3 ] `1-3MCART-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> =XBOOLE-0R4 n1 & [DOMAIN-1K4\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> n1,n2,n3 ] `2-3MCART-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1)\<^esub> =XBOOLE-0R4 n2"
               sorry
            then have "x =HIDDENR1 f .FUNCT-1K1 y"
              using A2 A4 A5 A7 A8 A6 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 f"
              using A2 A4 A7 funct_1_def_3 sorry
          qed "sorry"
          thus "{ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) } c=TARSKIR1 rngFUNCT-1K2 f"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{ff3(n1,n2,n3) where n1 be NatNAT-1M1, n2 be NatNAT-1M1, n3 be NatNAT-1M1 : Pp3(n1,n2,n3) } be countableCARD-3V4"
        using A4 card_3_th_93 sorry
    qed
    thus " ?thesis "
       sorry
  qed

reserve f, f1, f2 for "FunctionFUNCT-1M1"
reserve X1, X2 for "setHIDDENM2"
(*\$N Hessenberg's theorem*)
mtheorem card_4_th_15:
" for M be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 implies M *`CARD-2K2 M =XBOOLE-0R4 M"
proof-
  have " for M be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 implies M *`CARD-2K2 M =XBOOLE-0R4 M"
  proof(rule ballI,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    let ?P = "\<lambda>Lamb1.  ex f be FunctionFUNCT-1M1 st (f =HIDDENR1 Lamb1 & f be one-to-oneFUNCT-1V2) & domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
    obtain X where
      [ty]:"X be setHIDDENM2" and 
      A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 PFuncsPARTFUN1K4([:ZFMISC-1K2 M,M :],M) & ?P(x)"
      using xboole_0_sch_1 sorry
    have A2: " for x be setHIDDENM2 holds x inTARSKIR2 X implies x be FunctionFUNCT-1M1"
    proof-
      have " for x be setHIDDENM2 holds x inTARSKIR2 X implies x be FunctionFUNCT-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 X"
        then have " ex f be FunctionFUNCT-1M1 st (f =XBOOLE-0R4 x & f be one-to-oneFUNCT-1V2) & domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
          using A1 sorry
        thus "x be FunctionFUNCT-1M1"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for Z be setHIDDENM2 holds (Z <>HIDDENR2 {}XBOOLE-0K1 & Z c=TARSKIR1 X) & Z be c=-linearORDINAL1V6 implies unionTARSKIK3 Z inTARSKIR2 X"
    proof-
      have " for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 & (Z c=TARSKIR1 X & Z be c=-linearORDINAL1V6) implies unionTARSKIK3 Z inTARSKIR2 X"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume "Z <>HIDDENR2 {}XBOOLE-0K1"
          and A4: "Z c=TARSKIR1 X"
          and A5: "Z be c=-linearORDINAL1V6"
        have "unionTARSKIK3 Z be Relation-likeRELAT-1V1\<bar>Function-likeFUNCT-1V1"
        proof-
          have "unionTARSKIK3 Z be Relation-likeRELAT-1V1 & unionTARSKIK3 Z be Function-likeFUNCT-1V1"
          proof-
            let ?F = "unionTARSKIK3 Z"
            have "( for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 Z implies ( ex y1 be objectHIDDENM1 st  ex y2 be objectHIDDENM1 st [TARSKIK4 y1,y2 ] =HIDDENR1 x)) & unionTARSKIK3 Z be Function-likeFUNCT-1V1"
            proof(rule conjMI)
              show " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 Z implies ( ex y1 be objectHIDDENM1 st  ex y2 be objectHIDDENM1 st [TARSKIK4 y1,y2 ] =HIDDENR1 x)"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 Z implies  not ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not [TARSKIK4 y1,y2 ] =HIDDENR1 x)"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 ?F"
                  then obtain Y where
                    [ty]:"Y be setHIDDENM2" and 
                    A6: "x inHIDDENR3 Y"and A7: "Y inTARSKIR2 Z"
                    using tarski_def_4 sorry
                  obtain f where 
                    [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = Y"
                    using A2 A4 A7 sorry
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 f implies ( ex y1 be objectHIDDENM1 st  ex y2 be objectHIDDENM1 st [TARSKIK4 y1,y2 ] =HIDDENR1 x)"
                    using relat_1_def_1 sorry
                  thus " not ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not [TARSKIK4 y1,y2 ] =HIDDENR1 x)"
                    using A6 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 unionTARSKIK3 Z implies ([TARSKIK4 x,y2 ] inHIDDENR3 unionTARSKIK3 Z implies y1 =HIDDENR1 y2)"
              proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                fix y1 assume [ty]: "y1 be objectHIDDENM1"
                fix y2 assume [ty]: "y2 be objectHIDDENM1"
                assume "[TARSKIK4 x,y1 ] inHIDDENR3 ?F"
                then obtain X1 where
                  [ty]:"X1 be setHIDDENM2" and 
                  A8: "[TARSKIK4 x,y1 ] inHIDDENR3 X1"and A9: "X1 inTARSKIR2 Z"
                  using tarski_def_4 sorry
                assume "[TARSKIK4 x,y2 ] inHIDDENR3 ?F"
                then obtain X2 where
                  [ty]:"X2 be setHIDDENM2" and 
                  A10: "[TARSKIK4 x,y2 ] inHIDDENR3 X2"and A11: "X2 inTARSKIR2 Z"
                  using tarski_def_4 sorry
                obtain f1 f2 where 
                  [ty]:"f1 be FunctionFUNCT-1M1" and f1Def:"f1 = X1" and
                  [ty]:"f2 be FunctionFUNCT-1M1" and f2Def:"f2 = X2"
                  using A2 A4 A9 A11 sorry
                have "(X1,X2)are-c=-comparableXBOOLE-0R3"
                  using A5 A9 A11 ordinal1_def_8 sorry
                then have "X1 c=TARSKIR1 X2 or X2 c=TARSKIR1 X1"
                   sorry
                then have "[TARSKIK4 x,y2 ] inHIDDENR3 X1 & ( for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 f1 & [TARSKIK4 x,y2 ] inHIDDENR3 f1 implies y1 =HIDDENR1 y2) or [TARSKIK4 x,y1 ] inHIDDENR3 X2 & ( for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 f2 & [TARSKIK4 x,y2 ] inHIDDENR3 f2 implies y1 =HIDDENR1 y2)"
                  using A8 A10 funct_1_def_1 sorry
                thus "y1 =HIDDENR1 y2"
                  using A8 A10 sorry
              qed "sorry"
              thus "unionTARSKIK3 Z be Function-likeFUNCT-1V1"
                using funct_1_def_1 sorry
            qed
            thus "unionTARSKIK3 Z be Relation-likeRELAT-1V1 & unionTARSKIK3 Z be Function-likeFUNCT-1V1"
              using relat_1_def_1 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain f where 
          [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = unionTARSKIK3 Z"
           sorry
        have A12: "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f implies  not (f .FUNCT-1K1 x1 =HIDDENR1 f .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            fix x2 assume [ty]: "x2 be objectHIDDENM1"
            assume A13: "x1 inHIDDENR3 domRELAT-1K1 f"
              and A14: "x2 inHIDDENR3 domRELAT-1K1 f"
            have "[TARSKIK4 x1,f .FUNCT-1K1 x1 ] inHIDDENR3 f"
              using A13 funct_1_th_1 sorry
            then obtain X1 where
              [ty]:"X1 be setHIDDENM2" and 
              A15: "[TARSKIK4 x1,f .FUNCT-1K1 x1 ] inHIDDENR3 X1"and A16: "X1 inTARSKIR2 Z"
              using tarski_def_4 sorry
            have "[TARSKIK4 x2,f .FUNCT-1K1 x2 ] inHIDDENR3 f"
              using A14 funct_1_th_1 sorry
            then obtain X2 where
              [ty]:"X2 be setHIDDENM2" and 
              A17: "[TARSKIK4 x2,f .FUNCT-1K1 x2 ] inHIDDENR3 X2"and A18: "X2 inTARSKIR2 Z"
              using tarski_def_4 sorry
            obtain f2 where
              [ty]:"f2 be FunctionFUNCT-1M1" and 
              A19: "f2 =XBOOLE-0R4 X2"and A20: "f2 be one-to-oneFUNCT-1V2"and "domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f2,rngFUNCT-1K2 f2 :]"
              using A1 A4 A18 sorry
            obtain f1 where
              [ty]:"f1 be FunctionFUNCT-1M1" and 
              A21: "f1 =XBOOLE-0R4 X1"and A22: "f1 be one-to-oneFUNCT-1V2"and "domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f1,rngFUNCT-1K2 f1 :]"
              using A1 A4 A16 sorry
            have "(X1,X2)are-c=-comparableXBOOLE-0R3"
              using A5 A16 A18 ordinal1_def_8 sorry
            then have "X1 c=TARSKIR1 X2 or X2 c=TARSKIR1 X1"
               sorry
            then have "((x1 inHIDDENR3 domRELAT-1K1 f1 & x2 inHIDDENR3 domRELAT-1K1 f1) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f1 .FUNCT-1K1 x1) & f .FUNCT-1K1 x2 =XBOOLE-0R4 f1 .FUNCT-1K1 x2 or ((x1 inHIDDENR3 domRELAT-1K1 f2 & x2 inHIDDENR3 domRELAT-1K1 f2) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f2 .FUNCT-1K1 x1) & f .FUNCT-1K1 x2 =XBOOLE-0R4 f2 .FUNCT-1K1 x2"
              using A15 A17 A21 A19 funct_1_th_1 sorry
            thus " not (f .FUNCT-1K1 x1 =HIDDENR1 f .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
              using A22 A20 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        have A23: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
        proof-
          have "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :] & [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :] c=TARSKIR1 domRELAT-1K1 f"
          proof(rule conjMI)
            show "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 domRELAT-1K1 f"
                then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
                  using funct_1_def_2 sorry
                then obtain Y where
                  [ty]:"Y be setHIDDENM2" and 
                  A24: "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Y"and A25: "Y inTARSKIR2 Z"
                  using tarski_def_4 sorry
                obtain g where
                  [ty]:"g be FunctionFUNCT-1M1" and 
                  A26: "g =XBOOLE-0R4 Y"and "g be one-to-oneFUNCT-1V2"and A27: "domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 g,rngFUNCT-1K2 g :]"
                  using A1 A4 A25 sorry
                have "g c=RELAT-1R2 f"
                  using A25 A26 zfmisc_1_th_74 sorry
                then have "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 f"
                  using relat_1_th_11 sorry
                then have A28: "domRELAT-1K1 g c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
                  using A27 zfmisc_1_th_96 sorry
                have "x inHIDDENR3 domRELAT-1K1 g"
                  using A24 A26 funct_1_th_1 sorry
                thus "x inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
                  using A28 sorry
              qed "sorry"
              thus "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
                using tarski_def_3 sorry
            qed
            have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :] implies [TARSKIK4 x1,x2 ] inHIDDENR3 domRELAT-1K1 f"
            proof(rule ballI,rule ballI,rule impI)
              fix x1 assume [ty]: "x1 be objectHIDDENM1"
              fix x2 assume [ty]: "x2 be objectHIDDENM1"
              assume A29: "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
              have "[TARSKIK4 x1,x2 ] `1XTUPLE-0K1 inHIDDENR3 rngFUNCT-1K2 f"
                using A29 mcart_1_th_10 sorry
              then obtain y1 where
                [ty]:"y1 be objectHIDDENM1" and 
                A30: "y1 inHIDDENR3 domRELAT-1K1 f & [TARSKIK4 x1,x2 ] `1XTUPLE-0K1 =HIDDENR1 f .FUNCT-1K1 y1"
                using funct_1_def_3 sorry
              have "[TARSKIK4 x1,x2 ] `2XTUPLE-0K2 inHIDDENR3 rngFUNCT-1K2 f"
                using A29 mcart_1_th_10 sorry
              then obtain y2 where
                [ty]:"y2 be objectHIDDENM1" and 
                A31: "y2 inHIDDENR3 domRELAT-1K1 f & [TARSKIK4 x1,x2 ] `2XTUPLE-0K2 =HIDDENR1 f .FUNCT-1K1 y2"
                using funct_1_def_3 sorry
              have "[TARSKIK4 y2,[TARSKIK4 x1,x2 ] `2XTUPLE-0K2 ] inHIDDENR3 f"
                using A31 funct_1_th_1 sorry
              then obtain X2 where
                [ty]:"X2 be setHIDDENM2" and 
                A32: "[TARSKIK4 y2,[TARSKIK4 x1,x2 ] `2XTUPLE-0K2 ] inHIDDENR3 X2"and A33: "X2 inTARSKIR2 Z"
                using tarski_def_4 sorry
              obtain f2 where
                [ty]:"f2 be FunctionFUNCT-1M1" and 
                A34: "f2 =XBOOLE-0R4 X2"and "f2 be one-to-oneFUNCT-1V2"and A35: "domRELAT-1K1 f2 =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f2,rngFUNCT-1K2 f2 :]"
                using A1 A4 A33 sorry
              have "f2 c=RELAT-1R2 f"
                using A33 A34 zfmisc_1_th_74 sorry
              then have A36: "domRELAT-1K1 f2 c=TARSKIR1 domRELAT-1K1 f"
                using relat_1_th_11 sorry
              have "[TARSKIK4 y1,[TARSKIK4 x1,x2 ] `1XTUPLE-0K1 ] inHIDDENR3 f"
                using A30 funct_1_th_1 sorry
              then obtain X1 where
                [ty]:"X1 be setHIDDENM2" and 
                A37: "[TARSKIK4 y1,[TARSKIK4 x1,x2 ] `1XTUPLE-0K1 ] inHIDDENR3 X1"and A38: "X1 inTARSKIR2 Z"
                using tarski_def_4 sorry
              obtain f1 where
                [ty]:"f1 be FunctionFUNCT-1M1" and 
                A39: "f1 =XBOOLE-0R4 X1"and "f1 be one-to-oneFUNCT-1V2"and A40: "domRELAT-1K1 f1 =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f1,rngFUNCT-1K2 f1 :]"
                using A1 A4 A38 sorry
              have "(X1,X2)are-c=-comparableXBOOLE-0R3"
                using A5 A38 A33 ordinal1_def_8 sorry
              then have "X1 c=TARSKIR1 X2 or X2 c=TARSKIR1 X1"
                 sorry
              then have "((y1 inHIDDENR3 domRELAT-1K1 f1 & y2 inHIDDENR3 domRELAT-1K1 f1) & f1 .FUNCT-1K1 y1 =HIDDENR1 [TARSKIK4 x1,x2 ] `1XTUPLE-0K1) & f1 .FUNCT-1K1 y2 =HIDDENR1 [TARSKIK4 x1,x2 ] `2XTUPLE-0K2 or ((y1 inHIDDENR3 domRELAT-1K1 f2 & y2 inHIDDENR3 domRELAT-1K1 f2) & f2 .FUNCT-1K1 y1 =HIDDENR1 [TARSKIK4 x1,x2 ] `1XTUPLE-0K1) & f2 .FUNCT-1K1 y2 =HIDDENR1 [TARSKIK4 x1,x2 ] `2XTUPLE-0K2"
                using A37 A32 A39 A34 funct_1_th_1 sorry
              then have "[TARSKIK4 x1,x2 ] `1XTUPLE-0K1 inHIDDENR3 rngFUNCT-1K2 f1 & [TARSKIK4 x1,x2 ] `2XTUPLE-0K2 inHIDDENR3 rngFUNCT-1K2 f1 or [TARSKIK4 x1,x2 ] `1XTUPLE-0K1 inHIDDENR3 rngFUNCT-1K2 f2 & [TARSKIK4 x1,x2 ] `2XTUPLE-0K2 inHIDDENR3 rngFUNCT-1K2 f2"
                using funct_1_def_3 sorry
              then have A41: "[TARSKIK4 x1,x2 ] inHIDDENR3 domRELAT-1K1 f1 or [TARSKIK4 x1,x2 ] inHIDDENR3 domRELAT-1K1 f2"
                using A40 A35 zfmisc_1_th_87 sorry
              have "f1 c=RELAT-1R2 f"
                using A38 A39 zfmisc_1_th_74 sorry
              then have "domRELAT-1K1 f1 c=TARSKIR1 domRELAT-1K1 f"
                using relat_1_th_11 sorry
              thus "[TARSKIK4 x1,x2 ] inHIDDENR3 domRELAT-1K1 f"
                using A41 A36 sorry
            qed "sorry"
            thus "[:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :] c=TARSKIR1 domRELAT-1K1 f"
              using relat_1_def_3 sorry
          qed
          thus "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
            using xboole_0_def_10 sorry
        qed
        have A42: "rngFUNCT-1K2 f c=TARSKIR1 M"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 M"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 f"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A43: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have "[TARSKIK4 x,y ] inHIDDENR3 unionTARSKIK3 Z"
              using A43 funct_1_def_2 sorry
            then obtain Y where
              [ty]:"Y be setHIDDENM2" and 
              A44: "[TARSKIK4 x,y ] inHIDDENR3 Y"and A45: "Y inTARSKIR2 Z"
              using tarski_def_4 sorry
            have "Y inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 M,M :],M)"
              using A1 A4 A45 sorry
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A46: "Y =XBOOLE-0R4 g"and "domRELAT-1K1 g c=TARSKIR1 [:ZFMISC-1K2 M,M :]"and A47: "rngFUNCT-1K2 g c=TARSKIR1 M"
              using partfun1_def_3 sorry
            have "x inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =HIDDENR1 y"
              using A44 A46 funct_1_th_1 sorry
            then have "y inHIDDENR3 rngFUNCT-1K2 g"
              using funct_1_def_3 sorry
            thus "y inHIDDENR3 M"
              using A47 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 M"
            using tarski_def_3 sorry
        qed
        have "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 M,M :]"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 [:ZFMISC-1K2 M,M :]"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 domRELAT-1K1 f"
            then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 unionTARSKIK3 Z"
              using funct_1_def_2 sorry
            then obtain Y where
              [ty]:"Y be setHIDDENM2" and 
              A48: "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Y"and A49: "Y inTARSKIR2 Z"
              using tarski_def_4 sorry
            have "Y inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 M,M :],M)"
              using A1 A4 A49 sorry
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A50: "Y =XBOOLE-0R4 g"and A51: "domRELAT-1K1 g c=TARSKIR1 [:ZFMISC-1K2 M,M :]"and "rngFUNCT-1K2 g c=TARSKIR1 M"
              using partfun1_def_3 sorry
            have "x inHIDDENR3 domRELAT-1K1 g"
              using A48 A50 funct_1_th_1 sorry
            thus "x inHIDDENR3 [:ZFMISC-1K2 M,M :]"
              using A51 sorry
          qed "sorry"
          thus "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 M,M :]"
            using tarski_def_3 sorry
        qed
        then have "f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 M,M :],M)"
          using A42 partfun1_def_3 sorry
        thus "unionTARSKIK3 Z inTARSKIR2 X"
          using A1 A12 A23 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A52: "f be one-to-oneFUNCT-1V2"and A53: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :] & rngFUNCT-1K2 f =XBOOLE-0R4 omegaORDINAL1K4"
      using card_4_th_5 sorry
    assume A54: " not M be finiteFINSET-1V1"
    then have " not M inTARSKIR2 omegaORDINAL1K4"
       sorry
    then have A55: "omegaORDINAL1K4 c=ORDINAL1R1 M"
      using card_1_th_4 sorry
    then have "[:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :] c=RELAT-1R2 [:ZFMISC-1K2 M,M :]"
      using zfmisc_1_th_96 sorry
    then have "f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 M,M :],M)"
      using A53 A55 partfun1_def_3 sorry
    then have "X <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A52 A53 sorry
    then obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A56: "Y inTARSKIR2 X"and A57: " for Z be setHIDDENM2 holds Z inTARSKIR2 X & Z <>HIDDENR2 Y implies  not Y c=TARSKIR1 Z"
      using A3 orders_1_th_67 sorry
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A58: "f =XBOOLE-0R4 Y"and A59: "f be one-to-oneFUNCT-1V2"and A60: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
      using A1 A56 sorry
    let ?A = "rngFUNCT-1K2 f"
    have A61: "([:ZFMISC-1K2 ?A,?A :],?A)are-equipotentWELLORD2R2"
      using A59 A60 sorry
    have "Y inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 M,M :],M)"
      using A1 A56 sorry
    then have A62: " ex f be FunctionFUNCT-1M1 st (Y =XBOOLE-0R4 f & domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 M,M :]) & rngFUNCT-1K2 f c=TARSKIR1 M"
      using partfun1_def_3 sorry
    let ?N = "cardCARD-1K1 ?A"
    have A63: "cardCARD-1K1 M =XBOOLE-0R4 M"
       sorry
    then have A64: "?N c=ORDINAL1R1 M"
      using A58 A62 card_1_th_11 sorry
    have A65: "rngFUNCT-1K2 f be finiteFINSET-1V1 implies  False "
    proof(rule impI)
      have "omegaORDINAL1K4 \\SUBSET-1K6 ?A missesXBOOLE-0R1 ?A"
        using xboole_1_th_79 sorry
      then have A66: "(omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> ?A =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      then have "[:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> ?A,?A /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 ?A) :] =RELAT-1R1 {}XBOOLE-0K1"
        using zfmisc_1_th_90 sorry
      then have A67: "([:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]) =RELAT-1R1 {}XBOOLE-0K1"
        using zfmisc_1_th_100 sorry
      have "[:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 ?A),(omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> ?A :] =RELAT-1R1 {}XBOOLE-0K1"
        using A66 zfmisc_1_th_90 sorry
      then have "([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])/\\SUBSET-1K8\<^bsub>([:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :])\<^esub> ([:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :]) =RELAT-1R1 {}XBOOLE-0K1"
        using zfmisc_1_th_100 sorry
      then have A68: "[:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] missesXBOOLE-0R1 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :]"
         sorry
      have "[:ZFMISC-1K2 ?A /\\XBOOLE-0K3 ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> ?A :] =RELAT-1R1 {}XBOOLE-0K1"
        using A66 zfmisc_1_th_90 sorry
      then have A69: "([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 ?A,?A :]) =RELAT-1R1 {}XBOOLE-0K1"
        using zfmisc_1_th_100 sorry
      have "[:ZFMISC-1K2 (omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> ?A,?A /\\XBOOLE-0K3 ?A :] =RELAT-1R1 {}XBOOLE-0K1"
        using A66 zfmisc_1_th_90 sorry
      then have A70: "{}XBOOLE-0K1 \\/XBOOLE-0K2 {}XBOOLE-0K1 =RELAT-1R1 {}XBOOLE-0K1 & ([:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 ?A,?A :]) =RELAT-1R1 {}XBOOLE-0K1"
        using zfmisc_1_th_100 sorry
      have "[:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> ?A :] =RELAT-1R1 {}XBOOLE-0K1"
        using A66 zfmisc_1_th_90 sorry
      then have "([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])/\\SUBSET-1K8\<^bsub>([:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :])\<^esub> ([:ZFMISC-1K2 ?A,?A :]) =RELAT-1R1 {}XBOOLE-0K1"
        using zfmisc_1_th_100 sorry
      then have A71: "([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 ?A,?A :]) =RELAT-1R1 {}XBOOLE-0K1"
        using A70 xboole_1_th_23 sorry
      have A72: "omegaORDINAL1K4 c=ORDINAL1R1 omegaORDINAL1K4 +`CARD-2K1 ?N & omegaORDINAL1K4 +`CARD-2K1 omegaORDINAL1K4 =XBOOLE-0R4 omegaORDINAL1K4"
        using card_2_th_75 card_2_th_94 sorry
      assume A73: "?A be finiteFINSET-1V1"
      then have "?N inTARSKIR2 omegaORDINAL1K4"
        using card_3_th_42 sorry
      then have "omegaORDINAL1K4 +`CARD-2K1 ?N c=ORDINAL1R1 omegaORDINAL1K4 +`CARD-2K1 omegaORDINAL1K4"
        using card_2_th_83 sorry
      then have A74: "omegaORDINAL1K4 =XBOOLE-0R4 omegaORDINAL1K4 +`CARD-2K1 ?N"
        using A72 sorry
      have "?N =XBOOLE-0R4 cardCARD-1K1 (cardCARD-1K1 ?A)"
         sorry
      then have "omegaORDINAL1K4 *`CARD-2K2 ?N c=ORDINAL1R1 omegaORDINAL1K4"
        using A73 card_2_th_89 sorry
      then have A75: "omegaORDINAL1K4 +`CARD-2K1 omegaORDINAL1K4 *`CARD-2K2 ?N =XBOOLE-0R4 omegaORDINAL1K4"
        using card_2_th_76 sorry
      have A76: "omegaORDINAL1K4 =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4 \\SUBSET-1K6 ?A)"
        using A73 A74 card_2_th_98 card_3_th_42 sorry
      have "[:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)/\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 ?A) :] =RELAT-1R1 {}XBOOLE-0K1"
        using A66 zfmisc_1_th_90 sorry
      then have "([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])/\\SUBSET-1K8\<^bsub>([:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :])\<^esub> ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]) =RELAT-1R1 {}XBOOLE-0K1"
        using zfmisc_1_th_100 sorry
      then have "([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]) =HIDDENR1 {}XBOOLE-0K1 \\/XBOOLE-0K2 {}XBOOLE-0K1"
        using A67 xboole_1_th_23 sorry
      also have "... = {}XBOOLE-0K1"
         sorry
      finally have "([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]) =HIDDENR1 {}XBOOLE-0K1"
         sorry
      then have "[:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :] missesXBOOLE-0R1 [:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]"
         sorry
      then have "cardCARD-1K1 (([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])\\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]) =HIDDENR1 cardCARD-1K1 ([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :]) +`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])"
        using card_2_th_35 sorry
      also have "... = (cardCARD-1K1 ([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]) +`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :]))+`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])"
        using A68 card_2_th_35 sorry
      also have "... = (cardCARD-1K1 ([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]) +`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,?N :]))+`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])"
        using A76 card_2_th_7 sorry
      also have "... = (cardCARD-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,omegaORDINAL1K4 :]) +`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,?N :]))+`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])"
        using A76 card_2_th_7 sorry
      also have "... = (omegaORDINAL1K4 +`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,?N :]))+`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 ?N,omegaORDINAL1K4 :])"
        using A76 card_4_th_5 card_2_th_7 sorry
      also have "... = (omegaORDINAL1K4 +`CARD-2K1 omegaORDINAL1K4 *`CARD-2K2 ?N)+`CARD-2K1 cardCARD-1K1 ([:ZFMISC-1K2 ?N,omegaORDINAL1K4 :])"
        using card_2_def_2 sorry
      also have "... = (omegaORDINAL1K4 +`CARD-2K1 omegaORDINAL1K4 *`CARD-2K2 ?N)+`CARD-2K1 ?N *`CARD-2K2 omegaORDINAL1K4"
        using card_2_def_2 sorry
      finally have "cardCARD-1K1 (([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])\\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]) =HIDDENR1 (omegaORDINAL1K4 +`CARD-2K1 omegaORDINAL1K4 *`CARD-2K2 ?N)+`CARD-2K1 ?N *`CARD-2K2 omegaORDINAL1K4"
         sorry
      then have "(([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])\\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :],omegaORDINAL1K4 \\SUBSET-1K6 ?A)are-equipotentWELLORD2R2"
        using A76 A75 card_1_th_5 sorry
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A77: "g be one-to-oneFUNCT-1V2"and A78: "domRELAT-1K1 g =XBOOLE-0R4 ([:MCART-1K8\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> omegaORDINAL1K4 \\SUBSET-1K6 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,?A :])\\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :]"and A79: "rngFUNCT-1K2 g =XBOOLE-0R4 omegaORDINAL1K4 \\SUBSET-1K6 ?A"
         sorry
      have A80: "domRELAT-1K1 (g +*FUNCT-4K1 f) =XBOOLE-0R4 domRELAT-1K1 g \\/XBOOLE-0K2 domRELAT-1K1 f"
        using funct_4_def_1 sorry
      then have A81: "domRELAT-1K1 (g +*FUNCT-4K1 f) =HIDDENR1 ([:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)\\/XBOOLE-0K2 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :])\\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,?A :]"
        using A60 A78 zfmisc_1_th_97 sorry
      also have "... = [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)\\/XBOOLE-0K2 ?A :] \\/XBOOLE-0K2 ([:ZFMISC-1K2 ?A,omegaORDINAL1K4 \\SUBSET-1K6 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,?A :])"
        using xboole_1_th_4 sorry
      also have "... = [:ZFMISC-1K2 omegaORDINAL1K4 \\SUBSET-1K6 ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)\\/XBOOLE-0K2 ?A :] \\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)\\/XBOOLE-0K2 ?A :]"
        using zfmisc_1_th_97 sorry
      also have "... = [:ZFMISC-1K2 (omegaORDINAL1K4 \\SUBSET-1K6 ?A)\\/XBOOLE-0K2 ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)\\/XBOOLE-0K2 ?A :]"
        using zfmisc_1_th_97 sorry
      also have "... = [:ZFMISC-1K2 omegaORDINAL1K4 \\/XBOOLE-0K2 ?A,(omegaORDINAL1K4 \\SUBSET-1K6 ?A)\\/XBOOLE-0K2 ?A :]"
        using xboole_1_th_39 sorry
      also have "... = [:ZFMISC-1K2 omegaORDINAL1K4 \\/XBOOLE-0K2 ?A,omegaORDINAL1K4 \\/XBOOLE-0K2 ?A :]"
        using xboole_1_th_39 sorry
      finally have "domRELAT-1K1 (g +*FUNCT-4K1 f) =HIDDENR1 [:ZFMISC-1K2 omegaORDINAL1K4 \\/XBOOLE-0K2 ?A,omegaORDINAL1K4 \\/XBOOLE-0K2 ?A :]"
         sorry
      have "{}XBOOLE-0K1 \\/XBOOLE-0K2 {}XBOOLE-0K1 =RELAT-1R1 {}XBOOLE-0K1"
         sorry
      then have "domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
        using A60 A78 A71 A69 xboole_1_th_23 sorry
      then have A82: "domRELAT-1K1 g missesXBOOLE-0R1 domRELAT-1K1 f"
         sorry
      then have "g c=RELAT-1R2 g +*FUNCT-4K1 f"
        using funct_4_th_32 sorry
      then have "rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (g +*FUNCT-4K1 f) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (g +*FUNCT-4K1 f)"
        using funct_4_th_18 relat_1_th_11 sorry
      then have "rngFUNCT-1K2 (g +*FUNCT-4K1 f) c=TARSKIR1 rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 f & rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (g +*FUNCT-4K1 f)"
        using funct_4_th_17 xboole_1_th_8 sorry
      then have A83: "rngFUNCT-1K2 (g +*FUNCT-4K1 f) =HIDDENR1 rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 f"
         sorry
      also have "... = omegaORDINAL1K4 \\/XBOOLE-0K2 ?A"
        using A79 xboole_1_th_39 sorry
      finally have "rngFUNCT-1K2 (g +*FUNCT-4K1 f) =HIDDENR1 omegaORDINAL1K4 \\/XBOOLE-0K2 ?A"
         sorry
      have A84: "g +*FUNCT-4K1 f be one-to-oneFUNCT-1V2"
      proof-
        have "rngFUNCT-1K2 f missesXBOOLE-0R1 rngFUNCT-1K2 g"
          using A79 xboole_1_th_79 sorry
        then have A85: "rngFUNCT-1K2 f /\\XBOOLE-0K3 rngFUNCT-1K2 g =XBOOLE-0R4 {}XBOOLE-0K1"
           sorry
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 f) & y inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 f) implies  not ((g +*FUNCT-4K1 f).FUNCT-1K1 x =HIDDENR1 (g +*FUNCT-4K1 f).FUNCT-1K1 y &  not x =HIDDENR1 y)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A86: "x inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 f)"
            and A87: "y inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 f)"
          have A88: "y inHIDDENR3 domRELAT-1K1 g or y inHIDDENR3 domRELAT-1K1 f"
            using A80 A87 xboole_0_def_3 sorry
          have "x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 g"
            using A80 A86 xboole_0_def_3 sorry
          then have "((((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x & (g +*FUNCT-4K1 f).FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 y) & (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y) or ((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x & (g +*FUNCT-4K1 f).FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y) & (g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y implies x =HIDDENR1 y)) or (((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x & (g +*FUNCT-4K1 f).FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y) & f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f) & g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 g) or (((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x & (g +*FUNCT-4K1 f).FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 y) & g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g) & f .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 f"
            using A59 A77 A82 A88 funct_1_def_3 funct_4_th_13 funct_4_th_16 sorry
          thus " not ((g +*FUNCT-4K1 f).FUNCT-1K1 x =HIDDENR1 (g +*FUNCT-4K1 f).FUNCT-1K1 y &  not x =HIDDENR1 y)"
            using A85 xboole_0_def_4 sorry
        qed "sorry"
        thus "g +*FUNCT-4K1 f be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      let ?x = "the ElementSUBSET-1M1-of omegaORDINAL1K4 \\SUBSET-1K6 ?A"
      have "omegaORDINAL1K4 \\SUBSET-1K6 ?A <>HIDDENR2 {}XBOOLE-0K1"
        using A73 A74 card_1_th_68 card_3_th_42 sorry
      then have A89: "?x inTARSKIR2 omegaORDINAL1K4 &  not ?x inTARSKIR2 ?A"
        using xboole_0_def_5 sorry
      have A90: "omegaORDINAL1K4 \\/XBOOLE-0K2 ?A c=TARSKIR1 M"
        using A55 A58 A62 xboole_1_th_8 sorry
      then have "[:ZFMISC-1K2 omegaORDINAL1K4 \\/XBOOLE-0K2 ?A,omegaORDINAL1K4 \\/XBOOLE-0K2 ?A :] c=RELAT-1R2 [:ZFMISC-1K2 M,M :]"
        using zfmisc_1_th_96 sorry
      then have "g +*FUNCT-4K1 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 M,M :],M)"
        using A83 A81 A90 partfun1_def_3 sorry
      then have "g +*FUNCT-4K1 f inTARSKIR2 X"
        using A1 A83 A81 A84 sorry
      then have "g +*FUNCT-4K1 f =FUNCT-1R1 f"
        using A57 A58 funct_4_th_25 sorry
      thus " False "
        using A83 A89 xboole_0_def_3 sorry
    qed
    have A91: "cardCARD-1K1 (rngFUNCT-1K2 f) <>HIDDENR2 M implies  False "
    proof(rule impI)
      have "?N *`CARD-2K2 ?N =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 ?N,?N :])"
        using card_2_def_2 sorry
      then have A92: "?N *`CARD-2K2 ?N =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 ?A,?A :])"
        using card_2_th_7 sorry
      have "([:ZFMISC-1K2 ?A,?A :],?A)are-equipotentWELLORD2R2"
        using A59 A60 sorry
      then have A93: "?N *`CARD-2K2 ?N =XBOOLE-0R4 ?N"
        using A92 card_1_th_5 sorry
      assume "?N <>HIDDENR2 M"
      then have A94: "?N inTARSKIR2 M"
        using A64 card_1_th_3 sorry
      have "M +`CARD-2K1 ?N =XBOOLE-0R4 M"
        using A54 A64 card_2_th_76 sorry
      then have "cardCARD-1K1 (M \\SUBSET-1K6 ?A) =XBOOLE-0R4 M"
        using A63 A94 card_2_th_98 sorry
      then obtain h where
        [ty]:"h be FunctionFUNCT-1M1" and 
        A95: "h be one-to-oneFUNCT-1V2 & domRELAT-1K1 h =XBOOLE-0R4 ?A"and A96: "rngFUNCT-1K2 h c=TARSKIR1 M \\SUBSET-1K6 ?A"
        using A64 card_1_th_10 sorry
      let ?B = "rngFUNCT-1K2 h"
      have "(?A,?B)are-equipotentWELLORD2R2"
        using A95 sorry
      then have A97: "?N =XBOOLE-0R4 cardCARD-1K1 ?B"
        using card_1_th_5 sorry
      have "?A missesXBOOLE-0R1 M \\SUBSET-1K6 ?A & ?A /\\XBOOLE-0K3 ?B c=TARSKIR1 ?A /\\SUBSET-1K9\<^bsub>(M)\<^esub> (M \\SUBSET-1K6 ?A)"
        using A96 xboole_1_th_26 xboole_1_th_79 sorry
      then have "?A /\\XBOOLE-0K3 ?B c=TARSKIR1 {}XBOOLE-0K1"
         sorry
      then have "?A /\\XBOOLE-0K3 ?B =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      then have A98: "?A missesXBOOLE-0R1 ?B"
         sorry
      have "(?A \\/XBOOLE-0K2 ?B)\\SUBSET-1K6 ?A =HIDDENR1 ?B \\SUBSET-1K6 ?A"
        using xboole_1_th_40 sorry
      also have "... = ?B"
        using A98 xboole_1_th_83 sorry
      finally have "(?A \\/XBOOLE-0K2 ?B)\\SUBSET-1K6 ?A =HIDDENR1 ?B"
         sorry
      then have A99: "[:ZFMISC-1K2 ?B,?B :] c=RELAT-1R2 [:ZFMISC-1K2 (?A \\/XBOOLE-0K2 ?B)\\SUBSET-1K6 ?A,?A \\/XBOOLE-0K2 ?B :]"
        using zfmisc_1_th_96 sorry
      have "[:ZFMISC-1K2 (?A \\/XBOOLE-0K2 ?B)\\SUBSET-1K6 ?A,?A \\/XBOOLE-0K2 ?B :] c=RELAT-1R2 [:ZFMISC-1K2 (?A \\/XBOOLE-0K2 ?B)\\SUBSET-1K6 ?A,?A \\/XBOOLE-0K2 ?B :] \\/XBOOLE-0K2 [:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,(?A \\/XBOOLE-0K2 ?B)\\SUBSET-1K6 ?A :] & [:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\SUBSET-1K6 [:ZFMISC-1K2 ?A,?A :] =RELAT-1R1 [:ZFMISC-1K2 (?A \\/XBOOLE-0K2 ?B)\\SUBSET-1K6 ?A,?A \\/XBOOLE-0K2 ?B :] \\/XBOOLE-0K2 [:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,(?A \\/XBOOLE-0K2 ?B)\\SUBSET-1K6 ?A :]"
        using xboole_1_th_7 zfmisc_1_th_103 sorry
      then have A100: "[:ZFMISC-1K2 ?B,?B :] c=RELAT-1R2 [:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\SUBSET-1K6 [:ZFMISC-1K2 ?A,?A :]"
        using A99 sorry
      have "?N +`CARD-2K1 ?N =XBOOLE-0R4 ?N"
        using A65 card_2_th_75 sorry
      then have "cardCARD-1K1 (?A \\/XBOOLE-0K2 ?B) =XBOOLE-0R4 ?N"
        using A97 A98 card_2_th_35 sorry
      then have "cardCARD-1K1 ([:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :]) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 ?N,?N :])"
        using card_2_th_7 sorry
      also have "... = ?N"
        using A93 card_2_def_2 sorry
      finally have "cardCARD-1K1 ([:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :]) =HIDDENR1 ?N"
         sorry
      then have A101: "cardCARD-1K1 ([:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\SUBSET-1K6 [:ZFMISC-1K2 ?A,?A :]) c=ORDINAL1R1 ?N"
        using card_1_th_11 sorry
      have "?N =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 ?N,?N :])"
        using A93 card_2_def_2 sorry
      then have "?N =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 ?B,?B :])"
        using A97 card_2_th_7 sorry
      then have "?N c=ORDINAL1R1 cardCARD-1K1 ([:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\SUBSET-1K6 [:ZFMISC-1K2 ?A,?A :])"
        using A100 card_1_th_11 sorry
      then have "cardCARD-1K1 ([:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\SUBSET-1K6 [:ZFMISC-1K2 ?A,?A :]) =XBOOLE-0R4 ?N"
        using A101 sorry
      then have "([:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\SUBSET-1K6 [:ZFMISC-1K2 ?A,?A :],?B)are-equipotentWELLORD2R2"
        using A97 card_1_th_5 sorry
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A102: "g be one-to-oneFUNCT-1V2"and A103: "domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\SUBSET-1K6 [:ZFMISC-1K2 ?A,?A :]"and A104: "rngFUNCT-1K2 g =XBOOLE-0R4 ?B"
         sorry
      have A105: "domRELAT-1K1 (g +*FUNCT-4K1 f) =XBOOLE-0R4 domRELAT-1K1 g \\/XBOOLE-0K2 domRELAT-1K1 f"
        using funct_4_def_1 sorry
      then have "?A c=TARSKIR1 ?A \\/XBOOLE-0K2 ?B & domRELAT-1K1 (g +*FUNCT-4K1 f) =XBOOLE-0R4 [:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\/XBOOLE-0K2 [:ZFMISC-1K2 ?A,?A :]"
        using A60 A103 xboole_1_th_7 xboole_1_th_39 sorry
      then have A106: "domRELAT-1K1 (g +*FUNCT-4K1 f) =XBOOLE-0R4 [:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :]"
        using xboole_1_th_12 zfmisc_1_th_96 sorry
      have A107: "[:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] \\SUBSET-1K6 [:ZFMISC-1K2 ?A,?A :] missesXBOOLE-0R1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 f :]"
        using xboole_1_th_79 sorry
      have A108: "g +*FUNCT-4K1 f be one-to-oneFUNCT-1V2"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 f) & y inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 f) implies ((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 (g +*FUNCT-4K1 f).FUNCT-1K1 y implies x =HIDDENR1 y)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A109: "x inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 f)"
            and A110: "y inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 f)"
          have A111: "y inHIDDENR3 domRELAT-1K1 g or y inHIDDENR3 domRELAT-1K1 f"
            using A105 A110 xboole_0_def_3 sorry
          have "x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 g"
            using A105 A109 xboole_0_def_3 sorry
          then have A112: "((((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x & (g +*FUNCT-4K1 f).FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 y) & (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y) or ((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x & (g +*FUNCT-4K1 f).FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y) & (g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y implies x =HIDDENR1 y)) or (((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x & (g +*FUNCT-4K1 f).FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y) & f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f) & g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 g) or (((g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x & (g +*FUNCT-4K1 f).FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 y) & g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g) & f .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 f"
            using A59 A60 A102 A103 A107 A111 funct_1_def_3 funct_4_th_13 funct_4_th_16 sorry
          have "?A missesXBOOLE-0R1 M \\SUBSET-1K6 ?A & ?A /\\XBOOLE-0K3 ?B c=TARSKIR1 ?A /\\SUBSET-1K9\<^bsub>(M)\<^esub> (M \\SUBSET-1K6 ?A)"
            using A96 xboole_1_th_26 xboole_1_th_79 sorry
          then have A113: "rngFUNCT-1K2 f /\\XBOOLE-0K3 rngFUNCT-1K2 g c=TARSKIR1 {}XBOOLE-0K1"
            using A104 sorry
          assume "(g +*FUNCT-4K1 f).FUNCT-1K1 x =XBOOLE-0R4 (g +*FUNCT-4K1 f).FUNCT-1K1 y"
          thus "x =HIDDENR1 y"
            using A113 A112 xboole_0_def_4 sorry
        qed "sorry"
        thus "g +*FUNCT-4K1 f be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      let ?x = "the ElementSUBSET-1M1-of ?B"
      have A114: "?B <>HIDDENR2 {}XBOOLE-0K1"
        using A65 A97 sorry
      then have "?x inTARSKIR2 M \\SUBSET-1K6 ?A"
        using A96 sorry
      then have A115: " not ?x inTARSKIR2 rngFUNCT-1K2 f"
        using xboole_0_def_5 sorry
      have "g c=RELAT-1R2 g +*FUNCT-4K1 f"
        using A60 A103 funct_4_th_32 xboole_1_th_79 sorry
      then have "rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (g +*FUNCT-4K1 f) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (g +*FUNCT-4K1 f)"
        using funct_4_th_18 relat_1_th_11 sorry
      then have A116: "rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (g +*FUNCT-4K1 f)"
        using xboole_1_th_8 sorry
      have "rngFUNCT-1K2 (g +*FUNCT-4K1 f) c=TARSKIR1 rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 f"
        using funct_4_th_17 sorry
      then have A117: "rngFUNCT-1K2 (g +*FUNCT-4K1 f) =XBOOLE-0R4 rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 f"
        using A116 sorry
      have "?B c=TARSKIR1 M"
        using A96 xboole_1_th_1 sorry
      then have A118: "?A \\/XBOOLE-0K2 ?B c=TARSKIR1 M"
        using A58 A62 xboole_1_th_8 sorry
      then have "[:ZFMISC-1K2 ?A \\/XBOOLE-0K2 ?B,?A \\/XBOOLE-0K2 ?B :] c=RELAT-1R2 [:ZFMISC-1K2 M,M :]"
        using zfmisc_1_th_96 sorry
      then have "g +*FUNCT-4K1 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 M,M :],M)"
        using A104 A117 A106 A118 partfun1_def_3 sorry
      then have A119: "g +*FUNCT-4K1 f inTARSKIR2 X"
        using A1 A104 A117 A106 A108 sorry
      have "?x inTARSKIR2 rngFUNCT-1K2 (g +*FUNCT-4K1 f)"
        using A104 A117 A114 xboole_0_def_3 sorry
      thus " False "
        using A57 A58 A119 A115 funct_4_th_25 sorry
    qed
    then have "M *`CARD-2K2 M =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 ?N,?N :])"
      using card_2_def_2 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 ?A,?A :])"
      using card_2_th_7 sorry
    finally have "M *`CARD-2K2 M =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 ?A,?A :])"
       sorry
    thus "M *`CARD-2K2 M =XBOOLE-0R4 M"
      using A91 A61 card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_16:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ( not M be finiteFINSET-1V1 & 0NUMBERSK6 inTARSKIR2 N) & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies M *`CARD-2K2 N =XBOOLE-0R4 M & N *`CARD-2K2 M =XBOOLE-0R4 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 implies (0NUMBERSK6 inTARSKIR2 N implies (N c=ORDINAL1R1 M or N inTARSKIR2 M implies M *`CARD-2K2 N =XBOOLE-0R4 M & N *`CARD-2K2 M =XBOOLE-0R4 M))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: "\<one>\<^sub>M *`CARD-2K2 M =XBOOLE-0R4 M"
      using card_2_th_21 sorry
    assume " not M be finiteFINSET-1V1"
    then have A2: "M *`CARD-2K2 M =XBOOLE-0R4 M"
      using card_4_th_15 sorry
    assume "0NUMBERSK6 inTARSKIR2 N"
    then have "\<one>\<^sub>M c=ORDINAL1R1 N"
      using card_2_th_68 sorry
    then have A3: "\<one>\<^sub>M *`CARD-2K2 M c=ORDINAL1R1 N *`CARD-2K2 M"
      using card_2_th_90 sorry
    assume "N c=ORDINAL1R1 M or N inTARSKIR2 M"
    then have "N *`CARD-2K2 M c=ORDINAL1R1 M *`CARD-2K2 M"
      using card_2_th_90 sorry
    thus "M *`CARD-2K2 N =XBOOLE-0R4 M & N *`CARD-2K2 M =XBOOLE-0R4 M"
      using A2 A3 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_17:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies M *`CARD-2K2 N c=ORDINAL1R1 M & N *`CARD-2K2 M c=ORDINAL1R1 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies M *`CARD-2K2 N c=ORDINAL1R1 M & N *`CARD-2K2 M c=ORDINAL1R1 M"
  proof(rule ballI,rule ballI,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume " not M be finiteFINSET-1V1 & (N c=ORDINAL1R1 M or N inTARSKIR2 M)"
    then have "M *`CARD-2K2 N =XBOOLE-0R4 M or  not 0NUMBERSK6 inTARSKIR2 N"
      using card_4_th_16 sorry
    then have "M *`CARD-2K2 N c=ORDINAL1R1 M or (N =XBOOLE-0R4 0NUMBERSK6 & M *`CARD-2K2 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6) & 0NUMBERSK6 c=ORDINAL1R1 M"
      using card_2_th_20 ordinal3_th_8 sorry
    thus "M *`CARD-2K2 N c=ORDINAL1R1 M & N *`CARD-2K2 M c=ORDINAL1R1 M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_18:
" for X be setHIDDENM2 holds  not X be finiteFINSET-1V1 implies ([:ZFMISC-1K2 X,X :],X)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,X :]) =XBOOLE-0R4 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  not X be finiteFINSET-1V1 implies ([:ZFMISC-1K2 X,X :],X)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,X :]) =XBOOLE-0R4 cardCARD-1K1 X"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume " not X be finiteFINSET-1V1"
    then have "cardCARD-1K1 X *`CARD-2K2 cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 X"
      using card_4_th_15 sorry
    then have "cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 X :]) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_2_def_2 sorry
    then have "cardCARD-1K1 ([:ZFMISC-1K2 X,X :]) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_2_th_7 sorry
    thus "([:ZFMISC-1K2 X,X :],X)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,X :]) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_19:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( not X be finiteFINSET-1V1 & Y be finiteFINSET-1V1) & Y <>HIDDENR2 {}XBOOLE-0K1 implies ([:ZFMISC-1K2 X,Y :],X)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not X be finiteFINSET-1V1 & (Y be finiteFINSET-1V1 & Y <>HIDDENR2 {}XBOOLE-0K1) implies ([:ZFMISC-1K2 X,Y :],X)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: " not X be finiteFINSET-1V1"
      and A2: "Y be finiteFINSET-1V1 & Y <>HIDDENR2 {}XBOOLE-0K1"
    have "cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 X & 0NUMBERSK6 inTARSKIR2 cardCARD-1K1 Y"
      using A1 A2 ordinal3_th_8 sorry
    then have "cardCARD-1K1 X *`CARD-2K2 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X"
      using A1 card_4_th_16 sorry
    then have "cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :]) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_2_def_2 sorry
    then have "cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_2_th_7 sorry
    thus "([:ZFMISC-1K2 X,Y :],X)are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_20:
" for L be CardinalCARD-1M1 holds  for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K inTARSKIR2 L & M inTARSKIR2 N implies K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N & M *`CARD-2K2 K inTARSKIR2 L *`CARD-2K2 N"
proof-
  have " for L be CardinalCARD-1M1 holds  for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not ((K inTARSKIR2 L & M inTARSKIR2 N) &  not (K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N & M *`CARD-2K2 K inTARSKIR2 L *`CARD-2K2 N))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix L assume [ty]: "L be CardinalCARD-1M1"
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: " for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds (K inTARSKIR2 L & M inTARSKIR2 N) & L c=ORDINAL1R1 N implies K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
    proof-
      have " for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K inTARSKIR2 L & (M inTARSKIR2 N & L c=ORDINAL1R1 N) implies K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix K assume [ty]: "K be CardinalCARD-1M1"
        fix L assume [ty]: "L be CardinalCARD-1M1"
        fix M assume [ty]: "M be CardinalCARD-1M1"
        fix N assume [ty]: "N be CardinalCARD-1M1"
        assume A2: "K inTARSKIR2 L"
          and A3: "M inTARSKIR2 N"
          and A4: "L c=ORDINAL1R1 N"
        have A5: "N be finiteFINSET-1V1 implies K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
        proof(rule impI)
          assume A6: "N be finiteFINSET-1V1"
          then have 
            [ty]:"N be finiteFINSET-1V1\<bar>CardinalCARD-1M1"
             sorry
          have 
            [ty]:"L be finiteFINSET-1V1\<bar>CardinalCARD-1M1" and
            [ty]:"M be finiteFINSET-1V1\<bar>CardinalCARD-1M1" and
            [ty]:"K be finiteFINSET-1V1\<bar>CardinalCARD-1M1"
            using A2 A3 A4 A6 card_3_th_92 sorry
          have A7: "cardCARD-1K4 (SegmCARD-1K5 N) =XBOOLE-0R4 N"
             sorry
          have "cardCARD-1K4 (SegmCARD-1K5 M) =XBOOLE-0R4 M"
             sorry
          then have "cardCARD-1K4 M <XXREAL-0R3 cardCARD-1K4 N"
            using A3 A7 nat_1_th_41 sorry
          then have A8: "cardCARD-1K4 K *NAT-1K2 cardCARD-1K4 M <=XXREAL-0R1 cardCARD-1K4 K *NAT-1K2 cardCARD-1K4 N"
            using xreal_1_th_64 sorry
          have A9: "cardCARD-1K4 (SegmCARD-1K5 L) =XBOOLE-0R4 L"
             sorry
          have A10: "L *`CARD-2K2 N =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 (cardCARD-1K4 L *NAT-1K2 cardCARD-1K4 N))"
            using card_2_th_39 sorry
          have "cardCARD-1K4 (SegmCARD-1K5 K) =XBOOLE-0R4 K"
             sorry
          then have "cardCARD-1K4 K <XXREAL-0R3 cardCARD-1K4 L"
            using A2 A9 nat_1_th_41 sorry
          then have "cardCARD-1K4 K *NAT-1K2 cardCARD-1K4 N <XXREAL-0R3 cardCARD-1K4 L *NAT-1K2 cardCARD-1K4 N"
            using A3 xreal_1_th_68 sorry
          then have A11: "cardCARD-1K4 K *NAT-1K2 cardCARD-1K4 M <XXREAL-0R3 cardCARD-1K4 L *NAT-1K2 cardCARD-1K4 N"
            using A8 xxreal_0_th_2 sorry
          have "K *`CARD-2K2 M =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 (cardCARD-1K4 K *NAT-1K2 cardCARD-1K4 M))"
            using card_2_th_39 sorry
          thus "K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
            using A10 A11 nat_1_th_41 sorry
        qed
        have A12: "0NUMBERSK6 inTARSKIR2 L"
          using A2 ordinal3_th_8 sorry
        have " not N be finiteFINSET-1V1 implies K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
        proof(rule impI)
          assume A13: " not N be finiteFINSET-1V1"
          then have A14: "L *`CARD-2K2 N =XBOOLE-0R4 N"
            using A4 A12 card_4_th_16 sorry
          have A15: "omegaORDINAL1K4 c=ORDINAL1R1 N"
            using A13 card_3_th_85 sorry
          have A16: "K be finiteFINSET-1V1 & M be finiteFINSET-1V1 implies K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
          proof(rule impI)
            assume "K be finiteFINSET-1V1 & M be finiteFINSET-1V1"
            then have 
              [ty]:"K be finiteFINSET-1V1\<bar>CardinalCARD-1M1" and
              [ty]:"M be finiteFINSET-1V1\<bar>CardinalCARD-1M1"
               sorry
            have "K *`CARD-2K2 M =HIDDENR1 cardCARD-1K4 (cardCARD-1K4 K *NAT-1K2 cardCARD-1K4 M)"
              using card_2_th_39 sorry
            also have "... = cardCARD-1K4 K *NAT-1K2 cardCARD-1K4 M"
               sorry
            finally have "K *`CARD-2K2 M =HIDDENR1 cardCARD-1K4 K *NAT-1K2 cardCARD-1K4 M"
               sorry
            thus "K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
              using A14 A15 sorry
          qed
          have "K c=ORDINAL1R1 M & (M be finiteFINSET-1V1 or  not M be finiteFINSET-1V1) or M c=ORDINAL1R1 K & (K be finiteFINSET-1V1 or  not K be finiteFINSET-1V1)"
             sorry
          then have "(K be finiteFINSET-1V1 & M be finiteFINSET-1V1 or K *`CARD-2K2 M c=ORDINAL1R1 M) or K *`CARD-2K2 M c=ORDINAL1R1 K & K inTARSKIR2 N"
            using A2 A4 card_4_th_17 sorry
          thus "K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
            using A3 A14 A16 ordinal1_th_12 sorry
        qed
        thus "K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N"
          using A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "L c=ORDINAL1R1 N or N c=ORDINAL1R1 L"
       sorry
    thus " not ((K inTARSKIR2 L & M inTARSKIR2 N) &  not (K *`CARD-2K2 M inTARSKIR2 L *`CARD-2K2 N & M *`CARD-2K2 K inTARSKIR2 L *`CARD-2K2 N))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_21:
" for X be setHIDDENM2 holds  not X be finiteFINSET-1V1 implies cardCARD-1K1 X =XBOOLE-0R4 omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  not X be finiteFINSET-1V1 implies cardCARD-1K1 X =XBOOLE-0R4 omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K1 X"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " not X be finiteFINSET-1V1"
    then have "omegaORDINAL1K4 c=ORDINAL1R1 cardCARD-1K1 X"
      using card_3_th_85 sorry
    thus "cardCARD-1K1 X =XBOOLE-0R4 omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K1 X"
      using A1 card_4_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X <>HIDDENR2 {}XBOOLE-0K1 & X be finiteFINSET-1V1) &  not Y be finiteFINSET-1V1 implies cardCARD-1K1 Y *`CARD-2K2 cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X <>HIDDENR2 {}XBOOLE-0K1 & X be finiteFINSET-1V1) &  not Y be finiteFINSET-1V1 implies cardCARD-1K1 Y *`CARD-2K2 cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1 & X be finiteFINSET-1V1"
      and A2: " not Y be finiteFINSET-1V1"
    have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Y & 0NUMBERSK6 inTARSKIR2 cardCARD-1K1 X"
      using A1 A2 card_3_th_86 ordinal3_th_8 sorry
    thus "cardCARD-1K1 Y *`CARD-2K2 cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
      using A2 card_4_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  not D be finiteFINSET-1V1 & n <>HIDDENR2 0NUMBERSK6 implies (n -tuples-onFINSEQ-2K4 D,D)are-equipotentWELLORD2R2 & cardCARD-1K1 (n -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for n be NatNAT-1M1 holds  not D be finiteFINSET-1V1 & n <>HIDDENR2 0NUMBERSK6 implies (n -tuples-onFINSEQ-2K4 D,D)are-equipotentWELLORD2R2 & cardCARD-1K1 (n -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: " not D be finiteFINSET-1V1"
      and A2: "n <>HIDDENR2 0NUMBERSK6"
    let ?P = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 0NUMBERSK6 implies cardCARD-1K1 (Lamb1 -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
    have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (k <>HIDDENR2 0NUMBERSK6 implies cardCARD-1K1 (k -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D) implies (k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies cardCARD-1K1 ((k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have "(0NUMBERSK6)-tuples-onFINSEQ-2K4 D =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,D :]))\<^esub> <*>FINSEQ-1K7 D }"
          using finseq_2_th_94 sorry
        then have A4: "0NUMBERSK6 inTARSKIR2 cardCARD-1K1 ((0NUMBERSK6)-tuples-onFINSEQ-2K4 D) & cardCARD-1K1 ((0NUMBERSK6)-tuples-onFINSEQ-2K4 D) c=ORDINAL1R1 cardCARD-1K1 D"
          using A1 ordinal3_th_8 sorry
        have A5: "cardCARD-1K1 ((k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 D) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 k -tuples-onFINSEQ-2K4 D,\<one>\<^sub>M -tuples-onFINSEQ-2K4 D :])"
          using card_4_th_9 sorry
        also have "... = cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 (k -tuples-onFINSEQ-2K4 D),cardCARD-1K1 (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D) :])"
          using card_2_th_7 sorry
        also have "... = cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 (k -tuples-onFINSEQ-2K4 D),cardCARD-1K1 D :])"
          using card_4_th_8 sorry
        also have "... = cardCARD-1K1 (k -tuples-onFINSEQ-2K4 D) *`CARD-2K2 cardCARD-1K1 D"
          using card_2_def_2 sorry
        finally have "cardCARD-1K1 ((k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 D) =HIDDENR1 cardCARD-1K1 (k -tuples-onFINSEQ-2K4 D) *`CARD-2K2 cardCARD-1K1 D"
           sorry
        assume "?P(k)"
        thus "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies cardCARD-1K1 ((k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
          using A1 A5 A4 card_4_th_16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "?P(0NUMBERSK6)"
       sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A6 A3 sorry
    then have "cardCARD-1K1 (n -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
      using A2 sorry
    thus "(n -tuples-onFINSEQ-2K4 D,D)are-equipotentWELLORD2R2 & cardCARD-1K1 (n -tuples-onFINSEQ-2K4 D) =XBOOLE-0R4 cardCARD-1K1 D"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_4_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not D be finiteFINSET-1V1 implies cardCARD-1K1 D =XBOOLE-0R4 cardCARD-1K1 (D * FINSEQ-2K3)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not D be finiteFINSET-1V1 implies cardCARD-1K1 D =XBOOLE-0R4 cardCARD-1K1 (D * FINSEQ-2K3)"
  proof(rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  not  False "
    let ?f = "\<lambda>Lamb1. Lamb1 -tuples-onFINSEQ-2K4 D"
    have A1: "D * FINSEQ-2K3 =XBOOLE-0R4 unionTARSKIK3 ({k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  })"
      using finseq_2_th_108 sorry
    assume A2: " not D be finiteFINSET-1V1"
    have A3: " for X be setHIDDENM2 holds X inTARSKIR2 {k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  } implies cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 D"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X inTARSKIR2 {k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  }"
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A4: "X =XBOOLE-0R4 k -tuples-onFINSEQ-2K4 D"
         sorry
      have "(0NUMBERSK6)-tuples-onFINSEQ-2K4 D =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 omegaORDINAL1K4,D :]))\<^esub> <*>FINSEQ-1K7 D }"
        using finseq_2_th_94 sorry
      then have "cardCARD-1K1 ((0NUMBERSK6)-tuples-onFINSEQ-2K4 D) c=ORDINAL1R1 cardCARD-1K1 D & k =XBOOLE-0R4 0NUMBERSK6 or k <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      thus "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 D"
        using A2 A4 card_4_th_23 sorry
    qed "sorry"
    have "\<one>\<^sub>M -tuples-onFINSEQ-2K4 D inTARSKIR2 {k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  }"
       sorry
    then have "cardCARD-1K1 (\<one>\<^sub>M -tuples-onFINSEQ-2K4 D) c=ORDINAL1R1 cardCARD-1K1 (D * FINSEQ-2K3)"
      using A1 card_1_th_11 zfmisc_1_th_74 sorry
    then have A5: "cardCARD-1K1 D c=ORDINAL1R1 cardCARD-1K1 (D * FINSEQ-2K3)"
      using card_4_th_8 sorry
    have "{?f(k) where k be NatNAT-1M1 : ?P(k) } be countableCARD-3V4"
      using card_4_sch_1 sorry
    then have "cardCARD-1K1 ({k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  }) c=ORDINAL1R1 omegaORDINAL1K4"
       sorry
    then have "cardCARD-1K1 (unionTARSKIK3 ({k -tuples-onFINSEQ-2K4 D where k be NatNAT-1M1 :  True  })) c=ORDINAL1R1 omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K1 D"
      using A3 card_2_th_87 sorry
    then have "cardCARD-1K1 (D * FINSEQ-2K3) c=ORDINAL1R1 cardCARD-1K1 D"
      using A2 A1 card_4_th_21 sorry
    thus "cardCARD-1K1 D =XBOOLE-0R4 cardCARD-1K1 (D * FINSEQ-2K3)"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
