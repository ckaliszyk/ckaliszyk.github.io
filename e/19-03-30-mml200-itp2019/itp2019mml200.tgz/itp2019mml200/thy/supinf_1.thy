theory supinf_1
  imports domain_1 xxreal_2
begin
(*begin*)
syntax SUPINF_1M1 :: "Ty" ("R-ealSUPINF-1M1" 70)
translations "R-ealSUPINF-1M1" \<rightharpoonup> "ElementSUBSET-1M1-of ExtREALXXREAL-0K3"

abbreviation(input) SUPINF_1K1("+inftySUPINF-1K1" 300) where
  "+inftySUPINF-1K1 \<equiv> +inftyXXREAL-0K1"

mtheorem supinf_1_add_1:
"cluster +inftyXXREAL-0K1 as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "+inftyXXREAL-0K1 be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_1K2("-inftySUPINF-1K2" 300) where
  "-inftySUPINF-1K2 \<equiv> -inftyXXREAL-0K2"

mtheorem supinf_1_add_2:
"cluster -inftyXXREAL-0K2 as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "-inftyXXREAL-0K2 be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mdef supinf_1_def_1 ("SetMajorantSUPINF-1K3  _ " [164]164 ) where
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"func SetMajorantSUPINF-1K3 X \<rightarrow> ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  \<lambda>it.  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 it iff x be UpperBoundXXREAL-2M1-of X"
proof-
  (*existence*)
    show " ex it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 it iff x be UpperBoundXXREAL-2M1-of X"
    proof-
      have " ex tVar1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 tVar1 &  not x be UpperBoundXXREAL-2M1-of X) &  not (x be UpperBoundXXREAL-2M1-of X &  not x inHIDDENR3 tVar1)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 be UpperBoundXXREAL-2M1-of X"
        obtain Y where
          [ty]:"Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and 
          A1: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y iff ?P(x)"
          using membered_sch_2 sorry
        show " ex tVar1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 tVar1 &  not x be UpperBoundXXREAL-2M1-of X) &  not (x be UpperBoundXXREAL-2M1-of X &  not x inHIDDENR3 tVar1)"
        proof(rule bexI[of _ "Y"])
          show " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 Y &  not x be UpperBoundXXREAL-2M1-of X) &  not (x be UpperBoundXXREAL-2M1-of X &  not x inHIDDENR3 Y)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for it2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 it1 iff x be UpperBoundXXREAL-2M1-of X) & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 it2 iff x be UpperBoundXXREAL-2M1-of X) implies it1 =HIDDENR1 it2"
    proof-
      have " for Y1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y1 iff x be UpperBoundXXREAL-2M1-of X) & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y2 iff x be UpperBoundXXREAL-2M1-of X) implies Y1 =HIDDENR1 Y2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix Y1 assume [ty]: "Y1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
        fix Y2 assume [ty]: "Y2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
        assume A2: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y1 iff x be UpperBoundXXREAL-2M1-of X"
          and A3: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y2 iff x be UpperBoundXXREAL-2M1-of X"
        have " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 Y1 &  not x inHIDDENR3 Y2) &  not (x inHIDDENR3 Y2 &  not x inHIDDENR3 Y1)"
        proof(rule ballI)
          fix x assume [ty]: "x be ExtRealXXREAL-0M1"
          have "x inHIDDENR3 Y1 iff x be UpperBoundXXREAL-2M1-of X"
            using A2 sorry
          thus " not (x inHIDDENR3 Y1 &  not x inHIDDENR3 Y2) &  not (x inHIDDENR3 Y2 &  not x inHIDDENR3 Y1)"
            using A3 sorry
        qed "sorry"
        thus "Y1 =HIDDENR1 Y2"
          using membered_def_14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem supinf_1_cl_1:
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster SetMajorantSUPINF-1K3 X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SetMajorantSUPINF-1K3 X be  non emptyXBOOLE-0V1"
  proof-
    have " not SetMajorantSUPINF-1K3 X be emptyXBOOLE-0V1"
    proof-
      let ?x = "the UpperBoundXXREAL-2M1-of X"
      have "?x inHIDDENR3 SetMajorantSUPINF-1K3 X"
        using supinf_1_def_1 sorry
      thus " not SetMajorantSUPINF-1K3 X be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem supinf_1_th_1:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y implies ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 SetMajorantSUPINF-1K3 Y implies x inHIDDENR3 SetMajorantSUPINF-1K3 X)"
proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "X c=MEMBEREDR2 Y"
  fix x assume [ty]: "x be ExtRealXXREAL-0M1"
  assume "x inHIDDENR3 SetMajorantSUPINF-1K3 Y"
  then have "x be UpperBoundXXREAL-2M1-of Y"
    using supinf_1_def_1 sorry
  then have "x be UpperBoundXXREAL-2M1-of X"
    using A1 xxreal_2_th_6 sorry
  thus "x inHIDDENR3 SetMajorantSUPINF-1K3 X"
    using supinf_1_def_1 sorry
qed "sorry"

mdef supinf_1_def_2 ("SetMinorantSUPINF-1K4  _ " [164]164 ) where
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"func SetMinorantSUPINF-1K4 X \<rightarrow> ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  \<lambda>it.  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 it iff x be LowerBoundXXREAL-2M2-of X"
proof-
  (*existence*)
    show " ex it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 it iff x be LowerBoundXXREAL-2M2-of X"
    proof-
      have " ex tVar2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 tVar2 &  not x be LowerBoundXXREAL-2M2-of X) &  not (x be LowerBoundXXREAL-2M2-of X &  not x inHIDDENR3 tVar2)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 be LowerBoundXXREAL-2M2-of X"
        obtain Y where
          [ty]:"Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and 
          A1: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y iff ?P(x)"
          using membered_sch_2 sorry
        show " ex tVar2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 tVar2 &  not x be LowerBoundXXREAL-2M2-of X) &  not (x be LowerBoundXXREAL-2M2-of X &  not x inHIDDENR3 tVar2)"
        proof(rule bexI[of _ "Y"])
          show " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 Y &  not x be LowerBoundXXREAL-2M2-of X) &  not (x be LowerBoundXXREAL-2M2-of X &  not x inHIDDENR3 Y)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for it2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 it1 iff x be LowerBoundXXREAL-2M2-of X) & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 it2 iff x be LowerBoundXXREAL-2M2-of X) implies it1 =HIDDENR1 it2"
    proof-
      have " for Y1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y1 iff x be LowerBoundXXREAL-2M2-of X) & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y2 iff x be LowerBoundXXREAL-2M2-of X) implies Y1 =HIDDENR1 Y2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix Y1 assume [ty]: "Y1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
        fix Y2 assume [ty]: "Y2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
        assume A2: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y1 iff x be LowerBoundXXREAL-2M2-of X"
          and A3: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 Y2 iff x be LowerBoundXXREAL-2M2-of X"
        have " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 Y1 &  not x inHIDDENR3 Y2) &  not (x inHIDDENR3 Y2 &  not x inHIDDENR3 Y1)"
        proof(rule ballI)
          fix x assume [ty]: "x be ExtRealXXREAL-0M1"
          have "x inHIDDENR3 Y1 iff x be LowerBoundXXREAL-2M2-of X"
            using A2 sorry
          thus " not (x inHIDDENR3 Y1 &  not x inHIDDENR3 Y2) &  not (x inHIDDENR3 Y2 &  not x inHIDDENR3 Y1)"
            using A3 sorry
        qed "sorry"
        thus "Y1 =HIDDENR1 Y2"
          using membered_def_14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem supinf_1_cl_2:
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster SetMinorantSUPINF-1K4 X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SetMinorantSUPINF-1K4 X be  non emptyXBOOLE-0V1"
  proof-
    have " not SetMinorantSUPINF-1K4 X be emptyXBOOLE-0V1"
    proof-
      let ?x = "the LowerBoundXXREAL-2M2-of X"
      have "?x inHIDDENR3 SetMinorantSUPINF-1K4 X"
        using supinf_1_def_2 sorry
      thus " not SetMinorantSUPINF-1K4 X be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem supinf_1_th_2:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y implies ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 SetMinorantSUPINF-1K4 Y implies x inHIDDENR3 SetMinorantSUPINF-1K4 X)"
proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "X c=MEMBEREDR2 Y"
  fix x assume [ty]: "x be ExtRealXXREAL-0M1"
  assume "x inHIDDENR3 SetMinorantSUPINF-1K4 Y"
  then have "x be LowerBoundXXREAL-2M2-of Y"
    using supinf_1_def_2 sorry
  then have "x be LowerBoundXXREAL-2M2-of X"
    using A1 xxreal_2_th_5 sorry
  thus "x inHIDDENR3 SetMinorantSUPINF-1K4 X"
    using supinf_1_def_2 sorry
qed "sorry"

mtheorem supinf_1_th_3:
" for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds supXXREAL-2K1 X =HIDDENR1 infXXREAL-2K2 (SetMajorantSUPINF-1K3 X) & infXXREAL-2K2 X =HIDDENR1 supXXREAL-2K1 (SetMinorantSUPINF-1K4 X)"
proof(rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 SetMajorantSUPINF-1K3 X implies supXXREAL-2K1 X <=XXREAL-0R1 y"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume "y inHIDDENR3 SetMajorantSUPINF-1K3 X"
    then have "y be UpperBoundXXREAL-2M1-of X"
      using supinf_1_def_1 sorry
    thus "supXXREAL-2K1 X <=XXREAL-0R1 y"
      using xxreal_2_def_3 sorry
  qed "sorry"
  then have A1: "supXXREAL-2K1 X be LowerBoundXXREAL-2M2-of SetMajorantSUPINF-1K3 X"
    using xxreal_2_def_2 sorry
  have "infXXREAL-2K2 X be LowerBoundXXREAL-2M2-of X"
    using xxreal_2_def_4 sorry
  then have A2: "infXXREAL-2K2 X inHIDDENR3 SetMinorantSUPINF-1K4 X"
    using supinf_1_def_2 sorry
  have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 SetMinorantSUPINF-1K4 X implies y <=XXREAL-0R1 infXXREAL-2K2 X"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume "y inHIDDENR3 SetMinorantSUPINF-1K4 X"
    then have "y be LowerBoundXXREAL-2M2-of X"
      using supinf_1_def_2 sorry
    thus "y <=XXREAL-0R1 infXXREAL-2K2 X"
      using xxreal_2_def_4 sorry
  qed "sorry"
  then have A3: "infXXREAL-2K2 X be UpperBoundXXREAL-2M1-of SetMinorantSUPINF-1K4 X"
    using xxreal_2_def_1 sorry
  have "supXXREAL-2K1 X be UpperBoundXXREAL-2M1-of X"
    using xxreal_2_def_3 sorry
  then have "supXXREAL-2K1 X inHIDDENR3 SetMajorantSUPINF-1K3 X"
    using supinf_1_def_1 sorry
  thus "supXXREAL-2K1 X =HIDDENR1 infXXREAL-2K2 (SetMajorantSUPINF-1K3 X) & infXXREAL-2K2 X =HIDDENR1 supXXREAL-2K1 (SetMinorantSUPINF-1K4 X)"
    using A1 A2 A3 xxreal_2_th_55 xxreal_2_th_56 sorry
qed "sorry"

mtheorem supinf_1_cl_3:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1 for Subset-FamilySETFAM-1M1-of X"
proof
(*existence*)
  show " ex it be Subset-FamilySETFAM-1M1-of X st it be  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1"
  proof-
    have " ex tVar3 be Subset-FamilySETFAM-1M1-of X st tVar3 be  non emptyXBOOLE-0V1 & tVar3 be with-non-empty-elementsSETFAM-1V1"
    proof-
      show " ex tVar3 be Subset-FamilySETFAM-1M1-of X st tVar3 be  non emptyXBOOLE-0V1 & tVar3 be with-non-empty-elementsSETFAM-1V1"
      proof(rule bexI[of _ "{DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> [#]SUBSET-1K2 X }"],rule conjMI)
        show "{DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> [#]SUBSET-1K2 X } be  non emptyXBOOLE-0V1"
           sorry
        have "{}XBOOLE-0K1 inHIDDENR3 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> [#]SUBSET-1K2 X } implies  False "
        proof(rule impI)
          assume "{}XBOOLE-0K1 inHIDDENR3 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> [#]SUBSET-1K2 X }"
          thus " False "
            using tarski_def_1 sorry
        qed
        thus "{DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> [#]SUBSET-1K2 X } be with-non-empty-elementsSETFAM-1V1"
          using setfam_1_def_8 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax SUPINF_1M2 :: " Set \<Rightarrow> Ty" ("bool-DOMAINSUPINF-1M2-of  _ " [70]70)
translations "bool-DOMAINSUPINF-1M2-of X" \<rightharpoonup> " non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1\<bar>Subset-FamilySETFAM-1M1-of X"

mdef supinf_1_def_3 ("SUPSUPINF-1K5  _ " [164]164 ) where
  mlet "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
"func SUPSUPINF-1K5 F \<rightarrow> ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  \<lambda>it.  for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 it iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)"
proof-
  (*existence*)
    show " ex it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 it iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)"
    proof-
      have " ex tVar4 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for a be ExtRealXXREAL-0M1 holds  not (a inHIDDENR3 tVar4 & ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A))) &  not ( not ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)) &  not a inHIDDENR3 tVar4)"
      proof-
        let ?P = "\<lambda>Lamb1.  ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & Lamb1 =HIDDENR1 supXXREAL-2K1 A"
        obtain S where
          [ty]:"S be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and 
          A1: " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S iff ?P(a)"
          using membered_sch_2 sorry
        have 
          [ty]:"S be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
           sorry
        show " ex tVar4 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for a be ExtRealXXREAL-0M1 holds  not (a inHIDDENR3 tVar4 & ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A))) &  not ( not ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)) &  not a inHIDDENR3 tVar4)"
        proof(rule bexI[of _ "S"])
          show " for a be ExtRealXXREAL-0M1 holds  not (a inHIDDENR3 S & ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A))) &  not ( not ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)) &  not a inHIDDENR3 S)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for it2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 it1 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)) & ( for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 it2 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)) implies it1 =HIDDENR1 it2"
    proof-
      have " for S1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for S2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S1 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)) & ( for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S2 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)) implies S1 =HIDDENR1 S2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix S1 assume [ty]: "S1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
        fix S2 assume [ty]: "S2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
        assume A2: " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S1 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)"
          and A3: " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S2 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A)"
        have " for a be ExtRealXXREAL-0M1 holds (a inHIDDENR3 S1 implies a inHIDDENR3 S2) & (a inHIDDENR3 S2 implies a inHIDDENR3 S1)"
        proof(rule ballI,rule conjMI,rule impI)
          fix a assume [ty]: "a be ExtRealXXREAL-0M1"
          show "a inHIDDENR3 S1 implies a inHIDDENR3 S2"
          proof(rule impI)
            assume "a inHIDDENR3 S1"
            then have " ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A"
              using A2 sorry
            thus "a inHIDDENR3 S2"
              using A3 sorry
          qed
          assume "a inHIDDENR3 S2"
          then have " ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 supXXREAL-2K1 A"
            using A3 sorry
          thus "a inHIDDENR3 S1"
            using A2 sorry
        qed "sorry"
        thus "S1 =HIDDENR1 S2"
          using membered_def_14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem supinf_1_cl_4:
  mlet "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
"cluster SUPSUPINF-1K5 F as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SUPSUPINF-1K5 F be  non emptyXBOOLE-0V1"
  proof-
    have " not SUPSUPINF-1K5 F be emptyXBOOLE-0V1"
    proof-
      let ?A = "the ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (ExtREALXXREAL-0K3))\<^esub>-of F"
      obtain A where 
        [ty]:"A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and ADef:"A = ?A"
        using setfam_1_def_8 sorry
      have "supXXREAL-2K1 A =HIDDENR1 supXXREAL-2K1 A"
         sorry
      thus " not SUPSUPINF-1K5 F be emptyXBOOLE-0V1"
        using supinf_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem supinf_1_th_4:
" for F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3 holds  for S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>numberORDINAL1M2 holds S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies supXXREAL-2K1 S be UpperBoundXXREAL-2M1-of SUPSUPINF-1K5 F"
proof-
  have " for F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3 holds  for S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies supXXREAL-2K1 S be UpperBoundXXREAL-2M1-of SUPSUPINF-1K5 F"
  proof(rule ballI,rule ballI,rule impI)
    fix F assume [ty]: "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
    fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 SUPSUPINF-1K5 F implies x <=XXREAL-0R1 supXXREAL-2K1 S"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume "x inHIDDENR3 SUPSUPINF-1K5 F"
      then obtain A where
        [ty]:"A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and 
        A2: "A inHIDDENR3 F"and A3: "x =HIDDENR1 supXXREAL-2K1 A"
        using supinf_1_def_3 sorry
      have "A c=MEMBEREDR2 S"
        using A1 A2 tarski_def_4 sorry
      thus "x <=XXREAL-0R1 supXXREAL-2K1 S"
        using A3 xxreal_2_th_59 sorry
    qed "sorry"
    thus "supXXREAL-2K1 S be UpperBoundXXREAL-2M1-of SUPSUPINF-1K5 F"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_1_th_5:
" for F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3 holds  for S be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies supXXREAL-2K1 (SUPSUPINF-1K5 F) be UpperBoundXXREAL-2M1-of S"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
  fix S assume [ty]: "S be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 S implies x <=XXREAL-0R1 supXXREAL-2K1 (SUPSUPINF-1K5 F)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 S"
    then obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A2: "x inHIDDENR3 Z"and A3: "Z inHIDDENR3 F"
      using A1 tarski_def_4 sorry
    have 
      [ty]:"Z be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
      using A2 A3 sorry
    let ?a = "supXXREAL-2K1 Z"
    have "supXXREAL-2K1 Z be UpperBoundXXREAL-2M1-of Z & ?a inHIDDENR3 SUPSUPINF-1K5 F"
      using A3 supinf_1_def_3 xxreal_2_def_3 sorry
    thus "x <=XXREAL-0R1 supXXREAL-2K1 (SUPSUPINF-1K5 F)"
      using A2 xxreal_2_th_61 xxreal_2_def_1 sorry
  qed "sorry"
  thus "supXXREAL-2K1 (SUPSUPINF-1K5 F) be UpperBoundXXREAL-2M1-of S"
    using xxreal_2_def_1 sorry
qed "sorry"

mtheorem supinf_1_th_6:
" for F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3 holds  for S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies supXXREAL-2K1 S =HIDDENR1 supXXREAL-2K1 (SUPSUPINF-1K5 F)"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  let ?a = "supXXREAL-2K1 S"
  let ?b = "supXXREAL-2K1 (SUPSUPINF-1K5 F)"
  assume A1: "S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
  then have "supXXREAL-2K1 S be UpperBoundXXREAL-2M1-of SUPSUPINF-1K5 F"
    using supinf_1_th_4 sorry
  then have A2: "?b <=XXREAL-0R1 ?a"
    using xxreal_2_def_3 sorry
  have "supXXREAL-2K1 (SUPSUPINF-1K5 F) be UpperBoundXXREAL-2M1-of S"
    using A1 supinf_1_th_5 sorry
  then have "?a <=XXREAL-0R1 ?b"
    using xxreal_2_def_3 sorry
  thus "supXXREAL-2K1 S =HIDDENR1 supXXREAL-2K1 (SUPSUPINF-1K5 F)"
    using A2 xxreal_0_th_1 sorry
qed "sorry"

mdef supinf_1_def_4 ("INFSUPINF-1K6  _ " [164]164 ) where
  mlet "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
"func INFSUPINF-1K6 F \<rightarrow> ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  \<lambda>it.  for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 it iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)"
proof-
  (*existence*)
    show " ex it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 it iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)"
    proof-
      have " ex tVar5 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for a be ExtRealXXREAL-0M1 holds  not (a inHIDDENR3 tVar5 & ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A))) &  not ( not ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)) &  not a inHIDDENR3 tVar5)"
      proof-
        let ?A = "the ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (ExtREALXXREAL-0K3))\<^esub>-of F"
        let ?P = "\<lambda>Lamb1.  ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & Lamb1 =HIDDENR1 infXXREAL-2K2 A"
        obtain A where 
          [ty]:"A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and ADef:"A = ?A"
          using setfam_1_def_8 sorry
        obtain S where
          [ty]:"S be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and 
          A1: " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S iff ?P(a)"
          using membered_sch_2 sorry
        have "infXXREAL-2K2 A =HIDDENR1 infXXREAL-2K2 A"
           sorry
        then have 
          [ty]:"S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
          using A1 sorry
        show " ex tVar5 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st  for a be ExtRealXXREAL-0M1 holds  not (a inHIDDENR3 tVar5 & ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A))) &  not ( not ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)) &  not a inHIDDENR3 tVar5)"
        proof(rule bexI[of _ "S"])
          show " for a be ExtRealXXREAL-0M1 holds  not (a inHIDDENR3 S & ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A))) &  not ( not ( for A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)) &  not a inHIDDENR3 S)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for it2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 it1 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)) & ( for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 it2 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)) implies it1 =HIDDENR1 it2"
    proof-
      have " for S1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for S2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S1 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)) & ( for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S2 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)) implies S1 =HIDDENR1 S2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix S1 assume [ty]: "S1 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
        fix S2 assume [ty]: "S2 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
        assume A2: " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S1 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)"
          and A3: " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 S2 iff ( ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A)"
        have " for a be objectHIDDENM1 holds a inHIDDENR3 S1 iff a inHIDDENR3 S2"
        proof-
          have " for a be objectHIDDENM1 holds (a inHIDDENR3 S1 implies a inHIDDENR3 S2) & (a inHIDDENR3 S2 implies a inHIDDENR3 S1)"
          proof(rule ballI,rule conjMI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            show "a inHIDDENR3 S1 implies a inHIDDENR3 S2"
            proof(rule impI)
              assume A4: "a inHIDDENR3 S1"
              then obtain a9 where 
                [ty]:"a9 be ExtRealXXREAL-0M1" and a9Def:"a9 = a"
                 sorry
              have " ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a9 =HIDDENR1 infXXREAL-2K2 A"
                using A2 A4 sorry
              thus "a inHIDDENR3 S2"
                using A3 sorry
            qed
            assume A5: "a inHIDDENR3 S2"
            then have 
              [ty]:"a be ExtRealXXREAL-0M1"
               sorry
            have " ex A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st A inHIDDENR3 F & a =HIDDENR1 infXXREAL-2K2 A"
              using A3 A5 sorry
            thus "a inHIDDENR3 S1"
              using A2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "S1 =HIDDENR1 S2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem supinf_1_cl_5:
  mlet "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
"cluster INFSUPINF-1K6 F as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "INFSUPINF-1K6 F be  non emptyXBOOLE-0V1"
  proof-
    have " not INFSUPINF-1K6 F be emptyXBOOLE-0V1"
    proof-
      let ?A = "the ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (ExtREALXXREAL-0K3))\<^esub>-of F"
      obtain A where 
        [ty]:"A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and ADef:"A = ?A"
        using setfam_1_def_8 sorry
      have "infXXREAL-2K2 A =HIDDENR1 infXXREAL-2K2 A"
         sorry
      thus " not INFSUPINF-1K6 F be emptyXBOOLE-0V1"
        using supinf_1_def_4 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem supinf_1_th_7:
" for F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3 holds  for S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies infXXREAL-2K2 S be LowerBoundXXREAL-2M2-of INFSUPINF-1K6 F"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 INFSUPINF-1K6 F implies infXXREAL-2K2 S <=XXREAL-0R1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 INFSUPINF-1K6 F"
    then obtain A where
      [ty]:"A be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2" and 
      A2: "A inHIDDENR3 F"and A3: "x =HIDDENR1 infXXREAL-2K2 A"
      using supinf_1_def_4 sorry
    have "A c=MEMBEREDR2 S"
      using A1 A2 tarski_def_4 sorry
    thus "infXXREAL-2K2 S <=XXREAL-0R1 x"
      using A3 xxreal_2_th_60 sorry
  qed "sorry"
  thus "infXXREAL-2K2 S be LowerBoundXXREAL-2M2-of INFSUPINF-1K6 F"
    using xxreal_2_def_2 sorry
qed "sorry"

mtheorem supinf_1_th_8:
" for F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3 holds  for S be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies infXXREAL-2K2 (INFSUPINF-1K6 F) be LowerBoundXXREAL-2M2-of S"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
  fix S assume [ty]: "S be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 S implies infXXREAL-2K2 (INFSUPINF-1K6 F) <=XXREAL-0R1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 S"
    then obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A2: "x inHIDDENR3 Z"and A3: "Z inHIDDENR3 F"
      using A1 tarski_def_4 sorry
    have 
      [ty]:"Z be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
      using A2 A3 sorry
    let ?a = "infXXREAL-2K2 Z"
    have "infXXREAL-2K2 Z be LowerBoundXXREAL-2M2-of Z & ?a inHIDDENR3 INFSUPINF-1K6 F"
      using A3 supinf_1_def_4 xxreal_2_def_4 sorry
    thus "infXXREAL-2K2 (INFSUPINF-1K6 F) <=XXREAL-0R1 x"
      using A2 xxreal_2_th_62 xxreal_2_def_2 sorry
  qed "sorry"
  thus "infXXREAL-2K2 (INFSUPINF-1K6 F) be LowerBoundXXREAL-2M2-of S"
    using xxreal_2_def_2 sorry
qed "sorry"

mtheorem supinf_1_th_9:
" for F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3 holds  for S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies infXXREAL-2K2 S =HIDDENR1 infXXREAL-2K2 (INFSUPINF-1K6 F)"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be bool-DOMAINSUPINF-1M2-of ExtREALXXREAL-0K3"
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  let ?a = "infXXREAL-2K2 S"
  let ?b = "infXXREAL-2K2 (INFSUPINF-1K6 F)"
  assume A1: "S =MEMBEREDR8 unionSETFAM-1K5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
  then have "infXXREAL-2K2 S be LowerBoundXXREAL-2M2-of INFSUPINF-1K6 F"
    using supinf_1_th_7 sorry
  then have A2: "?a <=XXREAL-0R1 ?b"
    using xxreal_2_def_4 sorry
  have "infXXREAL-2K2 (INFSUPINF-1K6 F) be LowerBoundXXREAL-2M2-of S"
    using A1 supinf_1_th_8 sorry
  then have "?b <=XXREAL-0R1 ?a"
    using xxreal_2_def_4 sorry
  thus "infXXREAL-2K2 S =HIDDENR1 infXXREAL-2K2 (INFSUPINF-1K6 F)"
    using A2 xxreal_0_th_1 sorry
qed "sorry"

end
