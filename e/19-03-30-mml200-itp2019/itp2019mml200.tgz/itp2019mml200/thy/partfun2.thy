theory partfun2
  imports funcop_1
begin
(*begin*)
reserve x, y, X, Y for "setHIDDENM2"
reserve C, D, E for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve SC for "SubsetSUBSET-1M2-of C"
reserve SD for "SubsetSUBSET-1M2-of D"
reserve SE for "SubsetSUBSET-1M2-of E"
reserve c, c1, c2 for "ElementSUBSET-1M1-of C"
reserve d, d1, d2 for "ElementSUBSET-1M1-of D"
reserve e for "ElementSUBSET-1M1-of E"
reserve f, f1, g for "PartFuncPARTFUN1M1-of(C,D)"
reserve t for "PartFuncPARTFUN1M1-of(D,C)"
reserve s for "PartFuncPARTFUN1M1-of(D,E)"
reserve h for "PartFuncPARTFUN1M1-of(C,E)"
reserve F for "PartFuncPARTFUN1M1-of(D,D)"
mtheorem partfun2_th_1:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> g & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c) implies f =RELSET-1R2\<^bsub>(C,D)\<^esub> g"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> g & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c) implies f =RELSET-1R2\<^bsub>(C,D)\<^esub> g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      and A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      then obtain y where 
        [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = x"
         sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> y =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
        using A2 A3 sorry
      then have "f .FUNCT-1K1 y =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
        using A3 partfun1_def_6 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A1 A3 partfun1_def_6 sorry
    qed "sorry"
    thus "f =RELSET-1R2\<^bsub>(C,D)\<^esub> g"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_2:
" for y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds y inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f iff ( ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
proof-
  have " for y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (y inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f implies ( ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) & (( ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c) implies y inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix y assume [ty]: "y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "y inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f implies ( ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
    proof-
      have "y inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f implies ( ex tVar1 be ElementSUBSET-1M1-of C st tVar1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> tVar1)"
      proof(rule impI)
        assume "y inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"and A2: "y =XBOOLE-0R4 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have 
          [ty]:"x be ElementSUBSET-1M1-of C"
          using A1 sorry
        show " ex tVar1 be ElementSUBSET-1M1-of C st tVar1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> tVar1"
        proof(rule bexI[of _ "x"])
          show "x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x"
            using A1 A2 partfun1_def_6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
    then obtain c where
      [ty]:"c be ElementSUBSET-1M1-of C" and 
      A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"and A4: "y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
       sorry
    have "f .FUNCT-1K1 c inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
      using A3 funct_1_def_3 sorry
    thus "y inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
      using A3 A4 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for s be PartFuncPARTFUN1M1-of(D,E) holds  for h be PartFuncPARTFUN1M1-of(C,E) holds h =RELSET-1R2\<^bsub>(C,E)\<^esub> s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f iff ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h implies h /.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for s be PartFuncPARTFUN1M1-of(D,E) holds  for h be PartFuncPARTFUN1M1-of(C,E) holds (h =RELSET-1R2\<^bsub>(C,E)\<^esub> s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h implies h /.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c))) & (( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h implies h /.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) implies h =RELSET-1R2\<^bsub>(C,E)\<^esub> s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix s assume [ty]: "s be PartFuncPARTFUN1M1-of(D,E)"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(C,E)"
    show "h =RELSET-1R2\<^bsub>(C,E)\<^esub> s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h implies h /.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c))"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "h =RELSET-1R2\<^bsub>(C,E)\<^esub> s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f"
      have A2: " for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s) & (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h)"
      proof(rule ballI,rule conjMI,rule impMI ,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        show "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
        proof(rule impI)
          assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h"
          then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
            using A1 funct_1_th_11 sorry
          thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
            using partfun1_def_6 sorry
        qed
        assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          and A4: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
        have "f .FUNCT-1K1 c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
          using A3 A4 partfun1_def_6 sorry
        thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h"
          using A1 A3 funct_1_th_11 sorry
      qed "sorry"
      thus " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
         sorry
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h"
      then have "h .FUNCT-1K1 c =XBOOLE-0R4 s .FUNCT-1K1 (f .FUNCT-1K1 c)"
        using A1 funct_1_th_12 sorry
      then have A6: "h /.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s .FUNCT-1K1 (f .FUNCT-1K1 c)"
        using A5 partfun1_def_6 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A2 A5 sorry
      then have A7: "h /.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s .FUNCT-1K1 (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
        using A6 partfun1_def_6 sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
        using A2 A5 sorry
      thus "h /.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
        using A7 partfun1_def_6 sorry
    qed "sorry"
    assume A8: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
      and A9: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> h implies h /.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
    have A10: " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> h implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> h)"
    proof(rule ballI,rule conjMI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> h implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
      proof(rule impI)
        assume A11: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> h"
        then obtain y where 
          [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = x"
           sorry
        have "y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> y inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
          using A8 A11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
          using partfun1_def_6 sorry
      qed
      show "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> h"
      proof(rule impMI ,rule impI)
        assume A12: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          and A13: "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
        obtain y where 
          [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = x"
          using A12 sorry
        have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> y inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
          using A12 A13 partfun1_def_6 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> h"
          using A8 A12 sorry
      qed
    qed "sorry"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> h implies h .FUNCT-1K1 x =XBOOLE-0R4 s .FUNCT-1K1 (f .FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A14: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> h"
      then obtain y where 
        [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = x"
         sorry
      have "h /.PARTFUN1K7\<^bsub>(E)\<^esub> y =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> y)"
        using A9 A14 sorry
      then have A15: "h .FUNCT-1K1 y =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> y)"
        using A14 partfun1_def_6 sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> y inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
        using A8 A14 sorry
      then have A16: "h .FUNCT-1K1 x =XBOOLE-0R4 s .FUNCT-1K1 (f /.PARTFUN1K7\<^bsub>(D)\<^esub> y)"
        using A15 partfun1_def_6 sorry
      have "y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A8 A14 sorry
      thus "h .FUNCT-1K1 x =XBOOLE-0R4 s .FUNCT-1K1 (f .FUNCT-1K1 x)"
        using A16 partfun1_def_6 sorry
    qed "sorry"
    thus "h =RELSET-1R2\<^bsub>(C,E)\<^esub> s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f"
      using A10 funct_1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_4:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for s be PartFuncPARTFUN1M1-of(D,E) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s implies (s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)/.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for s be PartFuncPARTFUN1M1-of(D,E) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s implies (s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)/.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix s assume [ty]: "s be PartFuncPARTFUN1M1-of(D,E)"
    assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> s"
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
      using partfun2_th_3 sorry
    thus "(s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)/.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
      using partfun2_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_5:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for s be PartFuncPARTFUN1M1-of(D,E) holds rngRELSET-1K2\<^bsub>(D)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> s & c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies (s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)/.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for s be PartFuncPARTFUN1M1-of(D,E) holds rngRELSET-1K2\<^bsub>(D)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> s & c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies (s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)/.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix s assume [ty]: "s be PartFuncPARTFUN1M1-of(D,E)"
    assume A1: "rngRELSET-1K2\<^bsub>(D)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> s"
      and A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
    have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
      using A2 partfun2_th_2 sorry
    thus "(s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)/.PARTFUN1K7\<^bsub>(E)\<^esub> c =XBOOLE-0R4 s /.PARTFUN1K7\<^bsub>(E)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
      using A1 A2 partfun2_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax PARTFUN2K1 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("idPARTFUN2K1\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "idPARTFUN2K1\<^bsub>(D)\<^esub> SD" \<rightharpoonup> "idRELAT-1K7 SD"

mtheorem partfun2_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "SD be SubsetSUBSET-1M2-of D"
"cluster idRELAT-1K7 SD as-term-is PartFuncPARTFUN1M1-of(D,D)"
proof
(*coherence*)
  show "idRELAT-1K7 SD be PartFuncPARTFUN1M1-of(D,D)"
  proof-
    have "domRELSET-1K1\<^bsub>(SD)\<^esub> (idPARTFUN1K6 SD) =XBOOLE-0R4 SD & rngRELSET-1K2\<^bsub>(SD)\<^esub> (idPARTFUN1K6 SD) =XBOOLE-0R4 SD"
      using relat_1_th_45 sorry
    thus "idRELAT-1K7 SD be PartFuncPARTFUN1M1-of(D,D)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem partfun2_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for F be PartFuncPARTFUN1M1-of(D,D) holds F =RELSET-1R2\<^bsub>(D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD iff domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 SD & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD implies F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for F be PartFuncPARTFUN1M1-of(D,D) holds (F =RELSET-1R2\<^bsub>(D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD implies domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 SD & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD implies F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 d)) & (domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 SD & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD implies F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 d) implies F =RELSET-1R2\<^bsub>(D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SD assume [ty]: "SD be SubsetSUBSET-1M2-of D"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,D)"
    show "F =RELSET-1R2\<^bsub>(D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD implies domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 SD & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD implies F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 d)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "F =RELSET-1R2\<^bsub>(D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD"
      thus A2: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 SD"
        using relat_1_th_45 sorry
      fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
      assume A3: "d inTARSKIR2 SD"
      then have "F .FUNCT-1K1 d =XBOOLE-0R4 d"
        using A1 funct_1_th_18 sorry
      thus "F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 d"
        using A2 A3 partfun1_def_6 sorry
    qed "sorry"
    assume A4: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 SD"
      and A5: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD implies F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 d"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SD implies F .FUNCT-1K1 x =HIDDENR1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 SD"
      then obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of D" and x1Def:"x1 = x"
         sorry
      have "F /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 x1"
        using A5 A6 sorry
      thus "F .FUNCT-1K1 x =HIDDENR1 x"
        using A4 A6 partfun1_def_6 sorry
    qed "sorry"
    thus "F =RELSET-1R2\<^bsub>(D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD"
      using A4 funct_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for d be ElementSUBSET-1M1-of D holds  for F be PartFuncPARTFUN1M1-of(D,D) holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(D)\<^esub> SD implies F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 (F *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD)/.PARTFUN1K7\<^bsub>(D)\<^esub> d"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for d be ElementSUBSET-1M1-of D holds  for F be PartFuncPARTFUN1M1-of(D,D) holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(D)\<^esub> SD implies F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 (F *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD)/.PARTFUN1K7\<^bsub>(D)\<^esub> d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SD assume [ty]: "SD be SubsetSUBSET-1M2-of D"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,D)"
    assume A1: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(D)\<^esub> SD"
    then have A2: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using xboole_0_def_4 sorry
    have "F .FUNCT-1K1 d =XBOOLE-0R4 (F *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD).FUNCT-1K1 d"
      using A1 funct_1_th_20 sorry
    then have A3: "F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 (F *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD).FUNCT-1K1 d"
      using A2 partfun1_def_6 sorry
    have A4: "d inTARSKIR2 SD"
      using A1 xboole_0_def_4 sorry
    then have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD)"
      using relat_1_th_45 sorry
    have "idPARTFUN2K1\<^bsub>(D)\<^esub> SD /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using A2 A4 partfun2_th_6 sorry
    then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD)"
      using A5 partfun2_th_3 sorry
    thus "F /.PARTFUN1K7\<^bsub>(D)\<^esub> d =XBOOLE-0R4 (F *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> idPARTFUN2K1\<^bsub>(D)\<^esub> SD)/.PARTFUN1K7\<^bsub>(D)\<^esub> d"
      using A3 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for d be ElementSUBSET-1M1-of D holds  for F be PartFuncPARTFUN1M1-of(D,D) holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> F) iff d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F & F /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 SD"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for d be ElementSUBSET-1M1-of D holds  for F be PartFuncPARTFUN1M1-of(D,D) holds (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> F) implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F & F /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 SD) & (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F & F /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 SD implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> F))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SD assume [ty]: "SD be SubsetSUBSET-1M2-of D"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,D)"
    show "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> F) implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F & F /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 SD"
    proof(rule impI)
      assume A1: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> F)"
      then have "F /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD)"
        using partfun2_th_3 sorry
      thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F & F /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 SD"
        using A1 partfun2_th_3 relat_1_th_45 sorry
    qed
    assume A2: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      and A3: "F /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 SD"
    have "F /.PARTFUN1K7\<^bsub>(D)\<^esub> d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD)"
      using A3 relat_1_th_45 sorry
    thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (idPARTFUN2K1\<^bsub>(D)\<^esub> SD *PARTFUN1K1\<^bsub>(D,D,D,D)\<^esub> F)"
      using A2 partfun2_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_9:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds ( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds (c1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f) & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2 implies c1 =XBOOLE-0R4 c2) implies f be one-to-oneFUNCT-1V2"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds ( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds (c1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f) & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2 implies c1 =XBOOLE-0R4 c2) implies f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: " for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds (c1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f) & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2 implies c1 =XBOOLE-0R4 c2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & (y inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y) implies x =HIDDENR1 y"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A3: "y inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A4: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
      obtain y1 where 
        [ty]:"y1 be ElementSUBSET-1M1-of C" and y1Def:"y1 = y"
        using A3 sorry
      obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
        using A2 sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 f .FUNCT-1K1 y1"
        using A2 A4 partfun1_def_6 sorry
      then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y1"
        using A3 partfun1_def_6 sorry
      thus "x =HIDDENR1 y"
        using A1 A2 A3 sorry
    qed "sorry"
    thus "f be one-to-oneFUNCT-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_10:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds ((f be one-to-oneFUNCT-1V2 & x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f) & y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f) & f /.PARTFUN1K7\<^bsub>(D)\<^esub> x =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y implies x =XBOOLE-0R4 y"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f be one-to-oneFUNCT-1V2 & (x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f) implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> x =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y implies x =XBOOLE-0R4 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      and A3: "y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
    assume "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
    then have "f .FUNCT-1K1 x =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
      using A2 partfun1_def_6 sorry
    also have "... = f .FUNCT-1K1 y"
      using A3 partfun1_def_6 sorry
    finally have "f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y"
       sorry
    thus "x =XBOOLE-0R4 y"
      using A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax PARTFUN2K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ \<inverse>PARTFUN2K2\<^bsub>'( _ , _ ')\<^esub>" [228,0,0]228)
translations "f \<inverse>PARTFUN2K2\<^bsub>(X,Y)\<^esub>" \<rightharpoonup> "f \<inverse>FUNCT-1K4"

mtheorem partfun2_add_2:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(X,Y)"
"cluster f \<inverse>FUNCT-1K4 as-term-is PartFuncPARTFUN1M1-of(Y,X)"
proof
(*coherence*)
  show "f \<inverse>FUNCT-1K4 be PartFuncPARTFUN1M1-of(Y,X)"
    using partfun1_th_9 sorry
qed "sorry"

mtheorem partfun2_th_11:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(D,C) holds g =RELSET-1R2\<^bsub>(D,C)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> iff domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> f & ( for d be ElementSUBSET-1M1-of D holds  for c be ElementSUBSET-1M1-of C holds d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(D,C) holds (g =RELSET-1R2\<^bsub>(D,C)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> implies domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> f & ( for d be ElementSUBSET-1M1-of D holds  for c be ElementSUBSET-1M1-of C holds d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) & (domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> f & (( for d be ElementSUBSET-1M1-of D holds  for c be ElementSUBSET-1M1-of C holds d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c) & g <>HIDDENR2 f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>) implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(D,C)"
    show "g =RELSET-1R2\<^bsub>(D,C)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> implies domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> f & ( for d be ElementSUBSET-1M1-of D holds  for c be ElementSUBSET-1M1-of C holds d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
    proof-
      have "g =RELSET-1R2\<^bsub>(D,C)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> implies domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> f & ( for d be ElementSUBSET-1M1-of D holds  for c be ElementSUBSET-1M1-of C holds (d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c) & (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c implies d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d))"
      proof(rule impI,rule conjMI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
        assume A1: "g =RELSET-1R2\<^bsub>(D,C)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>"
        thus "domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
          using funct_1_th_32 sorry
        fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        have A2: "domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
          using A1 funct_1_th_32 sorry
        show "d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        proof(rule impMI ,rule impI)
          assume A3: "d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
            and A4: "c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d"
          have "c =XBOOLE-0R4 g .FUNCT-1K1 d"
            using A2 A3 A4 partfun1_def_6 sorry
          then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f .FUNCT-1K1 c"
            using A1 A3 funct_1_th_32 sorry
          thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
            using partfun1_def_6 sorry
        qed
        assume A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          and A6: "d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        have "d =XBOOLE-0R4 f .FUNCT-1K1 c"
          using A5 A6 partfun1_def_6 sorry
        then have "d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g .FUNCT-1K1 d"
          using A1 A5 funct_1_th_32 sorry
        thus "d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d"
          using A2 partfun1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A7: "domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
      and A8: " for d be ElementSUBSET-1M1-of D holds  for c be ElementSUBSET-1M1-of C holds d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      and A9: "g <>HIDDENR2 f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>"
    have " False "
    proof-
      show " False "
      proof-
        have cases: "domRELSET-1K1\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>) <>HIDDENR2 domRELSET-1K1\<^bsub>(D)\<^esub> g or ( ex d be ElementSUBSET-1M1-of D st d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>) & f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d <>HIDDENR2 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d)"
          using A9 partfun2_th_1 sorry
        have case1: "domRELSET-1K1\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>) <>HIDDENR2 domRELSET-1K1\<^bsub>(D)\<^esub> g implies  False "
        proof(rule impI)
          assume "domRELSET-1K1\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>) <>HIDDENR2 domRELSET-1K1\<^bsub>(D)\<^esub> g"
          thus " False "
            using A7 funct_1_th_33 sorry
        qed
        have case2: "( ex d be ElementSUBSET-1M1-of D st d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>) & f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d <>HIDDENR2 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d) implies  False "
        proof(rule impI)
          assume " ex d be ElementSUBSET-1M1-of D st d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>) & f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d <>HIDDENR2 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d"
          then obtain d where
            [ty]:"d be ElementSUBSET-1M1-of D" and 
            A10: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>)"and A11: "f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d <>HIDDENR2 g /.PARTFUN1K7\<^bsub>(C)\<^esub> d"
             sorry
          have "f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d inTARSKIR2 rngRELSET-1K2\<^bsub>(C)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>)"
            using A10 partfun2_th_2 sorry
          then have A12: "f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
            using funct_1_th_33 sorry
          have "d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
            using A10 funct_1_th_33 sorry
          then have "d =XBOOLE-0R4 f .FUNCT-1K1 (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> .FUNCT-1K1 d)"
            using funct_1_th_35 sorry
          then have "d =XBOOLE-0R4 f .FUNCT-1K1 (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d)"
            using A10 partfun1_def_6 sorry
          then have "d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d)"
            using A12 partfun1_def_6 sorry
          thus " False "
            using A8 A11 A12 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_12:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies c =XBOOLE-0R4 f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c) & c =XBOOLE-0R4 (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> *PARTFUN1K1\<^bsub>(C,D,D,C)\<^esub> f)/.PARTFUN1K7\<^bsub>(C)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies c =XBOOLE-0R4 f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c) & c =XBOOLE-0R4 (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> *PARTFUN1K1\<^bsub>(C,D,D,C)\<^esub> f)/.PARTFUN1K7\<^bsub>(C)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
    thus A2: "c =XBOOLE-0R4 f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
      using partfun2_th_11 sorry
    have "f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> =RELSET-1R2\<^bsub>(D,C)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>"
       sorry
    then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
      using A1 partfun2_th_11 sorry
    then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>)"
      using funct_1_th_33 sorry
    thus "c =XBOOLE-0R4 (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> *PARTFUN1K1\<^bsub>(C,D,D,C)\<^esub> f)/.PARTFUN1K7\<^bsub>(C)\<^esub> c"
      using A1 A2 partfun2_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_13:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D) holds d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f implies d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d) & d =XBOOLE-0R4 (f *PARTFUN1K1\<^bsub>(D,C,C,D)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>)/.PARTFUN1K7\<^bsub>(D)\<^esub> d"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D) holds d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f implies d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d) & d =XBOOLE-0R4 (f *PARTFUN1K1\<^bsub>(D,C,C,D)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>)/.PARTFUN1K7\<^bsub>(D)\<^esub> d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f"
    then have "d =XBOOLE-0R4 (f *PARTFUN1K1\<^bsub>(D,C,C,D)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>).FUNCT-1K1 d & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (f *PARTFUN1K1\<^bsub>(D,C,C,D)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>)"
      using funct_1_th_35 funct_1_th_37 sorry
    thus "d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub> /.PARTFUN1K7\<^bsub>(C)\<^esub> d) & d =XBOOLE-0R4 (f *PARTFUN1K1\<^bsub>(D,C,C,D)\<^esub> f \<inverse>PARTFUN2K2\<^bsub>(C,D)\<^esub>)/.PARTFUN1K7\<^bsub>(D)\<^esub> d"
      using A1 partfun2_th_11 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_14:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for t be PartFuncPARTFUN1M1-of(D,C) holds ((f be one-to-oneFUNCT-1V2 & domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(C)\<^esub> t) & rngRELSET-1K2\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> t) & ( for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> t implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d iff t /.PARTFUN1K7\<^bsub>(C)\<^esub> d =XBOOLE-0R4 c)) implies t =FUNCT-1R1 f \<inverse>FUNCT-1K4"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for t be PartFuncPARTFUN1M1-of(D,C) holds ((f be one-to-oneFUNCT-1V2 & domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(C)\<^esub> t) & rngRELSET-1K2\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> t) & ( for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> t implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d iff t /.PARTFUN1K7\<^bsub>(C)\<^esub> d =XBOOLE-0R4 c)) implies t =FUNCT-1R1 f \<inverse>FUNCT-1K4"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix t assume [ty]: "t be PartFuncPARTFUN1M1-of(D,C)"
    assume A1: "(f be one-to-oneFUNCT-1V2 & domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(C)\<^esub> t) & rngRELSET-1K2\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> t"
      and A2: " for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> t implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d iff t /.PARTFUN1K7\<^bsub>(C)\<^esub> d =XBOOLE-0R4 c)"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> t implies (f .FUNCT-1K1 x =HIDDENR1 y implies t .FUNCT-1K1 y =HIDDENR1 x) & (t .FUNCT-1K1 y =HIDDENR1 x implies f .FUNCT-1K1 x =HIDDENR1 y)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A4: "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> t"
      obtain y1 where 
        [ty]:"y1 be ElementSUBSET-1M1-of D" and y1Def:"y1 = y"
        using A4 sorry
      obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
        using A3 sorry
      show "f .FUNCT-1K1 x =HIDDENR1 y implies t .FUNCT-1K1 y =HIDDENR1 x"
      proof(rule impI)
        assume "f .FUNCT-1K1 x =HIDDENR1 y"
        then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 y1"
          using A3 partfun1_def_6 sorry
        then have "t /.PARTFUN1K7\<^bsub>(C)\<^esub> y1 =XBOOLE-0R4 x1"
          using A2 A3 A4 sorry
        thus "t .FUNCT-1K1 y =HIDDENR1 x"
          using A4 partfun1_def_6 sorry
      qed
      assume "t .FUNCT-1K1 y =HIDDENR1 x"
      then have "t /.PARTFUN1K7\<^bsub>(C)\<^esub> y1 =XBOOLE-0R4 x1"
        using A4 partfun1_def_6 sorry
      then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 y1"
        using A2 A3 A4 sorry
      thus "f .FUNCT-1K1 x =HIDDENR1 y"
        using A3 partfun1_def_6 sorry
    qed "sorry"
    thus "t =FUNCT-1R1 f \<inverse>FUNCT-1K4"
      using A1 funct_1_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_15:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds g =RELSET-1R2\<^bsub>(C,D)\<^esub> f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X iff domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds (g =RELSET-1R2\<^bsub>(C,D)\<^esub> f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X implies domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) & (domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c) implies g =RELSET-1R2\<^bsub>(C,D)\<^esub> f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    show "g =RELSET-1R2\<^bsub>(C,D)\<^esub> f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X implies domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "g =RELSET-1R2\<^bsub>(C,D)\<^esub> f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X"
      thus "domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      then have "g .FUNCT-1K1 c =XBOOLE-0R4 f .FUNCT-1K1 c"
        using A1 funct_1_th_47 sorry
      then have A3: "g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f .FUNCT-1K1 c"
        using A2 partfun1_def_6 sorry
      have "domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using A1 relat_1_th_61 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A2 xboole_0_def_4 sorry
      thus "g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        using A3 partfun1_def_6 sorry
    qed "sorry"
    assume A4: "domRELSET-1K1\<^bsub>(C)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      and A5: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      then obtain y where 
        [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = x"
         sorry
      have "g /.PARTFUN1K7\<^bsub>(D)\<^esub> y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
        using A5 A6 sorry
      then have A7: "g .FUNCT-1K1 y =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
        using A6 partfun1_def_6 sorry
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A4 A6 xboole_0_def_4 sorry
      thus "g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A7 partfun1_def_6 sorry
    qed "sorry"
    thus "g =RELSET-1R2\<^bsub>(C,D)\<^esub> f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X"
      using A4 funct_1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_16:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
      using relat_1_th_61 sorry
    thus "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      using partfun2_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_17:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X"
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
      using xboole_0_def_4 sorry
    thus "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      using partfun2_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_18:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      and A2: "c inTARSKIR2 X"
    have "f .FUNCT-1K1 c inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
      using A1 A2 funct_1_th_50 sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
      using A1 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax PARTFUN2K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _  |`PARTFUN2K3\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "X  |`RELAT-1K9 f"

mtheorem partfun2_add_3:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster X  |`RELAT-1K9 f as-term-is PartFuncPARTFUN1M1-of(C,D)"
proof
(*coherence*)
  show "X  |`RELAT-1K9 f be PartFuncPARTFUN1M1-of(C,D)"
    using partfun1_th_13 sorry
qed "sorry"

mtheorem partfun2_th_19:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds g =RELSET-1R2\<^bsub>(C,D)\<^esub> X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f iff ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds (g =RELSET-1R2\<^bsub>(C,D)\<^esub> X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) & (( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c) implies g =RELSET-1R2\<^bsub>(C,D)\<^esub> X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    show "g =RELSET-1R2\<^bsub>(C,D)\<^esub> X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X) & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "g =RELSET-1R2\<^bsub>(C,D)\<^esub> X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f"
      have " for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X) & (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g)"
      proof(rule ballI,rule conjMI,rule impMI ,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        show "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
        proof(rule impI)
          assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
          then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 c inTARSKIR2 X"
            using A1 funct_1_th_54 sorry
          thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
            using partfun1_def_6 sorry
        qed
        assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          and A3: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
        have "f .FUNCT-1K1 c inTARSKIR2 X"
          using A2 A3 partfun1_def_6 sorry
        thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
          using A1 A2 funct_1_th_54 sorry
      qed "sorry"
      thus " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
         sorry
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      then have "g .FUNCT-1K1 c =XBOOLE-0R4 f .FUNCT-1K1 c"
        using A1 funct_1_th_55 sorry
      then have A5: "g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f .FUNCT-1K1 c"
        using A4 partfun1_def_6 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A1 A4 funct_1_th_54 sorry
      thus "g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        using A5 partfun1_def_6 sorry
    qed "sorry"
    assume A6: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
      and A7: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
    have A8: " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 X) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 X implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 X"
      proof(rule impI)
        assume A9: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g"
        then obtain x1 where 
          [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
           sorry
        have "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 inTARSKIR2 X"
          using A6 A9 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 X"
          using partfun1_def_6 sorry
      qed
      assume A10: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A11: "f .FUNCT-1K1 x inTARSKIR2 X"
      obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
        using A10 sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 inTARSKIR2 X"
        using A10 A11 partfun1_def_6 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g"
        using A6 A10 sorry
    qed "sorry"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A12: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      then obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
         sorry
      have "g /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
        using A7 A12 sorry
      then have A13: "g .FUNCT-1K1 x1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
        using A12 partfun1_def_6 sorry
      have "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A6 A12 sorry
      thus "g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A13 partfun1_def_6 sorry
    qed "sorry"
    thus "g =RELSET-1R2\<^bsub>(C,D)\<^esub> X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f"
      using A8 funct_1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_20:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f) iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
  using partfun2_th_19 sorry

mtheorem partfun2_th_21:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f) implies (X  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
  using partfun2_th_19 sorry

mtheorem partfun2_th_22:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds SD =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X iff ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD iff ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c))"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (SD =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X implies ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD iff ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c))) & (( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD iff ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) & SD <>HIDDENR2 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SD assume [ty]: "SD be SubsetSUBSET-1M2-of D"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "SD =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X implies ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD iff ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c))"
    proof-
      have "SD =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X implies ( for d be ElementSUBSET-1M1-of D holds (d inTARSKIR2 SD implies ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) & (( ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & (c inTARSKIR2 X & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) implies d inTARSKIR2 SD))"
      proof(rule impI,rule ballI,rule conjMI,rule impI)
        assume A1: "SD =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X"
        fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
        show "d inTARSKIR2 SD implies ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
        proof-
          have "d inTARSKIR2 SD implies ( ex tVar2 be ElementSUBSET-1M1-of C st (tVar2 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & tVar2 inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> tVar2)"
          proof(rule impI)
            assume "d inTARSKIR2 SD"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"and A3: "x inHIDDENR3 X"and A4: "d =XBOOLE-0R4 f .FUNCT-1K1 x"
              using A1 funct_1_def_6 sorry
            have 
              [ty]:"x be ElementSUBSET-1M1-of C"
              using A2 sorry
            show " ex tVar2 be ElementSUBSET-1M1-of C st (tVar2 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & tVar2 inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> tVar2"
            proof(rule bexI[of _ "x"],rule conjMI)
              show "x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & x inTARSKIR2 X"
                using A2 A3 sorry
              show "d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x"
                using A2 A4 partfun1_def_6 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        assume Given: " ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & (c inTARSKIR2 X & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
        then obtain c where
          [ty]:"c be ElementSUBSET-1M1-of C" and 
          A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"and A6: "c inTARSKIR2 X & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
           sorry
        have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f .FUNCT-1K1 c"
          using A5 partfun1_def_6 sorry
        thus "d inTARSKIR2 SD"
          using A1 A5 A6 funct_1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A7: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 SD iff ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
      and A8: "SD <>HIDDENR2 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X"
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A9: " not (x inHIDDENR3 SD iff x inHIDDENR3 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X)"
      using A8 tarski_th_2 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "x inHIDDENR3 SD &  not x inHIDDENR3 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X or x inHIDDENR3 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X &  not x inHIDDENR3 SD"
          using A9 sorry
        have case1: "x inHIDDENR3 SD &  not x inHIDDENR3 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X implies  False "
        proof(rule impI)
          assume A10: "x inHIDDENR3 SD &  not x inHIDDENR3 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X"
          then have 
            [ty]:"x be ElementSUBSET-1M1-of D"
             sorry
          obtain c where
            [ty]:"c be ElementSUBSET-1M1-of C" and 
            A11: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"and A12: "c inTARSKIR2 X"and A13: "x =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
            using A7 A10 sorry
          have "x =XBOOLE-0R4 f .FUNCT-1K1 c"
            using A11 A13 partfun1_def_6 sorry
          thus " False "
            using A10 A11 A12 funct_1_def_6 sorry
        qed
        have case2: "x inHIDDENR3 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X &  not x inHIDDENR3 SD implies  False "
        proof(rule impI)
          assume A14: "x inHIDDENR3 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X &  not x inHIDDENR3 SD"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A15: "y inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"and A16: "y inHIDDENR3 X"and A17: "x =HIDDENR1 f .FUNCT-1K1 y"
            using funct_1_def_6 sorry
          have 
            [ty]:"y be ElementSUBSET-1M1-of C"
            using A15 sorry
          have "x =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
            using A15 A17 partfun1_def_6 sorry
          thus " False "
            using A7 A14 A15 A16 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_23:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds d inTARSKIR2 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X iff ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
  using partfun2_th_22 sorry

mtheorem partfun2_th_24:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies ImRELAT-1K12(f,c) =XBOOLE-0R4 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c }"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies ImRELAT-1K12(f,c) =HIDDENR1 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
    then have "ImRELAT-1K12(f,c) =HIDDENR1 {TARSKIK1 f .FUNCT-1K1 c }"
      using funct_1_th_59 sorry
    also have "... = {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c }"
      using A1 partfun1_def_6 sorry
    finally show "ImRELAT-1K12(f,c) =HIDDENR1 {TARSKIK1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_25:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .:RELSET-1K7\<^bsub>(C,D)\<^esub> {TARSKIK2 c1,c2 } =XBOOLE-0R4 {TARSKIK2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2 }"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .:RELSET-1K7\<^bsub>(C,D)\<^esub> {TARSKIK2 c1,c2 } =HIDDENR1 {TARSKIK2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of C"
    fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "c1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      and A2: "c2 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
    have "f .:RELSET-1K7\<^bsub>(C,D)\<^esub> {TARSKIK2 c1,c2 } =HIDDENR1 {TARSKIK2 f .FUNCT-1K1 c1,f .FUNCT-1K1 c2 }"
      using A1 A2 funct_1_th_60 sorry
    also have "... = {TARSKIK2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1,f .FUNCT-1K1 c2 }"
      using A1 partfun1_def_6 sorry
    also have "... = {TARSKIK2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2 }"
      using A2 partfun1_def_6 sorry
    finally show "f .:RELSET-1K7\<^bsub>(C,D)\<^esub> {TARSKIK2 c1,c2 } =HIDDENR1 {TARSKIK2 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_26:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds SC =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> X iff ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 SC iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (SC =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> X implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 SC iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X)) & (( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 SC iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X) implies SC =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SC assume [ty]: "SC be SubsetSUBSET-1M2-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "SC =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> X implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 SC iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X)"
    proof-
      have "SC =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> X implies ( for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 SC implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X) & (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X implies c inTARSKIR2 SC))"
      proof(rule impI,rule ballI,rule conjMI,rule impMI ,rule impI)
        assume A1: "SC =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> X"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        show "c inTARSKIR2 SC implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
        proof(rule impI)
          assume "c inTARSKIR2 SC"
          then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 c inTARSKIR2 X"
            using A1 funct_1_def_7 sorry
          thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
            using partfun1_def_6 sorry
        qed
        assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          and A3: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
        have "f .FUNCT-1K1 c inTARSKIR2 X"
          using A2 A3 partfun1_def_6 sorry
        thus "c inTARSKIR2 SC"
          using A1 A2 funct_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 SC iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 X"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 SC implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 X) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 X implies x inHIDDENR3 SC)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 SC implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 X"
      proof(rule impI)
        assume A5: "x inHIDDENR3 SC"
        then obtain x1 where 
          [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
           sorry
        have "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 inTARSKIR2 X"
          using A4 A5 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 x inTARSKIR2 X"
          using partfun1_def_6 sorry
      qed
      assume A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A7: "f .FUNCT-1K1 x inTARSKIR2 X"
      obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
        using A6 sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 inTARSKIR2 X"
        using A6 A7 partfun1_def_6 sorry
      thus "x inHIDDENR3 SC"
        using A4 A6 sorry
    qed "sorry"
    thus "SC =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> X"
      using funct_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_27:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  ex g be FunctionFUNCT-2M1-of(C,D) st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  ex tVar3 be FunctionFUNCT-2M1-of(C,D) st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies tVar3 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    obtain g where
      [ty]:"g be FunctionFUNCT-2M1-of(C,D)" and 
      A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using funct_2_th_71 sorry
    show " ex tVar3 be FunctionFUNCT-2M1-of(C,D) st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies tVar3 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      then have "g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 f .FUNCT-1K1 c"
        using A1 sorry
      thus "g .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        using A2 partfun1_def_6 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_28:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds f toleratesPARTFUN1R1 g iff ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds (f toleratesPARTFUN1R1 g implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)) & (( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c) implies f toleratesPARTFUN1R1 g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    show "f toleratesPARTFUN1R1 g implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
    proof(rule impI,rule ballI,rule impI)
      assume A1: "f toleratesPARTFUN1R1 g"
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g"
      then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using xboole_0_def_4 sorry
      have "f .FUNCT-1K1 c =XBOOLE-0R4 g .FUNCT-1K1 c"
        using A1 A2 partfun1_def_4 sorry
      then have A4: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g .FUNCT-1K1 c"
        using A3 partfun1_def_6 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
        using A2 xboole_0_def_4 sorry
      thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        using A4 partfun1_def_6 sorry
    qed "sorry"
    assume A5: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> g"
      then obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
         sorry
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
        using A5 A6 xboole_0_def_4 sorry
      then have A7: "f .FUNCT-1K1 x =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
        using partfun1_def_6 sorry
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> g"
        using A6 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A7 partfun1_def_6 sorry
    qed "sorry"
    thus "f toleratesPARTFUN1R1 g"
      using partfun1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem partfun2_sch_1:
  fixes Df0 Cf0 Pp2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows " ex f be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))) & ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies Pp2(d,f /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d))"
  proof-
    have " ex tVar4 be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar4 iff ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))) & ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar4 implies Pp2(d,tVar4 /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d))"
    proof-
      let ?R = "\<lambda>Lamb1.  ex c be ElementSUBSET-1M1-of Cf0 st Pp2(Lamb1,c)"
      let ?x = "the ElementSUBSET-1M1-of Cf0"
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. (( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(Lamb1,c)) implies Pp2(Lamb1,Lamb2)) & (( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(Lamb1,c)) implies Lamb2 =HIDDENR1 ?x)"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Df0 & ?R(x)"
        using xboole_0_sch_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Df0"
        using A1 sorry
      then have 
        [ty]:"X be SubsetSUBSET-1M2-of Df0"
        using tarski_def_3 sorry
      have A2: " for d be ElementSUBSET-1M1-of Df0 holds  ex z be ElementSUBSET-1M1-of Cf0 st ?Q(d,z)"
      proof-
        have " for d be ElementSUBSET-1M1-of Df0 holds  not ( for z be ElementSUBSET-1M1-of Cf0 holds  not ((( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)) implies Pp2(d,z)) & (( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(d,c)) implies z =HIDDENR1 the ElementSUBSET-1M1-of Cf0)))"
        proof(rule ballI)
          fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
          have "( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(d,c)) implies ( ex z be ElementSUBSET-1M1-of Cf0 st (( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)) implies Pp2(d,z)) & (( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(d,c)) implies z =XBOOLE-0R4 ?x))"
             sorry
          thus " not ( for z be ElementSUBSET-1M1-of Cf0 holds  not ((( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)) implies Pp2(d,z)) & (( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(d,c)) implies z =HIDDENR1 the ElementSUBSET-1M1-of Cf0)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain g where
        [ty]:"g be FunctionFUNCT-2M1-of(Df0,Cf0)" and 
        A3: " for d be ElementSUBSET-1M1-of Df0 holds ?Q(d,g .FUNCT-2K3\<^bsub>(Df0,Cf0)\<^esub> d)"
        using funct_2_sch_3 A2 sorry
      obtain f where 
        [ty]:"f be PartFuncPARTFUN1M1-of(Df0,Cf0)" and fDef:"f = g  |PARTFUN1K2\<^bsub>(Df0,Cf0)\<^esub> X"
         sorry
      show " ex tVar4 be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar4 iff ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))) & ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar4 implies Pp2(d,tVar4 /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
        have A4: "domRELSET-1K1\<^bsub>(Df0)\<^esub> g =XBOOLE-0R4 Df0"
          using funct_2_def_1 sorry
        show " for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))"
        proof-
          have " for d be ElementSUBSET-1M1-of Df0 holds (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))) & (( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)) implies d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f)"
          proof(rule ballI,rule conjMI,rule impI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
            have "domRELSET-1K1\<^bsub>(Df0)\<^esub> f c=TARSKIR1 X"
              using relat_1_th_58 sorry
            thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))"
              using A1 sorry
            assume " ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)"
            then have "d inTARSKIR2 X"
              using A1 sorry
            then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> g /\\SUBSET-1K9\<^bsub>(Df0)\<^esub> X"
              using A4 xboole_0_def_4 sorry
            thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f"
              using relat_1_th_61 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
        assume A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f"
        have "domRELSET-1K1\<^bsub>(Df0)\<^esub> f c=TARSKIR1 X"
          using relat_1_th_58 sorry
        then have " ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)"
          using A1 A5 sorry
        then have "Pp2(d,g .FUNCT-2K3\<^bsub>(Df0,Cf0)\<^esub> d)"
          using A3 sorry
        then have "Pp2(d,f .FUNCT-1K1 d)"
          using A5 funct_1_th_47 sorry
        thus "Pp2(d,f /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d)"
          using A5 partfun1_def_6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem partfun2_sch_2:
  fixes Df0 Cf0 Ff1 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Cf0"
  shows " ex f be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff Pp1(d)) & ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d =XBOOLE-0R4 Ff1(d))"
  proof-
    have " ex tVar5 be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar5 iff Pp1(d)) & ( for d be ElementSUBSET-1M1-of Df0 holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar5 &  not tVar5 /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d =XBOOLE-0R4 Ff1(d)))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. Pp1(Lamb1) & Lamb2 =XBOOLE-0R4 Ff1(Lamb1)"
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of(Df0,Cf0)" and 
        A1: " for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff ( ex c be ElementSUBSET-1M1-of Cf0 st ?Q(d,c))"and A2: " for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies ?Q(d,f /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d)"
        using partfun2_sch_1 sorry
      show " ex tVar5 be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar5 iff Pp1(d)) & ( for d be ElementSUBSET-1M1-of Df0 holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar5 &  not tVar5 /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d =XBOOLE-0R4 Ff1(d)))"
      proof(rule bexI[of _ "f"],rule conjMI)
        show " for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff Pp1(d)"
        proof-
          have " for d be ElementSUBSET-1M1-of Df0 holds (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies Pp1(d)) & (Pp1(d) implies d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f)"
          proof(rule ballI,rule conjMI,rule impI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
            show "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies Pp1(d)"
            proof(rule impI)
              assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f"
              then have " ex c be ElementSUBSET-1M1-of Cf0 st Pp1(d) & c =XBOOLE-0R4 Ff1(d)"
                using A1 sorry
              thus "Pp1(d)"
                 sorry
            qed
            assume "Pp1(d)"
            then have " ex c be ElementSUBSET-1M1-of Cf0 st Pp1(d) & c =XBOOLE-0R4 Ff1(d)"
               sorry
            thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f"
              using A1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for d be ElementSUBSET-1M1-of Df0 holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f &  not f /.PARTFUN1K7\<^bsub>(Cf0)\<^esub> d =XBOOLE-0R4 Ff1(d))"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem partfun2_sch_3:
  fixes Cf0 Df0 Xf0 Ff1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0"
  shows " for f be PartFuncPARTFUN1M1-of(Cf0,Df0) holds  for g be PartFuncPARTFUN1M1-of(Cf0,Df0) holds (domRELSET-1K1\<^bsub>(Cf0)\<^esub> f =XBOOLE-0R4 Xf0 & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =XBOOLE-0R4 Ff1(c))) & (domRELSET-1K1\<^bsub>(Cf0)\<^esub> g =XBOOLE-0R4 Xf0 & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =XBOOLE-0R4 Ff1(c))) implies f =RELSET-1R2\<^bsub>(Cf0,Df0)\<^esub> g"
  proof-
    have " for f be PartFuncPARTFUN1M1-of(Cf0,Df0) holds  for g be PartFuncPARTFUN1M1-of(Cf0,Df0) holds domRELSET-1K1\<^bsub>(Cf0)\<^esub> f =XBOOLE-0R4 Xf0 & (( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =XBOOLE-0R4 Ff1(c)) & (domRELSET-1K1\<^bsub>(Cf0)\<^esub> g =XBOOLE-0R4 Xf0 & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =XBOOLE-0R4 Ff1(c)))) implies f =RELSET-1R2\<^bsub>(Cf0,Df0)\<^esub> g"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
      fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(Cf0,Df0)"
      fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(Cf0,Df0)"
      assume A1: "domRELSET-1K1\<^bsub>(Cf0)\<^esub> f =XBOOLE-0R4 Xf0"
        and A2: " for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =XBOOLE-0R4 Ff1(c)"
        and A3: "domRELSET-1K1\<^bsub>(Cf0)\<^esub> g =XBOOLE-0R4 Xf0"
        and A4: " for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =XBOOLE-0R4 Ff1(c)"
      have " for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =HIDDENR1 g /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of Cf0"
        assume A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f"
        then have "f /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =HIDDENR1 Ff1(c)"
          using A2 sorry
        also have "... = g /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c"
          using A1 A3 A4 A5 sorry
        finally show "f /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c =HIDDENR1 g /.PARTFUN1K7\<^bsub>(Df0)\<^esub> c"
           sorry
      qed "sorry"
      thus "f =RELSET-1R2\<^bsub>(Cf0,Df0)\<^esub> g"
        using A1 A3 partfun2_th_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

syntax PARTFUN2K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -->PARTFUN2K4\<^bsub>'( _ , _ ')\<^esub>  _ " [116,0,0,116]116)
translations "SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d" \<rightharpoonup> "SC -->FUNCOP-1K2 d"

mtheorem partfun2_add_4:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "SC be SubsetSUBSET-1M2-of C", "d be ElementSUBSET-1M1-of D"
"cluster SC -->FUNCOP-1K2 d as-term-is PartFuncPARTFUN1M1-of(C,D)"
proof
(*coherence*)
  show "SC -->FUNCOP-1K2 d be PartFuncPARTFUN1M1-of(C,D)"
  proof-
    have "domRELSET-1K1\<^bsub>(SC)\<^esub> (SC -->FUNCOP-1K8\<^bsub>(D)\<^esub> d) =XBOOLE-0R4 SC"
      using funcop_1_th_13 sorry
    thus "SC -->FUNCOP-1K2 d be PartFuncPARTFUN1M1-of(C,D)"
      using relset_1_th_7 sorry
  qed
qed "sorry"

mtheorem partfun2_th_29:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds c inTARSKIR2 SC implies (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds c inTARSKIR2 SC implies (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SC assume [ty]: "SC be SubsetSUBSET-1M2-of C"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    assume A1: "c inTARSKIR2 SC"
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) =XBOOLE-0R4 SC & (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d).FUNCT-1K1 c =XBOOLE-0R4 d"
      using funcop_1_th_7 funcop_1_th_13 sorry
    thus "(SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
      using A1 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_30:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d) implies f =RELSET-1R2\<^bsub>(C,D)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d) implies f =RELSET-1R2\<^bsub>(C,D)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 x =XBOOLE-0R4 d"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      then obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
         sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 d"
        using A1 A2 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 d"
        using A2 partfun1_def_6 sorry
    qed "sorry"
    thus "f =RELSET-1R2\<^bsub>(C,D)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d"
      using funcop_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_31:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SE be SubsetSUBSET-1M2-of E holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f *PARTFUN1K1\<^bsub>(E,C,C,D)\<^esub> (SE -->PARTFUN2K4\<^bsub>(E,C)\<^esub> c) =RELSET-1R2\<^bsub>(E,D)\<^esub> SE -->PARTFUN2K4\<^bsub>(E,D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SE be SubsetSUBSET-1M2-of E holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f *PARTFUN1K1\<^bsub>(E,C,C,D)\<^esub> (SE -->PARTFUN2K4\<^bsub>(E,C)\<^esub> c) =RELSET-1R2\<^bsub>(E,D)\<^esub> SE -->PARTFUN2K4\<^bsub>(E,D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SE assume [ty]: "SE be SubsetSUBSET-1M2-of E"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
    then have "f *PARTFUN1K1\<^bsub>(E,C,C,D)\<^esub> (SE -->PARTFUN2K4\<^bsub>(E,C)\<^esub> c) =FUNCT-1R1 SE -->FUNCOP-1K7 f .FUNCT-1K1 c"
      using funcop_1_th_17 sorry
    thus "f *PARTFUN1K1\<^bsub>(E,C,C,D)\<^esub> (SE -->PARTFUN2K4\<^bsub>(E,C)\<^esub> c) =RELSET-1R2\<^bsub>(E,D)\<^esub> SE -->PARTFUN2K4\<^bsub>(E,D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      using A1 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_32:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds idPARTFUN2K1\<^bsub>(C)\<^esub> SC be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff SC =XBOOLE-0R4 C"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds (idPARTFUN2K1\<^bsub>(C)\<^esub> SC be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies SC =XBOOLE-0R4 C) & (SC =XBOOLE-0R4 C implies idPARTFUN2K1\<^bsub>(C)\<^esub> SC be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SC assume [ty]: "SC be SubsetSUBSET-1M2-of C"
    show "idPARTFUN2K1\<^bsub>(C)\<^esub> SC be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies SC =XBOOLE-0R4 C"
    proof(rule impI)
      assume "idPARTFUN2K1\<^bsub>(C)\<^esub> SC be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (idPARTFUN2K1\<^bsub>(C)\<^esub> SC) =XBOOLE-0R4 C"
        using partfun1_def_2 sorry
      thus "SC =XBOOLE-0R4 C"
        using relat_1_th_45 sorry
    qed
    assume "SC =XBOOLE-0R4 C"
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (idPARTFUN2K1\<^bsub>(C)\<^esub> SC) =XBOOLE-0R4 C"
      using relat_1_th_45 sorry
    thus "idPARTFUN2K1\<^bsub>(C)\<^esub> SC be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_33:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for d be ElementSUBSET-1M1-of D holds SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies SC <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for d be ElementSUBSET-1M1-of D holds SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub> & SC =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SC assume [ty]: "SC be SubsetSUBSET-1M2-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    assume A1: "SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      and A2: "SC =XBOOLE-0R4 {}XBOOLE-0K1"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) =XBOOLE-0R4 C"
      using A1 partfun1_def_2 sorry
    thus " False "
      using A2 funcop_1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_34:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for d be ElementSUBSET-1M1-of D holds SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff SC =XBOOLE-0R4 C"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for d be ElementSUBSET-1M1-of D holds (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies SC =XBOOLE-0R4 C) & (SC =XBOOLE-0R4 C implies SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SC assume [ty]: "SC be SubsetSUBSET-1M2-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    show "SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies SC =XBOOLE-0R4 C"
    proof(rule impI)
      assume "SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) =XBOOLE-0R4 C"
        using partfun1_def_2 sorry
      thus "SC =XBOOLE-0R4 C"
        using funcop_1_th_13 sorry
    qed
    assume "SC =XBOOLE-0R4 C"
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) =XBOOLE-0R4 C"
      using funcop_1_th_13 sorry
    thus "SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax PARTFUN2V1 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("constantPARTFUN2V1\<^bsub>'( _ , _ ')\<^esub>" [0,0]70)
translations "constantPARTFUN2V1\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "constantFUNCT-1V5"

mtheorem partfun2_def_1:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"redefine attr constantPARTFUN2V1\<^bsub>(C,D)\<^esub> for PartFuncPARTFUN1M1-of(C,D) means
  (\<lambda>f.  ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d)"
proof
(*compatibility*)
  show " for f be PartFuncPARTFUN1M1-of(C,D) holds f be constantPARTFUN2V1\<^bsub>(C,D)\<^esub> iff ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d)"
  proof(rule ballI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "f be constantPARTFUN2V1\<^bsub>(C,D)\<^esub> iff ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d)"
    proof-
      have "(f be constantFUNCT-1V5 implies ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d)) & (( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d) implies f be constantFUNCT-1V5)"
      proof(rule conjMI,rule impI)
        show "f be constantFUNCT-1V5 implies ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d)"
        proof-
          have "f be constantFUNCT-1V5 implies ( ex tVar6 be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f .FUNCT-1K1 c =XBOOLE-0R4 tVar6))"
          proof(rule impI)
            assume A1: "f be constantFUNCT-1V5"
            show " ex tVar6 be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f .FUNCT-1K1 c =XBOOLE-0R4 tVar6)"
            proof-
              have cases: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 or domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
                 sorry
              have case1: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar6 be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f .FUNCT-1K1 c =XBOOLE-0R4 tVar6))"
              proof(rule impI)
                assume A2: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1"
                let ?d = "the ElementSUBSET-1M1-of D"
                show " ex tVar6 be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f .FUNCT-1K1 c =XBOOLE-0R4 tVar6)"
                proof(rule bexI[of _ "?d"])
                  show " for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f .FUNCT-1K1 c =XBOOLE-0R4 the ElementSUBSET-1M1-of D)"
                    using A2 sorry
                qed "sorry"
              qed
              have case2: "domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 implies ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 d)"
              proof(rule impI)
                assume "domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
                then obtain c0 where
                  [ty]:"c0 be objectHIDDENM1" and 
                  A3: "c0 inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
                  using xboole_0_def_1 sorry
                have 
                  [ty]:"c0 be ElementSUBSET-1M1-of C"
                  using A3 sorry
                obtain d where 
                  [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = f /.PARTFUN1K7\<^bsub>(D)\<^esub> c0"
                   sorry
                show " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 d"
                proof(rule bexI[of _ "d"],rule ballI,rule impI)
                  fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
                  assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
                  then have "f .FUNCT-1K1 c =HIDDENR1 f .FUNCT-1K1 c0"
                    using A1 A3 sorry
                  also have "... = d"
                    using A3 partfun1_def_6 sorry
                  finally show "f .FUNCT-1K1 c =HIDDENR1 d"
                     sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
        assume Given: " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d"
        then obtain d where
          [ty]:"d be ElementSUBSET-1M1-of D" and 
          A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d"
           sorry
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f & y inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
            and A6: "y inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          have "f .FUNCT-1K1 x =HIDDENR1 d"
            using A4 A5 sorry
          also have "... = f .FUNCT-1K1 y"
            using A4 A6 sorry
          finally show "f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y"
             sorry
        qed "sorry"
        thus "f be constantFUNCT-1V5"
          using funct_1_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem partfun2_th_35:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 iff ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d)) & (( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d) implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d)"
    proof-
      have " not (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & ( for d be ElementSUBSET-1M1-of D holds  not ( for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d))))"
      proof-
        have "( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =XBOOLE-0R4 d) implies ( ex tVar8 be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =HIDDENR1 tVar8)"
        proof(rule impI)
          assume Given: " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =XBOOLE-0R4 d"
          then obtain d where
            [ty]:"d be ElementSUBSET-1M1-of D" and 
            A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =XBOOLE-0R4 d"
             sorry
          show " ex tVar8 be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =HIDDENR1 tVar8"
          proof(rule bexI[of _ "d"],rule ballI,rule impI)
            fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
            assume A2: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
            then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
              using relat_1_th_61 sorry
            have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
              using A2 xboole_0_def_4 sorry
            then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =HIDDENR1 f .FUNCT-1K1 c"
              using partfun1_def_6 sorry
            also have "... = (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c"
              using A3 funct_1_th_47 sorry
            also have "... = d"
              using A1 A3 sorry
            finally show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =HIDDENR1 d"
               sorry
          qed "sorry"
        qed
        thus " not (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & ( for d be ElementSUBSET-1M1-of D holds  not ( for c be ElementSUBSET-1M1-of C holds  not (c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d))))"
          using partfun2_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
    then obtain d where
      [ty]:"d be ElementSUBSET-1M1-of D" and 
      A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =HIDDENR1 d"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
      then have A6: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using relat_1_th_61 sorry
      then have A7: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using xboole_0_def_4 sorry
      have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =HIDDENR1 f .FUNCT-1K1 c"
        using A5 funct_1_th_47 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        using A7 partfun1_def_6 sorry
      also have "... = d"
        using A4 A6 sorry
      finally show "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =HIDDENR1 d"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
      using bexI[of _ "d"] partfun2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_36:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 iff ( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2)) & (( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2) implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2)"
    proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      assume "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
      then obtain d where
        [ty]:"d be ElementSUBSET-1M1-of D" and 
        A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using partfun2_th_35 sorry
      fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of C"
      fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of C"
      assume A2: "c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A3: "c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 d"
        using A1 A2 sorry
      thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2"
        using A1 A3 sorry
    qed "sorry"
    assume A4: " for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c1 =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c2"
    have "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
      proof-
        have cases: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 or X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
        proof(rule impI)
          assume A5: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1"
          have " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
          proof-
            let ?d = "the ElementSUBSET-1M1-of D"
            show " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
            proof(rule bexI[of _ "d"],rule ballI)
              fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
              show "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
                using A5 sorry
            qed "sorry"
          qed
          thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
            using partfun2_th_35 sorry
        qed
        have case2: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
        proof(rule impI)
          assume A6: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
          let ?x = "the ElementSUBSET-1M1-of X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
          have "?x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
            using A6 xboole_0_def_4 sorry
          then obtain x where 
            [ty]:"x be ElementSUBSET-1M1-of C" and xDef:"x = ?x"
             sorry
          have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x"
            using A4 sorry
          thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
            using partfun2_th_35 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_37:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds X meetsXBOOLE-0R5 domRELSET-1K1\<^bsub>(C)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 iff ( ex d be ElementSUBSET-1M1-of D st rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d}))"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  not ( not X meetsXBOOLE-0R5 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not ( not (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & ( for d be ElementSUBSET-1M1-of D holds  not rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d})) &  not ( not ( for d be ElementSUBSET-1M1-of D holds  not rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d}) &  not f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    have "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( ex d be ElementSUBSET-1M1-of D st rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d})) & (( ex d be ElementSUBSET-1M1-of D st rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d}) implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)"
    proof(rule impI,rule conjMI,rule impI)
      assume A1: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
      show "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( ex d be ElementSUBSET-1M1-of D st rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d})"
      proof-
        have "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( ex tVar11 be ElementSUBSET-1M1-of D st rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 tVar11})"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
          then obtain d where
            [ty]:"d be ElementSUBSET-1M1-of D" and 
            A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
            using partfun2_th_35 sorry
          show " ex tVar11 be ElementSUBSET-1M1-of D st rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 tVar11}"
          proof(rule bexI[of _ "d"])
            have "rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) c=TARSKIR1 {TARSKIK1 d} & {TARSKIK1 d} c=TARSKIR1 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
            proof(rule conjMI)
              show "rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) c=TARSKIR1 {TARSKIK1 d}"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) implies x inHIDDENR3 {TARSKIK1 d}"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A3: "y inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"and A4: "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 y =HIDDENR1 x"
                    using funct_1_def_3 sorry
                  have 
                    [ty]:"y be ElementSUBSET-1M1-of C"
                    using A3 sorry
                  have "domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
                    using relat_1_th_61 sorry
                  then have "d =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
                    using A2 A3 sorry
                  also have "... = (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> y"
                    using A3 partfun2_th_15 sorry
                  also have "... = x"
                    using A3 A4 partfun1_def_6 sorry
                  finally have "d =HIDDENR1 x"
                     sorry
                  thus "x inHIDDENR3 {TARSKIK1 d}"
                    using tarski_def_1 sorry
                qed "sorry"
                thus "rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) c=TARSKIR1 {TARSKIK1 d}"
                  using tarski_def_3 sorry
              qed
              show "{TARSKIK1 d} c=TARSKIR1 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
              proof-
                let ?y = "the ElementSUBSET-1M1-of X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
                have "?y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
                  using A1 xboole_0_def_4 sorry
                then obtain y where 
                  [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = ?y"
                   sorry
                have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 d} implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume A5: "x inHIDDENR3 {TARSKIK1 d}"
                  have A6: "domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
                    using relat_1_th_61 sorry
                  then have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> y =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> y"
                    using A1 partfun2_th_15 sorry
                  also have "... = d"
                    using A1 A2 sorry
                  also have "... = x"
                    using A5 tarski_def_1 sorry
                  finally have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> y =HIDDENR1 x"
                     sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
                    using A1 A6 partfun2_th_2 sorry
                qed "sorry"
                thus "{TARSKIK1 d} c=TARSKIR1 rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
                  using tarski_def_3 sorry
              qed
            qed
            thus "rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d}"
              using xboole_0_def_10 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      assume Given: " ex d be ElementSUBSET-1M1-of D st rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d}"
      then obtain d where
        [ty]:"d be ElementSUBSET-1M1-of D" and 
        A7: "rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d}"
         sorry
      have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =XBOOLE-0R4 d"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A8: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
        then have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 {TARSKIK1 d}"
          using A7 partfun2_th_2 sorry
        then have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c inTARSKIR2 {TARSKIK1 d}"
          using A8 partfun1_def_6 sorry
        thus "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =XBOOLE-0R4 d"
          using tarski_def_1 sorry
      qed "sorry"
      thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
        using bexI[of _ "d"] partfun2_def_1 sorry
    qed
    thus " not ( not X meetsXBOOLE-0R5 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not ( not (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & ( for d be ElementSUBSET-1M1-of D holds  not rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d})) &  not ( not ( for d be ElementSUBSET-1M1-of D holds  not rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) =XBOOLE-0R4 {TARSKIK1 d}) &  not f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_38:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & Y c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & Y c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
      and A2: "Y c=TARSKIR1 X"
    obtain d where
      [ty]:"d be ElementSUBSET-1M1-of D" and 
      A3: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
      using A1 partfun2_th_35 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
      then have "c inTARSKIR2 Y & c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using xboole_0_def_4 sorry
      then have "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A2 xboole_0_def_4 sorry
      thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using A3 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5"
      using partfun2_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_39:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds X missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  not (X missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    have "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
    proof(rule impI)
      assume A1: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1"
      have " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
      proof-
        let ?d = "the ElementSUBSET-1M1-of D"
        show " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        proof(rule bexI[of _ "d"],rule ballI)
          fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
          show "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
            using A1 sorry
        qed "sorry"
      qed
      thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
        using partfun2_th_35 sorry
    qed
    thus " not (X missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(C)\<^esub> f &  not f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_40:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC =RELSET-1R2\<^bsub>(C,D)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC) -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC be constantFUNCT-1V5"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC =RELSET-1R2\<^bsub>(C,D)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC) -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SC assume [ty]: "SC be SubsetSUBSET-1M2-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC =RELSET-1R2\<^bsub>(C,D)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC) -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d"
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 SC /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume "c inTARSKIR2 SC /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
      then have A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC)"
        using relat_1_th_61 sorry
      then have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using A1 partfun2_th_29 sorry
      thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using A2 partfun2_th_15 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC be constantFUNCT-1V5"
      using partfun2_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_41:
" for x be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
proof-
  have " for x be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    have "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
      proof-
        have cases: "{TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 or {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "{TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
        proof(rule impI)
          assume "{TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1"
          then have "{TARSKIK1 x} missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
             sorry
          thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
            using partfun2_th_39 sorry
        qed
        have case2: "{TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
        proof(rule impI)
          assume A1: "{TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
          let ?y = "the ElementSUBSET-1M1-of {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
          have "?y inTARSKIR2 {TARSKIK1 x} & ?y inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
            using A1 xboole_0_def_4 sorry
          then obtain x1 where 
            [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
            using tarski_def_1 sorry
          have " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
          proof-
            obtain d where 
              [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
               sorry
            show " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
            proof(rule bexI[of _ "d"],rule ballI,rule impI)
              fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
              assume "c inTARSKIR2 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
              then have "c inTARSKIR2 {TARSKIK1 x}"
                using xboole_0_def_4 sorry
              thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
                using tarski_def_1 sorry
            qed "sorry"
          qed
          thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
            using partfun2_th_35 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> {TARSKIK1 x} be constantFUNCT-1V5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_42:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5) & X /\\XBOOLE-0K3 Y meetsXBOOLE-0R5 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y) be constantFUNCT-1V5"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  not (((f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5) &  not X /\\XBOOLE-0K3 Y meetsXBOOLE-0R5 domRELSET-1K1\<^bsub>(C)\<^esub> f) &  not f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y) be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    have "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5 & (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1) implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y) be constantFUNCT-1V5"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A1: "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
        and A2: "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5"
        and A3: "(X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
      obtain d1 where
        [ty]:"d1 be ElementSUBSET-1M1-of D" and 
        A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d1"
        using A1 partfun2_th_35 sorry
      let ?x = "the ElementSUBSET-1M1-of (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
      have A5: "?x inTARSKIR2 X /\\XBOOLE-0K3 Y"
        using A3 xboole_0_def_4 sorry
      have A6: "?x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then obtain x where 
        [ty]:"x be ElementSUBSET-1M1-of C" and xDef:"x = ?x"
         sorry
      have "x inTARSKIR2 Y"
        using A5 xboole_0_def_4 sorry
      then have A7: "x inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A6 xboole_0_def_4 sorry
      obtain d2 where
        [ty]:"d2 be ElementSUBSET-1M1-of D" and 
        A8: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d2"
        using A2 partfun2_th_35 sorry
      have "x inTARSKIR2 X"
        using A5 xboole_0_def_4 sorry
      then have "x inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A6 xboole_0_def_4 sorry
      then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x =XBOOLE-0R4 d1"
        using A4 sorry
      then have A9: "d1 =XBOOLE-0R4 d2"
        using A8 A7 sorry
      have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y)) implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y)).FUNCT-1K1 c =XBOOLE-0R4 d1"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A10: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y))"
        then have A11: "c inTARSKIR2 (X \\/XBOOLE-0K2 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using relat_1_th_61 sorry
        then have A12: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using xboole_0_def_4 sorry
        have A13: "c inTARSKIR2 X \\/XBOOLE-0K2 Y"
          using A11 xboole_0_def_4 sorry
        have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d1"
        proof-
          show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d1"
          proof-
            have cases: "c inTARSKIR2 X or c inTARSKIR2 Y"
              using A13 xboole_0_def_3 sorry
            have case1: "c inTARSKIR2 X implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d1"
            proof(rule impI)
              assume "c inTARSKIR2 X"
              then have "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
                using A12 xboole_0_def_4 sorry
              thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d1"
                using A4 sorry
            qed
            have case2: "c inTARSKIR2 Y implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d1"
            proof(rule impI)
              assume "c inTARSKIR2 Y"
              then have "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
                using A12 xboole_0_def_4 sorry
              thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d1"
                using A8 A9 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        then have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y))/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d1"
          using A11 partfun2_th_16 sorry
        thus "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y)).FUNCT-1K1 c =XBOOLE-0R4 d1"
          using A10 partfun1_def_6 sorry
      qed "sorry"
      thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y) be constantFUNCT-1V5"
        using bexI[of _ "d1"] partfun2_def_1 sorry
    qed
    thus " not (((f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 & f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5) &  not X /\\XBOOLE-0K3 Y meetsXBOOLE-0R5 domRELSET-1K1\<^bsub>(C)\<^esub> f) &  not f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> (X \\/XBOOLE-0K2 Y) be constantFUNCT-1V5)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_43:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5 implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5 implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5"
    then obtain d where
      [ty]:"d be ElementSUBSET-1M1-of D" and 
      A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
      using partfun2_th_35 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y) implies ((f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y).FUNCT-1K1 c =XBOOLE-0R4 d"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y)"
      then have A3: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
        using relat_1_th_61 sorry
      then have A4: "c inTARSKIR2 Y"
        using xboole_0_def_4 sorry
      have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
        using A3 xboole_0_def_4 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K8\<^bsub>(C)\<^esub> X"
        using relat_1_th_61 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using xboole_0_def_4 sorry
      then have "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using A1 sorry
      then have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using A5 partfun2_th_15 sorry
      then have "((f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using A3 partfun2_th_16 sorry
      thus "((f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y).FUNCT-1K1 c =XBOOLE-0R4 d"
        using A2 partfun1_def_6 sorry
    qed "sorry"
    thus "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) |PARTFUN1K2\<^bsub>(C,D)\<^esub> Y be constantFUNCT-1V5"
      using bexI[of _ "d"] partfun2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_44:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for d be ElementSUBSET-1M1-of D holds (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC be constantFUNCT-1V5"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for d be ElementSUBSET-1M1-of D holds (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SC assume [ty]: "SC be SubsetSUBSET-1M2-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC) implies ((SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC).FUNCT-1K1 c =XBOOLE-0R4 d"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ((SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC)"
      then have A2: "c inTARSKIR2 SC /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d)"
        using relat_1_th_61 sorry
      then have "c inTARSKIR2 SC"
        using xboole_0_def_4 sorry
      then have "(SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using partfun2_th_29 sorry
      then have "((SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC)/.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using A2 partfun2_th_16 sorry
      thus "((SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC).FUNCT-1K1 c =XBOOLE-0R4 d"
        using A1 partfun1_def_6 sorry
    qed "sorry"
    thus "(SC -->PARTFUN2K4\<^bsub>(C,D)\<^esub> d) |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC be constantFUNCT-1V5"
      using bexI[of _ "d"] partfun2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_45:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds domRELSET-1K1\<^bsub>(C)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> g & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c) implies f c=RELSET-1R1\<^bsub>(C,D)\<^esub> g"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds domRELSET-1K1\<^bsub>(C)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> g & ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c) implies f c=RELSET-1R1\<^bsub>(C,D)\<^esub> g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "domRELSET-1K1\<^bsub>(C)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      and A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      then obtain x1 where 
        [ty]:"x1 be ElementSUBSET-1M1-of C" and x1Def:"x1 = x"
         sorry
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> x1 =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
        using A2 A3 sorry
      then have "f .FUNCT-1K1 x =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> x1"
        using A3 partfun1_def_6 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A1 A3 partfun1_def_6 sorry
    qed "sorry"
    thus "f c=RELSET-1R1\<^bsub>(C,D)\<^esub> g"
      using A1 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_46:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c iff [TARSKIK4 c,d ] inHIDDENR3 f"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c implies [TARSKIK4 c,d ] inHIDDENR3 f) & ([TARSKIK4 c,d ] inHIDDENR3 f implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c implies [TARSKIK4 c,d ] inHIDDENR3 f"
    proof(rule impMI ,rule impI)
      assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A2: "d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      have "d =XBOOLE-0R4 f .FUNCT-1K1 c"
        using A1 A2 partfun1_def_6 sorry
      thus "[TARSKIK4 c,d ] inHIDDENR3 f"
        using A1 funct_1_th_1 sorry
    qed
    assume "[TARSKIK4 c,d ] inHIDDENR3 f"
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f .FUNCT-1K1 c"
      using funct_1_th_1 sorry
    thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      using partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_47:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for e be ElementSUBSET-1M1-of E holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for s be PartFuncPARTFUN1M1-of(D,E) holds [TARSKIK4 c,e ] inHIDDENR3 s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f implies [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f & [TARSKIK4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c,e ] inHIDDENR3 s"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for e be ElementSUBSET-1M1-of E holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for s be PartFuncPARTFUN1M1-of(D,E) holds [TARSKIK4 c,e ] inHIDDENR3 s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f implies [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f & [TARSKIK4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c,e ] inHIDDENR3 s"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of E"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix s assume [ty]: "s be PartFuncPARTFUN1M1-of(D,E)"
    assume A1: "[TARSKIK4 c,e ] inHIDDENR3 s *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f"
    then have A2: "[TARSKIK4 f .FUNCT-1K1 c,e ] inHIDDENR3 s"
      using grfunc_1_th_4 sorry
    have A3: "[TARSKIK4 c,f .FUNCT-1K1 c ] inHIDDENR3 f"
      using A1 grfunc_1_th_4 sorry
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using funct_1_th_1 sorry
    thus "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f & [TARSKIK4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c,e ] inHIDDENR3 s"
      using A3 A2 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_48:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 c,d ] } implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 c,d ] } implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "f =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 c,d ] }"
    then have "[TARSKIK4 c,d ] inHIDDENR3 f"
      using tarski_def_1 sorry
    then have A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using funct_1_th_1 sorry
    have "f .FUNCT-1K1 c =XBOOLE-0R4 d"
      using A1 grfunc_1_th_6 sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
      using A2 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_49:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {TARSKIK1 c} implies f =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] }"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {TARSKIK1 c} implies f =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {TARSKIK1 c}"
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 c,f .FUNCT-1K1 c ] }"
      using grfunc_1_th_7 tarski_def_1 sorry
    thus "f =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] }"
      using partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_50:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for f1 be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g & c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c & f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for f1 be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g & c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c & f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g"
      and A2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
    have "f1 .FUNCT-1K1 c =XBOOLE-0R4 g .FUNCT-1K1 c"
      using A1 A2 grfunc_1_th_11 sorry
    then have A3: "f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g .FUNCT-1K1 c"
      using A2 partfun1_def_6 sorry
    have A4: "[TARSKIK4 c,f1 .FUNCT-1K1 c ] inHIDDENR3 f1"
      using A2 funct_1_th_1 sorry
    then have "[TARSKIK4 c,f1 .FUNCT-1K1 c ] inHIDDENR3 f"
      using A1 xboole_0_def_4 sorry
    then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using funct_1_th_1 sorry
    have "[TARSKIK4 c,f1 .FUNCT-1K1 c ] inHIDDENR3 g"
      using A1 A4 xboole_0_def_4 sorry
    then have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      using funct_1_th_1 sorry
    have "f1 .FUNCT-1K1 c =XBOOLE-0R4 f .FUNCT-1K1 c"
      using A1 A2 grfunc_1_th_11 sorry
    then have "f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f .FUNCT-1K1 c"
      using A2 partfun1_def_6 sorry
    thus "f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c & f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      using A5 A6 A3 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_51:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for f1 be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g implies f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for f1 be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g implies f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      and A2: "f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g"
    have "[TARSKIK4 c,f .FUNCT-1K1 c ] inHIDDENR3 f"
      using A1 funct_1_th_1 sorry
    then have "[TARSKIK4 c,f .FUNCT-1K1 c ] inHIDDENR3 f1"
      using A2 xboole_0_def_3 sorry
    then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
      using funct_1_th_1 sorry
    have "f1 .FUNCT-1K1 c =XBOOLE-0R4 f .FUNCT-1K1 c"
      using A1 A2 grfunc_1_th_15 sorry
    then have "f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f .FUNCT-1K1 c"
      using A3 partfun1_def_6 sorry
    thus "f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      using A1 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_52:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for f1 be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g & f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g implies f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for f1 be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g & f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g implies f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
      and A2: "f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g"
    have "[TARSKIK4 c,g .FUNCT-1K1 c ] inHIDDENR3 g"
      using A1 funct_1_th_1 sorry
    then have "[TARSKIK4 c,g .FUNCT-1K1 c ] inHIDDENR3 f1"
      using A2 xboole_0_def_3 sorry
    then have A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
      using funct_1_th_1 sorry
    have "f1 .FUNCT-1K1 c =XBOOLE-0R4 g .FUNCT-1K1 c"
      using A1 A2 grfunc_1_th_15 sorry
    then have "f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g .FUNCT-1K1 c"
      using A3 partfun1_def_6 sorry
    thus "f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
      using A1 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_53:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for f1 be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 & f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g implies f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c or f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds  for f1 be PartFuncPARTFUN1M1-of(C,D) holds  for g be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 & f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g implies  not ( not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c &  not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,D)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(C,D)"
    assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
      and A2: "f1 =RELSET-1R2\<^bsub>(C,D)\<^esub> f \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 C,D :])\<^esub> g"
    have "[TARSKIK4 c,f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f1"
      using A1 partfun2_th_46 sorry
    then have A3: "[TARSKIK4 c,f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f or [TARSKIK4 c,f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 g"
      using A2 xboole_0_def_3 sorry
    have " not ( not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c &  not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
    proof-
      show " not ( not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c &  not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
      proof-
        have cases: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f or c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
          using A3 funct_1_th_1 sorry
        have case1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies  not ( not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c &  not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
        proof(rule impI)
          assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          then have "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f"
            using partfun2_th_46 sorry
          then have "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f1"
            using A2 xboole_0_def_3 sorry
          thus " not ( not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c &  not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
            using partfun2_th_46 sorry
        qed
        have case2: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g implies  not ( not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c &  not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
        proof(rule impI)
          assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> g"
          then have "[TARSKIK4 c,g /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 g"
            using partfun2_th_46 sorry
          then have "[TARSKIK4 c,g /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f1"
            using A2 xboole_0_def_3 sorry
          thus " not ( not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c &  not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
            using partfun2_th_46 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c &  not f1 /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_54:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 SC iff [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SC be SubsetSUBSET-1M2-of C holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 SC implies [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC) & ([TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 SC)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SC assume [ty]: "SC be SubsetSUBSET-1M2-of C"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 SC implies [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC"
    proof(rule impMI ,rule impI)
      assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A2: "c inTARSKIR2 SC"
      have "[TARSKIK4 c,f .FUNCT-1K1 c ] inHIDDENR3 f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC"
        using A1 A2 grfunc_1_th_22 sorry
      thus "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC"
        using A1 partfun1_def_6 sorry
    qed
    assume "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC"
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> SC)"
      using funct_1_th_1 sorry
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f /\\SUBSET-1K9\<^bsub>(C)\<^esub> SC"
      using relat_1_th_61 sorry
    thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 SC"
      using xboole_0_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_55:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD iff [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 SD  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD implies [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 SD  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f) & ([TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 SD  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f implies c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SD assume [ty]: "SD be SubsetSUBSET-1M2-of D"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD implies [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 SD  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f"
    proof(rule impMI ,rule impI)
      assume A1: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A2: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD"
      have "f .FUNCT-1K1 c inTARSKIR2 SD"
        using A1 A2 partfun1_def_6 sorry
      then have "[TARSKIK4 c,f .FUNCT-1K1 c ] inHIDDENR3 SD  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f"
        using A1 grfunc_1_th_24 sorry
      thus "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 SD  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f"
        using A1 partfun1_def_6 sorry
    qed
    assume "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 SD  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f"
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (SD  |`PARTFUN2K3\<^bsub>(C,D)\<^esub> f)"
      using funct_1_th_1 sorry
    then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f .FUNCT-1K1 c inTARSKIR2 SD"
      using funct_1_th_54 sorry
    thus "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD"
      using partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_56:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> SD iff [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for SD be SubsetSUBSET-1M2-of D holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> SD implies [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD) & ([TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD implies c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> SD)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix SD assume [ty]: "SD be SubsetSUBSET-1M2-of D"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> SD implies [TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD"
    proof(rule impI)
      assume A1: "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> SD"
      then have A2: "f .FUNCT-1K1 c inTARSKIR2 SD"
        using grfunc_1_th_26 sorry
      have A3: "[TARSKIK4 c,f .FUNCT-1K1 c ] inHIDDENR3 f"
        using A1 grfunc_1_th_26 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using funct_1_th_1 sorry
      thus "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD"
        using A3 A2 partfun1_def_6 sorry
    qed
    assume A4: "[TARSKIK4 c,f /.PARTFUN1K7\<^bsub>(D)\<^esub> c ] inHIDDENR3 f"
      and A5: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> c inTARSKIR2 SD"
    have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using A4 partfun2_th_46 sorry
    thus "c inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> SD"
      using A5 partfun2_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_57:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 iff ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 d)) & (( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d) implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 d)"
    proof(rule impI)
      assume "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
      then obtain d where
        [ty]:"d be ElementSUBSET-1M1-of D" and 
        A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> c =XBOOLE-0R4 d"
        using partfun2_th_35 sorry
      show " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 d"
      proof(rule bexI[of _ "d"],rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A2: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using xboole_0_def_4 sorry
        then have "f .FUNCT-1K1 c =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
          using partfun1_def_6 sorry
        also have "... = d"
          using A1 A2 sorry
        finally show "f .FUNCT-1K1 c =HIDDENR1 d"
           sorry
      qed "sorry"
    qed
    assume Given: " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d"
    then obtain d where
      [ty]:"d be ElementSUBSET-1M1-of D" and 
      A3: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d"
       sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X) implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =HIDDENR1 d"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)"
      then have A5: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using relat_1_th_61 sorry
      then have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using xboole_0_def_4 sorry
      have "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X)/.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        using A4 partfun1_def_6 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> c"
        using A5 partfun2_th_16 sorry
      also have "... = f .FUNCT-1K1 c"
        using A6 partfun1_def_6 sorry
      also have "... = d"
        using A3 A5 sorry
      finally show "(f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X).FUNCT-1K1 c =HIDDENR1 d"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
      using bexI[of _ "d"] partfun2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_58:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 iff ( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c1 =XBOOLE-0R4 f .FUNCT-1K1 c2)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,D) holds (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c1 =XBOOLE-0R4 f .FUNCT-1K1 c2)) & (( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c1 =XBOOLE-0R4 f .FUNCT-1K1 c2) implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    show "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5 implies ( for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c1 =XBOOLE-0R4 f .FUNCT-1K1 c2)"
    proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      assume "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
      then obtain d where
        [ty]:"d be ElementSUBSET-1M1-of D" and 
        A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d"
        using partfun2_th_57 sorry
      fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of C"
      fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of C"
      assume A2: "c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
        and A3: "c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
      have "f .FUNCT-1K1 c1 =XBOOLE-0R4 d"
        using A1 A2 sorry
      thus "f .FUNCT-1K1 c1 =XBOOLE-0R4 f .FUNCT-1K1 c2"
        using A1 A3 sorry
    qed "sorry"
    assume A4: " for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds c1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f & c2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c1 =XBOOLE-0R4 f .FUNCT-1K1 c2"
    have "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
      proof-
        have cases: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 or X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
        proof(rule impI)
          assume A5: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1"
          have " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d"
          proof-
            let ?d = "the ElementSUBSET-1M1-of D"
            show " ex d be ElementSUBSET-1M1-of D st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d"
            proof(rule bexI[of _ "d"],rule ballI)
              fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
              show "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =XBOOLE-0R4 d"
                using A5 sorry
            qed "sorry"
          qed
          thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
            using partfun2_th_57 sorry
        qed
        have case2: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 implies f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
        proof(rule impI)
          assume A6: "X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1"
          let ?x = "the ElementSUBSET-1M1-of X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
          have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (the ElementSUBSET-1M1-of X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f)"
          proof(rule ballI,rule impI)
            fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
            have A7: "?x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
              using A6 xboole_0_def_4 sorry
            assume "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f"
            then have "f .FUNCT-1K1 c =HIDDENR1 f .FUNCT-1K1 (the ElementSUBSET-1M1-of X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f)"
              using A4 A7 sorry
            also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> (the ElementSUBSET-1M1-of X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f)"
              using A7 partfun1_def_6 sorry
            finally show "f .FUNCT-1K1 c =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (the ElementSUBSET-1M1-of X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f)"
               sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
            using partfun2_th_57 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> X be constantFUNCT-1V5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_59:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds d inTARSKIR2 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X implies ( ex c be ElementSUBSET-1M1-of C st (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & c inTARSKIR2 X) & d =XBOOLE-0R4 f .FUNCT-1K1 c)"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds d inTARSKIR2 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X implies ( ex tVar21 be ElementSUBSET-1M1-of C st (tVar21 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & tVar21 inTARSKIR2 X) & d =XBOOLE-0R4 f .FUNCT-1K1 tVar21)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    assume "d inTARSKIR2 f .:RELSET-1K7\<^bsub>(C,D)\<^esub> X"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"and A2: "x inHIDDENR3 X & d =XBOOLE-0R4 f .FUNCT-1K1 x"
      using funct_1_def_6 sorry
    have 
      [ty]:"x be ElementSUBSET-1M1-of C"
      using A1 sorry
    show " ex tVar21 be ElementSUBSET-1M1-of C st (tVar21 inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & tVar21 inTARSKIR2 X) & d =XBOOLE-0R4 f .FUNCT-1K1 tVar21"
    proof(rule bexI[of _ "x"])
      show "(x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & x inTARSKIR2 X) & d =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A1 A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_60:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f be one-to-oneFUNCT-1V2 implies (d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 d iff c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f .FUNCT-1K1 c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for d be ElementSUBSET-1M1-of D holds  for f be PartFuncPARTFUN1M1-of(C,D) holds f be one-to-oneFUNCT-1V2 implies  not ((d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 d) &  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f .FUNCT-1K1 c)) &  not ((c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f .FUNCT-1K1 c) &  not (d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 d))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,D)"
    have A1: "f \<inverse>FUNCT-1K4 =FUNCT-1R1 f \<inverse>FUNCT-1K4"
       sorry
    assume "f be one-to-oneFUNCT-1V2"
    thus " not ((d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 d) &  not (c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f .FUNCT-1K1 c)) &  not ((c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f & d =XBOOLE-0R4 f .FUNCT-1K1 c) &  not (d inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> f & c =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 d))"
      using A1 funct_1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun2_th_61:
" for Y be setHIDDENM2 holds  for f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds  for g be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f /.PARTFUN1K7\<^bsub>(Y)\<^esub> x =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(Y)\<^esub> x)"
proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix f assume [ty]: "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
  fix g assume [ty]: "g be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
  assume A1: "f c=RELAT-1R2 g"
  then have A2: "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
    using grfunc_1_th_2 sorry
  fix x assume [ty]: "x be setHIDDENM2"
  assume A3: "x inTARSKIR2 domRELAT-1K1 f"
  then have "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    using A1 grfunc_1_th_2 sorry
  then have "f /.PARTFUN1K7\<^bsub>(Y)\<^esub> x =XBOOLE-0R4 g .FUNCT-1K1 x"
    using A3 partfun1_def_6 sorry
  thus "f /.PARTFUN1K7\<^bsub>(Y)\<^esub> x =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(Y)\<^esub> x"
    using A2 A3 partfun1_def_6 sorry
qed "sorry"

end
