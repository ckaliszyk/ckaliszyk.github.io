theory finsub_1
  imports finset_1
begin
(*begin*)
reserve X, Y, x for "setHIDDENM2"
mdef finsub_1_def_1 ("cup-closedFINSUB-1V1" 70 ) where
"attr cup-closedFINSUB-1V1 for setHIDDENM2 means
  (\<lambda>IT.  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 IT & Y inTARSKIR2 IT implies X \\/XBOOLE-0K2 Y inTARSKIR2 IT)"..

mdef finsub_1_def_2 ("cap-closedFINSUB-1V2" 70 ) where
"attr cap-closedFINSUB-1V2 for setHIDDENM2 means
  (\<lambda>IT.  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 IT & Y inTARSKIR2 IT implies X /\\XBOOLE-0K3 Y inTARSKIR2 IT)"..

mdef finsub_1_def_3 ("diff-closedFINSUB-1V3" 70 ) where
"attr diff-closedFINSUB-1V3 for setHIDDENM2 means
  (\<lambda>IT.  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 IT & Y inTARSKIR2 IT implies X \\SUBSET-1K6 Y inTARSKIR2 IT)"..

mdef finsub_1_def_4 ("preBooleanFINSUB-1V4" 70 ) where
"attr preBooleanFINSUB-1V4 for setHIDDENM2 means
  (\<lambda>IT. IT be cup-closedFINSUB-1V1\<bar>diff-closedFINSUB-1V3)"..

mtheorem finsub_1_cl_1:
"cluster preBooleanFINSUB-1V4 also-is cup-closedFINSUB-1V1\<bar>diff-closedFINSUB-1V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be preBooleanFINSUB-1V4 implies it be cup-closedFINSUB-1V1\<bar>diff-closedFINSUB-1V3"
     sorry
qed "sorry"

mtheorem finsub_1_cl_2:
"cluster cup-closedFINSUB-1V1\<bar>diff-closedFINSUB-1V3 also-is preBooleanFINSUB-1V4 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be cup-closedFINSUB-1V1\<bar>diff-closedFINSUB-1V3 implies it be preBooleanFINSUB-1V4"
     sorry
qed "sorry"

mtheorem finsub_1_cl_3:
"cluster  non emptyXBOOLE-0V1\<bar>cup-closedFINSUB-1V1\<bar>cap-closedFINSUB-1V2\<bar>diff-closedFINSUB-1V3 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>cup-closedFINSUB-1V1\<bar>cap-closedFINSUB-1V2\<bar>diff-closedFINSUB-1V3"
  proof-
    have " ex tVar1 be setHIDDENM2 st tVar1 be  non emptyXBOOLE-0V1 & (tVar1 be cup-closedFINSUB-1V1 & (tVar1 be cap-closedFINSUB-1V2 & tVar1 be diff-closedFINSUB-1V3))"
    proof-
      show " ex tVar1 be setHIDDENM2 st tVar1 be  non emptyXBOOLE-0V1 & (tVar1 be cup-closedFINSUB-1V1 & (tVar1 be cap-closedFINSUB-1V2 & tVar1 be diff-closedFINSUB-1V3))"
      proof(rule bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 }"],rule conjMI,rule conjMI,rule conjMI)
        show "{TARSKIK1 {}XBOOLE-0K1 } be  non emptyXBOOLE-0V1"
           sorry
        show "{TARSKIK1 {}XBOOLE-0K1 } be cup-closedFINSUB-1V1"
        proof-
          have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } & Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } implies X \\/XBOOLE-0K2 Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix X assume [ty]: "X be setHIDDENM2"
            fix Y assume [ty]: "Y be setHIDDENM2"
            assume A1: "X inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
              and A2: "Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
            have "X =XBOOLE-0R4 {}XBOOLE-0K1"
              using A1 tarski_def_1 sorry
            thus "X \\/XBOOLE-0K2 Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
              using A2 sorry
          qed "sorry"
          thus "{TARSKIK1 {}XBOOLE-0K1 } be cup-closedFINSUB-1V1"
            using finsub_1_def_1 sorry
        qed
        show "{TARSKIK1 {}XBOOLE-0K1 } be cap-closedFINSUB-1V2"
        proof-
          have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } & Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } implies X /\\XBOOLE-0K3 Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix X assume [ty]: "X be setHIDDENM2"
            fix Y assume [ty]: "Y be setHIDDENM2"
            assume A3: "X inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
              and "Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
            have "X =XBOOLE-0R4 {}XBOOLE-0K1"
              using A3 tarski_def_1 sorry
            thus "X /\\XBOOLE-0K3 Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
              using tarski_def_1 sorry
          qed "sorry"
          thus "{TARSKIK1 {}XBOOLE-0K1 } be cap-closedFINSUB-1V2"
            using finsub_1_def_2 sorry
        qed
        show "{TARSKIK1 {}XBOOLE-0K1 } be diff-closedFINSUB-1V3"
        proof-
          have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } & Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } implies X \\SUBSET-1K6 Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix X assume [ty]: "X be setHIDDENM2"
            fix Y assume [ty]: "Y be setHIDDENM2"
            assume A4: "X inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
              and "Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
            have "X =XBOOLE-0R4 {}XBOOLE-0K1"
              using A4 tarski_def_1 sorry
            thus "X \\SUBSET-1K6 Y inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
              using tarski_def_1 sorry
          qed "sorry"
          thus "{TARSKIK1 {}XBOOLE-0K1 } be diff-closedFINSUB-1V3"
            using finsub_1_def_3 sorry
        qed
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finsub_1_th_1:
" for A be setHIDDENM2 holds A be preBooleanFINSUB-1V4 iff ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 A & Y inTARSKIR2 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A)"
proof-
  have " for A be setHIDDENM2 holds (A be preBooleanFINSUB-1V4 implies ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 A & Y inTARSKIR2 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A)) & (( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 A & Y inTARSKIR2 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A) implies A be preBooleanFINSUB-1V4)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    show "A be preBooleanFINSUB-1V4 implies ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 A & Y inTARSKIR2 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A)"
      using finsub_1_def_1 finsub_1_def_3 sorry
    assume A1: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 A & Y inTARSKIR2 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A"
    have A2: "A be diff-closedFINSUB-1V3"
      using A1 sorry
    have "A be cup-closedFINSUB-1V1"
      using A1 sorry
    thus "A be preBooleanFINSUB-1V4"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve A for " non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2"
syntax FINSUB_1K1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\'/FINSUB-1K1\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "X \\/FINSUB-1K1\<^bsub>(A)\<^esub> Y" \<rightharpoonup> "X \\/XBOOLE-0K2 Y"

mtheorem finsub_1_add_1:
  mlet "A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2", "X be ElementSUBSET-1M1-of A", "Y be ElementSUBSET-1M1-of A"
"cluster X \\/XBOOLE-0K2 Y as-term-is ElementSUBSET-1M1-of A"
proof
(*coherence*)
  show "X \\/XBOOLE-0K2 Y be ElementSUBSET-1M1-of A"
    using finsub_1_th_1 sorry
qed "sorry"

syntax FINSUB_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\FINSUB-1K2\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "X \\FINSUB-1K2\<^bsub>(A)\<^esub> Y" \<rightharpoonup> "X \\XBOOLE-0K4 Y"

mtheorem finsub_1_add_2:
  mlet "A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2", "X be ElementSUBSET-1M1-of A", "Y be ElementSUBSET-1M1-of A"
"cluster X \\XBOOLE-0K4 Y as-term-is ElementSUBSET-1M1-of A"
proof
(*coherence*)
  show "X \\XBOOLE-0K4 Y be ElementSUBSET-1M1-of A"
    using finsub_1_th_1 sorry
qed "sorry"

mtheorem finsub_1_th_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds X be ElementSUBSET-1M1-of A & Y be ElementSUBSET-1M1-of A implies X /\\XBOOLE-0K3 Y be ElementSUBSET-1M1-of A"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds X be ElementSUBSET-1M1-of A & Y be ElementSUBSET-1M1-of A implies X /\\XBOOLE-0K3 Y be ElementSUBSET-1M1-of A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2"
    assume "X be ElementSUBSET-1M1-of A & Y be ElementSUBSET-1M1-of A"
    then have 
      [ty]:"X be ElementSUBSET-1M1-of A" and
      [ty]:"Y be ElementSUBSET-1M1-of A"
       sorry
    have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X \\FINSUB-1K2\<^bsub>(A)\<^esub> (X \\FINSUB-1K2\<^bsub>(A)\<^esub> Y)"
      using xboole_1_th_48 sorry
    thus "X /\\XBOOLE-0K3 Y be ElementSUBSET-1M1-of A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finsub_1_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds X be ElementSUBSET-1M1-of A & Y be ElementSUBSET-1M1-of A implies X \\+\\XBOOLE-0K5 Y be ElementSUBSET-1M1-of A"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds X be ElementSUBSET-1M1-of A & Y be ElementSUBSET-1M1-of A implies X \\+\\XBOOLE-0K5 Y be ElementSUBSET-1M1-of A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2"
    assume "X be ElementSUBSET-1M1-of A & Y be ElementSUBSET-1M1-of A"
    then have 
      [ty]:"X be ElementSUBSET-1M1-of A" and
      [ty]:"Y be ElementSUBSET-1M1-of A"
       sorry
    have "X \\+\\XBOOLE-0K5 Y =XBOOLE-0R4 (X \\FINSUB-1K2\<^bsub>(A)\<^esub> Y)\\/FINSUB-1K1\<^bsub>(A)\<^esub> (Y \\FINSUB-1K2\<^bsub>(A)\<^esub> X)"
       sorry
    thus "X \\+\\XBOOLE-0K5 Y be ElementSUBSET-1M1-of A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finsub_1_th_4:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for X be ElementSUBSET-1M1-of A holds  for Y be ElementSUBSET-1M1-of A holds X \\+\\XBOOLE-0K5 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A) implies A be preBooleanFINSUB-1V4"
proof(rule ballI,rule impI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  assume A1: " for X be ElementSUBSET-1M1-of A holds  for Y be ElementSUBSET-1M1-of A holds X \\+\\XBOOLE-0K5 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A"
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 A & Y inTARSKIR2 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A2: "X inTARSKIR2 A"
      and A3: "Y inTARSKIR2 A"
    obtain Z where 
      [ty]:"Z be ElementSUBSET-1M1-of A" and ZDef:"Z = Y \\SUBSET-1K6 X"
      using A1 A2 A3 sorry
    have "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 Z"
      using xboole_1_th_98 sorry
    thus "X \\/XBOOLE-0K2 Y inTARSKIR2 A"
      using A1 A2 sorry
    show "X \\SUBSET-1K6 Y inTARSKIR2 A"
      using A1 A2 A3 sorry
  qed "sorry"
  thus "A be preBooleanFINSUB-1V4"
    using finsub_1_th_1 sorry
qed "sorry"

mtheorem finsub_1_th_5:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for X be ElementSUBSET-1M1-of A holds  for Y be ElementSUBSET-1M1-of A holds X \\+\\XBOOLE-0K5 Y inTARSKIR2 A & X /\\XBOOLE-0K3 Y inTARSKIR2 A) implies A be preBooleanFINSUB-1V4"
proof(rule ballI,rule impI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  assume A1: " for X be ElementSUBSET-1M1-of A holds  for Y be ElementSUBSET-1M1-of A holds X \\+\\XBOOLE-0K5 Y inTARSKIR2 A & X /\\XBOOLE-0K3 Y inTARSKIR2 A"
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 A & Y inTARSKIR2 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A2: "X inTARSKIR2 A"
      and A3: "Y inTARSKIR2 A"
    obtain Z1 Z2 where 
      [ty]:"Z1 be ElementSUBSET-1M1-of A" and Z1Def:"Z1 = X \\+\\XBOOLE-0K5 Y" and
      [ty]:"Z2 be ElementSUBSET-1M1-of A" and Z2Def:"Z2 = X /\\XBOOLE-0K3 Y"
      using A1 A2 A3 sorry
    have "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Z1 \\+\\XBOOLE-0K5 Z2"
      using xboole_1_th_94 sorry
    thus "X \\/XBOOLE-0K2 Y inTARSKIR2 A"
      using A1 sorry
    have "X \\SUBSET-1K6 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 Z2"
      using xboole_1_th_100 sorry
    thus "X \\SUBSET-1K6 Y inTARSKIR2 A"
      using A1 A2 sorry
  qed "sorry"
  thus "A be preBooleanFINSUB-1V4"
    using finsub_1_th_1 sorry
qed "sorry"

mtheorem finsub_1_th_6:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for X be ElementSUBSET-1M1-of A holds  for Y be ElementSUBSET-1M1-of A holds X \\+\\XBOOLE-0K5 Y inTARSKIR2 A & X \\/XBOOLE-0K2 Y inTARSKIR2 A) implies A be preBooleanFINSUB-1V4"
proof(rule ballI,rule impI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  assume A1: " for X be ElementSUBSET-1M1-of A holds  for Y be ElementSUBSET-1M1-of A holds X \\+\\XBOOLE-0K5 Y inTARSKIR2 A & X \\/XBOOLE-0K2 Y inTARSKIR2 A"
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 A & Y inTARSKIR2 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 A & X \\SUBSET-1K6 Y inTARSKIR2 A"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A2: "X inTARSKIR2 A"
      and A3: "Y inTARSKIR2 A"
    show "X \\/XBOOLE-0K2 Y inTARSKIR2 A"
      using A1 A2 A3 sorry
    obtain Z1 Z2 where 
      [ty]:"Z1 be ElementSUBSET-1M1-of A" and Z1Def:"Z1 = X \\+\\XBOOLE-0K5 Y" and
      [ty]:"Z2 be ElementSUBSET-1M1-of A" and Z2Def:"Z2 = X \\/XBOOLE-0K2 Y"
      using A1 A2 A3 sorry
    have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 Z1 \\+\\XBOOLE-0K5 Z2"
      using xboole_1_th_95 sorry
    then obtain Z where 
      [ty]:"Z be ElementSUBSET-1M1-of A" and ZDef:"Z = X /\\XBOOLE-0K3 Y"
      using A1 sorry
    have "X \\SUBSET-1K6 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 Z"
      using xboole_1_th_100 sorry
    thus "X \\SUBSET-1K6 Y inTARSKIR2 A"
      using A1 A2 sorry
  qed "sorry"
  thus "A be preBooleanFINSUB-1V4"
    using finsub_1_th_1 sorry
qed "sorry"

syntax FINSUB_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/'\\FINSUB-1K3\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "X /\\FINSUB-1K3\<^bsub>(A)\<^esub> Y" \<rightharpoonup> "X /\\XBOOLE-0K3 Y"

mtheorem finsub_1_add_3:
  mlet "A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2", "X be ElementSUBSET-1M1-of A", "Y be ElementSUBSET-1M1-of A"
"cluster X /\\XBOOLE-0K3 Y as-term-is ElementSUBSET-1M1-of A"
proof
(*coherence*)
  show "X /\\XBOOLE-0K3 Y be ElementSUBSET-1M1-of A"
    using finsub_1_th_2 sorry
qed "sorry"

syntax FINSUB_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\+'\\FINSUB-1K4\<^bsub>'( _ ')\<^esub>  _ " [130,0,130]130)
translations "X \\+\\FINSUB-1K4\<^bsub>(A)\<^esub> Y" \<rightharpoonup> "X \\+\\XBOOLE-0K5 Y"

mtheorem finsub_1_add_4:
  mlet "A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2", "X be ElementSUBSET-1M1-of A", "Y be ElementSUBSET-1M1-of A"
"cluster X \\+\\XBOOLE-0K5 Y as-term-is ElementSUBSET-1M1-of A"
proof
(*coherence*)
  show "X \\+\\XBOOLE-0K5 Y be ElementSUBSET-1M1-of A"
    using finsub_1_th_3 sorry
qed "sorry"

mtheorem finsub_1_th_7:
" for A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 A"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 A"
  proof(rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2"
    let ?x = "the ElementSUBSET-1M1-of A"
    have "?x \\FINSUB-1K2\<^bsub>(A)\<^esub> ?x =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_1_th_37 sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finsub_1_th_8:
" for A be setHIDDENM2 holds boolZFMISC-1K1 A be preBooleanFINSUB-1V4"
proof(rule ballI)
  fix A assume [ty]: "A be setHIDDENM2"
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 boolZFMISC-1K1 A & Y inTARSKIR2 boolZFMISC-1K1 A implies X \\/XBOOLE-0K2 Y inTARSKIR2 boolZFMISC-1K1 A & X \\SUBSET-1K6 Y inTARSKIR2 boolZFMISC-1K1 A"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X inTARSKIR2 boolZFMISC-1K1 A & Y inTARSKIR2 boolZFMISC-1K1 A"
    then obtain X9 Y9 where 
      [ty]:"X9 be SubsetSUBSET-1M2-of A" and X9Def:"X9 = X" and
      [ty]:"Y9 be SubsetSUBSET-1M2-of A" and Y9Def:"Y9 = Y"
       sorry
    have "X9 \\/SUBSET-1K4\<^bsub>(A)\<^esub> Y9 inTARSKIR2 boolZFMISC-1K1 A & X9 \\SUBSET-1K7\<^bsub>(A)\<^esub> Y9 inTARSKIR2 boolZFMISC-1K1 A"
       sorry
    thus "X \\/XBOOLE-0K2 Y inTARSKIR2 boolZFMISC-1K1 A & X \\SUBSET-1K6 Y inTARSKIR2 boolZFMISC-1K1 A"
       sorry
  qed "sorry"
  thus "boolZFMISC-1K1 A be preBooleanFINSUB-1V4"
    using finsub_1_th_1 sorry
qed "sorry"

mtheorem finsub_1_cl_4:
  mlet "A be setHIDDENM2"
"cluster boolZFMISC-1K1 A as-term-is preBooleanFINSUB-1V4"
proof
(*coherence*)
  show "boolZFMISC-1K1 A be preBooleanFINSUB-1V4"
    using finsub_1_th_8 sorry
qed "sorry"

mtheorem finsub_1_th_9:
" for A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds A /\\XBOOLE-0K3 B be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds  not A /\\XBOOLE-0K3 B be emptyXBOOLE-0V1 & A /\\XBOOLE-0K3 B be preBooleanFINSUB-1V4"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2"
    have "{}XBOOLE-0K1 inTARSKIR2 A & {}XBOOLE-0K1 inTARSKIR2 B"
      using finsub_1_th_7 sorry
    then obtain C where 
      [ty]:"C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and CDef:"C = A /\\XBOOLE-0K3 B"
      using xboole_0_def_4 sorry
    have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 C & Y inTARSKIR2 C implies X \\/XBOOLE-0K2 Y inTARSKIR2 C & X \\SUBSET-1K6 Y inTARSKIR2 C"
    proof(rule ballI,rule ballI,rule impI,rule conjMI)
      fix X assume [ty]: "X be setHIDDENM2"
      fix Y assume [ty]: "Y be setHIDDENM2"
      assume A1: "X inTARSKIR2 C & Y inTARSKIR2 C"
      then have A2: "X inTARSKIR2 B & Y inTARSKIR2 B"
        using xboole_0_def_4 sorry
      then have A3: "X \\/XBOOLE-0K2 Y inTARSKIR2 B"
        using finsub_1_th_1 sorry
      have A4: "X \\SUBSET-1K6 Y inTARSKIR2 B"
        using A2 finsub_1_th_1 sorry
      have A5: "X inTARSKIR2 A & Y inTARSKIR2 A"
        using A1 xboole_0_def_4 sorry
      then have "X \\/XBOOLE-0K2 Y inTARSKIR2 A"
        using finsub_1_th_1 sorry
      thus "X \\/XBOOLE-0K2 Y inTARSKIR2 C"
        using A3 xboole_0_def_4 sorry
      have "X \\SUBSET-1K6 Y inTARSKIR2 A"
        using A5 finsub_1_th_1 sorry
      thus "X \\SUBSET-1K6 Y inTARSKIR2 C"
        using A4 xboole_0_def_4 sorry
    qed "sorry"
    thus " not A /\\XBOOLE-0K3 B be emptyXBOOLE-0V1 & A /\\XBOOLE-0K3 B be preBooleanFINSUB-1V4"
      using finsub_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finsub_1_def_5 ("FinFINSUB-1K5  _ " [228]228 ) where
  mlet "A be setHIDDENM2"
"func FinFINSUB-1K5 A \<rightarrow> preBooleanFINSUB-1V4\<bar>setHIDDENM2 means
  \<lambda>it.  for X be setHIDDENM2 holds X inTARSKIR2 it iff X c=TARSKIR1 A & X be finiteFINSET-1V1"
proof-
  (*existence*)
    show " ex it be preBooleanFINSUB-1V4\<bar>setHIDDENM2 st  for X be setHIDDENM2 holds X inTARSKIR2 it iff X c=TARSKIR1 A & X be finiteFINSET-1V1"
    proof-
      have " not ( for VarFor1 be preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds  not ( for X be setHIDDENM2 holds  not (X inTARSKIR2 VarFor1 &  not (X c=TARSKIR1 A & X be finiteFINSET-1V1)) &  not ((X c=TARSKIR1 A & X be finiteFINSET-1V1) &  not X inTARSKIR2 VarFor1)))"
      proof-
        let ?P = "\<lambda>Lamb1.  ex y be setHIDDENM2 st (y =HIDDENR1 Lamb1 & y c=TARSKIR1 A) & y be finiteFINSET-1V1"
        obtain P where
          [ty]:"P be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 P iff x inHIDDENR3 boolZFMISC-1K1 A & ?P(x)"
          using xboole_0_sch_1 sorry
        have "{}XBOOLE-0K1 c=TARSKIR1 A"
           sorry
        then obtain Q where 
          [ty]:"Q be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and QDef:"Q = P"
          using A1 sorry
        have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Q & Y inTARSKIR2 Q implies X \\/XBOOLE-0K2 Y inTARSKIR2 Q & X \\SUBSET-1K6 Y inTARSKIR2 Q"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix X assume [ty]: "X be setHIDDENM2"
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume A2: "X inTARSKIR2 Q"
            and A3: "Y inTARSKIR2 Q"
          obtain Z1 where
            [ty]:"Z1 be setHIDDENM2" and 
            A4: "Z1 =XBOOLE-0R4 X"and A5: "Z1 c=TARSKIR1 A"and A6: "Z1 be finiteFINSET-1V1"
            using A1 A2 sorry
          obtain Z2 where
            [ty]:"Z2 be setHIDDENM2" and 
            A7: "Z2 =XBOOLE-0R4 Y"and A8: "Z2 c=TARSKIR1 A"and A9: "Z2 be finiteFINSET-1V1"
            using A1 A3 sorry
          have A10: "Z1 \\SUBSET-1K6 Z2 c=TARSKIR1 A"
            using A5 sorry
          have "Z1 \\/XBOOLE-0K2 Z2 c=TARSKIR1 A"
            using A5 A8 xboole_1_th_8 sorry
          thus "X \\/XBOOLE-0K2 Y inTARSKIR2 Q & X \\SUBSET-1K6 Y inTARSKIR2 Q"
            using A1 A4 A6 A7 A9 A10 sorry
        qed "sorry"
        then obtain R where 
          [ty]:"R be  non emptyXBOOLE-0V1\<bar>preBooleanFINSUB-1V4\<bar>setHIDDENM2" and RDef:"R = Q"
          using finsub_1_th_1 sorry
        have " for X be setHIDDENM2 holds X inTARSKIR2 R iff X c=TARSKIR1 A & X be finiteFINSET-1V1"
        proof-
          have " for X be setHIDDENM2 holds (X inTARSKIR2 R implies X c=TARSKIR1 A & X be finiteFINSET-1V1) &  not ((X c=TARSKIR1 A & X be finiteFINSET-1V1) &  not X inTARSKIR2 R)"
          proof(rule ballI,rule conjMI)
            fix X assume [ty]: "X be setHIDDENM2"
            show "X inTARSKIR2 R implies X c=TARSKIR1 A & X be finiteFINSET-1V1"
            proof(rule impI)
              assume "X inTARSKIR2 R"
              then have " ex Y be setHIDDENM2 st (Y =XBOOLE-0R4 X & Y c=TARSKIR1 A) & Y be finiteFINSET-1V1"
                using A1 sorry
              thus "X c=TARSKIR1 A & X be finiteFINSET-1V1"
                 sorry
            qed
            show " not ((X c=TARSKIR1 A & X be finiteFINSET-1V1) &  not X inTARSKIR2 R)"
              using A1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " not ( for VarFor1 be preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds  not ( for X be setHIDDENM2 holds  not (X inTARSKIR2 VarFor1 &  not (X c=TARSKIR1 A & X be finiteFINSET-1V1)) &  not ((X c=TARSKIR1 A & X be finiteFINSET-1V1) &  not X inTARSKIR2 VarFor1)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds  for it2 be preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 it1 iff X c=TARSKIR1 A & X be finiteFINSET-1V1) & ( for X be setHIDDENM2 holds X inTARSKIR2 it2 iff X c=TARSKIR1 A & X be finiteFINSET-1V1) implies it1 =HIDDENR1 it2"
    proof-
      have " for P be preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds  for Q be preBooleanFINSUB-1V4\<bar>setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 P iff X c=TARSKIR1 A & X be finiteFINSET-1V1) & ( for X be setHIDDENM2 holds X inTARSKIR2 Q iff X c=TARSKIR1 A & X be finiteFINSET-1V1) implies P =HIDDENR1 Q"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix P assume [ty]: "P be preBooleanFINSUB-1V4\<bar>setHIDDENM2"
        fix Q assume [ty]: "Q be preBooleanFINSUB-1V4\<bar>setHIDDENM2"
        assume A11: " for X be setHIDDENM2 holds X inTARSKIR2 P iff X c=TARSKIR1 A & X be finiteFINSET-1V1"
          and A12: " for X be setHIDDENM2 holds X inTARSKIR2 Q iff X c=TARSKIR1 A & X be finiteFINSET-1V1"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 P iff x inHIDDENR3 Q"
        proof-
          have " for x be objectHIDDENM1 holds (x inHIDDENR3 P implies x inHIDDENR3 Q) & (x inHIDDENR3 Q implies x inHIDDENR3 P)"
          proof(rule ballI,rule conjMI)
            fix x assume [ty]: "x be objectHIDDENM1"
            obtain xx where 
              [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
              using tarski_th_1 sorry
            show "x inHIDDENR3 P implies x inHIDDENR3 Q"
            proof(rule impI)
              assume "x inHIDDENR3 P"
              then have "xx c=TARSKIR1 A & xx be finiteFINSET-1V1"
                using A11 sorry
              thus "x inHIDDENR3 Q"
                using A12 sorry
            qed
            show "x inHIDDENR3 Q implies x inHIDDENR3 P"
            proof(rule impI)
              assume "x inHIDDENR3 Q"
              then have "xx c=TARSKIR1 A & xx be finiteFINSET-1V1"
                using A12 sorry
              thus "x inHIDDENR3 P"
                using A11 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "P =HIDDENR1 Q"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem finsub_1_cl_5:
  mlet "A be setHIDDENM2"
"cluster FinFINSUB-1K5 A as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "FinFINSUB-1K5 A be  non emptyXBOOLE-0V1"
  proof-
    have " not FinFINSUB-1K5 A be emptyXBOOLE-0V1"
    proof-
      have "{}XBOOLE-0K1 c=TARSKIR1 A"
         sorry
      thus " not FinFINSUB-1K5 A be emptyXBOOLE-0V1"
        using finsub_1_def_5 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finsub_1_cl_6:
  mlet "A be setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for ElementSUBSET-1M1-of FinFINSUB-1K5 A"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds it be finiteFINSET-1V1"
    using finsub_1_def_5 sorry
qed "sorry"

mtheorem finsub_1_th_10:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A c=TARSKIR1 B implies FinFINSUB-1K5 A c=TARSKIR1 FinFINSUB-1K5 B"
proof(rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  assume A1: "A c=TARSKIR1 B"
  have " for X be objectHIDDENM1 holds X inHIDDENR3 FinFINSUB-1K5 A implies X inHIDDENR3 FinFINSUB-1K5 B"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be objectHIDDENM1"
    obtain XX where 
      [ty]:"XX be setHIDDENM2" and XXDef:"XX = X"
      using tarski_th_1 sorry
    assume A2: "X inHIDDENR3 FinFINSUB-1K5 A"
    then have "XX c=TARSKIR1 A"
      using finsub_1_def_5 sorry
    then have "XX c=TARSKIR1 B"
      using A1 sorry
    thus "X inHIDDENR3 FinFINSUB-1K5 B"
      using A2 finsub_1_def_5 sorry
  qed "sorry"
  thus "FinFINSUB-1K5 A c=TARSKIR1 FinFINSUB-1K5 B"
    using tarski_def_3 sorry
qed "sorry"

mtheorem finsub_1_th_11:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds FinFINSUB-1K5 (A /\\XBOOLE-0K3 B) =XBOOLE-0R4 FinFINSUB-1K5 A /\\XBOOLE-0K3 FinFINSUB-1K5 B"
proof(rule ballI,rule ballI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  have Cut369: "FinFINSUB-1K5 (A /\\XBOOLE-0K3 B) c=TARSKIR1 FinFINSUB-1K5 A & FinFINSUB-1K5 (A /\\XBOOLE-0K3 B) c=TARSKIR1 FinFINSUB-1K5 B"
    using finsub_1_th_10 xboole_1_th_17 sorry
  have "FinFINSUB-1K5 (A /\\XBOOLE-0K3 B) c=TARSKIR1 FinFINSUB-1K5 A /\\XBOOLE-0K3 FinFINSUB-1K5 B & FinFINSUB-1K5 A /\\XBOOLE-0K3 FinFINSUB-1K5 B c=TARSKIR1 FinFINSUB-1K5 (A /\\XBOOLE-0K3 B)"
  proof(rule conjMI)
    show "FinFINSUB-1K5 (A /\\XBOOLE-0K3 B) c=TARSKIR1 FinFINSUB-1K5 A /\\XBOOLE-0K3 FinFINSUB-1K5 B"
      using xboole_1_th_19 Cut369 sorry
    have " for X be objectHIDDENM1 holds X inHIDDENR3 FinFINSUB-1K5 A /\\XBOOLE-0K3 FinFINSUB-1K5 B implies X inHIDDENR3 FinFINSUB-1K5 (A /\\XBOOLE-0K3 B)"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be objectHIDDENM1"
      obtain XX where 
        [ty]:"XX be setHIDDENM2" and XXDef:"XX = X"
        using tarski_th_1 sorry
      assume A1: "X inHIDDENR3 FinFINSUB-1K5 A /\\XBOOLE-0K3 FinFINSUB-1K5 B"
      then have "X inHIDDENR3 FinFINSUB-1K5 B"
        using xboole_0_def_4 sorry
      then have A2: "XX c=TARSKIR1 B"
        using finsub_1_def_5 sorry
      have A3: "X inHIDDENR3 FinFINSUB-1K5 A"
        using A1 xboole_0_def_4 sorry
      then have "XX c=TARSKIR1 A"
        using finsub_1_def_5 sorry
      then have "XX c=TARSKIR1 A /\\XBOOLE-0K3 B"
        using A2 xboole_1_th_19 sorry
      thus "X inHIDDENR3 FinFINSUB-1K5 (A /\\XBOOLE-0K3 B)"
        using A3 finsub_1_def_5 sorry
    qed "sorry"
    thus "FinFINSUB-1K5 A /\\XBOOLE-0K3 FinFINSUB-1K5 B c=TARSKIR1 FinFINSUB-1K5 (A /\\XBOOLE-0K3 B)"
      using tarski_def_3 sorry
  qed
  thus "FinFINSUB-1K5 (A /\\XBOOLE-0K3 B) =XBOOLE-0R4 FinFINSUB-1K5 A /\\XBOOLE-0K3 FinFINSUB-1K5 B"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem finsub_1_th_12:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds FinFINSUB-1K5 A \\/XBOOLE-0K2 FinFINSUB-1K5 B c=TARSKIR1 FinFINSUB-1K5 (A \\/XBOOLE-0K2 B)"
proof(rule ballI,rule ballI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  have "FinFINSUB-1K5 A c=TARSKIR1 FinFINSUB-1K5 (A \\/XBOOLE-0K2 B) & FinFINSUB-1K5 B c=TARSKIR1 FinFINSUB-1K5 (A \\/XBOOLE-0K2 B)"
    using finsub_1_th_10 xboole_1_th_7 sorry
  thus "FinFINSUB-1K5 A \\/XBOOLE-0K2 FinFINSUB-1K5 B c=TARSKIR1 FinFINSUB-1K5 (A \\/XBOOLE-0K2 B)"
    using xboole_1_th_8 sorry
qed "sorry"

mtheorem finsub_1_th_13:
" for A be setHIDDENM2 holds FinFINSUB-1K5 A c=TARSKIR1 boolZFMISC-1K1 A"
proof(rule ballI)
  fix A assume [ty]: "A be setHIDDENM2"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 FinFINSUB-1K5 A implies x inHIDDENR3 boolZFMISC-1K1 A"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    obtain xx where 
      [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
      using tarski_th_1 sorry
    assume "x inHIDDENR3 FinFINSUB-1K5 A"
    then have "xx c=TARSKIR1 A"
      using finsub_1_def_5 sorry
    thus "x inHIDDENR3 boolZFMISC-1K1 A"
       sorry
  qed "sorry"
  thus "FinFINSUB-1K5 A c=TARSKIR1 boolZFMISC-1K1 A"
    using tarski_def_3 sorry
qed "sorry"

mtheorem finsub_1_th_14:
" for A be setHIDDENM2 holds A be finiteFINSET-1V1 implies FinFINSUB-1K5 A =XBOOLE-0R4 boolZFMISC-1K1 A"
proof(rule ballI,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  assume A1: "A be finiteFINSET-1V1"
  have A2: "boolZFMISC-1K1 A c=TARSKIR1 FinFINSUB-1K5 A"
    using A1 finsub_1_def_5 sorry
  have "FinFINSUB-1K5 A c=TARSKIR1 boolZFMISC-1K1 A"
    using finsub_1_th_13 sorry
  thus "FinFINSUB-1K5 A =XBOOLE-0R4 boolZFMISC-1K1 A"
    using A2 sorry
qed "sorry"

mtheorem finsub_1_th_15:
"FinFINSUB-1K5 ({}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  using finsub_1_th_14 zfmisc_1_th_1 sorry

mtheorem finsub_1_th_16:
" for A be setHIDDENM2 holds  for X be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds X be SubsetSUBSET-1M2-of A"
  using finsub_1_def_5 sorry

mtheorem finsub_1_th_17:
" for A be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds A be finiteFINSET-1V1 implies X be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
  using finsub_1_def_5 sorry

end
