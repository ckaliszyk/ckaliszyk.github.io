theory ordinal3
  imports ordinal2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve fi, psi for "Ordinal-SequenceORDINAL2M1"
reserve A, A1, B, C, D for "OrdinalORDINAL1M3"
reserve X, Y for "setHIDDENM2"
reserve x, y for "objectHIDDENM1"
mtheorem ordinal3_th_1:
" for X be setHIDDENM2 holds X c=TARSKIR1 succORDINAL1K1 X"
  using xboole_1_th_7 sorry

mtheorem ordinal3_th_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds succORDINAL1K1 X c=TARSKIR1 Y implies X c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (succORDINAL1K1 X c=TARSKIR1 Y &  not X c=TARSKIR1 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X c=TARSKIR1 succORDINAL1K1 X"
      using xboole_1_th_7 sorry
    thus " not (succORDINAL1K1 X c=TARSKIR1 Y &  not X c=TARSKIR1 Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_3:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B iff succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 B &  not succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 B) &  not (succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 B &  not A inTARSKIR2 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "A inTARSKIR2 B iff succORDINAL1K1 A c=ORDINAL1R1 B"
      using ordinal1_th_21 sorry
    thus " not (A inTARSKIR2 B &  not succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 B) &  not (succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 B &  not A inTARSKIR2 B)"
      using ordinal1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_4:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies unionTARSKIK3 X be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies unionTARSKIK3 X be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X c=TARSKIR1 A"
    then have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be OrdinalORDINAL1M3"
       sorry
    thus "unionTARSKIK3 X be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2"
      using ordinal1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_5:
" for X be setHIDDENM2 holds unionTARSKIK3 (OnORDINAL1K2 X) be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2"
proof-
  have " for X be setHIDDENM2 holds unionTARSKIK3 (OnORDINAL1K2 X) be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 X implies x be OrdinalORDINAL1M3"
      using ordinal1_def_9 sorry
    thus "unionTARSKIK3 (OnORDINAL1K2 X) be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2"
      using ordinal1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_6:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies OnORDINAL1K2 X =XBOOLE-0R4 X"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies OnORDINAL1K2 X =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 X & Lamb1 be OrdinalORDINAL1M3"
    assume "X c=TARSKIR1 A"
    then have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff ?P(x)"
       sorry
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 X iff ?P(x)"
      using ordinal1_def_9 sorry
    show "OnORDINAL1K2 X =XBOOLE-0R4 X"
      using xboole_0_sch_2 A2 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_7:
" for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 {TARSKIK1 A} =XBOOLE-0R4 {TARSKIK1 A}"
proof-
  have " for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 {TARSKIK1 A} =XBOOLE-0R4 {TARSKIK1 A}"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "{TARSKIK1 A} c=TARSKIR1 succORDINAL1K1 A"
      using xboole_1_th_7 sorry
    thus "OnORDINAL1K2 {TARSKIK1 A} =XBOOLE-0R4 {TARSKIK1 A}"
      using ordinal3_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_8:
" for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 implies {}XBOOLE-0K1 inTARSKIR2 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 implies {}XBOOLE-0K1 inTARSKIR2 A"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have A1: "{}XBOOLE-0K1 c=ORDINAL1R1 A"
       sorry
    assume "A <>HIDDENR2 {}XBOOLE-0K1"
    then have "{}XBOOLE-0K1 c<XBOOLE-0R2 A"
      using A1 sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 A"
      using ordinal1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_9:
" for A be OrdinalORDINAL1M3 holds infORDINAL2K2 A =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be OrdinalORDINAL1M3 holds infORDINAL2K2 A =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have A1: "infORDINAL2K2 A =XBOOLE-0R4 meetSETFAM-1K1 A"
      using ordinal2_th_8 sorry
    then have "A <>HIDDENR2 {}XBOOLE-0K1 implies infORDINAL2K2 A =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal3_th_8 setfam_1_th_4 sorry
    thus "infORDINAL2K2 A =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 setfam_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_10:
" for A be OrdinalORDINAL1M3 holds infORDINAL2K2 {TARSKIK1 A} =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds infORDINAL2K2 {TARSKIK1 A} =HIDDENR1 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "infORDINAL2K2 {TARSKIK1 A} =HIDDENR1 meetSETFAM-1K1 {TARSKIK1 A}"
      using ordinal3_th_7 sorry
    also have "... = A"
      using setfam_1_th_10 sorry
    finally show "infORDINAL2K2 {TARSKIK1 A} =HIDDENR1 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_11:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies meetSETFAM-1K1 X be OrdinalORDINAL1M3"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies meetSETFAM-1K1 X be OrdinalORDINAL1M3"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X c=TARSKIR1 A"
    then have "infORDINAL2K2 X =XBOOLE-0R4 meetSETFAM-1K1 X"
      using ordinal3_th_6 sorry
    thus "meetSETFAM-1K1 X be OrdinalORDINAL1M3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_cl_1:
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"cluster A \\/XBOOLE-0K2 B as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "A \\/XBOOLE-0K2 B be ordinalORDINAL1V3"
  proof-
    have "A c=ORDINAL1R1 B or B c=ORDINAL1R1 A"
       sorry
    thus "A \\/XBOOLE-0K2 B be ordinalORDINAL1V3"
      using xboole_1_th_12 sorry
  qed
qed "sorry"

mtheorem ordinal3_cl_2:
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"cluster A /\\XBOOLE-0K3 B as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "A /\\XBOOLE-0K3 B be ordinalORDINAL1V3"
  proof-
    have "A c=ORDINAL1R1 B or B c=ORDINAL1R1 A"
       sorry
    thus "A /\\XBOOLE-0K3 B be ordinalORDINAL1V3"
      using xboole_1_th_28 sorry
  qed
qed "sorry"

mtheorem ordinal3_th_12:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A \\/XBOOLE-0K2 B =XBOOLE-0R4 A or A \\/XBOOLE-0K2 B =XBOOLE-0R4 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not ( not A \\/XBOOLE-0K2 B =XBOOLE-0R4 A &  not A \\/XBOOLE-0K2 B =XBOOLE-0R4 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "A c=ORDINAL1R1 B or B c=ORDINAL1R1 A"
       sorry
    thus " not ( not A \\/XBOOLE-0K2 B =XBOOLE-0R4 A &  not A \\/XBOOLE-0K2 B =XBOOLE-0R4 B)"
      using xboole_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_13:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A /\\XBOOLE-0K3 B =XBOOLE-0R4 A or A /\\XBOOLE-0K3 B =XBOOLE-0R4 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not ( not A /\\XBOOLE-0K3 B =XBOOLE-0R4 A &  not A /\\XBOOLE-0K3 B =XBOOLE-0R4 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "A c=ORDINAL1R1 B or B c=ORDINAL1R1 A"
       sorry
    thus " not ( not A /\\XBOOLE-0K3 B =XBOOLE-0R4 A &  not A /\\XBOOLE-0K3 B =XBOOLE-0R4 B)"
      using xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma ordinal3_lm_1:
"\<one>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5)"
   sorry

mtheorem ordinal3_th_14:
" for A be OrdinalORDINAL1M3 holds A inTARSKIR2 \<one>\<^sub>M implies A =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 \<one>\<^sub>M implies A =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume Cut154: "A inTARSKIR2 \<one>\<^sub>M"
    have "A c=ORDINAL1R1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=ORDINAL1R1 A"
    proof-
      show "A c=ORDINAL1R1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=ORDINAL1R1 A"
        using ordinal3_lm_1 ordinal1_th_22 Cut154 sorry
    qed
    thus "A =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_15:
"\<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  using ordinal3_lm_1 sorry

mtheorem ordinal3_th_16:
" for A be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 \<one>\<^sub>M implies A =XBOOLE-0R4 {}XBOOLE-0K1 or A =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for A be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 \<one>\<^sub>M & (A <>HIDDENR2 {}XBOOLE-0K1 & A <>HIDDENR2 \<one>\<^sub>M) implies  False "
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 \<one>\<^sub>M"
      and A2: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "A <>HIDDENR2 \<one>\<^sub>M"
    have "A c<XBOOLE-0R2 \<one>\<^sub>M"
      using A1 A3 sorry
    thus " False "
      using A2 ordinal3_th_14 ordinal1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_17:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds (A c=ORDINAL1R1 B or A inTARSKIR2 B) & C inTARSKIR2 D implies A +^ORDINAL2K10 C inTARSKIR2 B +^ORDINAL2K10 D"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds (A c=ORDINAL1R1 B or A inTARSKIR2 B) & C inTARSKIR2 D implies A +^ORDINAL2K10 C inTARSKIR2 B +^ORDINAL2K10 D"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 B or A inTARSKIR2 B"
      and A2: "C inTARSKIR2 D"
    have A3: "B +^ORDINAL2K10 C inTARSKIR2 B +^ORDINAL2K10 D"
      using A2 ordinal2_th_32 sorry
    have "A c=ORDINAL1R1 B"
      using A1 ordinal1_def_2 sorry
    thus "A +^ORDINAL2K10 C inTARSKIR2 B +^ORDINAL2K10 D"
      using A3 ordinal1_th_12 ordinal2_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_18:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B & C c=ORDINAL1R1 D implies A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 D"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B & C c=ORDINAL1R1 D implies A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 D"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 B"
      and A2: "C c=ORDINAL1R1 D"
    have A3: "B +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 D"
      using A2 ordinal2_th_33 sorry
    have "A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
      using A1 ordinal2_th_34 sorry
    thus "A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 D"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_19:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds A inTARSKIR2 B & (C c=ORDINAL1R1 D & D <>HIDDENR2 {}XBOOLE-0K1 or C inTARSKIR2 D) implies A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 D"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds A inTARSKIR2 B & (C c=ORDINAL1R1 D & D <>HIDDENR2 {}XBOOLE-0K1 or C inTARSKIR2 D) implies A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 D"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    assume A1: "A inTARSKIR2 B"
      and A2: "C c=ORDINAL1R1 D & D <>HIDDENR2 {}XBOOLE-0K1 or C inTARSKIR2 D"
    have A3: "C c=ORDINAL1R1 D"
      using A2 ordinal1_def_2 sorry
    have "A *^ORDINAL2K11 D inTARSKIR2 B *^ORDINAL2K11 D"
      using A1 A2 ordinal2_th_40 sorry
    thus "A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 D"
      using A3 ordinal1_th_12 ordinal2_th_42 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_20:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B & C c=ORDINAL1R1 D implies A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 D"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B & C c=ORDINAL1R1 D implies A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 D"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 B"
      and A2: "C c=ORDINAL1R1 D"
    have A3: "B *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 D"
      using A2 ordinal2_th_42 sorry
    have "A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
      using A1 ordinal2_th_41 sorry
    thus "A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 D"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_21:
" for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds B +^ORDINAL2K10 C =XBOOLE-0R4 B +^ORDINAL2K10 D implies C =XBOOLE-0R4 D"
proof-
  have " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds B +^ORDINAL2K10 C =XBOOLE-0R4 B +^ORDINAL2K10 D & C <>HIDDENR2 D implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    assume A1: "B +^ORDINAL2K10 C =XBOOLE-0R4 B +^ORDINAL2K10 D"
      and A2: "C <>HIDDENR2 D"
    have "C inTARSKIR2 D or D inTARSKIR2 C"
      using A2 ordinal1_th_14 sorry
    then have "B +^ORDINAL2K10 C inTARSKIR2 B +^ORDINAL2K10 C"
      using A1 ordinal2_th_32 sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_22:
" for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds B +^ORDINAL2K10 C inTARSKIR2 B +^ORDINAL2K10 D implies C inTARSKIR2 D"
proof-
  have " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds B +^ORDINAL2K10 C inTARSKIR2 B +^ORDINAL2K10 D &  not C inTARSKIR2 D implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    assume A1: "B +^ORDINAL2K10 C inTARSKIR2 B +^ORDINAL2K10 D"
      and A2: " not C inTARSKIR2 D"
    have "D c=ORDINAL1R1 C"
      using A2 ordinal1_th_16 sorry
    thus " False "
      using A1 ordinal1_th_5 ordinal2_th_33 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_23:
" for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds B +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 D implies C c=ORDINAL1R1 D"
proof-
  have " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds B +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 D implies C c=ORDINAL1R1 D"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    assume A1: "B +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 D"
    have "B +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 D & B +^ORDINAL2K10 C <>HIDDENR2 B +^ORDINAL2K10 D iff B +^ORDINAL2K10 C c<XBOOLE-0R2 B +^ORDINAL2K10 D"
       sorry
    then have "C =XBOOLE-0R4 D or C inTARSKIR2 D"
      using A1 ordinal3_th_21 ordinal3_th_22 ordinal1_th_11 sorry
    thus "C c=ORDINAL1R1 D"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_24:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 A +^ORDINAL2K10 B & B c=ORDINAL1R1 A +^ORDINAL2K10 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 A +^ORDINAL2K10 B & B c=ORDINAL1R1 A +^ORDINAL2K10 B"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have A1: "{}XBOOLE-0K1 +^ORDINAL2K10 B c=ORDINAL1R1 A +^ORDINAL2K10 B"
      using ordinal2_th_34 xboole_1_th_2 sorry
    have "A +^ORDINAL2K10 {}XBOOLE-0K1 c=ORDINAL1R1 A +^ORDINAL2K10 B"
      using ordinal2_th_33 xboole_1_th_2 sorry
    thus "A c=ORDINAL1R1 A +^ORDINAL2K10 B & B c=ORDINAL1R1 A +^ORDINAL2K10 B"
      using A1 ordinal2_th_27 ordinal2_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_25:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies A inTARSKIR2 B +^ORDINAL2K10 C & A inTARSKIR2 C +^ORDINAL2K10 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies A inTARSKIR2 B +^ORDINAL2K10 C & A inTARSKIR2 C +^ORDINAL2K10 B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A inTARSKIR2 B"
    have A2: "B c=ORDINAL1R1 C +^ORDINAL2K10 B"
      using ordinal3_th_24 sorry
    have "B c=ORDINAL1R1 B +^ORDINAL2K10 C"
      using ordinal3_th_24 sorry
    thus "A inTARSKIR2 B +^ORDINAL2K10 C & A inTARSKIR2 C +^ORDINAL2K10 B"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_26:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A +^ORDINAL2K10 B =XBOOLE-0R4 {}XBOOLE-0K1 implies A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 {}XBOOLE-0K1"
  using ordinal3_th_24 xboole_1_th_3 sorry

mtheorem ordinal3_th_27:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies ( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not (A c=ORDINAL1R1 B & ( for C be OrdinalORDINAL1M3 holds  not B =XBOOLE-0R4 A +^ORDINAL2K10 C))"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. A c=ORDINAL1R1 Lamb1 implies ( ex C be OrdinalORDINAL1M3 st Lamb1 =XBOOLE-0R4 A +^ORDINAL2K10 C)"
    have A1: " for B be OrdinalORDINAL1M3 holds ?P(B) implies ?P(succORDINAL1K1 B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds (A c=ORDINAL1R1 B implies ( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 A +^ORDINAL2K10 C)) & A c=ORDINAL1R1 succORDINAL1K1 B implies  not ( for C be OrdinalORDINAL1M3 holds  not succORDINAL1K1 B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
      proof(rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A2: "A c=ORDINAL1R1 B implies ( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
          and A3: "A c=ORDINAL1R1 succORDINAL1K1 B"
        have A4: "A <>HIDDENR2 succORDINAL1K1 B implies  not ( for C be OrdinalORDINAL1M3 holds  not succORDINAL1K1 B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
        proof(rule impI)
          assume "A <>HIDDENR2 succORDINAL1K1 B"
          then have "A c<XBOOLE-0R2 succORDINAL1K1 B"
            using A3 sorry
          then have "A inTARSKIR2 succORDINAL1K1 B"
            using ordinal1_th_11 sorry
          then obtain C where
            [ty]:"C be OrdinalORDINAL1M3" and 
            A5: "B =XBOOLE-0R4 A +^ORDINAL2K10 C"
            using A2 ordinal1_th_22 sorry
          have "succORDINAL1K1 B =XBOOLE-0R4 A +^ORDINAL2K10 succORDINAL1K1 C"
            using A5 ordinal2_th_28 sorry
          thus " not ( for C be OrdinalORDINAL1M3 holds  not succORDINAL1K1 B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
             sorry
        qed
        have "A =XBOOLE-0R4 succORDINAL1K1 B implies succORDINAL1K1 B =XBOOLE-0R4 A +^ORDINAL2K10 {}XBOOLE-0K1"
          using ordinal2_th_27 sorry
        thus " not ( for C be OrdinalORDINAL1M3 holds  not succORDINAL1K1 B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
          using A4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for B be OrdinalORDINAL1M3 holds (B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4) & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?P(C)) implies ?P(B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & (B be limit-ordinalORDINAL1V4 & (( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies (A c=ORDINAL1R1 C implies ( ex D be OrdinalORDINAL1M3 st C =XBOOLE-0R4 A +^ORDINAL2K10 D))) & A c=ORDINAL1R1 B)) implies  not ( for C be OrdinalORDINAL1M3 holds  not B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        let ?F = "\<lambda>Lamb1. A +^ORDINAL2K10 Lamb1"
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume "B <>HIDDENR2 0ORDINAL1K5"
          and A7: "B be limit-ordinalORDINAL1V4"
          and " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies (A c=ORDINAL1R1 C implies ( ex D be OrdinalORDINAL1M3 st C =XBOOLE-0R4 A +^ORDINAL2K10 D))"
          and A8: "A c=ORDINAL1R1 B"
        let ?P = "\<lambda>Lamb1. B c=ORDINAL1R1 A +^ORDINAL2K10 Lamb1"
        have A9: "B =XBOOLE-0R4 {}XBOOLE-0K1 +^ORDINAL2K10 B"
          using ordinal2_th_30 sorry
        have "{}XBOOLE-0K1 +^ORDINAL2K10 B c=ORDINAL1R1 A +^ORDINAL2K10 B"
          using ordinal2_th_34 xboole_1_th_2 sorry
        then have A10: " ex C be OrdinalORDINAL1M3 st ?P(C)"
          using A9 sorry
        obtain C where
          [ty]:"C be OrdinalORDINAL1M3" and 
          A11: "?P(C) & ( for D be OrdinalORDINAL1M3 holds ?P(D) implies C c=ORDINAL1R1 D)"
          using ordinal1_sch_1 A10 sorry
        obtain L where
          [ty]:"L be Ordinal-SequenceORDINAL2M1" and 
          A12: "domRELAT-1K1 L =XBOOLE-0R4 C & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies L .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
          using ordinal2_sch_3 sorry
        have A13: "C <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for C be OrdinalORDINAL1M3 holds  not B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
        proof(rule impI)
          have " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 rngFUNCT-1K2 L implies D inTARSKIR2 B"
          proof(rule ballI,rule impI)
            fix D assume [ty]: "D be OrdinalORDINAL1M3"
            assume "D inTARSKIR2 rngFUNCT-1K2 L"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A14: "y inHIDDENR3 domRELAT-1K1 L"and A15: "D =XBOOLE-0R4 L .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A14 sorry
            have A16: " not C c=ORDINAL1R1 y"
              using A12 A14 ordinal1_th_5 sorry
            have "L .FUNCT-1K1 y =XBOOLE-0R4 A +^ORDINAL2K10 y"
              using A12 A14 sorry
            thus "D inTARSKIR2 B"
              using A11 A15 A16 ordinal1_th_16 sorry
          qed "sorry"
          then have A17: "supORDINAL2K3 (rngFUNCT-1K2 L) c=ORDINAL1R1 B"
            using ordinal2_th_20 sorry
          have A18: "C be limit-ordinalORDINAL1V4"
          proof-
            have " not C be limit-ordinalORDINAL1V4 implies  False "
            proof(rule impI)
              assume " not C be limit-ordinalORDINAL1V4"
              then obtain D where
                [ty]:"D be OrdinalORDINAL1M3" and 
                A19: "C =XBOOLE-0R4 succORDINAL1K1 D"
                using ordinal1_th_29 sorry
              have " not C c=ORDINAL1R1 D"
                using A19 ordinal1_th_5 ordinal1_th_6 sorry
              then have "A +^ORDINAL2K10 D inTARSKIR2 B"
                using A11 ordinal1_th_16 sorry
              then have A20: "succORDINAL1K1 (A +^ORDINAL2K10 D) c=ORDINAL1R1 B"
                using ordinal1_th_21 sorry
              have "succORDINAL1K1 (A +^ORDINAL2K10 D) =XBOOLE-0R4 A +^ORDINAL2K10 succORDINAL1K1 D"
                using ordinal2_th_28 sorry
              then have "B =XBOOLE-0R4 succORDINAL1K1 (A +^ORDINAL2K10 D)"
                using A11 A19 A20 sorry
              thus " False "
                using A7 ordinal1_th_29 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          assume "C <>HIDDENR2 {}XBOOLE-0K1"
          then have "A +^ORDINAL2K10 C =HIDDENR1 supORDINAL2K4 L"
            using A12 A18 ordinal2_th_29 sorry
          also have "... = supORDINAL2K3 (rngFUNCT-1K2 L)"
             sorry
          finally have "A +^ORDINAL2K10 C =HIDDENR1 supORDINAL2K3 (rngFUNCT-1K2 L)"
             sorry
          then have "B =XBOOLE-0R4 A +^ORDINAL2K10 C"
            using A11 A17 sorry
          thus " not ( for C be OrdinalORDINAL1M3 holds  not B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
             sorry
        qed
        have "C =XBOOLE-0R4 {}XBOOLE-0K1 implies B =XBOOLE-0R4 A +^ORDINAL2K10 {}XBOOLE-0K1"
          using A8 A11 ordinal2_th_27 sorry
        thus " not ( for C be OrdinalORDINAL1M3 holds  not B =XBOOLE-0R4 A +^ORDINAL2K10 C)"
          using A13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A21: "?P(0ORDINAL1K5)"
    proof-
      have "A c=ORDINAL1R1 0ORDINAL1K5 implies  not ( for C be OrdinalORDINAL1M3 holds  not 0ORDINAL1K5 =XBOOLE-0R4 A +^ORDINAL2K10 C)"
      proof(rule impI)
        assume "A c=ORDINAL1R1 0ORDINAL1K5"
        then have "A =XBOOLE-0R4 {}XBOOLE-0K1"
          using xboole_1_th_3 sorry
        then have "{}XBOOLE-0K1 =XBOOLE-0R4 A +^ORDINAL2K10 {}XBOOLE-0K1"
          using ordinal2_th_30 sorry
        thus " not ( for C be OrdinalORDINAL1M3 holds  not 0ORDINAL1K5 =XBOOLE-0R4 A +^ORDINAL2K10 C)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for B be OrdinalORDINAL1M3 holds ?P(B)"
      using ordinal2_sch_1 A21 A1 A6 sorry
    thus " not (A c=ORDINAL1R1 B & ( for C be OrdinalORDINAL1M3 holds  not B =XBOOLE-0R4 A +^ORDINAL2K10 C))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_28:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies ( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 A +^ORDINAL2K10 C & C <>HIDDENR2 {}XBOOLE-0K1)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies ( ex tVar1 be OrdinalORDINAL1M3 st B =XBOOLE-0R4 A +^ORDINAL2K10 tVar1 & (tVar1 =XBOOLE-0R4 {}XBOOLE-0K1 implies  False ))"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "A inTARSKIR2 B"
    then have "A c=ORDINAL1R1 B"
      using ordinal1_def_2 sorry
    then obtain C where
      [ty]:"C be OrdinalORDINAL1M3" and 
      A2: "B =XBOOLE-0R4 A +^ORDINAL2K10 C"
      using ordinal3_th_27 sorry
    show " ex tVar1 be OrdinalORDINAL1M3 st B =XBOOLE-0R4 A +^ORDINAL2K10 tVar1 & (tVar1 =XBOOLE-0R4 {}XBOOLE-0K1 implies  False )"
    proof(rule bexI[of _ "C"],rule conjMI,rule impI)
      show "B =XBOOLE-0R4 A +^ORDINAL2K10 C"
        using A2 sorry
      assume "C =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "B =XBOOLE-0R4 A"
        using A2 ordinal2_th_27 sorry
      thus " False "
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_29:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies B +^ORDINAL2K10 A be limit-ordinalORDINAL1V4"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies B +^ORDINAL2K10 A be limit-ordinalORDINAL1V4"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "A be limit-ordinalORDINAL1V4"
    have "{}XBOOLE-0K1 c=ORDINAL1R1 A"
       sorry
    then have A3: "{}XBOOLE-0K1 c<XBOOLE-0R2 A"
      using A1 sorry
    let ?F = "\<lambda>Lamb1. B +^ORDINAL2K10 Lamb1"
    obtain L where
      [ty]:"L be Ordinal-SequenceORDINAL2M1" and 
      A4: "domRELAT-1K1 L =XBOOLE-0R4 A & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies L .FUNCT-1K1 C =XBOOLE-0R4 ?F(C))"
      using ordinal2_sch_3 sorry
    have A5: "B +^ORDINAL2K10 A =HIDDENR1 supORDINAL2K4 L"
      using A1 A2 A4 ordinal2_th_29 sorry
    also have "... = supORDINAL2K3 (rngFUNCT-1K2 L)"
       sorry
    finally have "B +^ORDINAL2K10 A =HIDDENR1 supORDINAL2K3 (rngFUNCT-1K2 L)"
       sorry
    have " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B +^ORDINAL2K10 A implies succORDINAL1K1 C inTARSKIR2 B +^ORDINAL2K10 A"
    proof(rule ballI,rule impI)
      fix C assume [ty]: "C be OrdinalORDINAL1M3"
      assume A6: "C inTARSKIR2 B +^ORDINAL2K10 A"
      have A7: " not C inTARSKIR2 B implies succORDINAL1K1 C inTARSKIR2 B +^ORDINAL2K10 A"
      proof(rule impI)
        assume " not C inTARSKIR2 B"
        then obtain D where
          [ty]:"D be OrdinalORDINAL1M3" and 
          A8: "C =XBOOLE-0R4 B +^ORDINAL2K10 D"
          using ordinal3_th_27 ordinal1_th_16 sorry
        have " not D inTARSKIR2 A implies  False "
        proof(rule impI)
          assume " not D inTARSKIR2 A"
          then have "B +^ORDINAL2K10 A c=ORDINAL1R1 B +^ORDINAL2K10 D"
            using ordinal1_th_16 ordinal2_th_33 sorry
          then have "C inTARSKIR2 C"
            using A6 A8 sorry
          thus " False "
             sorry
        qed
        then have A9: "succORDINAL1K1 D inTARSKIR2 A"
          using A2 ordinal1_th_28 sorry
        then have "L .FUNCT-1K1 succORDINAL1K1 D =HIDDENR1 B +^ORDINAL2K10 succORDINAL1K1 D"
          using A4 sorry
        also have "... = succORDINAL1K1 (B +^ORDINAL2K10 D)"
          using ordinal2_th_28 sorry
        finally have "L .FUNCT-1K1 succORDINAL1K1 D =HIDDENR1 succORDINAL1K1 (B +^ORDINAL2K10 D)"
           sorry
        then have "succORDINAL1K1 C inTARSKIR2 rngFUNCT-1K2 L"
          using A4 A8 A9 funct_1_def_3 sorry
        thus "succORDINAL1K1 C inTARSKIR2 B +^ORDINAL2K10 A"
          using A5 ordinal2_th_19 sorry
      qed
      have "C inTARSKIR2 B implies succORDINAL1K1 C inTARSKIR2 B +^ORDINAL2K10 A"
      proof(rule impI)
        assume "C inTARSKIR2 B"
        then have A10: "succORDINAL1K1 C c=ORDINAL1R1 B"
          using ordinal1_th_21 sorry
        have A11: "succORDINAL1K1 C +^ORDINAL2K10 {}XBOOLE-0K1 =XBOOLE-0R4 succORDINAL1K1 C"
          using ordinal2_th_27 sorry
        have "B +^ORDINAL2K10 {}XBOOLE-0K1 inTARSKIR2 B +^ORDINAL2K10 A"
          using A3 ordinal1_th_11 ordinal2_th_32 sorry
        thus "succORDINAL1K1 C inTARSKIR2 B +^ORDINAL2K10 A"
          using A10 A11 ordinal1_th_12 ordinal2_th_34 sorry
      qed
      thus "succORDINAL1K1 C inTARSKIR2 B +^ORDINAL2K10 A"
        using A7 sorry
    qed "sorry"
    thus "B +^ORDINAL2K10 A be limit-ordinalORDINAL1V4"
      using ordinal1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_30:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds (A +^ORDINAL2K10 B)+^ORDINAL2K10 C =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 C)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds (A +^ORDINAL2K10 B)+^ORDINAL2K10 C =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 C)"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    let ?Sigma = "\<lambda>Lamb1. (A +^ORDINAL2K10 B)+^ORDINAL2K10 Lamb1 =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 Lamb1)"
    have A1: " for C be OrdinalORDINAL1M3 holds ?Sigma(C) implies ?Sigma(succORDINAL1K1 C)"
    proof-
      have " for C be OrdinalORDINAL1M3 holds (A +^ORDINAL2K10 B)+^ORDINAL2K10 C =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 C) implies (A +^ORDINAL2K10 B)+^ORDINAL2K10 succORDINAL1K1 C =HIDDENR1 A +^ORDINAL2K10 (B +^ORDINAL2K10 succORDINAL1K1 C)"
      proof(rule ballI,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A2: "(A +^ORDINAL2K10 B)+^ORDINAL2K10 C =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 C)"
        have "(A +^ORDINAL2K10 B)+^ORDINAL2K10 succORDINAL1K1 C =HIDDENR1 succORDINAL1K1 ((A +^ORDINAL2K10 B)+^ORDINAL2K10 C)"
          using ordinal2_th_28 sorry
        also have "... = A +^ORDINAL2K10 succORDINAL1K1 (B +^ORDINAL2K10 C)"
          using A2 ordinal2_th_28 sorry
        also have "... = A +^ORDINAL2K10 (B +^ORDINAL2K10 succORDINAL1K1 C)"
          using ordinal2_th_28 sorry
        finally show "(A +^ORDINAL2K10 B)+^ORDINAL2K10 succORDINAL1K1 C =HIDDENR1 A +^ORDINAL2K10 (B +^ORDINAL2K10 succORDINAL1K1 C)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for C be OrdinalORDINAL1M3 holds (C <>HIDDENR2 0ORDINAL1K5 & C be limit-ordinalORDINAL1V4) & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies ?Sigma(D)) implies ?Sigma(C)"
    proof-
      have " for C be OrdinalORDINAL1M3 holds C <>HIDDENR2 0ORDINAL1K5 & (C be limit-ordinalORDINAL1V4 & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies (A +^ORDINAL2K10 B)+^ORDINAL2K10 D =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 D))) implies (A +^ORDINAL2K10 B)+^ORDINAL2K10 C =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 C)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        let ?F = "\<lambda>Lamb1. (A +^ORDINAL2K10 B)+^ORDINAL2K10 Lamb1"
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A4: "C <>HIDDENR2 0ORDINAL1K5"
          and A5: "C be limit-ordinalORDINAL1V4"
          and A6: " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies ?Sigma(D)"
        obtain L where
          [ty]:"L be Ordinal-SequenceORDINAL2M1" and 
          A7: "domRELAT-1K1 L =XBOOLE-0R4 C & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies L .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
          using ordinal2_sch_3 sorry
        let ?F = "\<lambda>Lamb1. A +^ORDINAL2K10 Lamb1"
        obtain L1 where
          [ty]:"L1 be Ordinal-SequenceORDINAL2M1" and 
          A8: "domRELAT-1K1 L1 =XBOOLE-0R4 B +^ORDINAL2K10 C & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B +^ORDINAL2K10 C implies L1 .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
          using ordinal2_sch_3 sorry
        have A9: "rngFUNCT-1K2 L c=TARSKIR1 rngFUNCT-1K2 L1"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 L implies x inHIDDENR3 rngFUNCT-1K2 L1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 L"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A10: "y inHIDDENR3 domRELAT-1K1 L"and A11: "x =HIDDENR1 L .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A10 sorry
            have A12: "B +^ORDINAL2K10 y inTARSKIR2 B +^ORDINAL2K10 C"
              using A7 A10 ordinal2_th_32 sorry
            have "L .FUNCT-1K1 y =XBOOLE-0R4 (A +^ORDINAL2K10 B)+^ORDINAL2K10 y"
              using A7 A10 sorry
            then have A13: "L .FUNCT-1K1 y =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 y)"
              using A6 A7 A10 sorry
            have "L1 .FUNCT-1K1 (B +^ORDINAL2K10 y) =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 y)"
              using A7 A8 A10 ordinal2_th_32 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 L1"
              using A8 A11 A13 A12 funct_1_def_3 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 L c=TARSKIR1 rngFUNCT-1K2 L1"
            using tarski_def_3 sorry
        qed
        have A14: "B +^ORDINAL2K10 C <>HIDDENR2 {}XBOOLE-0K1"
          using A4 ordinal3_th_26 sorry
        have "B +^ORDINAL2K10 C be limit-ordinalORDINAL1V4"
          using A4 A5 ordinal3_th_29 sorry
        then have A15: "A +^ORDINAL2K10 (B +^ORDINAL2K10 C) =HIDDENR1 supORDINAL2K4 L1"
          using A8 A14 ordinal2_th_29 sorry
        also have "... = supORDINAL2K3 (rngFUNCT-1K2 L1)"
           sorry
        finally have "A +^ORDINAL2K10 (B +^ORDINAL2K10 C) =HIDDENR1 supORDINAL2K3 (rngFUNCT-1K2 L1)"
           sorry
        have Cut464: "(A +^ORDINAL2K10 B)+^ORDINAL2K10 C =HIDDENR1 supORDINAL2K4 L"
          using A4 A5 A7 ordinal2_th_29 sorry
        also have "... = supORDINAL2K3 (rngFUNCT-1K2 L)"
           sorry
        finally have "(A +^ORDINAL2K10 B)+^ORDINAL2K10 C =HIDDENR1 supORDINAL2K3 (rngFUNCT-1K2 L)"
           sorry
        have "(A +^ORDINAL2K10 B)+^ORDINAL2K10 C c=ORDINAL1R1 A +^ORDINAL2K10 (B +^ORDINAL2K10 C) & A +^ORDINAL2K10 (B +^ORDINAL2K10 C) c=TARSKIR1 (A +^ORDINAL2K10 B)+^ORDINAL2K10 C"
        proof(rule conjMI)
          show "(A +^ORDINAL2K10 B)+^ORDINAL2K10 C c=ORDINAL1R1 A +^ORDINAL2K10 (B +^ORDINAL2K10 C)"
            using A15 A9 ordinal2_th_22 Cut464 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 A +^ORDINAL2K10 (B +^ORDINAL2K10 C) implies x inHIDDENR3 (A +^ORDINAL2K10 B)+^ORDINAL2K10 C"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A16: "x inHIDDENR3 A +^ORDINAL2K10 (B +^ORDINAL2K10 C)"
            then obtain x9 where 
              [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
               sorry
            have A17: " not x inHIDDENR3 A +^ORDINAL2K10 B implies x inHIDDENR3 (A +^ORDINAL2K10 B)+^ORDINAL2K10 C"
            proof(rule impI)
              have A18: "A c=ORDINAL1R1 A +^ORDINAL2K10 B"
                using ordinal3_th_24 sorry
              assume A19: " not x inHIDDENR3 A +^ORDINAL2K10 B"
              then have "A +^ORDINAL2K10 B c=ORDINAL1R1 x9"
                using ordinal1_th_16 sorry
              then obtain E where
                [ty]:"E be OrdinalORDINAL1M3" and 
                A20: "x9 =XBOOLE-0R4 A +^ORDINAL2K10 E"
                using A18 ordinal3_th_27 xboole_1_th_1 sorry
              have "B c=ORDINAL1R1 E"
                using A19 A20 ordinal1_th_16 ordinal2_th_32 sorry
              then obtain F where
                [ty]:"F be OrdinalORDINAL1M3" and 
                A21: "E =XBOOLE-0R4 B +^ORDINAL2K10 F"
                using ordinal3_th_27 sorry
              have A22: " not F inTARSKIR2 C implies  False "
              proof(rule impI)
                assume " not F inTARSKIR2 C"
                then have "B +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 F"
                  using ordinal1_th_16 ordinal2_th_33 sorry
                then have "A +^ORDINAL2K10 (B +^ORDINAL2K10 C) c=ORDINAL1R1 A +^ORDINAL2K10 (B +^ORDINAL2K10 F)"
                  using ordinal2_th_33 sorry
                then have "x9 inTARSKIR2 x9"
                  using A16 A20 A21 sorry
                thus " False "
                   sorry
              qed
              then have "x =HIDDENR1 (A +^ORDINAL2K10 B)+^ORDINAL2K10 F"
                using A6 A20 A21 sorry
              thus "x inHIDDENR3 (A +^ORDINAL2K10 B)+^ORDINAL2K10 C"
                using A22 ordinal2_th_32 sorry
            qed
            have A23: "(A +^ORDINAL2K10 B)+^ORDINAL2K10 {}XBOOLE-0K1 =XBOOLE-0R4 A +^ORDINAL2K10 B"
              using ordinal2_th_27 sorry
            have "(A +^ORDINAL2K10 B)+^ORDINAL2K10 {}XBOOLE-0K1 c=ORDINAL1R1 (A +^ORDINAL2K10 B)+^ORDINAL2K10 C"
              using ordinal2_th_33 xboole_1_th_2 sorry
            thus "x inHIDDENR3 (A +^ORDINAL2K10 B)+^ORDINAL2K10 C"
              using A23 A17 sorry
          qed "sorry"
          thus "A +^ORDINAL2K10 (B +^ORDINAL2K10 C) c=TARSKIR1 (A +^ORDINAL2K10 B)+^ORDINAL2K10 C"
            using tarski_def_3 sorry
        qed
        thus "?Sigma(C)"
          using xboole_0_def_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "(A +^ORDINAL2K10 B)+^ORDINAL2K10 {}XBOOLE-0K1 =HIDDENR1 A +^ORDINAL2K10 B"
      using ordinal2_th_27 sorry
    also have "... = A +^ORDINAL2K10 (B +^ORDINAL2K10 {}XBOOLE-0K1)"
      using ordinal2_th_27 sorry
    finally have "(A +^ORDINAL2K10 B)+^ORDINAL2K10 {}XBOOLE-0K1 =HIDDENR1 A +^ORDINAL2K10 (B +^ORDINAL2K10 {}XBOOLE-0K1)"
       sorry
    then have A24: "?Sigma(0ORDINAL1K5)"
       sorry
    have " for C be OrdinalORDINAL1M3 holds ?Sigma(C)"
      using ordinal2_sch_1 A24 A1 A3 sorry
    thus "(A +^ORDINAL2K10 B)+^ORDINAL2K10 C =XBOOLE-0R4 A +^ORDINAL2K10 (B +^ORDINAL2K10 C)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_31:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 B =XBOOLE-0R4 {}XBOOLE-0K1 implies A =XBOOLE-0R4 {}XBOOLE-0K1 or B =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 B =XBOOLE-0R4 {}XBOOLE-0K1 & (A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "A *^ORDINAL2K11 B =XBOOLE-0R4 {}XBOOLE-0K1"
      and A2: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "B <>HIDDENR2 {}XBOOLE-0K1"
    have "{}XBOOLE-0K1 c=ORDINAL1R1 A"
       sorry
    then have "{}XBOOLE-0K1 c<XBOOLE-0R2 A"
      using A2 sorry
    thus " False "
      using A1 A3 ordinal1_th_11 ordinal2_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_32:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B & C <>HIDDENR2 {}XBOOLE-0K1 implies A inTARSKIR2 B *^ORDINAL2K11 C & A inTARSKIR2 C *^ORDINAL2K11 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B & C <>HIDDENR2 {}XBOOLE-0K1 implies A inTARSKIR2 B *^ORDINAL2K11 C & A inTARSKIR2 C *^ORDINAL2K11 B"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A inTARSKIR2 B"
      and A2: "C <>HIDDENR2 {}XBOOLE-0K1"
    have "{}XBOOLE-0K1 c=ORDINAL1R1 C"
       sorry
    then have "{}XBOOLE-0K1 c<XBOOLE-0R2 C"
      using A2 sorry
    then have "{}XBOOLE-0K1 inTARSKIR2 C"
      using ordinal1_th_11 sorry
    then have A3: "\<one>\<^sub>M c=ORDINAL1R1 C"
      using ordinal3_lm_1 ordinal1_th_21 sorry
    then have A4: "\<one>\<^sub>M *^ORDINAL2K11 B c=ORDINAL1R1 C *^ORDINAL2K11 B"
      using ordinal2_th_41 sorry
    have A5: "\<one>\<^sub>M *^ORDINAL2K11 B =XBOOLE-0R4 B"
      using ordinal2_th_39 sorry
    have A6: "B *^ORDINAL2K11 \<one>\<^sub>M =XBOOLE-0R4 B"
      using ordinal2_th_39 sorry
    have "B *^ORDINAL2K11 \<one>\<^sub>M c=ORDINAL1R1 B *^ORDINAL2K11 C"
      using A3 ordinal2_th_42 sorry
    thus "A inTARSKIR2 B *^ORDINAL2K11 C & A inTARSKIR2 C *^ORDINAL2K11 B"
      using A1 A4 A6 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_33:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B *^ORDINAL2K11 A =XBOOLE-0R4 C *^ORDINAL2K11 A & A <>HIDDENR2 {}XBOOLE-0K1 implies B =XBOOLE-0R4 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B *^ORDINAL2K11 A =XBOOLE-0R4 C *^ORDINAL2K11 A & (A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 C) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "B *^ORDINAL2K11 A =XBOOLE-0R4 C *^ORDINAL2K11 A"
      and A2: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "B <>HIDDENR2 C"
    have "B inTARSKIR2 C or C inTARSKIR2 B"
      using A3 ordinal1_th_14 sorry
    then have "B *^ORDINAL2K11 A inTARSKIR2 B *^ORDINAL2K11 A"
      using A1 A2 ordinal2_th_40 sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_34:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B *^ORDINAL2K11 A inTARSKIR2 C *^ORDINAL2K11 A implies B inTARSKIR2 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B *^ORDINAL2K11 A inTARSKIR2 C *^ORDINAL2K11 A &  not B inTARSKIR2 C implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "B *^ORDINAL2K11 A inTARSKIR2 C *^ORDINAL2K11 A"
      and A2: " not B inTARSKIR2 C"
    have "C c=ORDINAL1R1 B"
      using A2 ordinal1_th_16 sorry
    thus " False "
      using A1 ordinal1_th_5 ordinal2_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_35:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 A & A <>HIDDENR2 {}XBOOLE-0K1 implies B c=ORDINAL1R1 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 A implies  not ( not A <>HIDDENR2 {}XBOOLE-0K1 &  not B c=ORDINAL1R1 C)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "B *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 A"
    have "B *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 A & B *^ORDINAL2K11 A <>HIDDENR2 C *^ORDINAL2K11 A iff B *^ORDINAL2K11 A c<XBOOLE-0R2 C *^ORDINAL2K11 A"
       sorry
    then have "(A <>HIDDENR2 {}XBOOLE-0K1 implies B =XBOOLE-0R4 C) or B inTARSKIR2 C"
      using A1 ordinal3_th_33 ordinal3_th_34 ordinal1_th_11 sorry
    thus " not ( not A <>HIDDENR2 {}XBOOLE-0K1 &  not B c=ORDINAL1R1 C)"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_36:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 {}XBOOLE-0K1 implies A c=ORDINAL1R1 A *^ORDINAL2K11 B & A c=ORDINAL1R1 B *^ORDINAL2K11 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 {}XBOOLE-0K1 implies A c=ORDINAL1R1 A *^ORDINAL2K11 B & A c=ORDINAL1R1 B *^ORDINAL2K11 A"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume "B <>HIDDENR2 {}XBOOLE-0K1"
    then have "{}XBOOLE-0K1 inTARSKIR2 B"
      using ordinal3_th_8 sorry
    then have A1: "\<one>\<^sub>M c=ORDINAL1R1 B"
      using ordinal3_lm_1 ordinal1_th_21 sorry
    then have A2: "A *^ORDINAL2K11 \<one>\<^sub>M c=ORDINAL1R1 A *^ORDINAL2K11 B"
      using ordinal2_th_42 sorry
    have "\<one>\<^sub>M *^ORDINAL2K11 A c=ORDINAL1R1 B *^ORDINAL2K11 A"
      using A1 ordinal2_th_41 sorry
    thus "A c=ORDINAL1R1 A *^ORDINAL2K11 B & A c=ORDINAL1R1 B *^ORDINAL2K11 A"
      using A2 ordinal2_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_37:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 B =XBOOLE-0R4 \<one>\<^sub>M implies A =XBOOLE-0R4 \<one>\<^sub>M & B =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 B =XBOOLE-0R4 \<one>\<^sub>M implies A =XBOOLE-0R4 \<one>\<^sub>M & B =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "A *^ORDINAL2K11 B =XBOOLE-0R4 \<one>\<^sub>M"
    then have A2: "B <>HIDDENR2 {}XBOOLE-0K1"
      using ordinal2_th_38 sorry
    have "{}XBOOLE-0K1 c=ORDINAL1R1 B"
       sorry
    then have "{}XBOOLE-0K1 c<XBOOLE-0R2 B"
      using A2 sorry
    then have "{}XBOOLE-0K1 inTARSKIR2 B"
      using ordinal1_th_11 sorry
    then have A3: "\<one>\<^sub>M c=ORDINAL1R1 B"
      using ordinal3_lm_1 ordinal1_th_21 sorry
    have A4: "\<one>\<^sub>M inTARSKIR2 A implies  False "
    proof(rule impI)
      have A5: "B =XBOOLE-0R4 \<one>\<^sub>M *^ORDINAL2K11 B"
        using ordinal2_th_39 sorry
      assume "\<one>\<^sub>M inTARSKIR2 A"
      thus " False "
        using A1 A2 A3 A5 ordinal1_th_5 ordinal2_th_40 sorry
    qed
    have "A inTARSKIR2 \<one>\<^sub>M implies  False "
    proof(rule impI)
      assume "A inTARSKIR2 \<one>\<^sub>M"
      then have "A c=ORDINAL1R1 {}XBOOLE-0K1"
        using ordinal3_lm_1 ordinal1_th_22 sorry
      then have "A =XBOOLE-0R4 {}XBOOLE-0K1"
        using xboole_1_th_3 sorry
      thus " False "
        using A1 ordinal2_th_35 sorry
    qed
    thus "A =XBOOLE-0R4 \<one>\<^sub>M"
      using A4 ordinal1_th_14 sorry
    thus "B =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 ordinal2_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_38:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B +^ORDINAL2K10 C implies A inTARSKIR2 B or ( ex D be OrdinalORDINAL1M3 st D inTARSKIR2 C & A =XBOOLE-0R4 B +^ORDINAL2K10 D)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B +^ORDINAL2K10 C &  not A inTARSKIR2 B implies ( ex tVar2 be OrdinalORDINAL1M3 st  not (tVar2 inTARSKIR2 C & A =XBOOLE-0R4 B +^ORDINAL2K10 tVar2) implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A inTARSKIR2 B +^ORDINAL2K10 C"
      and A2: " not A inTARSKIR2 B"
    obtain D where
      [ty]:"D be OrdinalORDINAL1M3" and 
      A3: "A =XBOOLE-0R4 B +^ORDINAL2K10 D"
      using A2 ordinal3_th_27 ordinal1_th_16 sorry
    show " ex tVar2 be OrdinalORDINAL1M3 st  not (tVar2 inTARSKIR2 C & A =XBOOLE-0R4 B +^ORDINAL2K10 tVar2) implies  False "
    proof(rule bexI[of _ "D"],rule impI)
      assume " not (D inTARSKIR2 C & A =XBOOLE-0R4 B +^ORDINAL2K10 D)"
      then have "C c=ORDINAL1R1 D"
        using A3 ordinal1_th_16 sorry
      thus " False "
        using A1 A3 ordinal1_th_5 ordinal2_th_33 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef ordinal3_def_1 (" _ +^ORDINAL3K1  _ " [132,132]132 ) where
  mlet "C be OrdinalORDINAL1M3", "fi be Ordinal-SequenceORDINAL2M1"
"func C +^ORDINAL3K1 fi \<rightarrow> Ordinal-SequenceORDINAL2M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A)"
proof-
  (*existence*)
    show " ex it be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A)"
    proof-
      have " ex F be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies F .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A)"
      proof-
        let ?F = "\<lambda>Lamb1. C +^ORDINAL2K10 fi .FUNCT-1K1 Lamb1"
        show " ex F be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies F .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A)"
          using ordinal2_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Ordinal-SequenceORDINAL2M1 holds  for it2 be Ordinal-SequenceORDINAL2M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it1 .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it2 .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be Ordinal-SequenceORDINAL2M1 holds  for f2 be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 fi & (( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f1 .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f2 .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be Ordinal-SequenceORDINAL2M1"
        fix f2 assume [ty]: "f2 be Ordinal-SequenceORDINAL2M1"
        assume A1: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 fi"
          and A2: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f1 .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A"
          and A3: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 fi"
          and A4: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f2 .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 fi .FUNCT-1K1 A"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 fi implies f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 fi"
          then obtain A where 
            [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
             sorry
          have "f1 .FUNCT-1K1 x =HIDDENR1 C +^ORDINAL2K10 fi .FUNCT-1K1 A"
            using A2 A5 sorry
          also have "... = f2 .FUNCT-1K1 x"
            using A4 A5 sorry
          finally show "f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A1 A3 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef ordinal3_def_2 (" _ +^ORDINAL3K2  _ " [132,132]132 ) where
  mlet "C be OrdinalORDINAL1M3", "fi be Ordinal-SequenceORDINAL2M1"
"func fi +^ORDINAL3K2 C \<rightarrow> Ordinal-SequenceORDINAL2M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C)"
proof-
  (*existence*)
    show " ex it be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C)"
    proof-
      have " ex F be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies F .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C)"
      proof-
        let ?F = "\<lambda>Lamb1. fi .FUNCT-1K1 Lamb1 +^ORDINAL2K10 C"
        show " ex F be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies F .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C)"
          using ordinal2_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Ordinal-SequenceORDINAL2M1 holds  for it2 be Ordinal-SequenceORDINAL2M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it1 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it2 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be Ordinal-SequenceORDINAL2M1 holds  for f2 be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 fi & (( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f1 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f2 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be Ordinal-SequenceORDINAL2M1"
        fix f2 assume [ty]: "f2 be Ordinal-SequenceORDINAL2M1"
        assume A6: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 fi"
          and A7: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f1 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C"
          and A8: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 fi"
          and A9: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f2 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A +^ORDINAL2K10 C"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 fi implies f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A10: "x inHIDDENR3 domRELAT-1K1 fi"
          then obtain A where 
            [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
             sorry
          have "f1 .FUNCT-1K1 x =HIDDENR1 fi .FUNCT-1K1 A +^ORDINAL2K10 C"
            using A7 A10 sorry
          also have "... = f2 .FUNCT-1K1 x"
            using A9 A10 sorry
          finally show "f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A6 A8 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef ordinal3_def_3 (" _ *^ORDINAL3K3  _ " [164,164]164 ) where
  mlet "C be OrdinalORDINAL1M3", "fi be Ordinal-SequenceORDINAL2M1"
"func C *^ORDINAL3K3 fi \<rightarrow> Ordinal-SequenceORDINAL2M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A)"
proof-
  (*existence*)
    show " ex it be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A)"
    proof-
      have " ex F be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies F .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A)"
      proof-
        let ?F = "\<lambda>Lamb1. C *^ORDINAL2K11 fi .FUNCT-1K1 Lamb1"
        show " ex F be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies F .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A)"
          using ordinal2_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Ordinal-SequenceORDINAL2M1 holds  for it2 be Ordinal-SequenceORDINAL2M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it1 .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it2 .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be Ordinal-SequenceORDINAL2M1 holds  for f2 be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 fi & (( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f1 .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f2 .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be Ordinal-SequenceORDINAL2M1"
        fix f2 assume [ty]: "f2 be Ordinal-SequenceORDINAL2M1"
        assume A11: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 fi"
          and A12: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f1 .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A"
          and A13: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 fi"
          and A14: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f2 .FUNCT-1K1 A =XBOOLE-0R4 C *^ORDINAL2K11 fi .FUNCT-1K1 A"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 fi implies f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A15: "x inHIDDENR3 domRELAT-1K1 fi"
          then obtain A where 
            [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
             sorry
          have "f1 .FUNCT-1K1 x =HIDDENR1 C *^ORDINAL2K11 fi .FUNCT-1K1 A"
            using A12 A15 sorry
          also have "... = f2 .FUNCT-1K1 x"
            using A14 A15 sorry
          finally show "f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A11 A13 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef ordinal3_def_4 (" _ *^ORDINAL3K4  _ " [164,164]164 ) where
  mlet "C be OrdinalORDINAL1M3", "fi be Ordinal-SequenceORDINAL2M1"
"func fi *^ORDINAL3K4 C \<rightarrow> Ordinal-SequenceORDINAL2M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C)"
proof-
  (*existence*)
    show " ex it be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C)"
    proof-
      have " ex F be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies F .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C)"
      proof-
        let ?F = "\<lambda>Lamb1. fi .FUNCT-1K1 Lamb1 *^ORDINAL2K11 C"
        show " ex F be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies F .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C)"
          using ordinal2_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Ordinal-SequenceORDINAL2M1 holds  for it2 be Ordinal-SequenceORDINAL2M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it1 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies it2 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be Ordinal-SequenceORDINAL2M1 holds  for f2 be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 fi & (( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f1 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 fi & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f2 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be Ordinal-SequenceORDINAL2M1"
        fix f2 assume [ty]: "f2 be Ordinal-SequenceORDINAL2M1"
        assume A16: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 fi"
          and A17: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f1 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C"
          and A18: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 fi"
          and A19: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi implies f2 .FUNCT-1K1 A =XBOOLE-0R4 fi .FUNCT-1K1 A *^ORDINAL2K11 C"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 fi implies f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A20: "x inHIDDENR3 domRELAT-1K1 fi"
          then obtain A where 
            [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
             sorry
          have "f1 .FUNCT-1K1 x =HIDDENR1 fi .FUNCT-1K1 A *^ORDINAL2K11 C"
            using A17 A20 sorry
          also have "... = f2 .FUNCT-1K1 x"
            using A19 A20 sorry
          finally show "f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A16 A18 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem ordinal3_th_39:
" for fi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds  for C be OrdinalORDINAL1M3 holds ({}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 psi) & ( for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi & B =XBOOLE-0R4 fi .FUNCT-1K1 A implies psi .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 B) implies supORDINAL2K4 psi =XBOOLE-0R4 C +^ORDINAL2K10 supORDINAL2K4 fi"
proof-
  have " for fi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds  for C be OrdinalORDINAL1M3 holds {}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi & (domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 psi & ( for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi & B =XBOOLE-0R4 fi .FUNCT-1K1 A implies psi .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 B)) implies supORDINAL2K4 psi =XBOOLE-0R4 C +^ORDINAL2K10 supORDINAL2K4 fi"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    fix psi assume [ty]: "psi be Ordinal-SequenceORDINAL2M1"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "{}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi"
      and A2: "domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 psi"
      and A3: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi & B =XBOOLE-0R4 fi .FUNCT-1K1 A implies psi .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 B"
    let ?z = "the ElementSUBSET-1M1-of domRELAT-1K1 fi"
    obtain z9 where 
      [ty]:"z9 be OrdinalORDINAL1M3" and z9Def:"z9 = fi .FUNCT-1K1 ?z"
       sorry
    have A4: "C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi) c=ORDINAL1R1 supORDINAL2K3 (rngFUNCT-1K2 psi)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi) implies x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 psi)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi)"
        then obtain A where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
           sorry
        have A6: "( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi) & A =XBOOLE-0R4 C +^ORDINAL2K10 B) implies A inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 psi)"
        proof(rule impI)
          assume Given: " ex B be OrdinalORDINAL1M3 st B inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi) & A =XBOOLE-0R4 C +^ORDINAL2K10 B"
          then obtain B where
            [ty]:"B be OrdinalORDINAL1M3" and 
            A7: "B inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi)"and A8: "A =XBOOLE-0R4 C +^ORDINAL2K10 B"
             sorry
          obtain D where
            [ty]:"D be OrdinalORDINAL1M3" and 
            A9: "D inTARSKIR2 rngFUNCT-1K2 fi"and A10: "B c=ORDINAL1R1 D"
            using A7 ordinal2_th_21 sorry
          obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A11: "x inHIDDENR3 domRELAT-1K1 fi"and A12: "D =XBOOLE-0R4 fi .FUNCT-1K1 x"
            using A9 funct_1_def_3 sorry
          have 
            [ty]:"x be OrdinalORDINAL1M3"
            using A11 sorry
          have "psi .FUNCT-1K1 x =XBOOLE-0R4 C +^ORDINAL2K10 D"
            using A3 A11 A12 sorry
          then have "C +^ORDINAL2K10 D inTARSKIR2 rngFUNCT-1K2 psi"
            using A2 A11 funct_1_def_3 sorry
          then have "C +^ORDINAL2K10 D inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 psi)"
            using ordinal2_th_19 sorry
          thus "A inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 psi)"
            using A8 A10 ordinal1_th_12 ordinal2_th_33 sorry
        qed
        have "A inTARSKIR2 C implies A inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 psi)"
        proof(rule impI)
          have "C +^ORDINAL2K10 z9 =XBOOLE-0R4 psi .FUNCT-1K1 ?z"
            using A1 A3 sorry
          then have "C +^ORDINAL2K10 z9 inTARSKIR2 rngFUNCT-1K2 psi"
            using A1 A2 funct_1_def_3 sorry
          then have A13: "C +^ORDINAL2K10 z9 inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 psi)"
            using ordinal2_th_19 sorry
          assume A14: "A inTARSKIR2 C"
          have "C c=ORDINAL1R1 C +^ORDINAL2K10 z9"
            using ordinal3_th_24 sorry
          then have "A c=ORDINAL1R1 C +^ORDINAL2K10 z9"
            using A14 ordinal1_def_2 sorry
          thus "A inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 psi)"
            using A13 ordinal1_th_12 sorry
        qed
        thus "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 psi)"
          using A5 A6 ordinal3_th_38 sorry
      qed "sorry"
      thus "C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi) c=ORDINAL1R1 supORDINAL2K3 (rngFUNCT-1K2 psi)"
        using tarski_def_3 sorry
    qed
    have "supORDINAL2K3 (rngFUNCT-1K2 psi) c=ORDINAL1R1 C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 psi) implies x inHIDDENR3 C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A15: "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 psi)"
        then obtain A where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
           sorry
        obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A16: "B inTARSKIR2 rngFUNCT-1K2 psi"and A17: "A c=ORDINAL1R1 B"
          using A15 ordinal2_th_21 sorry
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A18: "y inHIDDENR3 domRELAT-1K1 psi"and A19: "B =XBOOLE-0R4 psi .FUNCT-1K1 y"
          using A16 funct_1_def_3 sorry
        have 
          [ty]:"y be OrdinalORDINAL1M3"
          using A18 sorry
        obtain y9 where 
          [ty]:"y9 be OrdinalORDINAL1M3" and y9Def:"y9 = fi .FUNCT-1K1 y"
           sorry
        have "y9 inTARSKIR2 rngFUNCT-1K2 fi"
          using A2 A18 funct_1_def_3 sorry
        then have A20: "y9 inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi)"
          using ordinal2_th_19 sorry
        have "B =XBOOLE-0R4 C +^ORDINAL2K10 y9"
          using A2 A3 A18 A19 sorry
        then have "B inTARSKIR2 C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi)"
          using A20 ordinal2_th_32 sorry
        thus "x inHIDDENR3 C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi)"
          using A17 ordinal1_th_12 sorry
      qed "sorry"
      thus "supORDINAL2K3 (rngFUNCT-1K2 psi) c=ORDINAL1R1 C +^ORDINAL2K10 supORDINAL2K3 (rngFUNCT-1K2 fi)"
        using tarski_def_3 sorry
    qed
    thus "supORDINAL2K4 psi =XBOOLE-0R4 C +^ORDINAL2K10 supORDINAL2K4 fi"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_40:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A be limit-ordinalORDINAL1V4 implies A *^ORDINAL2K11 B be limit-ordinalORDINAL1V4"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A be limit-ordinalORDINAL1V4 implies A *^ORDINAL2K11 B be limit-ordinalORDINAL1V4"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have A1: "A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies  not (A be limit-ordinalORDINAL1V4 &  not A *^ORDINAL2K11 B be limit-ordinalORDINAL1V4)"
    proof(rule impMI ,rule impI)
      let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 B"
      assume A2: "A <>HIDDENR2 {}XBOOLE-0K1"
        and A3: "A be limit-ordinalORDINAL1V4"
      obtain fi where
        [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
        A4: "domRELAT-1K1 fi =XBOOLE-0R4 A & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?F(C))"
        using ordinal2_sch_3 sorry
      have A5: "A *^ORDINAL2K11 B =HIDDENR1 unionTARSKIK3 supORDINAL2K4 fi"
        using A2 A3 A4 ordinal2_th_37 sorry
      also have "... = unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
         sorry
      finally have "A *^ORDINAL2K11 B =HIDDENR1 unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
         sorry
      have " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A *^ORDINAL2K11 B implies succORDINAL1K1 C inTARSKIR2 A *^ORDINAL2K11 B"
      proof(rule ballI,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A6: "C inTARSKIR2 A *^ORDINAL2K11 B"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A7: "C inTARSKIR2 X"and A8: "X inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi)"
          using A5 tarski_def_4 sorry
        have 
          [ty]:"X be OrdinalORDINAL1M3"
          using A8 sorry
        obtain D where
          [ty]:"D be OrdinalORDINAL1M3" and 
          A9: "D inTARSKIR2 rngFUNCT-1K2 fi"and A10: "X c=ORDINAL1R1 D"
          using A8 ordinal2_th_21 sorry
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A11: "x inHIDDENR3 domRELAT-1K1 fi"and A12: "D =XBOOLE-0R4 fi .FUNCT-1K1 x"
          using A9 funct_1_def_3 sorry
        have "succORDINAL1K1 C c=ORDINAL1R1 D"
          using A7 A10 ordinal1_th_21 sorry
        then have A13: "succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 D"
          using ordinal1_th_22 sorry
        have 
          [ty]:"x be OrdinalORDINAL1M3"
          using A11 sorry
        have A14: "succORDINAL1K1 x inTARSKIR2 domRELAT-1K1 fi"
          using A3 A4 A11 ordinal1_th_28 sorry
        then have "fi .FUNCT-1K1 succORDINAL1K1 x =HIDDENR1 succORDINAL1K1 x *^ORDINAL2K11 B"
          using A4 sorry
        also have "... = x *^ORDINAL2K11 B +^ORDINAL2K10 B"
          using ordinal2_th_36 sorry
        finally have "fi .FUNCT-1K1 succORDINAL1K1 x =HIDDENR1 x *^ORDINAL2K11 B +^ORDINAL2K10 B"
           sorry
        then have "x *^ORDINAL2K11 B +^ORDINAL2K10 B inTARSKIR2 rngFUNCT-1K2 fi"
          using A14 funct_1_def_3 sorry
        then have A15: "x *^ORDINAL2K11 B +^ORDINAL2K10 B inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi)"
          using ordinal2_th_19 sorry
        have A16: "x *^ORDINAL2K11 B +^ORDINAL2K10 succORDINAL1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 succORDINAL1K1 (x *^ORDINAL2K11 B +^ORDINAL2K10 {}XBOOLE-0K1)"
          using ordinal2_th_28 sorry
        have "B <>HIDDENR2 {}XBOOLE-0K1"
          using A6 ordinal2_th_38 sorry
        then have "{}XBOOLE-0K1 inTARSKIR2 B"
          using ordinal3_th_8 sorry
        then have A17: "succORDINAL1K1 ({}XBOOLE-0K1) c=ORDINAL1R1 B"
          using ordinal1_th_21 sorry
        have A18: "x *^ORDINAL2K11 B +^ORDINAL2K10 {}XBOOLE-0K1 =XBOOLE-0R4 x *^ORDINAL2K11 B"
          using ordinal2_th_27 sorry
        have "x *^ORDINAL2K11 B =XBOOLE-0R4 fi .FUNCT-1K1 x"
          using A4 A11 sorry
        then have "succORDINAL1K1 D inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi)"
          using A12 A17 A16 A18 A15 ordinal1_th_12 ordinal2_th_33 sorry
        thus "succORDINAL1K1 C inTARSKIR2 A *^ORDINAL2K11 B"
          using A5 A13 tarski_def_4 sorry
      qed "sorry"
      thus " not (A be limit-ordinalORDINAL1V4 &  not A *^ORDINAL2K11 B be limit-ordinalORDINAL1V4)"
        using ordinal1_th_28 sorry
    qed
    assume "A be limit-ordinalORDINAL1V4"
    thus "A *^ORDINAL2K11 B be limit-ordinalORDINAL1V4"
      using A1 ordinal2_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_41:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B *^ORDINAL2K11 C & B be limit-ordinalORDINAL1V4 implies ( ex D be OrdinalORDINAL1M3 st D inTARSKIR2 B & A inTARSKIR2 D *^ORDINAL2K11 C)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B *^ORDINAL2K11 C & B be limit-ordinalORDINAL1V4 implies ( ex E be setHIDDENM2 st E inTARSKIR2 B & A inTARSKIR2 E *^ORDINAL2K11 C)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A inTARSKIR2 B *^ORDINAL2K11 C"
      and A2: "B be limit-ordinalORDINAL1V4"
    let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 C"
    obtain fi where
      [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
      A3: "domRELAT-1K1 fi =XBOOLE-0R4 B & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies fi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
      using ordinal2_sch_3 sorry
    have "B <>HIDDENR2 {}XBOOLE-0K1"
      using A1 ordinal2_th_35 sorry
    then have "B *^ORDINAL2K11 C =HIDDENR1 unionTARSKIK3 supORDINAL2K4 fi"
      using A2 A3 ordinal2_th_37 sorry
    also have "... = unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
       sorry
    finally have "B *^ORDINAL2K11 C =HIDDENR1 unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
       sorry
    then obtain X where
      [ty]:"X be setHIDDENM2" and 
      A4: "A inTARSKIR2 X"and A5: "X inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi)"
      using A1 tarski_def_4 sorry
    have 
      [ty]:"X be OrdinalORDINAL1M3"
      using A5 sorry
    obtain D where
      [ty]:"D be OrdinalORDINAL1M3" and 
      A6: "D inTARSKIR2 rngFUNCT-1K2 fi"and A7: "X c=ORDINAL1R1 D"
      using A5 ordinal2_th_21 sorry
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A8: "x inHIDDENR3 domRELAT-1K1 fi"and A9: "D =XBOOLE-0R4 fi .FUNCT-1K1 x"
      using A6 funct_1_def_3 sorry
    have 
      [ty]:"x be OrdinalORDINAL1M3"
      using A8 sorry
    obtain E where 
      [ty]:"E be setHIDDENM2" and EDef:"E = succORDINAL1K1 x"
       sorry
    show " ex E be setHIDDENM2 st E inTARSKIR2 B & A inTARSKIR2 E *^ORDINAL2K11 C"
    proof(rule bexI[of _ "E"],rule conjMI)
      show "E inTARSKIR2 B"
        using A2 A3 A8 ordinal1_th_28 sorry
      have A10: "D +^ORDINAL2K10 {}XBOOLE-0K1 =XBOOLE-0R4 D"
        using ordinal2_th_27 sorry
      have A11: "C <>HIDDENR2 {}XBOOLE-0K1"
        using A1 ordinal2_th_38 sorry
      have "E *^ORDINAL2K11 C =HIDDENR1 x *^ORDINAL2K11 C +^ORDINAL2K10 C"
        using ordinal2_th_36 sorry
      also have "... = D +^ORDINAL2K10 C"
        using A3 A8 A9 sorry
      finally have "E *^ORDINAL2K11 C =HIDDENR1 D +^ORDINAL2K10 C"
         sorry
      then have "D inTARSKIR2 E *^ORDINAL2K11 C"
        using A11 A10 ordinal3_th_8 ordinal2_th_32 sorry
      thus "A inTARSKIR2 E *^ORDINAL2K11 C"
        using A4 A7 ordinal1_th_10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_42:
" for fi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds  for C be OrdinalORDINAL1M3 holds ((domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 psi & C <>HIDDENR2 {}XBOOLE-0K1) & supORDINAL2K4 fi be limit-ordinalORDINAL1V4) & ( for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi & B =XBOOLE-0R4 fi .FUNCT-1K1 A implies psi .FUNCT-1K1 A =XBOOLE-0R4 B *^ORDINAL2K11 C) implies supORDINAL2K4 psi =XBOOLE-0R4 supORDINAL2K4 fi *^ORDINAL2K11 C"
proof-
  have " for fi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds  for C be OrdinalORDINAL1M3 holds domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 psi & (C <>HIDDENR2 {}XBOOLE-0K1 & (supORDINAL2K4 fi be limit-ordinalORDINAL1V4 & ( for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi & B =XBOOLE-0R4 fi .FUNCT-1K1 A implies psi .FUNCT-1K1 A =XBOOLE-0R4 B *^ORDINAL2K11 C))) implies supORDINAL2K4 psi =XBOOLE-0R4 supORDINAL2K4 fi *^ORDINAL2K11 C"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    fix psi assume [ty]: "psi be Ordinal-SequenceORDINAL2M1"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 psi"
      and A2: "C <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "supORDINAL2K4 fi be limit-ordinalORDINAL1V4"
      and A4: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi & B =XBOOLE-0R4 fi .FUNCT-1K1 A implies psi .FUNCT-1K1 A =XBOOLE-0R4 B *^ORDINAL2K11 C"
    have A5: "supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C c=ORDINAL1R1 supORDINAL2K3 (rngFUNCT-1K2 psi)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C implies x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 psi)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C"
        then obtain A where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
           sorry
        obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A7: "B inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi)"and A8: "A inTARSKIR2 B *^ORDINAL2K11 C"
          using A3 A6 ordinal3_th_41 sorry
        obtain D where
          [ty]:"D be OrdinalORDINAL1M3" and 
          A9: "D inTARSKIR2 rngFUNCT-1K2 fi"and A10: "B c=ORDINAL1R1 D"
          using A7 ordinal2_th_21 sorry
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A11: "y inHIDDENR3 domRELAT-1K1 fi"and A12: "D =XBOOLE-0R4 fi .FUNCT-1K1 y"
          using A9 funct_1_def_3 sorry
        have 
          [ty]:"y be OrdinalORDINAL1M3"
          using A11 sorry
        obtain y9 where 
          [ty]:"y9 be OrdinalORDINAL1M3" and y9Def:"y9 = psi .FUNCT-1K1 y"
           sorry
        have A13: "y9 inTARSKIR2 rngFUNCT-1K2 psi"
          using A1 A11 funct_1_def_3 sorry
        have "y9 =XBOOLE-0R4 D *^ORDINAL2K11 C"
          using A4 A11 A12 sorry
        then have A14: "D *^ORDINAL2K11 C inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 psi)"
          using A13 ordinal2_th_19 sorry
        have "B *^ORDINAL2K11 C c=ORDINAL1R1 D *^ORDINAL2K11 C"
          using A10 ordinal2_th_41 sorry
        thus "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 psi)"
          using A8 A14 ordinal1_th_10 sorry
      qed "sorry"
      thus "supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C c=ORDINAL1R1 supORDINAL2K3 (rngFUNCT-1K2 psi)"
        using tarski_def_3 sorry
    qed
    have "supORDINAL2K3 (rngFUNCT-1K2 psi) c=ORDINAL1R1 supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 psi) implies x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A15: "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 psi)"
        then obtain A where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
           sorry
        obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A16: "B inTARSKIR2 rngFUNCT-1K2 psi"and A17: "A c=ORDINAL1R1 B"
          using A15 ordinal2_th_21 sorry
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A18: "y inHIDDENR3 domRELAT-1K1 psi"and A19: "B =XBOOLE-0R4 psi .FUNCT-1K1 y"
          using A16 funct_1_def_3 sorry
        have 
          [ty]:"y be OrdinalORDINAL1M3"
          using A18 sorry
        obtain y9 where 
          [ty]:"y9 be OrdinalORDINAL1M3" and y9Def:"y9 = fi .FUNCT-1K1 y"
           sorry
        have "y9 inTARSKIR2 rngFUNCT-1K2 fi"
          using A1 A18 funct_1_def_3 sorry
        then have A20: "y9 inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi)"
          using ordinal2_th_19 sorry
        have "B =XBOOLE-0R4 y9 *^ORDINAL2K11 C"
          using A1 A4 A18 A19 sorry
        then have "B inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C"
          using A2 A20 ordinal2_th_40 sorry
        thus "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C"
          using A17 ordinal1_th_12 sorry
      qed "sorry"
      thus "supORDINAL2K3 (rngFUNCT-1K2 psi) c=ORDINAL1R1 supORDINAL2K3 (rngFUNCT-1K2 fi) *^ORDINAL2K11 C"
        using tarski_def_3 sorry
    qed
    thus "supORDINAL2K4 psi =XBOOLE-0R4 supORDINAL2K4 fi *^ORDINAL2K11 C"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_43:
" for fi be Ordinal-SequenceORDINAL2M1 holds  for C be OrdinalORDINAL1M3 holds {}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi implies supORDINAL2K4 (C +^ORDINAL3K1 fi) =XBOOLE-0R4 C +^ORDINAL2K10 supORDINAL2K4 fi"
proof-
  have " for fi be Ordinal-SequenceORDINAL2M1 holds  for C be OrdinalORDINAL1M3 holds  not ( not {}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi &  not supORDINAL2K4 (C +^ORDINAL3K1 fi) =XBOOLE-0R4 C +^ORDINAL2K10 supORDINAL2K4 fi)"
  proof(rule ballI,rule ballI)
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    have A1: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi & B =XBOOLE-0R4 fi .FUNCT-1K1 A implies (C +^ORDINAL3K1 fi).FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 B"
      using ordinal3_def_1 sorry
    have "domRELAT-1K1 (C +^ORDINAL3K1 fi) =XBOOLE-0R4 domRELAT-1K1 fi"
      using ordinal3_def_1 sorry
    thus " not ( not {}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi &  not supORDINAL2K4 (C +^ORDINAL3K1 fi) =XBOOLE-0R4 C +^ORDINAL2K10 supORDINAL2K4 fi)"
      using A1 ordinal3_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_44:
" for fi be Ordinal-SequenceORDINAL2M1 holds  for C be OrdinalORDINAL1M3 holds ({}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi & C <>HIDDENR2 {}XBOOLE-0K1) & supORDINAL2K4 fi be limit-ordinalORDINAL1V4 implies supORDINAL2K4 (fi *^ORDINAL3K4 C) =XBOOLE-0R4 supORDINAL2K4 fi *^ORDINAL2K11 C"
proof-
  have " for fi be Ordinal-SequenceORDINAL2M1 holds  for C be OrdinalORDINAL1M3 holds  not ((( not {}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi &  not C <>HIDDENR2 {}XBOOLE-0K1) & supORDINAL2K4 fi be limit-ordinalORDINAL1V4) &  not supORDINAL2K4 (fi *^ORDINAL3K4 C) =XBOOLE-0R4 supORDINAL2K4 fi *^ORDINAL2K11 C)"
  proof(rule ballI,rule ballI)
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    have A1: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fi & B =XBOOLE-0R4 fi .FUNCT-1K1 A implies (fi *^ORDINAL3K4 C).FUNCT-1K1 A =XBOOLE-0R4 B *^ORDINAL2K11 C"
      using ordinal3_def_4 sorry
    have "domRELAT-1K1 (fi *^ORDINAL3K4 C) =XBOOLE-0R4 domRELAT-1K1 fi"
      using ordinal3_def_4 sorry
    thus " not ((( not {}XBOOLE-0K1 <>HIDDENR2 domRELAT-1K1 fi &  not C <>HIDDENR2 {}XBOOLE-0K1) & supORDINAL2K4 fi be limit-ordinalORDINAL1V4) &  not supORDINAL2K4 (fi *^ORDINAL3K4 C) =XBOOLE-0R4 supORDINAL2K4 fi *^ORDINAL2K11 C)"
      using A1 ordinal3_th_42 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_45:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 {}XBOOLE-0K1 implies unionTARSKIK3 (A +^ORDINAL2K10 B) =XBOOLE-0R4 A +^ORDINAL2K10 unionTARSKIK3 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 {}XBOOLE-0K1 implies unionTARSKIK3 (A +^ORDINAL2K10 B) =XBOOLE-0R4 A +^ORDINAL2K10 unionTARSKIK3 B"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "B <>HIDDENR2 {}XBOOLE-0K1"
    have A2: " not ( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C) implies unionTARSKIK3 (A +^ORDINAL2K10 B) =XBOOLE-0R4 A +^ORDINAL2K10 unionTARSKIK3 B"
    proof(rule impI)
      assume " not ( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C)"
      then have A3: "B be limit-ordinalORDINAL1V4"
        using ordinal1_th_29 sorry
      then have "A +^ORDINAL2K10 B be limit-ordinalORDINAL1V4"
        using A1 ordinal3_th_29 sorry
      then have "unionTARSKIK3 (A +^ORDINAL2K10 B) =XBOOLE-0R4 A +^ORDINAL2K10 B"
         sorry
      thus "unionTARSKIK3 (A +^ORDINAL2K10 B) =XBOOLE-0R4 A +^ORDINAL2K10 unionTARSKIK3 B"
        using A3 sorry
    qed
    have "( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C) implies unionTARSKIK3 (A +^ORDINAL2K10 B) =HIDDENR1 A +^ORDINAL2K10 unionTARSKIK3 B"
    proof(rule impI)
      assume Given: " ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C"
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A4: "B =XBOOLE-0R4 succORDINAL1K1 C"
         sorry
      have "unionTARSKIK3 (A +^ORDINAL2K10 B) =HIDDENR1 unionTARSKIK3 (succORDINAL1K1 (A +^ORDINAL2K10 C))"
        using A4 ordinal2_th_28 sorry
      also have "... = A +^ORDINAL2K10 C"
        using ordinal2_th_2 sorry
      also have "... = A +^ORDINAL2K10 unionTARSKIK3 B"
        using A4 ordinal2_th_2 sorry
      finally show "unionTARSKIK3 (A +^ORDINAL2K10 B) =HIDDENR1 A +^ORDINAL2K10 unionTARSKIK3 B"
         sorry
    qed
    thus "unionTARSKIK3 (A +^ORDINAL2K10 B) =XBOOLE-0R4 A +^ORDINAL2K10 unionTARSKIK3 B"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_46:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds (A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds (A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    let ?S = "\<lambda>Lamb1. (A +^ORDINAL2K10 Lamb1)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 Lamb1 *^ORDINAL2K11 C"
    have A1: " for B be OrdinalORDINAL1M3 holds ?S(B) implies ?S(succORDINAL1K1 B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds (A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C implies (A +^ORDINAL2K10 succORDINAL1K1 B)*^ORDINAL2K11 C =HIDDENR1 A *^ORDINAL2K11 C +^ORDINAL2K10 succORDINAL1K1 B *^ORDINAL2K11 C"
      proof(rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A2: "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
        have "(A +^ORDINAL2K10 succORDINAL1K1 B)*^ORDINAL2K11 C =HIDDENR1 succORDINAL1K1 (A +^ORDINAL2K10 B) *^ORDINAL2K11 C"
          using ordinal2_th_28 sorry
        also have "... = (A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C)+^ORDINAL2K10 C"
          using A2 ordinal2_th_36 sorry
        also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 (B *^ORDINAL2K11 C +^ORDINAL2K10 C)"
          using ordinal3_th_30 sorry
        also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 succORDINAL1K1 B *^ORDINAL2K11 C"
          using ordinal2_th_36 sorry
        finally show "(A +^ORDINAL2K10 succORDINAL1K1 B)*^ORDINAL2K11 C =HIDDENR1 A *^ORDINAL2K11 C +^ORDINAL2K10 succORDINAL1K1 B *^ORDINAL2K11 C"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for B be OrdinalORDINAL1M3 holds (B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4) & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies ?S(D)) implies ?S(B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & (B be limit-ordinalORDINAL1V4 & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies (A +^ORDINAL2K10 D)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 D *^ORDINAL2K11 C)) implies (A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        let ?F = "\<lambda>Lamb1. A +^ORDINAL2K10 Lamb1"
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A4: "B <>HIDDENR2 0ORDINAL1K5"
          and A5: "B be limit-ordinalORDINAL1V4"
          and A6: " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies ?S(D)"
        obtain fi where
          [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
          A7: "domRELAT-1K1 fi =XBOOLE-0R4 B & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies fi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
          using ordinal2_sch_3 sorry
        have "A +^ORDINAL2K10 B be limit-ordinalORDINAL1V4"
          using A4 A5 ordinal3_th_29 sorry
        then have A8: "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C be limit-ordinalORDINAL1V4"
          using ordinal3_th_40 sorry
        have A9: "domRELAT-1K1 (fi *^ORDINAL3K4 C) =XBOOLE-0R4 domRELAT-1K1 fi"
          using ordinal3_def_4 sorry
        have A10: "C =XBOOLE-0R4 {}XBOOLE-0K1 implies (A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
        proof(rule impI)
          assume A11: "C =XBOOLE-0R4 {}XBOOLE-0K1"
          then have A12: "A *^ORDINAL2K11 C =XBOOLE-0R4 {}XBOOLE-0K1"
            using ordinal2_th_38 sorry
          have A13: "B *^ORDINAL2K11 C =XBOOLE-0R4 {}XBOOLE-0K1"
            using A11 ordinal2_th_38 sorry
          have "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 {}XBOOLE-0K1"
            using A11 ordinal2_th_38 sorry
          thus "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
            using A12 A13 ordinal2_th_27 sorry
        qed
        let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 C"
        obtain psi where
          [ty]:"psi be Ordinal-SequenceORDINAL2M1" and 
          A14: "domRELAT-1K1 psi =XBOOLE-0R4 B & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies psi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
          using ordinal2_sch_3 sorry
        have A15: " for x be objectHIDDENM1 holds x inHIDDENR3 B implies (fi *^ORDINAL3K4 C).FUNCT-1K1 x =HIDDENR1 (A *^ORDINAL2K11 C +^ORDINAL3K1 psi).FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A16: "x inHIDDENR3 B"
          then obtain k where 
            [ty]:"k be OrdinalORDINAL1M3" and kDef:"k = x"
             sorry
          obtain m n where 
            [ty]:"m be OrdinalORDINAL1M3" and mDef:"m = fi .FUNCT-1K1 k" and
            [ty]:"n be OrdinalORDINAL1M3" and nDef:"n = psi .FUNCT-1K1 k"
             sorry
          have "(fi *^ORDINAL3K4 C).FUNCT-1K1 x =HIDDENR1 m *^ORDINAL2K11 C"
            using A7 A16 ordinal3_def_4 sorry
          also have "... = (A +^ORDINAL2K10 k)*^ORDINAL2K11 C"
            using A7 A16 sorry
          also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 k *^ORDINAL2K11 C"
            using A6 A16 sorry
          also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 n"
            using A14 A16 sorry
          also have "... = (A *^ORDINAL2K11 C +^ORDINAL3K1 psi).FUNCT-1K1 x"
            using A14 A16 ordinal3_def_1 sorry
          finally show "(fi *^ORDINAL3K4 C).FUNCT-1K1 x =HIDDENR1 (A *^ORDINAL2K11 C +^ORDINAL3K1 psi).FUNCT-1K1 x"
             sorry
        qed "sorry"
        obtain k where 
          [ty]:"k be OrdinalORDINAL1M3" and kDef:"k = psi .FUNCT-1K1 {}XBOOLE-0K1"
           sorry
        have "{}XBOOLE-0K1 inTARSKIR2 B"
          using A4 ordinal3_th_8 sorry
        then have "k inTARSKIR2 rngFUNCT-1K2 psi"
          using A14 funct_1_def_3 sorry
        then have A17: "k inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 psi)"
          using ordinal2_th_19 sorry
        have "domRELAT-1K1 (A *^ORDINAL2K11 C +^ORDINAL3K1 psi) =XBOOLE-0R4 domRELAT-1K1 psi"
          using ordinal3_def_1 sorry
        then have A18: "fi *^ORDINAL3K4 C =FUNCT-1R1 A *^ORDINAL2K11 C +^ORDINAL3K1 psi"
          using A7 A14 A9 A15 funct_1_th_2 sorry
        have A19: "A +^ORDINAL2K10 B =XBOOLE-0R4 supORDINAL2K4 fi"
          using A4 A5 A7 ordinal2_th_29 sorry
        have "C <>HIDDENR2 {}XBOOLE-0K1 implies (A +^ORDINAL2K10 B)*^ORDINAL2K11 C =HIDDENR1 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
        proof(rule impI)
          assume "C <>HIDDENR2 {}XBOOLE-0K1"
          then have "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =HIDDENR1 supORDINAL2K4 (fi *^ORDINAL3K4 C)"
            using A4 A5 A7 A19 ordinal3_th_29 ordinal3_th_44 sorry
          also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 supORDINAL2K4 psi"
            using A4 A14 A18 ordinal3_th_43 sorry
          finally have "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =HIDDENR1 A *^ORDINAL2K11 C +^ORDINAL2K10 supORDINAL2K4 psi"
             sorry
          then have "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =HIDDENR1 unionTARSKIK3 (A *^ORDINAL2K11 C +^ORDINAL2K10 supORDINAL2K4 psi)"
            using A8 sorry
          also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 unionTARSKIK3 supORDINAL2K4 psi"
            using A17 ordinal3_th_45 sorry
          also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
            using A4 A5 A14 ordinal2_th_37 sorry
          finally show "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =HIDDENR1 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
             sorry
        qed
        thus "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
          using A10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "(A +^ORDINAL2K10 {}XBOOLE-0K1)*^ORDINAL2K11 C =HIDDENR1 A *^ORDINAL2K11 C"
      using ordinal2_th_27 sorry
    also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 {}XBOOLE-0K1"
      using ordinal2_th_27 sorry
    also have "... = A *^ORDINAL2K11 C +^ORDINAL2K10 {}XBOOLE-0K1 *^ORDINAL2K11 C"
      using ordinal2_th_35 sorry
    finally have "(A +^ORDINAL2K10 {}XBOOLE-0K1)*^ORDINAL2K11 C =HIDDENR1 A *^ORDINAL2K11 C +^ORDINAL2K10 {}XBOOLE-0K1 *^ORDINAL2K11 C"
       sorry
    then have A20: "?S(0ORDINAL1K5)"
       sorry
    have " for B be OrdinalORDINAL1M3 holds ?S(B)"
      using ordinal2_sch_1 A20 A1 A3 sorry
    thus "(A +^ORDINAL2K10 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 B *^ORDINAL2K11 C"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_47:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 implies ( ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds  not (B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A))"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?I = "\<lambda>Lamb1.  ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st Lamb1 =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1"
    have A2: " for B be OrdinalORDINAL1M3 holds (B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4) & ( for A1 be OrdinalORDINAL1M3 holds A1 inTARSKIR2 B implies ?I(A1)) implies ?I(B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & (B be limit-ordinalORDINAL1V4 & ( for A1 be OrdinalORDINAL1M3 holds A1 inTARSKIR2 B implies ( ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st A1 =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A))) implies ( ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        have "{}XBOOLE-0K1 inTARSKIR2 A"
          using A1 ordinal3_th_8 sorry
        then have A3: "succORDINAL1K1 (0ORDINAL1K5) c=ORDINAL1R1 A"
          using ordinal1_th_21 sorry
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume "B <>HIDDENR2 0ORDINAL1K5"
          and A4: "B be limit-ordinalORDINAL1V4"
          and " for A1 be OrdinalORDINAL1M3 holds A1 inTARSKIR2 B implies ?I(A1)"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 B & B inTARSKIR2 Lamb1 *^ORDINAL2K11 A"
        have "B *^ORDINAL2K11 \<one>\<^sub>M =XBOOLE-0R4 B"
          using ordinal2_th_39 sorry
        then have A5: "B c=ORDINAL1R1 B *^ORDINAL2K11 A"
          using A3 ordinal2_th_42 sorry
        have A6: "B <>HIDDENR2 B *^ORDINAL2K11 A implies ( ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A)"
        proof(rule impI)
          assume "B <>HIDDENR2 B *^ORDINAL2K11 A"
          then have "B c<XBOOLE-0R2 B *^ORDINAL2K11 A"
            using A5 sorry
          then have "B inTARSKIR2 B *^ORDINAL2K11 A"
            using ordinal1_th_11 sorry
          then have A7: " ex C be OrdinalORDINAL1M3 st ?P(C)"
            using A4 ordinal3_th_41 sorry
          obtain C where
            [ty]:"C be OrdinalORDINAL1M3" and 
            A8: "?P(C)"and A9: " for C1 be OrdinalORDINAL1M3 holds ?P(C1) implies C c=ORDINAL1R1 C1"
            using ordinal1_sch_1 A7 sorry
          have "C be limit-ordinalORDINAL1V4 implies  False "
          proof(rule impI)
            assume "C be limit-ordinalORDINAL1V4"
            then obtain C1 where
              [ty]:"C1 be OrdinalORDINAL1M3" and 
              A10: "C1 inTARSKIR2 C"and A11: "B inTARSKIR2 C1 *^ORDINAL2K11 A"
              using A8 ordinal3_th_41 sorry
            have "C1 inTARSKIR2 B"
              using A8 A10 ordinal1_th_10 sorry
            thus " False "
              using A9 A10 A11 ordinal1_th_5 sorry
          qed
          then obtain C1 where
            [ty]:"C1 be OrdinalORDINAL1M3" and 
            A12: "C =XBOOLE-0R4 succORDINAL1K1 C1"
            using ordinal1_th_29 sorry
          have A13: "C1 inTARSKIR2 C"
            using A12 ordinal1_th_6 sorry
          then have "C1 inTARSKIR2 B"
            using A8 ordinal1_th_10 sorry
          then have " not B inTARSKIR2 C1 *^ORDINAL2K11 A"
            using A9 A13 ordinal1_th_5 sorry
          then obtain D where
            [ty]:"D be OrdinalORDINAL1M3" and 
            A14: "B =XBOOLE-0R4 C1 *^ORDINAL2K11 A +^ORDINAL2K10 D"
            using ordinal3_th_27 ordinal1_th_16 sorry
          show " ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A"
          proof-
            have " ex tVar4 be OrdinalORDINAL1M3 st  ex tVar5 be OrdinalORDINAL1M3 st B =XBOOLE-0R4 tVar4 *^ORDINAL2K11 A +^ORDINAL2K10 tVar5 & tVar5 inTARSKIR2 A"
            proof-
              show " ex tVar4 be OrdinalORDINAL1M3 st  ex tVar5 be OrdinalORDINAL1M3 st B =XBOOLE-0R4 tVar4 *^ORDINAL2K11 A +^ORDINAL2K10 tVar5 & tVar5 inTARSKIR2 A"
              proof(rule bexI[of _ "C1"])
                show " ex tVar5 be OrdinalORDINAL1M3 st B =XBOOLE-0R4 C1 *^ORDINAL2K11 A +^ORDINAL2K10 tVar5 & tVar5 inTARSKIR2 A"
                proof(rule bexI[of _ "D"],rule conjMI)
                  show "B =XBOOLE-0R4 C1 *^ORDINAL2K11 A +^ORDINAL2K10 D"
                    using A14 sorry
                  have "C1 *^ORDINAL2K11 A +^ORDINAL2K10 D inTARSKIR2 C1 *^ORDINAL2K11 A +^ORDINAL2K10 A"
                    using A8 A12 A14 ordinal2_th_36 sorry
                  thus "D inTARSKIR2 A"
                    using ordinal3_th_22 sorry
                qed "sorry"
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
        qed
        have "B =XBOOLE-0R4 B *^ORDINAL2K11 A implies B =XBOOLE-0R4 B *^ORDINAL2K11 A +^ORDINAL2K10 {}XBOOLE-0K1 & {}XBOOLE-0K1 inTARSKIR2 A"
          using A1 ordinal3_th_8 ordinal2_th_27 sorry
        thus " ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A"
          using A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A15: " for B be OrdinalORDINAL1M3 holds ?I(B) implies ?I(succORDINAL1K1 B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds ( ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A) implies ( ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st succORDINAL1K1 B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A)"
      proof(rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume Given: " ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A"
        then obtain C D where
          [ty]:"C be OrdinalORDINAL1M3" "D be OrdinalORDINAL1M3" and 
          A16: "B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D"and A17: "D inTARSKIR2 A"
           sorry
        have A18: " not succORDINAL1K1 D inTARSKIR2 A implies ( ex C1 be setHIDDENM2 st  ex D1 be setHIDDENM2 st C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =HIDDENR1 succORDINAL1K1 B & D1 inTARSKIR2 A)"
        proof(rule impI)
          assume " not succORDINAL1K1 D inTARSKIR2 A"
          then have A19: "A c=ORDINAL1R1 succORDINAL1K1 D"
            using ordinal1_th_16 sorry
          obtain C1 where 
            [ty]:"C1 be setHIDDENM2" and C1Def:"C1 = succORDINAL1K1 C"
             sorry
          show " ex C1 be setHIDDENM2 st  ex D1 be setHIDDENM2 st C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =HIDDENR1 succORDINAL1K1 B & D1 inTARSKIR2 A"
          proof(rule bexI[of _ "C1"])
            obtain D1 where 
              [ty]:"D1 be setHIDDENM2" and D1Def:"D1 = {}XBOOLE-0K1"
               sorry
            show " ex D1 be setHIDDENM2 st C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =HIDDENR1 succORDINAL1K1 B & D1 inTARSKIR2 A"
            proof(rule bexI[of _ "D1"],rule conjMI)
              have "succORDINAL1K1 D c=ORDINAL1R1 A"
                using A17 ordinal1_th_21 sorry
              then have A20: "A =XBOOLE-0R4 succORDINAL1K1 D"
                using A19 sorry
              have "C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =HIDDENR1 C1 *^ORDINAL2K11 A"
                using ordinal2_th_27 sorry
              also have "... = C *^ORDINAL2K11 A +^ORDINAL2K10 A"
                using ordinal2_th_36 sorry
              also have "... = succORDINAL1K1 B"
                using A16 A20 ordinal2_th_28 sorry
              finally show "C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =HIDDENR1 succORDINAL1K1 B"
                 sorry
              show "D1 inTARSKIR2 A"
                using A1 ordinal3_th_8 sorry
            qed "sorry"
          qed "sorry"
        qed
        have "succORDINAL1K1 D inTARSKIR2 A implies ( ex C1 be OrdinalORDINAL1M3 st  ex D1 be setHIDDENM2 st C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =XBOOLE-0R4 succORDINAL1K1 B & D1 inTARSKIR2 A)"
        proof(rule impI)
          assume A21: "succORDINAL1K1 D inTARSKIR2 A"
          obtain C1 where 
            [ty]:"C1 be OrdinalORDINAL1M3" and C1Def:"C1 = C"
             sorry
          show " ex C1 be OrdinalORDINAL1M3 st  ex D1 be setHIDDENM2 st C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =XBOOLE-0R4 succORDINAL1K1 B & D1 inTARSKIR2 A"
          proof(rule bexI[of _ "C1"])
            obtain D1 where 
              [ty]:"D1 be setHIDDENM2" and D1Def:"D1 = succORDINAL1K1 D"
               sorry
            show " ex D1 be setHIDDENM2 st C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =XBOOLE-0R4 succORDINAL1K1 B & D1 inTARSKIR2 A"
            proof(rule bexI[of _ "D1"],rule conjMI)
              show "C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =XBOOLE-0R4 succORDINAL1K1 B"
                using A16 ordinal2_th_28 sorry
              show "D1 inTARSKIR2 A"
                using A21 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ex C be OrdinalORDINAL1M3 st  ex D be OrdinalORDINAL1M3 st succORDINAL1K1 B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A"
          using A18 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A22: "?I(0ORDINAL1K5)"
    proof-
      have " ex C be setHIDDENM2 st  ex D be setHIDDENM2 st 0ORDINAL1K5 =HIDDENR1 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A"
      proof-
        obtain C where 
          [ty]:"C be setHIDDENM2" and CDef:"C = {}XBOOLE-0K1"
           sorry
        show " ex C be setHIDDENM2 st  ex D be setHIDDENM2 st 0ORDINAL1K5 =HIDDENR1 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A"
        proof(rule bexI[of _ "C"])
          obtain D where 
            [ty]:"D be setHIDDENM2" and DDef:"D = {}XBOOLE-0K1"
             sorry
          show " ex D be setHIDDENM2 st 0ORDINAL1K5 =HIDDENR1 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A"
          proof(rule bexI[of _ "D"],rule conjMI)
            have "0ORDINAL1K5 =HIDDENR1 {}XBOOLE-0K1 +^ORDINAL2K10 {}XBOOLE-0K1"
              using ordinal2_th_27 sorry
            also have "... = C *^ORDINAL2K11 A +^ORDINAL2K10 D"
              using ordinal2_th_35 sorry
            finally show "0ORDINAL1K5 =HIDDENR1 C *^ORDINAL2K11 A +^ORDINAL2K10 D"
               sorry
            show "D inTARSKIR2 A"
              using A1 ordinal3_th_8 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    have " for B be OrdinalORDINAL1M3 holds ?I(B)"
      using ordinal2_sch_1 A22 A15 A2 sorry
    thus " not ( for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds  not (B =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D & D inTARSKIR2 A))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_48:
" for A be OrdinalORDINAL1M3 holds  for C1 be OrdinalORDINAL1M3 holds  for D1 be OrdinalORDINAL1M3 holds  for C2 be OrdinalORDINAL1M3 holds  for D2 be OrdinalORDINAL1M3 holds (C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =XBOOLE-0R4 C2 *^ORDINAL2K11 A +^ORDINAL2K10 D2 & D1 inTARSKIR2 A) & D2 inTARSKIR2 A implies C1 =XBOOLE-0R4 C2 & D1 =XBOOLE-0R4 D2"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for C1 be OrdinalORDINAL1M3 holds  for D1 be OrdinalORDINAL1M3 holds  for C2 be OrdinalORDINAL1M3 holds  for D2 be OrdinalORDINAL1M3 holds C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =XBOOLE-0R4 C2 *^ORDINAL2K11 A +^ORDINAL2K10 D2 & (D1 inTARSKIR2 A & D2 inTARSKIR2 A) implies C1 =XBOOLE-0R4 C2 & D1 =XBOOLE-0R4 D2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix C1 assume [ty]: "C1 be OrdinalORDINAL1M3"
    fix D1 assume [ty]: "D1 be OrdinalORDINAL1M3"
    fix C2 assume [ty]: "C2 be OrdinalORDINAL1M3"
    fix D2 assume [ty]: "D2 be OrdinalORDINAL1M3"
    assume A1: "C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1 =XBOOLE-0R4 C2 *^ORDINAL2K11 A +^ORDINAL2K10 D2"
      and A2: "D1 inTARSKIR2 A"
      and A3: "D2 inTARSKIR2 A"
    let ?B = "C1 *^ORDINAL2K11 A +^ORDINAL2K10 D1"
    have A4: "C2 inTARSKIR2 C1 implies  False "
    proof(rule impI)
      assume "C2 inTARSKIR2 C1"
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A5: "C1 =XBOOLE-0R4 C2 +^ORDINAL2K10 C"and A6: "C <>HIDDENR2 {}XBOOLE-0K1"
        using ordinal3_th_28 sorry
      have "?B =HIDDENR1 (C2 *^ORDINAL2K11 A +^ORDINAL2K10 C *^ORDINAL2K11 A)+^ORDINAL2K10 D1"
        using A5 ordinal3_th_46 sorry
      also have "... = C2 *^ORDINAL2K11 A +^ORDINAL2K10 (C *^ORDINAL2K11 A +^ORDINAL2K10 D1)"
        using ordinal3_th_30 sorry
      finally have "?B =HIDDENR1 C2 *^ORDINAL2K11 A +^ORDINAL2K10 (C *^ORDINAL2K11 A +^ORDINAL2K10 D1)"
         sorry
      then have A7: "D2 =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D1"
        using A1 ordinal3_th_21 sorry
      have A8: "C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 A +^ORDINAL2K10 D1"
        using ordinal3_th_24 sorry
      have "A c=ORDINAL1R1 C *^ORDINAL2K11 A"
        using A6 ordinal3_th_36 sorry
      thus " False "
        using A3 A7 A8 ordinal1_th_5 sorry
    qed
    have "C1 inTARSKIR2 C2 implies  False "
    proof(rule impI)
      assume "C1 inTARSKIR2 C2"
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A9: "C2 =XBOOLE-0R4 C1 +^ORDINAL2K10 C"and A10: "C <>HIDDENR2 {}XBOOLE-0K1"
        using ordinal3_th_28 sorry
      have "?B =HIDDENR1 (C1 *^ORDINAL2K11 A +^ORDINAL2K10 C *^ORDINAL2K11 A)+^ORDINAL2K10 D2"
        using A1 A9 ordinal3_th_46 sorry
      also have "... = C1 *^ORDINAL2K11 A +^ORDINAL2K10 (C *^ORDINAL2K11 A +^ORDINAL2K10 D2)"
        using ordinal3_th_30 sorry
      finally have "?B =HIDDENR1 C1 *^ORDINAL2K11 A +^ORDINAL2K10 (C *^ORDINAL2K11 A +^ORDINAL2K10 D2)"
         sorry
      then have A11: "D1 =XBOOLE-0R4 C *^ORDINAL2K11 A +^ORDINAL2K10 D2"
        using ordinal3_th_21 sorry
      have A12: "C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 A +^ORDINAL2K10 D2"
        using ordinal3_th_24 sorry
      have "A c=ORDINAL1R1 C *^ORDINAL2K11 A"
        using A10 ordinal3_th_36 sorry
      thus " False "
        using A2 A11 A12 ordinal1_th_5 sorry
    qed
    thus "C1 =XBOOLE-0R4 C2"
      using A4 ordinal1_th_14 sorry
    thus "D1 =XBOOLE-0R4 D2"
      using A1 ordinal3_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_49:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (\<one>\<^sub>M inTARSKIR2 B & A <>HIDDENR2 {}XBOOLE-0K1) & A be limit-ordinalORDINAL1V4 implies ( for fi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 fi =XBOOLE-0R4 A & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies fi .FUNCT-1K1 C =XBOOLE-0R4 C *^ORDINAL2K11 B) implies A *^ORDINAL2K11 B =XBOOLE-0R4 supORDINAL2K4 fi)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds \<one>\<^sub>M inTARSKIR2 B & (A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4) implies ( for fi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 fi =XBOOLE-0R4 A & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies fi .FUNCT-1K1 C =XBOOLE-0R4 C *^ORDINAL2K11 B) implies A *^ORDINAL2K11 B =XBOOLE-0R4 supORDINAL2K4 fi)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "\<one>\<^sub>M inTARSKIR2 B"
      and A2: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "A be limit-ordinalORDINAL1V4"
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    assume A4: "domRELAT-1K1 fi =XBOOLE-0R4 A"
      and A5: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies fi .FUNCT-1K1 C =XBOOLE-0R4 C *^ORDINAL2K11 B"
    have "( ex C be OrdinalORDINAL1M3 st supORDINAL2K4 fi =XBOOLE-0R4 succORDINAL1K1 C) implies  False "
    proof(rule impI)
      assume Given: " ex C be OrdinalORDINAL1M3 st supORDINAL2K4 fi =XBOOLE-0R4 succORDINAL1K1 C"
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A6: "supORDINAL2K4 fi =XBOOLE-0R4 succORDINAL1K1 C"
         sorry
      obtain D where
        [ty]:"D be OrdinalORDINAL1M3" and 
        A7: "D inTARSKIR2 rngFUNCT-1K2 fi"and A8: "C c=ORDINAL1R1 D"
        using A6 ordinal1_th_6 ordinal2_th_21 sorry
      have "D inTARSKIR2 supORDINAL2K4 fi"
        using A7 ordinal2_th_19 sorry
      then have A9: "succORDINAL1K1 D c=ORDINAL1R1 succORDINAL1K1 C"
        using A6 ordinal1_th_21 sorry
      have "succORDINAL1K1 C c=ORDINAL1R1 succORDINAL1K1 D"
        using A8 ordinal2_th_1 sorry
      then have "succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 D"
        using A9 sorry
      then have "C =XBOOLE-0R4 D"
        using ordinal1_th_7 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A10: "x inHIDDENR3 domRELAT-1K1 fi"and A11: "C =XBOOLE-0R4 fi .FUNCT-1K1 x"
        using A7 funct_1_def_3 sorry
      have 
        [ty]:"x be OrdinalORDINAL1M3"
        using A10 sorry
      have A12: "C =XBOOLE-0R4 x *^ORDINAL2K11 B"
        using A4 A5 A10 A11 sorry
      have "C +^ORDINAL2K10 \<one>\<^sub>M inTARSKIR2 C +^ORDINAL2K10 B"
        using A1 ordinal2_th_32 sorry
      then have A13: "supORDINAL2K4 fi inTARSKIR2 C +^ORDINAL2K10 B"
        using A6 ordinal2_th_31 sorry
      have A14: "succORDINAL1K1 x *^ORDINAL2K11 B =XBOOLE-0R4 x *^ORDINAL2K11 B +^ORDINAL2K10 B"
        using ordinal2_th_36 sorry
      have A15: "succORDINAL1K1 x inTARSKIR2 domRELAT-1K1 fi"
        using A3 A4 A10 ordinal1_th_28 sorry
      then have "fi .FUNCT-1K1 succORDINAL1K1 x =XBOOLE-0R4 succORDINAL1K1 x *^ORDINAL2K11 B"
        using A4 A5 sorry
      then have "C +^ORDINAL2K10 B inTARSKIR2 rngFUNCT-1K2 fi"
        using A15 A12 A14 funct_1_def_3 sorry
      thus " False "
        using A13 ordinal2_th_19 sorry
    qed
    then have A16: "supORDINAL2K4 fi be limit-ordinalORDINAL1V4"
      using ordinal1_th_29 sorry
    have "A *^ORDINAL2K11 B =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 fi"
      using A2 A3 A4 A5 ordinal2_th_37 sorry
    thus "A *^ORDINAL2K11 B =XBOOLE-0R4 supORDINAL2K4 fi"
      using A16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_50:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds (A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds (A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. (Lamb1 *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 Lamb1 *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
    have A1: "{}XBOOLE-0K1 *^ORDINAL2K11 C =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal2_th_35 sorry
    have A2: " for A be OrdinalORDINAL1M3 holds ?P(A) implies ?P(succORDINAL1K1 A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds (A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C) implies (succORDINAL1K1 A *^ORDINAL2K11 B)*^ORDINAL2K11 C =HIDDENR1 succORDINAL1K1 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
      proof(rule ballI,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A3: "(A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
        have "(succORDINAL1K1 A *^ORDINAL2K11 B)*^ORDINAL2K11 C =HIDDENR1 (A *^ORDINAL2K11 B +^ORDINAL2K10 B)*^ORDINAL2K11 C"
          using ordinal2_th_36 sorry
        also have "... = A *^ORDINAL2K11 (B *^ORDINAL2K11 C) +^ORDINAL2K10 B *^ORDINAL2K11 C"
          using A3 ordinal3_th_46 sorry
        also have "... = A *^ORDINAL2K11 (B *^ORDINAL2K11 C) +^ORDINAL2K10 \<one>\<^sub>M *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
          using ordinal2_th_39 sorry
        also have "... = (A +^ORDINAL2K10 \<one>\<^sub>M)*^ORDINAL2K11 (B *^ORDINAL2K11 C)"
          using ordinal3_th_46 sorry
        also have "... = succORDINAL1K1 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
          using ordinal2_th_31 sorry
        finally show "(succORDINAL1K1 A *^ORDINAL2K11 B)*^ORDINAL2K11 C =HIDDENR1 succORDINAL1K1 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 A implies ?P(D)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0ORDINAL1K5 & (A be limit-ordinalORDINAL1V4 & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 A implies (D *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 D *^ORDINAL2K11 (B *^ORDINAL2K11 C))) implies (A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A5: "A <>HIDDENR2 0ORDINAL1K5"
          and A6: "A be limit-ordinalORDINAL1V4"
          and A7: " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 A implies (D *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 D *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
        have A8: "\<one>\<^sub>M inTARSKIR2 B & \<one>\<^sub>M inTARSKIR2 C implies (A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
        proof(rule impMI ,rule impI)
          let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 B"
          assume A9: "\<one>\<^sub>M inTARSKIR2 B"
            and A10: "\<one>\<^sub>M inTARSKIR2 C"
          obtain fi where
            [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
            A11: "domRELAT-1K1 fi =XBOOLE-0R4 A & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 A implies fi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
            using ordinal2_sch_3 sorry
          have A12: "domRELAT-1K1 (fi *^ORDINAL3K4 C) =XBOOLE-0R4 A & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 A implies (fi *^ORDINAL3K4 C).FUNCT-1K1 D =XBOOLE-0R4 D *^ORDINAL2K11 (B *^ORDINAL2K11 C))"
          proof(rule conjMI,rule ballI,rule impI)
            show "domRELAT-1K1 (fi *^ORDINAL3K4 C) =XBOOLE-0R4 A"
              using A11 ordinal3_def_4 sorry
            fix D assume [ty]: "D be OrdinalORDINAL1M3"
            assume A13: "D inTARSKIR2 A"
            then have A14: "fi .FUNCT-1K1 D =XBOOLE-0R4 D *^ORDINAL2K11 B"
              using A11 sorry
            have "(fi *^ORDINAL3K4 C).FUNCT-1K1 D =XBOOLE-0R4 fi .FUNCT-1K1 D *^ORDINAL2K11 C"
              using A11 A13 ordinal3_def_4 sorry
            thus "(fi *^ORDINAL3K4 C).FUNCT-1K1 D =XBOOLE-0R4 D *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
              using A7 A13 A14 sorry
          qed "sorry"
          have "\<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M *^ORDINAL2K11 \<one>\<^sub>M"
            using ordinal2_th_39 sorry
          then have "\<one>\<^sub>M inTARSKIR2 B *^ORDINAL2K11 C"
            using A9 A10 ordinal3_th_19 sorry
          then have A15: "A *^ORDINAL2K11 (B *^ORDINAL2K11 C) =XBOOLE-0R4 supORDINAL2K4 (fi *^ORDINAL3K4 C)"
            using A5 A6 A12 ordinal3_th_49 sorry
          have "A *^ORDINAL2K11 B =XBOOLE-0R4 supORDINAL2K4 fi"
            using A5 A6 A9 A11 ordinal3_th_49 sorry
          thus "(A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
            using A5 A6 A10 A11 A15 ordinal3_th_40 ordinal3_th_44 sorry
        qed
        have " not (\<one>\<^sub>M inTARSKIR2 B & \<one>\<^sub>M inTARSKIR2 C) implies (A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
        proof(rule impI)
          assume " not (\<one>\<^sub>M inTARSKIR2 B & \<one>\<^sub>M inTARSKIR2 C)"
          then have A16: "((B =XBOOLE-0R4 {}XBOOLE-0K1 or B =XBOOLE-0R4 \<one>\<^sub>M) or C =XBOOLE-0R4 {}XBOOLE-0K1) or C =XBOOLE-0R4 \<one>\<^sub>M"
            using ordinal3_th_16 ordinal1_th_16 sorry
          have A17: "{}XBOOLE-0K1 *^ORDINAL2K11 C =XBOOLE-0R4 {}XBOOLE-0K1"
            using ordinal2_th_35 sorry
          have A18: "(A *^ORDINAL2K11 B)*^ORDINAL2K11 \<one>\<^sub>M =XBOOLE-0R4 A *^ORDINAL2K11 B"
            using ordinal2_th_39 sorry
          have A19: "(A *^ORDINAL2K11 B)*^ORDINAL2K11 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
            using ordinal2_th_38 sorry
          have A20: "A *^ORDINAL2K11 \<one>\<^sub>M =XBOOLE-0R4 A"
            using ordinal2_th_39 sorry
          have "A *^ORDINAL2K11 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
            using ordinal2_th_38 sorry
          thus "(A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
            using A16 A17 A20 A19 A18 ordinal2_th_38 ordinal2_th_39 sorry
        qed
        thus "(A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
          using A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "{}XBOOLE-0K1 *^ORDINAL2K11 B =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal2_th_35 sorry
    then have A21: "?P(0ORDINAL1K5)"
      using A1 ordinal2_th_35 sorry
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal2_sch_1 A21 A2 A4 sorry
    thus "(A *^ORDINAL2K11 B)*^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 (B *^ORDINAL2K11 C)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef ordinal3_def_5 (" _ -^ORDINAL3K5  _ " [132,132]132 ) where
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"func A -^ORDINAL3K5 B \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it. A =XBOOLE-0R4 B +^ORDINAL2K10 it if B c=ORDINAL1R1 A otherwise \<lambda>it. it =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  (*existence*)
    show "(B c=ORDINAL1R1 A implies ( ex it be OrdinalORDINAL1M3 st A =XBOOLE-0R4 B +^ORDINAL2K10 it)) & ( not B c=ORDINAL1R1 A implies ( ex it be OrdinalORDINAL1M3 st it =XBOOLE-0R4 {}XBOOLE-0K1))"
      using ordinal3_th_27 sorry
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds (B c=ORDINAL1R1 A implies (A =XBOOLE-0R4 B +^ORDINAL2K10 it1 & A =XBOOLE-0R4 B +^ORDINAL2K10 it2 implies it1 =HIDDENR1 it2)) & ( not B c=ORDINAL1R1 A implies (it1 =XBOOLE-0R4 {}XBOOLE-0K1 & it2 =XBOOLE-0R4 {}XBOOLE-0K1 implies it1 =HIDDENR1 it2))"
      using ordinal3_th_21 sorry
  (*consistency*)
    show " for it be OrdinalORDINAL1M3 holds  True "
       sorry
qed "sorry"

mdef ordinal3_def_6 (" _ div^ORDINAL3K6  _ " [132,132]132 ) where
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"func A div^ORDINAL3K6 B \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it.  ex C be OrdinalORDINAL1M3 st A =XBOOLE-0R4 it *^ORDINAL2K11 B +^ORDINAL2K10 C & C inTARSKIR2 B if B <>HIDDENR2 {}XBOOLE-0K1 otherwise \<lambda>it. it =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  (*consistency*)
    show " for it be OrdinalORDINAL1M3 holds  True "
       sorry
  (*existence*)
    show "(B <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be OrdinalORDINAL1M3 st  ex C be OrdinalORDINAL1M3 st A =XBOOLE-0R4 it *^ORDINAL2K11 B +^ORDINAL2K10 C & C inTARSKIR2 B)) & ( not B <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be OrdinalORDINAL1M3 st it =XBOOLE-0R4 {}XBOOLE-0K1))"
      using ordinal3_th_47 sorry
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds (B <>HIDDENR2 {}XBOOLE-0K1 implies (( ex C be OrdinalORDINAL1M3 st A =XBOOLE-0R4 it1 *^ORDINAL2K11 B +^ORDINAL2K10 C & C inTARSKIR2 B) & ( ex C be OrdinalORDINAL1M3 st A =XBOOLE-0R4 it2 *^ORDINAL2K11 B +^ORDINAL2K10 C & C inTARSKIR2 B) implies it1 =HIDDENR1 it2)) & ( not B <>HIDDENR2 {}XBOOLE-0K1 implies (it1 =XBOOLE-0R4 {}XBOOLE-0K1 & it2 =XBOOLE-0R4 {}XBOOLE-0K1 implies it1 =HIDDENR1 it2))"
      using ordinal3_th_48 sorry
qed "sorry"

mdef ordinal3_def_7 (" _ mod^ORDINAL3K7  _ " [132,132]132 ) where
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"func A mod^ORDINAL3K7 B \<rightarrow> OrdinalORDINAL1M3 equals
  A -^ORDINAL3K5 (A div^ORDINAL3K6 B)*^ORDINAL2K11 B"
proof-
  (*coherence*)
    show "A -^ORDINAL3K5 (A div^ORDINAL3K6 B)*^ORDINAL2K11 B be OrdinalORDINAL1M3"
       sorry
qed "sorry"

mtheorem ordinal3_th_51:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies B =XBOOLE-0R4 A +^ORDINAL2K10 (B -^ORDINAL3K5 A)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies B =XBOOLE-0R4 A +^ORDINAL2K10 (B -^ORDINAL3K5 A)"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume "A inTARSKIR2 B"
    then have "A c=ORDINAL1R1 B"
      using ordinal1_def_2 sorry
    thus "B =XBOOLE-0R4 A +^ORDINAL2K10 (B -^ORDINAL3K5 A)"
      using ordinal3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_52:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A +^ORDINAL2K10 B)-^ORDINAL3K5 A =XBOOLE-0R4 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A +^ORDINAL2K10 B)-^ORDINAL3K5 A =XBOOLE-0R4 B"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "A c=ORDINAL1R1 A +^ORDINAL2K10 B"
      using ordinal3_th_24 sorry
    thus "(A +^ORDINAL2K10 B)-^ORDINAL3K5 A =XBOOLE-0R4 B"
      using ordinal3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_53:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B & (C c=ORDINAL1R1 A or C inTARSKIR2 A) implies A -^ORDINAL3K5 C inTARSKIR2 B -^ORDINAL3K5 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B & (C c=ORDINAL1R1 A or C inTARSKIR2 A) implies A -^ORDINAL3K5 C inTARSKIR2 B -^ORDINAL3K5 C"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A inTARSKIR2 B"
      and A2: "C c=ORDINAL1R1 A or C inTARSKIR2 A"
    have "A c=ORDINAL1R1 B"
      using A1 ordinal1_def_2 sorry
    then have "C c=ORDINAL1R1 B"
      using A2 ordinal1_def_2 sorry
    then have A3: "B =XBOOLE-0R4 C +^ORDINAL2K10 (B -^ORDINAL3K5 C)"
      using ordinal3_def_5 sorry
    have "C c=ORDINAL1R1 A"
      using A2 ordinal1_def_2 sorry
    then have "A =XBOOLE-0R4 C +^ORDINAL2K10 (A -^ORDINAL3K5 C)"
      using ordinal3_def_5 sorry
    thus "A -^ORDINAL3K5 C inTARSKIR2 B -^ORDINAL3K5 C"
      using A1 A3 ordinal3_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_54:
" for A be OrdinalORDINAL1M3 holds A -^ORDINAL3K5 A =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be OrdinalORDINAL1M3 holds A -^ORDINAL3K5 A =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "A +^ORDINAL2K10 {}XBOOLE-0K1 =XBOOLE-0R4 A"
      using ordinal2_th_27 sorry
    thus "A -^ORDINAL3K5 A =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_55:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies B -^ORDINAL3K5 A <>HIDDENR2 {}XBOOLE-0K1 & {}XBOOLE-0K1 inTARSKIR2 B -^ORDINAL3K5 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies  not B -^ORDINAL3K5 A <>HIDDENR2 {}XBOOLE-0K1 & {}XBOOLE-0K1 inTARSKIR2 B -^ORDINAL3K5 A"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume "A inTARSKIR2 B"
    then have "A -^ORDINAL3K5 A inTARSKIR2 B -^ORDINAL3K5 A"
      using ordinal3_th_53 sorry
    thus " not B -^ORDINAL3K5 A <>HIDDENR2 {}XBOOLE-0K1 & {}XBOOLE-0K1 inTARSKIR2 B -^ORDINAL3K5 A"
      using ordinal3_th_54 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_56:
" for A be OrdinalORDINAL1M3 holds A -^ORDINAL3K5 {}XBOOLE-0K1 =XBOOLE-0R4 A & {}XBOOLE-0K1 -^ORDINAL3K5 A =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be OrdinalORDINAL1M3 holds A -^ORDINAL3K5 {}XBOOLE-0K1 =XBOOLE-0R4 A & {}XBOOLE-0K1 -^ORDINAL3K5 A =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have A1: "{}XBOOLE-0K1 +^ORDINAL2K10 A =XBOOLE-0R4 A"
      using ordinal2_th_30 sorry
    have "{}XBOOLE-0K1 c=ORDINAL1R1 A"
       sorry
    thus "A -^ORDINAL3K5 {}XBOOLE-0K1 =XBOOLE-0R4 A"
      using A1 ordinal3_def_5 sorry
    have " not A c=ORDINAL1R1 {}XBOOLE-0K1 or A c=ORDINAL1R1 {}XBOOLE-0K1"
       sorry
    then have "{}XBOOLE-0K1 -^ORDINAL3K5 A =XBOOLE-0R4 {}XBOOLE-0K1 or A =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal3_def_5 xboole_1_th_3 sorry
    thus "{}XBOOLE-0K1 -^ORDINAL3K5 A =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 ordinal3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_57:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    have "A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
    proof-
      show "A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
      proof-
        have cases: "B +^ORDINAL2K10 C c=ORDINAL1R1 A or  not B +^ORDINAL2K10 C c=ORDINAL1R1 A"
           sorry
        have case1: "B +^ORDINAL2K10 C c=ORDINAL1R1 A implies A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
        proof(rule impI)
          assume "B +^ORDINAL2K10 C c=ORDINAL1R1 A"
          then have "A =XBOOLE-0R4 (B +^ORDINAL2K10 C)+^ORDINAL2K10 (A -^ORDINAL3K5 (B +^ORDINAL2K10 C))"
            using ordinal3_def_5 sorry
          then have "A =XBOOLE-0R4 B +^ORDINAL2K10 (C +^ORDINAL2K10 (A -^ORDINAL3K5 (B +^ORDINAL2K10 C)))"
            using ordinal3_th_30 sorry
          then have "C +^ORDINAL2K10 (A -^ORDINAL3K5 (B +^ORDINAL2K10 C)) =XBOOLE-0R4 A -^ORDINAL3K5 B"
            using ordinal3_th_52 sorry
          thus "A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
            using ordinal3_th_52 sorry
        qed
        have case2: " not B +^ORDINAL2K10 C c=ORDINAL1R1 A implies A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
        proof(rule impI)
          assume A1: " not B +^ORDINAL2K10 C c=ORDINAL1R1 A"
          have A2: "A =XBOOLE-0R4 B +^ORDINAL2K10 (A -^ORDINAL3K5 B) implies (A -^ORDINAL3K5 B)-^ORDINAL3K5 C =XBOOLE-0R4 {}XBOOLE-0K1"
          proof(rule impI)
            assume "A =XBOOLE-0R4 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
            then have " not C c=ORDINAL1R1 A -^ORDINAL3K5 B"
              using A1 ordinal2_th_33 sorry
            thus "(A -^ORDINAL3K5 B)-^ORDINAL3K5 C =XBOOLE-0R4 {}XBOOLE-0K1"
              using ordinal3_def_5 sorry
          qed
          have "B c=ORDINAL1R1 A or  not B c=ORDINAL1R1 A"
             sorry
          then have A3: "A =XBOOLE-0R4 B +^ORDINAL2K10 (A -^ORDINAL3K5 B) or A -^ORDINAL3K5 B =XBOOLE-0R4 {}XBOOLE-0K1"
            using ordinal3_def_5 sorry
          have "A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 {}XBOOLE-0K1"
            using A1 ordinal3_def_5 sorry
          thus "A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
            using A3 A2 ordinal3_th_56 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "A -^ORDINAL3K5 (B +^ORDINAL2K10 C) =XBOOLE-0R4 (A -^ORDINAL3K5 B)-^ORDINAL3K5 C"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_58:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies C -^ORDINAL3K5 B c=ORDINAL1R1 C -^ORDINAL3K5 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies C -^ORDINAL3K5 B c=ORDINAL1R1 C -^ORDINAL3K5 A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 B"
    then have A2: "B =XBOOLE-0R4 A +^ORDINAL2K10 (B -^ORDINAL3K5 A)"
      using ordinal3_def_5 sorry
    have A3: "B c=ORDINAL1R1 C implies C -^ORDINAL3K5 B c=ORDINAL1R1 C -^ORDINAL3K5 A"
    proof(rule impI)
      assume A4: "B c=ORDINAL1R1 C"
      then have A5: "C =XBOOLE-0R4 B +^ORDINAL2K10 (C -^ORDINAL3K5 B)"
        using ordinal3_def_5 sorry
      have "A c=ORDINAL1R1 C"
        using A1 A4 sorry
      then have "B +^ORDINAL2K10 (C -^ORDINAL3K5 B) =XBOOLE-0R4 A +^ORDINAL2K10 (C -^ORDINAL3K5 A)"
        using A5 ordinal3_def_5 sorry
      then have "A +^ORDINAL2K10 ((B -^ORDINAL3K5 A)+^ORDINAL2K10 (C -^ORDINAL3K5 B)) =XBOOLE-0R4 A +^ORDINAL2K10 (C -^ORDINAL3K5 A)"
        using A2 ordinal3_th_30 sorry
      then have "(B -^ORDINAL3K5 A)+^ORDINAL2K10 (C -^ORDINAL3K5 B) =XBOOLE-0R4 C -^ORDINAL3K5 A"
        using ordinal3_th_21 sorry
      thus "C -^ORDINAL3K5 B c=ORDINAL1R1 C -^ORDINAL3K5 A"
        using ordinal3_th_24 sorry
    qed
    have " not B c=ORDINAL1R1 C implies C -^ORDINAL3K5 B c=ORDINAL1R1 C -^ORDINAL3K5 A"
      using ordinal3_def_5 sorry
    thus "C -^ORDINAL3K5 B c=ORDINAL1R1 C -^ORDINAL3K5 A"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_59:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies A -^ORDINAL3K5 C c=ORDINAL1R1 B -^ORDINAL3K5 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies A -^ORDINAL3K5 C c=ORDINAL1R1 B -^ORDINAL3K5 C"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 B"
    have A2: "C c=ORDINAL1R1 A implies A -^ORDINAL3K5 C c=ORDINAL1R1 B -^ORDINAL3K5 C"
    proof(rule impI)
      assume A3: "C c=ORDINAL1R1 A"
      then have A4: "A =XBOOLE-0R4 C +^ORDINAL2K10 (A -^ORDINAL3K5 C)"
        using ordinal3_def_5 sorry
      have "C c=ORDINAL1R1 B"
        using A1 A3 sorry
      then have "C +^ORDINAL2K10 (A -^ORDINAL3K5 C) c=ORDINAL1R1 C +^ORDINAL2K10 (B -^ORDINAL3K5 C)"
        using A1 A4 ordinal3_def_5 sorry
      thus "A -^ORDINAL3K5 C c=ORDINAL1R1 B -^ORDINAL3K5 C"
        using ordinal3_th_23 sorry
    qed
    have " not C c=ORDINAL1R1 A implies A -^ORDINAL3K5 C c=ORDINAL1R1 B -^ORDINAL3K5 C"
      using ordinal3_def_5 sorry
    thus "A -^ORDINAL3K5 C c=ORDINAL1R1 B -^ORDINAL3K5 C"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_60:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C <>HIDDENR2 {}XBOOLE-0K1 & A inTARSKIR2 B +^ORDINAL2K10 C implies A -^ORDINAL3K5 B inTARSKIR2 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C <>HIDDENR2 {}XBOOLE-0K1 implies  not (A inTARSKIR2 B +^ORDINAL2K10 C &  not A -^ORDINAL3K5 B inTARSKIR2 C)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "C <>HIDDENR2 {}XBOOLE-0K1"
    have A2: "(B +^ORDINAL2K10 C)-^ORDINAL3K5 B =XBOOLE-0R4 C"
      using ordinal3_th_52 sorry
    have " not B c=ORDINAL1R1 A implies A -^ORDINAL3K5 B =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal3_def_5 sorry
    thus " not (A inTARSKIR2 B +^ORDINAL2K10 C &  not A -^ORDINAL3K5 B inTARSKIR2 C)"
      using A1 A2 ordinal3_th_8 ordinal3_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_61:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A +^ORDINAL2K10 B inTARSKIR2 C implies B inTARSKIR2 C -^ORDINAL3K5 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  not (A +^ORDINAL2K10 B inTARSKIR2 C &  not B inTARSKIR2 C -^ORDINAL3K5 A)"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    have A1: "(A +^ORDINAL2K10 B)-^ORDINAL3K5 A =XBOOLE-0R4 B"
      using ordinal3_th_52 sorry
    have "A c=ORDINAL1R1 A +^ORDINAL2K10 B"
      using ordinal3_th_24 sorry
    thus " not (A +^ORDINAL2K10 B inTARSKIR2 C &  not B inTARSKIR2 C -^ORDINAL3K5 A)"
      using A1 ordinal3_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_62:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
    proof-
      show "A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
      proof-
        have cases: "B c=ORDINAL1R1 A or  not B c=ORDINAL1R1 A"
           sorry
        have case1: "B c=ORDINAL1R1 A implies A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
        proof(rule impI)
          assume "B c=ORDINAL1R1 A"
          thus "A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
            using ordinal3_def_5 sorry
        qed
        have case2: " not B c=ORDINAL1R1 A implies A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
        proof(rule impI)
          assume A1: " not B c=ORDINAL1R1 A"
          then have "A -^ORDINAL3K5 B =XBOOLE-0R4 {}XBOOLE-0K1"
            using ordinal3_def_5 sorry
          thus "A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
            using A1 ordinal2_th_27 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "A c=ORDINAL1R1 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_63:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 C -^ORDINAL3K5 B *^ORDINAL2K11 C =XBOOLE-0R4 (A -^ORDINAL3K5 B)*^ORDINAL2K11 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 C -^ORDINAL3K5 B *^ORDINAL2K11 C =XBOOLE-0R4 (A -^ORDINAL3K5 B)*^ORDINAL2K11 C"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    have A1: " not B c=ORDINAL1R1 A implies A *^ORDINAL2K11 C -^ORDINAL3K5 B *^ORDINAL2K11 C =XBOOLE-0R4 (A -^ORDINAL3K5 B)*^ORDINAL2K11 C"
    proof(rule impI)
      assume A2: " not B c=ORDINAL1R1 A"
      then have A3: " not B *^ORDINAL2K11 C c=ORDINAL1R1 A *^ORDINAL2K11 C or C =XBOOLE-0R4 {}XBOOLE-0K1"
        using ordinal3_th_35 sorry
      have A4: "{}XBOOLE-0K1 *^ORDINAL2K11 C =XBOOLE-0R4 {}XBOOLE-0K1"
        using ordinal2_th_35 sorry
      have A5: "A *^ORDINAL2K11 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
        using ordinal2_th_38 sorry
      have "A -^ORDINAL3K5 B =XBOOLE-0R4 {}XBOOLE-0K1"
        using A2 ordinal3_def_5 sorry
      thus "A *^ORDINAL2K11 C -^ORDINAL3K5 B *^ORDINAL2K11 C =XBOOLE-0R4 (A -^ORDINAL3K5 B)*^ORDINAL2K11 C"
        using A3 A5 A4 ordinal3_def_5 ordinal3_th_56 sorry
    qed
    have "B c=ORDINAL1R1 A implies A *^ORDINAL2K11 C -^ORDINAL3K5 B *^ORDINAL2K11 C =XBOOLE-0R4 (A -^ORDINAL3K5 B)*^ORDINAL2K11 C"
    proof(rule impI)
      assume "B c=ORDINAL1R1 A"
      then have "A =XBOOLE-0R4 B +^ORDINAL2K10 (A -^ORDINAL3K5 B)"
        using ordinal3_def_5 sorry
      then have "A *^ORDINAL2K11 C =XBOOLE-0R4 B *^ORDINAL2K11 C +^ORDINAL2K10 (A -^ORDINAL3K5 B)*^ORDINAL2K11 C"
        using ordinal3_th_46 sorry
      thus "A *^ORDINAL2K11 C -^ORDINAL3K5 B *^ORDINAL2K11 C =XBOOLE-0R4 (A -^ORDINAL3K5 B)*^ORDINAL2K11 C"
        using ordinal3_th_52 sorry
    qed
    thus "A *^ORDINAL2K11 C -^ORDINAL3K5 B *^ORDINAL2K11 C =XBOOLE-0R4 (A -^ORDINAL3K5 B)*^ORDINAL2K11 C"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_64:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "(A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
    proof-
      show "(A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
      proof-
        have cases: "B <>HIDDENR2 {}XBOOLE-0K1 or B =XBOOLE-0R4 {}XBOOLE-0K1"
           sorry
        have case1: "B <>HIDDENR2 {}XBOOLE-0K1 implies (A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
        proof(rule impI)
          assume "B <>HIDDENR2 {}XBOOLE-0K1"
          then have " ex C be OrdinalORDINAL1M3 st A =XBOOLE-0R4 (A div^ORDINAL3K6 B)*^ORDINAL2K11 B +^ORDINAL2K10 C & C inTARSKIR2 B"
            using ordinal3_def_6 sorry
          thus "(A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
            using ordinal3_th_24 sorry
        qed
        have case2: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies (A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
        proof(rule impI)
          assume "B =XBOOLE-0R4 {}XBOOLE-0K1"
          then have "A div^ORDINAL3K6 B =XBOOLE-0R4 {}XBOOLE-0K1"
            using ordinal3_def_6 sorry
          then have "(A div^ORDINAL3K6 B)*^ORDINAL2K11 B =XBOOLE-0R4 {}XBOOLE-0K1"
            using ordinal2_th_35 sorry
          thus "(A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_65:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A =XBOOLE-0R4 (A div^ORDINAL3K6 B)*^ORDINAL2K11 B +^ORDINAL2K10 (A mod^ORDINAL3K7 B)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A =XBOOLE-0R4 (A div^ORDINAL3K6 B)*^ORDINAL2K11 B +^ORDINAL2K10 (A mod^ORDINAL3K7 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "(A div^ORDINAL3K6 B)*^ORDINAL2K11 B c=ORDINAL1R1 A"
      using ordinal3_th_64 sorry
    thus "A =XBOOLE-0R4 (A div^ORDINAL3K6 B)*^ORDINAL2K11 B +^ORDINAL2K10 (A mod^ORDINAL3K7 B)"
      using ordinal3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_66:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds A =XBOOLE-0R4 B *^ORDINAL2K11 C +^ORDINAL2K10 D & D inTARSKIR2 C implies B =XBOOLE-0R4 A div^ORDINAL3K6 C & D =XBOOLE-0R4 A mod^ORDINAL3K7 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  for D be OrdinalORDINAL1M3 holds A =XBOOLE-0R4 B *^ORDINAL2K11 C +^ORDINAL2K10 D & D inTARSKIR2 C implies B =XBOOLE-0R4 A div^ORDINAL3K6 C & D =XBOOLE-0R4 A mod^ORDINAL3K7 C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    assume A1: "A =XBOOLE-0R4 B *^ORDINAL2K11 C +^ORDINAL2K10 D"
      and A2: "D inTARSKIR2 C"
    show "B =XBOOLE-0R4 A div^ORDINAL3K6 C"
      using A1 A2 ordinal3_def_6 sorry
    thus "D =XBOOLE-0R4 A mod^ORDINAL3K7 C"
      using A1 ordinal3_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_67:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B *^ORDINAL2K11 C implies A div^ORDINAL3K6 C inTARSKIR2 B & A mod^ORDINAL3K7 C inTARSKIR2 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B *^ORDINAL2K11 C implies ( not (A div^ORDINAL3K6 C inTARSKIR2 B & A mod^ORDINAL3K7 C inTARSKIR2 C) implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    have A1: "A =XBOOLE-0R4 (A div^ORDINAL3K6 C)*^ORDINAL2K11 C +^ORDINAL2K10 (A mod^ORDINAL3K7 C)"
      using ordinal3_th_65 sorry
    assume A2: "A inTARSKIR2 B *^ORDINAL2K11 C"
    then have "C <>HIDDENR2 {}XBOOLE-0K1"
      using ordinal2_th_38 sorry
    then have A3: " ex D be OrdinalORDINAL1M3 st A =XBOOLE-0R4 (A div^ORDINAL3K6 C)*^ORDINAL2K11 C +^ORDINAL2K10 D & D inTARSKIR2 C"
      using ordinal3_def_6 sorry
    then have A4: "(A div^ORDINAL3K6 C)*^ORDINAL2K11 C c=ORDINAL1R1 A"
      using ordinal3_th_24 sorry
    assume " not (A div^ORDINAL3K6 C inTARSKIR2 B & A mod^ORDINAL3K7 C inTARSKIR2 C)"
    then have "B *^ORDINAL2K11 C c=ORDINAL1R1 (A div^ORDINAL3K6 C)*^ORDINAL2K11 C"
      using A3 A1 ordinal3_th_21 ordinal1_th_16 ordinal2_th_41 sorry
    thus " False "
      using A2 A4 ordinal1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_68:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 {}XBOOLE-0K1 implies A *^ORDINAL2K11 B div^ORDINAL3K6 B =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 {}XBOOLE-0K1 implies A *^ORDINAL2K11 B div^ORDINAL3K6 B =XBOOLE-0R4 A"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume "B <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "{}XBOOLE-0K1 inTARSKIR2 B"
      using ordinal3_th_8 sorry
    have "A *^ORDINAL2K11 B =XBOOLE-0R4 A *^ORDINAL2K11 B +^ORDINAL2K10 {}XBOOLE-0K1"
      using ordinal2_th_27 sorry
    thus "A *^ORDINAL2K11 B div^ORDINAL3K6 B =XBOOLE-0R4 A"
      using A1 ordinal3_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_69:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 B mod^ORDINAL3K7 B =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 B mod^ORDINAL3K7 B =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have A1: "A *^ORDINAL2K11 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal2_th_38 sorry
    have A2: "A *^ORDINAL2K11 B -^ORDINAL3K5 A *^ORDINAL2K11 B =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal3_th_54 sorry
    have "{}XBOOLE-0K1 -^ORDINAL3K5 (A *^ORDINAL2K11 B div^ORDINAL3K6 B)*^ORDINAL2K11 B =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal3_th_56 sorry
    thus "A *^ORDINAL2K11 B mod^ORDINAL3K7 B =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 A2 ordinal3_th_68 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_70:
" for A be OrdinalORDINAL1M3 holds ({}XBOOLE-0K1 div^ORDINAL3K6 A =XBOOLE-0R4 {}XBOOLE-0K1 & {}XBOOLE-0K1 mod^ORDINAL3K7 A =XBOOLE-0R4 {}XBOOLE-0K1) & A mod^ORDINAL3K7 {}XBOOLE-0K1 =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds {}XBOOLE-0K1 div^ORDINAL3K6 A =XBOOLE-0R4 {}XBOOLE-0K1 & ({}XBOOLE-0K1 mod^ORDINAL3K7 A =XBOOLE-0R4 {}XBOOLE-0K1 & A mod^ORDINAL3K7 {}XBOOLE-0K1 =HIDDENR1 A)"
  proof(rule ballI,rule conjMI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have A1: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have "{}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1 *^ORDINAL2K11 A"
      using ordinal2_th_35 sorry
    thus "{}XBOOLE-0K1 div^ORDINAL3K6 A =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 ordinal3_def_6 ordinal3_th_68 sorry
    show "{}XBOOLE-0K1 mod^ORDINAL3K7 A =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal3_th_56 sorry
    have "A mod^ORDINAL3K7 {}XBOOLE-0K1 =HIDDENR1 A -^ORDINAL3K5 {}XBOOLE-0K1"
      using ordinal2_th_38 sorry
    also have "... = A"
      using ordinal3_th_56 sorry
    finally show "A mod^ORDINAL3K7 {}XBOOLE-0K1 =HIDDENR1 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_71:
" for A be OrdinalORDINAL1M3 holds A div^ORDINAL3K6 \<one>\<^sub>M =XBOOLE-0R4 A & A mod^ORDINAL3K7 \<one>\<^sub>M =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be OrdinalORDINAL1M3 holds A div^ORDINAL3K6 \<one>\<^sub>M =XBOOLE-0R4 A & A mod^ORDINAL3K7 \<one>\<^sub>M =HIDDENR1 {}XBOOLE-0K1"
  proof(rule ballI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have A1: "A =XBOOLE-0R4 A *^ORDINAL2K11 \<one>\<^sub>M"
      using ordinal2_th_39 sorry
    have A2: "A =XBOOLE-0R4 A +^ORDINAL2K10 {}XBOOLE-0K1"
      using ordinal2_th_27 sorry
    have "\<one>\<^sub>M =HIDDENR1 succORDINAL1K1 (0ORDINAL1K5)"
       sorry
    also have "... = {TARSKIK1 0ORDINAL1K5 }"
       sorry
    finally have "\<one>\<^sub>M =HIDDENR1 {TARSKIK1 0ORDINAL1K5 }"
       sorry
    then have A3: "{}XBOOLE-0K1 inTARSKIR2 \<one>\<^sub>M"
      using ordinal3_th_8 sorry
    thus "A div^ORDINAL3K6 \<one>\<^sub>M =XBOOLE-0R4 A"
      using A1 A2 ordinal3_def_6 sorry
    have "A mod^ORDINAL3K7 \<one>\<^sub>M =HIDDENR1 A -^ORDINAL3K5 A"
      using A1 A2 A3 ordinal3_def_6 sorry
    also have "... = {}XBOOLE-0K1"
      using ordinal3_th_54 sorry
    finally show "A mod^ORDINAL3K7 \<one>\<^sub>M =HIDDENR1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem ordinal3_th_72:
" for X be setHIDDENM2 holds supORDINAL2K3 X c=TARSKIR1 succORDINAL1K1 (unionTARSKIK3 (OnORDINAL1K2 X))"
proof-
  have " for X be setHIDDENM2 holds supORDINAL2K3 X c=TARSKIR1 succORDINAL1K1 (unionTARSKIK3 (OnORDINAL1K2 X))"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    obtain A where 
      [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = unionTARSKIK3 (OnORDINAL1K2 X)"
      using ordinal3_th_5 sorry
    have "OnORDINAL1K2 X c=TARSKIR1 succORDINAL1K1 A"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 X implies x inHIDDENR3 succORDINAL1K1 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 OnORDINAL1K2 X"
        then obtain a where 
          [ty]:"a be OrdinalORDINAL1M3" and aDef:"a = x"
          using ordinal1_def_9 sorry
        have "a c=ORDINAL1R1 A"
          using A1 zfmisc_1_th_74 sorry
        thus "x inHIDDENR3 succORDINAL1K1 A"
          using ordinal1_th_22 sorry
      qed "sorry"
      thus "OnORDINAL1K2 X c=TARSKIR1 succORDINAL1K1 A"
        using tarski_def_3 sorry
    qed
    thus "supORDINAL2K3 X c=TARSKIR1 succORDINAL1K1 (unionTARSKIK3 (OnORDINAL1K2 X))"
      using ordinal2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_73:
" for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A is-cofinal-withORDINAL2R2 \<one>\<^sub>M"
proof-
  have " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A is-cofinal-withORDINAL2R2 \<one>\<^sub>M"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?F = "\<lambda>Lamb1. A"
    obtain psi where
      [ty]:"psi be Ordinal-SequenceORDINAL2M1" and 
      A1: "domRELAT-1K1 psi =XBOOLE-0R4 \<one>\<^sub>M & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 \<one>\<^sub>M implies psi .FUNCT-1K1 B =XBOOLE-0R4 ?F(B))"
      using ordinal2_sch_3 sorry
    have "domRELAT-1K1 psi =XBOOLE-0R4 \<one>\<^sub>M & (rngFUNCT-1K2 psi c=TARSKIR1 succORDINAL1K1 A & (psi be increasingORDINAL2V2 & succORDINAL1K1 A =HIDDENR1 supORDINAL2K4 psi))"
    proof(rule conjMI,rule conjMI,rule conjMI)
      show "domRELAT-1K1 psi =XBOOLE-0R4 \<one>\<^sub>M"
        using A1 sorry
      show "rngFUNCT-1K2 psi c=TARSKIR1 succORDINAL1K1 A"
      proof-
        have " for e be objectHIDDENM1 holds e inHIDDENR3 rngFUNCT-1K2 psi implies e inHIDDENR3 succORDINAL1K1 A"
        proof(rule ballI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          assume "e inHIDDENR3 rngFUNCT-1K2 psi"
          then obtain u where
            [ty]:"u be objectHIDDENM1" and 
            A2: "u inHIDDENR3 \<one>\<^sub>M"and A3: "e =HIDDENR1 psi .FUNCT-1K1 u"
            using A1 funct_1_def_3 sorry
          have 
            [ty]:"u be OrdinalORDINAL1M3"
            using A2 sorry
          have "psi .FUNCT-1K1 u =XBOOLE-0R4 A"
            using A1 A2 sorry
          thus "e inHIDDENR3 succORDINAL1K1 A"
            using A3 ordinal1_th_6 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 psi c=TARSKIR1 succORDINAL1K1 A"
          using tarski_def_3 sorry
      qed
      show "psi be increasingORDINAL2V2"
        using A1 ordinal3_th_14 sorry
      have A4: "psi .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 A"
        using A1 ordinal3_lm_1 ordinal1_th_6 sorry
      have "rngFUNCT-1K2 psi =XBOOLE-0R4 {TARSKIK1 psi .FUNCT-1K1 {}XBOOLE-0K1 }"
        using A1 ordinal3_lm_1 funct_1_th_4 sorry
      thus "succORDINAL1K1 A =HIDDENR1 supORDINAL2K4 psi"
        using A4 ordinal2_th_23 sorry
    qed
    thus "succORDINAL1K1 A is-cofinal-withORDINAL2R2 \<one>\<^sub>M"
      using bexI[of _ "psi"] ordinal2_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal3_th_74:
" for a be OrdinalORDINAL1M3 holds  for b be OrdinalORDINAL1M3 holds a +^ORDINAL2K10 b be naturalORDINAL1V7 implies a inTARSKIR2 omegaORDINAL1K4 & b inTARSKIR2 omegaORDINAL1K4"
  using ordinal3_th_24 ordinal1_th_12 sorry

mtheorem ordinal3_cl_3:
  mlet "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3", "b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
"cluster a -^ORDINAL3K5 b as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "a -^ORDINAL3K5 b be naturalORDINAL1V7"
  proof-
    have " not b c=ORDINAL1R1 a or b c=ORDINAL1R1 a"
       sorry
    then have Cut1669: "a -^ORDINAL3K5 b =XBOOLE-0R4 {}XBOOLE-0K1 or a =XBOOLE-0R4 b +^ORDINAL2K10 (a -^ORDINAL3K5 b)"
      using ordinal3_def_5 sorry
    have "a -^ORDINAL3K5 b inTARSKIR2 omegaORDINAL1K4"
    proof-
      show "a -^ORDINAL3K5 b inTARSKIR2 omegaORDINAL1K4"
        using ordinal3_th_74 ordinal1_def_11 Cut1669 sorry
    qed
    thus "a -^ORDINAL3K5 b be naturalORDINAL1V7"
      using ordinal1_def_12 sorry
  qed
qed "sorry"

mtheorem ordinal3_cl_4:
  mlet "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3", "b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
"cluster a *^ORDINAL2K11 b as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "a *^ORDINAL2K11 b be naturalORDINAL1V7"
  proof-
    let ?P = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 b be naturalORDINAL1V7"
    have A1: " for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a *^ORDINAL2K11 b be naturalORDINAL1V7 implies succORDINAL1K1 a *^ORDINAL2K11 b be naturalORDINAL1V7"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
      assume "?P(a)"
      then obtain c where 
        [ty]:"c be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3" and cDef:"c = a *^ORDINAL2K11 b"
         sorry
      have "succORDINAL1K1 a *^ORDINAL2K11 b =XBOOLE-0R4 c +^ORDINAL2K10 b"
        using ordinal2_th_36 sorry
      thus "succORDINAL1K1 a *^ORDINAL2K11 b be naturalORDINAL1V7"
         sorry
    qed "sorry"
    have A2: "?P(0ORDINAL1K5)"
      using ordinal2_th_35 sorry
    have "?P(a)"
      using ordinal2_sch_17 A2 A1 sorry
    thus "a *^ORDINAL2K11 b be naturalORDINAL1V7"
       sorry
  qed
qed "sorry"

mtheorem ordinal3_th_75:
" for a be OrdinalORDINAL1M3 holds  for b be OrdinalORDINAL1M3 holds a *^ORDINAL2K11 b be naturalORDINAL1V7\<bar> non emptyXBOOLE-0V1 implies a inTARSKIR2 omegaORDINAL1K4 & b inTARSKIR2 omegaORDINAL1K4"
proof-
  have " for x be OrdinalORDINAL1M3 holds  for y be OrdinalORDINAL1M3 holds  not ((x *^ORDINAL2K11 y be naturalORDINAL1V7 &  not x *^ORDINAL2K11 y be emptyXBOOLE-0V1) &  not (x inTARSKIR2 omegaORDINAL1K4 & y inTARSKIR2 omegaORDINAL1K4))"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be OrdinalORDINAL1M3"
    fix y assume [ty]: "y be OrdinalORDINAL1M3"
    have "x *^ORDINAL2K11 y inTARSKIR2 omegaORDINAL1K4 implies (x *^ORDINAL2K11 y be  non emptyXBOOLE-0V1 implies x inTARSKIR2 omegaORDINAL1K4 & y inTARSKIR2 omegaORDINAL1K4)"
    proof(rule impI,rule impI)
      assume A1: "x *^ORDINAL2K11 y inTARSKIR2 omegaORDINAL1K4"
      assume A2: "x *^ORDINAL2K11 y be  non emptyXBOOLE-0V1"
      then have "y <>HIDDENR2 {}XBOOLE-0K1"
        using ordinal2_th_38 sorry
      then have A3: "x c=ORDINAL1R1 x *^ORDINAL2K11 y"
        using ordinal3_th_36 sorry
      have "x <>HIDDENR2 {}XBOOLE-0K1"
        using A2 ordinal2_th_35 sorry
      then have "y c=ORDINAL1R1 x *^ORDINAL2K11 y"
        using ordinal3_th_36 sorry
      thus "x inTARSKIR2 omegaORDINAL1K4 & y inTARSKIR2 omegaORDINAL1K4"
        using A1 A3 ordinal1_th_12 sorry
    qed
    thus " not ((x *^ORDINAL2K11 y be naturalORDINAL1V7 &  not x *^ORDINAL2K11 y be emptyXBOOLE-0V1) &  not (x inTARSKIR2 omegaORDINAL1K4 & y inTARSKIR2 omegaORDINAL1K4))"
      using ordinal1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) ORDINAL3K8(" _ +^ORDINAL3K8  _ " [132,132]132) where
  "a +^ORDINAL3K8 b \<equiv> a +^ORDINAL2K10 b"

mtheorem ORDINAL3K8_commutativity:
" for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds  for b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a +^ORDINAL3K8 b =HIDDENR1 b +^ORDINAL3K8 a"
proof-
  have " for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds  for b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a +^ORDINAL2K10 b =XBOOLE-0R4 b +^ORDINAL2K10 a"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
    fix b assume [ty]: "b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
    let ?R = "\<lambda>Lamb1. a +^ORDINAL2K10 Lamb1 =XBOOLE-0R4 Lamb1 +^ORDINAL2K10 a"
    have A1: " for b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a +^ORDINAL2K10 b =XBOOLE-0R4 b +^ORDINAL2K10 a implies a +^ORDINAL2K10 succORDINAL1K1 b =XBOOLE-0R4 succORDINAL1K1 b +^ORDINAL2K10 a"
    proof(rule ballI,rule impI)
      fix b assume [ty]: "b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
      assume A2: "?R(b)"
      let ?P = "\<lambda>Lamb1. succORDINAL1K1 b +^ORDINAL2K10 Lamb1 =XBOOLE-0R4 succORDINAL1K1 (b +^ORDINAL2K10 Lamb1)"
      have A3: " for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds succORDINAL1K1 b +^ORDINAL2K10 a =XBOOLE-0R4 succORDINAL1K1 (b +^ORDINAL2K10 a) implies succORDINAL1K1 b +^ORDINAL2K10 succORDINAL1K1 a =XBOOLE-0R4 succORDINAL1K1 (b +^ORDINAL2K10 succORDINAL1K1 a)"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
        assume A4: "?P(a)"
        have "succORDINAL1K1 b +^ORDINAL2K10 succORDINAL1K1 a =HIDDENR1 succORDINAL1K1 (succORDINAL1K1 b +^ORDINAL2K10 a)"
          using ordinal2_th_28 sorry
        also have "... = succORDINAL1K1 (b +^ORDINAL2K10 succORDINAL1K1 a)"
          using A4 ordinal2_th_28 sorry
        finally have "succORDINAL1K1 b +^ORDINAL2K10 succORDINAL1K1 a =HIDDENR1 succORDINAL1K1 (b +^ORDINAL2K10 succORDINAL1K1 a)"
           sorry
        thus "succORDINAL1K1 b +^ORDINAL2K10 succORDINAL1K1 a =XBOOLE-0R4 succORDINAL1K1 (b +^ORDINAL2K10 succORDINAL1K1 a)"
           sorry
      qed "sorry"
      have "succORDINAL1K1 b +^ORDINAL2K10 {}XBOOLE-0K1 =HIDDENR1 succORDINAL1K1 b"
        using ordinal2_th_27 sorry
      also have "... = succORDINAL1K1 (b +^ORDINAL2K10 {}XBOOLE-0K1)"
        using ordinal2_th_27 sorry
      finally have "succORDINAL1K1 b +^ORDINAL2K10 {}XBOOLE-0K1 =HIDDENR1 succORDINAL1K1 (b +^ORDINAL2K10 {}XBOOLE-0K1)"
         sorry
      then have A5: "?P(0ORDINAL1K5)"
         sorry
      have "?P(a)"
        using ordinal2_sch_17 A5 A3 sorry
      thus "a +^ORDINAL2K10 succORDINAL1K1 b =XBOOLE-0R4 succORDINAL1K1 b +^ORDINAL2K10 a"
        using A2 ordinal2_th_28 sorry
    qed "sorry"
    have "a +^ORDINAL2K10 {}XBOOLE-0K1 =HIDDENR1 a"
      using ordinal2_th_27 sorry
    also have "... = {}XBOOLE-0K1 +^ORDINAL2K10 a"
      using ordinal2_th_30 sorry
    finally have "a +^ORDINAL2K10 {}XBOOLE-0K1 =HIDDENR1 {}XBOOLE-0K1 +^ORDINAL2K10 a"
       sorry
    then have A6: "?R(0ORDINAL1K5)"
       sorry
    show "a +^ORDINAL2K10 b =XBOOLE-0R4 b +^ORDINAL2K10 a"
      using ordinal2_sch_17 A6 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) ORDINAL3K9(" _ *^ORDINAL3K9  _ " [164,164]164) where
  "a *^ORDINAL3K9 b \<equiv> a *^ORDINAL2K11 b"

mtheorem ORDINAL3K9_commutativity:
" for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds  for b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a *^ORDINAL3K9 b =HIDDENR1 b *^ORDINAL3K9 a"
proof-
  have " for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds  for b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a *^ORDINAL2K11 b =XBOOLE-0R4 b *^ORDINAL2K11 a"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
    fix b assume [ty]: "b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
    let ?R = "\<lambda>Lamb1. a *^ORDINAL2K11 Lamb1 =XBOOLE-0R4 Lamb1 *^ORDINAL2K11 a"
    have A1: " for b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a *^ORDINAL2K11 b =XBOOLE-0R4 b *^ORDINAL2K11 a implies a *^ORDINAL2K11 succORDINAL1K1 b =XBOOLE-0R4 succORDINAL1K1 b *^ORDINAL2K11 a"
    proof(rule ballI,rule impI)
      fix b assume [ty]: "b be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
      let ?P = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 succORDINAL1K1 b =XBOOLE-0R4 Lamb1 *^ORDINAL2K11 b +^ORDINAL3K8 Lamb1"
      assume A2: "?R(b)"
      have A3: " for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a *^ORDINAL2K11 succORDINAL1K1 b =XBOOLE-0R4 a *^ORDINAL2K11 b +^ORDINAL3K8 a implies succORDINAL1K1 a *^ORDINAL2K11 succORDINAL1K1 b =XBOOLE-0R4 succORDINAL1K1 a *^ORDINAL2K11 b +^ORDINAL3K8 succORDINAL1K1 a"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
        assume A4: "?P(a)"
        have "succORDINAL1K1 a *^ORDINAL2K11 succORDINAL1K1 b =HIDDENR1 a *^ORDINAL2K11 succORDINAL1K1 b +^ORDINAL3K8 succORDINAL1K1 b"
          using ordinal2_th_36 sorry
        also have "... = a *^ORDINAL2K11 b +^ORDINAL3K8 (a +^ORDINAL3K8 succORDINAL1K1 b)"
          using A4 ordinal3_th_30 sorry
        also have "... = a *^ORDINAL2K11 b +^ORDINAL3K8 succORDINAL1K1 (a +^ORDINAL3K8 b)"
          using ordinal2_th_28 sorry
        also have "... = succORDINAL1K1 (a *^ORDINAL2K11 b +^ORDINAL3K8 (a +^ORDINAL3K8 b))"
          using ordinal2_th_28 sorry
        also have "... = succORDINAL1K1 ((a *^ORDINAL2K11 b +^ORDINAL3K8 b)+^ORDINAL3K8 a)"
          using ordinal3_th_30 sorry
        also have "... = succORDINAL1K1 (succORDINAL1K1 a *^ORDINAL2K11 b +^ORDINAL3K8 a)"
          using ordinal2_th_36 sorry
        also have "... = succORDINAL1K1 a *^ORDINAL2K11 b +^ORDINAL3K8 succORDINAL1K1 a"
          using ordinal2_th_28 sorry
        finally have "succORDINAL1K1 a *^ORDINAL2K11 succORDINAL1K1 b =HIDDENR1 succORDINAL1K1 a *^ORDINAL2K11 b +^ORDINAL3K8 succORDINAL1K1 a"
           sorry
        thus "succORDINAL1K1 a *^ORDINAL2K11 succORDINAL1K1 b =XBOOLE-0R4 succORDINAL1K1 a *^ORDINAL2K11 b +^ORDINAL3K8 succORDINAL1K1 a"
           sorry
      qed "sorry"
      have "{}XBOOLE-0K1 *^ORDINAL2K11 succORDINAL1K1 b =HIDDENR1 {}XBOOLE-0K1"
        using ordinal2_th_35 sorry
      also have "... = {}XBOOLE-0K1 +^ORDINAL3K8 {}XBOOLE-0K1"
        using ordinal2_th_27 sorry
      also have "... = {}XBOOLE-0K1 *^ORDINAL2K11 b +^ORDINAL3K8 {}XBOOLE-0K1"
        using ordinal2_th_35 sorry
      finally have "{}XBOOLE-0K1 *^ORDINAL2K11 succORDINAL1K1 b =HIDDENR1 {}XBOOLE-0K1 *^ORDINAL2K11 b +^ORDINAL3K8 {}XBOOLE-0K1"
         sorry
      then have A5: "?P(0ORDINAL1K5)"
         sorry
      have "?P(a)"
        using ordinal2_sch_17 A5 A3 sorry
      thus "a *^ORDINAL2K11 succORDINAL1K1 b =XBOOLE-0R4 succORDINAL1K1 b *^ORDINAL2K11 a"
        using A2 ordinal2_th_36 sorry
    qed "sorry"
    have "a *^ORDINAL2K11 {}XBOOLE-0K1 =HIDDENR1 {}XBOOLE-0K1"
      using ordinal2_th_38 sorry
    also have "... = {}XBOOLE-0K1 *^ORDINAL2K11 a"
      using ordinal2_th_35 sorry
    finally have "a *^ORDINAL2K11 {}XBOOLE-0K1 =HIDDENR1 {}XBOOLE-0K1 *^ORDINAL2K11 a"
       sorry
    then have A6: "?R(0ORDINAL1K5)"
       sorry
    show "a *^ORDINAL2K11 b =XBOOLE-0R4 b *^ORDINAL2K11 a"
      using ordinal2_sch_17 A6 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
