theory fdiff_6
  imports int_2 power sin_cos2 fdiff_4
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, a for "RealXREAL-0M1"
reserve n for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve Z for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mlemma fdiff_6_lm_1:
" for x be RealXREAL-0M1 holds \<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x)^2SQUARE-1K1"
proof-
  have " for x be RealXREAL-0M1 holds \<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x)^2SQUARE-1K1"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (x +XCMPLX-0K2 x)"
       sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK20 x)*XCMPLX-0K3 (cosSIN-COSK20 x) -XCMPLX-0K6 (sinSIN-COSK18 x)*XCMPLX-0K3 (sinSIN-COSK18 x))"
      using sin_cos_th_75 sorry
    also have "... = ((cosSIN-COSK20 x)^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 x)^2SQUARE-1K1)-XCMPLX-0K6 ((cosSIN-COSK20 x)^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK18 x)^2SQUARE-1K1)"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x)^2SQUARE-1K1"
       sorry
    finally have "\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x)^2SQUARE-1K1"
       sorry
    thus "\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 x)^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_6_lm_2:
" for x be RealXREAL-0M1 holds \<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x)^2SQUARE-1K1"
proof-
  have " for x be RealXREAL-0M1 holds \<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x)^2SQUARE-1K1"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (x +XCMPLX-0K2 x)"
       sorry
    also have "... = \<one>\<^sub>M +XCMPLX-0K2 ((cosSIN-COSK20 x)^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK18 x)^2SQUARE-1K1)"
      using sin_cos_th_75 sorry
    also have "... = ((cosSIN-COSK20 x)^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 x)^2SQUARE-1K1)+XCMPLX-0K2 ((cosSIN-COSK20 x)^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK18 x)^2SQUARE-1K1)"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x)^2SQUARE-1K1"
       sorry
    finally have "\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x)^2SQUARE-1K1"
       sorry
    thus "\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 x)^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_6_lm_3:
" for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 implies (sinSIN-COSK17).FUNCT-1K1 x =HIDDENR1 ((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 implies (sinSIN-COSK17).FUNCT-1K1 x =HIDDENR1 ((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "(sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    then have "(sinSIN-COSK17).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
      using prepower_th_72 sorry
    also have "... = (((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 prepower_th_91 sorry
    also have "... = (((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 \<one>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 \<one>\<^sub>M)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 prepower_th_75 sorry
    also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 \<one>\<^sub>M)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 prepower_th_72 sorry
    also have "... = ((((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)-XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 prepower_th_72 sorry
    also have "... = (\<one>\<^sub>M ^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_28 sorry
    also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    finally have "(sinSIN-COSK17).FUNCT-1K1 x =HIDDENR1 ((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    thus "(sinSIN-COSK17).FUNCT-1K1 x =HIDDENR1 ((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_6_lm_4:
" for x be RealXREAL-0M1 holds ((sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M implies (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & ((cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "(sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      and A2: "(cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "(cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    have A4: "\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 xreal_1_th_15 sorry
    have "\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A3 xreal_1_th_8 sorry
    then have A5: "(\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x) >XXREAL-0R4 0NUMBERSK6"
      using A4 xreal_1_th_129 sorry
    have "(sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 fdiff_6_lm_3 sorry
    also have "... = (((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A4 A5 prepower_th_80 sorry
    also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A4 xcmplx_1_th_89 sorry
    finally have "(sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    thus "(sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_1:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 a #RPREPOWERK6 x"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 a #RPREPOWERK6 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    have "number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
      using taylor_1_th_11 sorry
    then have "(exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,a to-powerPOWERK2 x)"
      using A1 power_th_55 taylor_1_th_11 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,a #RPREPOWERK6 x)"
      using A1 power_def_2 sorry
    also have "... = a #RPREPOWERK6 x"
      using A1 prepower_th_81 taylor_1_th_15 sorry
    finally have "(exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 a #RPREPOWERK6 x"
       sorry
    thus "(exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 a #RPREPOWERK6 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_2:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    have A1: "number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
      using taylor_1_th_11 sorry
    assume A2: "a >XXREAL-0R4 0NUMBERSK6"
    have "(exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 x)*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
       sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,a to-powerPOWERK2 (-XCMPLX-0K4 x))"
      using A2 A1 power_th_55 taylor_1_th_11 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,a #RPREPOWERK6 (-XCMPLX-0K4 x))"
      using A2 power_def_2 sorry
    also have "... = a #RPREPOWERK6 (-XCMPLX-0K4 x)"
      using A2 prepower_th_81 taylor_1_th_15 sorry
    finally have "(exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
       sorry
    thus "(exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) =HIDDENR1 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_6_lm_5:
" for x be RealXREAL-0M1 holds ((sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M implies (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & ((cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "(sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      and A2: "(cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "(cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    have A4: "\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A3 xreal_1_th_8 sorry
    have "\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 xreal_1_th_15 sorry
    then have A5: "(\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x) >XXREAL-0R4 0NUMBERSK6"
      using A4 xreal_1_th_129 sorry
    have "(sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 fdiff_6_lm_3 sorry
    also have "... = (((\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A4 A5 prepower_th_80 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A4 xcmplx_1_th_89 sorry
    finally have "(sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    thus "(sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_3:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x"
      using A2 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 x"
        using A1 A3 A4 fdiff_4_th_12 sorry
      also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
      finally show "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x))"
      using A1 A3 A4 fdiff_4_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_4:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))\<^esub> (domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A1 rfunct_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_18 sorry
    then have A7: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 fdiff_4_th_17 sorry
    have A8: "Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A5 xboole_1_th_1 sorry
    then have A9: "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 fdiff_6_th_3 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A3 sorry
    then have A11: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A7 A9 fdiff_2_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A12: "f2 .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A2 taylor_1_def_1 sorry
      also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      finally have "f2 .FUNCT-1K1 x =HIDDENR1 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      assume A13: "x inHIDDENR3 Z"
      then have A14: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A3 sorry
      have A15: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A8 A13 valued_1_th_13 sorry
      also have "... = a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M"
        using A3 A13 A12 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      have A16: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
        using A6 A13 valued_1_def_1 sorry
      also have "... = a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
        using A3 A13 A12 sorry
      finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x"
        using A7 A9 A13 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 ((diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)^2SQUARE-1K1"
        using A14 fdiff_2_th_14 sorry
      also have "... = (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))*XCMPLX-0K3 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 A13 fdiff_1_def_7 sorry
      also have "... = (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)^2SQUARE-1K1"
        using A9 A13 fdiff_1_def_7 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)^2SQUARE-1K1"
        using A2 A6 A4 A13 fdiff_4_th_17 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)/XCMPLX-0K7 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)^2SQUARE-1K1"
        using A2 A8 A4 A13 fdiff_6_th_3 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
        using A16 A15 sorry
      finally have "diffFDIFF-1K1((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
         sorry
      thus "(((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
        using A11 A13 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1))"
      using A7 A9 A10 fdiff_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_5:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 f & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 0NUMBERSK6) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 0NUMBERSK6))) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      using A1 A2 funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      using tarski_def_3 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))\<^esub> (domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_1 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A4 sorry
    then have A9: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A3 A5 fdiff_6_th_4 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A6 xboole_1_th_18 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A12: "f2 .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<two>\<^sub>M"
          using A3 taylor_1_def_1 sorry
        also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
          using prepower_th_36 sorry
        finally have "f2 .FUNCT-1K1 x =HIDDENR1 x  |^NEWTONK1 \<two>\<^sub>M"
           sorry
        assume A13: "x inHIDDENR3 Z"
        then have A14: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A4 sorry
        have "a <>HIDDENR2 0NUMBERSK6"
          using A4 A13 sorry
        then have A15: "a ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
          using square_1_th_12 sorry
        have "x  |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 x ^2SQUARE-1K1"
          using newton_th_81 sorry
        then have A16: "a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
          using A15 xreal_1_th_8 xreal_1_th_63 sorry
        have A17: "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using A5 A13 rfunct_1_def_1 sorry
        also have "... = (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
          using xcmplx_0_def_9 sorry
        finally have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x /XCMPLX-0K7 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
           sorry
        have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
          using A10 A13 valued_1_def_1 sorry
        also have "... = a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
          using A4 A13 A12 sorry
        finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
           sorry
        thus " not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A14 A16 A17 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A18: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x & ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A11 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A19: "f is-differentiable-onFDIFF-1R2 Z"
      using A1 A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A20: "(a ^2SQUARE-1K1)^2SQUARE-1K1 =HIDDENR1 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1"
        using newton_th_81 sorry
      also have "... = a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M"
        using newton_th_81 sorry
      also have "... = (a  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M"
        using wsierp_1_th_1 sorry
      also have "... = a  |^NEWTONK1 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
        using newton_th_9 sorry
      also have "... = a  |^NEWTONK1 \<four>\<^sub>M"
         sorry
      finally have "(a ^2SQUARE-1K1)^2SQUARE-1K1 =HIDDENR1 a  |^NEWTONK1 \<four>\<^sub>M"
         sorry
      have A21: "(x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1 =HIDDENR1 (x  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M"
        using wsierp_1_th_1 sorry
      also have "... = x  |^NEWTONK1 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
        using newton_th_9 sorry
      also have "... = x  |^NEWTONK1 \<four>\<^sub>M"
         sorry
      finally have "(x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1 =HIDDENR1 x  |^NEWTONK1 \<four>\<^sub>M"
         sorry
      have A22: "f2 .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A3 taylor_1_def_1 sorry
      also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      finally have "f2 .FUNCT-1K1 x =HIDDENR1 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      assume A23: "x inHIDDENR3 Z"
      then have A24: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
        using A10 valued_1_def_1 sorry
      also have "... = a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
        using A4 A23 A22 sorry
      finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      have A25: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A7 A23 valued_1_th_13 sorry
      also have "... = a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M"
        using A4 A23 A22 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      then have A26: "a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
        using A4 A23 sorry
      have A27: "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A5 A23 rfunct_1_def_1 sorry
      also have "... = (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)"
        using A24 A25 xcmplx_0_def_9 sorry
      finally have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x =HIDDENR1 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)"
         sorry
      have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x & ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A11 A23 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)),x) =HIDDENR1 (diffFDIFF-1K1((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x))/XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x"
        using A9 A23 fdiff_1_def_7 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M))"
        using A3 A5 A8 A23 A27 fdiff_6_th_4 sorry
      also have "... = ((((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M))/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M))/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M))"
        using xcmplx_1_th_78 sorry
      also have "... = ((((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M))/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)))/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)"
        using xcmplx_1_th_48 sorry
      also have "... = (((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M))/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)"
        using A26 xcmplx_1_th_55 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M))"
        using xcmplx_1_th_78 sorry
      also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
        using A20 A21 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)),x) =HIDDENR1 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
         sorry
      thus "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
        using A2 A19 A23 fdiff_1_def_7 sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)))"
      using A1 A2 A18 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_6:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ((f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 0NUMBERSK6)) implies (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using A1 valued_1_def_5 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_6_th_5 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "a <>HIDDENR2 0NUMBERSK6"
        using A3 sorry
      then have "a ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using square_1_th_12 sorry
      then have A7: "\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1 >XXREAL-0R4 \<four>\<^sub>M *NAT-1K2 (0NUMBERSK6)"
        using xreal_1_th_68 sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A1 A5 A6 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A6 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))*XCMPLX-0K3 (((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 x)/XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M))"
        using A2 A3 A4 A6 fdiff_6_th_5 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))*XCMPLX-0K3 ((\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 (x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)))"
        using xcmplx_1_th_74 sorry
      also have "... = (x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))"
         sorry
      also have "... = x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
        using A7 xcmplx_1_th_108 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<four>\<^sub>M)))"
      using A1 A5 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_7:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & f1 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & x <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & (f1 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & x <>HIDDENR2 0NUMBERSK6)) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
      and A2: "f1 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & x <>HIDDENR2 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))\<^esub> (domRELAT-1K1 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K6 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A1 rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using xboole_1_th_1 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 is-differentiable-inFDIFF-1R1 x"
      using A2 taylor_1_th_2 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 f1"
      using A4 xboole_1_th_18 sorry
    then have A7: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "\<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using prepower_th_35 sorry
      then have A9: "diffFDIFF-1K1(f1,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A2 taylor_1_th_2 sorry
      assume "x inHIDDENR3 Z"
      thus "(f1 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A7 A9 fdiff_1_def_7 sorry
    qed "sorry"
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M ^2SQUARE-1K1"
      using A3 sorry
    then have A11: "f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A2 A5 fdiff_4_th_17 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A13: "\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
          using xreal_1_th_8 xreal_1_th_63 sorry
        assume A14: "x inHIDDENR3 Z"
        then have "(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x +XCMPLX-0K2 f1 .FUNCT-1K1 x"
          using A5 valued_1_def_1 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 f1 .FUNCT-1K1 x"
          using A3 A14 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M"
          using A2 taylor_1_def_1 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
          using prepower_th_36 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1"
          using newton_th_81 sorry
        finally have "(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1"
           sorry
        thus " not (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using A13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A15: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-onFDIFF-1R2 Z"
      using A11 A7 fdiff_2_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A16: "f1 is-differentiable-inFDIFF-1R1 x"
        using A2 taylor_1_th_2 sorry
      have A17: "f1 .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A2 taylor_1_def_1 sorry
      also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      also have "... = x ^2SQUARE-1K1"
        using newton_th_81 sorry
      finally have "f1 .FUNCT-1K1 x =HIDDENR1 x ^2SQUARE-1K1"
         sorry
      assume A18: "x inHIDDENR3 Z"
      then have A19: "(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x +XCMPLX-0K2 f1 .FUNCT-1K1 x"
        using A5 valued_1_def_1 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 f1 .FUNCT-1K1 x"
        using A3 A18 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A2 taylor_1_def_1 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1"
        using newton_th_81 sorry
      finally have "(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1"
         sorry
      have "f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x & (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A11 A12 A18 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1),x) =HIDDENR1 ((diffFDIFF-1K1(f1,x))*XCMPLX-0K3 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 ((f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)^2SQUARE-1K1"
        using A16 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 ((f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 A18 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x -XCMPLX-0K6 ((f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 ((f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)^2SQUARE-1K1"
        using A11 A18 fdiff_1_def_7 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x -XCMPLX-0K6 ((f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 ((f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 A18 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 x ^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1"
        using A2 A10 A5 A18 A17 A19 fdiff_4_th_17 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1"
         sorry
      finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1),x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1"
         sorry
      thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1"
        using A15 A18 fdiff_1_def_7 sorry
    qed "sorry"
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1))"
      using A11 A7 A12 fdiff_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_8:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & f1 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & x <>HIDDENR2 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & (f1 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & x <>HIDDENR2 0NUMBERSK6))) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
      and A3: "f1 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & x <>HIDDENR2 0NUMBERSK6"
    have A5: "Z c=TARSKIR1 domRELAT-1K1 f"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
      using A2 funct_1_th_11 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
      using tarski_def_3 sorry
    then have A7: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-onFDIFF-1R2 Z"
      using A3 A4 fdiff_6_th_7 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))\<^esub> (domRELAT-1K1 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) \\SUBSET-1K6 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A6 rfunct_1_def_1 sorry
    then have A8: "Z c=TARSKIR1 domRELAT-1K1 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using xboole_1_th_1 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A10: "x inHIDDENR3 Z"
        then have A11: "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 ((f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using A6 rfunct_1_def_1 sorry
        also have "... = f1 .FUNCT-1K1 x /XCMPLX-0K7 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x"
          using xcmplx_0_def_9 sorry
        finally have "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x /XCMPLX-0K7 (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x"
           sorry
        have A12: "x <>HIDDENR2 0NUMBERSK6"
          using A4 A10 sorry
        then have A13: "\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
          using square_1_th_12 xreal_1_th_8 sorry
        have A14: "f1 .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<two>\<^sub>M"
          using A3 taylor_1_def_1 sorry
        also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
          using prepower_th_36 sorry
        also have "... = x ^2SQUARE-1K1"
          using newton_th_81 sorry
        finally have "f1 .FUNCT-1K1 x =HIDDENR1 x ^2SQUARE-1K1"
           sorry
        then have A15: "f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A12 square_1_th_12 sorry
        have "(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x +XCMPLX-0K2 f1 .FUNCT-1K1 x"
          using A8 A10 valued_1_def_1 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1"
          using A4 A10 A14 sorry
        finally have "(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1"
           sorry
        thus " not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A15 A13 A11 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A7 A9 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A16: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A5 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A17: "f1 .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A3 taylor_1_def_1 sorry
      also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      also have "... = x ^2SQUARE-1K1"
        using newton_th_81 sorry
      finally have "f1 .FUNCT-1K1 x =HIDDENR1 x ^2SQUARE-1K1"
         sorry
      assume A18: "x inHIDDENR3 Z"
      then have A19: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A7 A9 fdiff_1_th_9 sorry
      have "x <>HIDDENR2 0NUMBERSK6"
        using A4 A18 sorry
      then have A20: "\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
        using square_1_th_12 xreal_1_th_8 sorry
      have A21: "(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x +XCMPLX-0K2 f1 .FUNCT-1K1 x"
        using A8 A18 valued_1_def_1 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1"
        using A4 A18 A17 sorry
      finally have "(f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1"
         sorry
      have A22: "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 ((f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A6 A18 rfunct_1_def_1 sorry
      also have "... = x ^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)"
        using A17 A21 xcmplx_0_def_9 sorry
      finally have "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x =HIDDENR1 x ^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)"
         sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)),x))"
        using A1 A2 A16 A18 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1),x))/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)"
        using A19 taylor_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)"
        using A7 A18 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1)/XCMPLX-0K7 (x ^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)))"
        using A3 A4 A6 A18 A22 fdiff_6_th_7 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1))/XCMPLX-0K7 (x ^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
        using xcmplx_1_th_74 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)^2SQUARE-1K1)/XCMPLX-0K7 (x ^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
        using xcmplx_1_th_74 sorry
      also have "... = ((x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 (x ^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
        using xcmplx_1_th_78 sorry
      also have "... = ((x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))/XCMPLX-0K7 (x ^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)"
        using xcmplx_1_th_48 sorry
      also have "... = (x /XCMPLX-0K7 x ^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)"
        using A20 xcmplx_1_th_55 sorry
      also have "... = ((x /XCMPLX-0K7 x)/XCMPLX-0K7 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)"
        using A4 A18 xcmplx_1_th_60 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
        using xcmplx_1_th_78 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1))))"
      using A1 A16 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_9:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n /XCMPLX-0K7 x)"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n /XCMPLX-0K7 x))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A4: "#ZTAYLOR-1K1 n .FUNCT-1K1 x =XBOOLE-0R4 x #ZPREPOWERK3 n"
        using taylor_1_def_1 sorry
      assume "x inHIDDENR3 Z"
      then have "#ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 x & #ZTAYLOR-1K1 n .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A4 prepower_th_39 taylor_1_th_2 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A5: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A6: "#ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 n,x) =HIDDENR1 n *XCMPLX-0K3 x #ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M)"
        using taylor_1_th_2 sorry
      assume A7: "x inHIDDENR3 Z"
      then have A8: "x >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      have A9: "x  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
        using A2 A7 newton_th_83 sorry
      have A10: "#ZTAYLOR-1K1 n .FUNCT-1K1 x =XBOOLE-0R4 x #ZPREPOWERK3 n"
        using taylor_1_def_1 sorry
      then have "#ZTAYLOR-1K1 n .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A7 prepower_th_39 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n,x) =HIDDENR1 (n *XCMPLX-0K3 x #ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 x #ZPREPOWERK3 n"
        using A6 A10 taylor_1_th_20 sorry
      also have "... = (n *XCMPLX-0K3 x #ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 x  |^NEWTONK1 n"
        using prepower_th_36 sorry
      also have "... = (n *XCMPLX-0K3 (x  |^NEWTONK1 n /XCMPLX-0K7 x  |^NEWTONK1 \<one>\<^sub>M))/XCMPLX-0K7 x  |^NEWTONK1 n"
        using A8 prepower_th_43 sorry
      also have "... = n *XCMPLX-0K3 ((x  |^NEWTONK1 n /XCMPLX-0K7 x  |^NEWTONK1 \<one>\<^sub>M)/XCMPLX-0K7 x  |^NEWTONK1 n)"
        using xcmplx_1_th_74 sorry
      also have "... = n *XCMPLX-0K3 ((x  |^NEWTONK1 n /XCMPLX-0K7 x  |^NEWTONK1 n)/XCMPLX-0K7 x  |^NEWTONK1 \<one>\<^sub>M)"
        using xcmplx_1_th_48 sorry
      also have "... = n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x  |^NEWTONK1 \<one>\<^sub>M)"
        using A9 xcmplx_1_th_60 sorry
      also have "... = n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
         sorry
      also have "... = (n *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 x"
        using xcmplx_1_th_74 sorry
      also have "... = n /XCMPLX-0K7 x"
         sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n,x) =HIDDENR1 n /XCMPLX-0K7 x"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n /XCMPLX-0K7 x"
        using A5 A7 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 n)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 n /XCMPLX-0K7 x))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_10:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f2 .FUNCT-1K1 x =HIDDENR1 x & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M) & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f2 .FUNCT-1K1 x =HIDDENR1 x & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M) & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f2 .FUNCT-1K1 x =HIDDENR1 x & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M) & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\XBOOLE-0K3 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      using A1 valued_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      using xboole_1_th_18 sorry
    have A5: "domRELAT-1K1 (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELAT-1K1 f2"
      using rfunct_1_th_1 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A3 xboole_1_th_18 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A5 xboole_1_th_1 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 0NUMBERSK6) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A2 sorry
    then have A8: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_4_th_24 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 0NUMBERSK6 +XCMPLX-0K2 x & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A10: "f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_4_th_14 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      then have A12: "f2 .FUNCT-1K1 x =HIDDENR1 x & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      have A13: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A11 sorry
      have "((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x) +XCMPLX-0K2 diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x)"
        using A1 A10 A8 A11 fdiff_1_th_18 sorry
      also have "... = ((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x)"
        using A10 A11 fdiff_1_def_7 sorry
      also have "... = ((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A11 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (0NUMBERSK6 +XCMPLX-0K2 x)^2SQUARE-1K1)+XCMPLX-0K2 (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A9 A11 fdiff_4_th_14 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (0NUMBERSK6 +XCMPLX-0K2 x)^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 0NUMBERSK6)/XCMPLX-0K7 ((x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (x -XCMPLX-0K6 0NUMBERSK6))"
        using A4 A7 A11 fdiff_4_th_24 sorry
      also have "... = (-XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M)))+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 x)"
        using A13 xcmplx_1_th_91 sorry
      also have "... = (-XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M)))+XCMPLX-0K2 (\<one>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (((x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 x)*XCMPLX-0K3 x)"
        using A12 xcmplx_1_th_91 sorry
      also have "... = (-XCMPLX-0K4 (x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M)) +XCMPLX-0K2 x /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))"
        using xcmplx_1_th_187 sorry
      also have "... = (((-XCMPLX-0K4 x)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 x)/XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))"
        using xcmplx_1_th_62 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))"
         sorry
      finally have "((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))"
         sorry
      thus "((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))"
         sorry
    qed "sorry"
    thus "f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 (x -XCMPLX-0K6 \<one>\<^sub>M))))"
      using A1 A10 A8 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_11:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))) & a >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) & a >XXREAL-0R4 0NUMBERSK6) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      and A3: "a >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 logPOWERK3(number-ePOWERK4,a) *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using A2 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A6 fdiff_1_th_9 sorry
      thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_19 sorry
    qed "sorry"
    then have A8: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A6 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using taylor_1_th_19 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A9 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
        using A4 A5 A9 fdiff_1_th_23 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
        using A2 A9 sorry
      also have "... = a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
        using A3 fdiff_6_th_1 sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
         sorry
      thus "(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
        using A8 A9 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))"
      using A1 A7 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_12:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))) & a >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 a #RPREPOWERK6 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a)) & (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M)) implies (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 a #RPREPOWERK6 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a)"
      and A3: "a >XXREAL-0R4 0NUMBERSK6"
      and A4: "a <>HIDDENR2 \<one>\<^sub>M"
    have A5: "Z c=TARSKIR1 domRELAT-1K1 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 valued_1_def_5 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_4 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using xboole_1_th_18 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A9: "\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a)) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a)"
         sorry
      assume "x inHIDDENR3 Z"
      thus "f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))"
        using A2 A9 sorry
    qed "sorry"
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      using A2 sorry
    then have A11: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A3 A7 fdiff_6_th_11 sorry
    have A12: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A6 xboole_1_th_18 sorry
    then have A13: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A8 fdiff_1_th_23 sorry
    then have A14: "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A5 A11 fdiff_1_th_21 sorry
    have A15: "logPOWERK3(number-ePOWERK4,a) <>HIDDENR2 0NUMBERSK6"
    proof-
      have "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 0NUMBERSK6 implies  False "
      proof(rule impI)
        have A16: "number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
          using taylor_1_th_11 sorry
        assume "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 0NUMBERSK6"
        then have "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 logPOWERK3(number-ePOWERK4,\<one>\<^sub>M)"
          using sin_cos2_th_13 taylor_1_th_13 sorry
        then have "a =HIDDENR1 (number-ePOWERK4)to-powerPOWERK2 logPOWERK3(number-ePOWERK4,\<one>\<^sub>M)"
          using A3 A16 power_def_3 taylor_1_th_11 sorry
        also have "... = \<one>\<^sub>M"
          using A16 power_def_3 taylor_1_th_11 sorry
        finally have "a =HIDDENR1 \<one>\<^sub>M"
           sorry
        thus " False "
          using A4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 a #RPREPOWERK6 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A17: "x inHIDDENR3 Z"
      then have A18: "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
        using A7 funct_1_th_12 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
        using A2 A17 sorry
      also have "... = a #RPREPOWERK6 x"
        using A3 fdiff_6_th_1 sorry
      finally have "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 x"
         sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (diffFDIFF-1K1(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A1 A14 A17 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 ((((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A14 A17 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x)) +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x)))"
        using A5 A11 A13 A17 fdiff_1_th_21 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x)))"
        using A11 A17 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A13 A17 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 (a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A3 A10 A7 A17 fdiff_6_th_11 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 (a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M)"
        using A12 A8 A17 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 ((f2 .FUNCT-1K1 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 a #RPREPOWERK6 x)"
        using A18 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (((x -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 a #RPREPOWERK6 x)"
        using A2 A17 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 ((x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))+XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 a #RPREPOWERK6 x"
         sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 ((x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 a #RPREPOWERK6 x"
        using A15 xcmplx_1_th_106 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 x)*XCMPLX-0K3 a #RPREPOWERK6 x"
         sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 a #RPREPOWERK6 x"
        using A15 xcmplx_1_th_106 sorry
      also have "... = x *XCMPLX-0K3 a #RPREPOWERK6 x"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x *XCMPLX-0K3 a #RPREPOWERK6 x"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 a #RPREPOWERK6 x"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 a #RPREPOWERK6 x))"
      using A1 A14 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_13:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))) & a >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 \<one>\<^sub>M /XCMPLX-0K7 (number-ePOWERK4) implies (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) & (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M /XCMPLX-0K7 (number-ePOWERK4))) implies (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      and A3: "a >XXREAL-0R4 0NUMBERSK6"
      and A4: "a <>HIDDENR2 \<one>\<^sub>M /XCMPLX-0K7 (number-ePOWERK4)"
    have A5: "Z c=TARSKIR1 domRELAT-1K1 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using A1 valued_1_def_5 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\XBOOLE-0K3 domRELAT-1K1 (exp-RSIN-COSK23)"
      using valued_1_def_4 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A7: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_6_th_11 sorry
    have A8: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A9: "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A5 A7 fdiff_1_th_21 sorry
    have A10: "\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a) <>HIDDENR2 0NUMBERSK6"
    proof-
      have "\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a) =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        have A11: "(number-ePOWERK4)*XCMPLX-0K3 a >XXREAL-0R4 (0NUMBERSK6)*XCMPLX-0K3 a"
          using A3 taylor_1_th_11 xreal_1_th_68 sorry
        assume A12: "\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a) =XBOOLE-0R4 0NUMBERSK6"
        have A13: "number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
          using taylor_1_th_11 sorry
        have "logPOWERK3(number-ePOWERK4,\<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
          using sin_cos2_th_13 taylor_1_th_13 sorry
        also have "... = logPOWERK3(number-ePOWERK4,number-ePOWERK4) +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)"
          using A12 A13 power_th_52 taylor_1_th_11 sorry
        also have "... = logPOWERK3(number-ePOWERK4,(number-ePOWERK4)*XCMPLX-0K3 a)"
          using A3 A13 power_th_53 taylor_1_th_11 sorry
        finally have "logPOWERK3(number-ePOWERK4,\<one>\<^sub>M) =HIDDENR1 logPOWERK3(number-ePOWERK4,(number-ePOWERK4)*XCMPLX-0K3 a)"
           sorry
        then have "(number-ePOWERK4)*XCMPLX-0K3 a =HIDDENR1 (number-ePOWERK4)to-powerPOWERK2 logPOWERK3(number-ePOWERK4,\<one>\<^sub>M)"
          using A13 A11 power_def_3 taylor_1_th_11 sorry
        also have "... = \<one>\<^sub>M"
          using A13 power_def_3 taylor_1_th_11 sorry
        finally have "(number-ePOWERK4)*XCMPLX-0K3 a =HIDDENR1 \<one>\<^sub>M"
           sorry
        thus " False "
          using A4 xcmplx_1_th_73 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x)"
        using A6 funct_1_th_12 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
        using A2 A14 sorry
      also have "... = a #RPREPOWERK6 x"
        using A3 fdiff_6_th_1 sorry
      finally have "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 x"
         sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (diffFDIFF-1K1(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x))"
        using A1 A9 A14 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 ((((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A14 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)))"
        using A5 A7 A8 A14 fdiff_1_th_21 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)))"
        using A7 A14 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using taylor_1_th_16 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (((((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 ((a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A2 A3 A6 A14 fdiff_6_th_11 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (logPOWERK3(number-ePOWERK4,a) +XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 a #RPREPOWERK6 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A15 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a #RPREPOWERK6 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A10 xcmplx_1_th_106 sorry
      also have "... = a #RPREPOWERK6 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))"
      using A1 A9 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_14:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x"
        using A2 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      finally have "f .FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
    qed "sorry"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_1_th_9 sorry
      thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_19 sorry
    qed "sorry"
    then have A7: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using taylor_1_th_19 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A8 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A4 A3 A8 fdiff_1_th_23 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A2 A8 sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x)"
         sorry
      also have "... = -XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
        using sin_cos_def_23 sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
         sorry
      thus "(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
        using A7 A8 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_15:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M & f2 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (exp-RSIN-COSK24 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M & f2 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (exp-RSIN-COSK24 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M & f2 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A3 xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 .FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M"
        using A2 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
         sorry
      finally have "f1 .FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
         sorry
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    then have A7: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x"
      using A2 sorry
    then have A9: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_6_th_14 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (exp-RSIN-COSK24 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f2 .FUNCT-1K1 x)"
        using A5 funct_1_th_12 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x)"
        using A2 A10 sorry
      also have "... = exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
        using sin_cos_def_23 sorry
      finally have "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
         sorry
      have "((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 f1 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A1 A7 A9 A10 fdiff_1_th_21 sorry
      also have "... = (exp-RSIN-COSK24 (-XCMPLX-0K4 x))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x)) +XCMPLX-0K2 ((-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A2 A10 A11 sorry
      also have "... = (exp-RSIN-COSK24 (-XCMPLX-0K4 x))*XCMPLX-0K3 (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK24 (-XCMPLX-0K4 x))*XCMPLX-0K3 (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A10 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK24 (-XCMPLX-0K4 x))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) +XCMPLX-0K2 ((-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A6 A10 fdiff_1_th_23 sorry
      also have "... = (exp-RSIN-COSK24 (-XCMPLX-0K4 x))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) +XCMPLX-0K2 ((-XCMPLX-0K4 x)-XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
        using A8 A5 A10 fdiff_6_th_14 sorry
      also have "... = x *XCMPLX-0K3 (exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
         sorry
      also have "... = x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using taylor_1_th_4 sorry
      also have "... = x /XCMPLX-0K7 (exp-RSIN-COSK24 x)"
        using xcmplx_1_th_99 sorry
      finally have "((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 (exp-RSIN-COSK24 x)"
         sorry
      thus "((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (exp-RSIN-COSK24 x)"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (exp-RSIN-COSK24 x)))"
      using A1 A7 A9 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_16:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))) & a >XXREAL-0R4 0NUMBERSK6 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) & a >XXREAL-0R4 0NUMBERSK6) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      and A3: "a >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_th_8 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 logPOWERK3(number-ePOWERK4,a) *XCMPLX-0K3 x"
        using A2 sorry
      also have "... = (-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      finally have "f .FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
    qed "sorry"
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A7 fdiff_1_th_9 sorry
      thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_19 sorry
    qed "sorry"
    then have A8: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f is-differentiable-inFDIFF-1R1 x"
        using A7 fdiff_1_th_9 sorry
      have "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A8 A10 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
        using A11 taylor_1_th_19 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,a)))"
        using A5 A6 A10 fdiff_1_th_23 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) *XCMPLX-0K3 (-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,a)))"
        using A2 A10 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 (-XCMPLX-0K4 logPOWERK3(number-ePOWERK4,a)))"
        using A3 fdiff_6_th_2 sorry
      also have "... = a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
         sorry
      finally have "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
         sorry
      thus "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
         sorry
    qed "sorry"
    have "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using A1 sorry
    thus "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))"
      using A8 A9 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_17:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))) & a >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 a #RPREPOWERK6 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a)) & (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M)) implies (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 a #RPREPOWERK6 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a)"
      and A3: "a >XXREAL-0R4 0NUMBERSK6"
      and A4: "a <>HIDDENR2 \<one>\<^sub>M"
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a)"
      using A2 sorry
    have A6: "Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 valued_1_def_5 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_4 sorry
    then have A8: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using xboole_1_th_18 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      using A2 sorry
    then have A10: "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A3 A8 fdiff_6_th_16 sorry
    have A11: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A7 xboole_1_th_18 sorry
    then have A12: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_23 sorry
    then have A13: "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A6 A10 fdiff_1_th_21 sorry
    have A14: "logPOWERK3(number-ePOWERK4,a) <>HIDDENR2 0NUMBERSK6"
    proof-
      have "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 0NUMBERSK6 implies  False "
      proof(rule impI)
        have A15: "number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
          using taylor_1_th_11 sorry
        assume "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 0NUMBERSK6"
        then have "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 logPOWERK3(number-ePOWERK4,\<one>\<^sub>M)"
          using sin_cos2_th_13 taylor_1_th_13 sorry
        then have "a =HIDDENR1 (number-ePOWERK4)to-powerPOWERK2 logPOWERK3(number-ePOWERK4,\<one>\<^sub>M)"
          using A3 A15 power_def_3 taylor_1_th_11 sorry
        also have "... = \<one>\<^sub>M"
          using A15 power_def_3 taylor_1_th_11 sorry
        finally have "a =HIDDENR1 \<one>\<^sub>M"
           sorry
        thus " False "
          using A4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 a #RPREPOWERK6 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A16: "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A8 sorry
      then have A17: "x inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using valued_1_th_8 sorry
      have A18: "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x"
        using valued_1_th_8 sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
        using A17 funct_1_th_12 sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
        using A2 A16 sorry
      also have "... = -XCMPLX-0K4 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
        using A3 fdiff_6_th_2 sorry
      finally have "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
         sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (diffFDIFF-1K1((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A1 A13 A16 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A13 A16 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x)) +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x)))"
        using A6 A10 A12 A16 fdiff_1_th_21 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f2,x)))"
        using A10 A16 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A12 A16 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 (a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A3 A9 A8 A16 fdiff_6_th_16 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (f2 .FUNCT-1K1 x *XCMPLX-0K3 (a #RPREPOWERK6 (-XCMPLX-0K4 x) *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M)"
        using A11 A5 A16 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 ((f2 .FUNCT-1K1 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 a #RPREPOWERK6 (-XCMPLX-0K4 x))"
        using A18 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (((x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 a #RPREPOWERK6 (-XCMPLX-0K4 x))"
        using A2 A16 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 ((x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))-XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
         sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 ((x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
        using A14 xcmplx_1_th_106 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 x)*XCMPLX-0K3 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
         sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 a #RPREPOWERK6 (-XCMPLX-0K4 x)"
        using A14 xcmplx_1_th_106 sorry
      also have "... = x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 x)"
        using A3 prepower_th_76 sorry
      also have "... = x /XCMPLX-0K7 a #RPREPOWERK6 x"
        using xcmplx_1_th_99 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a #RPREPOWERK6 x"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 a #RPREPOWERK6 x"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 logPOWERK3(number-ePOWERK4,a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 a #RPREPOWERK6 x))"
      using A1 A13 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_18:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))) & a >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 number-ePOWERK4 implies (\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) & (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 number-ePOWERK4)) implies (\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      and A3: "a >XXREAL-0R4 0NUMBERSK6"
      and A4: "a <>HIDDENR2 number-ePOWERK4"
    have "Z c=TARSKIR1 domRELAT-1K1 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using A1 valued_1_def_5 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (exp-RSIN-COSK23))\<^esub> (domRELAT-1K1 (exp-RSIN-COSK23) \\SUBSET-1K6 (exp-RSIN-COSK23)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A6: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_6_th_11 sorry
    have "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
      using fdiff_1_th_26 sin_cos_th_54 taylor_1_th_16 sorry
    then have A7: "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_2_th_21 sorry
    have A8: "logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6"
    proof-
      have "logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        have A9: "number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
          using taylor_1_th_11 sorry
        assume "logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
        then have "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 logPOWERK3(number-ePOWERK4,number-ePOWERK4)"
          using A9 power_th_52 taylor_1_th_11 sorry
        then have "a =HIDDENR1 (number-ePOWERK4)to-powerPOWERK2 logPOWERK3(number-ePOWERK4,number-ePOWERK4)"
          using A3 A9 power_def_3 taylor_1_th_11 sorry
        also have "... = number-ePOWERK4"
          using A9 power_def_3 taylor_1_th_11 sorry
        finally have "a =HIDDENR1 number-ePOWERK4"
           sorry
        thus " False "
          using A4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A10: "(exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using sin_cos_th_54 sorry
      assume A11: "x inHIDDENR3 Z"
      then have A12: "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x)"
        using A5 funct_1_th_12 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
        using A2 A11 sorry
      also have "... = a #RPREPOWERK6 x"
        using A3 fdiff_6_th_1 sorry
      finally have "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 x"
         sorry
      have A13: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A6 A11 fdiff_1_th_9 sin_cos_th_65 sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x))"
        using A1 A7 A11 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (((diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A13 A10 fdiff_2_th_14 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (((diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 a #RPREPOWERK6 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A12 sin_cos_th_65 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (((diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) -XCMPLX-0K6 a #RPREPOWERK6 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))"
         sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) -XCMPLX-0K6 a #RPREPOWERK6 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A10 xcmplx_1_th_91 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) -XCMPLX-0K6 a #RPREPOWERK6 x))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using xcmplx_1_th_74 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 a #RPREPOWERK6 x))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A6 A11 fdiff_1_def_7 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 a #RPREPOWERK6 x))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A2 A3 A5 A11 fdiff_6_th_11 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 a #RPREPOWERK6 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a #RPREPOWERK6 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A8 xcmplx_1_th_106 sorry
      also have "... = a #RPREPOWERK6 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (logPOWERK3(number-ePOWERK4,a) -XCMPLX-0K6 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x))"
      using A1 A7 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_19:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))) & a >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 number-ePOWERK4 implies (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 a #RPREPOWERK6 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) & (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 number-ePOWERK4)) implies (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 a #RPREPOWERK6 x))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      and A3: "a >XXREAL-0R4 0NUMBERSK6"
      and A4: "a <>HIDDENR2 number-ePOWERK4"
    have "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using A1 valued_1_def_5 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))\<^esub> (domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_1 sorry
    then have A6: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_6_th_11 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A5 funct_1_th_12 sorry
        thus " not ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using sin_cos_th_54 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A8: "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A6 A7 fdiff_2_th_21 sorry
    have A9: "\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a) <>HIDDENR2 0NUMBERSK6"
    proof-
      have "\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a) =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        have A10: "number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
          using taylor_1_th_11 sorry
        assume "\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a) =XBOOLE-0R4 0NUMBERSK6"
        then have "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 logPOWERK3(number-ePOWERK4,number-ePOWERK4)"
          using A10 power_th_52 taylor_1_th_11 sorry
        then have "a =HIDDENR1 (number-ePOWERK4)to-powerPOWERK2 logPOWERK3(number-ePOWERK4,number-ePOWERK4)"
          using A3 A10 power_def_3 taylor_1_th_11 sorry
        also have "... = number-ePOWERK4"
          using A10 power_def_3 taylor_1_th_11 sorry
        finally have "a =HIDDENR1 number-ePOWERK4"
           sorry
        thus " False "
          using A4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 a #RPREPOWERK6 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A11: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      have A12: "a #RPREPOWERK6 x >XXREAL-0R4 0NUMBERSK6"
        using A3 prepower_th_81 sorry
      assume A13: "x inHIDDENR3 Z"
      then have A14: "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x)"
        using A5 funct_1_th_12 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
        using A2 A13 sorry
      also have "... = a #RPREPOWERK6 x"
        using A3 fdiff_6_th_1 sorry
      finally have "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 x"
         sorry
      have A15: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A6 A7 A13 fdiff_1_th_9 sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (diffFDIFF-1K1((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x))"
        using A1 A8 A13 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (((diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A11 A15 fdiff_2_th_14 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 a #RPREPOWERK6 x -XCMPLX-0K6 (diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (a #RPREPOWERK6 x)^2SQUARE-1K1)"
        using A14 sin_cos_th_65 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (a #RPREPOWERK6 x -XCMPLX-0K6 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)))/XCMPLX-0K7 (a #RPREPOWERK6 x)^2SQUARE-1K1)"
         sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (a #RPREPOWERK6 x -XCMPLX-0K6 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x))/XCMPLX-0K7 (a #RPREPOWERK6 x)^2SQUARE-1K1)"
        using A6 A13 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (a #RPREPOWERK6 x -XCMPLX-0K6 a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))/XCMPLX-0K7 (a #RPREPOWERK6 x)^2SQUARE-1K1)"
        using A2 A3 A5 A13 fdiff_6_th_11 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 a #RPREPOWERK6 x))/XCMPLX-0K7 (a #RPREPOWERK6 x)^2SQUARE-1K1"
        using xcmplx_1_th_74 sorry
      also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 a #RPREPOWERK6 x)/XCMPLX-0K7 (a #RPREPOWERK6 x)^2SQUARE-1K1"
         sorry
      also have "... = ((\<one>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 a #RPREPOWERK6 x)/XCMPLX-0K7 (a #RPREPOWERK6 x)^2SQUARE-1K1"
        using A9 xcmplx_1_th_106 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 a #RPREPOWERK6 x"
        using A12 xcmplx_1_th_91 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 a #RPREPOWERK6 x"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 a #RPREPOWERK6 x"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 a #RPREPOWERK6 x))"
      using A1 A8 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_20:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A7: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A8: "exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 A6 fdiff_1_th_18 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A10: "x inHIDDENR3 Z"
        then have "((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,x) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
          using A4 A6 A7 fdiff_1_th_18 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
          using sin_cos_th_65 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A6 A10 fdiff_1_def_7 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 0NUMBERSK6"
          using A5 A3 A10 fdiff_1_th_23 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        finally show "((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A12: "x inHIDDENR3 Z"
        then have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x"
          using A4 valued_1_def_1 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
          using A2 A12 sorry
        finally have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        thus " not (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 xreal_1_th_34 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A8 A11 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A14: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A15: "x inHIDDENR3 Z"
      then have A16: "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x"
        using A4 valued_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
        using A2 A15 sorry
      finally have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      have "exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A8 A11 A15 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))/XCMPLX-0K7 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
        using A8 A15 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
        using A9 A15 A16 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
        using A14 A15 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))"
      using A1 A13 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_21:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_th_12 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A7: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A8: "exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 A6 fdiff_1_th_19 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A10: "x inHIDDENR3 Z"
        then have "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,x) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
          using A4 A6 A7 fdiff_1_th_19 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
          using sin_cos_th_65 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A6 A10 fdiff_1_def_7 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 0NUMBERSK6"
          using A5 A3 A10 fdiff_1_th_23 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        finally show "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A8 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A12: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A13: "x inHIDDENR3 Z"
      then have A14: "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x"
        using A4 valued_1_th_13 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
        using A2 A13 sorry
      finally have "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      have "exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A8 A13 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 (diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))/XCMPLX-0K7 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
        using A8 A13 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
        using A9 A13 A14 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
        using A12 A13 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)))"
      using A1 A11 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_22:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))"
      using A1 valued_1_th_8 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_th_12 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A8: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A9: "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using A5 A7 fdiff_1_th_19 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A9 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A10: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have "((f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f,x) -XCMPLX-0K6 diffFDIFF-1K1(exp-RSIN-COSK23,x)"
        using A5 A7 A8 fdiff_1_th_19 sorry
      also have "... = diffFDIFF-1K1(f,x) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A7 A12 fdiff_1_def_7 sorry
      also have "... = 0NUMBERSK6 -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A6 A3 A12 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally show "((f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
    qed "sorry"
    have A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A5 valued_1_th_13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A2 A14 sorry
      finally have "(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have A16: "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A9 A14 fdiff_1_th_9 sorry
      have "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23),x))"
        using A1 A10 A14 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((diffFDIFF-1K1(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23,x))/XCMPLX-0K7 (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A16 taylor_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (((f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A9 A14 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))"
        using A11 A14 A15 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using xcmplx_1_th_74 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      finally have "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      thus "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    have "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))"
      using A1 sorry
    thus "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)))"
      using A10 A13 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_23:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using A1 valued_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using A3 xboole_1_th_18 sorry
    then have A8: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A9: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A10: "x inHIDDENR3 Z"
      then have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
        using A1 A7 A8 fdiff_1_th_18 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
        using A9 taylor_1_th_3 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
        using sin_cos_th_65 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
        using prepower_th_35 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
         sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
        using sin_cos_def_23 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x)) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
        using sin_cos_def_23 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (x +XCMPLX-0K2 x)) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
        using sin_cos_th_50 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x)) +XCMPLX-0K2 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x)) +XCMPLX-0K2 0NUMBERSK6"
        using A4 A6 A10 fdiff_1_th_23 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))"
         sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))"
         sorry
      thus "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))))"
      using A1 A7 A8 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_24:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & f =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & (f =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M)) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: "f =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 tarski_def_3 sorry
    then have A6: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_6_th_23 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) /\\XBOOLE-0K3 domRELAT-1K1 f1"
      using A5 valued_1_def_1 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using xboole_1_th_18 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A9: "((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
          using prepower_th_39 sin_cos_th_54 sorry
        assume A10: "x inHIDDENR3 Z"
        then have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x +XCMPLX-0K2 f1 .FUNCT-1K1 x"
          using A5 valued_1_def_1 sorry
        also have "... = #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) +XCMPLX-0K2 f1 .FUNCT-1K1 x"
          using A7 A10 funct_1_th_12 sorry
        also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 f1 .FUNCT-1K1 x"
          using taylor_1_def_1 sorry
        also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
          using A3 A10 sorry
        finally have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        thus " not f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A2 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 A8 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A11: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A12: "exp-RSIN-COSK24 x >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_55 sorry
      assume A13: "x inHIDDENR3 Z"
      then have A14: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 A8 fdiff_1_th_9 sorry
      have A15: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x +XCMPLX-0K2 f1 .FUNCT-1K1 x"
        using A5 A13 valued_1_def_1 sorry
      also have "... = #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) +XCMPLX-0K2 f1 .FUNCT-1K1 x"
        using A7 A13 funct_1_th_12 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 f1 .FUNCT-1K1 x"
        using taylor_1_def_1 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
        using A3 A13 sorry
      also have "... = (exp-RSIN-COSK24 x)#ZPREPOWERK3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M"
        using sin_cos_def_23 sorry
      also have "... = (exp-RSIN-COSK24 x)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 x)#ZPREPOWERK3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
        using A12 prepower_th_44 sorry
      also have "... = (exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x)#ZPREPOWERK3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
        using prepower_th_35 sorry
      also have "... = (exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) +XCMPLX-0K2 \<one>\<^sub>M"
        using prepower_th_35 sorry
      finally have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A11 A13 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x)"
        using A14 taylor_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)"
        using A2 A6 A13 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x)))/XCMPLX-0K7 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) +XCMPLX-0K2 \<one>\<^sub>M))"
        using A3 A5 A13 A15 fdiff_6_th_23 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))))/XCMPLX-0K7 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) +XCMPLX-0K2 \<one>\<^sub>M)"
        using xcmplx_1_th_74 sorry
      also have "... = ((exp-RSIN-COSK24 (x +XCMPLX-0K2 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using A12 xcmplx_1_th_55 sorry
      also have "... = (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using sin_cos_th_50 sorry
      also have "... = (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using xcmplx_1_th_62 sorry
      also have "... = (exp-RSIN-COSK24 x)/XCMPLX-0K7 (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using A12 xcmplx_1_th_89 sorry
      also have "... = (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using A12 xcmplx_1_th_89 sorry
      also have "... = (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
        using taylor_1_th_4 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))))"
      using A1 A11 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_25:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using A1 valued_1_th_12 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using A3 xboole_1_th_18 sorry
    then have A8: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A9: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A10: "x inHIDDENR3 Z"
      then have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
        using A1 A7 A8 fdiff_1_th_19 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
        using A9 taylor_1_th_3 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
        using sin_cos_th_65 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
        using prepower_th_35 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
         sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
        using sin_cos_def_23 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x)) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
        using sin_cos_def_23 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (x +XCMPLX-0K2 x)) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
        using sin_cos_th_50 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x)) -XCMPLX-0K6 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x)) -XCMPLX-0K6 0NUMBERSK6"
        using A4 A6 A10 fdiff_1_th_23 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))"
         sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))"
         sorry
      thus "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))))"
      using A1 A7 A8 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_26:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & f =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & (f =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: "f =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 tarski_def_3 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
      using A3 sorry
    then have A7: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_6_th_25 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 A7 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A8: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) /\\XBOOLE-0K3 domRELAT-1K1 f1"
      using A5 valued_1_th_12 sorry
    then have A9: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A10: "exp-RSIN-COSK24 x >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_55 sorry
      assume A11: "x inHIDDENR3 Z"
      then have A12: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 A7 fdiff_1_th_9 sorry
      have A13: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x"
        using A5 A11 valued_1_th_13 sorry
      also have "... = #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) -XCMPLX-0K6 f1 .FUNCT-1K1 x"
        using A9 A11 funct_1_th_12 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 f1 .FUNCT-1K1 x"
        using taylor_1_def_1 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
        using A3 A11 sorry
      also have "... = (exp-RSIN-COSK24 x)#ZPREPOWERK3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M"
        using sin_cos_def_23 sorry
      also have "... = (exp-RSIN-COSK24 x)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 x)#ZPREPOWERK3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
        using A10 prepower_th_44 sorry
      also have "... = (exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x)#ZPREPOWERK3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
        using prepower_th_35 sorry
      also have "... = (exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) -XCMPLX-0K6 \<one>\<^sub>M"
        using prepower_th_35 sorry
      finally have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A8 A11 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x)"
        using A12 taylor_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)"
        using A2 A7 A11 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x)))/XCMPLX-0K7 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) -XCMPLX-0K6 \<one>\<^sub>M))"
        using A6 A5 A11 A13 fdiff_6_th_25 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK24 (\<two>\<^sub>M *XCMPLX-0K3 x))))/XCMPLX-0K7 ((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) -XCMPLX-0K6 \<one>\<^sub>M)"
        using xcmplx_1_th_74 sorry
      also have "... = ((exp-RSIN-COSK24 (x +XCMPLX-0K2 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using A10 xcmplx_1_th_55 sorry
      also have "... = (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using sin_cos_th_50 sorry
      also have "... = (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using xcmplx_1_th_120 sorry
      also have "... = (exp-RSIN-COSK24 x)/XCMPLX-0K7 (((exp-RSIN-COSK24 x)*XCMPLX-0K3 (exp-RSIN-COSK24 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using A10 xcmplx_1_th_89 sorry
      also have "... = (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x))"
        using A10 xcmplx_1_th_89 sorry
      also have "... = (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
        using taylor_1_th_4 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x)/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))))"
      using A1 A8 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_27:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_th_12 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A8: "f is-differentiable-inFDIFF-1R1 x"
        using A6 fdiff_1_th_9 sorry
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      then have "exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_14 sorry
      thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A9: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A10: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A11: "x inHIDDENR3 Z"
      then have A12: "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x"
        using A3 valued_1_th_13 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
        using A2 A11 sorry
      finally have "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      have A13: "f is-differentiable-inFDIFF-1R1 x"
        using A6 A11 fdiff_1_th_9 sorry
      then have A14: "diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,x) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
        using A10 fdiff_1_th_14 sorry
      also have "... = diffFDIFF-1K1(exp-RSIN-COSK23,x) -XCMPLX-0K6 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A11 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 0NUMBERSK6"
        using A4 A5 A11 fdiff_1_th_23 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally have "diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have A15: "exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A13 A10 fdiff_1_th_14 sorry
      have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x)"
        using A9 A11 fdiff_1_def_7 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A15 taylor_1_th_3 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A14 A12 prepower_th_35 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      thus "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)))"
      using A1 A7 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_28:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 f & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using A1 A2 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (exp-RSIN-COSK23))\<^esub> (domRELAT-1K1 (exp-RSIN-COSK23) \\SUBSET-1K6 (exp-RSIN-COSK23)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
      using xboole_1_th_18 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using funct_1_th_11 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using tarski_def_3 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A8: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 sorry
        assume A9: "x inHIDDENR3 Z"
        then have A10: "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
          using A3 prepower_th_39 sorry
        have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using A4 A9 rfunct_1_def_1 sorry
        also have "... = (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
          using xcmplx_1_th_215 sorry
        also have "... = (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using xcmplx_1_th_99 sorry
        also have "... = #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x) /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using A5 A9 funct_1_th_12 sorry
        also have "... = ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using taylor_1_def_1 sorry
        finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        thus " not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A10 A8 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
      using A3 sorry
    then have A12: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_6_th_27 sorry
    have "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
      using fdiff_1_th_26 sin_cos_th_54 taylor_1_th_16 sorry
    then have A13: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A12 fdiff_2_th_21 sorry
    have A14: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x & ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A13 A7 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A15: "f is-differentiable-onFDIFF-1R2 Z"
      using A1 A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A16: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_54 sorry
      have A17: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A18: "x inHIDDENR3 Z"
      then have A19: "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x"
        using A6 valued_1_th_13 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
        using A3 A18 sorry
      finally have "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      then have A20: "(exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
        using A3 A18 sorry
      have A21: "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A4 A18 rfunct_1_def_1 sorry
      also have "... = (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using xcmplx_1_th_99 sorry
      also have "... = #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x) /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A5 A18 funct_1_th_12 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)#ZPREPOWERK3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A19 taylor_1_def_1 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A20 prepower_th_44 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using prepower_th_35 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using prepower_th_35 sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have A22: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x & ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A13 A7 A18 fdiff_1_th_9 sorry
      have "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-inFDIFF-1R1 x"
        using A12 A18 fdiff_1_th_9 sorry
      then have A23: "diffFDIFF-1K1((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 ((diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1),x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A16 A17 fdiff_2_th_14 sorry
      also have "... = (((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A12 A18 fdiff_1_def_7 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A11 A5 A18 fdiff_6_th_27 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_65 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A16 xcmplx_1_th_91 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A5 A18 funct_1_th_12 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using taylor_1_def_1 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 f1 .FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A6 A18 valued_1_th_13 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)#ZPREPOWERK3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A3 A18 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A20 prepower_th_44 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using prepower_th_35 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using prepower_th_35 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally have "diffFDIFF-1K1((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)),x)"
        using A2 A15 A18 fdiff_1_def_7 sorry
      also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A22 A23 A21 taylor_1_th_20 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))"
        using A16 xcmplx_1_th_55 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
        using A20 xcmplx_1_th_91 sorry
      finally have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      thus "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)))"
      using A1 A2 A14 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_29:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A8: "f is-differentiable-inFDIFF-1R1 x"
        using A6 fdiff_1_th_9 sorry
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      then have "exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_13 sorry
      thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A9: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A10: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A11: "x inHIDDENR3 Z"
      then have A12: "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x"
        using A3 valued_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
        using A2 A11 sorry
      finally have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      have A13: "f is-differentiable-inFDIFF-1R1 x"
        using A6 A11 fdiff_1_th_9 sorry
      then have A14: "diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,x) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
        using A10 fdiff_1_th_13 sorry
      also have "... = diffFDIFF-1K1(exp-RSIN-COSK23,x) +XCMPLX-0K2 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A11 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 0NUMBERSK6"
        using A4 A5 A11 fdiff_1_th_23 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally have "diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have A15: "exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A13 A10 fdiff_1_th_13 sorry
      have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x)"
        using A9 A11 fdiff_1_def_7 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A15 taylor_1_th_3 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A14 A12 prepower_th_35 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      thus "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))"
      using A1 A7 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_30:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 f & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M)) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using A1 A2 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (exp-RSIN-COSK23))\<^esub> (domRELAT-1K1 (exp-RSIN-COSK23) \\SUBSET-1K6 (exp-RSIN-COSK23)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
      using xboole_1_th_18 sorry
    then have A6: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_6_th_29 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A5 funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using tarski_def_3 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A9: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 sorry
        assume A10: "x inHIDDENR3 Z"
        then have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 f1 .FUNCT-1K1 x"
          using A7 valued_1_def_1 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
          using A3 A10 sorry
        finally have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        then have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 xreal_1_th_34 sorry
        then have A11: "((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
          using prepower_th_39 sorry
        have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using A4 A10 rfunct_1_def_1 sorry
        also have "... = (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
          using xcmplx_1_th_215 sorry
        also have "... = (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using xcmplx_1_th_99 sorry
        also have "... = #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x) /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using A5 A10 funct_1_th_12 sorry
        also have "... = ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using taylor_1_def_1 sorry
        finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        thus " not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A11 A9 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
      using fdiff_1_th_26 sin_cos_th_54 taylor_1_th_16 sorry
    then have A12: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_2_th_21 sorry
    have A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x & ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A12 A8 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A14: "f is-differentiable-onFDIFF-1R2 Z"
      using A1 A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A15: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_54 sorry
      have A16: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      have A17: "(exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_54 xreal_1_th_34 sorry
      assume A18: "x inHIDDENR3 Z"
      then have A19: "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 f1 .FUNCT-1K1 x"
        using A7 valued_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
        using A3 A18 sorry
      finally have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      have A20: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x =HIDDENR1 #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)"
        using A5 A18 funct_1_th_12 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)#ZPREPOWERK3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
        using A19 taylor_1_def_1 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M"
        using A17 prepower_th_44 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)#ZPREPOWERK3 \<one>\<^sub>M"
        using prepower_th_35 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
        using prepower_th_35 sorry
      finally have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      have A21: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x & ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A12 A8 A18 fdiff_1_th_9 sorry
      have "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-inFDIFF-1R1 x"
        using A6 A18 fdiff_1_th_9 sorry
      then have A22: "diffFDIFF-1K1((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 ((diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1),x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A15 A16 fdiff_2_th_14 sorry
      also have "... = (((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A18 fdiff_1_def_7 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A3 A5 A18 fdiff_6_th_29 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_65 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M) -XCMPLX-0K6 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A15 A20 xcmplx_1_th_91 sorry
      finally have "diffFDIFF-1K1((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have A23: "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A4 A18 rfunct_1_def_1 sorry
      also have "... = (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A20 xcmplx_1_th_99 sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)),x)"
        using A2 A14 A18 fdiff_1_def_7 sorry
      also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A21 A22 A23 taylor_1_th_20 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))"
        using A15 xcmplx_1_th_55 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
        using A17 xcmplx_1_th_91 sorry
      finally have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      thus "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))"
      using A1 A2 A13 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_31:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_th_12 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A8: "f is-differentiable-inFDIFF-1R1 x"
        using A6 fdiff_1_th_9 sorry
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      then have "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_1_th_14 sorry
      thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A9: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A10: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A11: "x inHIDDENR3 Z"
      then have A12: "(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A3 valued_1_th_13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A2 A11 sorry
      finally have "(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have A13: "f is-differentiable-inFDIFF-1R1 x"
        using A6 A11 fdiff_1_th_9 sorry
      then have A14: "diffFDIFF-1K1(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23,x) =HIDDENR1 diffFDIFF-1K1(f,x) -XCMPLX-0K6 diffFDIFF-1K1(exp-RSIN-COSK23,x)"
        using A10 fdiff_1_th_14 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(exp-RSIN-COSK23,x)"
        using A6 A11 fdiff_1_def_7 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      also have "... = 0NUMBERSK6 -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A4 A5 A11 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally have "diffFDIFF-1K1(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23,x) =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have A15: "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using A13 A10 fdiff_1_th_14 sorry
      have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23),x)"
        using A9 A11 fdiff_1_def_7 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23,x))"
        using A15 taylor_1_th_3 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A14 A12 prepower_th_35 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      thus "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)))"
      using A1 A7 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_32:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 f & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))"
      using A1 A2 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))\<^esub> (domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) \\SUBSET-1K6 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))"
      using xboole_1_th_1 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using funct_1_th_11 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using tarski_def_3 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A8: "x inHIDDENR3 Z"
        then have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)"
          using A5 funct_1_th_12 sorry
        also have "... = ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
          using taylor_1_def_1 sorry
        finally have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
           sorry
        thus " not (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A3 A8 prepower_th_39 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A10: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 sorry
        assume A11: "x inHIDDENR3 Z"
        then have A12: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A7 sorry
        have "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using A4 A11 rfunct_1_def_1 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)"
          using xcmplx_1_th_215 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x"
          using xcmplx_1_th_99 sorry
        finally have "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x"
           sorry
        thus " not ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A12 A10 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
      using A3 sorry
    then have A14: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_6_th_31 sorry
    have "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
      using A7 fdiff_1_th_26 taylor_1_th_16 sorry
    then have A15: "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z"
      using A14 fdiff_2_th_21 sorry
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A15 A9 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A17: "f is-differentiable-onFDIFF-1R2 Z"
      using A1 A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A18: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A19: "x inHIDDENR3 Z"
      then have A20: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A5 funct_1_th_12 sorry
      also have "... = ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using taylor_1_def_1 sorry
      also have "... = (f1 .FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using A6 A19 valued_1_th_13 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using A3 A19 sorry
      finally have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have A21: "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A4 A19 rfunct_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using A20 xcmplx_1_th_99 sorry
      finally have "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have A22: "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A15 A9 A19 fdiff_1_th_9 sorry
      have A23: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A19 sorry
      have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using A14 A7 A19 fdiff_1_th_9 sorry
      then have A24: "diffFDIFF-1K1((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)),x) =HIDDENR1 ((diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23),x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)^2SQUARE-1K1"
        using A18 fdiff_2_th_14 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23),x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_65 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x -XCMPLX-0K6 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)^2SQUARE-1K1"
        using A14 A19 fdiff_1_def_7 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)^2SQUARE-1K1"
        using A13 A5 A19 A20 fdiff_6_th_31 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
         sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using xcmplx_1_th_83 sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)),x) =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have A25: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_54 sorry
      have A26: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A6 A19 valued_1_th_13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A3 A19 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      then have "(\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
        using A3 A19 prepower_th_39 sorry
      then have A27: "(exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M <>HIDDENR2 0NUMBERSK6"
        using A25 xreal_1_th_139 sorry
      have A28: "(\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
         sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M"
        using A23 A26 prepower_th_44 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M"
        using prepower_th_35 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using prepower_th_35 sorry
      finally have "(\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))),x)"
        using A2 A17 A19 fdiff_1_def_7 sorry
      also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using A22 A24 A21 taylor_1_th_20 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using xcmplx_1_th_78 sorry
      also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))"
        using A27 A28 xcmplx_1_th_91 sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A23 A26 xcmplx_1_th_91 sorry
      finally have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      thus "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)))"
      using A1 A2 A16 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_33:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 f & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M)) implies f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))"
      using A1 A2 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))\<^esub> (domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) \\SUBSET-1K6 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))"
      using xboole_1_th_1 sorry
    then have A6: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_6_th_29 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using A5 funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using tarski_def_3 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A9: "x inHIDDENR3 Z"
        then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using A7 valued_1_def_1 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using A3 A9 sorry
        finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        then have A10: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 xreal_1_th_34 sorry
        have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)"
          using A5 A9 funct_1_th_12 sorry
        also have "... = ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
          using taylor_1_def_1 sorry
        finally have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
           sorry
        thus " not (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A10 prepower_th_39 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A12: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 sorry
        assume A13: "x inHIDDENR3 Z"
        then have A14: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A8 sorry
        have "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using A4 A13 rfunct_1_def_1 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)"
          using xcmplx_1_th_215 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x"
          using xcmplx_1_th_99 sorry
        finally have "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x"
           sorry
        thus " not ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A14 A12 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
      using A8 fdiff_1_th_26 taylor_1_th_16 sorry
    then have A15: "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_2_th_21 sorry
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A15 A11 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A17: "f is-differentiable-onFDIFF-1R2 Z"
      using A1 A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A18: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A19: "x inHIDDENR3 Z"
      then have A20: "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 #ZTAYLOR-1K1 \<two>\<^sub>M .FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A5 funct_1_th_12 sorry
      also have "... = ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using taylor_1_def_1 sorry
      also have "... = (f1 .FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using A7 A19 valued_1_def_1 sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using A3 A19 sorry
      finally have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have "(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using A6 A8 A19 fdiff_1_th_9 sorry
      then have A21: "diffFDIFF-1K1((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)),x) =HIDDENR1 ((diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23),x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)^2SQUARE-1K1"
        using A18 fdiff_2_th_14 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23),x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_65 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x -XCMPLX-0K6 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A19 fdiff_1_def_7 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)^2SQUARE-1K1"
        using A3 A5 A19 A20 fdiff_6_th_29 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
         sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using xcmplx_1_th_83 sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)),x) =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have A22: "\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_54 xreal_1_th_34 sorry
      then have "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
        using prepower_th_39 sin_cos_th_54 sorry
      then have A23: "(exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M <>HIDDENR2 0NUMBERSK6"
        using xreal_1_th_139 sorry
      have A24: "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A4 A19 rfunct_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
        using A20 xcmplx_1_th_99 sorry
      finally have "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have A25: "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A15 A11 A19 fdiff_1_th_9 sorry
      have A26: "(\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
         sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M"
        using A22 prepower_th_44 sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M"
        using prepower_th_35 sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using prepower_th_35 sorry
      finally have "(\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))),x)"
        using A2 A17 A19 fdiff_1_def_7 sorry
      also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using A25 A21 A24 taylor_1_th_20 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using xcmplx_1_th_78 sorry
      also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x))/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x))"
        using A23 A26 xcmplx_1_th_91 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A22 xcmplx_1_th_91 sorry
      finally have "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      thus "(f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (f `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)))"
      using A1 A2 A16 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_34:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using xboole_1_th_18 sorry
    then have A6: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_6_th_14 sorry
    have A7: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 A6 fdiff_1_th_18 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A10: "x inHIDDENR3 Z"
        then have "((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,x) +XCMPLX-0K2 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x)"
          using A4 A6 A7 fdiff_1_th_18 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x)"
          using sin_cos_th_65 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A6 A10 fdiff_1_def_7 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (-XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
          using A3 A5 A10 fdiff_6_th_14 sorry
        also have "... = exp-RSIN-COSK24 x +XCMPLX-0K2 (-XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
          using sin_cos_def_23 sorry
        also have "... = exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
           sorry
        finally show "((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A12: "exp-RSIN-COSK24 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_55 sorry
        assume A13: "x inHIDDENR3 Z"
        then have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x"
          using A4 valued_1_def_1 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
          using A5 A13 funct_1_th_12 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x)"
          using A3 A13 sorry
        also have "... = exp-RSIN-COSK24 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x)"
          using sin_cos_def_23 sorry
        also have "... = exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
          using sin_cos_def_23 sorry
        finally have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
           sorry
        thus " not (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A12 sin_cos_th_55 xreal_1_th_34 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A14: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A8 A11 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A15: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A16: "x inHIDDENR3 Z"
      then have A17: "f .FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x"
        using A2 A4 valued_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
        using A5 A16 funct_1_th_12 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x)"
        using A3 A16 sorry
      also have "... = exp-RSIN-COSK24 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x)"
        using sin_cos_def_23 sorry
      also have "... = exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
        using sin_cos_def_23 sorry
      finally have "f .FUNCT-1K1 x =HIDDENR1 exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
         sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A8 A11 A16 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 f .FUNCT-1K1 x"
        using A8 A16 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
        using A2 A9 A16 A17 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
        using A15 A16 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))))"
      using A1 A14 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_35:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using valued_1_th_12 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x"
      using A3 sorry
    then have A7: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_6_th_14 sorry
    have A8: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A9: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 A7 fdiff_1_th_19 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A11: "x inHIDDENR3 Z"
        then have "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,x) -XCMPLX-0K6 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x)"
          using A4 A7 A8 fdiff_1_th_19 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x)"
          using sin_cos_th_65 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A7 A11 fdiff_1_def_7 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
          using A6 A5 A11 fdiff_6_th_14 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
           sorry
        also have "... = exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
          using sin_cos_def_23 sorry
        finally show "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A9 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A13: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "f .FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x"
        using A2 A4 valued_1_th_13 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
        using A5 A14 funct_1_th_12 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x)"
        using A3 A14 sorry
      also have "... = exp-RSIN-COSK24 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 x)"
        using sin_cos_def_23 sorry
      also have "... = exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
        using sin_cos_def_23 sorry
      finally have "f .FUNCT-1K1 x =HIDDENR1 exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x)"
         sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A9 A14 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 f .FUNCT-1K1 x"
        using A9 A14 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
        using A2 A10 A14 A15 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))"
        using A13 A14 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK24 x +XCMPLX-0K2 exp-RSIN-COSK24 (-XCMPLX-0K4 x))/XCMPLX-0K7 (exp-RSIN-COSK24 x -XCMPLX-0K6 exp-RSIN-COSK24 (-XCMPLX-0K4 x))))"
      using A1 A12 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_36:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have A4: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23))"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A8: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A9: "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using A5 A7 fdiff_1_th_18 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A11: "x inHIDDENR3 Z"
        then have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using A5 valued_1_def_1 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using A2 A11 sorry
        finally have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        thus " not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 xreal_1_th_34 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A10 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A12: "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A13: "x inHIDDENR3 Z"
      then have A14: "((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f,x) +XCMPLX-0K2 diffFDIFF-1K1(exp-RSIN-COSK23,x)"
        using A5 A7 A8 fdiff_1_th_18 sorry
      also have "... = diffFDIFF-1K1(f,x) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A7 A13 fdiff_1_def_7 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A6 A3 A13 fdiff_1_th_23 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally have "((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have A15: "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A10 A13 fdiff_1_th_9 sorry
      have A16: "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A5 A13 valued_1_def_1 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A2 A13 sorry
      finally have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have "(((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23),x))"
        using A1 A12 A13 fdiff_1_th_20 sorry
      also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23,x)))"
        using A15 taylor_1_th_22 sorry
      also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)`|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A9 A13 fdiff_1_def_7 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A16 A14 sorry
      finally have "(((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A12 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_37:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f1 .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))) & a >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 \<one>\<^sub>M implies (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f1 .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)) & (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M)) implies (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f1 .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      and A3: "a >XXREAL-0R4 0NUMBERSK6"
      and A4: "a <>HIDDENR2 \<one>\<^sub>M"
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have A6: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using tarski_def_3 sorry
    then have A8: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_def_1 sorry
    then have A9: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using xboole_1_th_18 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
      using A2 sorry
    then have A11: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A3 A9 fdiff_6_th_11 sorry
    have A12: "Z c=TARSKIR1 domRELAT-1K1 f"
      using A8 xboole_1_th_18 sorry
    then have A13: "f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_23 sorry
    then have A14: "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 Z"
      using A7 A11 fdiff_1_th_18 sorry
    have A15: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A16: "x inHIDDENR3 Z"
        then have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x"
          using A7 valued_1_def_1 sorry
        also have "... = f .FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
          using A9 A16 funct_1_th_12 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
          using A2 A16 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
          using A2 A16 sorry
        finally have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
           sorry
        thus " not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 xreal_1_th_34 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A14 A15 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A17: "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have A18: "logPOWERK3(number-ePOWERK4,a) <>HIDDENR2 0NUMBERSK6"
    proof-
      have "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 0NUMBERSK6 implies  False "
      proof(rule impI)
        have A19: "number-ePOWERK4 <>HIDDENR2 \<one>\<^sub>M"
          using taylor_1_th_11 sorry
        assume "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 0NUMBERSK6"
        then have "logPOWERK3(number-ePOWERK4,a) =HIDDENR1 logPOWERK3(number-ePOWERK4,\<one>\<^sub>M)"
          using sin_cos2_th_13 taylor_1_th_13 sorry
        then have "a =HIDDENR1 (number-ePOWERK4)to-powerPOWERK2 logPOWERK3(number-ePOWERK4,\<one>\<^sub>M)"
          using A3 A19 power_def_3 taylor_1_th_11 sorry
        also have "... = \<one>\<^sub>M"
          using A19 power_def_3 taylor_1_th_11 sorry
        finally have "a =HIDDENR1 \<one>\<^sub>M"
           sorry
        thus " False "
          using A4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A20: "\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a) <>HIDDENR2 0NUMBERSK6"
        using A18 sorry
      assume A21: "x inHIDDENR3 Z"
      then have A22: "((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f,x) +XCMPLX-0K2 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x)"
        using A7 A13 A11 fdiff_1_th_18 sorry
      also have "... = diffFDIFF-1K1(f,x) +XCMPLX-0K2 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A21 fdiff_1_def_7 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A13 A21 fdiff_1_def_7 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A12 A5 A21 fdiff_1_th_23 sorry
      also have "... = a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
        using A3 A10 A9 A21 fdiff_6_th_11 sorry
      finally have "((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)"
         sorry
      have A23: "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x"
        using A7 A21 valued_1_def_1 sorry
      also have "... = f .FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
        using A9 A21 funct_1_th_12 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (f1 .FUNCT-1K1 x)"
        using A2 A21 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
        using A2 A21 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x"
        using A3 fdiff_6_th_1 sorry
      finally have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x"
         sorry
      have "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A14 A15 A21 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1),x) =HIDDENR1 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x))"
        using taylor_1_th_22 sorry
      also have "... = ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (a #RPREPOWERK6 x *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))"
        using A14 A21 A23 A22 fdiff_1_def_7 sorry
      also have "... = (((\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 a #RPREPOWERK6 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1),x) =HIDDENR1 (((\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 a #RPREPOWERK6 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      then have "(((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 ((((\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 a #RPREPOWERK6 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A1 A17 A21 fdiff_1_th_20 sorry
      also have "... = (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))*XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 a #RPREPOWERK6 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a #RPREPOWERK6 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A20 xcmplx_1_th_112 sorry
      also have "... = a #RPREPOWERK6 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "(((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a #RPREPOWERK6 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,a)))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a #RPREPOWERK6 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a #RPREPOWERK6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A17 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_38:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x) implies (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x) implies (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)"
      using A1 A2 valued_1_def_5 sorry
    then have A4: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_38 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A4 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A5 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6))"
        using A3 A5 fdiff_4_th_38 sorry
      also have "... = sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x)"
        using sin_cos_def_17 sorry
      finally have "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x)"
         sorry
      thus "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x)"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 x)))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_39:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have A4: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (cosSIN-COSK19) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_th_12 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A8: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    then have A9: "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using A5 A7 fdiff_1_th_19 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A11: "x inHIDDENR3 Z"
        then have "(cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
          using A2 sorry
        then have A12: "\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_15 sorry
        have "(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
          using A5 A11 valued_1_th_13 sorry
        also have "... = \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
          using A2 A11 sorry
        finally have "(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
           sorry
        thus " not (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x & (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A10 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A13: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "diffFDIFF-1K1(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x) =HIDDENR1 ((f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 fdiff_1_def_7 sorry
      also have "... = diffFDIFF-1K1(f,x) -XCMPLX-0K6 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A5 A7 A8 A14 fdiff_1_th_19 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A7 A14 fdiff_1_def_7 sorry
      also have "... = 0NUMBERSK6 -XCMPLX-0K6 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A6 A3 A14 fdiff_1_th_23 sorry
      also have "... = 0NUMBERSK6 -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally have "diffFDIFF-1K1(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      have A16: "(cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A2 A14 sorry
      have A17: "(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
        using A5 A14 valued_1_th_13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
        using A2 A14 sorry
      finally have "(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      have A18: "f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x & (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A10 A14 fdiff_1_th_9 sorry
      have A19: "(sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 A14 sorry
      have "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19),x))"
        using A1 A13 A14 fdiff_1_th_20 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x)))"
        using A18 taylor_1_th_22 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A17 A15 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A10 A14 A17 prepower_th_76 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using xcmplx_1_th_99 sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A19 A16 fdiff_6_lm_4 sorry
      finally have "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A13 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_40:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies (-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies (-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have A4: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (cosSIN-COSK19) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A8: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    then have A9: "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using A5 A7 fdiff_1_th_18 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A11: "x inHIDDENR3 Z"
        then have "(cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
          using A2 sorry
        then have A12: "\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
          using xreal_1_th_8 sorry
        have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
          using A5 A11 valued_1_def_1 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
          using A2 A11 sorry
        finally have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
           sorry
        thus " not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A10 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A13: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "diffFDIFF-1K1(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x) =HIDDENR1 ((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 fdiff_1_def_7 sorry
      also have "... = diffFDIFF-1K1(f,x) +XCMPLX-0K2 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A5 A7 A8 A14 fdiff_1_th_18 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A7 A14 fdiff_1_def_7 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A6 A3 A14 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      finally have "diffFDIFF-1K1(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      have A16: "(cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A2 A14 sorry
      have A17: "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
        using A5 A14 valued_1_def_1 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
        using A2 A14 sorry
      finally have "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      have A18: "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A10 A14 fdiff_1_th_9 sorry
      have A19: "(sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 A14 sorry
      have "(((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19),x))"
        using A1 A13 A14 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x)))"
        using A18 taylor_1_th_22 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A17 A15 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A10 A14 A17 prepower_th_76 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using xcmplx_1_th_99 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A19 A16 fdiff_6_lm_5 sorry
      finally have "(((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A13 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_6_lm_6:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A1 valued_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A5: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    then have A7: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A3 xboole_1_th_18 sorry
    then have A8: "\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_20 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A9: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      assume A10: "x inHIDDENR3 Z"
      then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x)"
        using A1 A7 A8 fdiff_1_th_18 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x)"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A9 fdiff_1_th_15 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A4 A6 A10 fdiff_1_th_23 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      finally have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      thus "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
      using A1 A7 A8 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_41:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & (f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: "f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A2 tarski_def_3 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
      using A3 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A5 fdiff_6_lm_6 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A7 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A8: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A5 valued_1_def_1 sorry
    then have A9: "Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f .FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x"
        using A2 A5 valued_1_def_1 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x"
        using A3 A10 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
        using A9 A10 valued_1_def_5 sorry
      finally have "f .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      have A12: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A7 A10 fdiff_1_th_9 sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A8 A10 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x)"
        using A12 taylor_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 f .FUNCT-1K1 x)"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 f .FUNCT-1K1 x)"
        using A2 A6 A5 A10 fdiff_6_lm_6 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))/XCMPLX-0K7 f .FUNCT-1K1 x"
        using xcmplx_1_th_74 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A11 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)))"
      using A1 A8 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_6_lm_7:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A1 valued_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A5: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    then have A7: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A3 xboole_1_th_18 sorry
    then have A8: "\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_20 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A9: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_63 sorry
      assume A10: "x inHIDDENR3 Z"
      then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x)"
        using A1 A7 A8 fdiff_1_th_18 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x)"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A9 fdiff_1_th_15 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A4 A6 A10 fdiff_1_th_23 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      thus "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A1 A7 A8 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_42:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & (f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: "f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A2 tarski_def_3 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
      using A3 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A5 fdiff_6_lm_7 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A7 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A8: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A5 valued_1_def_1 sorry
    then have A9: "Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f .FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x"
        using A2 A5 valued_1_def_1 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x"
        using A3 A10 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A9 A10 valued_1_def_5 sorry
      finally have "f .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      have A12: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A7 A10 fdiff_1_th_9 sorry
      have "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A8 A10 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x)"
        using A12 taylor_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 f .FUNCT-1K1 x)"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 f .FUNCT-1K1 x)"
        using A2 A6 A5 A10 fdiff_6_lm_7 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))/XCMPLX-0K7 f .FUNCT-1K1 x"
        using xcmplx_1_th_74 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using A11 sorry
      finally have "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      thus "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)))"
      using A1 A8 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_43:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)) & a <>HIDDENR2 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x) & a <>HIDDENR2 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x"
      and A3: "a <>HIDDENR2 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)"
      using A1 A2 valued_1_def_5 sorry
    then have A5: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_37 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A5 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A6 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6))"
        using A4 A6 fdiff_4_th_37 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)"
         sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)"
        using xcmplx_1_th_102 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 a))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)"
         sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)"
        using A3 xcmplx_1_th_106 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))"
        using sin_cos_def_19 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))))"
      using A1 A5 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_44:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 \<two>\<^sub>M & f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)) & a <>HIDDENR2 0NUMBERSK6 implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK18 (a *XCMPLX-0K3 x))^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 \<two>\<^sub>M & f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x) & a <>HIDDENR2 0NUMBERSK6) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK18 (a *XCMPLX-0K3 x))^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 \<two>\<^sub>M & f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x"
      and A3: "a <>HIDDENR2 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using A1 valued_1_th_12 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M"
        using A2 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      finally have "f1 .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
    qed "sorry"
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x"
      using A2 sorry
    then have A8: "(\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A3 A5 fdiff_6_th_43 sorry
    have A9: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using A4 xboole_1_th_18 sorry
    then have A10: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK18 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      then have "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x)"
        using A1 A8 A10 fdiff_1_th_19 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x)"
        using A10 A11 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A11 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))"
        using A3 A7 A5 A11 fdiff_6_th_43 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))"
        using A9 A6 A11 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 x)))"
         sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 (a *XCMPLX-0K3 x))^2SQUARE-1K1)"
        using fdiff_6_lm_1 sorry
      also have "... = (sinSIN-COSK18 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      finally have "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK18 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      thus "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK18 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK18 (a *XCMPLX-0K3 x))^2SQUARE-1K1))"
      using A1 A8 A10 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_45:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 \<two>\<^sub>M & f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x)) & a <>HIDDENR2 0NUMBERSK6 implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK20 (a *XCMPLX-0K3 x))^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 \<two>\<^sub>M & f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x) & a <>HIDDENR2 0NUMBERSK6) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK20 (a *XCMPLX-0K3 x))^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 \<two>\<^sub>M & f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x"
      and A3: "a <>HIDDENR2 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using A1 valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M"
        using A2 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      finally have "f1 .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
    qed "sorry"
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x"
      using A2 sorry
    then have A8: "(\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A3 A5 fdiff_6_th_43 sorry
    have A9: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using A4 xboole_1_th_18 sorry
    then have A10: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK20 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x)"
        using A1 A8 A10 fdiff_1_th_18 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x)"
        using A10 A11 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (((\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A11 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))"
        using A3 A7 A5 A11 fdiff_6_th_43 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 x))"
        using A9 A6 A11 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 x)))"
         sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK20 (a *XCMPLX-0K3 x))^2SQUARE-1K1)"
        using fdiff_6_lm_2 sorry
      also have "... = (cosSIN-COSK20 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      finally have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK20 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      thus "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK20 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK20 (a *XCMPLX-0K3 x))^2SQUARE-1K1))"
      using A1 A8 A10 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_46:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) & n >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) & n >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))"
      and A2: "n >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_63 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A1 valued_1_def_5 sorry
    then have A4: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A5: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_63 sorry
      assume "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A1 A4 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x)))"
        using A5 taylor_1_th_3 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x))"
        using sin_cos_th_63 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 n)*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      also have "... = ((n \<inverse>XCMPLX-0K5 *XCMPLX-0K3 n)*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A2 xcmplx_0_def_7 sorry
      also have "... = -XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_47:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) implies (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) implies (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
    then have "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) /\\XBOOLE-0K3 domRELAT-1K1 (cosSIN-COSK19)"
      using valued_1_th_12 sorry
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))"
      using xboole_1_th_18 sorry
    then have A3: "(\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_6_th_46 sorry
    have A4: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)),x) -XCMPLX-0K6 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A1 A3 A4 fdiff_1_th_19 sorry
      also have "... = diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)),x) -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A3 A5 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (\<three>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A2 A5 fdiff_6_th_46 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
         sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 ( |.INT-2K1 \<two>\<^sub>M.|))"
        using prepower_def_3 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M)"
        using absvalue_def_1 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using wsierp_1_th_1 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos_th_28 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M"
        using wsierp_1_th_1 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
        using newton_th_6 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M))"
      using A1 A3 A4 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_48:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) implies sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) implies sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
    then have "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) /\\XBOOLE-0K3 domRELAT-1K1 (sinSIN-COSK17)"
      using valued_1_th_12 sorry
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      using xboole_1_th_18 sorry
    then have A3: "(\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_54 sorry
    have A4: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(sinSIN-COSK17,x) -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using A1 A3 A4 fdiff_1_th_19 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A3 A5 fdiff_1_def_7 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (\<three>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A2 A5 fdiff_4_th_54 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
         sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 ( |.INT-2K1 \<two>\<^sub>M.|))"
        using prepower_def_3 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M)"
        using absvalue_def_1 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using wsierp_1_th_1 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_28 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M"
        using wsierp_1_th_1 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
        using newton_th_6 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M"
         sorry
      finally have "((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M"
         sorry
      thus "((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M"
         sorry
    qed "sorry"
    thus "sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<three>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M))"
      using A1 A3 A4 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_49:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (lnTAYLOR-1K3)"
      using funct_1_th_11 sorry
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 (lnTAYLOR-1K3)"
      using tarski_def_3 sorry
    then have A3: "lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_18 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A5: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A3 fdiff_1_th_9 sorry
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_2_th_13 sorry
    qed "sorry"
    then have A6: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A7: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      assume A8: "x inHIDDENR3 Z"
      then have A9: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using A1 funct_1_th_11 taylor_1_th_18 sorry
      have "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A3 A8 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 (diffFDIFF-1K1(sinSIN-COSK17,(lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A7 fdiff_2_th_13 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) *XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A9 taylor_1_def_2 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A2 A8 taylor_1_th_18 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x"
        using xcmplx_1_th_99 sorry
      finally have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x"
         sorry
      thus "(((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x"
        using A6 A8 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x))"
      using A1 A4 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_6_th_50:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
      using valued_1_th_8 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (lnTAYLOR-1K3)"
      using funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 (lnTAYLOR-1K3)"
      using tarski_def_3 sorry
    then have A4: "lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A5: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_1_th_9 sorry
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_2_th_13 sorry
    qed "sorry"
    then have A6: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_9 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A8: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      assume A9: "x inHIDDENR3 Z"
      then have A10: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using A2 funct_1_th_11 taylor_1_th_18 sorry
      have A11: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A4 A9 fdiff_1_th_9 sorry
      have "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x))"
        using A1 A6 A9 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((diffFDIFF-1K1(cosSIN-COSK19,(lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x)))"
        using A11 A8 fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x)))"
        using sin_cos_th_63 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x)))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
         sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x)))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A10 taylor_1_def_2 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x)))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A3 A9 taylor_1_th_18 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x"
        using xcmplx_1_th_99 sorry
      finally have "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x"
         sorry
      thus "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x"
         sorry
    qed "sorry"
    have "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)))"
      using A1 sorry
    thus "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x) /XCMPLX-0K7 x))"
      using A6 A7 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
