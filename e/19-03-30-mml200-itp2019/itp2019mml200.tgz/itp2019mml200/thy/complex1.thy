theory complex1
  imports real_1 square_1 funct_2 card_1 membered
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d for "RealXREAL-0M1"
mtheorem complex1_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 =HIDDENR1 0NUMBERSK6 implies a =HIDDENR1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  not (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 =HIDDENR1 0NUMBERSK6 &  not a =HIDDENR1 0NUMBERSK6)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 a ^2SQUARE-1K1 & 0NUMBERSK6 <=XXREAL-0R1 b ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    thus " not (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 =HIDDENR1 0NUMBERSK6 &  not a =HIDDENR1 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 a ^2SQUARE-1K1 & 0NUMBERSK6 <=XXREAL-0R1 b ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef complex1_def_1 ("ReCOMPLEX1K1  _ " [228]228 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func ReCOMPLEX1K1 z \<rightarrow> numberORDINAL1M2 means
  \<lambda>it. it =HIDDENR1 z if z be realXREAL-0V1 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
proof-
  (*existence*)
    show "(z be realXREAL-0V1 implies ( ex it be numberORDINAL1M2 st it =HIDDENR1 z)) & ( not z be realXREAL-0V1 implies ( ex it be numberORDINAL1M2 st  ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)))"
    proof-
      have "(z be realXREAL-0V1 implies ( ex IT be setHIDDENM2 st IT =HIDDENR1 z)) & ( not z be realXREAL-0V1 implies ( ex tVar1 be numberORDINAL1M2 st  ex tVar2 be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar2 & tVar2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 tVar2 .FUNCT-1K1 (0NUMBERSK6)))"
      proof(rule conjMI,rule impI)
        show "z be realXREAL-0V1 implies ( ex IT be setHIDDENM2 st IT =HIDDENR1 z)"
        proof-
          have "z be realXREAL-0V1 implies  not ( for IT be setHIDDENM2 holds  not IT =HIDDENR1 z)"
          proof(rule impI)
            assume "z be realXREAL-0V1"
            then have "z inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            thus " not ( for IT be setHIDDENM2 holds  not IT =HIDDENR1 z)"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A1: "z inHIDDENR3 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        assume " not z be realXREAL-0V1"
        then have " not z inHIDDENR3 REALNUMBERSK2"
           sorry
        then have "z inHIDDENR3 FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 })"
          using A1 card_1_th_50 numbers_def_2 xboole_0_def_3 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using funct_2_th_66 sorry
        show " ex tVar1 be numberORDINAL1M2 st  ex tVar2 be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar2 & tVar2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 tVar2 .FUNCT-1K1 (0NUMBERSK6)"
        proof(rule bexI[of _ "f .FUNCT-1K1 (0NUMBERSK6)"])
          show " ex tVar2 be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar2 & tVar2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 tVar2 .FUNCT-1K1 (0NUMBERSK6)"
          proof(rule bexI[of _ "f"])
            show "z =HIDDENR1 f & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be numberORDINAL1M2 holds  for it2 be numberORDINAL1M2 holds (z be realXREAL-0V1 implies (it1 =HIDDENR1 z & it2 =HIDDENR1 z implies it1 =HIDDENR1 it2)) & ( not z be realXREAL-0V1 implies (( ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)) & ( ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be numberORDINAL1M2 holds  True "
       sorry
qed "sorry"

mdef complex1_def_2 ("ImCOMPLEX1K2  _ " [228]228 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func ImCOMPLEX1K2 z \<rightarrow> numberORDINAL1M2 means
  \<lambda>it. it =HIDDENR1 0NUMBERSK6 if z be realXREAL-0V1 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
proof-
  (*existence*)
    show "(z be realXREAL-0V1 implies ( ex it be numberORDINAL1M2 st it =HIDDENR1 0NUMBERSK6)) & ( not z be realXREAL-0V1 implies ( ex it be numberORDINAL1M2 st  ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M))"
    proof-
      have "(z be realXREAL-0V1 implies ( ex IT be setHIDDENM2 st IT =HIDDENR1 0NUMBERSK6)) & ( not z be realXREAL-0V1 implies ( ex tVar3 be numberORDINAL1M2 st  ex tVar4 be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar4 & tVar4 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 tVar4 .FUNCT-1K1 \<one>\<^sub>M))"
      proof(rule conjMI,rule impI)
        show "z be realXREAL-0V1 implies ( ex IT be setHIDDENM2 st IT =HIDDENR1 0NUMBERSK6)"
           sorry
        have A2: "z inHIDDENR3 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        assume " not z be realXREAL-0V1"
        then have " not z inHIDDENR3 REALNUMBERSK2"
           sorry
        then have "z inHIDDENR3 FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 })"
          using A2 card_1_th_50 numbers_def_2 xboole_0_def_3 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using funct_2_th_66 sorry
        show " ex tVar3 be numberORDINAL1M2 st  ex tVar4 be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar4 & tVar4 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 tVar4 .FUNCT-1K1 \<one>\<^sub>M"
        proof(rule bexI[of _ "f .FUNCT-1K1 \<one>\<^sub>M"])
          show " ex tVar4 be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar4 & tVar4 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 tVar4 .FUNCT-1K1 \<one>\<^sub>M"
          proof(rule bexI[of _ "f"])
            show "z =HIDDENR1 f & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be numberORDINAL1M2 holds  for it2 be numberORDINAL1M2 holds (z be realXREAL-0V1 implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & ( not z be realXREAL-0V1 implies (( ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & ( ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be numberORDINAL1M2 holds  True "
       sorry
qed "sorry"

mtheorem complex1_cl_1:
  mlet "z be ComplexXCMPLX-0M1"
"cluster ReCOMPLEX1K1 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "ReCOMPLEX1K1 z be realXREAL-0V1"
  proof-
    show "ReCOMPLEX1K1 z be realXREAL-0V1"
    proof-
      have cases: "z be realXREAL-0V1 or  not z be realXREAL-0V1"
         sorry
      have case1: "z be realXREAL-0V1 implies ReCOMPLEX1K1 z be realXREAL-0V1"
      proof(rule impI)
        assume "z be realXREAL-0V1"
        thus "ReCOMPLEX1K1 z be realXREAL-0V1"
          using complex1_def_1 sorry
      qed
      have case2: " not z be realXREAL-0V1 implies ReCOMPLEX1K1 z be realXREAL-0V1"
      proof(rule impI)
        assume " not z be realXREAL-0V1"
        then obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)" and 
          "z =HIDDENR1 f"and A1: "ReCOMPLEX1K1 z =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
          using complex1_def_1 sorry
        have "0NUMBERSK6 inTARSKIR2 \<two>\<^sub>M"
          using card_1_th_50 tarski_def_2 sorry
        then have "f .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 REALNUMBERSK2"
          using funct_2_th_5 sorry
        thus "ReCOMPLEX1K1 z be realXREAL-0V1"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem complex1_cl_2:
  mlet "z be ComplexXCMPLX-0M1"
"cluster ImCOMPLEX1K2 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "ImCOMPLEX1K2 z be realXREAL-0V1"
  proof-
    show "ImCOMPLEX1K2 z be realXREAL-0V1"
    proof-
      have cases: "z be realXREAL-0V1 or  not z be realXREAL-0V1"
         sorry
      have case1: "z be realXREAL-0V1 implies ImCOMPLEX1K2 z be realXREAL-0V1"
      proof(rule impI)
        assume "z be realXREAL-0V1"
        thus "ImCOMPLEX1K2 z be realXREAL-0V1"
          using complex1_def_2 sorry
      qed
      have case2: " not z be realXREAL-0V1 implies ImCOMPLEX1K2 z be realXREAL-0V1"
      proof(rule impI)
        assume " not z be realXREAL-0V1"
        then obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)" and 
          "z =HIDDENR1 f"and A2: "ImCOMPLEX1K2 z =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
          using complex1_def_2 sorry
        have "\<one>\<^sub>M inTARSKIR2 \<two>\<^sub>M"
          using card_1_th_50 tarski_def_2 sorry
        then have "f .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
          using funct_2_th_5 sorry
        thus "ImCOMPLEX1K2 z be realXREAL-0V1"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

abbreviation(input) COMPLEX1K3("ReCOMPLEX1K3  _ " [228]228) where
  "ReCOMPLEX1K3 z \<equiv> ReCOMPLEX1K1 z"

mtheorem complex1_add_1:
  mlet "z be ComplexXCMPLX-0M1"
"cluster ReCOMPLEX1K1 z as-term-is ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show "ReCOMPLEX1K1 z be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
qed "sorry"

abbreviation(input) COMPLEX1K4("ImCOMPLEX1K4  _ " [228]228) where
  "ImCOMPLEX1K4 z \<equiv> ImCOMPLEX1K2 z"

mtheorem complex1_add_2:
  mlet "z be ComplexXCMPLX-0M1"
"cluster ImCOMPLEX1K2 z as-term-is ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show "ImCOMPLEX1K2 z be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
qed "sorry"

mtheorem complex1_cl_3:
  mlet "r be RealXREAL-0M1"
"cluster ImCOMPLEX1K4 r as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show "ImCOMPLEX1K4 r be zeroORDINAL1V8"
  proof-
    show "ImCOMPLEX1K4 r be zeroORDINAL1V8"
      using complex1_def_2 sorry
  qed
qed "sorry"

mtheorem complex1_th_2:
" for f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) holds  ex a be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex b be ElementSUBSET-1M1-of REALNUMBERSK2 st f =FUNCT-2R1\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2,{TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub> (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b)"
proof-
  have " for f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) holds  ex tVar5 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar6 be ElementSUBSET-1M1-of REALNUMBERSK2 st f =FUNCT-2R1\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2,{TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub> (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(tVar5,tVar6)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)"
    have "0NUMBERSK6 inTARSKIR2 \<two>\<^sub>M & \<one>\<^sub>M inTARSKIR2 \<two>\<^sub>M"
      using card_1_th_50 tarski_def_2 sorry
    then obtain a b where 
      [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = f .FUNCT-1K1 (0NUMBERSK6)" and
      [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = f .FUNCT-1K1 \<one>\<^sub>M"
      using funct_2_th_5 sorry
    show " ex tVar5 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar6 be ElementSUBSET-1M1-of REALNUMBERSK2 st f =FUNCT-2R1\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2,{TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub> (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(tVar5,tVar6)"
    proof(rule bexI[of _ "a"])
      show " ex tVar6 be ElementSUBSET-1M1-of REALNUMBERSK2 st f =FUNCT-2R1\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2,{TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub> (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,tVar6)"
      proof(rule bexI[of _ "b"])
        have "domRELAT-1K1 f =HIDDENR1 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
          using card_1_th_50 funct_2_def_1 sorry
        thus "f =FUNCT-2R1\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2,{TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub> (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b)"
          using funct_4_th_66 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_2:
" for a be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b be ElementSUBSET-1M1-of REALNUMBERSK2 holds ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =HIDDENR1 a & ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =HIDDENR1 b"
proof(rule ballI,rule ballI,rule conjMI)
  fix a assume [ty]: "a be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix b assume [ty]: "b be ElementSUBSET-1M1-of REALNUMBERSK2"
  obtain a9 b9 where 
    [ty]:"a9 be ElementSUBSET-1M1-of REALNUMBERSK2" and a9Def:"a9 = a" and
    [ty]:"b9 be ElementSUBSET-1M1-of REALNUMBERSK2" and b9Def:"b9 = b"
     sorry
  show "ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =HIDDENR1 a"
  proof-
    show "ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =HIDDENR1 a"
    proof-
      have cases: "b =HIDDENR1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "b =HIDDENR1 0NUMBERSK6 implies ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =HIDDENR1 a"
      proof(rule impI)
        assume "b =HIDDENR1 0NUMBERSK6"
        then have "[*ARYTM-0K5 a,b *] =HIDDENR1 a"
          using arytm_0_def_5 sorry
        thus "ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =HIDDENR1 a"
          using complex1_def_1 sorry
      qed
      have case2: "b <>HIDDENR2 0NUMBERSK6 implies ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =HIDDENR1 a"
      proof(rule impI)
        assume "b <>HIDDENR2 0NUMBERSK6"
        then have A1: "[*ARYTM-0K5 a,b *] =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a9,b9)"
          using arytm_0_def_5 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)" and fDef:"f = [*ARYTM-0K5 a,b *]"
          using card_1_th_50 sorry
        have A2: " not [*ARYTM-0K5 a,b *] inTARSKIR2 REALNUMBERSK2 & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 a"
          using A1 arytm_0_th_8 funct_4_th_63 sorry
        then have " not [*ARYTM-0K5 a,b *] be realXREAL-0V1"
          using xreal_0_def_1 sorry
        thus "ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =HIDDENR1 a"
          using complex1_def_1 A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  show "ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =HIDDENR1 b"
  proof-
    have cases: "b =HIDDENR1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "b =HIDDENR1 0NUMBERSK6 implies ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =HIDDENR1 b"
    proof(rule impI)
      assume A2: "b =HIDDENR1 0NUMBERSK6"
      then have "[*ARYTM-0K5 a,b *] =HIDDENR1 a"
        using arytm_0_def_5 sorry
      thus "ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =HIDDENR1 b"
        using A2 sorry
    qed
    have case2: "b <>HIDDENR2 0NUMBERSK6 implies ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =HIDDENR1 b"
    proof(rule impI)
      assume "b <>HIDDENR2 0NUMBERSK6"
      then have A3: "[*ARYTM-0K5 a,b *] =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a9,b9)"
        using arytm_0_def_5 sorry
      then obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)" and fDef:"f = [*ARYTM-0K5 a,b *]"
        using card_1_th_50 sorry
      have A4: " not [*ARYTM-0K5 a,b *] inTARSKIR2 REALNUMBERSK2 & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 b"
        using A3 arytm_0_th_8 funct_4_th_63 sorry
      then have " not [*ARYTM-0K5 a,b *] be realXREAL-0V1"
        using xreal_0_def_1 sorry
      thus "ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =HIDDENR1 b"
        using complex1_def_2 A4 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

reserve z, z1, z2 for "ComplexXCMPLX-0M1"
mlemma complex1_lm_3:
" for z be ComplexXCMPLX-0M1 holds [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: "z inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    show "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
    proof-
      have cases: "z be realXREAL-0V1 or  not z be realXREAL-0V1"
         sorry
      have case1: "z be realXREAL-0V1 implies [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
      proof(rule impI)
        assume A2: "z be realXREAL-0V1"
        then have "ImCOMPLEX1K4 z =HIDDENR1 0NUMBERSK6"
           sorry
        then have "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 ReCOMPLEX1K3 z"
          using arytm_0_def_5 sorry
        also have "... = z"
          using A2 complex1_def_1 sorry
        finally show "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
           sorry
      qed
      have case2: " not z be realXREAL-0V1 implies [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
      proof(rule impI)
        assume A3: " not z be realXREAL-0V1"
        then have a3: " not z inHIDDENR3 REALNUMBERSK2"
           sorry
        have A4: " ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & ImCOMPLEX1K4 z =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
          using complex1_def_2 A3 sorry
        then obtain a b where
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" "b be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A5: "z =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b)"
          using complex1_th_2 sorry
        obtain f where 
          [ty]:"f be ElementFUNCT-2M4\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using A5 card_1_th_50 funct_2_th_8 sorry
        have "z inHIDDENR3 FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 })"
          using A1 a3 card_1_th_50 numbers_def_2 xboole_0_def_3 sorry
        then have " not z inHIDDENR3 {x where x be ElementFUNCT-2M4\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 }"
          using xboole_0_def_5 sorry
        then have "f .FUNCT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6"
           sorry
        then have A6: "b <>HIDDENR2 0NUMBERSK6"
          using A5 funct_4_th_63 sorry
        have " ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & ReCOMPLEX1K3 z =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
          using A3 complex1_def_1 sorry
        then have A7: "ReCOMPLEX1K3 z =HIDDENR1 a"
          using A5 funct_4_th_63 sorry
        have "ImCOMPLEX1K4 z =HIDDENR1 b"
          using A4 A5 funct_4_th_63 sorry
        thus "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
          using A5 A7 A6 arytm_0_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_3:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z1 =HIDDENR1 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 z1 =HIDDENR1 ImCOMPLEX1K4 z2 implies z1 =HIDDENR1 z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z1 =HIDDENR1 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 z1 =HIDDENR1 ImCOMPLEX1K4 z2 implies z1 =HIDDENR1 z2"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume "ReCOMPLEX1K3 z1 =HIDDENR1 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 z1 =HIDDENR1 ImCOMPLEX1K4 z2"
    then have "z1 =HIDDENR1 [*ARYTM-0K5 ReCOMPLEX1K3 z2,ImCOMPLEX1K4 z2 *]"
      using complex1_lm_3 sorry
    also have "... = z2"
      using complex1_lm_3 sorry
    finally show "z1 =HIDDENR1 z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) COMPLEX1R1(" _ =COMPLEX1R1  _ " [50,50]50) where
  "z1 =COMPLEX1R1 z2 \<equiv> z1 =HIDDENR1 z2"

mtheorem complex1_def_3:
  mlet "z1 be ComplexXCMPLX-0M1", "z2 be ComplexXCMPLX-0M1"
"redefine pred z1 =COMPLEX1R1 z2 means
  ReCOMPLEX1K3 z1 =HIDDENR1 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 z1 =HIDDENR1 ImCOMPLEX1K4 z2"
proof
(*compatibility*)
  show "z1 =COMPLEX1R1 z2 iff ReCOMPLEX1K3 z1 =HIDDENR1 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 z1 =HIDDENR1 ImCOMPLEX1K4 z2"
    using complex1_th_3 sorry
qed "sorry"

abbreviation(input) COMPLEX1K5("0cCOMPLEX1K5" 228) where
  "0cCOMPLEX1K5 \<equiv> 0ORDINAL1K5"

abbreviation(input) COMPLEX1K6("0cCOMPLEX1K6" 228) where
  "0cCOMPLEX1K6 \<equiv> 0ORDINAL1K5"

mtheorem complex1_add_3:
"cluster 0ORDINAL1K5 as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "0ORDINAL1K5 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mdef complex1_def_4 ("1rCOMPLEX1K7" 228 ) where
"func 1rCOMPLEX1K7 \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<one>\<^sub>M be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

abbreviation(input) COMPLEX1K8("<i>COMPLEX1K8" 164) where
  "<i>COMPLEX1K8 \<equiv> <i>XCMPLX-0K1"

mtheorem complex1_add_4:
"cluster <i>XCMPLX-0K1 as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "<i>XCMPLX-0K1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem complex1_th_4:
"ReCOMPLEX1K3 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
proof-
  obtain zz where 
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have "0NUMBERSK6 =COMPLEX1R1 [*ARYTM-0K5 zz,zz *]"
    using arytm_0_def_5 sorry
  thus "ReCOMPLEX1K3 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
    using complex1_lm_2 sorry
qed

mtheorem complex1_th_5:
" for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 0NUMBERSK6 iff (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
  using complex1_th_4 complex1_th_1 sorry

mtheorem complex1_th_6:
"ReCOMPLEX1K3 (1rCOMPLEX1K7) =COMPLEX1R1 \<one>\<^sub>M & ImCOMPLEX1K4 (1rCOMPLEX1K7) =COMPLEX1R1 0NUMBERSK6"
proof-
  obtain zz j where 
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6" and
    [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
    using xreal_0_def_1 sorry
  have "1rCOMPLEX1K7 =COMPLEX1R1 [*ARYTM-0K5 j,zz *]"
    using arytm_0_def_5 sorry
  thus "ReCOMPLEX1K3 (1rCOMPLEX1K7) =COMPLEX1R1 \<one>\<^sub>M & ImCOMPLEX1K4 (1rCOMPLEX1K7) =COMPLEX1R1 0NUMBERSK6"
    using complex1_lm_2 sorry
qed

mtheorem complex1_th_7:
"ReCOMPLEX1K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (<i>COMPLEX1K8) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  obtain zz j where 
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6" and
    [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
    using xreal_0_def_1 sorry
  have "<i>COMPLEX1K8 =COMPLEX1R1 [*ARYTM-0K5 zz,j *]"
    using arytm_0_def_5 xcmplx_0_def_1 sorry
  thus "ReCOMPLEX1K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (<i>COMPLEX1K8) =COMPLEX1R1 \<one>\<^sub>M"
    using complex1_lm_2 sorry
qed

mlemma complex1_lm_4:
" for x be RealXREAL-0M1 holds  for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *] implies x2 =COMPLEX1R1 0NUMBERSK6 & x =COMPLEX1R1 x1"
proof-
  have " for x be RealXREAL-0M1 holds  for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *] implies (x2 <>HIDDENR2 0NUMBERSK6 implies  False ) & x =COMPLEX1R1 x1"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of REALNUMBERSK2"
    assume A1: "x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *]"
    have A2: "x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    show "x2 <>HIDDENR2 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "x2 <>HIDDENR2 0NUMBERSK6"
      then have "x =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(x1,x2)"
        using A1 arytm_0_def_5 sorry
      thus " False "
        using A2 arytm_0_th_8 sorry
    qed
    thus "x =COMPLEX1R1 x1"
      using A1 arytm_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_5:
" for x9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y implies +ARYTM-0K1(x9,y9) =COMPLEX1R1 x +XCMPLX-0K2 y"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix x assume [ty]: "x be RealXREAL-0M1"
  fix y assume [ty]: "y be RealXREAL-0M1"
  assume A1: "x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y"
  obtain x1 x2 y1 y2 where
    [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
    A2: "x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *] & y =COMPLEX1R1 [*ARYTM-0K5 y1,y2 *]"and A3: "x +XCMPLX-0K2 y =COMPLEX1R1 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
    using xcmplx_0_def_4 sorry
  have "x2 =COMPLEX1R1 0NUMBERSK6 & y2 =COMPLEX1R1 0NUMBERSK6"
    using A2 complex1_lm_4 sorry
  then have A4: "+ARYTM-0K1(x2,y2) =COMPLEX1R1 0NUMBERSK6"
    using arytm_0_th_11 sorry
  have "x =COMPLEX1R1 x1 & y =COMPLEX1R1 y1"
    using A2 complex1_lm_4 sorry
  thus "+ARYTM-0K1(x9,y9) =COMPLEX1R1 x +XCMPLX-0K2 y"
    using A1 A3 A4 arytm_0_def_5 sorry
qed "sorry"

mlemma complex1_lm_6:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds oppARYTM-0K3 x =COMPLEX1R1 -REAL-1K1 x"
proof(rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  have "+ARYTM-0K1(x,oppARYTM-0K3 x) =COMPLEX1R1 0NUMBERSK6"
    using arytm_0_def_3 sorry
  then have "x +REAL-1K3 oppARYTM-0K3 x =COMPLEX1R1 0NUMBERSK6"
    using complex1_lm_5 sorry
  thus "oppARYTM-0K3 x =COMPLEX1R1 -REAL-1K1 x"
     sorry
qed "sorry"

mlemma complex1_lm_7:
" for x9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y implies  *ARYTM-0K2(x9,y9) =COMPLEX1R1 x *XCMPLX-0K3 y"
proof-
  have " for x9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y implies  *ARYTM-0K2(x9,y9) =HIDDENR1 x *XCMPLX-0K3 y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y"
    obtain x1 x2 y1 y2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *]"and A3: "y =COMPLEX1R1 [*ARYTM-0K5 y1,y2 *]"and A4: "x *XCMPLX-0K3 y =COMPLEX1R1 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
      using xcmplx_0_def_5 sorry
    have "x2 =COMPLEX1R1 0NUMBERSK6"
      using A2 complex1_lm_4 sorry
    then have A5: " *ARYTM-0K2(x2,y1) =COMPLEX1R1 0NUMBERSK6"
      using arytm_0_th_12 sorry
    have A6: "y2 =COMPLEX1R1 0NUMBERSK6"
      using A3 complex1_lm_4 sorry
    then have " *ARYTM-0K2(x1,y2) =COMPLEX1R1 0NUMBERSK6"
      using arytm_0_th_12 sorry
    then have A7: "+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) =COMPLEX1R1 0NUMBERSK6"
      using A5 arytm_0_th_11 sorry
    have "x =COMPLEX1R1 x1 & y =COMPLEX1R1 y1"
      using A2 A3 complex1_lm_4 sorry
    then have " *ARYTM-0K2(x9,y9) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2))"
      using A1 A6 arytm_0_th_11 arytm_0_th_12 sorry
    also have "... = +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)))"
      using arytm_0_th_15 sorry
    also have "... = x *XCMPLX-0K3 y"
      using A4 A7 arytm_0_def_5 sorry
    finally show " *ARYTM-0K2(x9,y9) =HIDDENR1 x *XCMPLX-0K3 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_8:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 x +XCMPLX-0K2 y implies ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 x +REAL-1K3 ReCOMPLEX1K3 y"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 x +XCMPLX-0K2 y implies ReCOMPLEX1K3 z =HIDDENR1 ReCOMPLEX1K3 x +REAL-1K3 ReCOMPLEX1K3 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z =COMPLEX1R1 x +XCMPLX-0K2 y"
    obtain x1 x2 y1 y2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *] & y =COMPLEX1R1 [*ARYTM-0K5 y1,y2 *]"and A3: "x +XCMPLX-0K2 y =COMPLEX1R1 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
      using xcmplx_0_def_4 sorry
    have A4: "ReCOMPLEX1K3 x =COMPLEX1R1 x1 & ReCOMPLEX1K3 y =COMPLEX1R1 y1"
      using A2 complex1_lm_2 sorry
    have "ReCOMPLEX1K3 z =HIDDENR1 +ARYTM-0K1(x1,y1)"
      using A1 A3 complex1_lm_2 sorry
    also have "... = ReCOMPLEX1K3 x +REAL-1K3 ReCOMPLEX1K3 y"
      using A4 complex1_lm_5 sorry
    finally show "ReCOMPLEX1K3 z =HIDDENR1 ReCOMPLEX1K3 x +REAL-1K3 ReCOMPLEX1K3 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_9:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 x +XCMPLX-0K2 y implies ImCOMPLEX1K4 z =COMPLEX1R1 ImCOMPLEX1K4 x +REAL-1K3 ImCOMPLEX1K4 y"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 x +XCMPLX-0K2 y implies ImCOMPLEX1K4 z =HIDDENR1 ImCOMPLEX1K4 x +REAL-1K3 ImCOMPLEX1K4 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z =COMPLEX1R1 x +XCMPLX-0K2 y"
    obtain x1 x2 y1 y2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *] & y =COMPLEX1R1 [*ARYTM-0K5 y1,y2 *]"and A3: "x +XCMPLX-0K2 y =COMPLEX1R1 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
      using xcmplx_0_def_4 sorry
    have A4: "ImCOMPLEX1K4 x =COMPLEX1R1 x2 & ImCOMPLEX1K4 y =COMPLEX1R1 y2"
      using A2 complex1_lm_2 sorry
    have "ImCOMPLEX1K4 z =HIDDENR1 +ARYTM-0K1(x2,y2)"
      using A1 A3 complex1_lm_2 sorry
    also have "... = ImCOMPLEX1K4 x +REAL-1K3 ImCOMPLEX1K4 y"
      using A4 complex1_lm_5 sorry
    finally show "ImCOMPLEX1K4 z =HIDDENR1 ImCOMPLEX1K4 x +REAL-1K3 ImCOMPLEX1K4 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_10:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 x *XCMPLX-0K3 y implies ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 y -REAL-1K5 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 y"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 x *XCMPLX-0K3 y implies ReCOMPLEX1K3 z =HIDDENR1 ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 y -REAL-1K5 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z =COMPLEX1R1 x *XCMPLX-0K3 y"
    obtain x1 x2 y1 y2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *] & y =COMPLEX1R1 [*ARYTM-0K5 y1,y2 *]"and A3: "x *XCMPLX-0K3 y =COMPLEX1R1 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
      using xcmplx_0_def_5 sorry
    have A4: "ReCOMPLEX1K3 x =COMPLEX1R1 x1 & ReCOMPLEX1K3 y =COMPLEX1R1 y1"
      using A2 complex1_lm_2 sorry
    have A5: "ImCOMPLEX1K4 x =COMPLEX1R1 x2 & ImCOMPLEX1K4 y =COMPLEX1R1 y2"
      using A2 complex1_lm_2 sorry
    have "ReCOMPLEX1K3 z =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)))"
      using A1 A3 complex1_lm_2 sorry
    also have "... =  *ARYTM-0K2(x1,y1) +REAL-1K3 oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))"
      using complex1_lm_5 sorry
    also have "... = x1 *REAL-1K4 y1 +REAL-1K3 oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))"
      using complex1_lm_7 sorry
    also have "... = x1 *REAL-1K4 y1 +REAL-1K3 (-REAL-1K1  *ARYTM-0K2(x2,y2))"
      using complex1_lm_6 sorry
    also have "... = x1 *REAL-1K4 y1 -REAL-1K5  *ARYTM-0K2(x2,y2)"
       sorry
    also have "... = ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 y -REAL-1K5 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 y"
      using A4 A5 complex1_lm_7 sorry
    finally show "ReCOMPLEX1K3 z =HIDDENR1 ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 y -REAL-1K5 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_11:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 x *XCMPLX-0K3 y implies ImCOMPLEX1K4 z =COMPLEX1R1 ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 y +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 y"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 x *XCMPLX-0K3 y implies ImCOMPLEX1K4 z =HIDDENR1 ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 y +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z =COMPLEX1R1 x *XCMPLX-0K3 y"
    obtain x1 x2 y1 y2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "x =COMPLEX1R1 [*ARYTM-0K5 x1,x2 *] & y =COMPLEX1R1 [*ARYTM-0K5 y1,y2 *]"and A3: "x *XCMPLX-0K3 y =COMPLEX1R1 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
      using xcmplx_0_def_5 sorry
    have A4: "ImCOMPLEX1K4 x =COMPLEX1R1 x2 & ImCOMPLEX1K4 y =COMPLEX1R1 y2"
      using A2 complex1_lm_2 sorry
    have A5: "ReCOMPLEX1K3 x =COMPLEX1R1 x1 & ReCOMPLEX1K3 y =COMPLEX1R1 y1"
      using A2 complex1_lm_2 sorry
    have "ImCOMPLEX1K4 z =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1))"
      using A1 A3 complex1_lm_2 sorry
    also have "... =  *ARYTM-0K2(x1,y2) +REAL-1K3  *ARYTM-0K2(x2,y1)"
      using complex1_lm_5 sorry
    also have "... = x1 *REAL-1K4 y2 +REAL-1K3  *ARYTM-0K2(x2,y1)"
      using complex1_lm_7 sorry
    also have "... = ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 y +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 y"
      using A4 A5 complex1_lm_7 sorry
    finally show "ImCOMPLEX1K4 z =HIDDENR1 ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 y +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_12:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 +XCMPLX-0K2 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2,ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2 *]"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 +XCMPLX-0K2 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2,ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2 *]"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?z = "[*ARYTM-0K5 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2,ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2 *]"
    obtain z9 where 
      [ty]:"z9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and z9Def:"z9 = z1 +XCMPLX-0K2 z2"
      using xcmplx_0_def_2 sorry
    have A1: "ImCOMPLEX1K4 ?z =HIDDENR1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
      using complex1_lm_2 sorry
    also have "... = ImCOMPLEX1K4 z9"
      using complex1_lm_9 sorry
    finally have "ImCOMPLEX1K4 ?z =HIDDENR1 ImCOMPLEX1K4 z9"
       sorry
    have "ReCOMPLEX1K3 ?z =HIDDENR1 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2"
      using complex1_lm_2 sorry
    also have "... = ReCOMPLEX1K3 z9"
      using complex1_lm_8 sorry
    finally have "ReCOMPLEX1K3 ?z =HIDDENR1 ReCOMPLEX1K3 z9"
       sorry
    thus "z1 +XCMPLX-0K2 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2,ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2 *]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_13:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 *XCMPLX-0K3 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2,ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 *]"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 *XCMPLX-0K3 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2,ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 *]"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?z = "[*ARYTM-0K5 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2,ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 *]"
    obtain z9 where 
      [ty]:"z9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and z9Def:"z9 = z1 *XCMPLX-0K3 z2"
      using xcmplx_0_def_2 sorry
    have A1: "ImCOMPLEX1K4 ?z =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
      using complex1_lm_2 sorry
    also have "... = ImCOMPLEX1K4 z9"
      using complex1_lm_11 sorry
    finally have "ImCOMPLEX1K4 ?z =HIDDENR1 ImCOMPLEX1K4 z9"
       sorry
    have "ReCOMPLEX1K3 ?z =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2"
      using complex1_lm_2 sorry
    also have "... = ReCOMPLEX1K3 z9"
      using complex1_lm_10 sorry
    finally have "ReCOMPLEX1K3 ?z =HIDDENR1 ReCOMPLEX1K3 z9"
       sorry
    thus "z1 *XCMPLX-0K3 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2,ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 *]"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_14:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "z1 *XCMPLX-0K3 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2,ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 *]"
      using complex1_lm_13 sorry
    thus "ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
      using complex1_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_15:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "z1 +XCMPLX-0K2 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2,ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2 *]"
      using complex1_lm_12 sorry
    thus "ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
      using complex1_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_16:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds ReCOMPLEX1K3 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds ReCOMPLEX1K3 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    have "ReCOMPLEX1K3 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 (<i>COMPLEX1K8) -REAL-1K5 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 (<i>COMPLEX1K8)"
      using complex1_lm_14 sorry
    also have "... = ReCOMPLEX1K3 x *XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ImCOMPLEX1K4 (<i>COMPLEX1K8)"
      using complex1_th_7 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally show "ReCOMPLEX1K3 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_17:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds ImCOMPLEX1K4 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 x"
proof-
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds ImCOMPLEX1K4 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
    have "ImCOMPLEX1K4 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 (<i>COMPLEX1K8) +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 (<i>COMPLEX1K8)"
      using complex1_lm_14 sorry
    also have "... = x"
      using complex1_def_1 complex1_th_7 sorry
    finally show "ImCOMPLEX1K4 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_18:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds [*ARYTM-0K5 x,y *] =COMPLEX1R1 x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  have A1: "ImCOMPLEX1K4 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ImCOMPLEX1K4 x +REAL-1K3 ImCOMPLEX1K4 (y *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using complex1_lm_15 sorry
  also have "... = 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 (y *XCMPLX-0K3 (<i>COMPLEX1K8))"
     sorry
  also have "... = y"
    using complex1_lm_17 sorry
  finally have "ImCOMPLEX1K4 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 y"
     sorry
  have "ReCOMPLEX1K3 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ReCOMPLEX1K3 x +REAL-1K3 ReCOMPLEX1K3 (y *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using complex1_lm_15 sorry
  also have "... = ReCOMPLEX1K3 x +XCMPLX-0K2 0NUMBERSK6"
    using complex1_lm_16 sorry
  also have "... = x"
    using complex1_def_1 sorry
  finally have "ReCOMPLEX1K3 (x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 x"
     sorry
  thus "[*ARYTM-0K5 x,y *] =COMPLEX1R1 x +XCMPLX-0K2 y *XCMPLX-0K3 (<i>COMPLEX1K8)"
    using A1 complex1_lm_3 sorry
qed "sorry"

(*\$CD*)
mtheorem complex1_th_8:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "z1 +XCMPLX-0K2 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2,ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2 *]"
      using complex1_lm_12 sorry
    thus "ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
      using complex1_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CD*)
mtheorem complex1_th_9:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "z1 *XCMPLX-0K3 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2,ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 *]"
      using complex1_lm_13 sorry
    thus "ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
      using complex1_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_10:
" for a be RealXREAL-0M1 holds ReCOMPLEX1K3 (a *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds ReCOMPLEX1K3 (a *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "ReCOMPLEX1K3 (a *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 (<i>COMPLEX1K8) -REAL-1K5 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 (<i>COMPLEX1K8)"
      using complex1_th_9 sorry
    also have "... = ReCOMPLEX1K3 a *XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ImCOMPLEX1K4 (<i>COMPLEX1K8)"
      using complex1_th_7 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally show "ReCOMPLEX1K3 (a *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_11:
" for a be RealXREAL-0M1 holds ImCOMPLEX1K4 (a *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds ImCOMPLEX1K4 (a *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 a"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "ImCOMPLEX1K4 (a *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 (<i>COMPLEX1K8) +REAL-1K3 ImCOMPLEX1K4 a *REAL-1K4 ReCOMPLEX1K3 (<i>COMPLEX1K8)"
      using complex1_th_9 sorry
    also have "... = a"
      using complex1_def_1 complex1_th_7 sorry
    finally show "ImCOMPLEX1K4 (a *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_12:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ReCOMPLEX1K3 (a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 a & ImCOMPLEX1K4 (a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ReCOMPLEX1K3 (a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 a & ImCOMPLEX1K4 (a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 b"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have 
      [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and
      [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 [*ARYTM-0K5 a,b *]"
      using complex1_lm_18 sorry
    thus "ReCOMPLEX1K3 (a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 a & ImCOMPLEX1K4 (a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 b"
      using complex1_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_13:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =COMPLEX1R1 z"
      using complex1_lm_3 sorry
    thus "ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 z"
      using complex1_lm_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_14:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z1 =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 z2 =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z1 =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 z2 =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume A1: "ImCOMPLEX1K4 z1 =COMPLEX1R1 0NUMBERSK6"
      and A2: "ImCOMPLEX1K4 z2 =COMPLEX1R1 0NUMBERSK6"
    have "ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2"
      using complex1_th_9 sorry
    also have "... = ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2"
      using A1 sorry
    finally show "ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2"
       sorry
    have "ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
      using complex1_th_9 sorry
    also have "... = 0NUMBERSK6"
      using A1 A2 sorry
    finally show "ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_15:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z1 =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 z2 =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z1 =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 z2 =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume A1: "ReCOMPLEX1K3 z1 =COMPLEX1R1 0NUMBERSK6"
      and A2: "ReCOMPLEX1K3 z2 =COMPLEX1R1 0NUMBERSK6"
    have "ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2"
      using complex1_th_9 sorry
    also have "... = -REAL-1K1 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2"
      using A1 sorry
    finally show "ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2"
       sorry
    have "ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1"
      using complex1_th_9 sorry
    also have "... = 0NUMBERSK6"
      using A1 A2 sorry
    finally show "ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_16:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z *XCMPLX-0K3 z) =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1 & ImCOMPLEX1K4 (z *XCMPLX-0K3 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z *XCMPLX-0K3 z) =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1 & ImCOMPLEX1K4 (z *XCMPLX-0K3 z) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z)"
  proof(rule ballI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show "ReCOMPLEX1K3 (z *XCMPLX-0K3 z) =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using complex1_th_9 sorry
    have "ImCOMPLEX1K4 (z *XCMPLX-0K3 z) =HIDDENR1 ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z +REAL-1K3 ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z"
      using complex1_th_9 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z)"
       sorry
    finally show "ImCOMPLEX1K4 (z *XCMPLX-0K3 z) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CD*)
mlemma complex1_lm_19:
" for z be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 z =COMPLEX1R1 (-REAL-1K1 ReCOMPLEX1K3 z)+XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  obtain zz where 
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  let ?z9 = "[*ARYTM-0K5 -REAL-1K1 ReCOMPLEX1K3 z,-REAL-1K1 ImCOMPLEX1K4 z *]"
  have "?z9 +XCMPLX-0K2 z =HIDDENR1 [*ARYTM-0K5 ReCOMPLEX1K3 ?z9 +REAL-1K3 ReCOMPLEX1K3 z,ImCOMPLEX1K4 ?z9 +REAL-1K3 ImCOMPLEX1K4 z *]"
    using complex1_lm_12 sorry
  also have "... = [*ARYTM-0K5 (-REAL-1K1 ReCOMPLEX1K3 z)+REAL-1K3 ReCOMPLEX1K3 z,ImCOMPLEX1K4 ?z9 +REAL-1K3 ImCOMPLEX1K4 z *]"
    using complex1_lm_2 sorry
  also have "... = [*ARYTM-0K5 zz,(-REAL-1K1 ImCOMPLEX1K4 z)+REAL-1K3 ImCOMPLEX1K4 z *]"
    using complex1_lm_2 sorry
  also have "... = 0NUMBERSK6"
    using arytm_0_def_5 sorry
  finally have "?z9 +XCMPLX-0K2 z =HIDDENR1 0NUMBERSK6"
     sorry
  thus "-XCMPLX-0K4 z =COMPLEX1R1 (-REAL-1K1 ReCOMPLEX1K3 z)+XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using complex1_lm_18 sorry
qed "sorry"

mtheorem complex1_th_17:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (-XCMPLX-0K4 z) =COMPLEX1R1 -REAL-1K1 ReCOMPLEX1K3 z & ImCOMPLEX1K4 (-XCMPLX-0K4 z) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (-XCMPLX-0K4 z) =COMPLEX1R1 -REAL-1K1 ReCOMPLEX1K3 z & ImCOMPLEX1K4 (-XCMPLX-0K4 z) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "-XCMPLX-0K4 z =COMPLEX1R1 (-REAL-1K1 ReCOMPLEX1K3 z)+XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_lm_19 sorry
    thus "ReCOMPLEX1K3 (-XCMPLX-0K4 z) =COMPLEX1R1 -REAL-1K1 ReCOMPLEX1K3 z & ImCOMPLEX1K4 (-XCMPLX-0K4 z) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z"
      using complex1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_18:
"(<i>COMPLEX1K8)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 -XCMPLX-0K4 1rCOMPLEX1K7"
   sorry

(*\$CD*)
mlemma complex1_lm_20:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 -XCMPLX-0K6 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI,rule ballI)
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
  have A1: "z1 =COMPLEX1R1 ReCOMPLEX1K3 z1 +XCMPLX-0K2 ImCOMPLEX1K4 z1 *XCMPLX-0K3 (<i>COMPLEX1K8)"
    using complex1_th_13 sorry
  have "z1 -XCMPLX-0K6 z2 =HIDDENR1 z1 +XCMPLX-0K2 (-XCMPLX-0K4 z2)"
     sorry
  also have "... = z1 +XCMPLX-0K2 ((-REAL-1K1 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    using complex1_lm_19 sorry
  also have "... = (ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using A1 sorry
  finally have "z1 -XCMPLX-0K6 z2 =HIDDENR1 (ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  thus "z1 -XCMPLX-0K6 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
qed "sorry"

mtheorem complex1_th_19:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 -XCMPLX-0K6 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 -XCMPLX-0K6 z2) =HIDDENR1 ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 -XCMPLX-0K6 z2) =HIDDENR1 ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2"
  proof(rule ballI,rule ballI,rule conjMI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "ReCOMPLEX1K3 (z1 -XCMPLX-0K6 z2) =HIDDENR1 ReCOMPLEX1K3 ((ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using complex1_lm_20 sorry
    also have "... = ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2"
      using complex1_th_12 sorry
    finally show "ReCOMPLEX1K3 (z1 -XCMPLX-0K6 z2) =HIDDENR1 ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2"
       sorry
    have "ImCOMPLEX1K4 (z1 -XCMPLX-0K6 z2) =HIDDENR1 ImCOMPLEX1K4 ((ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using complex1_lm_20 sorry
    also have "... = ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2"
      using complex1_th_12 sorry
    finally show "ImCOMPLEX1K4 (z1 -XCMPLX-0K6 z2) =HIDDENR1 ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CD*)
mlemma complex1_lm_21:
" for z be ComplexXCMPLX-0M1 holds z \<inverse>XCMPLX-0K5 =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  obtain z9 where 
    [ty]:"z9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and z9Def:"z9 = ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_0_def_2 sorry
  show "z \<inverse>XCMPLX-0K5 =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof-
    have cases: "z =COMPLEX1R1 0NUMBERSK6 or z <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "z =COMPLEX1R1 0NUMBERSK6 implies z \<inverse>XCMPLX-0K5 =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    proof(rule impI)
      assume "z =COMPLEX1R1 0NUMBERSK6"
      thus "z \<inverse>XCMPLX-0K5 =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        using complex1_th_4 sorry
    qed
    have case2: "z <>HIDDENR2 0NUMBERSK6 implies z \<inverse>XCMPLX-0K5 =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    proof(rule impI)
      assume A1: "z <>HIDDENR2 0NUMBERSK6"
      then have A2: "(ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6"
        using complex1_th_5 sorry
      have A3: "ImCOMPLEX1K4 z9 =COMPLEX1R1 (-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
        using complex1_th_12 sorry
      then have A4: "ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z9 +REAL-1K3 ReCOMPLEX1K3 z9 *REAL-1K4 ImCOMPLEX1K4 z =HIDDENR1 (ReCOMPLEX1K3 z /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)) +XCMPLX-0K2 (ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 ImCOMPLEX1K4 z"
        using complex1_th_12 sorry
      also have "... = (ReCOMPLEX1K3 z *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z))/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)) +XCMPLX-0K2 ((ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 ImCOMPLEX1K4 z)/XCMPLX-0K7 \<one>\<^sub>M"
        using xcmplx_1_th_76 sorry
      also have "... = (ReCOMPLEX1K3 z *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z))/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)) +XCMPLX-0K2 ((ImCOMPLEX1K4 z /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 ReCOMPLEX1K3 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
        using xcmplx_1_th_76 sorry
      also have "... = ((-REAL-1K1 ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z)+REAL-1K3 ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
        using xcmplx_1_th_62 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z9 +REAL-1K3 ReCOMPLEX1K3 z9 *REAL-1K4 ImCOMPLEX1K4 z =HIDDENR1 0NUMBERSK6"
         sorry
      have A5: "ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z9 -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z9 =HIDDENR1 (ReCOMPLEX1K3 z /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 (ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)) -XCMPLX-0K6 ImCOMPLEX1K4 z *XCMPLX-0K3 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))"
        using A3 complex1_th_12 sorry
      also have "... = (ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)) -XCMPLX-0K6 (ImCOMPLEX1K4 z /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))"
        using xcmplx_1_th_76 sorry
      also have "... = (ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) -XCMPLX-0K6 (ImCOMPLEX1K4 z *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z))/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))"
        using xcmplx_1_th_76 sorry
      also have "... = (ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) -XCMPLX-0K6 (-XCMPLX-0K4 (ImCOMPLEX1K4 z)^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))"
         sorry
      also have "... = (ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) -XCMPLX-0K6 (-XCMPLX-0K4 (ImCOMPLEX1K4 z)^2SQUARE-1K1 /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))"
        using xcmplx_1_th_187 sorry
      also have "... = (ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))"
         sorry
      also have "... = ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
        using xcmplx_1_th_62 sorry
      also have "... = \<one>\<^sub>M"
        using A2 xcmplx_1_th_60 sorry
      finally have "ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z9 -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z9 =HIDDENR1 \<one>\<^sub>M"
         sorry
      have "z *XCMPLX-0K3 z9 =HIDDENR1 [*ARYTM-0K5 ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z9 -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z9,ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z9 +REAL-1K3 ReCOMPLEX1K3 z9 *REAL-1K4 ImCOMPLEX1K4 z *]"
        using complex1_lm_13 sorry
      also have "... = \<one>\<^sub>M"
        using A5 A4 arytm_0_def_5 sorry
      finally have "z *XCMPLX-0K3 z9 =HIDDENR1 \<one>\<^sub>M"
         sorry
      thus "z \<inverse>XCMPLX-0K5 =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        using A1 xcmplx_0_def_7 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem complex1_th_20:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) & ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 (-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) & ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 (-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z \<inverse>XCMPLX-0K5 =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_lm_21 sorry
    thus "ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) & ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 (-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using complex1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_21:
"(<i>COMPLEX1K8)\<inverse>XCMPLX-0K5 =COMPLEX1R1 -XCMPLX-0K4 <i>COMPLEX1K8"
   sorry

mtheorem complex1_th_22:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <>HIDDENR2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 (ReCOMPLEX1K3 z)\<inverse>REAL-1K2 & ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <>HIDDENR2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =HIDDENR1 (ReCOMPLEX1K3 z)\<inverse>REAL-1K2 & ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impMI ,rule impI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "ReCOMPLEX1K3 z <>HIDDENR2 0NUMBERSK6"
      and A2: "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
    have "ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using complex1_th_20 sorry
    then have "ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =HIDDENR1 (\<one>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)/XCMPLX-0K7 (ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z)"
      using A2 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 ReCOMPLEX1K3 z"
      using A1 xcmplx_1_th_91 sorry
    also have "... = (ReCOMPLEX1K3 z)\<inverse>REAL-1K2"
      using xcmplx_1_th_215 sorry
    finally show "ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =HIDDENR1 (ReCOMPLEX1K3 z)\<inverse>REAL-1K2"
       sorry
    have "ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 (-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using complex1_th_20 sorry
    thus "ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_23:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 z <>HIDDENR2 0NUMBERSK6 implies ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 -REAL-1K1 (ImCOMPLEX1K4 z)\<inverse>REAL-1K2"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 z <>HIDDENR2 0NUMBERSK6 implies ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =HIDDENR1 -REAL-1K1 (ImCOMPLEX1K4 z)\<inverse>REAL-1K2"
  proof(rule ballI,rule impMI ,rule impI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6"
      and A2: "ImCOMPLEX1K4 z <>HIDDENR2 0NUMBERSK6"
    have "ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using complex1_th_20 sorry
    thus "ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 0NUMBERSK6"
      using A1 sorry
    have "ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =COMPLEX1R1 (-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using complex1_th_20 sorry
    then have "ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 z)/XCMPLX-0K7 (ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z)"
      using A1 xcmplx_1_th_187 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ImCOMPLEX1K4 z"
      using A2 xcmplx_1_th_91 sorry
    also have "... = -REAL-1K1 (ImCOMPLEX1K4 z)\<inverse>REAL-1K2"
      using xcmplx_1_th_215 sorry
    finally show "ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5) =HIDDENR1 -REAL-1K1 (ImCOMPLEX1K4 z)\<inverse>REAL-1K2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CD*)
mlemma complex1_lm_22:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 /XCMPLX-0K7 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) +XCMPLX-0K2 ((ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI,rule ballI)
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
  have 
    [ty]:"z1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and
    [ty]:"z2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
  obtain k where 
    [ty]:"k be ElementSUBSET-1M1-of REALNUMBERSK2" and kDef:"k = (ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1"
    using xreal_0_def_1 sorry
  obtain r i where 
    [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = ReCOMPLEX1K3 z2 /REAL-1K6 k" and
    [ty]:"i be ElementSUBSET-1M1-of REALNUMBERSK2" and iDef:"i = (-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k"
     sorry
  have A1: "ReCOMPLEX1K3 ([*ARYTM-0K5 r,i *]) =HIDDENR1 ReCOMPLEX1K3 (ReCOMPLEX1K3 z2 /REAL-1K6 k +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    using complex1_lm_18 sorry
  also have "... = ReCOMPLEX1K3 z2 /REAL-1K6 k"
    using complex1_th_12 sorry
  finally have "ReCOMPLEX1K3 ([*ARYTM-0K5 r,i *]) =HIDDENR1 ReCOMPLEX1K3 z2 /REAL-1K6 k"
     sorry
  have A2: "ImCOMPLEX1K4 ([*ARYTM-0K5 r,i *]) =HIDDENR1 ImCOMPLEX1K4 (ReCOMPLEX1K3 z2 /REAL-1K6 k +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    using complex1_lm_18 sorry
  also have "... = (-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k"
    using complex1_th_12 sorry
  finally have "ImCOMPLEX1K4 ([*ARYTM-0K5 r,i *]) =HIDDENR1 (-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k"
     sorry
  obtain r1 i1 where 
    [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and r1Def:"r1 = (ReCOMPLEX1K3 z1 /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 (ReCOMPLEX1K3 z2 /REAL-1K6 k) -XCMPLX-0K6 ImCOMPLEX1K4 z1 *REAL-1K4 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k)" and
    [ty]:"i1 be ElementSUBSET-1M1-of REALNUMBERSK2" and i1Def:"i1 = ReCOMPLEX1K3 z1 *REAL-1K4 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k) +REAL-1K3 (ReCOMPLEX1K3 z2 /REAL-1K6 k)*REAL-1K4 ImCOMPLEX1K4 z1"
    using xreal_0_def_1 sorry
  have "z1 /XCMPLX-0K7 z2 =HIDDENR1 z1 *XCMPLX-0K3 z2 \<inverse>XCMPLX-0K5"
    using xcmplx_0_def_9 sorry
  also have "... = z1 *XCMPLX-0K3 (r +XCMPLX-0K2 i *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using complex1_lm_21 sorry
  also have "... = z1 *XCMPLX-0K3 ([*ARYTM-0K5 r,i *])"
    using complex1_lm_18 sorry
  also have "... = [*ARYTM-0K5 r1,i1 *]"
    using A1 A2 complex1_lm_13 sorry
  also have "... = ((ReCOMPLEX1K3 z1 /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 (ReCOMPLEX1K3 z2 /REAL-1K6 k) -XCMPLX-0K6 ImCOMPLEX1K4 z1 *REAL-1K4 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k))+XCMPLX-0K2 (ReCOMPLEX1K3 z1 *REAL-1K4 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k) +REAL-1K3 (ReCOMPLEX1K3 z2 /REAL-1K6 k)*REAL-1K4 ImCOMPLEX1K4 z1)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using complex1_lm_18 sorry
  also have "... = ((ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 k) -XCMPLX-0K6 (ImCOMPLEX1K4 z1 /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k))+XCMPLX-0K2 (ReCOMPLEX1K3 z1 *REAL-1K4 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k) +REAL-1K3 (ReCOMPLEX1K3 z2 /REAL-1K6 k)*REAL-1K4 ImCOMPLEX1K4 z1)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_1_th_76 sorry
  also have "... = ((ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2)/REAL-1K6 k -XCMPLX-0K6 (ImCOMPLEX1K4 z1 *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z2))/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 k))+XCMPLX-0K2 ((ReCOMPLEX1K3 z1 /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 ((-REAL-1K1 ImCOMPLEX1K4 z2)/REAL-1K6 k) +XCMPLX-0K2 (ReCOMPLEX1K3 z2 /REAL-1K6 k)*REAL-1K4 ImCOMPLEX1K4 z1)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_1_th_76 sorry
  also have "... = ((ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2)/REAL-1K6 k -REAL-1K5 (ImCOMPLEX1K4 z1 *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z2))/REAL-1K6 k)+XCMPLX-0K2 ((ReCOMPLEX1K3 z1 *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z2))/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 k) +XCMPLX-0K2 (ReCOMPLEX1K3 z2 /REAL-1K6 k)*XCMPLX-0K3 (ImCOMPLEX1K4 z1 /XCMPLX-0K7 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_1_th_76 sorry
  also have "... = ((ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2)/REAL-1K6 k -REAL-1K5 (ImCOMPLEX1K4 z1 *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z2))/REAL-1K6 k)+XCMPLX-0K2 ((ReCOMPLEX1K3 z1 *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z2))/REAL-1K6 k +XCMPLX-0K2 (ImCOMPLEX1K4 z1 *REAL-1K4 ReCOMPLEX1K3 z2)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_1_th_76 sorry
  also have "... = (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z2))/REAL-1K6 k +XCMPLX-0K2 ((ReCOMPLEX1K3 z1 *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z2))/REAL-1K6 k +XCMPLX-0K2 (ImCOMPLEX1K4 z1 *REAL-1K4 ReCOMPLEX1K3 z2)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_1_th_120 sorry
  also have "... = (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/REAL-1K6 k +XCMPLX-0K2 (((-REAL-1K1 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)+REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ReCOMPLEX1K3 z2)/REAL-1K6 k)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_1_th_62 sorry
  also have "... = (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) +XCMPLX-0K2 ((ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  finally have "z1 /XCMPLX-0K7 z2 =HIDDENR1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) +XCMPLX-0K2 ((ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  thus "z1 /XCMPLX-0K7 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) +XCMPLX-0K2 ((ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
qed "sorry"

mtheorem complex1_th_24:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) & ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 (ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1)"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) & ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =HIDDENR1 (ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 ReCOMPLEX1K3 ((ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) +XCMPLX-0K2 ((ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using complex1_lm_22 sorry
    also have "... = (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1)"
      using complex1_th_12 sorry
    finally show "ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1)"
       sorry
    have "ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =HIDDENR1 ImCOMPLEX1K4 ((ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) +XCMPLX-0K2 ((ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using complex1_lm_22 sorry
    also have "... = (ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1)"
      using complex1_th_12 sorry
    finally show "ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =HIDDENR1 (ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_25:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (ImCOMPLEX1K4 z1 =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 z2 =COMPLEX1R1 0NUMBERSK6) & ReCOMPLEX1K3 z2 <>HIDDENR2 0NUMBERSK6 implies ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 ReCOMPLEX1K3 z1 /REAL-1K6 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z1 =COMPLEX1R1 0NUMBERSK6 & (ImCOMPLEX1K4 z2 =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 z2 <>HIDDENR2 0NUMBERSK6) implies ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 ReCOMPLEX1K3 z1 /REAL-1K6 ReCOMPLEX1K3 z2 & ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume A1: "ImCOMPLEX1K4 z1 =COMPLEX1R1 0NUMBERSK6"
      and A2: "ImCOMPLEX1K4 z2 =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 z2 <>HIDDENR2 0NUMBERSK6"
    have A3: "z1 /XCMPLX-0K7 z2 =COMPLEX1R1 z1 *XCMPLX-0K3 z2 \<inverse>XCMPLX-0K5 & ImCOMPLEX1K4 (z2 \<inverse>XCMPLX-0K5) =COMPLEX1R1 0NUMBERSK6"
      using A2 complex1_th_22 xcmplx_0_def_9 sorry
    then have "ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 (z2 \<inverse>XCMPLX-0K5)"
      using A1 complex1_th_14 sorry
    also have "... = ReCOMPLEX1K3 z1 *REAL-1K4 (ReCOMPLEX1K3 z2)\<inverse>REAL-1K2"
      using A2 complex1_th_22 sorry
    also have "... = ReCOMPLEX1K3 z1 /REAL-1K6 ReCOMPLEX1K3 z2"
      using xcmplx_0_def_9 sorry
    finally show "ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 ReCOMPLEX1K3 z1 /REAL-1K6 ReCOMPLEX1K3 z2"
       sorry
    show "ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 0NUMBERSK6"
      using A1 A3 complex1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_26:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (ReCOMPLEX1K3 z1 =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 z2 =COMPLEX1R1 0NUMBERSK6) & ImCOMPLEX1K4 z2 <>HIDDENR2 0NUMBERSK6 implies ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 /REAL-1K6 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z1 =COMPLEX1R1 0NUMBERSK6 & (ReCOMPLEX1K3 z2 =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 z2 <>HIDDENR2 0NUMBERSK6) implies ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 ImCOMPLEX1K4 z1 /REAL-1K6 ImCOMPLEX1K4 z2 & ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume A1: "ReCOMPLEX1K3 z1 =COMPLEX1R1 0NUMBERSK6"
      and A2: "ReCOMPLEX1K3 z2 =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 z2 <>HIDDENR2 0NUMBERSK6"
    have A3: "z1 /XCMPLX-0K7 z2 =COMPLEX1R1 z1 *XCMPLX-0K3 z2 \<inverse>XCMPLX-0K5 & ReCOMPLEX1K3 (z2 \<inverse>XCMPLX-0K5) =COMPLEX1R1 0NUMBERSK6"
      using A2 complex1_th_23 xcmplx_0_def_9 sorry
    then have "ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 (z2 \<inverse>XCMPLX-0K5)"
      using A1 complex1_th_15 sorry
    also have "... = -REAL-1K1 ImCOMPLEX1K4 z1 *REAL-1K4 (-REAL-1K1 (ImCOMPLEX1K4 z2)\<inverse>REAL-1K2)"
      using A2 complex1_th_23 sorry
    also have "... = -REAL-1K1 (-REAL-1K1 ImCOMPLEX1K4 z1 *REAL-1K4 (ImCOMPLEX1K4 z2)\<inverse>REAL-1K2)"
       sorry
    also have "... = ImCOMPLEX1K4 z1 /REAL-1K6 ImCOMPLEX1K4 z2"
      using xcmplx_0_def_9 sorry
    finally show "ReCOMPLEX1K3 (z1 /XCMPLX-0K7 z2) =HIDDENR1 ImCOMPLEX1K4 z1 /REAL-1K6 ImCOMPLEX1K4 z2"
       sorry
    show "ImCOMPLEX1K4 (z1 /XCMPLX-0K7 z2) =COMPLEX1R1 0NUMBERSK6"
      using A1 A3 complex1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef complex1_def_11 (" _ *''COMPLEX1K9" [228]228 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z *'COMPLEX1K9 \<rightarrow> ComplexXCMPLX-0M1 equals
  ReCOMPLEX1K3 z -XCMPLX-0K6 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  (*coherence*)
    show "ReCOMPLEX1K3 z -XCMPLX-0K6 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) be ComplexXCMPLX-0M1"
       sorry
qed "sorry"

mtheorem COMPLEX1K9_involutiveness:
" for z be ComplexXCMPLX-0M1 holds (z *'COMPLEX1K9)*'COMPLEX1K9 =HIDDENR1 z"
proof-
  have " for it be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds it =HIDDENR1 z *'COMPLEX1K9 implies z =HIDDENR1 it *'COMPLEX1K9"
  proof-
    have " for it be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds it =HIDDENR1 ReCOMPLEX1K3 z -XCMPLX-0K6 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) implies z =HIDDENR1 ReCOMPLEX1K3 it -XCMPLX-0K6 ImCOMPLEX1K4 it *XCMPLX-0K3 (<i>COMPLEX1K8)"
    proof-
      have " for z be ComplexXCMPLX-0M1 holds  for z9 be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 ReCOMPLEX1K3 z9 -XCMPLX-0K6 ImCOMPLEX1K4 z9 *XCMPLX-0K3 (<i>COMPLEX1K8) implies z9 =HIDDENR1 ReCOMPLEX1K3 z -XCMPLX-0K6 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      proof(rule ballI,rule ballI,rule impI)
        fix z assume [ty]: "z be ComplexXCMPLX-0M1"
        fix z9 assume [ty]: "z9 be ComplexXCMPLX-0M1"
        assume "z =COMPLEX1R1 ReCOMPLEX1K3 z9 -XCMPLX-0K6 ImCOMPLEX1K4 z9 *XCMPLX-0K3 (<i>COMPLEX1K8)"
        then have "z =COMPLEX1R1 ReCOMPLEX1K3 z9 +XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z9)*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
        then have "ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 z9 & -REAL-1K1 ImCOMPLEX1K4 z =COMPLEX1R1 -REAL-1K1 (-REAL-1K1 ImCOMPLEX1K4 z9)"
          using complex1_th_12 sorry
        then have "z9 =HIDDENR1 ReCOMPLEX1K3 z +XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using complex1_th_13 sorry
        also have "... = ReCOMPLEX1K3 z -XCMPLX-0K6 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
        finally show "z9 =HIDDENR1 ReCOMPLEX1K3 z -XCMPLX-0K6 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using complex1_def_11 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_27:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z *'COMPLEX1K9) =COMPLEX1R1 ReCOMPLEX1K3 z & ImCOMPLEX1K4 (z *'COMPLEX1K9) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z *'COMPLEX1K9) =COMPLEX1R1 ReCOMPLEX1K3 z & ImCOMPLEX1K4 (z *'COMPLEX1K9) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z *'COMPLEX1K9 =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "ReCOMPLEX1K3 (z *'COMPLEX1K9) =COMPLEX1R1 ReCOMPLEX1K3 z & ImCOMPLEX1K4 (z *'COMPLEX1K9) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z"
      using complex1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_28:
"(0NUMBERSK6)*'COMPLEX1K9 =COMPLEX1R1 0NUMBERSK6"
  using complex1_th_4 sorry

mtheorem complex1_th_29:
" for z be ComplexXCMPLX-0M1 holds z *'COMPLEX1K9 =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds z *'COMPLEX1K9 =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume "z *'COMPLEX1K9 =COMPLEX1R1 0NUMBERSK6"
    then have Cut820: "0NUMBERSK6 =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    have "ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 (0NUMBERSK6) & ImCOMPLEX1K4 z =COMPLEX1R1 ImCOMPLEX1K4 (0NUMBERSK6)"
    proof-
      show "ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 (0NUMBERSK6) & ImCOMPLEX1K4 z =COMPLEX1R1 ImCOMPLEX1K4 (0NUMBERSK6)"
        using complex1_th_12 Cut820 sorry
    qed
    thus "z =COMPLEX1R1 0NUMBERSK6"
      using complex1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_30:
"(1rCOMPLEX1K7)*'COMPLEX1K9 =COMPLEX1R1 1rCOMPLEX1K7"
  using complex1_th_6 sorry

mtheorem complex1_th_31:
"(<i>COMPLEX1K8)*'COMPLEX1K9 =COMPLEX1R1 -XCMPLX-0K4 <i>COMPLEX1K8"
  using complex1_th_7 sorry

mtheorem complex1_th_32:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 +XCMPLX-0K2 z2)*'COMPLEX1K9 =COMPLEX1R1 z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 +XCMPLX-0K2 z2)*'COMPLEX1K9 =COMPLEX1R1 z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "ReCOMPLEX1K3 ((z1 +XCMPLX-0K2 z2)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9) & ImCOMPLEX1K4 ((z1 +XCMPLX-0K2 z2)*'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 (z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9)"
    proof(rule conjMI)
      have "ReCOMPLEX1K3 ((z1 +XCMPLX-0K2 z2)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2)"
        using complex1_th_27 sorry
      also have "... = ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2"
        using complex1_th_8 sorry
      also have "... = ReCOMPLEX1K3 (z1 *'COMPLEX1K9) +REAL-1K3 ReCOMPLEX1K3 z2"
        using complex1_th_27 sorry
      also have "... = ReCOMPLEX1K3 (z1 *'COMPLEX1K9) +REAL-1K3 ReCOMPLEX1K3 (z2 *'COMPLEX1K9)"
        using complex1_th_27 sorry
      also have "... = ReCOMPLEX1K3 (z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9)"
        using complex1_th_8 sorry
      finally show "ReCOMPLEX1K3 ((z1 +XCMPLX-0K2 z2)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9)"
         sorry
      have "ImCOMPLEX1K4 ((z1 +XCMPLX-0K2 z2)*'COMPLEX1K9) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2)"
        using complex1_th_27 sorry
      also have "... = -REAL-1K1 (ImCOMPLEX1K4 z1 +REAL-1K3 (-REAL-1K1 (-REAL-1K1 ImCOMPLEX1K4 z2)))"
        using complex1_th_8 sorry
      also have "... = (-REAL-1K1 ImCOMPLEX1K4 z1)+REAL-1K3 (-REAL-1K1 ImCOMPLEX1K4 z2)"
         sorry
      also have "... = ImCOMPLEX1K4 (z1 *'COMPLEX1K9) +REAL-1K3 (-REAL-1K1 ImCOMPLEX1K4 z2)"
        using complex1_th_27 sorry
      also have "... = ImCOMPLEX1K4 (z1 *'COMPLEX1K9) +REAL-1K3 ImCOMPLEX1K4 (z2 *'COMPLEX1K9)"
        using complex1_th_27 sorry
      also have "... = ImCOMPLEX1K4 (z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9)"
        using complex1_th_8 sorry
      finally show "ImCOMPLEX1K4 ((z1 +XCMPLX-0K2 z2)*'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 (z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9)"
         sorry
    qed
    thus "(z1 +XCMPLX-0K2 z2)*'COMPLEX1K9 =COMPLEX1R1 z1 *'COMPLEX1K9 +XCMPLX-0K2 z2 *'COMPLEX1K9"
      using complex1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_33:
" for z be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 z)*'COMPLEX1K9 =COMPLEX1R1 -XCMPLX-0K4 z *'COMPLEX1K9"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 z)*'COMPLEX1K9 =COMPLEX1R1 -XCMPLX-0K4 z *'COMPLEX1K9"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "ReCOMPLEX1K3 ((-XCMPLX-0K4 z)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (-XCMPLX-0K4 z *'COMPLEX1K9) & ImCOMPLEX1K4 ((-XCMPLX-0K4 z)*'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 (-XCMPLX-0K4 z *'COMPLEX1K9)"
    proof(rule conjMI)
      have "ReCOMPLEX1K3 ((-XCMPLX-0K4 z)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (-XCMPLX-0K4 z)"
        using complex1_th_27 sorry
      also have "... = -REAL-1K1 ReCOMPLEX1K3 z"
        using complex1_th_17 sorry
      also have "... = -REAL-1K1 ReCOMPLEX1K3 (z *'COMPLEX1K9)"
        using complex1_th_27 sorry
      also have "... = ReCOMPLEX1K3 (-XCMPLX-0K4 z *'COMPLEX1K9)"
        using complex1_th_17 sorry
      finally show "ReCOMPLEX1K3 ((-XCMPLX-0K4 z)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (-XCMPLX-0K4 z *'COMPLEX1K9)"
         sorry
      have "ImCOMPLEX1K4 ((-XCMPLX-0K4 z)*'COMPLEX1K9) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 (-XCMPLX-0K4 z)"
        using complex1_th_27 sorry
      also have "... = -REAL-1K1 (-REAL-1K1 ImCOMPLEX1K4 z)"
        using complex1_th_17 sorry
      also have "... = -REAL-1K1 ImCOMPLEX1K4 (z *'COMPLEX1K9)"
        using complex1_th_27 sorry
      also have "... = ImCOMPLEX1K4 (-XCMPLX-0K4 z *'COMPLEX1K9)"
        using complex1_th_17 sorry
      finally show "ImCOMPLEX1K4 ((-XCMPLX-0K4 z)*'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 (-XCMPLX-0K4 z *'COMPLEX1K9)"
         sorry
    qed
    thus "(-XCMPLX-0K4 z)*'COMPLEX1K9 =COMPLEX1R1 -XCMPLX-0K4 z *'COMPLEX1K9"
      using complex1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_34:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 -XCMPLX-0K6 z2)*'COMPLEX1K9 =COMPLEX1R1 z1 *'COMPLEX1K9 -XCMPLX-0K6 z2 *'COMPLEX1K9"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 -XCMPLX-0K6 z2)*'COMPLEX1K9 =HIDDENR1 z1 *'COMPLEX1K9 -XCMPLX-0K6 z2 *'COMPLEX1K9"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "(z1 -XCMPLX-0K6 z2)*'COMPLEX1K9 =HIDDENR1 (z1 +XCMPLX-0K2 (-XCMPLX-0K4 z2))*'COMPLEX1K9"
       sorry
    also have "... = z1 *'COMPLEX1K9 +XCMPLX-0K2 (-XCMPLX-0K4 z2)*'COMPLEX1K9"
      using complex1_th_32 sorry
    also have "... = z1 *'COMPLEX1K9 +XCMPLX-0K2 (-XCMPLX-0K4 z2 *'COMPLEX1K9)"
      using complex1_th_33 sorry
    also have "... = z1 *'COMPLEX1K9 -XCMPLX-0K6 z2 *'COMPLEX1K9"
       sorry
    finally show "(z1 -XCMPLX-0K6 z2)*'COMPLEX1K9 =HIDDENR1 z1 *'COMPLEX1K9 -XCMPLX-0K6 z2 *'COMPLEX1K9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_35:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 *XCMPLX-0K3 z2)*'COMPLEX1K9 =COMPLEX1R1 z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 *XCMPLX-0K3 z2)*'COMPLEX1K9 =COMPLEX1R1 z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have A1: "ReCOMPLEX1K3 (z1 *'COMPLEX1K9) =COMPLEX1R1 ReCOMPLEX1K3 z1 & ReCOMPLEX1K3 (z2 *'COMPLEX1K9) =COMPLEX1R1 ReCOMPLEX1K3 z2"
      using complex1_th_27 sorry
    have A2: "ImCOMPLEX1K4 (z1 *'COMPLEX1K9) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z1 & ImCOMPLEX1K4 (z2 *'COMPLEX1K9) =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 z2"
      using complex1_th_27 sorry
    have "ReCOMPLEX1K3 ((z1 *XCMPLX-0K3 z2)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9) & ImCOMPLEX1K4 ((z1 *XCMPLX-0K3 z2)*'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 (z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9)"
    proof(rule conjMI)
      have "ReCOMPLEX1K3 ((z1 *XCMPLX-0K3 z2)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2)"
        using complex1_th_27 sorry
      also have "... = ReCOMPLEX1K3 (z1 *'COMPLEX1K9) *REAL-1K4 ReCOMPLEX1K3 (z2 *'COMPLEX1K9) -REAL-1K5 (-REAL-1K1 ImCOMPLEX1K4 (z1 *'COMPLEX1K9))*REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 (z2 *'COMPLEX1K9))"
        using A1 A2 complex1_th_9 sorry
      also have "... = ReCOMPLEX1K3 (z1 *'COMPLEX1K9) *REAL-1K4 ReCOMPLEX1K3 (z2 *'COMPLEX1K9) -REAL-1K5 (-REAL-1K1 (-REAL-1K1 ImCOMPLEX1K4 (z1 *'COMPLEX1K9) *REAL-1K4 ImCOMPLEX1K4 (z2 *'COMPLEX1K9)))"
         sorry
      also have "... = ReCOMPLEX1K3 (z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9)"
        using complex1_th_9 sorry
      finally show "ReCOMPLEX1K3 ((z1 *XCMPLX-0K3 z2)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9)"
         sorry
      have "ImCOMPLEX1K4 ((z1 *XCMPLX-0K3 z2)*'COMPLEX1K9) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2)"
        using complex1_th_27 sorry
      also have "... = -REAL-1K1 (ReCOMPLEX1K3 (z1 *'COMPLEX1K9) *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 (z2 *'COMPLEX1K9)) +REAL-1K3 ReCOMPLEX1K3 (z2 *'COMPLEX1K9) *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 (z1 *'COMPLEX1K9)))"
        using A1 A2 complex1_th_9 sorry
      also have "... = ReCOMPLEX1K3 (z2 *'COMPLEX1K9) *REAL-1K4 ImCOMPLEX1K4 (z1 *'COMPLEX1K9) +REAL-1K3 (-REAL-1K1 (-REAL-1K1 ReCOMPLEX1K3 (z1 *'COMPLEX1K9) *REAL-1K4 ImCOMPLEX1K4 (z2 *'COMPLEX1K9)))"
         sorry
      also have "... = ImCOMPLEX1K4 (z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9)"
        using complex1_th_9 sorry
      finally show "ImCOMPLEX1K4 ((z1 *XCMPLX-0K3 z2)*'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 (z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9)"
         sorry
    qed
    thus "(z1 *XCMPLX-0K3 z2)*'COMPLEX1K9 =COMPLEX1R1 z1 *'COMPLEX1K9 *XCMPLX-0K3 z2 *'COMPLEX1K9"
      using complex1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_36:
" for z be ComplexXCMPLX-0M1 holds (z \<inverse>XCMPLX-0K5)*'COMPLEX1K9 =COMPLEX1R1 (z *'COMPLEX1K9)\<inverse>XCMPLX-0K5"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (z \<inverse>XCMPLX-0K5)*'COMPLEX1K9 =COMPLEX1R1 (z *'COMPLEX1K9)\<inverse>XCMPLX-0K5"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: "ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 (z *'COMPLEX1K9) & -REAL-1K1 ImCOMPLEX1K4 z =COMPLEX1R1 ImCOMPLEX1K4 (z *'COMPLEX1K9)"
      using complex1_th_27 sorry
    have "ReCOMPLEX1K3 ((z \<inverse>XCMPLX-0K5)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 ((z *'COMPLEX1K9)\<inverse>XCMPLX-0K5) & ImCOMPLEX1K4 ((z \<inverse>XCMPLX-0K5)*'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 ((z *'COMPLEX1K9)\<inverse>XCMPLX-0K5)"
    proof(rule conjMI)
      have "ReCOMPLEX1K3 ((z \<inverse>XCMPLX-0K5)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 (z \<inverse>XCMPLX-0K5)"
        using complex1_th_27 sorry
      also have "... = ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
        using complex1_th_20 sorry
      also have "... = ReCOMPLEX1K3 (z *'COMPLEX1K9) /XCMPLX-0K7 ((ReCOMPLEX1K3 (z *'COMPLEX1K9))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z *'COMPLEX1K9))^2SQUARE-1K1)"
        using A1 sorry
      also have "... = ReCOMPLEX1K3 ((z *'COMPLEX1K9)\<inverse>XCMPLX-0K5)"
        using complex1_th_20 sorry
      finally show "ReCOMPLEX1K3 ((z \<inverse>XCMPLX-0K5)*'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 ((z *'COMPLEX1K9)\<inverse>XCMPLX-0K5)"
         sorry
      have "ImCOMPLEX1K4 ((z \<inverse>XCMPLX-0K5)*'COMPLEX1K9) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5)"
        using complex1_th_27 sorry
      also have "... = -XCMPLX-0K4 (-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
        using complex1_th_20 sorry
      also have "... = (-REAL-1K1 ImCOMPLEX1K4 (z *'COMPLEX1K9))/XCMPLX-0K7 ((ReCOMPLEX1K3 (z *'COMPLEX1K9))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z *'COMPLEX1K9))^2SQUARE-1K1)"
        using A1 xcmplx_1_th_187 sorry
      also have "... = ImCOMPLEX1K4 ((z *'COMPLEX1K9)\<inverse>XCMPLX-0K5)"
        using complex1_th_20 sorry
      finally show "ImCOMPLEX1K4 ((z \<inverse>XCMPLX-0K5)*'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 ((z *'COMPLEX1K9)\<inverse>XCMPLX-0K5)"
         sorry
    qed
    thus "(z \<inverse>XCMPLX-0K5)*'COMPLEX1K9 =COMPLEX1R1 (z *'COMPLEX1K9)\<inverse>XCMPLX-0K5"
      using complex1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_37:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 /XCMPLX-0K7 z2)*'COMPLEX1K9 =COMPLEX1R1 z1 *'COMPLEX1K9 /XCMPLX-0K7 z2 *'COMPLEX1K9"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 /XCMPLX-0K7 z2)*'COMPLEX1K9 =HIDDENR1 z1 *'COMPLEX1K9 /XCMPLX-0K7 z2 *'COMPLEX1K9"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "(z1 /XCMPLX-0K7 z2)*'COMPLEX1K9 =HIDDENR1 (z1 *XCMPLX-0K3 z2 \<inverse>XCMPLX-0K5)*'COMPLEX1K9"
      using xcmplx_0_def_9 sorry
    also have "... = z1 *'COMPLEX1K9 *XCMPLX-0K3 (z2 \<inverse>XCMPLX-0K5)*'COMPLEX1K9"
      using complex1_th_35 sorry
    also have "... = z1 *'COMPLEX1K9 *XCMPLX-0K3 (z2 *'COMPLEX1K9)\<inverse>XCMPLX-0K5"
      using complex1_th_36 sorry
    also have "... = z1 *'COMPLEX1K9 /XCMPLX-0K7 z2 *'COMPLEX1K9"
      using xcmplx_0_def_9 sorry
    finally show "(z1 /XCMPLX-0K7 z2)*'COMPLEX1K9 =HIDDENR1 z1 *'COMPLEX1K9 /XCMPLX-0K7 z2 *'COMPLEX1K9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_38:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies z *'COMPLEX1K9 =COMPLEX1R1 z"
  using complex1_th_27 sorry

mtheorem complex1_reduce_1:
  mlet "r be RealXREAL-0M1"
"reduce r *'COMPLEX1K9 to r"
proof
(*reducibility*)
  show "r *'COMPLEX1K9 =HIDDENR1 r"
    using complex1_th_38 sorry
qed "sorry"

mtheorem complex1_th_39:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 implies z *'COMPLEX1K9 =COMPLEX1R1 -XCMPLX-0K4 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 implies z *'COMPLEX1K9 =HIDDENR1 -XCMPLX-0K4 z"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6"
    then have "z *'COMPLEX1K9 =HIDDENR1 (-XCMPLX-0K4 0NUMBERSK6)+XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    also have "... = -XCMPLX-0K4 z"
      using A1 complex1_lm_19 sorry
    finally show "z *'COMPLEX1K9 =HIDDENR1 -XCMPLX-0K4 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_40:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z *XCMPLX-0K3 z *'COMPLEX1K9) =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1 & ImCOMPLEX1K4 (z *XCMPLX-0K3 z *'COMPLEX1K9) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z *XCMPLX-0K3 z *'COMPLEX1K9) =HIDDENR1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1 & ImCOMPLEX1K4 (z *XCMPLX-0K3 z *'COMPLEX1K9) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "ReCOMPLEX1K3 (z *XCMPLX-0K3 z *'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 (z *'COMPLEX1K9) -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 (z *'COMPLEX1K9)"
      using complex1_th_9 sorry
    also have "... = ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 (z *'COMPLEX1K9)"
      using complex1_th_27 sorry
    also have "... = ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z)"
      using complex1_th_27 sorry
    also have "... = (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
       sorry
    finally show "ReCOMPLEX1K3 (z *XCMPLX-0K3 z *'COMPLEX1K9) =HIDDENR1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
       sorry
    have "ImCOMPLEX1K4 (z *XCMPLX-0K3 z *'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 (z *'COMPLEX1K9) +REAL-1K3 ReCOMPLEX1K3 (z *'COMPLEX1K9) *REAL-1K4 ImCOMPLEX1K4 z"
      using complex1_th_9 sorry
    also have "... = ReCOMPLEX1K3 z *REAL-1K4 (-REAL-1K1 ImCOMPLEX1K4 z) +REAL-1K3 ReCOMPLEX1K3 (z *'COMPLEX1K9) *REAL-1K4 ImCOMPLEX1K4 z"
      using complex1_th_27 sorry
    also have "... = (-REAL-1K1 ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z)+REAL-1K3 ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z"
      using complex1_th_27 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally show "ImCOMPLEX1K4 (z *XCMPLX-0K3 z *'COMPLEX1K9) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_41:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z +XCMPLX-0K2 z *'COMPLEX1K9) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z & ImCOMPLEX1K4 (z +XCMPLX-0K2 z *'COMPLEX1K9) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z +XCMPLX-0K2 z *'COMPLEX1K9) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z & ImCOMPLEX1K4 (z +XCMPLX-0K2 z *'COMPLEX1K9) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "ReCOMPLEX1K3 (z +XCMPLX-0K2 z *'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 z +REAL-1K3 ReCOMPLEX1K3 (z *'COMPLEX1K9)"
      using complex1_th_8 sorry
    also have "... = ReCOMPLEX1K3 z +REAL-1K3 ReCOMPLEX1K3 z"
      using complex1_th_27 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z"
       sorry
    finally show "ReCOMPLEX1K3 (z +XCMPLX-0K2 z *'COMPLEX1K9) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z"
       sorry
    have "ImCOMPLEX1K4 (z +XCMPLX-0K2 z *'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 z +REAL-1K3 ImCOMPLEX1K4 (z *'COMPLEX1K9)"
      using complex1_th_8 sorry
    also have "... = ImCOMPLEX1K4 z +REAL-1K3 (-REAL-1K1 ImCOMPLEX1K4 z)"
      using complex1_th_27 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally show "ImCOMPLEX1K4 (z +XCMPLX-0K2 z *'COMPLEX1K9) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_42:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z -XCMPLX-0K6 z *'COMPLEX1K9) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (z -XCMPLX-0K6 z *'COMPLEX1K9) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (z -XCMPLX-0K6 z *'COMPLEX1K9) =HIDDENR1 0NUMBERSK6 & ImCOMPLEX1K4 (z -XCMPLX-0K6 z *'COMPLEX1K9) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 z"
  proof(rule ballI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "ReCOMPLEX1K3 (z -XCMPLX-0K6 z *'COMPLEX1K9) =HIDDENR1 ReCOMPLEX1K3 z -REAL-1K5 ReCOMPLEX1K3 (z *'COMPLEX1K9)"
      using complex1_th_19 sorry
    also have "... = ReCOMPLEX1K3 z -REAL-1K5 ReCOMPLEX1K3 z"
      using complex1_th_27 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally show "ReCOMPLEX1K3 (z -XCMPLX-0K6 z *'COMPLEX1K9) =HIDDENR1 0NUMBERSK6"
       sorry
    have "ImCOMPLEX1K4 (z -XCMPLX-0K6 z *'COMPLEX1K9) =HIDDENR1 ImCOMPLEX1K4 z -REAL-1K5 ImCOMPLEX1K4 (z *'COMPLEX1K9)"
      using complex1_th_19 sorry
    also have "... = ImCOMPLEX1K4 z -REAL-1K5 (-REAL-1K1 ImCOMPLEX1K4 z)"
      using complex1_th_27 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 z"
       sorry
    finally show "ImCOMPLEX1K4 (z -XCMPLX-0K6 z *'COMPLEX1K9) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef complex1_def_12 (" |.COMPLEX1K10  _ .|" [0]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func  |.COMPLEX1K10 z.| \<rightarrow> RealXREAL-0M1 equals
  sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
proof-
  (*coherence*)
    show "sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem COMPLEX1K10_projectivity:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10  |.COMPLEX1K10 z.| .| =HIDDENR1  |.COMPLEX1K10 z.|"
proof-
  have " for it be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds it =HIDDENR1  |.COMPLEX1K10 z.| implies it =HIDDENR1  |.COMPLEX1K10 it.|"
  proof-
    have " for it be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds it =HIDDENR1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) implies it =HIDDENR1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 it)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 it)^2SQUARE-1K1)"
    proof-
      have " for r be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds r =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) implies r =HIDDENR1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 r)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 r)^2SQUARE-1K1)"
      proof(rule ballI,rule ballI,rule impI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        obtain rr where 
          [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr = r"
          using xreal_0_def_1 sorry
        fix z assume [ty]: "z be ComplexXCMPLX-0M1"
        assume A1: "r =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
        have "(ReCOMPLEX1K3 z)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & (ImCOMPLEX1K4 z)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
          using xreal_1_th_63 sorry
        then have "r >=XXREAL-0R2 0NUMBERSK6"
          using A1 square_1_def_2 sorry
        then have A2: "ReCOMPLEX1K3 rr >=XXREAL-0R2 0NUMBERSK6"
          using complex1_def_1 sorry
        have "r =HIDDENR1 ReCOMPLEX1K3 rr"
          using complex1_def_1 sorry
        also have "... = sqrtSQUARE-1K3 ((ReCOMPLEX1K3 r)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 r)^2SQUARE-1K1)"
          using A2 square_1_th_22 sorry
        finally show "r =HIDDENR1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 r)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 r)^2SQUARE-1K1)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using complex1_def_12 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_43:
" for a be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies  |.COMPLEX1K10 a.| =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies  |.COMPLEX1K10 a.| =HIDDENR1 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a >=XXREAL-0R2 0NUMBERSK6"
    then have "ReCOMPLEX1K3 a >=XXREAL-0R2 0NUMBERSK6"
      using complex1_def_1 sorry
    then have " |.COMPLEX1K10 a.| =HIDDENR1 ReCOMPLEX1K3 a"
      using square_1_th_22 sorry
    also have "... = a"
      using complex1_def_1 sorry
    finally show " |.COMPLEX1K10 a.| =HIDDENR1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_cl_4:
  mlet "z be zeroORDINAL1V8\<bar>ComplexXCMPLX-0M1"
"cluster  |.COMPLEX1K10 z.| as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show " |.COMPLEX1K10 z.| be zeroORDINAL1V8"
    using complex1_th_4 square_1_th_17 sorry
qed "sorry"

mtheorem complex1_th_44:
" |.COMPLEX1K10 0NUMBERSK6 .| =COMPLEX1R1 0NUMBERSK6"
   sorry

mtheorem complex1_cl_5:
  mlet "z be  non zeroORDINAL1V8\<bar>ComplexXCMPLX-0M1"
"cluster  |.COMPLEX1K10 z.| as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show " |.COMPLEX1K10 z.| be  non zeroORDINAL1V8"
  proof-
    have " |.COMPLEX1K10 z.| be zeroORDINAL1V8 implies  not  True "
    proof(rule impI)
      assume " |.COMPLEX1K10 z.| be zeroORDINAL1V8"
      then have "(ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
        using complex1_lm_1 square_1_th_24 sorry
      thus " not  True "
        using complex1_th_5 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem complex1_th_45:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 0NUMBERSK6"
   sorry

mtheorem complex1_cl_6:
  mlet "z be ComplexXCMPLX-0M1"
"cluster  |.COMPLEX1K10 z.| as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show " |.COMPLEX1K10 z.| be  non negativeXXREAL-0V3"
  proof-
    have " not  |.COMPLEX1K10 z.| be negativeXXREAL-0V3"
    proof-
      have "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
        using complex1_lm_1 sorry
      thus " not  |.COMPLEX1K10 z.| be negativeXXREAL-0V3"
        using square_1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem complex1_th_46:
" for z be ComplexXCMPLX-0M1 holds 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 z.|"
   sorry

mtheorem complex1_th_47:
" for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 0NUMBERSK6 iff 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z.|"
   sorry

mtheorem complex1_th_48:
" |.COMPLEX1K10 1rCOMPLEX1K7.| =COMPLEX1R1 \<one>\<^sub>M"
  using complex1_th_6 square_1_th_18 sorry

mtheorem complex1_th_49:
" |.COMPLEX1K10 <i>COMPLEX1K8 .| =COMPLEX1R1 \<one>\<^sub>M"
  using complex1_th_7 square_1_th_18 sorry

mlemma complex1_lm_23:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 -XCMPLX-0K4 z .| =COMPLEX1R1  |.COMPLEX1K10 z.|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 -XCMPLX-0K4 z .| =HIDDENR1  |.COMPLEX1K10 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 -XCMPLX-0K4 z .| =HIDDENR1 sqrtSQUARE-1K3 ((-REAL-1K1 ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (-XCMPLX-0K4 z))^2SQUARE-1K1)"
      using complex1_th_17 sorry
    also have "... = sqrtSQUARE-1K3 ((-REAL-1K1 ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using complex1_th_17 sorry
    also have "... =  |.COMPLEX1K10 z.|"
       sorry
    finally show " |.COMPLEX1K10 -XCMPLX-0K4 z .| =HIDDENR1  |.COMPLEX1K10 z.|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_24:
" for a be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies  |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
proof-
  have " for a be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies  |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 0NUMBERSK6"
    then have " |.COMPLEX1K10 -XCMPLX-0K4 a .| =COMPLEX1R1 -XCMPLX-0K4 a"
      using complex1_th_43 sorry
    thus " |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
      using complex1_lm_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_25:
" for a be RealXREAL-0M1 holds sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1  |.COMPLEX1K10 a.|"
proof-
  have " for a be RealXREAL-0M1 holds sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1  |.COMPLEX1K10 a.|"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    show "sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1  |.COMPLEX1K10 a.|"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-0R1 a or  not 0NUMBERSK6 <=XXREAL-0R1 a"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-0R1 a implies sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1  |.COMPLEX1K10 a.|"
      proof(rule impI)
        assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
        then have "sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1 a"
          using square_1_th_22 sorry
        thus "sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1  |.COMPLEX1K10 a.|"
          using A1 complex1_th_43 sorry
      qed
      have case2: " not 0NUMBERSK6 <=XXREAL-0R1 a implies sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1  |.COMPLEX1K10 a.|"
      proof(rule impI)
        assume A2: " not 0NUMBERSK6 <=XXREAL-0R1 a"
        then have " |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
          using complex1_lm_24 sorry
        thus "sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1  |.COMPLEX1K10 a.|"
          using A2 square_1_th_23 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_50:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies  |.COMPLEX1K10 z.| =COMPLEX1R1  |.COMPLEX1K10 ReCOMPLEX1K3 z.|"
  using complex1_lm_25 sorry

mtheorem complex1_th_51:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 implies  |.COMPLEX1K10 z.| =COMPLEX1R1  |.COMPLEX1K10 ImCOMPLEX1K4 z.|"
  using complex1_lm_25 sorry

mtheorem complex1_th_52:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 -XCMPLX-0K4 z .| =COMPLEX1R1  |.COMPLEX1K10 z.|"
  using complex1_lm_23 sorry

mtheorem complex1_th_53:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z *'COMPLEX1K9.| =COMPLEX1R1  |.COMPLEX1K10 z.|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z *'COMPLEX1K9.| =HIDDENR1  |.COMPLEX1K10 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 z *'COMPLEX1K9.| =HIDDENR1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z *'COMPLEX1K9))^2SQUARE-1K1)"
      using complex1_th_27 sorry
    also have "... = sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using complex1_th_27 sorry
    also have "... =  |.COMPLEX1K10 z.|"
       sorry
    finally show " |.COMPLEX1K10 z *'COMPLEX1K9.| =HIDDENR1  |.COMPLEX1K10 z.|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_26:
" for a be RealXREAL-0M1 holds -XCMPLX-0K4  |.COMPLEX1K10 a.| <=XXREAL-0R1 a & a <=XXREAL-0R1  |.COMPLEX1K10 a.|"
proof-
  have " for a be RealXREAL-0M1 holds -XCMPLX-0K4  |.COMPLEX1K10 a.| <=XXREAL-0R1 a & a <=XXREAL-0R1  |.COMPLEX1K10 a.|"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a <XXREAL-0R3 0NUMBERSK6 implies -XCMPLX-0K4  |.COMPLEX1K10 a.| <=XXREAL-0R1 a & a <=XXREAL-0R1  |.COMPLEX1K10 a.|"
    proof(rule impI)
      assume "a <XXREAL-0R3 0NUMBERSK6"
      then have " |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
        using complex1_lm_24 sorry
      thus "-XCMPLX-0K4  |.COMPLEX1K10 a.| <=XXREAL-0R1 a & a <=XXREAL-0R1  |.COMPLEX1K10 a.|"
         sorry
    qed
    thus "-XCMPLX-0K4  |.COMPLEX1K10 a.| <=XXREAL-0R1 a & a <=XXREAL-0R1  |.COMPLEX1K10 a.|"
      using complex1_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_54:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <=XXREAL-0R1  |.COMPLEX1K10 z.|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <=XXREAL-0R1  |.COMPLEX1K10 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A1: "(ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using xreal_1_th_7 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have "sqrtSQUARE-1K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1 <=XXREAL-0R1  |.COMPLEX1K10 z.|"
      using A1 square_1_th_26 sorry
    then have A2: " |.COMPLEX1K10 ReCOMPLEX1K3 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.|"
      using complex1_lm_25 sorry
    have "ReCOMPLEX1K3 z <=XXREAL-0R1  |.COMPLEX1K10 ReCOMPLEX1K3 z.|"
      using complex1_lm_26 sorry
    thus "ReCOMPLEX1K3 z <=XXREAL-0R1  |.COMPLEX1K10 z.|"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_55:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z <=XXREAL-0R1  |.COMPLEX1K10 z.|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z <=XXREAL-0R1  |.COMPLEX1K10 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A1: "(ImCOMPLEX1K4 z)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using xreal_1_th_7 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have "sqrtSQUARE-1K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1 <=XXREAL-0R1  |.COMPLEX1K10 z.|"
      using A1 square_1_th_26 sorry
    then have A2: " |.COMPLEX1K10 ImCOMPLEX1K4 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.|"
      using complex1_lm_25 sorry
    have "ImCOMPLEX1K4 z <=XXREAL-0R1  |.COMPLEX1K10 ImCOMPLEX1K4 z.|"
      using complex1_lm_26 sorry
    thus "ImCOMPLEX1K4 z <=XXREAL-0R1  |.COMPLEX1K10 z.|"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_56:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 +XCMPLX-0K2 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1.| +XCMPLX-0K2  |.COMPLEX1K10 z2.|"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 +XCMPLX-0K2 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1.| +XCMPLX-0K2  |.COMPLEX1K10 z2.|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?r1 = "ReCOMPLEX1K3 z1"
    let ?r2 = "ReCOMPLEX1K3 z2"
    let ?i1 = "ImCOMPLEX1K4 z1"
    let ?i2 = "ImCOMPLEX1K4 z2"
    have A1: "(ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 =HIDDENR1 (?i1 +REAL-1K3 ?i2)^2SQUARE-1K1"
      using complex1_th_8 sorry
    also have "... = (?i1 ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?i1)*XCMPLX-0K3 ?i2)+XCMPLX-0K2 ?i2 ^2SQUARE-1K1"
       sorry
    finally have "(ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 =HIDDENR1 (?i1 ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?i1)*XCMPLX-0K3 ?i2)+XCMPLX-0K2 ?i2 ^2SQUARE-1K1"
       sorry
    have A2: "0NUMBERSK6 <=XXREAL-0R1 ?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1"
      using complex1_lm_1 sorry
    have "(?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)*XCMPLX-0K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1) -XCMPLX-0K6 (?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2)^2SQUARE-1K1 =COMPLEX1R1 (?r1 *REAL-1K4 ?i2 -REAL-1K5 ?i1 *REAL-1K4 ?r2)^2SQUARE-1K1"
       sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)*XCMPLX-0K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1) -XCMPLX-0K6 (?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A3: "(?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)*XCMPLX-0K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1)"
      using xreal_1_th_19 sorry
    have "?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2 <=XXREAL-0R1  |.COMPLEX1K10 ?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2 .|"
      using complex1_lm_26 sorry
    then have A4: "?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2 <=XXREAL-0R1 sqrtSQUARE-1K3 (?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2)^2SQUARE-1K1"
      using complex1_lm_25 sorry
    have A5: "0NUMBERSK6 <=XXREAL-0R1 ?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1"
      using complex1_lm_1 sorry
    then have A6: "(sqrtSQUARE-1K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 ?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1"
      using square_1_def_2 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 (?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have "sqrtSQUARE-1K3 (?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2)^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 ((?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)*XCMPLX-0K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1))"
      using A3 square_1_th_26 sorry
    then have "sqrtSQUARE-1K3 (?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2)^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1)"
      using A2 A5 square_1_th_29 sorry
    then have A7: "?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2 <=XXREAL-0R1 sqrtSQUARE-1K3 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1)"
      using A4 xxreal_0_th_2 sorry
    have "(\<two>\<^sub>M *XCMPLX-0K3 ?r1)*XCMPLX-0K3 ?r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?i1)*XCMPLX-0K3 ?i2 =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (?r1 *REAL-1K4 ?r2 +REAL-1K3 ?i1 *REAL-1K4 ?i2)"
       sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 ?r1)*XCMPLX-0K3 ?r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?i1)*XCMPLX-0K3 ?i2 <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1))"
      using A7 xreal_1_th_64 sorry
    then have A8: "(?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?r1)*XCMPLX-0K3 ?r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?i1)*XCMPLX-0K3 ?i2) <=XXREAL-0R1 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1))*XCMPLX-0K3 sqrtSQUARE-1K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1)"
      using xreal_1_th_7 sorry
    have "(ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 =HIDDENR1 (?r1 +REAL-1K3 ?r2)^2SQUARE-1K1"
      using complex1_th_8 sorry
    also have "... = (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?r1)*XCMPLX-0K3 ?r2)+XCMPLX-0K2 ?r2 ^2SQUARE-1K1"
       sorry
    finally have "(ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 =HIDDENR1 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?r1)*XCMPLX-0K3 ?r2)+XCMPLX-0K2 ?r2 ^2SQUARE-1K1"
       sorry
    then have "(ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 =COMPLEX1R1 ((?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?r1)*XCMPLX-0K3 ?r2 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ?i1)*XCMPLX-0K3 ?i2))+XCMPLX-0K2 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1)"
      using A1 sorry
    then have A9: "(ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 <=XXREAL-0R1 ((?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1))*XCMPLX-0K3 sqrtSQUARE-1K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1))+XCMPLX-0K2 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1)"
      using A8 xreal_1_th_7 sorry
    have A10: "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1"
      using complex1_lm_1 sorry
    have "(sqrtSQUARE-1K3 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 ?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1"
      using A2 square_1_def_2 sorry
    then have "sqrtSQUARE-1K3 ((ReCOMPLEX1K3 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2))^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (sqrtSQUARE-1K3 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1))^2SQUARE-1K1"
      using A6 A9 A10 square_1_th_26 sorry
    thus " |.COMPLEX1K10 z1 +XCMPLX-0K2 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1.| +XCMPLX-0K2  |.COMPLEX1K10 z2.|"
      using square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_57:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1.| +XCMPLX-0K2  |.COMPLEX1K10 z2.|"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1.| +XCMPLX-0K2  |.COMPLEX1K10 z2.|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1  |.COMPLEX1K10 z1 +XCMPLX-0K2 (-XCMPLX-0K4 z2) .|"
       sorry
    then have " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1.| +XCMPLX-0K2  |.COMPLEX1K10 -XCMPLX-0K4 z2 .|"
      using complex1_th_56 sorry
    thus " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1.| +XCMPLX-0K2  |.COMPLEX1K10 z2.|"
      using complex1_lm_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_58:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| <=XXREAL-0R1  |.COMPLEX1K10 z1 +XCMPLX-0K2 z2 .|"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| <=XXREAL-0R1  |.COMPLEX1K10 z1 +XCMPLX-0K2 z2 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "z1 =COMPLEX1R1 (z1 +XCMPLX-0K2 z2)-XCMPLX-0K6 z2"
       sorry
    then have " |.COMPLEX1K10 z1.| <=XXREAL-0R1  |.COMPLEX1K10 z1 +XCMPLX-0K2 z2 .| +XCMPLX-0K2  |.COMPLEX1K10 z2.|"
      using complex1_th_57 sorry
    thus " |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| <=XXREAL-0R1  |.COMPLEX1K10 z1 +XCMPLX-0K2 z2 .|"
      using xreal_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_59:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "z1 =COMPLEX1R1 (z1 -XCMPLX-0K6 z2)+XCMPLX-0K2 z2"
       sorry
    then have " |.COMPLEX1K10 z1.| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| +XCMPLX-0K2  |.COMPLEX1K10 z2.|"
      using complex1_th_56 sorry
    thus " |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
      using xreal_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_60:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1  |.COMPLEX1K10 z2 -XCMPLX-0K6 z1 .|"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =HIDDENR1  |.COMPLEX1K10 z2 -XCMPLX-0K6 z1 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 (z2 -XCMPLX-0K6 z1) .|"
       sorry
    also have "... =  |.COMPLEX1K10 z2 -XCMPLX-0K6 z1 .|"
      using complex1_lm_23 sorry
    finally show " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =HIDDENR1  |.COMPLEX1K10 z2 -XCMPLX-0K6 z1 .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_61:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1 0NUMBERSK6 iff z1 =COMPLEX1R1 z2"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1 0NUMBERSK6 implies z1 =COMPLEX1R1 z2) &  not (z1 =COMPLEX1R1 z2 &  not  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    show " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1 0NUMBERSK6 implies z1 =COMPLEX1R1 z2"
    proof(rule impI)
      assume " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1 0NUMBERSK6"
      then have "z1 -XCMPLX-0K6 z2 =COMPLEX1R1 0NUMBERSK6"
         sorry
      thus "z1 =COMPLEX1R1 z2"
         sorry
    qed
    show " not (z1 =COMPLEX1R1 z2 &  not  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_62:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 z2 iff 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds (z1 <>HIDDENR2 z2 implies 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|) &  not ( not 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| & z1 <>HIDDENR2 z2)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    show "z1 <>HIDDENR2 z2 implies 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
    proof-
      have "z1 <>HIDDENR2 z2 implies  not 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
      proof(rule impI)
        assume "z1 <>HIDDENR2 z2"
        then have " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <>HIDDENR2 0NUMBERSK6"
          using complex1_th_61 sorry
        thus " not 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " not ( not 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| & z1 <>HIDDENR2 z2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_63:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z .| +XCMPLX-0K2  |.COMPLEX1K10 z -XCMPLX-0K6 z2 .|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z .| +XCMPLX-0K2  |.COMPLEX1K10 z -XCMPLX-0K6 z2 .|"
  proof(rule ballI,rule ballI,rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| =COMPLEX1R1  |.COMPLEX1K10 (z1 -XCMPLX-0K6 z)+XCMPLX-0K2 (z -XCMPLX-0K6 z2) .|"
       sorry
    thus " |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z .| +XCMPLX-0K2  |.COMPLEX1K10 z -XCMPLX-0K6 z2 .|"
      using complex1_th_56 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex1_lm_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b iff  |.COMPLEX1K10 a.| <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  not ((-XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b) &  not  |.COMPLEX1K10 a.| <=XXREAL-0R1 b) &  not ( |.COMPLEX1K10 a.| <=XXREAL-0R1 b &  not (-XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b))"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have A1: " |.COMPLEX1K10 a.| <=XXREAL-0R1 b implies -XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b"
    proof(rule impI)
      assume A2: " |.COMPLEX1K10 a.| <=XXREAL-0R1 b"
      have "a <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6 implies -XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b"
      proof(rule impI)
        assume A3: "a <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
        then have "-XCMPLX-0K4 a <=XXREAL-0R1 b"
          using A2 complex1_lm_24 sorry
        then have "-XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 a)"
          using xreal_1_th_24 sorry
        thus "-XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b"
          using A3 sorry
      qed
      thus "-XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b"
        using A2 complex1_th_43 sorry
    qed
    have "-XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b implies  |.COMPLEX1K10 a.| <=XXREAL-0R1 b"
    proof(rule impMI ,rule impI)
      assume A4: "-XCMPLX-0K4 b <=XXREAL-0R1 a"
        and A5: "a <=XXREAL-0R1 b"
      have "-XCMPLX-0K4 a <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 b)"
        using A4 xreal_1_th_24 sorry
      then have "a <XXREAL-0R3 0NUMBERSK6 implies  |.COMPLEX1K10 a.| <=XXREAL-0R1 b"
        using complex1_lm_24 sorry
      thus " |.COMPLEX1K10 a.| <=XXREAL-0R1 b"
        using A5 complex1_th_43 sorry
    qed
    thus " not ((-XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b) &  not  |.COMPLEX1K10 a.| <=XXREAL-0R1 b) &  not ( |.COMPLEX1K10 a.| <=XXREAL-0R1 b &  not (-XCMPLX-0K4 b <=XXREAL-0R1 a & a <=XXREAL-0R1 b))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_64:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10  |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| .| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10  |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| .| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 z2.| -XCMPLX-0K6  |.COMPLEX1K10 z1.| <=XXREAL-0R1  |.COMPLEX1K10 z2 -XCMPLX-0K6 z1 .|"
      using complex1_th_59 sorry
    then have "-XCMPLX-0K4 ( |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.|) <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
      using complex1_th_60 sorry
    then have A1: "-XCMPLX-0K4  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .| <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 ( |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.|))"
      using xreal_1_th_24 sorry
    have " |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
      using complex1_th_59 sorry
    thus " |.COMPLEX1K10  |.COMPLEX1K10 z1.| -XCMPLX-0K6  |.COMPLEX1K10 z2.| .| <=XXREAL-0R1  |.COMPLEX1K10 z1 -XCMPLX-0K6 z2 .|"
      using A1 complex1_lm_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_65:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 *XCMPLX-0K3 z2 .| =COMPLEX1R1 ( |.COMPLEX1K10 z1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z2.|)"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z1 *XCMPLX-0K3 z2 .| =COMPLEX1R1 ( |.COMPLEX1K10 z1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z2.|)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    let ?r1 = "ReCOMPLEX1K3 z1"
    let ?r2 = "ReCOMPLEX1K3 z2"
    let ?i1 = "ImCOMPLEX1K4 z1"
    let ?i2 = "ImCOMPLEX1K4 z2"
    have A1: "0NUMBERSK6 <=XXREAL-0R1 ?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1 & 0NUMBERSK6 <=XXREAL-0R1 ?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1"
      using complex1_lm_1 sorry
    have A2: "(ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2))^2SQUARE-1K1 =HIDDENR1 (?r1 *REAL-1K4 ?i2 +REAL-1K3 ?r2 *REAL-1K4 ?i1)^2SQUARE-1K1"
      using complex1_th_9 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (?r1 *REAL-1K4 ?r2))*XCMPLX-0K3 (?i1 *REAL-1K4 ?i2) +XCMPLX-0K2 ((?r1 *REAL-1K4 ?i2)^2SQUARE-1K1 +XCMPLX-0K2 (?r2 *REAL-1K4 ?i1)^2SQUARE-1K1)"
       sorry
    finally have "(ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2))^2SQUARE-1K1 =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (?r1 *REAL-1K4 ?r2))*XCMPLX-0K3 (?i1 *REAL-1K4 ?i2) +XCMPLX-0K2 ((?r1 *REAL-1K4 ?i2)^2SQUARE-1K1 +XCMPLX-0K2 (?r2 *REAL-1K4 ?i1)^2SQUARE-1K1)"
       sorry
    have "(ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2))^2SQUARE-1K1 =HIDDENR1 (?r1 *REAL-1K4 ?r2 -REAL-1K5 ?i1 *REAL-1K4 ?i2)^2SQUARE-1K1"
      using complex1_th_9 sorry
    also have "... = ((?r1 *REAL-1K4 ?r2)^2SQUARE-1K1 +XCMPLX-0K2 (?i1 *REAL-1K4 ?i2)^2SQUARE-1K1)+XCMPLX-0K2 (-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (?r1 *REAL-1K4 ?r2))*XCMPLX-0K3 (?i1 *REAL-1K4 ?i2))"
       sorry
    finally have "(ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2))^2SQUARE-1K1 =HIDDENR1 ((?r1 *REAL-1K4 ?r2)^2SQUARE-1K1 +XCMPLX-0K2 (?i1 *REAL-1K4 ?i2)^2SQUARE-1K1)+XCMPLX-0K2 (-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (?r1 *REAL-1K4 ?r2))*XCMPLX-0K3 (?i1 *REAL-1K4 ?i2))"
       sorry
    then have "(ReCOMPLEX1K3 (z1 *XCMPLX-0K3 z2))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z1 *XCMPLX-0K3 z2))^2SQUARE-1K1 =COMPLEX1R1 (?r1 ^2SQUARE-1K1 +XCMPLX-0K2 ?i1 ^2SQUARE-1K1)*XCMPLX-0K3 (?r2 ^2SQUARE-1K1 +XCMPLX-0K2 ?i2 ^2SQUARE-1K1)"
      using A2 sorry
    thus " |.COMPLEX1K10 z1 *XCMPLX-0K3 z2 .| =COMPLEX1R1 ( |.COMPLEX1K10 z1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z2.|)"
      using A1 square_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_66:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =HIDDENR1 ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show " |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =HIDDENR1 ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
    proof-
      have cases: "z <>HIDDENR2 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "z <>HIDDENR2 0NUMBERSK6 implies  |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =HIDDENR1 ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
      proof(rule impI)
        assume A1: "z <>HIDDENR2 0NUMBERSK6"
        let ?r2i2 = "(ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
        have A2: "?r2i2 <>HIDDENR2 0NUMBERSK6"
          using A1 complex1_th_5 sorry
        have A3: "0NUMBERSK6 <=XXREAL-0R1 ?r2i2"
          using complex1_lm_1 sorry
        have " |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =HIDDENR1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (z \<inverse>XCMPLX-0K5))^2SQUARE-1K1)"
          using complex1_th_20 sorry
        also have "... = sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))^2SQUARE-1K1 +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))^2SQUARE-1K1)"
          using complex1_th_20 sorry
        also have "... = sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)^2SQUARE-1K1 +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))^2SQUARE-1K1)"
          using xcmplx_1_th_76 sorry
        also have "... = sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)^2SQUARE-1K1 +XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)^2SQUARE-1K1 /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)^2SQUARE-1K1)"
          using xcmplx_1_th_76 sorry
        also have "... = sqrtSQUARE-1K3 ((\<one>\<^sub>M *XCMPLX-0K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))/XCMPLX-0K7 (((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)*XCMPLX-0K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)))"
          using xcmplx_1_th_62 sorry
        also have "... = sqrtSQUARE-1K3 (\<one>\<^sub>M /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))"
          using A2 xcmplx_1_th_91 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
          using A3 square_1_th_18 square_1_th_30 sorry
        also have "... = ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
          using xcmplx_1_th_215 sorry
        finally show " |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =HIDDENR1 ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
           sorry
      qed
      have case2: "z =COMPLEX1R1 0NUMBERSK6 implies  |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =HIDDENR1 ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
      proof(rule impI)
        assume A4: "z =COMPLEX1R1 0NUMBERSK6"
        then have " |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =HIDDENR1 (0NUMBERSK6)\<inverse>XCMPLX-0K5"
           sorry
        also have "... = ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
          using A4 sorry
        finally show " |.COMPLEX1K10 z \<inverse>XCMPLX-0K5.| =HIDDENR1 ( |.COMPLEX1K10 z.|)\<inverse>XCMPLX-0K5"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_67:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z1.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z2.|) =COMPLEX1R1  |.COMPLEX1K10 z1 /XCMPLX-0K7 z2 .|"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z1.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z2.|) =HIDDENR1  |.COMPLEX1K10 z1 /XCMPLX-0K7 z2 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    have "( |.COMPLEX1K10 z1.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z2.|) =HIDDENR1 ( |.COMPLEX1K10 z1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z2.|)\<inverse>XCMPLX-0K5"
      using xcmplx_0_def_9 sorry
    also have "... = ( |.COMPLEX1K10 z1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z2 \<inverse>XCMPLX-0K5.|)"
      using complex1_th_66 sorry
    also have "... =  |.COMPLEX1K10 z1 *XCMPLX-0K3 z2 \<inverse>XCMPLX-0K5 .|"
      using complex1_th_65 sorry
    also have "... =  |.COMPLEX1K10 z1 /XCMPLX-0K7 z2 .|"
      using xcmplx_0_def_9 sorry
    finally show "( |.COMPLEX1K10 z1.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z2.|) =HIDDENR1  |.COMPLEX1K10 z1 /XCMPLX-0K7 z2 .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_68:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z *XCMPLX-0K3 z .| =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z *XCMPLX-0K3 z .| =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1 &  |.COMPLEX1K10 z *XCMPLX-0K3 z .| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z.|)"
      using complex1_lm_1 complex1_th_65 sorry
    then have " |.COMPLEX1K10 z *XCMPLX-0K3 z .| =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)^2SQUARE-1K1"
      using square_1_th_29 sorry
    thus " |.COMPLEX1K10 z *XCMPLX-0K3 z .| =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using complex1_lm_1 square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_69:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z *XCMPLX-0K3 z .| =COMPLEX1R1  |.COMPLEX1K10 z *XCMPLX-0K3 z *'COMPLEX1K9 .|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z *XCMPLX-0K3 z .| =HIDDENR1  |.COMPLEX1K10 z *XCMPLX-0K3 z *'COMPLEX1K9 .|"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 z *XCMPLX-0K3 z .| =HIDDENR1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z.|)"
      using complex1_th_65 sorry
    also have "... = ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z *'COMPLEX1K9.|)"
      using complex1_th_53 sorry
    also have "... =  |.COMPLEX1K10 z *XCMPLX-0K3 z *'COMPLEX1K9 .|"
      using complex1_th_65 sorry
    finally show " |.COMPLEX1K10 z *XCMPLX-0K3 z .| =HIDDENR1  |.COMPLEX1K10 z *XCMPLX-0K3 z *'COMPLEX1K9 .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_70:
" for a be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies  |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
  using complex1_lm_24 sorry

mtheorem complex1_th_71:
" for a be RealXREAL-0M1 holds  |.COMPLEX1K10 a.| =COMPLEX1R1 a or  |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
proof-
  have " for a be RealXREAL-0M1 holds  not ( not  |.COMPLEX1K10 a.| =COMPLEX1R1 a &  not  |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a)"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
       sorry
    thus " not ( not  |.COMPLEX1K10 a.| =COMPLEX1R1 a &  not  |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a)"
      using complex1_lm_24 complex1_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_72:
" for a be RealXREAL-0M1 holds sqrtSQUARE-1K3 a ^2SQUARE-1K1 =COMPLEX1R1  |.COMPLEX1K10 a.|"
  using complex1_lm_25 sorry

mtheorem complex1_th_73:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds minXXREAL-0K4(a,b) =COMPLEX1R1 ((a +XCMPLX-0K2 b)-XCMPLX-0K6  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds minXXREAL-0K4(a,b) =COMPLEX1R1 ((a +XCMPLX-0K2 b)-XCMPLX-0K6  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    show "minXXREAL-0K4(a,b) =COMPLEX1R1 ((a +XCMPLX-0K2 b)-XCMPLX-0K6  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
    proof-
      have cases: "a <=XXREAL-0R1 b or b <=XXREAL-0R1 a"
         sorry
      have case1: "a <=XXREAL-0R1 b implies minXXREAL-0K4(a,b) =COMPLEX1R1 ((a +XCMPLX-0K2 b)-XCMPLX-0K6  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
      proof(rule impI)
        assume A1: "a <=XXREAL-0R1 b"
        have " |.COMPLEX1K10 a -XCMPLX-0K6 b .| =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 (b -XCMPLX-0K6 a) .|"
           sorry
        also have "... =  |.COMPLEX1K10 b -XCMPLX-0K6 a .|"
          using complex1_lm_23 sorry
        also have "... = b -XCMPLX-0K6 a"
          using A1 complex1_th_43 xreal_1_th_48 sorry
        finally have " |.COMPLEX1K10 a -XCMPLX-0K6 b .| =HIDDENR1 b -XCMPLX-0K6 a"
           sorry
        thus "minXXREAL-0K4(a,b) =COMPLEX1R1 ((a +XCMPLX-0K2 b)-XCMPLX-0K6  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using A1 xxreal_0_def_9 sorry
      qed
      have case2: "b <=XXREAL-0R1 a implies minXXREAL-0K4(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)-XCMPLX-0K6  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
      proof(rule impI)
        assume A2: "b <=XXREAL-0R1 a"
        then have "minXXREAL-0K4(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 (a -XCMPLX-0K6 b))/XCMPLX-0K7 \<two>\<^sub>M"
          using xxreal_0_def_9 sorry
        also have "... = ((a +XCMPLX-0K2 b)-XCMPLX-0K6  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using A2 complex1_th_43 xreal_1_th_48 sorry
        finally show "minXXREAL-0K4(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)-XCMPLX-0K6  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_74:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds maxXXREAL-0K5(a,b) =COMPLEX1R1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds maxXXREAL-0K5(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    show "maxXXREAL-0K5(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
    proof-
      have cases: "b <=XXREAL-0R1 a or a <=XXREAL-0R1 b"
         sorry
      have case1: "b <=XXREAL-0R1 a implies maxXXREAL-0K5(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
      proof(rule impI)
        assume A1: "b <=XXREAL-0R1 a"
        then have "maxXXREAL-0K5(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 (a -XCMPLX-0K6 b))/XCMPLX-0K7 \<two>\<^sub>M"
          using xxreal_0_def_10 sorry
        also have "... = ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using A1 complex1_th_43 xreal_1_th_48 sorry
        finally show "maxXXREAL-0K5(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
           sorry
      qed
      have case2: "a <=XXREAL-0R1 b implies maxXXREAL-0K5(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
      proof(rule impI)
        assume A2: "a <=XXREAL-0R1 b"
        then have A3: "0NUMBERSK6 <=XXREAL-0R1 b -XCMPLX-0K6 a"
          using xreal_1_th_48 sorry
        have "maxXXREAL-0K5(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 (-XCMPLX-0K4 (a -XCMPLX-0K6 b)))/XCMPLX-0K7 \<two>\<^sub>M"
          using A2 xxreal_0_def_10 sorry
        also have "... = ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 -XCMPLX-0K4 (a -XCMPLX-0K6 b) .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using A3 complex1_th_43 sorry
        also have "... = ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using complex1_lm_23 sorry
        finally show "maxXXREAL-0K5(a,b) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2  |.COMPLEX1K10 a -XCMPLX-0K6 b .|)/XCMPLX-0K7 \<two>\<^sub>M"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_75:
" for a be RealXREAL-0M1 holds ( |.COMPLEX1K10 a.|)^2SQUARE-1K1 =COMPLEX1R1 a ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds ( |.COMPLEX1K10 a.|)^2SQUARE-1K1 =COMPLEX1R1 a ^2SQUARE-1K1"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have " |.COMPLEX1K10 a.| =COMPLEX1R1 a or  |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
      using complex1_th_71 sorry
    thus "( |.COMPLEX1K10 a.|)^2SQUARE-1K1 =COMPLEX1R1 a ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_76:
" for a be RealXREAL-0M1 holds -XCMPLX-0K4  |.COMPLEX1K10 a.| <=XXREAL-0R1 a & a <=XXREAL-0R1  |.COMPLEX1K10 a.|"
  using complex1_lm_26 sorry

mtheorem complex1_th_77:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 c +XCMPLX-0K2 d *XCMPLX-0K3 (<i>COMPLEX1K8) implies a =COMPLEX1R1 c & b =COMPLEX1R1 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 c +XCMPLX-0K2 d *XCMPLX-0K3 (<i>COMPLEX1K8) implies a =COMPLEX1R1 c & b =COMPLEX1R1 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "a +XCMPLX-0K2 b *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 c +XCMPLX-0K2 d *XCMPLX-0K3 (<i>COMPLEX1K8)"
    then have "(a -XCMPLX-0K6 c)+XCMPLX-0K2 (b -XCMPLX-0K6 d)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have "a -XCMPLX-0K6 c =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_4 complex1_th_12 sorry
    thus "a =COMPLEX1R1 c & b =COMPLEX1R1 d"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_78:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1  |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1  |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have A1: "(sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have "a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A2: "(sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1"
      using square_1_def_2 sorry
    have "( |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|)^2SQUARE-1K1 =COMPLEX1R1 (( |.COMPLEX1K10 a.|)^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 a.|))*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))+XCMPLX-0K2 ( |.COMPLEX1K10 b.|)^2SQUARE-1K1 & ( |.COMPLEX1K10 a.|)^2SQUARE-1K1 =COMPLEX1R1 a ^2SQUARE-1K1"
      using complex1_th_75 sorry
    then have "( |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1 =HIDDENR1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 a.|))*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))+XCMPLX-0K2 b ^2SQUARE-1K1)-XCMPLX-0K6 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)"
      using A2 complex1_th_75 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 a.|))*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
       sorry
    finally have "( |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1 =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 a.|))*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
       sorry
    then have "( |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|)^2SQUARE-1K1 >=XXREAL-0R2 (sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1"
      using xreal_1_th_49 sorry
    then have "sqrtSQUARE-1K3 ( |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|)^2SQUARE-1K1 >=XXREAL-0R2 sqrtSQUARE-1K3 (sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1"
      using A1 square_1_th_26 sorry
    thus "sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1  |.COMPLEX1K10 a.| +XCMPLX-0K2  |.COMPLEX1K10 b.|"
      using A2 square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_79:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  |.COMPLEX1K10 a.| <=XXREAL-0R1 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  |.COMPLEX1K10 a.| <=XXREAL-0R1 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & a ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1"
      using xreal_1_th_6 xreal_1_th_63 sorry
    then have "sqrtSQUARE-1K3 a ^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)"
      using square_1_th_26 sorry
    thus " |.COMPLEX1K10 a.| <=XXREAL-0R1 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)"
      using complex1_lm_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex1_th_80:
" for z1 be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 z1 .| =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 z1.|)"
  using complex1_th_48 complex1_th_67 sorry

mtheorem complex1_th_81:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 +XCMPLX-0K2 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI,rule ballI)
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
  have "z1 +XCMPLX-0K2 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2,ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2 *]"
    using complex1_lm_12 sorry
  thus "z1 +XCMPLX-0K2 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 +REAL-1K3 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using complex1_lm_18 sorry
qed "sorry"

mtheorem complex1_th_82:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 *XCMPLX-0K3 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)+XCMPLX-0K2 (ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI,rule ballI)
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
  have "z1 *XCMPLX-0K3 z2 =COMPLEX1R1 [*ARYTM-0K5 ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2,ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 *]"
    using complex1_lm_13 sorry
  thus "z1 *XCMPLX-0K3 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 -REAL-1K5 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)+XCMPLX-0K2 (ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2 +REAL-1K3 ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using complex1_lm_18 sorry
qed "sorry"

mtheorem complex1_th_83:
" for z be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 z =COMPLEX1R1 (-REAL-1K1 ReCOMPLEX1K3 z)+XCMPLX-0K2 (-REAL-1K1 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  using complex1_lm_19 sorry

mtheorem complex1_th_84:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 -XCMPLX-0K6 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 -REAL-1K5 ReCOMPLEX1K3 z2)+XCMPLX-0K2 (ImCOMPLEX1K4 z1 -REAL-1K5 ImCOMPLEX1K4 z2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  using complex1_lm_20 sorry

mtheorem complex1_th_85:
" for z be ComplexXCMPLX-0M1 holds z \<inverse>XCMPLX-0K5 =COMPLEX1R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) +XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z)/XCMPLX-0K7 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  using complex1_lm_21 sorry

mtheorem complex1_th_86:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 /XCMPLX-0K7 z2 =COMPLEX1R1 (ReCOMPLEX1K3 z1 *REAL-1K4 ReCOMPLEX1K3 z2 +REAL-1K3 ImCOMPLEX1K4 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1) +XCMPLX-0K2 ((ReCOMPLEX1K3 z2 *REAL-1K4 ImCOMPLEX1K4 z1 -REAL-1K5 ReCOMPLEX1K3 z1 *REAL-1K4 ImCOMPLEX1K4 z2)/XCMPLX-0K7 ((ReCOMPLEX1K3 z2)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z2)^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  using complex1_lm_22 sorry

end
