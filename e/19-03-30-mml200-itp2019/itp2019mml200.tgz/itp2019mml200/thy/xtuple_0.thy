theory xtuple_0
  imports enumset1
begin
(*begin*)
reserve x, x1, x2, x3, x4, y, y1, y2, y3, y4, z, z1, z2, z2, z4 for "objectHIDDENM1"
mdef xtuple_0_def_1 ("pairXTUPLE-0V1" 70 ) where
"attr pairXTUPLE-0V1 for objectHIDDENM1 means
  (\<lambda>x.  ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 x1,x2 ])"..

mtheorem xtuple_0_cl_1:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1"
"cluster [TARSKIK4 x1,x2 ] as-term-is pairXTUPLE-0V1"
proof
(*coherence*)
  show "[TARSKIK4 x1,x2 ] be pairXTUPLE-0V1"
     sorry
qed "sorry"

mlemma xtuple_0_lm_1:
" for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies x =HIDDENR1 y1"
proof-
  have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies x =HIDDENR1 y1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    assume "{TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 }"
    then have "y1 inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_2 sorry
    thus "x =HIDDENR1 y1"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xtuple_0_lm_2:
" for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies y1 =HIDDENR1 y2"
proof-
  have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies y1 =HIDDENR1 y2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    assume A1: "{TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y1,y2 }"
    then have "x =HIDDENR1 y1"
      using xtuple_0_lm_1 sorry
    thus "y1 =HIDDENR1 y2"
      using A1 xtuple_0_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xtuple_0_lm_3:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 y1,y2 } implies x1 =HIDDENR1 y1 or x1 =HIDDENR1 y2"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not (({TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 y1,y2 } &  not x1 =HIDDENR1 y1) &  not x1 =HIDDENR1 y2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    have "x1 inHIDDENR3 {TARSKIK2 x1,x2 }"
      using tarski_def_2 sorry
    thus " not (({TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 y1,y2 } &  not x1 =HIDDENR1 y1) &  not x1 =HIDDENR1 y2)"
      using tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_1:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] =HIDDENR1 [TARSKIK4 y1,y2 ] implies x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] =HIDDENR1 [TARSKIK4 y1,y2 ] implies x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    assume A1: "[TARSKIK4 x1,x2 ] =HIDDENR1 [TARSKIK4 y1,y2 ]"
    show "x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2"
    proof-
      have cases: "y1 <>HIDDENR2 y2 or y1 =HIDDENR1 y2"
         sorry
      have case1: "y1 <>HIDDENR2 y2 implies x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2"
      proof(rule impI,rule conjMI)
        assume A2: "y1 <>HIDDENR2 y2"
        then have A3: "{TARSKIK1 x1} <>HIDDENR2 {TARSKIK2 y1,y2 }"
          using xtuple_0_lm_2 sorry
        then have "{TARSKIK1 x1} =XBOOLE-0R4 {TARSKIK1 y1}"
          using A1 xtuple_0_lm_3 sorry
        then have "x1 inHIDDENR3 {TARSKIK1 y1}"
          using tarski_def_1 sorry
        thus A4: "x1 =HIDDENR1 y1"
          using tarski_def_1 sorry
        have "{TARSKIK2 y1,y2 } =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
          using A1 A3 xtuple_0_lm_3 sorry
        thus "x2 =HIDDENR1 y2"
          using A2 A4 xtuple_0_lm_3 sorry
      qed
      have case2: "y1 =HIDDENR1 y2 implies x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2"
      proof(rule impI)
        assume A5: "y1 =HIDDENR1 y2"
        then have "{TARSKIK2 {TARSKIK2 x1,x2 },{TARSKIK1 x1} } =HIDDENR1 {TARSKIK2 {TARSKIK1 y1},{TARSKIK1 y1} }"
          using A1 enumset1_th_29 sorry
        also have "... = {TARSKIK1 {TARSKIK1 y1} }"
          using enumset1_th_29 sorry
        finally have "{TARSKIK2 {TARSKIK2 x1,x2 },{TARSKIK1 x1} } =HIDDENR1 {TARSKIK1 {TARSKIK1 y1} }"
           sorry
        then have "{TARSKIK1 y1} =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
          using xtuple_0_lm_1 sorry
        thus "x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2"
          using A5 xtuple_0_lm_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef xtuple_0_def_2 (" _ `1XTUPLE-0K1" [355]355 ) where
  mlet "x be objectHIDDENM1"
"assume x be pairXTUPLE-0V1 func x `1XTUPLE-0K1 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it =HIDDENR1 y1"
proof-
  (*existence*)
    show "x be pairXTUPLE-0V1 implies ( ex it be objectHIDDENM1 st  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it =HIDDENR1 y1)"
    proof(rule impI)
      assume Assume: "x be pairXTUPLE-0V1"
      have "x be pairXTUPLE-0V1"
        using Assume sorry
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A1: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
         sorry
      show " ex it be objectHIDDENM1 st  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it =HIDDENR1 y1"
      proof-
        have " ex tVar1 be objectHIDDENM1 st  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not (x =HIDDENR1 [TARSKIK4 y1,y2 ] &  not tVar1 =HIDDENR1 y1)"
        proof-
          show " ex tVar1 be objectHIDDENM1 st  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not (x =HIDDENR1 [TARSKIK4 y1,y2 ] &  not tVar1 =HIDDENR1 y1)"
          proof(rule bexI[of _ "x1"])
            show " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not (x =HIDDENR1 [TARSKIK4 y1,y2 ] &  not x1 =HIDDENR1 y1)"
              using A1 xtuple_0_th_1 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "x be pairXTUPLE-0V1 implies ( for it1 be objectHIDDENM1 holds  for it2 be objectHIDDENM1 holds ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it1 =HIDDENR1 y1) & ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it2 =HIDDENR1 y1) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "x be pairXTUPLE-0V1"
      have "x be pairXTUPLE-0V1"
        using Assume sorry
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A1: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
         sorry
      show " for it1 be objectHIDDENM1 holds  for it2 be objectHIDDENM1 holds ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it1 =HIDDENR1 y1) & ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it2 =HIDDENR1 y1) implies it1 =HIDDENR1 it2"
      proof-
        have " for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies z1 =HIDDENR1 y1) & ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies z2 =HIDDENR1 y1) implies z1 =HIDDENR1 z2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix z1 assume [ty]: "z1 be objectHIDDENM1"
          fix z2 assume [ty]: "z2 be objectHIDDENM1"
          assume A2: " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies z1 =HIDDENR1 y1"
            and A3: " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies z2 =HIDDENR1 y1"
          have "z1 =HIDDENR1 x1"
            using A1 A2 sorry
          also have "... = z2"
            using A1 A3 sorry
          finally show "z1 =HIDDENR1 z2"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef xtuple_0_def_3 (" _ `2XTUPLE-0K2" [355]355 ) where
  mlet "x be objectHIDDENM1"
"assume x be pairXTUPLE-0V1 func x `2XTUPLE-0K2 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it =HIDDENR1 y2"
proof-
  (*existence*)
    show "x be pairXTUPLE-0V1 implies ( ex it be objectHIDDENM1 st  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it =HIDDENR1 y2)"
    proof(rule impI)
      assume Assume: "x be pairXTUPLE-0V1"
      have "x be pairXTUPLE-0V1"
        using Assume sorry
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A1: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
         sorry
      show " ex it be objectHIDDENM1 st  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it =HIDDENR1 y2"
      proof-
        have " ex tVar2 be objectHIDDENM1 st  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not (x =HIDDENR1 [TARSKIK4 y1,y2 ] &  not tVar2 =HIDDENR1 y2)"
        proof-
          show " ex tVar2 be objectHIDDENM1 st  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not (x =HIDDENR1 [TARSKIK4 y1,y2 ] &  not tVar2 =HIDDENR1 y2)"
          proof(rule bexI[of _ "x2"])
            show " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  not (x =HIDDENR1 [TARSKIK4 y1,y2 ] &  not x2 =HIDDENR1 y2)"
              using A1 xtuple_0_th_1 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "x be pairXTUPLE-0V1 implies ( for it1 be objectHIDDENM1 holds  for it2 be objectHIDDENM1 holds ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it1 =HIDDENR1 y2) & ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it2 =HIDDENR1 y2) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "x be pairXTUPLE-0V1"
      have "x be pairXTUPLE-0V1"
        using Assume sorry
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A1: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
         sorry
      show " for it1 be objectHIDDENM1 holds  for it2 be objectHIDDENM1 holds ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it1 =HIDDENR1 y2) & ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies it2 =HIDDENR1 y2) implies it1 =HIDDENR1 it2"
      proof-
        have " for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies z1 =HIDDENR1 y2) & ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies z2 =HIDDENR1 y2) implies z1 =HIDDENR1 z2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix z1 assume [ty]: "z1 be objectHIDDENM1"
          fix z2 assume [ty]: "z2 be objectHIDDENM1"
          assume A4: " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies z1 =HIDDENR1 y2"
            and A5: " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 y1,y2 ] implies z2 =HIDDENR1 y2"
          have "z1 =HIDDENR1 x2"
            using A1 A4 sorry
          also have "... = z2"
            using A1 A5 sorry
          finally show "z1 =HIDDENR1 z2"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem xtuple_0_reduce_1:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1"
"reduce [TARSKIK4 x1,x2 ] `1XTUPLE-0K1 to x1"
proof
(*reducibility*)
  show "[TARSKIK4 x1,x2 ] `1XTUPLE-0K1 =HIDDENR1 x1"
    using xtuple_0_def_2 sorry
qed "sorry"

mtheorem xtuple_0_reduce_2:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1"
"reduce [TARSKIK4 x1,x2 ] `2XTUPLE-0K2 to x2"
proof
(*reducibility*)
  show "[TARSKIK4 x1,x2 ] `2XTUPLE-0K2 =HIDDENR1 x2"
    using xtuple_0_def_3 sorry
qed "sorry"

mtheorem xtuple_0_cl_2:
"cluster pairXTUPLE-0V1 for objectHIDDENM1"
proof
(*existence*)
  show " ex it be objectHIDDENM1 st it be pairXTUPLE-0V1"
  proof-
    have " ex tVar3 be objectHIDDENM1 st tVar3 be pairXTUPLE-0V1"
    proof-
      show " ex tVar3 be objectHIDDENM1 st tVar3 be pairXTUPLE-0V1"
      proof(rule bexI[of _ "[TARSKIK4 the objectHIDDENM1,the objectHIDDENM1 ]"])
        have " ex tVar5 be objectHIDDENM1 st [TARSKIK4 tVar5,tVar5 ] =HIDDENR1 [TARSKIK4 tVar5,tVar5 ]"
        proof(rule bexI[of _ "the objectHIDDENM1"])
          show "[TARSKIK4 the objectHIDDENM1,the objectHIDDENM1 ] =HIDDENR1 [TARSKIK4 the objectHIDDENM1,the objectHIDDENM1 ]"
             sorry
        qed "sorry"
        thus "[TARSKIK4 the objectHIDDENM1,the objectHIDDENM1 ] be pairXTUPLE-0V1"
          using bexI[of _ "the objectHIDDENM1"] xtuple_0_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xtuple_0_reduce_3:
  mlet "x be pairXTUPLE-0V1\<bar>objectHIDDENM1"
"reduce [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] to x"
proof
(*reducibility*)
  show "[TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] =HIDDENR1 x"
  proof-
    have " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 x1,x2 ]"
      using xtuple_0_def_1 sorry
    thus "[TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] =HIDDENR1 x"
       sorry
  qed
qed "sorry"

mtheorem xtuple_0_th_2:
" for a be pairXTUPLE-0V1\<bar>objectHIDDENM1 holds  for b be pairXTUPLE-0V1\<bar>objectHIDDENM1 holds a `1XTUPLE-0K1 =HIDDENR1 b `1XTUPLE-0K1 & a `2XTUPLE-0K2 =HIDDENR1 b `2XTUPLE-0K2 implies a =HIDDENR1 b"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be pairXTUPLE-0V1\<bar>objectHIDDENM1"
  fix b assume [ty]: "b be pairXTUPLE-0V1\<bar>objectHIDDENM1"
  assume A1: "a `1XTUPLE-0K1 =HIDDENR1 b `1XTUPLE-0K1 & a `2XTUPLE-0K2 =HIDDENR1 b `2XTUPLE-0K2"
  have "a =HIDDENR1 [TARSKIK4 a `1XTUPLE-0K1,a `2XTUPLE-0K2 ] & b =HIDDENR1 [TARSKIK4 b `1XTUPLE-0K1,b `2XTUPLE-0K2 ]"
     sorry
  thus "a =HIDDENR1 b"
    using A1 sorry
qed "sorry"

(*begin*)
mdef xtuple_0_def_4 ("[XTUPLE-0K3 _ , _ , _ ]" [0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1"
"func [XTUPLE-0K3 x1,x2,x3 ] \<rightarrow> objectHIDDENM1 equals
  [TARSKIK4 [TARSKIK4 x1,x2 ],x3 ]"
proof-
  (*coherence*)
    show "[TARSKIK4 [TARSKIK4 x1,x2 ],x3 ] be objectHIDDENM1"
       sorry
qed "sorry"

mdef xtuple_0_def_5 ("tripleXTUPLE-0V2" 70 ) where
"attr tripleXTUPLE-0V2 for objectHIDDENM1 means
  (\<lambda>x.  ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])"..

mtheorem xtuple_0_cl_3:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1"
"cluster [XTUPLE-0K3 x1,x2,x3 ] as-term-is tripleXTUPLE-0V2"
proof
(*coherence*)
  show "[XTUPLE-0K3 x1,x2,x3 ] be tripleXTUPLE-0V2"
     sorry
qed "sorry"

mtheorem xtuple_0_th_3:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [XTUPLE-0K3 x1,x2,x3 ] =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies (x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [XTUPLE-0K3 x1,x2,x3 ] =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies (x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    assume A1: "[XTUPLE-0K3 x1,x2,x3 ] =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ]"
    then have "[TARSKIK4 x1,x2 ] =HIDDENR1 [TARSKIK4 y1,y2 ]"
      using xtuple_0_th_1 sorry
    thus "(x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3"
      using A1 xtuple_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_cl_4:
"cluster tripleXTUPLE-0V2 for objectHIDDENM1"
proof
(*existence*)
  show " ex it be objectHIDDENM1 st it be tripleXTUPLE-0V2"
  proof-
    have " ex tVar6 be objectHIDDENM1 st tVar6 be tripleXTUPLE-0V2"
    proof-
      show " ex tVar6 be objectHIDDENM1 st tVar6 be tripleXTUPLE-0V2"
      proof(rule bexI[of _ "[XTUPLE-0K3 the setHIDDENM2,the setHIDDENM2,the setHIDDENM2 ]"])
        have " ex tVar8 be objectHIDDENM1 st  ex tVar9 be objectHIDDENM1 st [XTUPLE-0K3 tVar9,tVar9,tVar9 ] =HIDDENR1 [XTUPLE-0K3 tVar9,tVar9,tVar9 ]"
        proof(rule bexI[of _ "the setHIDDENM2"])
          show " ex tVar9 be objectHIDDENM1 st [XTUPLE-0K3 tVar9,tVar9,tVar9 ] =HIDDENR1 [XTUPLE-0K3 tVar9,tVar9,tVar9 ]"
          proof(rule bexI[of _ "the setHIDDENM2"])
            show "[XTUPLE-0K3 the setHIDDENM2,the setHIDDENM2,the setHIDDENM2 ] =HIDDENR1 [XTUPLE-0K3 the setHIDDENM2,the setHIDDENM2,the setHIDDENM2 ]"
               sorry
          qed "sorry"
        qed "sorry"
        thus "[XTUPLE-0K3 the setHIDDENM2,the setHIDDENM2,the setHIDDENM2 ] be tripleXTUPLE-0V2"
          using bexI[of _ "the setHIDDENM2"] xtuple_0_def_5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xtuple_0_cl_5:
"cluster tripleXTUPLE-0V2 also-is pairXTUPLE-0V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be tripleXTUPLE-0V2 implies it be pairXTUPLE-0V1"
     sorry
qed "sorry"

mdef xtuple_0_def_6 (" _ `1-3XTUPLE-0K4" [164]164 ) where
  mlet "x be objectHIDDENM1"
"func x `1-3XTUPLE-0K4 \<rightarrow> objectHIDDENM1 equals
  (x `1XTUPLE-0K1)`1XTUPLE-0K1"
proof-
  (*coherence*)
    show "(x `1XTUPLE-0K1)`1XTUPLE-0K1 be objectHIDDENM1"
       sorry
qed "sorry"

mdef xtuple_0_def_7 (" _ `2-3XTUPLE-0K5" [164]164 ) where
  mlet "x be objectHIDDENM1"
"func x `2-3XTUPLE-0K5 \<rightarrow> objectHIDDENM1 equals
  (x `1XTUPLE-0K1)`2XTUPLE-0K2"
proof-
  (*coherence*)
    show "(x `1XTUPLE-0K1)`2XTUPLE-0K2 be objectHIDDENM1"
       sorry
qed "sorry"

abbreviation(input) XTUPLE_0K6(" _ `3-3XTUPLE-0K6" [164]164) where
  "x `3-3XTUPLE-0K6 \<equiv> x `2XTUPLE-0K2"

mtheorem xtuple_0_reduce_4:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1"
"reduce [XTUPLE-0K3 x1,x2,x3 ] `1-3XTUPLE-0K4 to x1"
proof
(*reducibility*)
  show "[XTUPLE-0K3 x1,x2,x3 ] `1-3XTUPLE-0K4 =HIDDENR1 x1"
     sorry
qed "sorry"

mtheorem xtuple_0_reduce_5:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1"
"reduce [XTUPLE-0K3 x1,x2,x3 ] `2-3XTUPLE-0K5 to x2"
proof
(*reducibility*)
  show "[XTUPLE-0K3 x1,x2,x3 ] `2-3XTUPLE-0K5 =HIDDENR1 x2"
     sorry
qed "sorry"

mtheorem xtuple_0_reduce_6:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1"
"reduce [XTUPLE-0K3 x1,x2,x3 ] `3-3XTUPLE-0K6 to x3"
proof
(*reducibility*)
  show "[XTUPLE-0K3 x1,x2,x3 ] `3-3XTUPLE-0K6 =HIDDENR1 x3"
     sorry
qed "sorry"

mtheorem xtuple_0_reduce_7:
  mlet "x be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
"reduce [XTUPLE-0K3 x `1-3XTUPLE-0K4,x `2-3XTUPLE-0K5,x `3-3XTUPLE-0K6 ] to x"
proof
(*reducibility*)
  show "[XTUPLE-0K3 x `1-3XTUPLE-0K4,x `2-3XTUPLE-0K5,x `3-3XTUPLE-0K6 ] =HIDDENR1 x"
  proof-
    obtain x1 x2 x3 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
      using xtuple_0_def_5 sorry
    show "[XTUPLE-0K3 x `1-3XTUPLE-0K4,x `2-3XTUPLE-0K5,x `3-3XTUPLE-0K6 ] =HIDDENR1 x"
      using A1 sorry
  qed
qed "sorry"

mtheorem xtuple_0_th_4:
" for a be tripleXTUPLE-0V2\<bar>objectHIDDENM1 holds  for b be tripleXTUPLE-0V2\<bar>objectHIDDENM1 holds (a `1-3XTUPLE-0K4 =HIDDENR1 b `1-3XTUPLE-0K4 & a `2-3XTUPLE-0K5 =HIDDENR1 b `2-3XTUPLE-0K5) & a `3-3XTUPLE-0K6 =HIDDENR1 b `3-3XTUPLE-0K6 implies a =HIDDENR1 b"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
  fix b assume [ty]: "b be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
  assume A1: "(a `1-3XTUPLE-0K4 =HIDDENR1 b `1-3XTUPLE-0K4 & a `2-3XTUPLE-0K5 =HIDDENR1 b `2-3XTUPLE-0K5) & a `3-3XTUPLE-0K6 =HIDDENR1 b `3-3XTUPLE-0K6"
  have "a =HIDDENR1 [XTUPLE-0K3 a `1-3XTUPLE-0K4,a `2-3XTUPLE-0K5,a `3-3XTUPLE-0K6 ] & b =HIDDENR1 [XTUPLE-0K3 b `1-3XTUPLE-0K4,b `2-3XTUPLE-0K5,b `3-3XTUPLE-0K6 ]"
     sorry
  thus "a =HIDDENR1 b"
    using A1 sorry
qed "sorry"

(*begin*)
mdef xtuple_0_def_8 ("[XTUPLE-0K7 _ , _ , _ , _ ]" [0,0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"func [XTUPLE-0K7 x1,x2,x3,x4 ] \<rightarrow> objectHIDDENM1 equals
  [TARSKIK4 [XTUPLE-0K3 x1,x2,x3 ],x4 ]"
proof-
  (*coherence*)
    show "[TARSKIK4 [XTUPLE-0K3 x1,x2,x3 ],x4 ] be objectHIDDENM1"
       sorry
qed "sorry"

mdef xtuple_0_def_9 ("quadrupleXTUPLE-0V3" 70 ) where
"attr quadrupleXTUPLE-0V3 for objectHIDDENM1 means
  (\<lambda>x.  ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])"..

mtheorem xtuple_0_cl_6:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster [XTUPLE-0K7 x1,x2,x3,x4 ] as-term-is quadrupleXTUPLE-0V3"
proof
(*coherence*)
  show "[XTUPLE-0K7 x1,x2,x3,x4 ] be quadrupleXTUPLE-0V3"
     sorry
qed "sorry"

mtheorem xtuple_0_th_5:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds [XTUPLE-0K7 x1,x2,x3,x4 ] =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies ((x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3) & x4 =HIDDENR1 y4"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds [XTUPLE-0K7 x1,x2,x3,x4 ] =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies ((x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3) & x4 =HIDDENR1 y4"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    fix y4 assume [ty]: "y4 be objectHIDDENM1"
    assume A1: "[XTUPLE-0K7 x1,x2,x3,x4 ] =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ]"
    then have "[XTUPLE-0K3 x1,x2,x3 ] =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ]"
      using xtuple_0_th_1 sorry
    thus "((x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3) & x4 =HIDDENR1 y4"
      using A1 xtuple_0_th_3 xtuple_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_cl_7:
"cluster quadrupleXTUPLE-0V3 for objectHIDDENM1"
proof
(*existence*)
  show " ex it be objectHIDDENM1 st it be quadrupleXTUPLE-0V3"
  proof-
    have " ex tVar10 be objectHIDDENM1 st tVar10 be quadrupleXTUPLE-0V3"
    proof-
      show " ex tVar10 be objectHIDDENM1 st tVar10 be quadrupleXTUPLE-0V3"
      proof(rule bexI[of _ "[XTUPLE-0K7 the objectHIDDENM1,the objectHIDDENM1,the objectHIDDENM1,the objectHIDDENM1 ]"])
        have " ex tVar12 be objectHIDDENM1 st  ex tVar13 be objectHIDDENM1 st  ex tVar14 be objectHIDDENM1 st [XTUPLE-0K7 tVar14,tVar14,tVar14,tVar14 ] =HIDDENR1 [XTUPLE-0K7 tVar14,tVar14,tVar14,tVar14 ]"
        proof(rule bexI[of _ "the objectHIDDENM1"])
          show " ex tVar13 be objectHIDDENM1 st  ex tVar14 be objectHIDDENM1 st [XTUPLE-0K7 tVar14,tVar14,tVar14,tVar14 ] =HIDDENR1 [XTUPLE-0K7 tVar14,tVar14,tVar14,tVar14 ]"
          proof(rule bexI[of _ "the objectHIDDENM1"])
            show " ex tVar14 be objectHIDDENM1 st [XTUPLE-0K7 tVar14,tVar14,tVar14,tVar14 ] =HIDDENR1 [XTUPLE-0K7 tVar14,tVar14,tVar14,tVar14 ]"
            proof(rule bexI[of _ "the objectHIDDENM1"])
              show "[XTUPLE-0K7 the objectHIDDENM1,the objectHIDDENM1,the objectHIDDENM1,the objectHIDDENM1 ] =HIDDENR1 [XTUPLE-0K7 the objectHIDDENM1,the objectHIDDENM1,the objectHIDDENM1,the objectHIDDENM1 ]"
                 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus "[XTUPLE-0K7 the objectHIDDENM1,the objectHIDDENM1,the objectHIDDENM1,the objectHIDDENM1 ] be quadrupleXTUPLE-0V3"
          using bexI[of _ "the objectHIDDENM1"] xtuple_0_def_9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xtuple_0_cl_8:
"cluster quadrupleXTUPLE-0V3 also-is tripleXTUPLE-0V2 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be quadrupleXTUPLE-0V3 implies it be tripleXTUPLE-0V2"
  proof-
    have " for x be objectHIDDENM1 holds  not (x be quadrupleXTUPLE-0V3 &  not x be tripleXTUPLE-0V2)"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]) implies x be tripleXTUPLE-0V2"
      proof(rule impI)
        assume Given: " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
        then obtain x1 x2 x3 x4 where
          [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
          A1: "x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
           sorry
        have "x =HIDDENR1 [XTUPLE-0K3 [TARSKIK4 x1,x2 ],x3,x4 ]"
          using A1 sorry
        thus "x be tripleXTUPLE-0V2"
           sorry
      qed
      thus " not (x be quadrupleXTUPLE-0V3 &  not x be tripleXTUPLE-0V2)"
        using xtuple_0_def_9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef xtuple_0_def_10 (" _ `1-4XTUPLE-0K8" [164]164 ) where
  mlet "x be objectHIDDENM1"
"func x `1-4XTUPLE-0K8 \<rightarrow> objectHIDDENM1 equals
  ((x `1XTUPLE-0K1)`1XTUPLE-0K1)`1XTUPLE-0K1"
proof-
  (*coherence*)
    show "((x `1XTUPLE-0K1)`1XTUPLE-0K1)`1XTUPLE-0K1 be objectHIDDENM1"
       sorry
qed "sorry"

mdef xtuple_0_def_11 (" _ `2-4XTUPLE-0K9" [164]164 ) where
  mlet "x be objectHIDDENM1"
"func x `2-4XTUPLE-0K9 \<rightarrow> objectHIDDENM1 equals
  ((x `1XTUPLE-0K1)`1XTUPLE-0K1)`2XTUPLE-0K2"
proof-
  (*coherence*)
    show "((x `1XTUPLE-0K1)`1XTUPLE-0K1)`2XTUPLE-0K2 be objectHIDDENM1"
       sorry
qed "sorry"

abbreviation(input) XTUPLE_0K10(" _ `3-4XTUPLE-0K10" [164]164) where
  "x `3-4XTUPLE-0K10 \<equiv> x `2-3XTUPLE-0K5"

abbreviation(input) XTUPLE_0K11(" _ `4-4XTUPLE-0K11" [164]164) where
  "x `4-4XTUPLE-0K11 \<equiv> x `2XTUPLE-0K2"

mtheorem xtuple_0_reduce_8:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce [XTUPLE-0K7 x1,x2,x3,x4 ] `1-4XTUPLE-0K8 to x1"
proof
(*reducibility*)
  show "[XTUPLE-0K7 x1,x2,x3,x4 ] `1-4XTUPLE-0K8 =HIDDENR1 x1"
     sorry
qed "sorry"

mtheorem xtuple_0_reduce_9:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce [XTUPLE-0K7 x1,x2,x3,x4 ] `2-4XTUPLE-0K9 to x2"
proof
(*reducibility*)
  show "[XTUPLE-0K7 x1,x2,x3,x4 ] `2-4XTUPLE-0K9 =HIDDENR1 x2"
     sorry
qed "sorry"

mtheorem xtuple_0_reduce_10:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce [XTUPLE-0K7 x1,x2,x3,x4 ] `3-4XTUPLE-0K10 to x3"
proof
(*reducibility*)
  show "[XTUPLE-0K7 x1,x2,x3,x4 ] `3-4XTUPLE-0K10 =HIDDENR1 x3"
     sorry
qed "sorry"

mtheorem xtuple_0_reduce_11:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce [XTUPLE-0K7 x1,x2,x3,x4 ] `4-4XTUPLE-0K11 to x4"
proof
(*reducibility*)
  show "[XTUPLE-0K7 x1,x2,x3,x4 ] `4-4XTUPLE-0K11 =HIDDENR1 x4"
     sorry
qed "sorry"

mtheorem xtuple_0_reduce_12:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"reduce [XTUPLE-0K7 x `1-4XTUPLE-0K8,x `2-4XTUPLE-0K9,x `3-4XTUPLE-0K10,x `4-4XTUPLE-0K11 ] to x"
proof
(*reducibility*)
  show "[XTUPLE-0K7 x `1-4XTUPLE-0K8,x `2-4XTUPLE-0K9,x `3-4XTUPLE-0K10,x `4-4XTUPLE-0K11 ] =HIDDENR1 x"
  proof-
    obtain x1 x2 x3 x4 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
      using xtuple_0_def_9 sorry
    show "[XTUPLE-0K7 x `1-4XTUPLE-0K8,x `2-4XTUPLE-0K9,x `3-4XTUPLE-0K10,x `4-4XTUPLE-0K11 ] =HIDDENR1 x"
      using A1 sorry
  qed
qed "sorry"

reserve X, X1, X2, X3, X4, Y for "setHIDDENM2"
mtheorem xtuple_0_th_6:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 X implies x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 X implies x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 X"
    have "{TARSKIK1 x} inTARSKIR2 {TARSKIK2 {TARSKIK1 x},{TARSKIK2 x,y } }"
      using tarski_def_2 sorry
    then have A2: "{TARSKIK1 x} inTARSKIR2 unionTARSKIK3 X"
      using A1 tarski_def_4 sorry
    have "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
      using A2 tarski_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_7:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 X implies y inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 X implies y inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 X"
    have "{TARSKIK2 x,y } inTARSKIR2 {TARSKIK2 {TARSKIK1 x},{TARSKIK2 x,y } }"
      using tarski_def_2 sorry
    then have A2: "{TARSKIK2 x,y } inTARSKIR2 unionTARSKIK3 X"
      using A1 tarski_def_4 sorry
    have "y inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    thus "y inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
      using A2 tarski_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef xtuple_0_def_12 ("proj1XTUPLE-0K12  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func proj1XTUPLE-0K12 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
    proof-
      have " ex tVar15 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar15 implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)) & (( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X) implies x inHIDDENR3 tVar15)"
      proof-
        let ?Q = "\<lambda>Lamb1.  ex y be objectHIDDENM1 st [TARSKIK4 Lamb1,y ] inHIDDENR3 X"
        obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X) & ?Q(x)"
          using xboole_0_sch_1 sorry
        show " ex tVar15 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar15 implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)) & (( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X) implies x inHIDDENR3 tVar15)"
        proof(rule bexI[of _ "Y"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 Y implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
            using A1 sorry
          assume Given: " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,y ] inHIDDENR3 X"
             sorry
          have "x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
            using A2 xtuple_0_th_6 sorry
          thus "x inHIDDENR3 Y"
            using A2 A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)) implies it1 =HIDDENR1 it2"
    proof-
      have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)) implies X1 =HIDDENR1 X2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        fix X2 assume [ty]: "X2 be setHIDDENM2"
        assume A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x inHIDDENR3 X2"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X)"
            using A3 sorry
          thus "x inHIDDENR3 X1 iff x inHIDDENR3 X2"
            using A4 sorry
        qed "sorry"
        thus "X1 =HIDDENR1 X2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef xtuple_0_def_13 ("proj2XTUPLE-0K13  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func proj2XTUPLE-0K13 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)"
    proof-
      have " ex tVar16 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar16 implies ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)) & (( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X) implies x inHIDDENR3 tVar16)"
      proof-
        let ?Q = "\<lambda>Lamb1.  ex y be objectHIDDENM1 st [TARSKIK4 y,Lamb1 ] inHIDDENR3 X"
        obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A5: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X) & ?Q(x)"
          using xboole_0_sch_1 sorry
        show " ex tVar16 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar16 implies ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)) & (( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X) implies x inHIDDENR3 tVar16)"
        proof(rule bexI[of _ "Y"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 Y implies ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)"
            using A5 sorry
          assume Given: " ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A6: "[TARSKIK4 y,x ] inHIDDENR3 X"
             sorry
          have "x inHIDDENR3 unionTARSKIK3 (unionTARSKIK3 X)"
            using A6 xtuple_0_th_7 sorry
          thus "x inHIDDENR3 Y"
            using A6 A5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)) implies it1 =HIDDENR1 it2"
    proof-
      have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)) implies X1 =HIDDENR1 X2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        fix X2 assume [ty]: "X2 be setHIDDENM2"
        assume A7: " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)"
          and A8: " for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x inHIDDENR3 X2"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 X1 iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X)"
            using A7 sorry
          thus "x inHIDDENR3 X1 iff x inHIDDENR3 X2"
            using A8 sorry
        qed "sorry"
        thus "X1 =HIDDENR1 X2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem xtuple_0_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj1XTUPLE-0K12 X c=TARSKIR1 proj1XTUPLE-0K12 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj1XTUPLE-0K12 X c=TARSKIR1 proj1XTUPLE-0K12 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 X implies x inHIDDENR3 proj1XTUPLE-0K12 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 proj1XTUPLE-0K12 X"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,y ] inHIDDENR3 X"
        using xtuple_0_def_12 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 Y"
        using A1 A2 sorry
      thus "x inHIDDENR3 proj1XTUPLE-0K12 Y"
        using xtuple_0_def_12 sorry
    qed "sorry"
    thus "proj1XTUPLE-0K12 X c=TARSKIR1 proj1XTUPLE-0K12 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj2XTUPLE-0K13 X c=TARSKIR1 proj2XTUPLE-0K13 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj2XTUPLE-0K13 X c=TARSKIR1 proj2XTUPLE-0K13 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 proj2XTUPLE-0K13 X implies x inHIDDENR3 proj2XTUPLE-0K13 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 proj2XTUPLE-0K13 X"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "[TARSKIK4 y,x ] inHIDDENR3 X"
        using xtuple_0_def_13 sorry
      have "[TARSKIK4 y,x ] inHIDDENR3 Y"
        using A1 A2 sorry
      thus "x inHIDDENR3 proj2XTUPLE-0K13 Y"
        using xtuple_0_def_13 sorry
    qed "sorry"
    thus "proj2XTUPLE-0K13 X c=TARSKIR1 proj2XTUPLE-0K13 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef xtuple_0_def_14 ("proj1-3XTUPLE-0K14  _ " [164]164 ) where
  mlet "X be setHIDDENM2"
"func proj1-3XTUPLE-0K14 X \<rightarrow> setHIDDENM2 equals
  proj1XTUPLE-0K12 (proj1XTUPLE-0K12 X)"
proof-
  (*coherence*)
    show "proj1XTUPLE-0K12 (proj1XTUPLE-0K12 X) be setHIDDENM2"
       sorry
qed "sorry"

mdef xtuple_0_def_15 ("proj2-3XTUPLE-0K15  _ " [164]164 ) where
  mlet "X be setHIDDENM2"
"func proj2-3XTUPLE-0K15 X \<rightarrow> setHIDDENM2 equals
  proj2XTUPLE-0K13 (proj1XTUPLE-0K12 X)"
proof-
  (*coherence*)
    show "proj2XTUPLE-0K13 (proj1XTUPLE-0K12 X) be setHIDDENM2"
       sorry
qed "sorry"

abbreviation(input) XTUPLE_0K16("proj3-3XTUPLE-0K16  _ " [164]164) where
  "proj3-3XTUPLE-0K16 X \<equiv> proj2XTUPLE-0K13 X"

mtheorem xtuple_0_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj1-3XTUPLE-0K14 X c=TARSKIR1 proj1-3XTUPLE-0K14 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj1-3XTUPLE-0K14 X c=TARSKIR1 proj1-3XTUPLE-0K14 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X c=TARSKIR1 Y"
    then have "proj1XTUPLE-0K12 X c=TARSKIR1 proj1XTUPLE-0K12 Y"
      using xtuple_0_th_8 sorry
    thus "proj1-3XTUPLE-0K14 X c=TARSKIR1 proj1-3XTUPLE-0K14 Y"
      using xtuple_0_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj2-3XTUPLE-0K15 X c=TARSKIR1 proj2-3XTUPLE-0K15 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj2-3XTUPLE-0K15 X c=TARSKIR1 proj2-3XTUPLE-0K15 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X c=TARSKIR1 Y"
    then have "proj1XTUPLE-0K12 X c=TARSKIR1 proj1XTUPLE-0K12 Y"
      using xtuple_0_th_8 sorry
    thus "proj2-3XTUPLE-0K15 X c=TARSKIR1 proj2-3XTUPLE-0K15 Y"
      using xtuple_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_12:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 proj1-3XTUPLE-0K14 X implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st [XTUPLE-0K3 x,y,z ] inHIDDENR3 X)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 proj1-3XTUPLE-0K14 X implies ( ex tVar17 be objectHIDDENM1 st  ex tVar18 be objectHIDDENM1 st [XTUPLE-0K3 x,tVar17,tVar18 ] inHIDDENR3 X)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "x inHIDDENR3 proj1-3XTUPLE-0K14 X"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A1: "[TARSKIK4 x,y ] inHIDDENR3 proj1XTUPLE-0K12 X"
      using xtuple_0_def_12 sorry
    obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A2: "[TARSKIK4 [TARSKIK4 x,y ],z ] inHIDDENR3 X"
      using A1 xtuple_0_def_12 sorry
    show " ex tVar17 be objectHIDDENM1 st  ex tVar18 be objectHIDDENM1 st [XTUPLE-0K3 x,tVar17,tVar18 ] inHIDDENR3 X"
    proof(rule bexI[of _ "y"])
      show " ex tVar18 be objectHIDDENM1 st [XTUPLE-0K3 x,y,tVar18 ] inHIDDENR3 X"
      proof(rule bexI[of _ "z"])
        show "[XTUPLE-0K3 x,y,z ] inHIDDENR3 X"
          using A2 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_13:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds [XTUPLE-0K3 x,y,z ] inHIDDENR3 X implies x inHIDDENR3 proj1-3XTUPLE-0K14 X"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds [XTUPLE-0K3 x,y,z ] inHIDDENR3 X implies x inHIDDENR3 proj1-3XTUPLE-0K14 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "[XTUPLE-0K3 x,y,z ] inHIDDENR3 X"
    then have "[TARSKIK4 x,y ] inHIDDENR3 proj1XTUPLE-0K12 X"
      using xtuple_0_def_12 sorry
    thus "x inHIDDENR3 proj1-3XTUPLE-0K14 X"
      using xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_14:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 proj2-3XTUPLE-0K15 X implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st [XTUPLE-0K3 y,x,z ] inHIDDENR3 X)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 proj2-3XTUPLE-0K15 X implies ( ex tVar19 be objectHIDDENM1 st  ex tVar20 be objectHIDDENM1 st [XTUPLE-0K3 tVar19,x,tVar20 ] inHIDDENR3 X)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "x inHIDDENR3 proj2-3XTUPLE-0K15 X"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A1: "[TARSKIK4 y,x ] inHIDDENR3 proj1XTUPLE-0K12 X"
      using xtuple_0_def_13 sorry
    obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A2: "[TARSKIK4 [TARSKIK4 y,x ],z ] inHIDDENR3 X"
      using A1 xtuple_0_def_12 sorry
    show " ex tVar19 be objectHIDDENM1 st  ex tVar20 be objectHIDDENM1 st [XTUPLE-0K3 tVar19,x,tVar20 ] inHIDDENR3 X"
    proof(rule bexI[of _ "y"])
      show " ex tVar20 be objectHIDDENM1 st [XTUPLE-0K3 y,x,tVar20 ] inHIDDENR3 X"
      proof(rule bexI[of _ "z"])
        show "[XTUPLE-0K3 y,x,z ] inHIDDENR3 X"
          using A2 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_15:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds [XTUPLE-0K3 x,y,z ] inHIDDENR3 X implies y inHIDDENR3 proj2-3XTUPLE-0K15 X"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds [XTUPLE-0K3 x,y,z ] inHIDDENR3 X implies y inHIDDENR3 proj2-3XTUPLE-0K15 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "[XTUPLE-0K3 x,y,z ] inHIDDENR3 X"
    then have "[TARSKIK4 x,y ] inHIDDENR3 proj1XTUPLE-0K12 X"
      using xtuple_0_def_12 sorry
    thus "y inHIDDENR3 proj2-3XTUPLE-0K15 X"
      using xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef xtuple_0_def_16 ("proj1-4XTUPLE-0K17  _ " [164]164 ) where
  mlet "X be setHIDDENM2"
"func proj1-4XTUPLE-0K17 X \<rightarrow> setHIDDENM2 equals
  proj1XTUPLE-0K12 (proj1-3XTUPLE-0K14 X)"
proof-
  (*coherence*)
    show "proj1XTUPLE-0K12 (proj1-3XTUPLE-0K14 X) be setHIDDENM2"
       sorry
qed "sorry"

mdef xtuple_0_def_17 ("proj2-4XTUPLE-0K18  _ " [164]164 ) where
  mlet "X be setHIDDENM2"
"func proj2-4XTUPLE-0K18 X \<rightarrow> setHIDDENM2 equals
  proj2XTUPLE-0K13 (proj1-3XTUPLE-0K14 X)"
proof-
  (*coherence*)
    show "proj2XTUPLE-0K13 (proj1-3XTUPLE-0K14 X) be setHIDDENM2"
       sorry
qed "sorry"

abbreviation(input) XTUPLE_0K19("proj3-4XTUPLE-0K19  _ " [164]164) where
  "proj3-4XTUPLE-0K19 X \<equiv> proj2-3XTUPLE-0K15 X"

abbreviation(input) XTUPLE_0K20("proj4-4XTUPLE-0K20  _ " [164]164) where
  "proj4-4XTUPLE-0K20 X \<equiv> proj2XTUPLE-0K13 X"

mtheorem xtuple_0_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj1-4XTUPLE-0K17 X c=TARSKIR1 proj1-4XTUPLE-0K17 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj1-4XTUPLE-0K17 X c=TARSKIR1 proj1-4XTUPLE-0K17 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X c=TARSKIR1 Y"
    then have "proj1-3XTUPLE-0K14 X c=TARSKIR1 proj1-3XTUPLE-0K14 Y"
      using xtuple_0_th_10 sorry
    thus "proj1-4XTUPLE-0K17 X c=TARSKIR1 proj1-4XTUPLE-0K17 Y"
      using xtuple_0_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_17:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj2-4XTUPLE-0K18 X c=TARSKIR1 proj2-4XTUPLE-0K18 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies proj2-4XTUPLE-0K18 X c=TARSKIR1 proj2-4XTUPLE-0K18 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X c=TARSKIR1 Y"
    then have "proj1-3XTUPLE-0K14 X c=TARSKIR1 proj1-3XTUPLE-0K14 Y"
      using xtuple_0_th_10 sorry
    thus "proj2-4XTUPLE-0K18 X c=TARSKIR1 proj2-4XTUPLE-0K18 Y"
      using xtuple_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_18:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 proj1-4XTUPLE-0K17 X implies ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st [XTUPLE-0K7 x,x1,x2,x3 ] inHIDDENR3 X)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 proj1-4XTUPLE-0K17 X implies ( ex tVar21 be objectHIDDENM1 st  ex tVar22 be objectHIDDENM1 st  ex tVar23 be objectHIDDENM1 st [XTUPLE-0K7 x,tVar21,tVar22,tVar23 ] inHIDDENR3 X)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "x inHIDDENR3 proj1-4XTUPLE-0K17 X"
    then obtain x1 where
      [ty]:"x1 be objectHIDDENM1" and 
      A1: "[TARSKIK4 x,x1 ] inHIDDENR3 proj1-3XTUPLE-0K14 X"
      using xtuple_0_def_12 sorry
    obtain x2 where
      [ty]:"x2 be objectHIDDENM1" and 
      A2: "[TARSKIK4 [TARSKIK4 x,x1 ],x2 ] inHIDDENR3 proj1XTUPLE-0K12 X"
      using A1 xtuple_0_def_12 sorry
    obtain x3 where
      [ty]:"x3 be objectHIDDENM1" and 
      A3: "[TARSKIK4 [TARSKIK4 [TARSKIK4 x,x1 ],x2 ],x3 ] inHIDDENR3 X"
      using A2 xtuple_0_def_12 sorry
    show " ex tVar21 be objectHIDDENM1 st  ex tVar22 be objectHIDDENM1 st  ex tVar23 be objectHIDDENM1 st [XTUPLE-0K7 x,tVar21,tVar22,tVar23 ] inHIDDENR3 X"
    proof(rule bexI[of _ "x1"])
      show " ex tVar22 be objectHIDDENM1 st  ex tVar23 be objectHIDDENM1 st [XTUPLE-0K7 x,x1,tVar22,tVar23 ] inHIDDENR3 X"
      proof(rule bexI[of _ "x2"])
        show " ex tVar23 be objectHIDDENM1 st [XTUPLE-0K7 x,x1,x2,tVar23 ] inHIDDENR3 X"
        proof(rule bexI[of _ "x3"])
          show "[XTUPLE-0K7 x,x1,x2,x3 ] inHIDDENR3 X"
            using A3 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_19:
" for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for X be setHIDDENM2 holds [XTUPLE-0K7 x,x1,x2,x3 ] inHIDDENR3 X implies x inHIDDENR3 proj1-4XTUPLE-0K17 X"
proof-
  have " for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for X be setHIDDENM2 holds [XTUPLE-0K7 x,x1,x2,x3 ] inHIDDENR3 X implies x inHIDDENR3 proj1-4XTUPLE-0K17 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "[XTUPLE-0K7 x,x1,x2,x3 ] inHIDDENR3 X"
    then have "[XTUPLE-0K3 [TARSKIK4 x,x1 ],x2,x3 ] inHIDDENR3 X"
       sorry
    then have "[TARSKIK4 x,x1 ] inHIDDENR3 proj1-3XTUPLE-0K14 X"
      using xtuple_0_th_13 sorry
    thus "x inHIDDENR3 proj1-4XTUPLE-0K17 X"
      using xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_20:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 proj2-4XTUPLE-0K18 X implies ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st [XTUPLE-0K7 x1,x,x2,x3 ] inHIDDENR3 X)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 proj2-4XTUPLE-0K18 X implies ( ex tVar24 be objectHIDDENM1 st  ex tVar25 be objectHIDDENM1 st  ex tVar26 be objectHIDDENM1 st [XTUPLE-0K7 tVar24,x,tVar25,tVar26 ] inHIDDENR3 X)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "x inHIDDENR3 proj2-4XTUPLE-0K18 X"
    then obtain x1 where
      [ty]:"x1 be objectHIDDENM1" and 
      A1: "[TARSKIK4 x1,x ] inHIDDENR3 proj1-3XTUPLE-0K14 X"
      using xtuple_0_def_13 sorry
    obtain x2 where
      [ty]:"x2 be objectHIDDENM1" and 
      A2: "[TARSKIK4 [TARSKIK4 x1,x ],x2 ] inHIDDENR3 proj1XTUPLE-0K12 X"
      using A1 xtuple_0_def_12 sorry
    obtain x3 where
      [ty]:"x3 be objectHIDDENM1" and 
      A3: "[TARSKIK4 [TARSKIK4 [TARSKIK4 x1,x ],x2 ],x3 ] inHIDDENR3 X"
      using A2 xtuple_0_def_12 sorry
    show " ex tVar24 be objectHIDDENM1 st  ex tVar25 be objectHIDDENM1 st  ex tVar26 be objectHIDDENM1 st [XTUPLE-0K7 tVar24,x,tVar25,tVar26 ] inHIDDENR3 X"
    proof(rule bexI[of _ "x1"])
      show " ex tVar25 be objectHIDDENM1 st  ex tVar26 be objectHIDDENM1 st [XTUPLE-0K7 x1,x,tVar25,tVar26 ] inHIDDENR3 X"
      proof(rule bexI[of _ "x2"])
        show " ex tVar26 be objectHIDDENM1 st [XTUPLE-0K7 x1,x,x2,tVar26 ] inHIDDENR3 X"
        proof(rule bexI[of _ "x3"])
          show "[XTUPLE-0K7 x1,x,x2,x3 ] inHIDDENR3 X"
            using A3 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_21:
" for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for X be setHIDDENM2 holds [XTUPLE-0K7 x1,x,x2,x3 ] inHIDDENR3 X implies x inHIDDENR3 proj2-4XTUPLE-0K18 X"
proof-
  have " for x be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for X be setHIDDENM2 holds [XTUPLE-0K7 x1,x,x2,x3 ] inHIDDENR3 X implies x inHIDDENR3 proj2-4XTUPLE-0K18 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "[XTUPLE-0K7 x1,x,x2,x3 ] inHIDDENR3 X"
    then have "[XTUPLE-0K3 [TARSKIK4 x1,x ],x2,x3 ] inHIDDENR3 X"
       sorry
    then have "[TARSKIK4 x1,x ] inHIDDENR3 proj1-3XTUPLE-0K14 X"
      using xtuple_0_th_13 sorry
    thus "x inHIDDENR3 proj2-4XTUPLE-0K18 X"
      using xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_22:
" for a be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1 holds  for b be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1 holds ((a `1-4XTUPLE-0K8 =HIDDENR1 b `1-4XTUPLE-0K8 & a `2-4XTUPLE-0K9 =HIDDENR1 b `2-4XTUPLE-0K9) & a `3-4XTUPLE-0K10 =HIDDENR1 b `3-4XTUPLE-0K10) & a `4-4XTUPLE-0K11 =HIDDENR1 b `4-4XTUPLE-0K11 implies a =HIDDENR1 b"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
  fix b assume [ty]: "b be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
  assume A1: "((a `1-4XTUPLE-0K8 =HIDDENR1 b `1-4XTUPLE-0K8 & a `2-4XTUPLE-0K9 =HIDDENR1 b `2-4XTUPLE-0K9) & a `3-4XTUPLE-0K10 =HIDDENR1 b `3-4XTUPLE-0K10) & a `4-4XTUPLE-0K11 =HIDDENR1 b `4-4XTUPLE-0K11"
  have "a =HIDDENR1 [XTUPLE-0K7 a `1-4XTUPLE-0K8,a `2-4XTUPLE-0K9,a `3-4XTUPLE-0K10,a `4-4XTUPLE-0K11 ] & b =HIDDENR1 [XTUPLE-0K7 b `1-4XTUPLE-0K8,b `2-4XTUPLE-0K9,b `3-4XTUPLE-0K10,b `4-4XTUPLE-0K11 ]"
     sorry
  thus "a =HIDDENR1 b"
    using A1 sorry
qed "sorry"

(*begin*)
mtheorem xtuple_0_cl_9:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster proj1XTUPLE-0K12 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "proj1XTUPLE-0K12 X be emptyXBOOLE-0V1"
  proof-
    have "proj1XTUPLE-0K12 X be  non emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      assume "proj1XTUPLE-0K12 X be  non emptyXBOOLE-0V1"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 proj1XTUPLE-0K12 X"
         sorry
      have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 X"
        using A1 xtuple_0_def_12 sorry
      thus " False "
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xtuple_0_cl_10:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster proj2XTUPLE-0K13 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "proj2XTUPLE-0K13 X be emptyXBOOLE-0V1"
  proof-
    have "proj2XTUPLE-0K13 X be  non emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      assume "proj2XTUPLE-0K13 X be  non emptyXBOOLE-0V1"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 proj2XTUPLE-0K13 X"
         sorry
      have " ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 X"
        using A1 xtuple_0_def_13 sorry
      thus " False "
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xtuple_0_cl_11:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster proj1-3XTUPLE-0K14 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "proj1-3XTUPLE-0K14 X be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem xtuple_0_cl_12:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster proj2-3XTUPLE-0K15 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "proj2-3XTUPLE-0K15 X be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem xtuple_0_cl_13:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster proj1-4XTUPLE-0K17 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "proj1-4XTUPLE-0K17 X be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem xtuple_0_cl_14:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster proj2-4XTUPLE-0K18 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "proj2-4XTUPLE-0K18 X be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem xtuple_0_th_23:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y & proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y)"
    proof(rule conjMI)
      show "proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y) implies x inHIDDENR3 proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y)"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xtuple_0_def_12 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 X or [TARSKIK4 x,y ] inHIDDENR3 Y"
            using A1 xboole_0_def_3 sorry
          then have "x inHIDDENR3 proj1XTUPLE-0K12 X or x inHIDDENR3 proj1XTUPLE-0K12 Y"
            using xtuple_0_def_12 sorry
          thus "x inHIDDENR3 proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y"
          using tarski_def_3 sorry
      qed
      have A2: "proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y)"
        using xtuple_0_th_8 xboole_1_th_7 sorry
      have "proj1XTUPLE-0K12 X c=TARSKIR1 proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y)"
        using xtuple_0_th_8 xboole_1_th_7 sorry
      thus "proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y)"
        using A2 xboole_1_th_8 sorry
    qed
    thus "proj1XTUPLE-0K12 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_24:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1XTUPLE-0K12 X /\\XBOOLE-0K3 proj1XTUPLE-0K12 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1XTUPLE-0K12 X /\\XBOOLE-0K3 proj1XTUPLE-0K12 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1XTUPLE-0K12 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1XTUPLE-0K12 X & proj1XTUPLE-0K12 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1XTUPLE-0K12 Y"
      using xtuple_0_th_8 xboole_1_th_17 sorry
    thus "proj1XTUPLE-0K12 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1XTUPLE-0K12 X /\\XBOOLE-0K3 proj1XTUPLE-0K12 Y"
      using xboole_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_25:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 X \\XBOOLE-0K4 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\XBOOLE-0K4 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 X \\XBOOLE-0K4 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\XBOOLE-0K4 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1XTUPLE-0K12 X \\XBOOLE-0K4 proj1XTUPLE-0K12 Y implies x inHIDDENR3 proj1XTUPLE-0K12 (X \\XBOOLE-0K4 Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 proj1XTUPLE-0K12 X \\XBOOLE-0K4 proj1XTUPLE-0K12 Y"
      then have "x inHIDDENR3 proj1XTUPLE-0K12 X"
        using xboole_0_def_5 sorry
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,y ] inHIDDENR3 X"
        using xtuple_0_def_12 sorry
      have " not x inHIDDENR3 proj1XTUPLE-0K12 Y"
        using A1 xboole_0_def_5 sorry
      then have " not [TARSKIK4 x,y ] inHIDDENR3 Y"
        using xtuple_0_def_12 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 X \\XBOOLE-0K4 Y"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 proj1XTUPLE-0K12 (X \\XBOOLE-0K4 Y)"
        using xtuple_0_def_12 sorry
    qed "sorry"
    thus "proj1XTUPLE-0K12 X \\XBOOLE-0K4 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\XBOOLE-0K4 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_26:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 X \\+\\XBOOLE-0K5 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\+\\XBOOLE-0K5 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1XTUPLE-0K12 X \\+\\XBOOLE-0K5 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\+\\XBOOLE-0K5 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1XTUPLE-0K12 X \\XBOOLE-0K4 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\XBOOLE-0K4 Y) & proj1XTUPLE-0K12 Y \\XBOOLE-0K4 proj1XTUPLE-0K12 X c=TARSKIR1 proj1XTUPLE-0K12 (Y \\XBOOLE-0K4 X)"
      using xtuple_0_th_25 sorry
    then have "proj1XTUPLE-0K12 X \\+\\XBOOLE-0K5 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\XBOOLE-0K4 Y) \\/XBOOLE-0K2 proj1XTUPLE-0K12 (Y \\XBOOLE-0K4 X)"
      using xboole_1_th_13 sorry
    thus "proj1XTUPLE-0K12 X \\+\\XBOOLE-0K5 proj1XTUPLE-0K12 Y c=TARSKIR1 proj1XTUPLE-0K12 (X \\+\\XBOOLE-0K5 Y)"
      using xtuple_0_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_27:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y & proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y)"
    proof(rule conjMI)
      show "proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y) implies y inHIDDENR3 proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xtuple_0_def_13 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 X or [TARSKIK4 x,y ] inHIDDENR3 Y"
            using A1 xboole_0_def_3 sorry
          then have "y inHIDDENR3 proj2XTUPLE-0K13 X or y inHIDDENR3 proj2XTUPLE-0K13 Y"
            using xtuple_0_def_13 sorry
          thus "y inHIDDENR3 proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y"
          using tarski_def_3 sorry
      qed
      have A2: "proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y)"
        using xtuple_0_th_9 xboole_1_th_7 sorry
      have "proj2XTUPLE-0K13 X c=TARSKIR1 proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y)"
        using xtuple_0_th_9 xboole_1_th_7 sorry
      thus "proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y)"
        using A2 xboole_1_th_8 sorry
    qed
    thus "proj2XTUPLE-0K13 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj2XTUPLE-0K13 X \\/XBOOLE-0K2 proj2XTUPLE-0K13 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_28:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2XTUPLE-0K13 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj2XTUPLE-0K13 X /\\XBOOLE-0K3 proj2XTUPLE-0K13 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2XTUPLE-0K13 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj2XTUPLE-0K13 X /\\XBOOLE-0K3 proj2XTUPLE-0K13 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 proj2XTUPLE-0K13 (X /\\XBOOLE-0K3 Y) implies y inHIDDENR3 proj2XTUPLE-0K13 X /\\XBOOLE-0K3 proj2XTUPLE-0K13 Y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 proj2XTUPLE-0K13 (X /\\XBOOLE-0K3 Y)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,y ] inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using xtuple_0_def_13 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 Y"
        using A1 xboole_0_def_4 sorry
      then have A2: "y inHIDDENR3 proj2XTUPLE-0K13 Y"
        using xtuple_0_def_13 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 X"
        using A1 xboole_0_def_4 sorry
      then have "y inHIDDENR3 proj2XTUPLE-0K13 X"
        using xtuple_0_def_13 sorry
      thus "y inHIDDENR3 proj2XTUPLE-0K13 X /\\XBOOLE-0K3 proj2XTUPLE-0K13 Y"
        using A2 xboole_0_def_4 sorry
    qed "sorry"
    thus "proj2XTUPLE-0K13 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj2XTUPLE-0K13 X /\\XBOOLE-0K3 proj2XTUPLE-0K13 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_29:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2XTUPLE-0K13 X \\XBOOLE-0K4 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\XBOOLE-0K4 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2XTUPLE-0K13 X \\XBOOLE-0K4 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\XBOOLE-0K4 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 proj2XTUPLE-0K13 X \\XBOOLE-0K4 proj2XTUPLE-0K13 Y implies y inHIDDENR3 proj2XTUPLE-0K13 (X \\XBOOLE-0K4 Y)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A1: "y inHIDDENR3 proj2XTUPLE-0K13 X \\XBOOLE-0K4 proj2XTUPLE-0K13 Y"
      then have "y inHIDDENR3 proj2XTUPLE-0K13 X"
        using xboole_0_def_5 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,y ] inHIDDENR3 X"
        using xtuple_0_def_13 sorry
      have " not y inHIDDENR3 proj2XTUPLE-0K13 Y"
        using A1 xboole_0_def_5 sorry
      then have " not [TARSKIK4 x,y ] inHIDDENR3 Y"
        using xtuple_0_def_13 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 X \\XBOOLE-0K4 Y"
        using A2 xboole_0_def_5 sorry
      thus "y inHIDDENR3 proj2XTUPLE-0K13 (X \\XBOOLE-0K4 Y)"
        using xtuple_0_def_13 sorry
    qed "sorry"
    thus "proj2XTUPLE-0K13 X \\XBOOLE-0K4 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\XBOOLE-0K4 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_30:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2XTUPLE-0K13 X \\+\\XBOOLE-0K5 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\+\\XBOOLE-0K5 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2XTUPLE-0K13 X \\+\\XBOOLE-0K5 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\+\\XBOOLE-0K5 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj2XTUPLE-0K13 X \\XBOOLE-0K4 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\XBOOLE-0K4 Y) & proj2XTUPLE-0K13 Y \\XBOOLE-0K4 proj2XTUPLE-0K13 X c=TARSKIR1 proj2XTUPLE-0K13 (Y \\XBOOLE-0K4 X)"
      using xtuple_0_th_29 sorry
    then have "proj2XTUPLE-0K13 X \\+\\XBOOLE-0K5 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\XBOOLE-0K4 Y) \\/XBOOLE-0K2 proj2XTUPLE-0K13 (Y \\XBOOLE-0K4 X)"
      using xboole_1_th_13 sorry
    thus "proj2XTUPLE-0K13 X \\+\\XBOOLE-0K5 proj2XTUPLE-0K13 Y c=TARSKIR1 proj2XTUPLE-0K13 (X \\+\\XBOOLE-0K5 Y)"
      using xtuple_0_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_31:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-3XTUPLE-0K14 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj1-3XTUPLE-0K14 X \\/XBOOLE-0K2 proj1-3XTUPLE-0K14 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-3XTUPLE-0K14 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj1-3XTUPLE-0K14 X \\/XBOOLE-0K2 proj1-3XTUPLE-0K14 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1-3XTUPLE-0K14 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj1XTUPLE-0K12 (proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y)"
      using xtuple_0_th_23 sorry
    also have "... = proj1-3XTUPLE-0K14 X \\/XBOOLE-0K2 proj1-3XTUPLE-0K14 Y"
      using xtuple_0_th_23 sorry
    finally show "proj1-3XTUPLE-0K14 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj1-3XTUPLE-0K14 X \\/XBOOLE-0K2 proj1-3XTUPLE-0K14 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_32:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-3XTUPLE-0K14 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj1-3XTUPLE-0K14 X)/\\XBOOLE-0K3 (proj1-3XTUPLE-0K14 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-3XTUPLE-0K14 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj1-3XTUPLE-0K14 X)/\\XBOOLE-0K3 (proj1-3XTUPLE-0K14 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1-3XTUPLE-0K14 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1-3XTUPLE-0K14 X & proj1-3XTUPLE-0K14 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1-3XTUPLE-0K14 Y"
      using xtuple_0_th_10 xboole_1_th_17 sorry
    thus "proj1-3XTUPLE-0K14 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj1-3XTUPLE-0K14 X)/\\XBOOLE-0K3 (proj1-3XTUPLE-0K14 Y)"
      using xboole_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_33:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-3XTUPLE-0K14 X \\XBOOLE-0K4 proj1-3XTUPLE-0K14 Y c=TARSKIR1 proj1-3XTUPLE-0K14 (X \\XBOOLE-0K4 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-3XTUPLE-0K14 X \\XBOOLE-0K4 proj1-3XTUPLE-0K14 Y c=TARSKIR1 proj1-3XTUPLE-0K14 (X \\XBOOLE-0K4 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1-3XTUPLE-0K14 X \\XBOOLE-0K4 proj1-3XTUPLE-0K14 Y implies x inHIDDENR3 proj1-3XTUPLE-0K14 (X \\XBOOLE-0K4 Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 proj1-3XTUPLE-0K14 X \\XBOOLE-0K4 proj1-3XTUPLE-0K14 Y"
      then have "x inHIDDENR3 proj1-3XTUPLE-0K14 X"
        using xboole_0_def_5 sorry
      then obtain y z where
        [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
        A2: "[XTUPLE-0K3 x,y,z ] inHIDDENR3 X"
        using xtuple_0_th_12 sorry
      have " not x inHIDDENR3 proj1-3XTUPLE-0K14 Y"
        using A1 xboole_0_def_5 sorry
      then have " not [XTUPLE-0K3 x,y,z ] inHIDDENR3 Y"
        using xtuple_0_th_13 sorry
      then have "[XTUPLE-0K3 x,y,z ] inHIDDENR3 X \\XBOOLE-0K4 Y"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 proj1-3XTUPLE-0K14 (X \\XBOOLE-0K4 Y)"
        using xtuple_0_th_13 sorry
    qed "sorry"
    thus "proj1-3XTUPLE-0K14 X \\XBOOLE-0K4 proj1-3XTUPLE-0K14 Y c=TARSKIR1 proj1-3XTUPLE-0K14 (X \\XBOOLE-0K4 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_34:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-3XTUPLE-0K14 X \\+\\XBOOLE-0K5 proj1-3XTUPLE-0K14 Y c=TARSKIR1 proj1-3XTUPLE-0K14 (X \\+\\XBOOLE-0K5 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-3XTUPLE-0K14 X \\+\\XBOOLE-0K5 proj1-3XTUPLE-0K14 Y c=TARSKIR1 proj1-3XTUPLE-0K14 (X \\+\\XBOOLE-0K5 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1-3XTUPLE-0K14 X \\XBOOLE-0K4 proj1-3XTUPLE-0K14 Y c=TARSKIR1 proj1-3XTUPLE-0K14 (X \\XBOOLE-0K4 Y) & proj1-3XTUPLE-0K14 Y \\XBOOLE-0K4 proj1-3XTUPLE-0K14 X c=TARSKIR1 proj1-3XTUPLE-0K14 (Y \\XBOOLE-0K4 X)"
      using xtuple_0_th_33 sorry
    then have "proj1-3XTUPLE-0K14 X \\+\\XBOOLE-0K5 proj1-3XTUPLE-0K14 Y c=TARSKIR1 proj1-3XTUPLE-0K14 (X \\XBOOLE-0K4 Y) \\/XBOOLE-0K2 proj1-3XTUPLE-0K14 (Y \\XBOOLE-0K4 X)"
      using xboole_1_th_13 sorry
    thus "proj1-3XTUPLE-0K14 X \\+\\XBOOLE-0K5 proj1-3XTUPLE-0K14 Y c=TARSKIR1 proj1-3XTUPLE-0K14 (X \\+\\XBOOLE-0K5 Y)"
      using xtuple_0_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_35:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-3XTUPLE-0K15 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj2-3XTUPLE-0K15 X \\/XBOOLE-0K2 proj2-3XTUPLE-0K15 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-3XTUPLE-0K15 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj2-3XTUPLE-0K15 X \\/XBOOLE-0K2 proj2-3XTUPLE-0K15 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj2-3XTUPLE-0K15 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj2XTUPLE-0K13 (proj1XTUPLE-0K12 X \\/XBOOLE-0K2 proj1XTUPLE-0K12 Y)"
      using xtuple_0_th_23 sorry
    also have "... = proj2-3XTUPLE-0K15 X \\/XBOOLE-0K2 proj2-3XTUPLE-0K15 Y"
      using xtuple_0_th_27 sorry
    finally show "proj2-3XTUPLE-0K15 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj2-3XTUPLE-0K15 X \\/XBOOLE-0K2 proj2-3XTUPLE-0K15 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_36:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-3XTUPLE-0K15 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj2-3XTUPLE-0K15 X)/\\XBOOLE-0K3 (proj2-3XTUPLE-0K15 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-3XTUPLE-0K15 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj2-3XTUPLE-0K15 X)/\\XBOOLE-0K3 (proj2-3XTUPLE-0K15 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj2-3XTUPLE-0K15 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj2-3XTUPLE-0K15 X & proj2-3XTUPLE-0K15 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj2-3XTUPLE-0K15 Y"
      using xtuple_0_th_11 xboole_1_th_17 sorry
    thus "proj2-3XTUPLE-0K15 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj2-3XTUPLE-0K15 X)/\\XBOOLE-0K3 (proj2-3XTUPLE-0K15 Y)"
      using xboole_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_37:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-3XTUPLE-0K15 X \\XBOOLE-0K4 proj2-3XTUPLE-0K15 Y c=TARSKIR1 proj2-3XTUPLE-0K15 (X \\XBOOLE-0K4 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-3XTUPLE-0K15 X \\XBOOLE-0K4 proj2-3XTUPLE-0K15 Y c=TARSKIR1 proj2-3XTUPLE-0K15 (X \\XBOOLE-0K4 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 proj2-3XTUPLE-0K15 X \\XBOOLE-0K4 proj2-3XTUPLE-0K15 Y implies x inHIDDENR3 proj2-3XTUPLE-0K15 (X \\XBOOLE-0K4 Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 proj2-3XTUPLE-0K15 X \\XBOOLE-0K4 proj2-3XTUPLE-0K15 Y"
      then have "x inHIDDENR3 proj2-3XTUPLE-0K15 X"
        using xboole_0_def_5 sorry
      then obtain y z where
        [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
        A2: "[XTUPLE-0K3 y,x,z ] inHIDDENR3 X"
        using xtuple_0_th_14 sorry
      have " not x inHIDDENR3 proj2-3XTUPLE-0K15 Y"
        using A1 xboole_0_def_5 sorry
      then have " not [XTUPLE-0K3 y,x,z ] inHIDDENR3 Y"
        using xtuple_0_th_15 sorry
      then have "[XTUPLE-0K3 y,x,z ] inHIDDENR3 X \\XBOOLE-0K4 Y"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 proj2-3XTUPLE-0K15 (X \\XBOOLE-0K4 Y)"
        using xtuple_0_th_15 sorry
    qed "sorry"
    thus "proj2-3XTUPLE-0K15 X \\XBOOLE-0K4 proj2-3XTUPLE-0K15 Y c=TARSKIR1 proj2-3XTUPLE-0K15 (X \\XBOOLE-0K4 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_38:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-3XTUPLE-0K15 X \\+\\XBOOLE-0K5 proj2-3XTUPLE-0K15 Y c=TARSKIR1 proj2-3XTUPLE-0K15 (X \\+\\XBOOLE-0K5 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-3XTUPLE-0K15 X \\+\\XBOOLE-0K5 proj2-3XTUPLE-0K15 Y c=TARSKIR1 proj2-3XTUPLE-0K15 (X \\+\\XBOOLE-0K5 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj2-3XTUPLE-0K15 X \\XBOOLE-0K4 proj2-3XTUPLE-0K15 Y c=TARSKIR1 proj2-3XTUPLE-0K15 (X \\XBOOLE-0K4 Y) & proj2-3XTUPLE-0K15 Y \\XBOOLE-0K4 proj2-3XTUPLE-0K15 X c=TARSKIR1 proj2-3XTUPLE-0K15 (Y \\XBOOLE-0K4 X)"
      using xtuple_0_th_37 sorry
    then have "proj2-3XTUPLE-0K15 X \\+\\XBOOLE-0K5 proj2-3XTUPLE-0K15 Y c=TARSKIR1 proj2-3XTUPLE-0K15 (X \\XBOOLE-0K4 Y) \\/XBOOLE-0K2 proj2-3XTUPLE-0K15 (Y \\XBOOLE-0K4 X)"
      using xboole_1_th_13 sorry
    thus "proj2-3XTUPLE-0K15 X \\+\\XBOOLE-0K5 proj2-3XTUPLE-0K15 Y c=TARSKIR1 proj2-3XTUPLE-0K15 (X \\+\\XBOOLE-0K5 Y)"
      using xtuple_0_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_39:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-4XTUPLE-0K17 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj1-4XTUPLE-0K17 X \\/XBOOLE-0K2 proj1-4XTUPLE-0K17 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-4XTUPLE-0K17 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj1-4XTUPLE-0K17 X \\/XBOOLE-0K2 proj1-4XTUPLE-0K17 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1-4XTUPLE-0K17 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj1XTUPLE-0K12 (proj1-3XTUPLE-0K14 X \\/XBOOLE-0K2 proj1-3XTUPLE-0K14 Y)"
      using xtuple_0_th_31 sorry
    also have "... = proj1-4XTUPLE-0K17 X \\/XBOOLE-0K2 proj1-4XTUPLE-0K17 Y"
      using xtuple_0_th_23 sorry
    finally show "proj1-4XTUPLE-0K17 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj1-4XTUPLE-0K17 X \\/XBOOLE-0K2 proj1-4XTUPLE-0K17 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-4XTUPLE-0K17 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj1-4XTUPLE-0K17 X)/\\XBOOLE-0K3 (proj1-4XTUPLE-0K17 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-4XTUPLE-0K17 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj1-4XTUPLE-0K17 X)/\\XBOOLE-0K3 (proj1-4XTUPLE-0K17 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1-4XTUPLE-0K17 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1-4XTUPLE-0K17 X & proj1-4XTUPLE-0K17 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj1-4XTUPLE-0K17 Y"
      using xtuple_0_th_16 xboole_1_th_17 sorry
    thus "proj1-4XTUPLE-0K17 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj1-4XTUPLE-0K17 X)/\\XBOOLE-0K3 (proj1-4XTUPLE-0K17 Y)"
      using xboole_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-4XTUPLE-0K17 X \\XBOOLE-0K4 proj1-4XTUPLE-0K17 Y c=TARSKIR1 proj1-4XTUPLE-0K17 (X \\XBOOLE-0K4 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-4XTUPLE-0K17 X \\XBOOLE-0K4 proj1-4XTUPLE-0K17 Y c=TARSKIR1 proj1-4XTUPLE-0K17 (X \\XBOOLE-0K4 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 proj1-4XTUPLE-0K17 X \\XBOOLE-0K4 proj1-4XTUPLE-0K17 Y implies x inHIDDENR3 proj1-4XTUPLE-0K17 (X \\XBOOLE-0K4 Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 proj1-4XTUPLE-0K17 X \\XBOOLE-0K4 proj1-4XTUPLE-0K17 Y"
      then have "x inHIDDENR3 proj1-4XTUPLE-0K17 X"
        using xboole_0_def_5 sorry
      then obtain x1 x2 x3 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
        A2: "[XTUPLE-0K7 x,x1,x2,x3 ] inHIDDENR3 X"
        using xtuple_0_th_18 sorry
      have " not x inHIDDENR3 proj1-4XTUPLE-0K17 Y"
        using A1 xboole_0_def_5 sorry
      then have " not [XTUPLE-0K7 x,x1,x2,x3 ] inHIDDENR3 Y"
        using xtuple_0_th_19 sorry
      then have "[XTUPLE-0K7 x,x1,x2,x3 ] inHIDDENR3 X \\XBOOLE-0K4 Y"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 proj1-4XTUPLE-0K17 (X \\XBOOLE-0K4 Y)"
        using xtuple_0_th_19 sorry
    qed "sorry"
    thus "proj1-4XTUPLE-0K17 X \\XBOOLE-0K4 proj1-4XTUPLE-0K17 Y c=TARSKIR1 proj1-4XTUPLE-0K17 (X \\XBOOLE-0K4 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_42:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-4XTUPLE-0K17 X \\+\\XBOOLE-0K5 proj1-4XTUPLE-0K17 Y c=TARSKIR1 proj1-4XTUPLE-0K17 (X \\+\\XBOOLE-0K5 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj1-4XTUPLE-0K17 X \\+\\XBOOLE-0K5 proj1-4XTUPLE-0K17 Y c=TARSKIR1 proj1-4XTUPLE-0K17 (X \\+\\XBOOLE-0K5 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj1-4XTUPLE-0K17 X \\XBOOLE-0K4 proj1-4XTUPLE-0K17 Y c=TARSKIR1 proj1-4XTUPLE-0K17 (X \\XBOOLE-0K4 Y) & proj1-4XTUPLE-0K17 Y \\XBOOLE-0K4 proj1-4XTUPLE-0K17 X c=TARSKIR1 proj1-4XTUPLE-0K17 (Y \\XBOOLE-0K4 X)"
      using xtuple_0_th_41 sorry
    then have "proj1-4XTUPLE-0K17 X \\+\\XBOOLE-0K5 proj1-4XTUPLE-0K17 Y c=TARSKIR1 proj1-4XTUPLE-0K17 (X \\XBOOLE-0K4 Y) \\/XBOOLE-0K2 proj1-4XTUPLE-0K17 (Y \\XBOOLE-0K4 X)"
      using xboole_1_th_13 sorry
    thus "proj1-4XTUPLE-0K17 X \\+\\XBOOLE-0K5 proj1-4XTUPLE-0K17 Y c=TARSKIR1 proj1-4XTUPLE-0K17 (X \\+\\XBOOLE-0K5 Y)"
      using xtuple_0_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_43:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-4XTUPLE-0K18 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 proj2-4XTUPLE-0K18 X \\/XBOOLE-0K2 proj2-4XTUPLE-0K18 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-4XTUPLE-0K18 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj2-4XTUPLE-0K18 X \\/XBOOLE-0K2 proj2-4XTUPLE-0K18 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj2-4XTUPLE-0K18 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj2XTUPLE-0K13 (proj1-3XTUPLE-0K14 X \\/XBOOLE-0K2 proj1-3XTUPLE-0K14 Y)"
      using xtuple_0_th_31 sorry
    also have "... = proj2-4XTUPLE-0K18 X \\/XBOOLE-0K2 proj2-4XTUPLE-0K18 Y"
      using xtuple_0_th_27 sorry
    finally show "proj2-4XTUPLE-0K18 (X \\/XBOOLE-0K2 Y) =HIDDENR1 proj2-4XTUPLE-0K18 X \\/XBOOLE-0K2 proj2-4XTUPLE-0K18 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_44:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-4XTUPLE-0K18 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj2-4XTUPLE-0K18 X)/\\XBOOLE-0K3 (proj2-4XTUPLE-0K18 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-4XTUPLE-0K18 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj2-4XTUPLE-0K18 X)/\\XBOOLE-0K3 (proj2-4XTUPLE-0K18 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj2-4XTUPLE-0K18 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj2-4XTUPLE-0K18 X & proj2-4XTUPLE-0K18 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 proj2-4XTUPLE-0K18 Y"
      using xtuple_0_th_17 xboole_1_th_17 sorry
    thus "proj2-4XTUPLE-0K18 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 (proj2-4XTUPLE-0K18 X)/\\XBOOLE-0K3 (proj2-4XTUPLE-0K18 Y)"
      using xboole_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_45:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-4XTUPLE-0K18 X \\XBOOLE-0K4 proj2-4XTUPLE-0K18 Y c=TARSKIR1 proj2-4XTUPLE-0K18 (X \\XBOOLE-0K4 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-4XTUPLE-0K18 X \\XBOOLE-0K4 proj2-4XTUPLE-0K18 Y c=TARSKIR1 proj2-4XTUPLE-0K18 (X \\XBOOLE-0K4 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 proj2-4XTUPLE-0K18 X \\XBOOLE-0K4 proj2-4XTUPLE-0K18 Y implies x inHIDDENR3 proj2-4XTUPLE-0K18 (X \\XBOOLE-0K4 Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 proj2-4XTUPLE-0K18 X \\XBOOLE-0K4 proj2-4XTUPLE-0K18 Y"
      then have "x inHIDDENR3 proj2-4XTUPLE-0K18 X"
        using xboole_0_def_5 sorry
      then obtain x1 x2 x3 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
        A2: "[XTUPLE-0K7 x1,x,x2,x3 ] inHIDDENR3 X"
        using xtuple_0_th_20 sorry
      have " not x inHIDDENR3 proj2-4XTUPLE-0K18 Y"
        using A1 xboole_0_def_5 sorry
      then have " not [XTUPLE-0K7 x1,x,x2,x3 ] inHIDDENR3 Y"
        using xtuple_0_th_21 sorry
      then have "[XTUPLE-0K7 x1,x,x2,x3 ] inHIDDENR3 X \\XBOOLE-0K4 Y"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 proj2-4XTUPLE-0K18 (X \\XBOOLE-0K4 Y)"
        using xtuple_0_th_21 sorry
    qed "sorry"
    thus "proj2-4XTUPLE-0K18 X \\XBOOLE-0K4 proj2-4XTUPLE-0K18 Y c=TARSKIR1 proj2-4XTUPLE-0K18 (X \\XBOOLE-0K4 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xtuple_0_th_46:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-4XTUPLE-0K18 X \\+\\XBOOLE-0K5 proj2-4XTUPLE-0K18 Y c=TARSKIR1 proj2-4XTUPLE-0K18 (X \\+\\XBOOLE-0K5 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds proj2-4XTUPLE-0K18 X \\+\\XBOOLE-0K5 proj2-4XTUPLE-0K18 Y c=TARSKIR1 proj2-4XTUPLE-0K18 (X \\+\\XBOOLE-0K5 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "proj2-4XTUPLE-0K18 X \\XBOOLE-0K4 proj2-4XTUPLE-0K18 Y c=TARSKIR1 proj2-4XTUPLE-0K18 (X \\XBOOLE-0K4 Y) & proj2-4XTUPLE-0K18 Y \\XBOOLE-0K4 proj2-4XTUPLE-0K18 X c=TARSKIR1 proj2-4XTUPLE-0K18 (Y \\XBOOLE-0K4 X)"
      using xtuple_0_th_45 sorry
    then have "proj2-4XTUPLE-0K18 X \\+\\XBOOLE-0K5 proj2-4XTUPLE-0K18 Y c=TARSKIR1 proj2-4XTUPLE-0K18 (X \\XBOOLE-0K4 Y) \\/XBOOLE-0K2 proj2-4XTUPLE-0K18 (Y \\XBOOLE-0K4 X)"
      using xboole_1_th_13 sorry
    thus "proj2-4XTUPLE-0K18 X \\+\\XBOOLE-0K5 proj2-4XTUPLE-0K18 Y c=TARSKIR1 proj2-4XTUPLE-0K18 (X \\+\\XBOOLE-0K5 Y)"
      using xtuple_0_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
