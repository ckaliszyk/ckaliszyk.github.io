theory sin_cos
  imports nat_d comseq_3 fdiff_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve q, th, r for "RealXREAL-0M1"
reserve a, b, p for "RealXREAL-0M1"
reserve w, z for "ComplexXCMPLX-0M1"
reserve k, l, m, n, n1, n2 for "NatNAT-1M1"
reserve seq, seq1, seq2, cq1 for "Complex-SequenceCOMSEQ-1M1"
reserve rseq, rseq1, rseq2 for "Real-SequenceSEQ-1M1"
reserve hy1 for "0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
mdef sin_cos_def_1 ("CHKSIN-COSK1'( _ , _ ')" [0,0]164 ) where
  mlet "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"func CHKSIN-COSK1(m,k) \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  \<one>\<^sub>M if m <=XXREAL-0R1 k otherwise 0NUMBERSK6"
proof-
  (*coherence*)
    show "(m <=XXREAL-0R1 k implies \<one>\<^sub>M be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) & ( not m <=XXREAL-0R1 k implies 0NUMBERSK6 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)"
    proof-
      have "( not (m <=XXREAL-0R1 k &  not \<one>\<^sub>M be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) &  not ( not m <=XXREAL-0R1 k &  not 0NUMBERSK6 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)) & ( for VarFor1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  True )"
      proof-
        have "0cCOMPLEX1K6 =COMPLEX1R1 0NUMBERSK6"
           sorry
        thus "( not (m <=XXREAL-0R1 k &  not \<one>\<^sub>M be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) &  not ( not m <=XXREAL-0R1 k &  not 0NUMBERSK6 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)) & ( for VarFor1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  True )"
          using complex1_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  True "
    proof-
      have "( not (m <=XXREAL-0R1 k &  not \<one>\<^sub>M be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) &  not ( not m <=XXREAL-0R1 k &  not 0NUMBERSK6 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)) & ( for VarFor1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  True )"
      proof-
        have "0cCOMPLEX1K6 =COMPLEX1R1 0NUMBERSK6"
           sorry
        thus "( not (m <=XXREAL-0R1 k &  not \<one>\<^sub>M be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) &  not ( not m <=XXREAL-0R1 k &  not 0NUMBERSK6 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)) & ( for VarFor1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  True )"
          using complex1_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem sin_cos_cl_1:
  mlet "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster CHKSIN-COSK1(m,k) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "CHKSIN-COSK1(m,k) be realXREAL-0V1"
    using sin_cos_def_1 sorry
qed "sorry"

theorem sin_cos_sch_1:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be NatNAT-1M1 \<Longrightarrow> Ff2(x1,x2) be ComplexXCMPLX-0M1"
  shows " for k be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds (n <=XXREAL-0R1 k implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff2(k,n)) & (n >XXREAL-0R4 k implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
  proof-
    have " for k be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds  not (n <=XXREAL-0R1 k &  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff2(k,n)) &  not ( not n >XXREAL-0R4 k &  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
    proof(rule ballI)
      fix k assume [ty]: "k be NatNAT-1M1"
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be NatNAT-1M1 st (n =HIDDENR1 Lamb1 & (n <=XXREAL-0R1 k implies Lamb2 =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies Lamb2 =HIDDENR1 0cCOMPLEX1K6)"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st  ex n be NatNAT-1M1 st (n =HIDDENR1 x & (n <=XXREAL-0R1 k implies y =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies y =HIDDENR1 0cCOMPLEX1K6))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A2: "n =HIDDENR1 x"
           sorry
        have A3: "n <=XXREAL-0R1 k implies (CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 Ff2(k,n)"
        proof(rule impI)
          assume "n <=XXREAL-0R1 k"
          then have "(CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 Ff2(k,n)"
            using sin_cos_def_1 sorry
          also have "... = Ff2(k,n)"
             sorry
          finally show "(CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 Ff2(k,n)"
             sorry
        qed
        have A4: "n >XXREAL-0R4 k implies (CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 0NUMBERSK6"
        proof(rule impI)
          assume "n >XXREAL-0R4 k"
          then have "(CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 Ff2(k,n)"
            using sin_cos_def_1 sorry
          also have "... = 0NUMBERSK6"
             sorry
          finally show "(CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 0NUMBERSK6"
             sorry
        qed
        obtain y where 
          [ty]:"y be objectHIDDENM1" and yDef:"y = (CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n)"
           sorry
        show " ex y be objectHIDDENM1 st  ex n be NatNAT-1M1 st (n =HIDDENR1 x & (n <=XXREAL-0R1 k implies y =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies y =HIDDENR1 0cCOMPLEX1K6)"
        proof(rule bexI[of _ "y"])
          show " ex n be NatNAT-1M1 st (n =HIDDENR1 x & (n <=XXREAL-0R1 k implies y =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies y =HIDDENR1 0cCOMPLEX1K6)"
            using A2 A3 A4 sorry
        qed "sorry"
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A5: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,f .FUNCT-1K1 x)"
        using classes1_sch_1 A1 sorry
      have " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 NATNUMBERSK1"
        then have " ex n be NatNAT-1M1 st (n =XBOOLE-0R4 x & (n <=XXREAL-0R1 k implies f .FUNCT-1K1 x =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies f .FUNCT-1K1 x =XBOOLE-0R4 0cCOMPLEX1K6)"
          using A6 sorry
        thus "f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
      qed "sorry"
      then have 
        [ty]:"f be Complex-SequenceCOMSEQ-1M1"
        using A5 comseq_1_th_1 sorry
      obtain seq where 
        [ty]:"seq be Complex-SequenceCOMSEQ-1M1" and seqDef:"seq = f"
         sorry
      show " ex seq be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds  not (n <=XXREAL-0R1 k &  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff2(k,n)) &  not ( not n >XXREAL-0R4 k &  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
      proof(rule bexI[of _ "seq"],rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "?P(n,f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
          using A6 sorry
        then have " ex l be NatNAT-1M1 st (l =COMPLEX1R1 n & (l <=XXREAL-0R1 k implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff2(k,l))) & (l >XXREAL-0R4 k implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6)"
           sorry
        thus " not (n <=XXREAL-0R1 k &  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff2(k,n)) &  not ( not n >XXREAL-0R4 k &  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
           sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem sin_cos_sch_2:
  fixes Ff2 
  assumes
[ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be NatNAT-1M1 \<Longrightarrow> Ff2(x1,x2) be RealXREAL-0M1"
  shows " for k be NatNAT-1M1 holds  ex rseq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds (n <=XXREAL-0R1 k implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff2(k,n)) & (n >XXREAL-0R4 k implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
  proof-
    have " for k be NatNAT-1M1 holds  ex rseq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds  not (n <=XXREAL-0R1 k &  not rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff2(k,n)) &  not ( not n >XXREAL-0R4 k &  not rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
    proof(rule ballI)
      fix k assume [ty]: "k be NatNAT-1M1"
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be NatNAT-1M1 st (n =HIDDENR1 Lamb1 & (n <=XXREAL-0R1 k implies Lamb2 =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies Lamb2 =HIDDENR1 0NUMBERSK6)"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st  ex n be NatNAT-1M1 st (n =HIDDENR1 x & (n <=XXREAL-0R1 k implies y =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies y =HIDDENR1 0NUMBERSK6))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A2: "n =HIDDENR1 x"
           sorry
        have A3: "n <=XXREAL-0R1 k implies (CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 Ff2(k,n)"
        proof(rule impI)
          assume "n <=XXREAL-0R1 k"
          then have "(CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 Ff2(k,n)"
            using sin_cos_def_1 sorry
          also have "... = Ff2(k,n)"
             sorry
          finally show "(CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 Ff2(k,n)"
             sorry
        qed
        have A4: "n >XXREAL-0R4 k implies (CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 0NUMBERSK6"
        proof(rule impI)
          assume "n >XXREAL-0R4 k"
          then have "(CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 Ff2(k,n)"
            using sin_cos_def_1 sorry
          also have "... = 0NUMBERSK6"
             sorry
          finally show "(CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n) =HIDDENR1 0NUMBERSK6"
             sorry
        qed
        obtain y where 
          [ty]:"y be objectHIDDENM1" and yDef:"y = (CHKSIN-COSK1(n,k))*XCMPLX-0K3 Ff2(k,n)"
           sorry
        show " ex y be objectHIDDENM1 st  ex n be NatNAT-1M1 st (n =HIDDENR1 x & (n <=XXREAL-0R1 k implies y =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies y =HIDDENR1 0NUMBERSK6)"
        proof(rule bexI[of _ "y"])
          show " ex n be NatNAT-1M1 st (n =HIDDENR1 x & (n <=XXREAL-0R1 k implies y =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies y =HIDDENR1 0NUMBERSK6)"
            using A2 A3 A4 sorry
        qed "sorry"
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A5: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,f .FUNCT-1K1 x)"
        using classes1_sch_1 A1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then have " ex n be NatNAT-1M1 st (n =HIDDENR1 x & (n <=XXREAL-0R1 k implies f .FUNCT-1K1 x =HIDDENR1 Ff2(k,n))) & (n >XXREAL-0R4 k implies f .FUNCT-1K1 x =XBOOLE-0R4 0NUMBERSK6)"
          using A6 sorry
        thus "f .FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      then have 
        [ty]:"f be Real-SequenceSEQ-1M1"
        using A5 seq_1_th_1 sorry
      obtain rseq where 
        [ty]:"rseq be Real-SequenceSEQ-1M1" and rseqDef:"rseq = f"
         sorry
      show " ex rseq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds  not (n <=XXREAL-0R1 k &  not rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff2(k,n)) &  not ( not n >XXREAL-0R4 k &  not rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
      proof(rule bexI[of _ "rseq"],rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have " ex l be NatNAT-1M1 st (l =COMPLEX1R1 n & (l <=XXREAL-0R1 k implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff2(k,l))) & (l >XXREAL-0R4 k implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
          using A6 sorry
        thus " not (n <=XXREAL-0R1 k &  not rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff2(k,n)) &  not ( not n >XXREAL-0R4 k &  not rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6)"
           sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

mlemma sin_cos_lm_1:
"\<one>\<^sub>M inTARSKIR2 NATNUMBERSK1"
   sorry

mdef sin_cos_def_2 ("Prod-real-nSIN-COSK2" 164 ) where
"func Prod-real-nSIN-COSK2 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it. it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have " ex tVar5 be Real-SequenceSEQ-1M1 st tVar5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds tVar5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 tVar5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10(Lamb2 *XCMPLX-0K3 (Lamb1 +NAT-1K1 \<one>\<^sub>M),REALNUMBERSK2)"
        obtain jj where 
          [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
          using sin_cos_lm_1 numbers_th_19 sorry
        obtain f where
          [ty]:"f be sequenceNAT-1M2-of REALNUMBERSK2" and 
          A1: "f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 jj"and A2: " for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ?U(n,f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using nat_1_sch_12 sorry
        show " ex tVar5 be Real-SequenceSEQ-1M1 st tVar5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds tVar5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 tVar5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI)
          show "f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
            using A1 sorry
          fix n assume [ty]: "n be NatNAT-1M1"
          have "f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 InSUBSET-1K10(f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M),REALNUMBERSK2)"
            using A2 sorry
          also have "... = f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
             sorry
          finally show "f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds (it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))) & (it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
    proof-
      have " for rseq1 be Real-SequenceSEQ-1M1 holds  for rseq2 be Real-SequenceSEQ-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & (( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)) & (rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)))) implies rseq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> rseq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
        fix rseq2 assume [ty]: "rseq2 be Real-SequenceSEQ-1M1"
        assume A3: "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
          and A4: " for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
          and A5: "rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
          and A6: " for n be NatNAT-1M1 holds rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
        let ?X = "\<lambda>Lamb1. rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
        have A7: "?X(0NUMBERSK6)"
          using A3 A5 sorry
        have A8: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for k be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            then have "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)"
              using A4 sorry
            also have "... = rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              using A6 sorry
            finally show "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " for n be NatNAT-1M1 holds ?X(n)"
          using nat_1_sch_2 A7 A8 sorry
        thus "rseq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> rseq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

abbreviation(input) SIN_COSK3(" _ !SIN-COSK3" [164]164) where
  "n !SIN-COSK3 \<equiv> n !NEWTONK2"

mtheorem sin_cos_def_3:
  mlet "n be NatNAT-1M1"
"redefine func n !SIN-COSK3 \<rightarrow> setHIDDENM2 equals
  (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 n !SIN-COSK3 iff it =HIDDENR1 (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof-
    have " for VarFor1 be setHIDDENM2 holds  not (VarFor1 =HIDDENR1 n !NEWTONK2 &  not VarFor1 =HIDDENR1 (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) &  not (VarFor1 =HIDDENR1 (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n &  not VarFor1 =HIDDENR1 n !NEWTONK2)"
    proof-
      let ?X = "\<lambda>Lamb1. (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 Lamb1 !NEWTONK7"
      have A1: "?X(0NUMBERSK6)"
        using sin_cos_def_2 newton_th_12 sorry
      have A2: " for l be NatNAT-1M1 holds (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l =COMPLEX1R1 l !NEWTONK7 implies (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
      proof(rule ballI,rule impI)
        fix l assume [ty]: "l be NatNAT-1M1"
        assume A3: "?X(l)"
        have "(Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 (l +NAT-1K1 \<one>\<^sub>M)"
          using sin_cos_def_2 sorry
        also have "... = (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
          using A3 newton_th_15 sorry
        finally have "(Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
           sorry
        thus "(Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
           sorry
      qed "sorry"
      have " for k be NatNAT-1M1 holds ?X(k)"
        using nat_1_sch_2 A1 A2 sorry
      thus " for VarFor1 be setHIDDENM2 holds  not (VarFor1 =HIDDENR1 n !NEWTONK2 &  not VarFor1 =HIDDENR1 (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) &  not (VarFor1 =HIDDENR1 (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n &  not VarFor1 =HIDDENR1 n !NEWTONK2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef sin_cos_def_4 (" _ ExpSeqSIN-COSK4" [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z ExpSeqSIN-COSK4 \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
    proof-
      let ?U = "\<lambda>Lamb1. z  |^COMSEQ-3K2 Lamb1 /XCMPLX-0K7 (Lamb1 !SIN-COSK3)"
      show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
      proof-
        have " ex s be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
        proof-
          show " ex s be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
            using comseq_1_sch_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) implies it1 =HIDDENR1 it2"
    proof-
      let ?U = "\<lambda>Lamb1. z  |^COMSEQ-3K2 Lamb1 /XCMPLX-0K7 (Lamb1 !SIN-COSK3)"
      show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) implies it1 =HIDDENR1 it2"
      proof-
        have " for s1 be Complex-SequenceCOMSEQ-1M1 holds  for s2 be Complex-SequenceCOMSEQ-1M1 holds ( for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 z  |^COMSEQ-3K2 x /XCMPLX-0K7 (x !SIN-COSK3)) & ( for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 z  |^COMSEQ-3K2 x /XCMPLX-0K7 (x !SIN-COSK3)) implies s1 =HIDDENR1 s2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
          fix s2 assume [ty]: "s2 be Complex-SequenceCOMSEQ-1M1"
          assume A1: " for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 ?U(x)"
            and A2: " for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 ?U(x)"
          have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
          proof(rule ballI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 z  |^COMSEQ-3K2 x /XCMPLX-0K7 (x !SIN-COSK3)"
              using A1 sorry
            also have "... = s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
              using A2 sorry
            finally show "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
               sorry
          qed "sorry"
          thus "s1 =HIDDENR1 s2"
            using funct_2_def_8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef sin_cos_def_5 (" _ rExpSeqSIN-COSK5" [164]164 ) where
  mlet "a be RealXREAL-0M1"
"func a rExpSeqSIN-COSK5 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
    proof-
      let ?U = "\<lambda>Lamb1. a  |^COMSEQ-3K2 Lamb1 /XCMPLX-0K7 (Lamb1 !SIN-COSK3)"
      show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
      proof-
        have " ex s be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
        proof-
          show " ex s be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
            using seq_1_sch_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) implies it1 =HIDDENR1 it2"
    proof-
      let ?U = "\<lambda>Lamb1. a  |^COMSEQ-3K2 Lamb1 /XCMPLX-0K7 (Lamb1 !SIN-COSK3)"
      show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 a  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)) implies it1 =HIDDENR1 it2"
      proof-
        have " for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 a  |^COMSEQ-3K2 x /XCMPLX-0K7 (x !SIN-COSK3)) & ( for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 a  |^COMSEQ-3K2 x /XCMPLX-0K7 (x !SIN-COSK3)) implies s1 =HIDDENR1 s2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
          fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
          assume A1: " for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
            and A2: " for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
          have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
          proof(rule ballI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 a  |^COMSEQ-3K2 x /XCMPLX-0K7 (x !SIN-COSK3)"
              using A1 sorry
            also have "... = s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
              using A2 sorry
            finally show "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
               sorry
          qed "sorry"
          thus "s1 =HIDDENR1 s2"
            using funct_2_def_8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem sin_cos_th_1:
" for n be NatNAT-1M1 holds ((0NUMBERSK6)!SIN-COSK3 =COMPLEX1R1 \<one>\<^sub>M & n !SIN-COSK3 <>HIDDENR2 0NUMBERSK6) & (n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3 =COMPLEX1R1 (n !SIN-COSK3)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
  using sin_cos_def_2 sorry

mtheorem sin_cos_th_2:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (0NUMBERSK6 <XXREAL-0R3 k implies ((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 k =COMPLEX1R1 k !SIN-COSK3) & (k <=XXREAL-0R1 m implies ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 ((m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k) =COMPLEX1R1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3)"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 k &  not ((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 k =COMPLEX1R1 k !SIN-COSK3) &  not (k <=XXREAL-0R1 m &  not ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 ((m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k) =COMPLEX1R1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3)"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    have A1: " for k be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 k implies k !SIN-COSK3 =COMPLEX1R1 ((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "0NUMBERSK6 <XXREAL-0R3 k"
      then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
        using int_1_th_7 sorry
      then have "(k -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (k -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_233 sorry
      also have "... = k"
         sorry
      finally have "(k -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 k"
         sorry
      thus "k !SIN-COSK3 =COMPLEX1R1 ((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 k"
        using sin_cos_th_1 sorry
    qed "sorry"
    have " for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds k <=XXREAL-0R1 m implies ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3 =HIDDENR1 ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 ((m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)"
    proof(rule ballI,rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A2: "k <=XXREAL-0R1 m"
      have "m <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_29 sorry
      then have "(m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k =HIDDENR1 (m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k"
        using A2 xreal_1_th_233 xxreal_0_th_2 sorry
      also have "... = (m -XCMPLX-0K6 k)+XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      also have "... = (m -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M"
        using A2 xreal_1_th_233 sorry
      finally have "(m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k =HIDDENR1 (m -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M"
         sorry
      then have "((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3 =HIDDENR1 ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 (((m -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
        using sin_cos_th_1 sorry
      also have "... = ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 (((m -XCMPLX-0K6 k)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
        using A2 xreal_1_th_233 sorry
      also have "... = ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 ((m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)"
         sorry
      finally show "((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3 =HIDDENR1 ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 ((m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)"
         sorry
    qed "sorry"
    thus " not ( not 0NUMBERSK6 <XXREAL-0R3 k &  not ((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 k =COMPLEX1R1 k !SIN-COSK3) &  not (k <=XXREAL-0R1 m &  not ((m -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 ((m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k) =COMPLEX1R1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef sin_cos_def_6 ("CoefSIN-COSK6  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func CoefSIN-COSK6 n \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
    proof-
      have " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) &  not ( not k >XXREAL-0R4 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 !SIN-COSK3)/XCMPLX-0K7 ((Lamb2 !SIN-COSK3)*XCMPLX-0K3 ((Lamb1 -'NAT-DK9 Lamb2)!SIN-COSK3))"
        have " for n be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ?U(n,k)) & (k >XXREAL-0R4 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          using sin_cos_sch_1 sorry
        thus " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) &  not ( not k >XXREAL-0R4 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
        fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
        assume A1: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          and A2: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          proof-
            have cases: "k <=XXREAL-0R1 n or k >XXREAL-0R4 n"
               sorry
            have case1: "k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A3: "k <=XXREAL-0R1 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A3 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            have case2: "k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A4: "k >XXREAL-0R4 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 0cCOMPLEX1K6"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A4 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_7 ("Coef-eSIN-COSK7  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func Coef-eSIN-COSK7 n \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
    proof-
      have " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) &  not ( not k >XXREAL-0R4 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. 1rCOMPLEX1K7 /XCMPLX-0K7 ((Lamb2 !SIN-COSK3)*XCMPLX-0K3 ((Lamb1 -'NAT-DK9 Lamb2)!SIN-COSK3))"
        have " for n be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ?U(n,k)) & (k >XXREAL-0R4 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          using sin_cos_sch_1 sorry
        thus " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) &  not ( not k >XXREAL-0R4 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
        fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
        assume A1: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          and A2: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          proof-
            have cases: "k <=XXREAL-0R1 n or k >XXREAL-0R4 n"
               sorry
            have case1: "k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A3: "k <=XXREAL-0R1 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A3 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            have case2: "k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A4: "k >XXREAL-0R4 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 0cCOMPLEX1K6"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A4 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_8 ("ShiftSIN-COSK8  _ " [164]164 ) where
  mlet "seq be Complex-SequenceCOMSEQ-1M1"
"func ShiftSIN-COSK8 seq \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it. it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
    proof-
      have " ex tVar6 be Complex-SequenceCOMSEQ-1M1 st tVar6 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds tVar6 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
        obtain f where
          [ty]:"f be sequenceNAT-1M2-of COMPLEXNUMBERSK3" and 
          A1: "f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0cCOMPLEX1K6 & ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ?U(n,f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
          using nat_1_sch_12 sorry
        show " ex tVar6 be Complex-SequenceCOMSEQ-1M1 st tVar6 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds tVar6 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
        proof(rule bexI[of _ "f"])
          show "f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds (it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)) & (it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for k be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & (( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) & (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & ( for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))) implies seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
        fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
        assume A2: "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
          and A3: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          and A4: "seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
          and A5: " for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        let ?X = "\<lambda>Lamb1. seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
        have A6: "?X(0NUMBERSK6)"
          using A2 A4 sorry
        have A7: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for k be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
              using A3 sorry
            also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              using A5 sorry
            finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " for n be NatNAT-1M1 holds ?X(n)"
          using nat_1_sch_2 A6 A7 sorry
        thus "seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_9 ("ExpanSIN-COSK9'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "z be ComplexXCMPLX-0M1", "w be ComplexXCMPLX-0M1"
"func ExpanSIN-COSK9(n,z,w) \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
    proof-
      have " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. ((CoefSIN-COSK6 Lamb1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb2 *XCMPLX-0K3 z  |^COMSEQ-3K2 Lamb2)*XCMPLX-0K3 w  |^COMSEQ-3K2 (Lamb1 -'NAT-DK9 Lamb2)"
        have " for n be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ?U(n,k)) & (k >XXREAL-0R4 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          using sin_cos_sch_1 sorry
        thus " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
        fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
        assume A1: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          and A2: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          proof-
            have cases: "k <=XXREAL-0R1 n or k >XXREAL-0R4 n"
               sorry
            have case1: "k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A3: "k <=XXREAL-0R1 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A3 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            have case2: "k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A4: "k >XXREAL-0R4 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 0cCOMPLEX1K6"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A4 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_10 ("Expan-eSIN-COSK10'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "z be ComplexXCMPLX-0M1", "w be ComplexXCMPLX-0M1"
"func Expan-eSIN-COSK10(n,z,w) \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
    proof-
      have " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. ((Coef-eSIN-COSK7 Lamb1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb2 *XCMPLX-0K3 z  |^COMSEQ-3K2 Lamb2)*XCMPLX-0K3 w  |^COMSEQ-3K2 (Lamb1 -'NAT-DK9 Lamb2)"
        have " for n be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ?U(n,k)) & (k >XXREAL-0R4 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          using sin_cos_sch_1 sorry
        thus " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
        fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
        assume A1: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          and A2: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          proof-
            have cases: "k <=XXREAL-0R1 n or k >XXREAL-0R4 n"
               sorry
            have case1: "k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A3: "k <=XXREAL-0R1 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A3 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            have case2: "k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A4: "k >XXREAL-0R4 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 0cCOMPLEX1K6"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A4 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_11 ("AlfaSIN-COSK11'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "z be ComplexXCMPLX-0M1", "w be ComplexXCMPLX-0M1"
"func AlfaSIN-COSK11(n,z,w) \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
    proof-
      have " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb2 *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (Lamb1 -'NAT-DK9 Lamb2)"
        have " for n be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ?U(n,k)) & (k >XXREAL-0R4 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          using sin_cos_sch_1 sorry
        thus " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
        fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
        assume A1: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          and A2: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          proof-
            have cases: "k <=XXREAL-0R1 n or k >XXREAL-0R4 n"
               sorry
            have case1: "k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A3: "k <=XXREAL-0R1 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k)"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A3 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            have case2: "k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A4: "k >XXREAL-0R4 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 0cCOMPLEX1K6"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A4 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_12 ("ConjSIN-COSK12'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "n be NatNAT-1M1"
"func ConjSIN-COSK12(n,a,b) \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
    proof-
      have " not ( for VarFor1 be Real-SequenceSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb2 *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Lamb1 -'NAT-DK9 Lamb2))"
        have " for n be NatNAT-1M1 holds  ex rseq be Real-SequenceSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 ?U(n,k)) & (k >XXREAL-0R4 n implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          using sin_cos_sch_2 sorry
        thus " not ( for VarFor1 be Real-SequenceSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
    proof-
      have " for rseq1 be Real-SequenceSEQ-1M1 holds  for rseq2 be Real-SequenceSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (k >XXREAL-0R4 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (k >XXREAL-0R4 n implies rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies rseq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> rseq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
        fix rseq2 assume [ty]: "rseq2 be Real-SequenceSEQ-1M1"
        assume A1: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (k >XXREAL-0R4 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          and A2: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))) & (k >XXREAL-0R4 n implies rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          show "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          proof-
            have cases: "k <=XXREAL-0R1 n or k >XXREAL-0R4 n"
               sorry
            have case1: "k <=XXREAL-0R1 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            proof(rule impI)
              assume A3: "k <=XXREAL-0R1 n"
              then have "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 (a rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *REAL-1K4 (Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 (b rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n -'NAT-DK9 k))"
                using A1 sorry
              also have "... = rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
                using A2 A3 sorry
              finally show "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
                 sorry
            qed
            have case2: "k >XXREAL-0R4 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            proof(rule impI)
              assume A4: "k >XXREAL-0R4 n"
              then have "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 0NUMBERSK6"
                using A1 sorry
              also have "... = rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
                using A2 A4 sorry
              finally show "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "rseq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> rseq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_13 ("ConjSIN-COSK13'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "z be ComplexXCMPLX-0M1", "w be ComplexXCMPLX-0M1", "n be NatNAT-1M1"
"func ConjSIN-COSK13(n,z,w) \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
    proof-
      have " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb2 *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (Lamb1 -'NAT-DK9 Lamb2))"
        have " for n be NatNAT-1M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ?U(n,k)) & (k >XXREAL-0R4 n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          using sin_cos_sch_1 sorry
        thus " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k <=XXREAL-0R1 n &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) &  not ( not n <XXREAL-0R3 k &  not VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (n <XXREAL-0R3 k implies it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)) implies seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
        fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
        assume A1: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
          and A2: " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))) & (k >XXREAL-0R4 n implies seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 0NUMBERSK6)"
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          proof-
            have cases: "k <=XXREAL-0R1 n or k >XXREAL-0R4 n"
               sorry
            have case1: "k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A3: "k <=XXREAL-0R1 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n -'NAT-DK9 k))"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A3 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            have case2: "k >XXREAL-0R4 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A4: "k >XXREAL-0R4 n"
              then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 0cCOMPLEX1K6"
                using A1 sorry
              also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A2 A4 sorry
              finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "seq1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma sin_cos_lm_2:
" for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds  for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds (p1 +XCMPLX-0K2 g1 *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (p1 *XCMPLX-0K3 p2 -XCMPLX-0K6 g1 *XCMPLX-0K3 g2)+XCMPLX-0K2 (p1 *XCMPLX-0K3 g2 +XCMPLX-0K2 p2 *XCMPLX-0K3 g1)*XCMPLX-0K3 (<i>COMPLEX1K8) & (p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9 =COMPLEX1R1 p2 +XCMPLX-0K2 (-XCMPLX-0K4 g2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for p1 be RealXREAL-0M1 holds  for p2 be RealXREAL-0M1 holds  for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds (p1 +XCMPLX-0K2 g1 *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (p1 *XCMPLX-0K3 p2 -XCMPLX-0K6 g1 *XCMPLX-0K3 g2)+XCMPLX-0K2 (p1 *XCMPLX-0K3 g2 +XCMPLX-0K2 p2 *XCMPLX-0K3 g1)*XCMPLX-0K3 (<i>COMPLEX1K8) & (p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9 =HIDDENR1 p2 +XCMPLX-0K2 (-XCMPLX-0K4 g2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix p1 assume [ty]: "p1 be RealXREAL-0M1"
    fix p2 assume [ty]: "p2 be RealXREAL-0M1"
    fix g1 assume [ty]: "g1 be RealXREAL-0M1"
    fix g2 assume [ty]: "g2 be RealXREAL-0M1"
    show "(p1 +XCMPLX-0K2 g1 *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (p1 *XCMPLX-0K3 p2 -XCMPLX-0K6 g1 *XCMPLX-0K3 g2)+XCMPLX-0K2 (p1 *XCMPLX-0K3 g2 +XCMPLX-0K2 p2 *XCMPLX-0K3 g1)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    have "(p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9 =HIDDENR1 p2 -XCMPLX-0K6 ImCOMPLEX1K4 (p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8)) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = p2 -XCMPLX-0K6 g2 *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = p2 +XCMPLX-0K2 (-XCMPLX-0K4 g2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally show "(p2 +XCMPLX-0K2 g2 *XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9 =HIDDENR1 p2 +XCMPLX-0K2 (-XCMPLX-0K4 g2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_3:
" for n be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) & (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M) &  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
proof-
  have " for n be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) & (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M) &  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: " for n be NatNAT-1M1 holds (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using sin_cos_def_4 sorry
      also have "... = (z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using comseq_3_def_1 sorry
      also have "... = (z  |^COMSEQ-3K2 n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n !SIN-COSK3)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
        using sin_cos_th_1 sorry
      also have "... = (z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (z /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
        using xcmplx_1_th_76 sorry
      also have "... = ((z  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
         sorry
      also have "... = ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
        using sin_cos_def_4 sorry
      finally show "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
         sorry
    qed "sorry"
    have A2: "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 z  |^COMSEQ-3K2 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
      using sin_cos_def_4 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_1 comseq_3_def_1 sorry
    finally have "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    let ?X = "\<lambda>Lamb1.  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1.| =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
    have "(( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
      using sin_cos_def_5 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 (Prod-real-nSIN-COSK2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using newton_th_4 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"
      using sin_cos_def_2 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally have "(( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
      using A2 complex1_th_48 sorry
    have A4: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M).| =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A5: "?X(n)"
      have A6: " |.COMPLEX1K10 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .| =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
        using absvalue_def_1 sorry
      have " |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M).| =HIDDENR1  |.COMPLEX1K10 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) .|"
        using A1 sorry
      also have "... = ( |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z .|)/XCMPLX-0K7 ( |.COMPLEX1K10 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)"
        using complex1_th_67 sorry
      also have "... = ((( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 z.|))/XCMPLX-0K7 ( |.COMPLEX1K10 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)"
        using A5 complex1_th_65 sorry
      also have "... = ((( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 ( |.COMPLEX1K10 z.|))/XCMPLX-0K7 ( |.COMPLEX1K10 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)"
        using sin_cos_def_5 sorry
      also have "... = (( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n *XCMPLX-0K3 ( |.COMPLEX1K10 z.|))/XCMPLX-0K7 ((n !SIN-COSK3)*XCMPLX-0K3 ( |.COMPLEX1K10 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|))"
        using xcmplx_1_th_83 sorry
      also have "... = (( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n *XCMPLX-0K3 ( |.COMPLEX1K10 z.|))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using A6 newton_th_15 sorry
      also have "... = ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using newton_th_6 sorry
      also have "... = (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using sin_cos_def_5 sorry
      finally have " |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M).| =HIDDENR1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus " |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M).| =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A4 sorry
    thus "((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) & (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M) &  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_4:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds 0NUMBERSK6 <XXREAL-0R3 k implies (ShiftSIN-COSK8 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds 0NUMBERSK6 <XXREAL-0R3 k implies (ShiftSIN-COSK8 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 k"
    have A2: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
      using int_1_th_7 A1 sorry
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "m +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 k"
      using A1 nat_1_th_6 sorry
    have A4: "m =COMPLEX1R1 k -XCMPLX-0K6 \<one>\<^sub>M"
      using A3 sorry
    have "(ShiftSIN-COSK8 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m"
      using A3 sin_cos_def_8 sorry
    also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
      using A2 A4 xreal_1_th_233 sorry
    finally show "(ShiftSIN-COSK8 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_5:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
    have "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 0cCOMPLEX1K6 +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (ShiftSIN-COSK8 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using sin_cos_def_8 sorry
    also have "... = Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    finally have "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
       sorry
    then have A1: "?X(0NUMBERSK6)"
       sorry
    have A2: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k implies Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        have "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)+XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A3 series_1_def_1 sorry
        also have "... = (Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (ShiftSIN-COSK8 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using sin_cos_def_8 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        finally show "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds ?X(k)"
      using nat_1_sch_2 A1 A2 sorry
    thus "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_6:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds (z +XCMPLX-0K2 w) |^COMSEQ-3K2 n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds (z +XCMPLX-0K2 w) |^COMSEQ-3K2 n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "0NUMBERSK6 -'NAT-DK9 0NUMBERSK6 =COMPLEX1R1 0NUMBERSK6"
      using xreal_1_th_232 sorry
    let ?X = "\<lambda>Lamb1. (z +XCMPLX-0K2 w) |^COMSEQ-3K2 Lamb1 =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(Lamb1,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
    have "Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(0NUMBERSK6,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 (ExpanSIN-COSK9(0NUMBERSK6,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = ((CoefSIN-COSK6 (0NUMBERSK6)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z  |^COMSEQ-3K2 (0NUMBERSK6))*XCMPLX-0K3 w  |^COMSEQ-3K2 (0NUMBERSK6)"
      using A1 sin_cos_def_9 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M))*XCMPLX-0K3 z  |^COMSEQ-3K2 (0NUMBERSK6))*XCMPLX-0K3 w  |^COMSEQ-3K2 (0NUMBERSK6)"
      using A1 sin_cos_def_6 sin_cos_th_1 sorry
    also have "... = 1rCOMPLEX1K7 *XCMPLX-0K3 w GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using comseq_3_def_1 sorry
    also have "... = 1rCOMPLEX1K7"
      using comseq_3_def_1 sorry
    finally have "Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(0NUMBERSK6,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 1rCOMPLEX1K7"
       sorry
    then have A2: "?X(0NUMBERSK6)"
      using comseq_3_def_1 sorry
    have A3: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds (z +XCMPLX-0K2 w) |^COMSEQ-3K2 n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies (z +XCMPLX-0K2 w) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        have A5: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A6: "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (z +XCMPLX-0K2 w)GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (z +XCMPLX-0K2 w)"
          using comseq_3_def_1 sorry
        also have "... = ((z +XCMPLX-0K2 w)(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using A4 valued_1_th_6 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using comseq_3_th_29 sorry
        finally have "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
           sorry
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((z +XCMPLX-0K2 w)(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "((z +XCMPLX-0K2 w)(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (z +XCMPLX-0K2 w)*XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            using valued_1_th_6 sorry
          also have "... = z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
             sorry
          also have "... = (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            using valued_1_th_6 sorry
          also have "... = (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            using valued_1_th_6 sorry
          also have "... = (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            using valued_1_th_1 sorry
          finally show "((z +XCMPLX-0K2 w)(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
             sorry
        qed "sorry"
        then have "(z +XCMPLX-0K2 w)(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))"
           sorry
        then have A7: "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using A6 comseq_3_th_27 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using valued_1_th_1 A5 sorry
        finally have "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
           sorry
        have A8: "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using valued_1_th_6 sorry
        finally have "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        have "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_29 sorry
        then have A9: "(ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0cCOMPLEX1K6"
          using sin_cos_def_9 sorry
        have A10: "Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using valued_1_th_6 sorry
        finally have "Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        have A11: "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using sin_cos_th_5 sorry
        have "0NUMBERSK6 +XCMPLX-0K2 n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_29 sorry
        then have "(ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0cCOMPLEX1K6"
          using sin_cos_def_9 sorry
        then have "z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0cCOMPLEX1K6"
           sorry
        then have A12: "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 0cCOMPLEX1K6"
          using A11 valued_1_th_6 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        finally have "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        proof(rule ballI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          have A13: "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 k implies (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          proof(rule impI)
            assume A14: "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 k"
            have A15: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_6 sorry
            have A16: "(n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 k -XCMPLX-0K6 \<one>\<^sub>M"
              using A14 xreal_1_th_9 sorry
            then have A17: "n +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 (k -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
              using xreal_1_th_8 sorry
            have A18: "k -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 k -'NAT-DK9 \<one>\<^sub>M"
              using A14 A15 xreal_1_th_233 xxreal_0_th_2 sorry
            have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
              using valued_1_th_1 sorry
            also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
              using valued_1_th_6 sorry
            also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
              using A17 sin_cos_th_4 sorry
            also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
              using valued_1_th_6 sorry
            also have "... = w *XCMPLX-0K3 0cCOMPLEX1K6 +XCMPLX-0K2 z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
              using A17 sin_cos_def_9 sorry
            also have "... = 0cCOMPLEX1K6 +XCMPLX-0K2 z *XCMPLX-0K3 0cCOMPLEX1K6"
              using A16 A18 sin_cos_def_9 sorry
            also have "... = 0cCOMPLEX1K6"
               sorry
            finally have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 0cCOMPLEX1K6"
               sorry
            thus "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
              using A14 sin_cos_def_9 sorry
          qed
          have "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          proof(rule impI)
            assume A19: "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
            have A20: "k =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A21: "k =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
              have A22: "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                using xreal_1_th_29 sorry
              have A23: "n -'NAT-DK9 n =HIDDENR1 n -XCMPLX-0K6 n"
                using xreal_1_th_233 sorry
              also have "... = 0NUMBERSK6"
                 sorry
              finally have "n -'NAT-DK9 n =HIDDENR1 0NUMBERSK6"
                 sorry
              have A24: "(n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)"
                using xreal_1_th_233 sorry
              also have "... = 0NUMBERSK6"
                 sorry
              finally have "(n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
                 sorry
              have A25: "(CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (n !SIN-COSK3)/XCMPLX-0K7 ((n !SIN-COSK3)*XCMPLX-0K3 ((0NUMBERSK6)!SIN-COSK3))"
                using A23 sin_cos_def_6 sorry
              also have "... = \<one>\<^sub>M"
                using sin_cos_th_1 xcmplx_1_th_60 sorry
              finally have "(CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 \<one>\<^sub>M"
                 sorry
              have A26: "(CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)/XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 ((0NUMBERSK6)!SIN-COSK3))"
                using A24 sin_cos_def_6 sorry
              also have "... = \<one>\<^sub>M"
                using sin_cos_th_1 xcmplx_1_th_60 sorry
              finally have "(CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
                 sorry
              have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                using A21 valued_1_th_1 sorry
              also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                using valued_1_th_6 sorry
              also have "... = w *XCMPLX-0K3 0cCOMPLEX1K6 +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                using A22 sin_cos_def_9 sorry
              also have "... = (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
                using sin_cos_def_8 sorry
              also have "... = z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
                using valued_1_th_6 sorry
              also have "... = z *XCMPLX-0K3 (((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z  |^COMSEQ-3K2 n)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 n))"
                using sin_cos_def_9 sorry
              also have "... = ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z))*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 n)"
                 sorry
              also have "... = ((CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 n)"
                using A25 A26 comseq_3_def_1 sorry
              also have "... = (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A21 A23 A24 sin_cos_def_9 sorry
              finally have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
              thus "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                 sorry
            qed
            have "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            proof(rule impI)
              assume A27: "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
              have A28: "k =COMPLEX1R1 0NUMBERSK6 implies (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
              proof(rule impI)
                assume A29: "k =COMPLEX1R1 0NUMBERSK6"
                have A30: "n -'NAT-DK9 0NUMBERSK6 =COMPLEX1R1 n -XCMPLX-0K6 0NUMBERSK6"
                  using xreal_1_th_233 sorry
                have A31: "(n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 0NUMBERSK6 =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 0NUMBERSK6"
                  using xreal_1_th_233 sorry
                have A32: "(CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 (n !SIN-COSK3)/XCMPLX-0K7 (((0NUMBERSK6)!SIN-COSK3)*XCMPLX-0K3 (n !SIN-COSK3))"
                  using A30 sin_cos_def_6 sorry
                also have "... = \<one>\<^sub>M"
                  using sin_cos_th_1 xcmplx_1_th_60 sorry
                finally have "(CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
                   sorry
                have A33: "(CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)/XCMPLX-0K7 (((0NUMBERSK6)!SIN-COSK3)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
                  using A31 sin_cos_def_6 sorry
                also have "... = \<one>\<^sub>M"
                  using sin_cos_th_1 xcmplx_1_th_60 sorry
                finally have "(CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
                   sorry
                have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
                  using A29 valued_1_th_1 sorry
                also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
                  using valued_1_th_6 sorry
                also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 0cCOMPLEX1K6"
                  using sin_cos_def_8 sorry
                also have "... = w *XCMPLX-0K3 (((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z  |^COMSEQ-3K2 (0NUMBERSK6))*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 0NUMBERSK6))"
                  using sin_cos_def_9 sorry
                also have "... = ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z  |^COMSEQ-3K2 (0NUMBERSK6))*XCMPLX-0K3 (w GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 w)"
                  using A30 sorry
                also have "... = ((CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z  |^COMSEQ-3K2 (0NUMBERSK6))*XCMPLX-0K3 w  |^COMSEQ-3K2 ((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 0NUMBERSK6)"
                  using A31 A32 A33 comseq_3_def_1 sorry
                also have "... = (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                  using A29 sin_cos_def_9 sorry
                finally have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                   sorry
                thus "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                   sorry
              qed
              have "k <>HIDDENR2 0NUMBERSK6 implies (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
              proof(rule impI)
                assume A34: "k <>HIDDENR2 0NUMBERSK6"
                then have A35: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
                  using int_1_th_7 sorry
                have A36: "(k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
                  using A27 int_1_th_7 sorry
                have "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
                  using xreal_1_th_29 sorry
                then have "k -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
                  using xreal_1_th_9 sorry
                then have "k -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 n"
                  using A36 xxreal_0_th_2 sorry
                then have A37: "k -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 n"
                  using A35 xreal_1_th_233 sorry
                have A38: "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                  using valued_1_th_1 sorry
                also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                  using valued_1_th_6 sorry
                also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
                  using A34 sin_cos_th_4 sorry
                also have "... = w *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
                  using valued_1_th_6 sorry
                also have "... = w *XCMPLX-0K3 (((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) +XCMPLX-0K2 z *XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
                  using A36 sin_cos_def_9 sorry
                also have "... = (w *XCMPLX-0K3 ((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k))*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k) +XCMPLX-0K2 z *XCMPLX-0K3 (((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M) *XCMPLX-0K3 z  |^COMSEQ-3K2 (k -'NAT-DK9 \<one>\<^sub>M))*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M)))"
                  using A37 sin_cos_def_9 sorry
                also have "... = (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 ((w *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) +XCMPLX-0K2 (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M) *XCMPLX-0K3 ((z  |^COMSEQ-3K2 (k -'NAT-DK9 \<one>\<^sub>M) *XCMPLX-0K3 z)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M)))"
                   sorry
                finally have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 ((w *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)) +XCMPLX-0K2 (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M) *XCMPLX-0K3 ((z  |^COMSEQ-3K2 (k -'NAT-DK9 \<one>\<^sub>M) *XCMPLX-0K3 z)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M)))"
                   sorry
                have A39: "(n -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (n -XCMPLX-0K6 k)+XCMPLX-0K2 \<one>\<^sub>M"
                  using A36 xreal_1_th_233 sorry
                also have "... = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k"
                   sorry
                also have "... = (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k"
                  using A27 xreal_1_th_233 sorry
                finally have "(n -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k"
                   sorry
                have A40: "n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 n -XCMPLX-0K6 (k -'NAT-DK9 \<one>\<^sub>M)"
                  using A37 xreal_1_th_233 sorry
                also have "... = n -XCMPLX-0K6 (k -XCMPLX-0K6 \<one>\<^sub>M)"
                  using A35 xreal_1_th_233 sorry
                also have "... = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k"
                   sorry
                also have "... = (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k"
                  using A27 xreal_1_th_233 sorry
                finally have "n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k"
                   sorry
                have "(k -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (k -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
                  using A35 xreal_1_th_233 sorry
                also have "... = k"
                   sorry
                finally have "(k -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 k"
                   sorry
                then have A41: "w  |^COMSEQ-3K2 (n -'NAT-DK9 k) *XCMPLX-0K3 w =COMPLEX1R1 w  |^COMSEQ-3K2 ((n -'NAT-DK9 k)+NAT-1K1 \<one>\<^sub>M) & z  |^COMSEQ-3K2 (k -'NAT-DK9 \<one>\<^sub>M) *XCMPLX-0K3 z =COMPLEX1R1 z  |^COMSEQ-3K2 k"
                  using comseq_3_def_1 sorry
                have A42: "(CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)) +XCMPLX-0K2 (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M)"
                  using A36 sin_cos_def_6 sorry
                also have "... = (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)) +XCMPLX-0K2 (n !SIN-COSK3)/XCMPLX-0K7 (((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M))!SIN-COSK3))"
                  using A37 sin_cos_def_6 sorry
                finally have "(CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)) +XCMPLX-0K2 (n !SIN-COSK3)/XCMPLX-0K7 (((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M))!SIN-COSK3))"
                   sorry
                have A43: "((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (k !SIN-COSK3)*XCMPLX-0K3 (((n -'NAT-DK9 k)!SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
                   sorry
                have A44: "(((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M))!SIN-COSK3))*XCMPLX-0K3 (k +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ((k +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 ((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 ((n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M))!SIN-COSK3)"
                   sorry
                also have "... = (k !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3)"
                  using A34 A40 sin_cos_th_2 sorry
                finally have "(((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M))!SIN-COSK3))*XCMPLX-0K3 (k +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (k !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3)"
                   sorry
                have "((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) <>HIDDENR2 0cCOMPLEX1K6"
                  using A27 sorry
                then have A45: "(n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)) =HIDDENR1 ((n !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
                  using xcmplx_1_th_91 sorry
                also have "... = ((n !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3))"
                  using A36 A43 sin_cos_th_2 sorry
                finally have "(n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)) =HIDDENR1 ((n !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3))"
                   sorry
                have "(n !SIN-COSK3)/XCMPLX-0K7 (((k -'NAT-DK9 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 (k -'NAT-DK9 \<one>\<^sub>M))!SIN-COSK3)) =COMPLEX1R1 ((n !SIN-COSK3)*XCMPLX-0K3 (k +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3))"
                  using A34 A44 xcmplx_1_th_91 sorry
                then have "(CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 ((n !SIN-COSK3)*XCMPLX-0K3 ((((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 k)+XCMPLX-0K2 k)+XCMPLX-0K2 (0NUMBERSK6 +NAT-1K1 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3))"
                  using A42 A45 sorry
                also have "... = ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)!SIN-COSK3))"
                  using sin_cos_th_1 sorry
                also have "... = (CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                  using A27 sin_cos_def_6 sorry
                finally have "(CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 (CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                   sorry
                then have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((CoefSIN-COSK6 (n +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 ((n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 k)"
                  using A38 A39 A40 A41 sorry
                also have "... = (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                  using A27 sin_cos_def_9 sorry
                finally have "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                   sorry
                thus "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                   sorry
              qed
              thus "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
                using A28 sorry
            qed
            thus "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
              using A19 A20 xxreal_0_th_1 sorry
          qed
          thus "(w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
            using A13 sorry
        qed "sorry"
        then have A46: "w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)"
           sorry
        have "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Partial-SumsCOMSEQ-3K10 (w (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (ShiftSIN-COSK8 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A7 A8 A9 A10 A12 valued_1_th_1 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A46 comseq_3_th_27 sorry
        finally show "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A2 A3 sorry
    thus "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_7:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds Expan-eSIN-COSK10(n,z,w) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds Expan-eSIN-COSK10(n,z,w) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))"
  proof(rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds (Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
    proof(rule ballI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A1: "n <XXREAL-0R3 k implies (Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      proof(rule impI)
        assume A2: "n <XXREAL-0R3 k"
        then have "(Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 0cCOMPLEX1K6"
          using sin_cos_def_10 sorry
        also have "... = (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          using A2 sin_cos_def_9 sorry
        also have "... = ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          using valued_1_th_6 sorry
        finally show "(Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
           sorry
      qed
      have "k <=XXREAL-0R1 n implies (Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      proof(rule impI)
        assume A3: "k <=XXREAL-0R1 n"
        then have A4: "(Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((Coef-eSIN-COSK7 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)"
          using sin_cos_def_10 sorry
        also have "... = ((1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)))*XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)"
          using A3 sin_cos_def_7 sorry
        finally have "(Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)))*XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k)"
           sorry
        have "1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)) =HIDDENR1 (((n !SIN-COSK3)*XCMPLX-0K3 1rCOMPLEX1K7)/XCMPLX-0K7 (n !SIN-COSK3))/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))"
          using xcmplx_1_th_60 sorry
        also have "... = ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3))/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))"
           sorry
        finally have "1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)) =HIDDENR1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3))/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3))"
           sorry
        then have "(Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3))/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)))*XCMPLX-0K3 (z  |^COMSEQ-3K2 k *XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k))"
          using A4 sorry
        also have "... = (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 ((((n !SIN-COSK3)/XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 ((n -'NAT-DK9 k)!SIN-COSK3)))*XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k))"
           sorry
        also have "... = (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (((CoefSIN-COSK6 n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (n -'NAT-DK9 k))"
          using A3 sin_cos_def_6 sorry
        also have "... = (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (ExpanSIN-COSK9(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          using A3 sin_cos_def_9 sorry
        also have "... = ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
          using valued_1_th_6 sorry
        finally show "(Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
           sorry
      qed
      thus "(Expan-eSIN-COSK10(n,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using A1 sorry
    qed "sorry"
    thus "Expan-eSIN-COSK10(n,z,w) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_8:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds (z +XCMPLX-0K2 w) |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3) =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds (z +XCMPLX-0K2 w) |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))"
      using sin_cos_th_6 sorry
    also have "... = ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (ExpanSIN-COSK9(n,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      using valued_1_th_6 sorry
    also have "... = Partial-SumsCOMSEQ-3K10 ((1rCOMPLEX1K7 /XCMPLX-0K7 (n !SIN-COSK3))(#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (ExpanSIN-COSK9(n,z,w))) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      using comseq_3_th_29 sorry
    also have "... = Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      using sin_cos_th_7 sorry
    finally show "(z +XCMPLX-0K2 w) |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_9:
"0cCOMPLEX1K6 ExpSeqSIN-COSK4 be absolutely-summableCOMSEQ-3V2 & SumCOMSEQ-3K11 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) =COMPLEX1R1 1rCOMPLEX1K7"
proof-
  obtain jj where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
    using sin_cos_lm_1 numbers_th_19 sorry
  let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) .FUNCT-1K1 Lamb1 =COMPLEX1R1 jj"
  have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
    using series_1_def_1 sorry
  also have "... =  |.COMPLEX1K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).|"
    using valued_1_th_18 sorry
  also have "... = \<one>\<^sub>M"
    using sin_cos_th_3 complex1_th_48 sorry
  finally have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
     sorry
  then have A1: "?X(0NUMBERSK6)"
     sorry
  have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 jj implies Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 jj"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A3: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 jj"
      have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A3 series_1_def_1 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M).|"
        using valued_1_th_18 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 ((0cCOMPLEX1K6 ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 0cCOMPLEX1K6)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) .|"
        using sin_cos_th_3 sorry
      also have "... = jj"
        using complex1_th_44 sorry
      finally show "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 jj"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have " for n be NatNAT-1M1 holds ?X(n)"
    using nat_1_sch_2 A1 A2 sorry
  then have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .|) be constantVALUED-0V15"
    using valued_0_def_18 sorry
  then have A4: " |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 ExpSeqSIN-COSK4 .| be summableSERIES-1V1"
    using series_1_def_2 sorry
  let ?X = "\<lambda>Lamb1. Partial-SumsCOMSEQ-3K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) .FUNCT-1K1 Lamb1 =COMPLEX1R1 \<one>\<^sub>M"
  have "Partial-SumsCOMSEQ-3K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 (0cCOMPLEX1K6 ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
    using series_1_def_1 sorry
  also have "... = \<one>\<^sub>M"
    using sin_cos_th_3 sorry
  finally have "Partial-SumsCOMSEQ-3K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
     sorry
  then have A5: "?X(0NUMBERSK6)"
     sorry
  have A6: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M implies Partial-SumsCOMSEQ-3K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A7: "Partial-SumsCOMSEQ-3K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M"
      have "Partial-SumsCOMSEQ-3K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 1rCOMPLEX1K7 +XCMPLX-0K2 (0cCOMPLEX1K6 ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A7 series_1_def_1 sorry
      also have "... = 1rCOMPLEX1K7 +XCMPLX-0K2 ((0cCOMPLEX1K6 ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 0cCOMPLEX1K6)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
        using sin_cos_th_3 sorry
      also have "... = \<one>\<^sub>M"
         sorry
      finally show "Partial-SumsCOMSEQ-3K10 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have " for n be NatNAT-1M1 holds ?X(n)"
    using nat_1_sch_2 A5 A6 sorry
  thus "0cCOMPLEX1K6 ExpSeqSIN-COSK4 be absolutely-summableCOMSEQ-3V2 & SumCOMSEQ-3K11 (0cCOMPLEX1K6 ExpSeqSIN-COSK4) =COMPLEX1R1 1rCOMPLEX1K7"
    using A4 comseq_2_th_10 sorry
qed

mtheorem sin_cos_cl_2:
  mlet "z be ComplexXCMPLX-0M1"
"cluster z ExpSeqSIN-COSK4 as-term-is absolutely-summableCOMSEQ-3V2"
proof
(*coherence*)
  show "z ExpSeqSIN-COSK4 be absolutely-summableCOMSEQ-3V2"
  proof-
    have "z <>HIDDENR2 0cCOMPLEX1K6 implies ( for n be NatNAT-1M1 holds (z ExpSeqSIN-COSK4).FUNCT-1K1 n <>HIDDENR2 0cCOMPLEX1K6) & z ExpSeqSIN-COSK4 be absolutely-summableCOMSEQ-3V2"
    proof(rule impI,rule conjMI)
      assume A1: "z <>HIDDENR2 0cCOMPLEX1K6"
      let ?X = "\<lambda>Lamb1. (z ExpSeqSIN-COSK4).FUNCT-1K1 Lamb1 <>HIDDENR2 0cCOMPLEX1K6"
      have A2: "?X(0NUMBERSK6)"
        using sin_cos_th_3 sorry
      have A3: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6 implies (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0cCOMPLEX1K6"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A4: "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
          show "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0cCOMPLEX1K6"
          proof-
            have "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0cCOMPLEX1K6 implies  False "
            proof(rule impI)
              assume "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0cCOMPLEX1K6"
              then have A5: "((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0cCOMPLEX1K6"
                using sin_cos_th_3 sorry
              have "0cCOMPLEX1K6 =HIDDENR1 0cCOMPLEX1K6 /XCMPLX-0K7 z"
                 sorry
              also have "... = ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 z"
                using A5 xcmplx_1_th_50 sorry
              also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (z /XCMPLX-0K7 z)"
                 sorry
              also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 \<one>\<^sub>M"
                using A1 xcmplx_1_th_60 sorry
              also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
                 sorry
              finally have "0cCOMPLEX1K6 =HIDDENR1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
                 sorry
              thus " False "
                using A4 sorry
            qed
            thus " ?thesis "
               sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      let ?U = "\<lambda>Lamb1. ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
      show A6: " for n be NatNAT-1M1 holds (z ExpSeqSIN-COSK4).FUNCT-1K1 n <>HIDDENR2 0cCOMPLEX1K6"
        using nat_1_sch_2 A2 A3 sorry
      have " ex rseq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
        using seq_1_sch_1 sorry
      then obtain rseq where
        [ty]:"rseq be Real-SequenceSEQ-1M1" and 
        A7: " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
      have " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A7 sorry
        also have "... = ( |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M).|)/XCMPLX-0K7 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using valued_1_th_18 sorry
        also have "... = ( |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M).|)/XCMPLX-0K7 ( |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
          using valued_1_th_18 sorry
        also have "... =  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
          using complex1_th_67 sorry
        also have "... =  |.COMPLEX1K10 (((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
          using sin_cos_th_3 sorry
        also have "... =  |.COMPLEX1K10 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (z /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))))/XCMPLX-0K7 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
           sorry
        also have "... =  |.COMPLEX1K10 z /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) .|"
          using A6 xcmplx_1_th_89 sorry
        also have "... = ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10 n +NAT-1K1 \<one>\<^sub>M .|)"
          using complex1_th_67 sorry
        also have "... = ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using absvalue_def_1 sorry
        finally show "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      then have "rseq be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq <XXREAL-0R3 \<one>\<^sub>M"
        using seq_4_th_31 sorry
      thus "z ExpSeqSIN-COSK4 be absolutely-summableCOMSEQ-3V2"
        using A6 A7 comseq_3_th_75 sorry
    qed
    thus "z ExpSeqSIN-COSK4 be absolutely-summableCOMSEQ-3V2"
      using sin_cos_th_9 sorry
  qed
qed "sorry"

mtheorem sin_cos_th_10:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & (ExpanSIN-COSK9(0NUMBERSK6,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M & (ExpanSIN-COSK9(0NUMBERSK6,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule conjMI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 z  |^COMSEQ-3K2 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
      using sin_cos_def_4 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_1 comseq_3_def_1 sorry
    finally show "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have A1: "0NUMBERSK6 -'NAT-DK9 0NUMBERSK6 =COMPLEX1R1 0NUMBERSK6"
      using xreal_1_th_232 sorry
    then have "(ExpanSIN-COSK9(0NUMBERSK6,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 ((CoefSIN-COSK6 (0NUMBERSK6)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z  |^COMSEQ-3K2 (0NUMBERSK6))*XCMPLX-0K3 w  |^COMSEQ-3K2 (0NUMBERSK6)"
      using sin_cos_def_9 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M))*XCMPLX-0K3 z  |^COMSEQ-3K2 (0NUMBERSK6))*XCMPLX-0K3 w  |^COMSEQ-3K2 (0NUMBERSK6)"
      using A1 sin_cos_def_6 sin_cos_th_1 sorry
    also have "... = 1rCOMPLEX1K7 *XCMPLX-0K3 w GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using comseq_3_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using comseq_3_def_1 sorry
    finally show "(ExpanSIN-COSK9(0NUMBERSK6,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_11:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =COMPLEX1R1 (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l +XCMPLX-0K2 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =COMPLEX1R1 (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l +XCMPLX-0K2 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    assume A1: "l <=XXREAL-0R1 k"
    have A2: "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_29 sorry
    then have A3: "l <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
    have "(k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l =COMPLEX1R1 (k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 l"
      using A1 A2 xreal_1_th_233 xxreal_0_th_2 sorry
    then have A4: "(k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l =HIDDENR1 (k -XCMPLX-0K6 l)+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    also have "... = (k -'NAT-DK9 l)+NAT-1K1 \<one>\<^sub>M"
      using A1 xreal_1_th_233 sorry
    finally have "(k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l =HIDDENR1 (k -'NAT-DK9 l)+NAT-1K1 \<one>\<^sub>M"
       sorry
    then have A5: "(AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =HIDDENR1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((k -'NAT-DK9 l)+NAT-1K1 \<one>\<^sub>M)"
      using A3 sin_cos_def_11 sorry
    also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) +XCMPLX-0K2 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l))"
      using A4 series_1_def_1 sorry
    also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) +XCMPLX-0K2 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l)"
       sorry
    also have "... = (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l +XCMPLX-0K2 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l)"
      using A1 sin_cos_def_11 sorry
    finally have "(AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =HIDDENR1 (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l +XCMPLX-0K2 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l)"
       sorry
    have "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l) =HIDDENR1 (z  |^COMSEQ-3K2 l /XCMPLX-0K7 (l !SIN-COSK3))*XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l)"
      using sin_cos_def_4 sorry
    also have "... = (z  |^COMSEQ-3K2 l /XCMPLX-0K7 (l !SIN-COSK3))*XCMPLX-0K3 (w  |^COMSEQ-3K2 ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l) /XCMPLX-0K7 (((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l)!SIN-COSK3))"
      using sin_cos_def_4 sorry
    also have "... = ((z  |^COMSEQ-3K2 l *XCMPLX-0K3 w  |^COMSEQ-3K2 ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l))*XCMPLX-0K3 1rCOMPLEX1K7)/XCMPLX-0K7 ((l !SIN-COSK3)*XCMPLX-0K3 (((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l)!SIN-COSK3))"
      using xcmplx_1_th_76 sorry
    also have "... = (z  |^COMSEQ-3K2 l *XCMPLX-0K3 w  |^COMSEQ-3K2 ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l))*XCMPLX-0K3 (1rCOMPLEX1K7 /XCMPLX-0K7 ((l !SIN-COSK3)*XCMPLX-0K3 (((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l)!SIN-COSK3)))"
       sorry
    also have "... = (Coef-eSIN-COSK7 (k +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (z  |^COMSEQ-3K2 l *XCMPLX-0K3 w  |^COMSEQ-3K2 ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l))"
      using A3 sin_cos_def_7 sorry
    also have "... = ((Coef-eSIN-COSK7 (k +NAT-1K1 \<one>\<^sub>M)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 z  |^COMSEQ-3K2 l)*XCMPLX-0K3 w  |^COMSEQ-3K2 ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l)"
       sorry
    also have "... = (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
      using A3 sin_cos_def_10 sorry
    finally have "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 l) =HIDDENR1 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
       sorry
    thus "(AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =COMPLEX1R1 (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l +XCMPLX-0K2 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_12:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    have A1: "k inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have " for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =HIDDENR1 (AlfaSIN-COSK11(k,z,w) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
    proof(rule ballI,rule impI)
      fix l assume [ty]: "l be NatNAT-1M1"
      have A2: "l inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      assume "l <=XXREAL-0R1 k"
      then have "(AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =HIDDENR1 (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l +XCMPLX-0K2 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
        using sin_cos_th_11 sorry
      also have "... = (AlfaSIN-COSK11(k,z,w) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
        using valued_1_th_1 A2 sorry
      finally show "(AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =HIDDENR1 (AlfaSIN-COSK11(k,z,w) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
         sorry
    qed "sorry"
    then have "Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using comseq_3_th_35 sorry
    also have "... = (Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using comseq_3_th_27 sorry
    also have "... = Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using valued_1_th_1 A1 sorry
    finally show "Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_13:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 (Expan-eSIN-COSK10(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds (Expan-eSIN-COSK10(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    have A1: "0NUMBERSK6 =COMPLEX1R1 k -XCMPLX-0K6 k"
       sorry
    then have A2: "k -'NAT-DK9 k =COMPLEX1R1 0NUMBERSK6"
      using xreal_1_th_233 sorry
    have A3: "(k -'NAT-DK9 k)!SIN-COSK3 =COMPLEX1R1 \<one>\<^sub>M"
      using A1 sin_cos_th_1 xreal_1_th_233 sorry
    have "(Expan-eSIN-COSK10(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 ((Coef-eSIN-COSK7 k).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 w  |^COMSEQ-3K2 (0NUMBERSK6)"
      using A2 sin_cos_def_10 sorry
    also have "... = ((Coef-eSIN-COSK7 k).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 1rCOMPLEX1K7"
      using comseq_3_th_11 sorry
    also have "... = (1rCOMPLEX1K7 /XCMPLX-0K7 ((k !SIN-COSK3)*XCMPLX-0K3 1rCOMPLEX1K7))*XCMPLX-0K3 z  |^COMSEQ-3K2 k"
      using A3 sin_cos_def_7 sorry
    also have "... = (z  |^COMSEQ-3K2 k *XCMPLX-0K3 1rCOMPLEX1K7)/XCMPLX-0K7 (k !SIN-COSK3)"
       sorry
    also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using sin_cos_def_4 sorry
    finally show "(Expan-eSIN-COSK10(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_14:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_10 sorry
    finally have "Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    let ?X = "\<lambda>Lamb1. Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(Lamb1,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
    have A2: "0NUMBERSK6 -'NAT-DK9 0NUMBERSK6 =COMPLEX1R1 0NUMBERSK6"
      using xreal_1_th_232 sorry
    have "Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(0NUMBERSK6,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 (AlfaSIN-COSK11(0NUMBERSK6,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using A2 sin_cos_def_11 sorry
    also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = 1rCOMPLEX1K7 *XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using sin_cos_th_10 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_10 sorry
    finally have "Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(0NUMBERSK6,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
      using A1 sorry
    have A4: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k implies Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A5: "Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        have A6: "Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = (Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)+XCMPLX-0K2 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using sin_cos_th_12 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using A5 sorry
        finally have "Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
           sorry
        have "(k +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
          using xreal_1_th_232 sorry
        then have "(AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
          using sin_cos_def_11 sorry
        also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (w ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
          using series_1_def_1 sorry
        also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M"
          using sin_cos_th_10 sorry
        also have "... = (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using sin_cos_th_13 sorry
        finally have "(AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
        then have "Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = (z +XCMPLX-0K2 w) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
          using sin_cos_th_8 sorry
        finally have "Partial-SumsCOMSEQ-3K10 (Expan-eSIN-COSK10(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (z +XCMPLX-0K2 w) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
           sorry
        then have "Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A6 sin_cos_def_4 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        finally have "Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k +NAT-1K1 \<one>\<^sub>M,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A4 sorry
    thus "Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(n,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_15:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    have A1: "k inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A2: "Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using sin_cos_th_14 sorry
    also have "... = (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using valued_1_th_6 sorry
    also have "... = Partial-SumsCOMSEQ-3K10 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using comseq_3_th_29 sorry
    also have "... = Partial-SumsCOMSEQ-3K10 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using valued_1_th_8 sorry
    also have "... = (Partial-SumsCOMSEQ-3K10 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4)) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (AlfaSIN-COSK11(k,z,w))).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using valued_1_th_1 A1 sorry
    also have "... = Partial-SumsCOMSEQ-3K10 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using comseq_3_th_28 sorry
    finally have "Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 Partial-SumsCOMSEQ-3K10 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> AlfaSIN-COSK11(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
       sorry
    have " for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =COMPLEX1R1 (ConjSIN-COSK13(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
    proof-
      have " for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =HIDDENR1 (ConjSIN-COSK13(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
      proof(rule ballI,rule impI)
        fix l assume [ty]: "l be NatNAT-1M1"
        assume A3: "l <=XXREAL-0R1 k"
        have A4: "l inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =HIDDENR1 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
          using valued_1_th_1 A4 sorry
        also have "... = (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l -XCMPLX-0K6 (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
          using valued_1_th_8 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l -XCMPLX-0K6 (AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
          using valued_1_th_6 sorry
        also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l)"
          using A3 sin_cos_def_11 sorry
        also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l))"
           sorry
        also have "... = (ConjSIN-COSK13(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
          using A3 sin_cos_def_13 sorry
        finally show "(Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> AlfaSIN-COSK11(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l =HIDDENR1 (ConjSIN-COSK13(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using A2 comseq_3_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_16:
" for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k & Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)) &  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k & (Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) &  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    let ?X = "\<lambda>Lamb1.  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
    have A1: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).| =HIDDENR1  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).|"
      using series_1_def_1 sorry
    also have "... =  |.COMPLEX1K10 z  |^COMSEQ-3K2 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3) .|"
      using sin_cos_def_4 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_1 complex1_th_48 comseq_3_def_1 sorry
    finally have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).| =HIDDENR1 \<one>\<^sub>M"
       sorry
    have "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
      using sin_cos_def_5 sorry
    also have "... = \<one>\<^sub>M"
      using newton_th_4 newton_th_12 sorry
    finally have "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A2: "?X(0NUMBERSK6)"
      using A1 sorry
    have A3: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A4: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
        have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| =COMPLEX1R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) .| &  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).|"
          using complex1_th_56 series_1_def_1 sorry
        then have A5: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using sin_cos_th_3 sorry
        have A6: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A4 xreal_1_th_6 sorry
        have "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A5 A6 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: " for k be NatNAT-1M1 holds ?X(k)"
      using nat_1_sch_2 A2 A3 sorry
    thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
       sorry
    have " for k be objectHIDDENM1 holds k inHIDDENR3 NATNUMBERSK1 implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).FUNCT-1K1 k =HIDDENR1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be objectHIDDENM1"
      assume A8: "k inHIDDENR3 NATNUMBERSK1"
      have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).FUNCT-1K1 k =HIDDENR1  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).FUNCT-1K1 k.|"
        using valued_1_th_18 sorry
      also have "... = (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).FUNCT-1K1 k"
        using A8 sin_cos_th_3 sorry
      finally show "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).FUNCT-1K1 k =HIDDENR1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).FUNCT-1K1 k"
         sorry
    qed "sorry"
    then have A9: " |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .| =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5"
       sorry
    then have "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 limSEQ-2K1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
      using seq_4_th_37 sorry
    thus "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
      using series_1_def_3 sorry
    have A10: " for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
    proof(rule ballI)
      fix k assume [ty]: "k be NatNAT-1M1"
      have "limSEQ-2K1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) =COMPLEX1R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
        using series_1_def_3 sorry
      thus "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
        using A9 seq_4_th_37 sorry
    qed "sorry"
    have A11: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
      using A7 sorry
    have "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
      using A10 sorry
    thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
      using A11 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_17:
" for z be ComplexXCMPLX-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).| =HIDDENR1  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).|"
      using series_1_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_3 complex1_th_48 sorry
    finally have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).| =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
      using sin_cos_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_18:
" for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI,rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "(( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
      using sin_cos_th_3 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using complex1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_19:
" for z be ComplexXCMPLX-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & (n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n &  not (n <=XXREAL-0R1 m &  not  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  proof(rule ballI,rule ballI,rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using sin_cos_th_18 sorry
    thus " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n &  not (n <=XXREAL-0R1 m &  not  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using comseq_3_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_20:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 (ConjSIN-COSK13(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using valued_1_th_18 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using complex1_th_46 sorry
    qed "sorry"
    have A2: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using seqm_3_th_6 series_1_def_1 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using A1 sorry
    thus " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A2 absvalue_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_21:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <XXREAL-0R3 p)"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex n4 be setHIDDENM2 st  for k be NatNAT-1M1 holds  not (n4 <=XXREAL-0R1 k &  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <XXREAL-0R3 p))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A1: "p >XXREAL-0R4 0NUMBERSK6"
    obtain pp where 
      [ty]:"pp be RealXREAL-0M1" and ppDef:"pp = p"
       sorry
    have A2: "\<one>\<^sub>M <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
      using sin_cos_th_17 sorry
    have A3: "0NUMBERSK6 <XXREAL-0R3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)"
      using sin_cos_th_17 sorry
    let ?p1 = "minXXREAL-0K4(pp /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)),pp /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)))"
    have A4: "?p1 >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 A3 xxreal_0_th_15 sorry
    have " for k be objectHIDDENM1 holds k inHIDDENR3 NATNUMBERSK1 implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).FUNCT-1K1 k =HIDDENR1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be objectHIDDENM1"
      assume A5: "k inHIDDENR3 NATNUMBERSK1"
      have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).FUNCT-1K1 k =HIDDENR1  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).FUNCT-1K1 k.|"
        using valued_1_th_18 sorry
      also have "... = (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).FUNCT-1K1 k"
        using A5 sin_cos_th_3 sorry
      finally show "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).FUNCT-1K1 k =HIDDENR1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).FUNCT-1K1 k"
         sorry
    qed "sorry"
    then have " |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .| =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5"
       sorry
    then obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A6: " for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n1 <=XXREAL-0R1 k & n1 <=XXREAL-0R1 l implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <XXREAL-0R3 ?p1"
      using A4 comseq_3_th_4 sorry
    obtain n2 where
      [ty]:"n2 be NatNAT-1M1" and 
      A7: " for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n2 <=XXREAL-0R1 k & n2 <=XXREAL-0R1 l implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l .| <XXREAL-0R3 ?p1"
      using A4 comseq_3_th_47 sorry
    let ?n3 = "n1 +XCMPLX-0K2 n2"
    obtain n4 where 
      [ty]:"n4 be setHIDDENM2" and n4Def:"n4 = ?n3 +XCMPLX-0K2 ?n3"
       sorry
    show " ex n4 be setHIDDENM2 st  for k be NatNAT-1M1 holds  not (n4 <=XXREAL-0R1 k &  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "n4"])
      have A8: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .|)"
      proof(rule ballI,rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        fix k assume [ty]: "k be NatNAT-1M1"
        have " for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l =HIDDENR1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .|)"
        proof(rule ballI,rule impI)
          fix l assume [ty]: "l be NatNAT-1M1"
          assume A9: "l <=XXREAL-0R1 k"
          have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l =HIDDENR1  |.COMPLEX1K10 (ConjSIN-COSK13(k,z,w)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l.|"
            using valued_1_th_18 sorry
          also have "... =  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l)) .|"
            using A9 sin_cos_def_13 sorry
          also have "... = ( |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l.|)*XCMPLX-0K3 ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .|)"
            using complex1_th_65 sorry
          also have "... = (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .|)"
            using sin_cos_th_3 sorry
          finally show "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l =HIDDENR1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .|)"
             sorry
        qed "sorry"
        thus " for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .|)"
           sorry
      qed "sorry"
      have A10: " for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))"
      proof(rule ballI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have " for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))"
        proof(rule ballI,rule impI)
          fix l assume [ty]: "l be NatNAT-1M1"
          assume "l <=XXREAL-0R1 k"
          then have A11: "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l =COMPLEX1R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .|)"
            using A8 sorry
          have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)"
            using sin_cos_th_16 sorry
          then have A12: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l).| <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5) +XCMPLX-0K2  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l).|"
            using xreal_1_th_6 sorry
          have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l).| <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)"
            using sin_cos_th_16 sorry
          then have "SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5) +XCMPLX-0K2  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l).| <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5) +XCMPLX-0K2 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)"
            using xreal_1_th_6 sorry
          then have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l).| &  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l).| <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)"
            using A12 complex1_th_57 xxreal_0_th_2 sorry
          then have A13: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .| <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)"
            using xxreal_0_th_2 sorry
          have "0NUMBERSK6 <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l"
            using sin_cos_th_18 sorry
          thus "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))"
            using A11 A13 xreal_1_th_64 sorry
        qed "sorry"
        thus " for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))"
           sorry
      qed "sorry"
      have " for k be NatNAT-1M1 holds n4 <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <XXREAL-0R3 p"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A14: "n4 <=XXREAL-0R1 k"
        have A15: "0NUMBERSK6 +XCMPLX-0K2 ?n3 <=XXREAL-0R1 ?n3 +XCMPLX-0K2 ?n3"
          using xreal_1_th_6 sorry
        then have A16: "?n3 <=XXREAL-0R1 k"
          using A14 xxreal_0_th_2 sorry
        have A17: "n1 +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using xreal_1_th_6 sorry
        then have A18: "n1 <=XXREAL-0R1 k"
          using A16 xxreal_0_th_2 sorry
        have " for l be NatNAT-1M1 holds l <=XXREAL-0R1 n1 +XCMPLX-0K2 n2 implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 minXXREAL-0K4(pp /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)),pp /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))) *XCMPLX-0K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l"
        proof(rule ballI,rule impI)
          fix l assume [ty]: "l be NatNAT-1M1"
          assume A19: "l <=XXREAL-0R1 ?n3"
          then have A20: "k -'NAT-DK9 l =COMPLEX1R1 k -XCMPLX-0K6 l"
            using A16 xreal_1_th_233 xxreal_0_th_2 sorry
          have A21: "0NUMBERSK6 +XCMPLX-0K2 n2 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
            using xreal_1_th_6 sorry
          have A22: "n4 -XCMPLX-0K6 l <=XXREAL-0R1 k -XCMPLX-0K6 l"
            using A14 xreal_1_th_9 sorry
          have "(?n3 +XCMPLX-0K2 ?n3)-XCMPLX-0K6 ?n3 <=XXREAL-0R1 (?n3 +XCMPLX-0K2 ?n3)-XCMPLX-0K6 l"
            using A19 xreal_1_th_10 sorry
          then have "?n3 <=XXREAL-0R1 k -XCMPLX-0K6 l"
            using A22 xxreal_0_th_2 sorry
          then have A23: "n2 <=XXREAL-0R1 k -'NAT-DK9 l"
            using A20 A21 xxreal_0_th_2 sorry
          have "0NUMBERSK6 +XCMPLX-0K2 ?n3 <=XXREAL-0R1 ?n3 +XCMPLX-0K2 ?n3"
            using xreal_1_th_6 sorry
          then have "n2 <=XXREAL-0R1 n4"
            using A21 xxreal_0_th_2 sorry
          then have "n2 <=XXREAL-0R1 k"
            using A14 xxreal_0_th_2 sorry
          then have A24: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .| <XXREAL-0R3 ?p1"
            using A7 A23 sorry
          have "0NUMBERSK6 <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l"
            using sin_cos_th_18 sorry
          then have "(( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 ( |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k -'NAT-DK9 l) .|) <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l *XCMPLX-0K3 ?p1"
            using A24 xreal_1_th_64 sorry
          thus "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 minXXREAL-0K4(pp /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)),pp /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))) *XCMPLX-0K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l"
            using A8 A16 A19 xxreal_0_th_2 sorry
        qed "sorry"
        then have A25: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <=XXREAL-0R1 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 *XCMPLX-0K3 ?p1"
          using comseq_3_th_7 sorry
        have "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 *XCMPLX-0K3 ?p1 <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) *XCMPLX-0K3 ?p1"
          using A4 sin_cos_th_16 xreal_1_th_64 sorry
        then have A26: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) *XCMPLX-0K3 ?p1"
          using A25 xxreal_0_th_2 sorry
        have A27: "SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) *XCMPLX-0K3 ?p1 <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) *XCMPLX-0K3 (p /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)))"
          using A2 xreal_1_th_64 xxreal_0_th_17 sorry
        have A28: "0NUMBERSK6 <>HIDDENR2 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5)"
          using sin_cos_th_17 sorry
        have "SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) *XCMPLX-0K3 (p /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5))) =HIDDENR1 (SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) *XCMPLX-0K3 p)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5))"
           sorry
        also have "... = p /XCMPLX-0K7 \<four>\<^sub>M"
          using A28 xcmplx_1_th_91 sorry
        finally have "SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) *XCMPLX-0K3 (p /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5))) =HIDDENR1 p /XCMPLX-0K7 \<four>\<^sub>M"
           sorry
        then have A29: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <=XXREAL-0R1 p /XCMPLX-0K7 \<four>\<^sub>M"
          using A26 A27 xxreal_0_th_2 sorry
        have "0NUMBERSK6 +XCMPLX-0K2 p /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 p /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<four>\<^sub>M"
          using A1 xreal_1_th_6 sorry
        then have A30: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A29 xxreal_0_th_2 sorry
        have "k -'NAT-DK9 ?n3 =COMPLEX1R1 k -XCMPLX-0K6 ?n3"
          using A14 A15 xreal_1_th_233 xxreal_0_th_2 sorry
        then have A31: "k =COMPLEX1R1 (k -'NAT-DK9 ?n3)+XCMPLX-0K2 ?n3"
           sorry
        have " for l be NatNAT-1M1 holds l <=XXREAL-0R1 k implies ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))*XCMPLX-0K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l"
          using A10 sorry
        then have A32: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <=XXREAL-0R1 (Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))"
          using A31 comseq_3_th_8 sorry
        have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 .| <=XXREAL-0R1 ?p1"
          using A6 A17 A18 sorry
        then have "Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <=XXREAL-0R1 ?p1"
          using A14 A15 sin_cos_th_19 xxreal_0_th_2 sorry
        then have "(Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 (( |.COMPLEX1K10 z.|)rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)) <=XXREAL-0R1 ?p1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))"
          using A3 xreal_1_th_64 sorry
        then have A33: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <=XXREAL-0R1 ?p1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))"
          using A32 xxreal_0_th_2 sorry
        have A34: "(\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))*XCMPLX-0K3 ?p1 <=XXREAL-0R1 (\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))*XCMPLX-0K3 (p /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)))"
          using A3 xreal_1_th_64 xxreal_0_th_17 sorry
        have A35: "0NUMBERSK6 <>HIDDENR2 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5)"
          using sin_cos_th_17 sorry
        have "(\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))*XCMPLX-0K3 (p /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))) =HIDDENR1 ((\<two>\<^sub>M *XCMPLX-0K3 p)*XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))"
           sorry
        also have "... = (p +XCMPLX-0K2 p)/XCMPLX-0K7 \<four>\<^sub>M"
          using A35 xcmplx_1_th_91 sorry
        also have "... = p /XCMPLX-0K7 \<two>\<^sub>M"
           sorry
        finally have "(\<two>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))*XCMPLX-0K3 (p /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 SumSERIES-1K4 (( |.COMPLEX1K10 w.|)rExpSeqSIN-COSK5))) =HIDDENR1 p /XCMPLX-0K7 \<two>\<^sub>M"
           sorry
        then have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <=XXREAL-0R1 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A33 A34 xxreal_0_th_2 sorry
        then have "(Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3)+REAL-1K3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ?n3 <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A30 xreal_1_th_8 sorry
        thus " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <XXREAL-0R3 p"
          using sin_cos_th_20 sorry
      qed "sorry"
      thus " for k be NatNAT-1M1 holds  not (n4 <=XXREAL-0R1 k &  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <XXREAL-0R3 p)"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_22:
" for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for w be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  not (( for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) &  not (seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule ballI)
    fix w assume [ty]: "w be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for seq be Complex-SequenceCOMSEQ-1M1 holds ( for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
    proof(rule ballI,rule impI)
      fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
      assume A1: " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      have A2: " for k be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
      proof(rule ballI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| =COMPLEX1R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.|"
          using A1 sorry
        thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          using comseq_3_th_30 sorry
      qed "sorry"
      let ?U = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(Lamb1,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
      have " ex rseq be Real-SequenceSEQ-1M1 st  for k be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 ?U(k)"
        using seq_1_sch_1 sorry
      then obtain rseq where
        [ty]:"rseq be Real-SequenceSEQ-1M1" and 
        A3: " for k be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A4: " for k be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
      proof(rule ballI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          using A2 sorry
        thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          using A3 sorry
      qed "sorry"
      have A5: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume "p >XXREAL-0R4 0NUMBERSK6"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A6: " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| <XXREAL-0R3 p"
          using sin_cos_th_21 sorry
        show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"])
          have " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A7: "n <=XXREAL-0R1 k"
            have " |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 0NUMBERSK6 .| =COMPLEX1R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> ConjSIN-COSK13(k,z,w) .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.|"
              using A3 sorry
            thus " |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
              using A6 A7 sorry
          qed "sorry"
          thus " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
             sorry
        qed "sorry"
      qed "sorry"
      then have A8: "rseq be convergentCOMSEQ-2V3"
        using seq_2_def_6 sorry
      then have "limSEQ-2K1 rseq =COMPLEX1R1 0NUMBERSK6"
        using A5 seq_2_def_7 sorry
      thus "seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
        using A4 A8 comseq_3_th_48 sorry
    qed "sorry"
    thus " not (( for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) &  not (seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0NUMBERSK6))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos_lm_3:
" for z be ComplexXCMPLX-0M1 holds  for w be ComplexXCMPLX-0M1 holds SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 (w ExpSeqSIN-COSK4) =COMPLEX1R1 SumCOMSEQ-3K11 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4)"
proof-
  have " for z0 be ComplexXCMPLX-0M1 holds  for w0 be ComplexXCMPLX-0M1 holds SumCOMSEQ-3K11 (z0 ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 (w0 ExpSeqSIN-COSK4) =COMPLEX1R1 SumCOMSEQ-3K11 ((z0 +XCMPLX-0K2 w0)ExpSeqSIN-COSK4)"
  proof(rule ballI,rule ballI)
    fix z0 assume [ty]: "z0 be ComplexXCMPLX-0M1"
    fix w0 assume [ty]: "w0 be ComplexXCMPLX-0M1"
    obtain z w where 
      [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and zDef:"z = z0" and
      [ty]:"w be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and wDef:"w = w0"
      using xcmplx_0_def_2 sorry
    let ?U = "\<lambda>Lamb1. Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(Lamb1,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
    have " ex seq be Complex-SequenceCOMSEQ-1M1 st  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ?U(k)"
      using comseq_1_sch_1 sorry
    then obtain seq where
      [ty]:"seq be Complex-SequenceCOMSEQ-1M1" and 
      A1: " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
       sorry
    have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) (#)VALUED-1K20\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
    proof(rule ballI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 Partial-SumsCOMSEQ-3K10 (ConjSIN-COSK13(k,z,w)) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using A1 sorry
      also have "... = Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using sin_cos_th_15 sorry
      also have "... = (Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) (#)VALUED-1K20\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using valued_1_th_5 sorry
      also have "... = (Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) (#)VALUED-1K20\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using valued_1_th_8 sorry
      also have "... = (Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) (#)VALUED-1K20\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using valued_1_th_1 sorry
      finally show "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) (#)VALUED-1K20\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
         sorry
    qed "sorry"
    then have A2: "seq =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) (#)VALUED-1K20\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) -VALUED-1K48\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 ((z +XCMPLX-0K2 w)ExpSeqSIN-COSK4)"
       sorry
    have A3: "Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) (#)VALUED-1K20\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4) be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) (#)VALUED-1K20\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4)) =COMPLEX1R1 (limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4))*XCMPLX-0K3 (limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 (w ExpSeqSIN-COSK4))"
      using comseq_2_th_30 sorry
    have "limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
      using A1 sin_cos_th_22 sorry
    thus "SumCOMSEQ-3K11 (z0 ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 (w0 ExpSeqSIN-COSK4) =COMPLEX1R1 SumCOMSEQ-3K11 ((z0 +XCMPLX-0K2 w0)ExpSeqSIN-COSK4)"
      using A2 A3 comseq_3_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef sin_cos_def_14 ("expSIN-COSK14" 164 ) where
"func expSIN-COSK14 \<rightarrow> FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  \<lambda>it.  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds it .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
    proof-
      have " ex tVar9 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar9 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
      proof-
        let ?U = "\<lambda>Lamb1. SumCOMSEQ-3K11 (Lamb1 ExpSeqSIN-COSK4)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
          A1: " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 ?U(x)"
          using funct_2_sch_4 sorry
        show " ex tVar9 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st  for z be ComplexXCMPLX-0M1 holds tVar9 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
        proof(rule bexI[of _ "f"],rule ballI)
          fix z assume [ty]: "z be ComplexXCMPLX-0M1"
          have "z inHIDDENR3 COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          thus "f .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds it1 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)) & ( for z be ComplexXCMPLX-0M1 holds it2 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds ( for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)) implies (( for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)) implies f1 =FUNCT-2R2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
        assume A2: " for z be ComplexXCMPLX-0M1 holds f1 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
        assume A3: " for z be ComplexXCMPLX-0M1 holds f2 .FUNCT-1K1 z =COMPLEX1R1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
        have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
        proof-
          have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
          proof(rule ballI)
            fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
            have "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4)"
              using A2 sorry
            also have "... = f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
              using A3 sorry
            finally show "f1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =FUNCT-2R2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_15 ("expSIN-COSK15  _ " [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func expSIN-COSK15 z \<rightarrow> ComplexXCMPLX-0M1 equals
  (expSIN-COSK14).FUNCT-1K1 z"
proof-
  (*coherence*)
    show "(expSIN-COSK14).FUNCT-1K1 z be ComplexXCMPLX-0M1"
       sorry
qed "sorry"

abbreviation(input) SIN_COSK16("expSIN-COSK16  _ " [164]164) where
  "expSIN-COSK16 z \<equiv> expSIN-COSK15 z"

mtheorem sin_cos_add_1:
  mlet "z be ComplexXCMPLX-0M1"
"cluster expSIN-COSK15 z as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "expSIN-COSK15 z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem sin_cos_th_23:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds expSIN-COSK16 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (expSIN-COSK16 z1)*XCMPLX-0K3 (expSIN-COSK16 z2)"
proof(rule ballI,rule ballI)
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
  have "expSIN-COSK16 (z1 +XCMPLX-0K2 z2) =HIDDENR1 SumCOMSEQ-3K11 ((z1 +XCMPLX-0K2 z2)ExpSeqSIN-COSK4)"
    using sin_cos_def_14 sorry
  also have "... = SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 (z2 ExpSeqSIN-COSK4)"
    using sin_cos_lm_3 sorry
  also have "... = (expSIN-COSK16 z1)*XCMPLX-0K3 SumCOMSEQ-3K11 (z2 ExpSeqSIN-COSK4)"
    using sin_cos_def_14 sorry
  also have "... = (expSIN-COSK16 z1)*XCMPLX-0K3 (expSIN-COSK16 z2)"
    using sin_cos_def_14 sorry
  finally have "expSIN-COSK16 (z1 +XCMPLX-0K2 z2) =HIDDENR1 (expSIN-COSK16 z1)*XCMPLX-0K3 (expSIN-COSK16 z2)"
     sorry
  thus "expSIN-COSK16 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 (expSIN-COSK16 z1)*XCMPLX-0K3 (expSIN-COSK16 z2)"
     sorry
qed "sorry"

(*begin*)
reserve d for "RealXREAL-0M1"
mdef sin_cos_def_16 ("sinSIN-COSK17" 164 ) where
"func sinSIN-COSK17 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    proof-
      have " ex tVar10 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds tVar10 .FUNCT-1K1 x =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((x *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      proof-
        let ?U = "\<lambda>Lamb1. ImCOMPLEX1K4 SumCOMSEQ-3K11 ((Lamb1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
          using funct_2_sch_4 sorry
        show " ex tVar10 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds tVar10 .FUNCT-1K1 x =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((x *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
        proof(rule bexI[of _ "f"],rule ballI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          have 
            [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2"
            using xreal_0_def_1 sorry
          have "f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
            using A1 sorry
          thus "f .FUNCT-1K1 x =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((x *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) implies (( for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) implies f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A2: " for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
        assume A3: " for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =COMPLEX1R1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
          proof(rule ballI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            have "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
              using A2 sorry
            also have "... = f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
              using A3 sorry
            finally show "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_17 ("sinSIN-COSK18  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func sinSIN-COSK18 th \<rightarrow> numberORDINAL1M2 equals
  (sinSIN-COSK17).FUNCT-1K1 th"
proof-
  (*coherence*)
    show "(sinSIN-COSK17).FUNCT-1K1 th be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos_cl_3:
  mlet "th be RealXREAL-0M1"
"cluster sinSIN-COSK18 th as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "sinSIN-COSK18 th be realXREAL-0V1"
     sorry
qed "sorry"

mdef sin_cos_def_18 ("cosSIN-COSK19" 164 ) where
"func cosSIN-COSK19 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    proof-
      have " ex tVar11 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar11 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      proof-
        let ?U = "\<lambda>Lamb1. ReCOMPLEX1K3 SumCOMSEQ-3K11 ((Lamb1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
          using funct_2_sch_4 sorry
        show " ex tVar11 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar11 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
        proof(rule bexI[of _ "f"],rule ballI)
          fix d assume [ty]: "d be RealXREAL-0M1"
          have 
            [ty]:"d be ElementSUBSET-1M1-of REALNUMBERSK2"
            using xreal_0_def_1 sorry
          have "f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
            using A1 sorry
          thus "f .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) implies (( for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) implies f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A2: " for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
        assume A3: " for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =COMPLEX1R1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
          proof(rule ballI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            have "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((d *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
              using A2 sorry
            also have "... = f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
              using A3 sorry
            finally show "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_19 ("cosSIN-COSK20  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func cosSIN-COSK20 th \<rightarrow> numberORDINAL1M2 equals
  (cosSIN-COSK19).FUNCT-1K1 th"
proof-
  (*coherence*)
    show "(cosSIN-COSK19).FUNCT-1K1 th be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos_cl_4:
  mlet "th be RealXREAL-0M1"
"cluster cosSIN-COSK20 th as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "cosSIN-COSK20 th be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem sin_cos_th_24:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) =XBOOLE-0R4 REALNUMBERSK2 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) =XBOOLE-0R4 REALNUMBERSK2"
  using funct_2_def_1 sorry

mlemma sin_cos_lm_4:
" for th be RealXREAL-0M1 holds SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for th be RealXREAL-0M1 holds SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th & ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th"
      using sin_cos_def_16 sin_cos_def_18 sorry
    thus "SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_25:
" for th be RealXREAL-0M1 holds expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 cosSIN-COSK20 th +XCMPLX-0K2 (sinSIN-COSK18 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for th be RealXREAL-0M1 holds expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 cosSIN-COSK20 th +XCMPLX-0K2 (sinSIN-COSK18 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_def_14 sorry
    also have "... = cosSIN-COSK20 th +XCMPLX-0K2 (sinSIN-COSK18 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_lm_4 sorry
    finally have "expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 cosSIN-COSK20 th +XCMPLX-0K2 (sinSIN-COSK18 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 cosSIN-COSK20 th +XCMPLX-0K2 (sinSIN-COSK18 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos_lm_5:
" for th be RealXREAL-0M1 holds SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9 =COMPLEX1R1 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
proof-
  have " for th be RealXREAL-0M1 holds SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9 =COMPLEX1R1 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    proof-
      have A1: " for n be NatNAT-1M1 holds (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*'COMPLEX1K9 =COMPLEX1R1 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      proof-
        let ?X = "\<lambda>Lamb1. (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1)*'COMPLEX1K9 =COMPLEX1R1 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
        have "(((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))*'COMPLEX1K9 =HIDDENR1 1rCOMPLEX1K7"
          using sin_cos_th_3 complex1_th_30 sorry
        also have "... = ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
          using sin_cos_th_3 sorry
        finally have "(((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))*'COMPLEX1K9 =HIDDENR1 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
           sorry
        then have A2: "?X(0NUMBERSK6)"
           sorry
        have A3: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for n be NatNAT-1M1 holds (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*'COMPLEX1K9 =COMPLEX1R1 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*'COMPLEX1K9 =HIDDENR1 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume A4: "(((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*'COMPLEX1K9 =COMPLEX1R1 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
            have "(((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*'COMPLEX1K9 =HIDDENR1 ((((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))*'COMPLEX1K9"
              using sin_cos_th_3 sorry
            also have "... = (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))))*'COMPLEX1K9"
               sorry
            also have "... = ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*'COMPLEX1K9"
              using A4 complex1_th_35 sorry
            also have "... = ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((0NUMBERSK6 +XCMPLX-0K2 th *XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9 /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)*'COMPLEX1K9)"
              using complex1_th_37 sorry
            also have "... = ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 th)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9)"
              using sin_cos_lm_2 sorry
            also have "... = ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 th)*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
              using sin_cos_lm_2 sorry
            also have "... = (((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
               sorry
            also have "... = ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
              using sin_cos_th_3 sorry
            finally show "(((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*'COMPLEX1K9 =HIDDENR1 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for n be NatNAT-1M1 holds (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*'COMPLEX1K9 =COMPLEX1R1 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using nat_1_sch_2 A2 A3 sorry
      qed
      let ?X = "\<lambda>Lamb1. Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
      have "Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 (Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))*'COMPLEX1K9"
        using comseq_2_def_2 sorry
      also have "... = (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))*'COMPLEX1K9"
        using series_1_def_1 sorry
      also have "... = \<one>\<^sub>M"
        using sin_cos_th_3 complex1_th_30 sorry
      also have "... = ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
        using sin_cos_th_3 sorry
      also have "... = Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
        using series_1_def_1 sorry
      finally have "Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
         sorry
      then have A5: "?X(0NUMBERSK6)"
         sorry
      have A6: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A7: "Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          have A8: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*'COMPLEX1K9"
            using comseq_2_def_2 sorry
          also have "... = (Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*'COMPLEX1K9"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*'COMPLEX1K9 +XCMPLX-0K2 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*'COMPLEX1K9"
            using complex1_th_32 sorry
          also have "... = Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*'COMPLEX1K9"
            using A7 comseq_2_def_2 A8 sorry
          also have "... = Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
            using A1 sorry
          also have "... = Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          finally show "Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be NatNAT-1M1 holds ?X(n)"
        using nat_1_sch_2 A5 A6 sorry
      thus "Partial-SumsCOMSEQ-3K10 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMSEQ-2K2\<^bsub>(omegaORDINAL1K4)\<^esub> =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
         sorry
    qed
    thus "SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9 =COMPLEX1R1 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using comseq_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_26:
" for th be RealXREAL-0M1 holds (expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*'COMPLEX1K9 =COMPLEX1R1 expSIN-COSK16 (-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))"
proof-
  have " for th be RealXREAL-0M1 holds (expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*'COMPLEX1K9 =COMPLEX1R1 expSIN-COSK16 (-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "(expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*'COMPLEX1K9 =HIDDENR1 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9"
      using sin_cos_def_14 sorry
    also have "... = SumCOMSEQ-3K11 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_lm_5 sorry
    also have "... = expSIN-COSK16 (-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_def_14 sorry
    finally have "(expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*'COMPLEX1K9 =HIDDENR1 expSIN-COSK16 (-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    thus "(expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*'COMPLEX1K9 =COMPLEX1R1 expSIN-COSK16 (-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos_lm_6:
" for th be RealXREAL-0M1 holds  for th1 be RealXREAL-0M1 holds th =COMPLEX1R1 th1 implies ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).| =COMPLEX1R1 \<one>\<^sub>M &  |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 th1.| <=XXREAL-0R1 \<one>\<^sub>M) &  |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 th1.| <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for th be RealXREAL-0M1 holds  for th1 be RealXREAL-0M1 holds th =COMPLEX1R1 th1 implies  |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).| =COMPLEX1R1 \<one>\<^sub>M & ( |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 th1.| <=XXREAL-0R1 \<one>\<^sub>M &  |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 th1.| <=XXREAL-0R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    assume A1: "th =COMPLEX1R1 th1"
    have A2: "SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =HIDDENR1 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8) +XCMPLX-0K2 (-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8)))ExpSeqSIN-COSK4)"
      using sin_cos_lm_3 sorry
    also have "... = 1rCOMPLEX1K7"
      using sin_cos_th_9 sorry
    finally have "SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =HIDDENR1 1rCOMPLEX1K7"
       sorry
    have "( |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|)*XCMPLX-0K3 ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|) =HIDDENR1  |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .|"
      using complex1_th_65 sorry
    also have "... =  |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9 .|"
      using complex1_th_69 sorry
    also have "... = \<one>\<^sub>M"
      using A2 sin_cos_lm_5 complex1_th_48 sorry
    finally have "( |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|)*XCMPLX-0K3 ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A3: " |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).| =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|) &  |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).| <>HIDDENR2 0NUMBERSK6"
      using xcmplx_1_th_73 sorry
    have " |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).| <>HIDDENR2 -XCMPLX-0K4 \<one>\<^sub>M"
      using complex1_th_46 sorry
    thus A4: " |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).| =COMPLEX1R1 \<one>\<^sub>M"
      using A3 xcmplx_1_th_199 sorry
    have " |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 th.| =COMPLEX1R1  |.COMPLEX1K10 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).| &  |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 th.| =COMPLEX1R1  |.COMPLEX1K10 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|"
      using sin_cos_def_16 sin_cos_def_18 sorry
    thus " |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 th1.| <=XXREAL-0R1 \<one>\<^sub>M &  |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 th1.| <=XXREAL-0R1 \<one>\<^sub>M"
      using A1 A4 comseq_3_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_27:
" for th be RealXREAL-0M1 holds  |.COMPLEX1K10 expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) .| =COMPLEX1R1 \<one>\<^sub>M & ( for th be RealXREAL-0M1 holds  |.COMPLEX1K10 sinSIN-COSK18 th .| <=XXREAL-0R1 \<one>\<^sub>M &  |.COMPLEX1K10 cosSIN-COSK20 th .| <=XXREAL-0R1 \<one>\<^sub>M)"
proof-
  have " for th be RealXREAL-0M1 holds  |.COMPLEX1K10 expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) .| =HIDDENR1 \<one>\<^sub>M & ( for th be RealXREAL-0M1 holds  |.COMPLEX1K10 sinSIN-COSK18 th .| <=XXREAL-0R1 \<one>\<^sub>M &  |.COMPLEX1K10 cosSIN-COSK20 th .| <=XXREAL-0R1 \<one>\<^sub>M)"
  proof(rule ballI,rule conjMI,rule ballI,rule conjMI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have " |.COMPLEX1K10 expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) .| =HIDDENR1  |.COMPLEX1K10 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|"
      using sin_cos_def_14 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_lm_6 sorry
    finally show " |.COMPLEX1K10 expSIN-COSK16 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) .| =HIDDENR1 \<one>\<^sub>M"
       sorry
    fix th assume [ty]: "th be RealXREAL-0M1"
    show " |.COMPLEX1K10 sinSIN-COSK18 th .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_lm_6 sorry
    show " |.COMPLEX1K10 cosSIN-COSK20 th .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_lm_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve th, th1, th2 for "RealXREAL-0M1"
mtheorem sin_cos_th_28:
" for th be RealXREAL-0M1 holds ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 th)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M & (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for th be RealXREAL-0M1 holds ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 th)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M & (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI,rule conjMI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    obtain th1 where 
      [ty]:"th1 be RealXREAL-0M1" and th1Def:"th1 = th"
       sorry
    have A1: "SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =HIDDENR1 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8) +XCMPLX-0K2 (-XCMPLX-0K4 th1 *XCMPLX-0K3 (<i>COMPLEX1K8)))ExpSeqSIN-COSK4)"
      using sin_cos_lm_3 sorry
    also have "... = 1rCOMPLEX1K7"
      using sin_cos_th_9 sorry
    finally have "SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =HIDDENR1 1rCOMPLEX1K7"
       sorry
    have "((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 th)^2SQUARE-1K1 =HIDDENR1 (ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 th)^2SQUARE-1K1"
      using sin_cos_def_18 sorry
    also have "... = (ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))^2SQUARE-1K1"
      using sin_cos_def_16 sorry
    also have "... =  |.COMPLEX1K10 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .|"
      using complex1_th_68 sorry
    also have "... =  |.COMPLEX1K10 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9 .|"
      using complex1_th_69 sorry
    also have "... = \<one>\<^sub>M"
      using A1 sin_cos_lm_5 complex1_th_48 sorry
    finally show "((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 th)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "(cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_29:
" for th be RealXREAL-0M1 holds (cosSIN-COSK20 th)^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 th)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M & (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) +XCMPLX-0K2 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) =COMPLEX1R1 \<one>\<^sub>M"
  using sin_cos_th_28 sorry

mtheorem sin_cos_th_30:
" for th be RealXREAL-0M1 holds (((cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th) & (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
proof-
  have " for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M & ((sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6 & ((cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th & (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th))"
  proof(rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "(cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (((0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_def_18 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_9 complex1_th_6 sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have "(sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 ImCOMPLEX1K4 SumCOMSEQ-3K11 (((0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_def_16 sorry
    also have "... = 0NUMBERSK6"
      using sin_cos_th_9 complex1_th_6 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
    obtain th1 where 
      [ty]:"th1 be RealXREAL-0M1" and th1Def:"th1 = th"
       sorry
    have "(cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th) =HIDDENR1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (((-XCMPLX-0K4 0NUMBERSK6)+XCMPLX-0K2 (-XCMPLX-0K4 th1)*XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_def_18 sorry
    also have "... = ReCOMPLEX1K3 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
       sorry
    also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9)"
      using sin_cos_lm_5 sorry
    also have "... = ReCOMPLEX1K3 (((cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9)"
      using sin_cos_lm_4 sorry
    also have "... = ReCOMPLEX1K3 ((cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_lm_2 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th"
      using complex1_th_12 sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
    have "(sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th) =HIDDENR1 ImCOMPLEX1K4 SumCOMSEQ-3K11 (((-XCMPLX-0K4 0NUMBERSK6)+XCMPLX-0K2 (-XCMPLX-0K4 th1)*XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_def_16 sorry
    also have "... = ImCOMPLEX1K4 SumCOMSEQ-3K11 ((-XCMPLX-0K4 th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
       sorry
    also have "... = ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *'COMPLEX1K9)"
      using sin_cos_lm_5 sorry
    also have "... = ImCOMPLEX1K4 (((cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (<i>COMPLEX1K8))*'COMPLEX1K9)"
      using sin_cos_lm_4 sorry
    also have "... = ImCOMPLEX1K4 ((cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_lm_2 sorry
    also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
      using complex1_th_12 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_31:
" for th be RealXREAL-0M1 holds ((cosSIN-COSK20 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & sinSIN-COSK18 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) & cosSIN-COSK20 (-XCMPLX-0K4 th) =COMPLEX1R1 cosSIN-COSK20 th) & sinSIN-COSK18 (-XCMPLX-0K4 th) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 th"
  using sin_cos_th_30 sorry

mdef sin_cos_def_20 (" _ P-sinSIN-COSK21" [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func th P-sinSIN-COSK21 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
    proof-
      let ?U = "\<lambda>Lamb1. ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Lamb1 *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      proof-
        have " ex s be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        proof-
          show " ex s be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using seq_1_sch_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
    proof-
      let ?U = "\<lambda>Lamb1. ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Lamb1 *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
      proof-
        have " for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 x *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 x +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 x +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) & ( for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 x *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 x +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 x +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) implies s1 =HIDDENR1 s2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
          fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
          assume A1: " for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
            and A2: " for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
          have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
          proof(rule ballI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 x *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 x +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 x +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using A1 sorry
            also have "... = s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
              using A2 sorry
            finally show "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
               sorry
          qed "sorry"
          thus "s1 =HIDDENR1 s2"
            using funct_2_def_8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef sin_cos_def_21 (" _ P-cosSIN-COSK22" [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func th P-cosSIN-COSK22 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)"
    proof-
      let ?U = "\<lambda>Lamb1. ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Lamb1 *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      let ?U = "\<lambda>Lamb1. ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Lamb1 *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 Lamb1)!SIN-COSK3)"
      show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)"
      proof-
        have " ex s be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)"
        proof-
          show " ex s be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)"
            using seq_1_sch_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
    proof-
      let ?U = "\<lambda>Lamb1. ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Lamb1 *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      let ?U = "\<lambda>Lamb1. ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Lamb1 *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 Lamb1)!SIN-COSK3)"
      show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 n *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
      proof-
        have " for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 x *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 x)!SIN-COSK3)) & ( for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 x *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 x)!SIN-COSK3)) implies s1 =HIDDENR1 s2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
          fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
          assume A3: " for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
            and A4: " for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
          have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
          proof(rule ballI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 x *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 x)!SIN-COSK3)"
              using A3 sorry
            also have "... = s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
              using A4 sorry
            finally show "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
               sorry
          qed "sorry"
          thus "s1 =HIDDENR1 s2"
            using funct_2_def_8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem sin_cos_th_32:
" for z be ComplexXCMPLX-0M1 holds  for k be NatNAT-1M1 holds z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 k) |^COMSEQ-3K2 \<two>\<^sub>M & z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k"
proof(rule ballI,rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  let ?X = "\<lambda>Lamb1. z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1) =COMPLEX1R1 (z  |^COMSEQ-3K2 Lamb1) |^COMSEQ-3K2 \<two>\<^sub>M & z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1) =COMPLEX1R1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 Lamb1"
  have A1: "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)) =HIDDENR1 \<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
    using newton_th_4 sorry
  also have "... = \<one>\<^sub>M  |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M"
     sorry
  also have "... = \<one>\<^sub>M  |^COMSEQ-3K2 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
     sorry
  also have "... = (z  |^COMSEQ-3K2 (0NUMBERSK6)) |^COMSEQ-3K2 \<two>\<^sub>M"
    using newton_th_4 sorry
  finally have "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)) =HIDDENR1 (z  |^COMSEQ-3K2 (0NUMBERSK6)) |^COMSEQ-3K2 \<two>\<^sub>M"
     sorry
  have "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)) =HIDDENR1 \<one>\<^sub>M"
    using newton_th_4 sorry
  also have "... = (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6)"
    using newton_th_4 sorry
  finally have "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)) =HIDDENR1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6)"
     sorry
  then have A2: "?X(0NUMBERSK6)"
    using A1 sorry
  have A3: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for k be NatNAT-1M1 holds z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 k) |^COMSEQ-3K2 \<two>\<^sub>M & z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k implies z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)) |^COMSEQ-3K2 \<two>\<^sub>M & z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impMI ,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 k) |^COMSEQ-3K2 \<two>\<^sub>M"
        and A5: "z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k"
      have A6: "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
         sorry
      also have "... = z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z"
        using comseq_3_def_1 sorry
      also have "... = (z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) *XCMPLX-0K3 z)*XCMPLX-0K3 z"
        using comseq_3_def_1 sorry
      finally have "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) *XCMPLX-0K3 z)*XCMPLX-0K3 z"
         sorry
      then have A7: "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((z  |^COMSEQ-3K2 k)GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z)*XCMPLX-0K3 z"
        using A4 sorry
      also have "... = (((z  |^COMSEQ-3K2 k)GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 z)*XCMPLX-0K3 z"
        using comseq_3_def_1 sorry
      also have "... = ((((z  |^COMSEQ-3K2 k)GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 z)*XCMPLX-0K3 z"
        using comseq_3_def_1 sorry
      also have "... = (((1rCOMPLEX1K7 *XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 z  |^COMSEQ-3K2 k)*XCMPLX-0K3 z)*XCMPLX-0K3 z"
        using comseq_3_def_1 sorry
      also have "... = (1rCOMPLEX1K7 *XCMPLX-0K3 (z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z))*XCMPLX-0K3 (z  |^COMSEQ-3K2 k *XCMPLX-0K3 z)"
         sorry
      also have "... = (1rCOMPLEX1K7 *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z)"
        using comseq_3_def_1 sorry
      also have "... = (1rCOMPLEX1K7 *XCMPLX-0K3 z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using comseq_3_def_1 sorry
      also have "... = ((z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M))GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
        using comseq_3_def_1 sorry
      also have "... = (z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M))GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
        using comseq_3_def_1 sorry
      also have "... = (z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M))GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
        using comseq_3_def_1 sorry
      also have "... = (z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)) |^COMSEQ-3K2 \<two>\<^sub>M"
         sorry
      finally have "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)) |^COMSEQ-3K2 \<two>\<^sub>M"
         sorry
      have "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 ((1rCOMPLEX1K7 *XCMPLX-0K3 z)*XCMPLX-0K3 z)"
        using A5 A6 sorry
      also have "... = (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 ((z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z)*XCMPLX-0K3 z)"
        using comseq_3_def_1 sorry
      also have "... = (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 (z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z)"
        using comseq_3_def_1 sorry
      also have "... = (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
        using comseq_3_def_1 sorry
      also have "... = (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
        using comseq_3_def_1 sorry
      finally have "z  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)) |^COMSEQ-3K2 \<two>\<^sub>M & z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
        using A7 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have " for k be NatNAT-1M1 holds ?X(k)"
    using nat_1_sch_2 A2 A3 sorry
  thus "z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 k) |^COMSEQ-3K2 \<two>\<^sub>M & z  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (z  |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k"
     sorry
qed "sorry"

mtheorem sin_cos_th_33:
" for k be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) & (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for k be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) & (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix th assume [ty]: "th be RealXREAL-0M1"
    have A1: "((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))*XCMPLX-0K3 (<i>COMPLEX1K8) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_def_1 sorry
    also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_th_3 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_def_1 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_th_3 sorry
    finally have "((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))*XCMPLX-0K3 (<i>COMPLEX1K8) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    let ?X = "\<lambda>Lamb1. (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Lamb1 *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1) & (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Lamb1 *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    have "((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_def_1 sorry
    also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 (th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 th))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_th_3 sorry
    also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 th))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_th_3 sorry
    also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_def_1 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using prepower_th_3 sorry
    also have "... = th *XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8) =HIDDENR1 th *XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    then have A2: "?X(0NUMBERSK6)"
      using A1 comseq_3_def_1 sorry
    have A3: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) & (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8) implies (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)) & (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      proof(rule ballI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A4: "(th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k)"
          and A5: "(th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        have A6: "(th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
          using sin_cos_th_32 sorry
        also have "... = ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 \<two>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 \<two>\<^sub>M"
          using comseq_3_def_1 sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8))GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using A4 sin_cos_th_32 sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          using comseq_3_def_1 sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          using comseq_3_def_1 sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 ((1rCOMPLEX1K7 *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          using comseq_3_def_1 sorry
        also have "... = ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 th)*XCMPLX-0K3 th"
           sorry
        also have "... = ((((-XCMPLX-0K4 \<one>\<^sub>M)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 th)*XCMPLX-0K3 th"
          using prepower_def_1 sorry
        also have "... = (((-XCMPLX-0K4 \<one>\<^sub>M)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 th)*XCMPLX-0K3 th"
          using prepower_th_3 sorry
        also have "... = (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 th)*XCMPLX-0K3 th"
          using prepower_def_1 sorry
        also have "... = (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k))*XCMPLX-0K3 th)*XCMPLX-0K3 th"
          using prepower_def_1 sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k) *XCMPLX-0K3 th))*XCMPLX-0K3 th"
           sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 th"
          using prepower_th_3 sorry
        also have "... = (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th)"
           sorry
        also have "... = (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using prepower_th_3 sorry
        also have "... = (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))"
          using prepower_def_1 sorry
        finally have "(th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))"
           sorry
        have "(th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (th *XCMPLX-0K3 (<i>COMPLEX1K8))GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8))"
          using comseq_3_def_1 sorry
        also have "... = ((th *XCMPLX-0K3 (<i>COMPLEX1K8))GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8))"
          using comseq_3_def_1 sorry
        also have "... = (((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 th)*XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using A5 sorry
        also have "... = (((((-XCMPLX-0K4 \<one>\<^sub>M)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 th)*XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using prepower_def_1 sorry
        also have "... = ((((-XCMPLX-0K4 \<one>\<^sub>M)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 th)*XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using prepower_th_3 sorry
        also have "... = ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 th)*XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using prepower_def_1 sorry
        also have "... = ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 th)*XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using prepower_def_1 sorry
        also have "... = (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th))*XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
        also have "... = (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 th)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using prepower_th_3 sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th))*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using prepower_th_3 sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using prepower_def_1 sorry
        finally have "(th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
        thus "(th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)) & (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds ?X(k)"
      using nat_1_sch_2 A2 A3 sorry
    thus "(th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k) & (th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem sin_cos_th_35:
" for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n)"
proof-
  have " for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix th assume [ty]: "th be RealXREAL-0M1"
    have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n)"
    proof-
      have A1: "Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (th P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using series_1_def_1 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using sin_cos_def_20 sorry
      finally have "Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
         sorry
      have A2: "(\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3 =HIDDENR1 ((0NUMBERSK6)!SIN-COSK3)*XCMPLX-0K3 \<one>\<^sub>M"
        using newton_th_15 sorry
      also have "... = \<one>\<^sub>M"
        using newton_th_12 sorry
      finally have "(\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3 =HIDDENR1 \<one>\<^sub>M"
         sorry
      have A3: "(-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using prepower_def_1 sorry
      also have "... = \<one>\<^sub>M"
        using prepower_th_3 sorry
      finally have "(-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
         sorry
      have A4: "Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using series_1_def_1 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))!SIN-COSK3)"
        using sin_cos_def_21 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6))/XCMPLX-0K7 \<one>\<^sub>M"
        using A3 newton_th_12 prepower_def_1 sorry
      also have "... = \<one>\<^sub>M"
        using prepower_th_3 sorry
      finally have "Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
         sorry
      have A5: "ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 ImCOMPLEX1K4 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)) & ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =COMPLEX1R1 ImCOMPLEX1K4 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M)"
        using comseq_3_def_6 sorry
      have A6: "th *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 th *XCMPLX-0K3 (<i>COMPLEX1K8)"
         sorry
      have A7: "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
        using series_1_def_1 sorry
      also have "... = ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
        using series_1_def_1 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))"
        using A5 sin_cos_th_3 complex1_th_6 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 ((((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
        using sin_cos_th_3 sorry
      also have "... = ImCOMPLEX1K4 ((\<one>\<^sub>M *XCMPLX-0K3 (th *XCMPLX-0K3 (<i>COMPLEX1K8)))/XCMPLX-0K7 \<one>\<^sub>M)"
        using sin_cos_th_3 sorry
      also have "... = th"
        using A6 complex1_th_12 sorry
      finally have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 th"
         sorry
      let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 Lamb1)"
      have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)) =HIDDENR1 ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using series_1_def_1 sorry
      also have "... = ReCOMPLEX1K3 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
        using comseq_3_def_5 sorry
      also have "... = \<one>\<^sub>M"
        using sin_cos_th_3 complex1_th_6 sorry
      finally have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)) =HIDDENR1 \<one>\<^sub>M"
         sorry
      then have A8: "?X(0NUMBERSK6)"
        using A1 A2 A3 A4 A7 sorry
      have A9: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k) implies Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M))"
        proof(rule ballI,rule impMI ,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A10: "Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)"
            and A11: "Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k)"
          have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +REAL-1K3 ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))+REAL-1K3 ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using A10 series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))))+REAL-1K3 ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using comseq_3_def_6 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))))+REAL-1K3 ImCOMPLEX1K4 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))"
            using comseq_3_def_6 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)))+REAL-1K3 ImCOMPLEX1K4 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))"
            using sin_cos_def_4 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)))+REAL-1K3 ImCOMPLEX1K4 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
            using sin_cos_def_4 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)))+REAL-1K3 ImCOMPLEX1K4 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
            using sin_cos_th_33 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)))+REAL-1K3 ImCOMPLEX1K4 ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
            using sin_cos_th_33 sorry
          finally have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)))+REAL-1K3 ImCOMPLEX1K4 ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
             sorry
          then have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3) +XCMPLX-0K2 ((0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3))*XCMPLX-0K3 (<i>COMPLEX1K8)))+REAL-1K3 ImCOMPLEX1K4 ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
             sorry
          then have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +XCMPLX-0K2 0NUMBERSK6)+XCMPLX-0K2 ImCOMPLEX1K4 ((0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (<i>COMPLEX1K8))"
            using complex1_th_12 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +XCMPLX-0K2 (0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3))+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using complex1_th_12 sorry
          finally have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +XCMPLX-0K2 (0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3))+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
             sorry
          then have A12: "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (th P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using sin_cos_def_20 sorry
          also have "... = Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          finally have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
          have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))+REAL-1K3 ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
            using A11 series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)))+REAL-1K3 ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
            using comseq_3_def_5 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)))+REAL-1K3 ReCOMPLEX1K3 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
            using comseq_3_def_5 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))+REAL-1K3 ReCOMPLEX1K3 (((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
            using sin_cos_def_4 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))+REAL-1K3 ReCOMPLEX1K3 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) /XCMPLX-0K7 (((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
            using sin_cos_def_4 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))+REAL-1K3 ReCOMPLEX1K3 ((th *XCMPLX-0K3 (<i>COMPLEX1K8)) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3))"
            using sin_cos_th_33 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))+REAL-1K3 ReCOMPLEX1K3 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3))"
            using sin_cos_th_33 sorry
          finally have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 ((((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))+REAL-1K3 ReCOMPLEX1K3 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3))"
             sorry
          then have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 ((0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 k *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (<i>COMPLEX1K8)))+REAL-1K3 ReCOMPLEX1K3 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3))"
             sorry
          then have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +XCMPLX-0K2 (0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))+XCMPLX-0K2 ReCOMPLEX1K3 (((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3) +XCMPLX-0K2 ((0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3))*XCMPLX-0K3 (<i>COMPLEX1K8))"
            using complex1_th_12 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +XCMPLX-0K2 (0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
            using complex1_th_12 sorry
          finally have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +XCMPLX-0K2 (0NUMBERSK6)/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
             sorry
          then have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using sin_cos_def_21 sorry
          also have "... = Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          finally have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
          thus "Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M))"
            using A12 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n)"
        using nat_1_sch_2 A8 A9 sorry
    qed
    thus "Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_36:
" for th be RealXREAL-0M1 holds ((Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) be convergentCOMSEQ-2V3 & SumSERIES-1K4 (th P-sinSIN-COSK21) =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) be convergentCOMSEQ-2V3) & SumSERIES-1K4 (th P-cosSIN-COSK22) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
proof(rule ballI)
  fix th assume [ty]: "th be RealXREAL-0M1"
  have A1: "SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) *XCMPLX-0K3 (<i>COMPLEX1K8)"
    using comseq_3_th_53 sorry
  then have A2: "SumSERIES-1K4 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using complex1_th_12 sorry
  have A3: "SumSERIES-1K4 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using A1 complex1_th_12 sorry
  have A4: "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) be convergentCOMSEQ-2V3 & limSEQ-2K1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using A2 series_1_def_2 series_1_def_3 sorry
  have A5: "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) be convergentCOMSEQ-2V3 & limSEQ-2K1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using A3 series_1_def_2 series_1_def_3 sorry
  have A6: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p)"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume "p >XXREAL-0R4 0NUMBERSK6"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A7: " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
      using A4 seq_2_def_7 sorry
    show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
    proof(rule bexI[of _ "n"])
      have " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A8: "n <=XXREAL-0R1 k"
        have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| =COMPLEX1R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k) -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| & \<two>\<^sub>M *XCMPLX-0K3 k =COMPLEX1R1 k +XCMPLX-0K2 k"
          using sin_cos_th_35 sorry
        thus " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
          using A7 A8 nat_1_th_12 sorry
      qed "sorry"
      thus " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
         sorry
    qed "sorry"
  qed "sorry"
  then have "Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) be convergentCOMSEQ-2V3"
    using seq_2_def_6 sorry
  then have A9: "limSEQ-2K1 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using A6 seq_2_def_7 sorry
  have A10: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p)"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume "p >XXREAL-0R4 0NUMBERSK6"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A11: " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
      using A5 seq_2_def_7 sorry
    show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
    proof(rule bexI[of _ "n"])
      have " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A12: "n <=XXREAL-0R1 k"
        have A13: " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| =COMPLEX1R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .|"
          using sin_cos_th_35 sorry
        have "\<two>\<^sub>M *XCMPLX-0K3 k =COMPLEX1R1 k +XCMPLX-0K2 k"
           sorry
        then have "n <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 k"
          using A12 nat_1_th_12 sorry
        then have "n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        thus " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
          using A11 A13 sorry
      qed "sorry"
      thus " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) .| <XXREAL-0R3 p"
         sorry
    qed "sorry"
  qed "sorry"
  then have "Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) be convergentCOMSEQ-2V3"
    using seq_2_def_6 sorry
  then have "limSEQ-2K1 Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using A10 seq_2_def_7 sorry
  thus "((Partial-SumsSERIES-1K3 (th P-sinSIN-COSK21) be convergentCOMSEQ-2V3 & SumSERIES-1K4 (th P-sinSIN-COSK21) =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)) & Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) be convergentCOMSEQ-2V3) & SumSERIES-1K4 (th P-cosSIN-COSK22) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using A6 A9 A10 seq_2_def_6 series_1_def_3 sorry
qed "sorry"

mtheorem sin_cos_th_37:
" for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-cosSIN-COSK22) & (sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-sinSIN-COSK21)"
proof-
  have " for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-cosSIN-COSK22) & (sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-sinSIN-COSK21)"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have 
      [ty]:"th be RealXREAL-0M1"
       sorry
    have "(sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) & (cosSIN-COSK19).FUNCT-1K1 th =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((th *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_def_16 sin_cos_def_18 sorry
    thus "(cosSIN-COSK19).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-cosSIN-COSK22) & (sinSIN-COSK17).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-sinSIN-COSK21)"
      using sin_cos_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_38:
" for p be RealXREAL-0M1 holds  for th be RealXREAL-0M1 holds  for rseq be Real-SequenceSEQ-1M1 holds (rseq be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq =COMPLEX1R1 th) & ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 p) implies th >=XXREAL-0R2 p"
  using prepower_th_1 sorry

mlemma sin_cos_lm_7:
" for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds  for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) =COMPLEX1R1 (th  |^COMSEQ-3K2 n) |^COMSEQ-3K2 \<two>\<^sub>M & (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) =COMPLEX1R1 \<one>\<^sub>M) & (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds  for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) =COMPLEX1R1 (th  |^COMSEQ-3K2 n) |^COMSEQ-3K2 \<two>\<^sub>M & ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) =COMPLEX1R1 \<one>\<^sub>M & (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix th assume [ty]: "th be RealXREAL-0M1"
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    obtain Dn where 
      [ty]:"Dn be ElementSUBSET-1M1-of NATNUMBERSK1" and DnDef:"Dn = \<two>\<^sub>M *XCMPLX-0K3 n"
      using ordinal1_def_12 sorry
    show "th  |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) =COMPLEX1R1 (th  |^COMSEQ-3K2 n) |^COMSEQ-3K2 \<two>\<^sub>M"
      using newton_th_9 sorry
    have "(-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Dn =HIDDENR1 \<one>\<^sub>M  |^COMSEQ-3K2 Dn"
      using power_th_1 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally have "(-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 Dn =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus A1: "(-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) =COMPLEX1R1 \<one>\<^sub>M"
       sorry
    have "(-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
      using A1 sorry
    finally show "(-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_39:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 k implies n !SIN-COSK3 <=XXREAL-0R1 k !SIN-COSK3"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 k implies n !SIN-COSK3 <=XXREAL-0R1 k !SIN-COSK3"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n <=XXREAL-0R1 k"
    have A2: " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
    proof(rule ballI)
      fix m assume [ty]: "m be NatNAT-1M1"
      have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      thus "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
         sorry
    qed "sorry"
    let ?U = "\<lambda>Lamb1. Lamb1 !SIN-COSK3"
    obtain rseq where
      [ty]:"rseq be Real-SequenceSEQ-1M1" and 
      A3: " for l be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l =COMPLEX1R1 ?U(l)"
      using seq_1_sch_1 sorry
    have " for l be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) & rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for l be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) &  not rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI)
        fix l assume [ty]: "l be NatNAT-1M1"
        let ?X = "\<lambda>Lamb1. rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M) & rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >XXREAL-0R4 0NUMBERSK6"
        have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3"
          using A3 sorry
        also have "... = ((0NUMBERSK6)!SIN-COSK3)*XCMPLX-0K3 \<one>\<^sub>M"
          using newton_th_15 sorry
        also have "... = \<one>\<^sub>M"
          using newton_th_12 sorry
        finally have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
           sorry
        then have A4: "?X(0NUMBERSK6)"
          using A3 newton_th_12 sorry
        have A5: " for l be NatNAT-1M1 holds ?X(l) implies ?X(l +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for l be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) & rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l >XXREAL-0R4 0NUMBERSK6 implies rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          proof(rule ballI,rule impI)
            fix l assume [ty]: "l be NatNAT-1M1"
            assume A6: "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) & rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l >XXREAL-0R4 0NUMBERSK6"
            have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!SIN-COSK3"
              using A3 sorry
            also have "... = ((l +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 ((l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
              using newton_th_15 sorry
            also have "... = rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
              using A3 sorry
            finally have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
               sorry
            thus "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
              using A2 A6 xreal_1_th_151 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " for l be NatNAT-1M1 holds ?X(l)"
          using nat_1_sch_2 A4 A5 sorry
        thus "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (l +NAT-1K1 \<one>\<^sub>M) &  not rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A7: "rseq be non-decreasingVALUED-0V11"
       sorry
    have "n !SIN-COSK3 =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & k !SIN-COSK3 =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
      using A3 sorry
    thus "n !SIN-COSK3 <=XXREAL-0R1 k !SIN-COSK3"
      using A1 A7 seqm_3_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_40:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 th & th <=XXREAL-0R1 \<one>\<^sub>M) & n <=XXREAL-0R1 k implies th  |^COMSEQ-3K2 k <=XXREAL-0R1 th  |^COMSEQ-3K2 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for th be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 th & (th <=XXREAL-0R1 \<one>\<^sub>M & n <=XXREAL-0R1 k) implies th  |^COMSEQ-3K2 k <=XXREAL-0R1 th  |^COMSEQ-3K2 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 th"
      and A2: "th <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "n <=XXREAL-0R1 k"
    have " for m be NatNAT-1M1 holds th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m >=XXREAL-0R2 0NUMBERSK6"
    proof(rule ballI)
      fix m assume [ty]: "m be NatNAT-1M1"
      let ?X = "\<lambda>Lamb1. th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 & th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >=XXREAL-0R2 0NUMBERSK6"
      have "th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 th"
        using prepower_th_3 sorry
      also have "... = \<one>\<^sub>M *XCMPLX-0K3 th"
        using prepower_th_3 sorry
      also have "... = th"
         sorry
      finally have "th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 th"
         sorry
      then have A4: "?X(0NUMBERSK6)"
        using A2 prepower_th_3 sorry
      have A5: " for m be NatNAT-1M1 holds ?X(m) implies ?X(m +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for m be NatNAT-1M1 holds th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m >=XXREAL-0R2 0NUMBERSK6 implies th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) & th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6"
        proof(rule ballI,rule impMI ,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
            and A6: "th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m >=XXREAL-0R2 0NUMBERSK6"
          have "th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th & th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 th"
            using prepower_th_3 sorry
          thus "th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) & th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6"
            using A1 A2 A6 xreal_1_th_153 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for m be NatNAT-1M1 holds ?X(m)"
        using nat_1_sch_2 A4 A5 sorry
      thus "th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m >=XXREAL-0R2 0NUMBERSK6"
         sorry
    qed "sorry"
    then have A7: "th GeoSeqPREPOWERK1 be non-increasingVALUED-0V12"
       sorry
    have "th  |^COMSEQ-3K2 k =COMPLEX1R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k & th  |^COMSEQ-3K2 n =COMPLEX1R1 th GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using prepower_def_1 sorry
    thus "th  |^COMSEQ-3K2 k <=XXREAL-0R1 th  |^COMSEQ-3K2 n"
      using A3 A7 seqm_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem sin_cos_th_42:
" for p be RealXREAL-0M1 holds ImCOMPLEX1K4 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) =COMPLEX1R1 0NUMBERSK6"
proof(rule ballI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  have A1: " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 0NUMBERSK6"
    have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = ImCOMPLEX1K4 ((p ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
      using comseq_3_def_6 sorry
    also have "... = 0NUMBERSK6"
      using sin_cos_th_3 complex1_th_6 sorry
    finally have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
    then have A2: "?X(0NUMBERSK6)"
       sorry
    have A3: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6 implies Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 0NUMBERSK6"
        then have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ImCOMPLEX1K4 ((p ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using comseq_3_def_6 sorry
        also have "... = ImCOMPLEX1K4 (p  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
          using sin_cos_def_4 sorry
        also have "... = ImCOMPLEX1K4 (p  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
           sorry
        also have "... = 0NUMBERSK6"
          using complex1_th_12 sorry
        finally have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
           sorry
        thus "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A2 A3 sorry
    thus "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
       sorry
  qed "sorry"
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    have "m inTARSKIR2 NATNUMBERSK1 & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
      using A1 ordinal1_def_12 sorry
    thus "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
      using A1 sorry
  qed "sorry"
  then have A4: "limSEQ-2K1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) =HIDDENR1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
    using seq_4_th_26 valued_0_th_24 sorry
  also have "... = 0NUMBERSK6"
    using A1 sorry
  finally have "limSEQ-2K1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) =HIDDENR1 0NUMBERSK6"
     sorry
  have "ImCOMPLEX1K4 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) =HIDDENR1 ImCOMPLEX1K4 (SumSERIES-1K4 (ReCOMSEQ-3K7 (p ExpSeqSIN-COSK4)) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4)) *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using comseq_3_th_53 sorry
  also have "... = SumSERIES-1K4 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4))"
    using complex1_th_12 sorry
  finally have "ImCOMPLEX1K4 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) =HIDDENR1 SumSERIES-1K4 (ImCOMSEQ-3K8 (p ExpSeqSIN-COSK4))"
     sorry
  thus "ImCOMPLEX1K4 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) =COMPLEX1R1 0NUMBERSK6"
    using A4 series_1_def_3 sorry
qed "sorry"

mtheorem sin_cos_th_43:
"((cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M"
proof-
  have "( not (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 &  not (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6) &  not (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M"
  proof-
    have A1: "Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) be convergentCOMSEQ-2V3"
      using sin_cos_th_36 sorry
    have A2: "(cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 SumSERIES-1K4 (\<one>\<^sub>M P-cosSIN-COSK22)"
      using sin_cos_th_37 sorry
    let ?U = "\<lambda>Lamb1. \<two>\<^sub>M *XCMPLX-0K3 Lamb1 +XCMPLX-0K2 \<one>\<^sub>M"
    obtain bq where
      [ty]:"bq be Real-SequenceSEQ-1M1" and 
      Lm6: " for n be NatNAT-1M1 holds bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
      using seq_1_sch_1 sorry
    have "bq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    proof-
      have A1: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <XXREAL-0R3 k implies bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
      proof-
        have " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <XXREAL-0R3 k implies  not bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
        proof(rule ballI,rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "n <XXREAL-0R3 k"
          then have "\<two>\<^sub>M *XCMPLX-0K3 n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 k"
            using xreal_1_th_68 sorry
          then have "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M"
            using xreal_1_th_6 sorry
          then have "bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M"
            using Lm6 sorry
          thus " not bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            using Lm6 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be NatNAT-1M1 holds bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
           sorry
        thus "bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using Lm6 sorry
      qed "sorry"
      thus "bq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
        using A1 seqm_3_th_1 seqm_3_th_13 sorry
    qed
    then have 
      [ty]:"bq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
       sorry
    have "limSEQ-2K1 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq) =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22)"
      using A1 seq_4_th_17 sorry
    then have A3: "limSEQ-2K1 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M"
      using A2 series_1_def_3 sorry
    have " for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      let ?X = "\<lambda>Lamb1. (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
      have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6))"
        using funct_2_th_15 sorry
      also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)"
        using Lm6 sorry
      also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))!SIN-COSK3) +XCMPLX-0K2 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
        using sin_cos_def_21 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))!SIN-COSK3) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
        using sin_cos_def_21 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))!SIN-COSK3) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
        using sin_cos_lm_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
        using newton_th_12 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
         sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
         sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 ((\<one>\<^sub>M !SIN-COSK3)*XCMPLX-0K3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
        using newton_th_15 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 ((((0NUMBERSK6)!SIN-COSK3)*XCMPLX-0K3 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 \<two>\<^sub>M)"
        using newton_th_15 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
        using newton_th_12 sorry
      finally have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
         sorry
      then have A4: "?X(0NUMBERSK6)"
         sorry
      have A5: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A6: "k inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume A7: "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
          have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
            using funct_2_th_15 sorry
          also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using Lm6 sorry
          also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k) +REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using Lm6 sorry
          also have "... = ((Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_th_15 A6 sorry
          finally have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
             sorry
          then have A8: "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
             sorry
          have A9: "(\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
            using sin_cos_def_21 sorry
          also have "... = (\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
            using sin_cos_lm_7 sorry
          also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
             sorry
          finally have "(\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
             sorry
          have A10: "(\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
            using sin_cos_def_21 sorry
          also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
            using sin_cos_lm_7 sorry
          also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
             sorry
          also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
             sorry
          finally have "(\<one>\<^sub>M P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
             sorry
          have "\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using xreal_1_th_29 xreal_1_th_68 sorry
          then have "(\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3 <=XXREAL-0R1 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3"
            using sin_cos_th_39 sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3) >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
            using xreal_1_th_85 sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3) >=XXREAL-0R2 0NUMBERSK6"
            using xreal_1_th_48 sorry
          then have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            using A8 A9 A10 xreal_1_th_49 sorry
          thus "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
            using A7 xxreal_0_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be NatNAT-1M1 holds ?X(n)"
        using nat_1_sch_2 A4 A5 sorry
      thus "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
         sorry
    qed "sorry"
    then have A11: "(cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
      using A1 A3 prepower_th_1 seq_4_th_16 sorry
    have A12: "Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) be convergentCOMSEQ-2V3"
      using sin_cos_th_36 sorry
    have A13: "(sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 SumSERIES-1K4 (\<one>\<^sub>M P-sinSIN-COSK21)"
      using sin_cos_th_37 sorry
    have "limSEQ-2K1 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq) =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21)"
      using A12 seq_4_th_17 sorry
    then have A14: "limSEQ-2K1 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M"
      using A13 series_1_def_3 sorry
    have " for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      let ?X = "\<lambda>Lamb1. (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >=XXREAL-0R2 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
      have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6))"
        using funct_2_th_15 sorry
      also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)"
        using Lm6 sorry
      also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
        using sin_cos_def_20 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using sin_cos_def_20 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using sin_cos_lm_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
         sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (((0NUMBERSK6)!SIN-COSK3)*XCMPLX-0K3 \<one>\<^sub>M) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using newton_th_15 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using newton_th_12 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
         sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
        using newton_th_15 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (((\<one>\<^sub>M !SIN-COSK3)*XCMPLX-0K3 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 \<three>\<^sub>M)"
        using newton_th_15 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)*XCMPLX-0K3 (\<two>\<^sub>M *NAT-1K2 \<three>\<^sub>M))"
         sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 ((\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*NAT-1K2 \<six>\<^sub>M)"
        using newton_th_12 newton_th_15 sorry
      also have "... = \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
         sorry
      finally have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
         sorry
      then have A15: "?X(0NUMBERSK6)"
         sorry
      have A16: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M implies (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A17: "k inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume A18: "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
          have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
            using funct_2_th_15 sorry
          also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using Lm6 sorry
          also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k) +REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using Lm6 sorry
          also have "... = ((Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_th_15 A17 sorry
          finally have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
             sorry
          then have A19: "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
             sorry
          have A20: "(\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using sin_cos_def_20 sorry
          also have "... = (\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using sin_cos_lm_7 sorry
          also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
             sorry
          finally have "(\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
             sorry
          have A21: "(\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using sin_cos_def_20 sorry
          also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using sin_cos_lm_7 sorry
          also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
             sorry
          also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
             sorry
          finally have "(\<one>\<^sub>M P-sinSIN-COSK21).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
             sorry
          have "\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using xreal_1_th_29 xreal_1_th_68 sorry
          then have "\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
            using xreal_1_th_6 sorry
          then have "(\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3 <=XXREAL-0R1 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3"
            using sin_cos_th_39 sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using xreal_1_th_85 sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) >=XXREAL-0R2 0NUMBERSK6"
            using xreal_1_th_48 sorry
          then have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            using A19 A20 A21 xreal_1_th_49 sorry
          thus "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
            using A18 xxreal_0_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be NatNAT-1M1 holds ?X(n)"
        using nat_1_sch_2 A15 A16 sorry
      thus "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M P-sinSIN-COSK21) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
         sorry
    qed "sorry"
    then have A22: "(sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M"
      using A12 A14 prepower_th_1 seq_4_th_16 sorry
    have A23: "((cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M"
      using sin_cos_th_28 sorry
    have A24: "((sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 >=XXREAL-0R2 (\<five>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)^2SQUARE-1K1"
      using A22 square_1_th_15 sorry
    then have "\<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1) <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 \<two>\<five>\<^sub>M /XCMPLX-0K7 \<three>\<six>\<^sub>M"
      using A23 xreal_1_th_10 sorry
    then have "((cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 \<two>\<five>\<^sub>M /XCMPLX-0K7 \<three>\<six>\<^sub>M"
      using xxreal_0_th_2 sorry
    then have "((sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 >XXREAL-0R4 ((cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
      using A24 xxreal_0_th_2 sorry
    then have A25: "sqrtSQUARE-1K3 ((cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 sqrtSQUARE-1K3 ((sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
      using square_1_th_27 xreal_1_th_63 sorry
    have "sqrtSQUARE-1K3 ((cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M"
      using A11 square_1_th_22 sorry
    thus "( not (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 &  not (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6) &  not (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M"
      using A11 A22 A25 square_1_th_22 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_44:
" for th be RealXREAL-0M1 holds th rExpSeqSIN-COSK5 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4)"
proof(rule ballI)
  fix th assume [ty]: "th be RealXREAL-0M1"
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (th rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 ((th ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
      using comseq_3_def_5 sorry
    also have "... = ReCOMPLEX1K3 (th  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
      using sin_cos_def_4 sorry
    also have "... = ReCOMPLEX1K3 (th  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
    also have "... = th  |^COMSEQ-3K2 n /XCMPLX-0K7 (n !SIN-COSK3)"
      using complex1_th_12 sorry
    also have "... = (th rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using sin_cos_def_5 sorry
    finally have "ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (th rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
    thus "(th rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
  qed "sorry"
  thus "th rExpSeqSIN-COSK5 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4)"
     sorry
qed "sorry"

mtheorem sin_cos_th_45:
" for th be RealXREAL-0M1 holds th rExpSeqSIN-COSK5 be summableSERIES-1V1 & SumSERIES-1K4 (th rExpSeqSIN-COSK5) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4)"
proof(rule ballI)
  fix th assume [ty]: "th be RealXREAL-0M1"
  have "SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4) =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4)) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 (th ExpSeqSIN-COSK4)) *XCMPLX-0K3 (<i>COMPLEX1K8) & SumSERIES-1K4 (th rExpSeqSIN-COSK5) =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 (th ExpSeqSIN-COSK4))"
    using sin_cos_th_44 comseq_3_th_53 sorry
  thus "th rExpSeqSIN-COSK5 be summableSERIES-1V1 & SumSERIES-1K4 (th rExpSeqSIN-COSK5) =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4)"
    using sin_cos_th_44 complex1_th_12 sorry
qed "sorry"

mlemma sin_cos_lm_8:
" for n be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M =COMPLEX1R1 z & (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7) &  |.COMPLEX1K10 z  |^COMSEQ-3K2 n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n"
proof-
  have " for n be NatNAT-1M1 holds  for z be ComplexXCMPLX-0M1 holds ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M =COMPLEX1R1 z & (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7) &  |.COMPLEX1K10 z  |^COMSEQ-3K2 n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z  |^COMSEQ-3K2 \<one>\<^sub>M =COMPLEX1R1 z"
       sorry
    then have A1: "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M =HIDDENR1 z /XCMPLX-0K7 (\<one>\<^sub>M !SIN-COSK3)"
      using sin_cos_def_4 sorry
    also have "... = z"
      using newton_th_13 sorry
    finally have "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M =HIDDENR1 z"
       sorry
    have A2: "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 z  |^COMSEQ-3K2 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
      using sin_cos_def_4 sorry
    also have "... = 1rCOMPLEX1K7"
      using sin_cos_th_1 comseq_3_th_11 sorry
    finally have "(z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 1rCOMPLEX1K7"
       sorry
    have " |.COMPLEX1K10 z  |^COMSEQ-3K2 n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n"
    proof-
      let ?X = "\<lambda>Lamb1.  |.COMPLEX1K10 z  |^COMSEQ-3K2 Lamb1.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 Lamb1"
      have " |.COMPLEX1K10 z  |^COMSEQ-3K2 (0NUMBERSK6).| =COMPLEX1R1 \<one>\<^sub>M"
        using complex1_th_48 comseq_3_def_1 sorry
      then have A3: "?X(0NUMBERSK6)"
        using newton_th_4 sorry
      have A4: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds  |.COMPLEX1K10 z  |^COMSEQ-3K2 k.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 k implies  |.COMPLEX1K10 z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M).| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A5: " |.COMPLEX1K10 z  |^COMSEQ-3K2 k.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 k"
          have " |.COMPLEX1K10 z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M).| =HIDDENR1  |.COMPLEX1K10 z *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k .|"
            using comseq_3_def_1 sorry
          also have "... = ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 k *XCMPLX-0K3 ( |.COMPLEX1K10 z.|)"
            using A5 complex1_th_65 sorry
          also have "... = ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
            using newton_th_6 sorry
          finally have " |.COMPLEX1K10 z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M).| =HIDDENR1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
          thus " |.COMPLEX1K10 z  |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M).| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be NatNAT-1M1 holds ?X(n)"
        using nat_1_sch_2 A3 A4 sorry
      thus " |.COMPLEX1K10 z  |^COMSEQ-3K2 n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n"
         sorry
    qed
    thus "((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M =COMPLEX1R1 z & (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7) &  |.COMPLEX1K10 z  |^COMSEQ-3K2 n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos_lm_9:
" for th be RealXREAL-0M1 holds SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4) =COMPLEX1R1 SumSERIES-1K4 (th rExpSeqSIN-COSK5)"
proof(rule ballI)
  fix th assume [ty]: "th be RealXREAL-0M1"
  have A1: " for n be NatNAT-1M1 holds ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
  proof-
    let ?X = "\<lambda>Lamb1. ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 0NUMBERSK6"
    have "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
      using comseq_3_def_6 sorry
    also have "... = ImCOMPLEX1K4 ((th ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
      using series_1_def_1 sorry
    also have "... = 0NUMBERSK6"
      using sin_cos_lm_8 complex1_th_6 sorry
    finally have "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
    then have A2: "?X(0NUMBERSK6)"
       sorry
    have A3: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6 implies ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
        have "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          using comseq_3_def_6 sorry
        also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (th ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          using series_1_def_1 sorry
        also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ImCOMPLEX1K4 ((th ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          using complex1_th_8 sorry
        also have "... = 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 ((th ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          using A4 comseq_3_def_6 sorry
        also have "... = ImCOMPLEX1K4 (th  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
          using sin_cos_def_4 sorry
        also have "... = 0NUMBERSK6"
          using complex1_th_12 sorry
        finally have "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
           sorry
        thus "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A2 A3 sorry
    thus " for n be NatNAT-1M1 holds ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
       sorry
  qed
  then have "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) be constantVALUED-0V15"
    using valued_0_def_18 sorry
  then have "limSEQ-2K1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) =HIDDENR1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
    using seq_4_th_26 sorry
  also have "... = 0NUMBERSK6"
    using A1 sorry
  finally have "limSEQ-2K1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (th ExpSeqSIN-COSK4) =HIDDENR1 0NUMBERSK6"
     sorry
  then have "ImCOMPLEX1K4 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4) =COMPLEX1R1 0NUMBERSK6"
    using comseq_3_th_41 sorry
  then have "SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4) =HIDDENR1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using complex1_th_13 sorry
  also have "... = SumSERIES-1K4 (th rExpSeqSIN-COSK5)"
    using sin_cos_th_45 sorry
  finally have "SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4) =HIDDENR1 SumSERIES-1K4 (th rExpSeqSIN-COSK5)"
     sorry
  thus "SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4) =COMPLEX1R1 SumSERIES-1K4 (th rExpSeqSIN-COSK5)"
     sorry
qed "sorry"

mtheorem sin_cos_th_46:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds SumSERIES-1K4 ((p +XCMPLX-0K2 q)rExpSeqSIN-COSK5) =COMPLEX1R1 SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 SumSERIES-1K4 (q rExpSeqSIN-COSK5)"
proof(rule ballI,rule ballI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix q assume [ty]: "q be RealXREAL-0M1"
  have 
    [ty]:"p be RealXREAL-0M1" and
    [ty]:"q be RealXREAL-0M1"
     sorry
  have "SumSERIES-1K4 ((p +XCMPLX-0K2 q)rExpSeqSIN-COSK5) =HIDDENR1 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((p +XCMPLX-0K2 q)ExpSeqSIN-COSK4)"
    using sin_cos_th_45 sorry
  also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4))"
    using sin_cos_lm_3 sorry
  also have "... = ReCOMPLEX1K3 ((ReCOMPLEX1K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) +XCMPLX-0K2 ImCOMPLEX1K4 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4))"
    using complex1_th_13 sorry
  also have "... = ReCOMPLEX1K3 ((ReCOMPLEX1K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) +XCMPLX-0K2 ImCOMPLEX1K4 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (ReCOMPLEX1K3 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4) +XCMPLX-0K2 ImCOMPLEX1K4 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4) *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using complex1_th_13 sorry
  also have "... = ReCOMPLEX1K3 ((SumSERIES-1K4 (p rExpSeqSIN-COSK5) +XCMPLX-0K2 ImCOMPLEX1K4 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (ReCOMPLEX1K3 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4) +XCMPLX-0K2 ImCOMPLEX1K4 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4) *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_th_45 sorry
  also have "... = ReCOMPLEX1K3 ((SumSERIES-1K4 (p rExpSeqSIN-COSK5) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (ReCOMPLEX1K3 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4) +XCMPLX-0K2 ImCOMPLEX1K4 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4) *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_th_42 sorry
  also have "... = ReCOMPLEX1K3 (SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 (SumSERIES-1K4 (q rExpSeqSIN-COSK5) +XCMPLX-0K2 ImCOMPLEX1K4 SumCOMSEQ-3K11 (q ExpSeqSIN-COSK4) *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_th_45 sorry
  also have "... = ReCOMPLEX1K3 (SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 (SumSERIES-1K4 (q rExpSeqSIN-COSK5) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_th_42 sorry
  also have "... = ReCOMPLEX1K3 (SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 SumSERIES-1K4 (q rExpSeqSIN-COSK5) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
     sorry
  also have "... = SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 SumSERIES-1K4 (q rExpSeqSIN-COSK5)"
    using complex1_th_12 sorry
  finally have "SumSERIES-1K4 ((p +XCMPLX-0K2 q)rExpSeqSIN-COSK5) =HIDDENR1 SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 SumSERIES-1K4 (q rExpSeqSIN-COSK5)"
     sorry
  thus "SumSERIES-1K4 ((p +XCMPLX-0K2 q)rExpSeqSIN-COSK5) =COMPLEX1R1 SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 SumSERIES-1K4 (q rExpSeqSIN-COSK5)"
     sorry
qed "sorry"

mdef sin_cos_def_22 ("exp-RSIN-COSK23" 164 ) where
"func exp-RSIN-COSK23 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
    proof-
      have " ex tVar14 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar14 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10(SumSERIES-1K4 (Lamb1 rExpSeqSIN-COSK5),REALNUMBERSK2)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
          using funct_2_sch_4 sorry
        show " ex tVar14 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar14 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
        proof(rule bexI[of _ "f"],rule ballI)
          fix d assume [ty]: "d be RealXREAL-0M1"
          have "d inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have "f .FUNCT-1K1 d =COMPLEX1R1 ?U(d)"
            using A1 sorry
          thus "f .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)) implies (( for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)) implies f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A2: " for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
        assume A3: " for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =COMPLEX1R1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =COMPLEX1R1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
          proof(rule ballI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            have "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 SumSERIES-1K4 (d rExpSeqSIN-COSK5)"
              using A2 sorry
            also have "... = f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
              using A3 sorry
            finally show "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos_def_23 ("exp-RSIN-COSK24  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func exp-RSIN-COSK24 th \<rightarrow> numberORDINAL1M2 equals
  (exp-RSIN-COSK23).FUNCT-1K1 th"
proof-
  (*coherence*)
    show "(exp-RSIN-COSK23).FUNCT-1K1 th be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos_cl_5:
  mlet "th be RealXREAL-0M1"
"cluster exp-RSIN-COSK24 th as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "exp-RSIN-COSK24 th be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem sin_cos_th_47:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 REALNUMBERSK2"
  using funct_2_def_1 sorry

mtheorem sin_cos_th_48:
" for th be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 th =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4)"
proof(rule ballI)
  fix th assume [ty]: "th be RealXREAL-0M1"
  have "(exp-RSIN-COSK23).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th rExpSeqSIN-COSK5)"
    using sin_cos_def_22 sorry
  thus "(exp-RSIN-COSK23).FUNCT-1K1 th =COMPLEX1R1 ReCOMPLEX1K3 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4)"
    using sin_cos_th_45 sorry
qed "sorry"

mtheorem sin_cos_th_49:
" for th be RealXREAL-0M1 holds expSIN-COSK16 th =COMPLEX1R1 exp-RSIN-COSK24 th"
proof-
  have " for th be RealXREAL-0M1 holds expSIN-COSK16 th =HIDDENR1 exp-RSIN-COSK24 th"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "expSIN-COSK16 th =HIDDENR1 SumCOMSEQ-3K11 (th ExpSeqSIN-COSK4)"
      using sin_cos_def_14 sorry
    also have "... = SumSERIES-1K4 (th rExpSeqSIN-COSK5)"
      using sin_cos_lm_9 sorry
    also have "... = exp-RSIN-COSK24 th"
      using sin_cos_def_22 sorry
    finally show "expSIN-COSK16 th =HIDDENR1 exp-RSIN-COSK24 th"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos_lm_10:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
proof(rule ballI,rule ballI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix q assume [ty]: "q be RealXREAL-0M1"
  have "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =HIDDENR1 SumSERIES-1K4 ((p +XCMPLX-0K2 q)rExpSeqSIN-COSK5)"
    using sin_cos_def_22 sorry
  also have "... = SumSERIES-1K4 (p rExpSeqSIN-COSK5) *XCMPLX-0K3 SumSERIES-1K4 (q rExpSeqSIN-COSK5)"
    using sin_cos_th_46 sorry
  also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 SumSERIES-1K4 (q rExpSeqSIN-COSK5)"
    using sin_cos_def_22 sorry
  also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
    using sin_cos_def_22 sorry
  finally have "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
     sorry
  thus "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
     sorry
qed "sorry"

mtheorem sin_cos_th_50:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds exp-RSIN-COSK24 (p +XCMPLX-0K2 q) =COMPLEX1R1 (exp-RSIN-COSK24 p)*XCMPLX-0K3 (exp-RSIN-COSK24 q)"
  using sin_cos_lm_10 sorry

mlemma sin_cos_lm_11:
"(exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have "(exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 SumSERIES-1K4 ((0NUMBERSK6)rExpSeqSIN-COSK5)"
    using sin_cos_def_22 sorry
  also have "... = \<one>\<^sub>M"
    using sin_cos_th_9 sin_cos_th_45 complex1_th_6 sorry
  finally have "(exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
     sorry
  thus "(exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
     sorry
qed

mtheorem sin_cos_th_51:
"exp-RSIN-COSK24 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
  using sin_cos_lm_11 sorry

mtheorem sin_cos_th_52:
" for th be RealXREAL-0M1 holds th >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 th >=XXREAL-0R2 \<one>\<^sub>M"
proof-
  have " for th be RealXREAL-0M1 holds th >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 th >=XXREAL-0R2 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume A1: "th >XXREAL-0R4 0NUMBERSK6"
    have A2: " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M"
      proof-
        let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >=XXREAL-0R2 \<one>\<^sub>M"
        have "Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (th rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using series_1_def_1 sorry
        also have "... = th  |^COMSEQ-3K2 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          using sin_cos_def_5 sorry
        also have "... = \<one>\<^sub>M"
          using newton_th_4 newton_th_12 sorry
        finally have "Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
           sorry
        then have A3: "?X(0NUMBERSK6)"
           sorry
        have A4: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume A5: "Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M"
            have A6: "Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (th rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
              using series_1_def_1 sorry
            also have "... = Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 th  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using sin_cos_def_5 sorry
            finally have "Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 th  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
               sorry
            have "th  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6 & (n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3 >XXREAL-0R4 0NUMBERSK6"
              using A1 prepower_th_6 sorry
            then have "Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 th  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) >XXREAL-0R4 Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using xreal_1_th_29 sorry
            thus "Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M"
              using A5 A6 xxreal_0_th_2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " for n be NatNAT-1M1 holds ?X(n)"
          using nat_1_sch_2 A3 A4 sorry
        thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "th rExpSeqSIN-COSK5 be summableSERIES-1V1"
      using sin_cos_th_45 sorry
    then have A7: "Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) be convergentCOMSEQ-2V3"
      using series_1_def_2 sorry
    have "limSEQ-2K1 Partial-SumsSERIES-1K3 (th rExpSeqSIN-COSK5) =COMPLEX1R1 SumSERIES-1K4 (th rExpSeqSIN-COSK5)"
      using series_1_def_3 sorry
    then have "SumSERIES-1K4 (th rExpSeqSIN-COSK5) >=XXREAL-0R2 \<one>\<^sub>M"
      using A2 A7 prepower_th_1 sorry
    thus "(exp-RSIN-COSK23).FUNCT-1K1 th >=XXREAL-0R2 \<one>\<^sub>M"
      using sin_cos_def_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_53:
" for th be RealXREAL-0M1 holds th <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 <XXREAL-0R3 (exp-RSIN-COSK23).FUNCT-1K1 th & (exp-RSIN-COSK23).FUNCT-1K1 th <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for th be RealXREAL-0M1 holds th <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 <XXREAL-0R3 (exp-RSIN-COSK23).FUNCT-1K1 th & (exp-RSIN-COSK23).FUNCT-1K1 th <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule impI,rule conjMI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume "th <XXREAL-0R3 0NUMBERSK6"
    then have A1: "(exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 th) >=XXREAL-0R2 \<one>\<^sub>M"
      using sin_cos_th_52 sorry
    have A2: "(exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 th) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 th =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 th)+XCMPLX-0K2 th)"
      using sin_cos_lm_10 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_lm_11 sorry
    finally have "(exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 th) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 th =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A3: "(exp-RSIN-COSK23).FUNCT-1K1 th =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 th)"
      using xcmplx_1_th_73 sorry
    show "0NUMBERSK6 <XXREAL-0R3 (exp-RSIN-COSK23).FUNCT-1K1 th"
      using A1 A2 sorry
    show "(exp-RSIN-COSK23).FUNCT-1K1 th <=XXREAL-0R1 \<one>\<^sub>M"
      using A1 A3 xreal_1_th_211 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_54:
" for th be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for th be RealXREAL-0M1 holds  not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
    proof-
      show " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
      proof-
        have cases: "th =COMPLEX1R1 0NUMBERSK6 or th <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "th =COMPLEX1R1 0NUMBERSK6 implies  not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
        proof(rule impI)
          assume "th =COMPLEX1R1 0NUMBERSK6"
          thus " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
            using sin_cos_lm_11 sorry
        qed
        have case2: "th <>HIDDENR2 0NUMBERSK6 implies  not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
        proof(rule impI)
          assume A1: "th <>HIDDENR2 0NUMBERSK6"
          have " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
          proof-
            show " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
            proof-
              have cases: "th <XXREAL-0R3 0NUMBERSK6 or th >XXREAL-0R4 0NUMBERSK6"
                using A1 sorry
              have case1: "th <XXREAL-0R3 0NUMBERSK6 implies  not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
              proof(rule impI)
                assume "th <XXREAL-0R3 0NUMBERSK6"
                thus " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
                  using sin_cos_th_53 sorry
              qed
              have case2: "th >XXREAL-0R4 0NUMBERSK6 implies  not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
              proof(rule impI)
                assume "th >XXREAL-0R4 0NUMBERSK6"
                thus " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
                  using sin_cos_th_52 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (exp-RSIN-COSK23).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_55:
" for th be RealXREAL-0M1 holds exp-RSIN-COSK24 th >XXREAL-0R4 0NUMBERSK6"
  using sin_cos_th_54 sorry

(*begin*)
mdef sin_cos_def_24 (" _ P-dtSIN-COSK25" [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z P-dtSIN-COSK25 \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
    proof-
      let ?U = "\<lambda>Lamb1. z  |^COMSEQ-3K2 (Lamb1 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((Lamb1 +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
      show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
      proof-
        have " ex s be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
        proof-
          show " ex s be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
            using comseq_1_sch_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
    proof-
      let ?U = "\<lambda>Lamb1. z  |^COMSEQ-3K2 (Lamb1 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((Lamb1 +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
      show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
      proof-
        have " for s1 be Complex-SequenceCOMSEQ-1M1 holds  for s2 be Complex-SequenceCOMSEQ-1M1 holds ( for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 z  |^COMSEQ-3K2 (x +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((x +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) & ( for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 z  |^COMSEQ-3K2 (x +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((x +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) implies s1 =HIDDENR1 s2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
          fix s2 assume [ty]: "s2 be Complex-SequenceCOMSEQ-1M1"
          assume A1: " for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 ?U(x)"
            and A2: " for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 ?U(x)"
          have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
          proof(rule ballI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 z  |^COMSEQ-3K2 (x +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((x +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
              using A1 sorry
            also have "... = s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
              using A2 sorry
            finally show "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
               sorry
          qed "sorry"
          thus "s1 =HIDDENR1 s2"
            using funct_2_def_8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef sin_cos_def_25 (" _ P-tSIN-COSK26" [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z P-tSIN-COSK26 \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
    proof-
      let ?U = "\<lambda>Lamb1. z  |^COMSEQ-3K2 (Lamb1 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((Lamb1 +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
      let ?U = "\<lambda>Lamb1. z  |^COMSEQ-3K2 Lamb1 /XCMPLX-0K7 ((Lamb1 +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
      show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
      proof-
        have " ex s be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
        proof-
          show " ex s be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
            using comseq_1_sch_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
    proof-
      let ?U = "\<lambda>Lamb1. z  |^COMSEQ-3K2 (Lamb1 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((Lamb1 +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
      let ?U = "\<lambda>Lamb1. z  |^COMSEQ-3K2 Lamb1 /XCMPLX-0K7 ((Lamb1 +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
      show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) implies it1 =HIDDENR1 it2"
      proof-
        have " for s1 be Complex-SequenceCOMSEQ-1M1 holds  for s2 be Complex-SequenceCOMSEQ-1M1 holds ( for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 z  |^COMSEQ-3K2 x /XCMPLX-0K7 ((x +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) & ( for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 z  |^COMSEQ-3K2 x /XCMPLX-0K7 ((x +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)) implies s1 =HIDDENR1 s2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
          fix s2 assume [ty]: "s2 be Complex-SequenceCOMSEQ-1M1"
          assume A3: " for x be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 ?U(x)"
            and A4: " for x be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 ?U(x)"
          have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
          proof(rule ballI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 z  |^COMSEQ-3K2 x /XCMPLX-0K7 ((x +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
              using A3 sorry
            also have "... = s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
              using A4 sorry
            finally show "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
               sorry
          qed "sorry"
          thus "s1 =HIDDENR1 s2"
            using funct_2_def_8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mlemma sin_cos_lm_12:
" for p be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds ((ReCOMPLEX1K3 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z) =COMPLEX1R1 -XCMPLX-0K4 p *XCMPLX-0K3 ImCOMPLEX1K4 z & ImCOMPLEX1K4 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ReCOMPLEX1K3 z) & ReCOMPLEX1K3 (p *XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ReCOMPLEX1K3 z) & ImCOMPLEX1K4 (p *XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ImCOMPLEX1K4 z"
proof(rule ballI,rule ballI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have A1: "(p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z =HIDDENR1 (p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using complex1_th_13 sorry
  also have "... = (-XCMPLX-0K4 p *XCMPLX-0K3 ImCOMPLEX1K4 z)+XCMPLX-0K2 (p *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  finally have "(p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z =HIDDENR1 (-XCMPLX-0K4 p *XCMPLX-0K3 ImCOMPLEX1K4 z)+XCMPLX-0K2 (p *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  have "p *XCMPLX-0K3 z =HIDDENR1 p *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8))"
    using complex1_th_13 sorry
  also have "... = p *XCMPLX-0K3 ReCOMPLEX1K3 z +XCMPLX-0K2 (p *XCMPLX-0K3 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  finally have "p *XCMPLX-0K3 z =HIDDENR1 p *XCMPLX-0K3 ReCOMPLEX1K3 z +XCMPLX-0K2 (p *XCMPLX-0K3 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  thus "((ReCOMPLEX1K3 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z) =COMPLEX1R1 -XCMPLX-0K4 p *XCMPLX-0K3 ImCOMPLEX1K4 z & ImCOMPLEX1K4 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ReCOMPLEX1K3 z) & ReCOMPLEX1K3 (p *XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ReCOMPLEX1K3 z) & ImCOMPLEX1K4 (p *XCMPLX-0K3 z) =COMPLEX1R1 p *XCMPLX-0K3 ImCOMPLEX1K4 z"
    using A1 complex1_th_12 sorry
qed "sorry"

mlemma sin_cos_lm_13:
" for p be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies (ReCOMPLEX1K3 (z /XCMPLX-0K7 (p *XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 ImCOMPLEX1K4 z /XCMPLX-0K7 p & ImCOMPLEX1K4 (z /XCMPLX-0K7 (p *XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 -XCMPLX-0K4 ReCOMPLEX1K3 z /XCMPLX-0K7 p) &  |.COMPLEX1K10 z /XCMPLX-0K7 p .| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 p"
proof(rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  assume A1: "p >XXREAL-0R4 0NUMBERSK6"
  have A2: "ReCOMPLEX1K3 (0NUMBERSK6 +XCMPLX-0K2 p *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (0NUMBERSK6 +XCMPLX-0K2 p *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 p"
    using complex1_th_12 sorry
  have A3: "ImCOMPLEX1K4 (p +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6"
    using complex1_th_12 sorry
  have A4: "z /XCMPLX-0K7 (p *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 (ReCOMPLEX1K3 z *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 p)/XCMPLX-0K7 ((0NUMBERSK6)^2SQUARE-1K1 +XCMPLX-0K2 p ^2SQUARE-1K1) +XCMPLX-0K2 (((0NUMBERSK6)*XCMPLX-0K3 ImCOMPLEX1K4 z -XCMPLX-0K6 ReCOMPLEX1K3 z *XCMPLX-0K3 p)/XCMPLX-0K7 ((0NUMBERSK6)^2SQUARE-1K1 +XCMPLX-0K2 p ^2SQUARE-1K1))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using A2 complex1_th_86 sorry
  also have "... = (ImCOMPLEX1K4 z *XCMPLX-0K3 p)/XCMPLX-0K7 (p *XCMPLX-0K3 p) +XCMPLX-0K2 (((-REAL-1K1 ReCOMPLEX1K3 z)*XCMPLX-0K3 p)/XCMPLX-0K7 (p *XCMPLX-0K3 p))*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  also have "... = (ImCOMPLEX1K4 z *XCMPLX-0K3 p)/XCMPLX-0K7 (p *XCMPLX-0K3 p) +XCMPLX-0K2 ((-REAL-1K1 ReCOMPLEX1K3 z)/XCMPLX-0K7 p)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using A1 xcmplx_1_th_91 sorry
  also have "... = ImCOMPLEX1K4 z /XCMPLX-0K7 p +XCMPLX-0K2 (-XCMPLX-0K4 ReCOMPLEX1K3 z /XCMPLX-0K7 p)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using A1 xcmplx_1_th_91 sorry
  finally have "z /XCMPLX-0K7 (p *XCMPLX-0K3 (<i>COMPLEX1K8)) =HIDDENR1 ImCOMPLEX1K4 z /XCMPLX-0K7 p +XCMPLX-0K2 (-XCMPLX-0K4 ReCOMPLEX1K3 z /XCMPLX-0K7 p)*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  have " |.COMPLEX1K10 z /XCMPLX-0K7 p .| =HIDDENR1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10 p.|)"
    using complex1_th_67 sorry
  also have "... = ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 sqrtSQUARE-1K3 p ^2SQUARE-1K1"
    using A3 complex1_th_12 sorry
  finally have " |.COMPLEX1K10 z /XCMPLX-0K7 p .| =HIDDENR1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 sqrtSQUARE-1K3 p ^2SQUARE-1K1"
     sorry
  thus "(ReCOMPLEX1K3 (z /XCMPLX-0K7 (p *XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 ImCOMPLEX1K4 z /XCMPLX-0K7 p & ImCOMPLEX1K4 (z /XCMPLX-0K7 (p *XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 -XCMPLX-0K4 ReCOMPLEX1K3 z /XCMPLX-0K7 p) &  |.COMPLEX1K10 z /XCMPLX-0K7 p .| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 p"
    using A1 A4 complex1_th_12 square_1_th_22 sorry
qed "sorry"

mtheorem sin_cos_th_56:
" for z be ComplexXCMPLX-0M1 holds z P-dtSIN-COSK25 be absolutely-summableCOMSEQ-3V2"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have " ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
  proof-
    have " ex tVar15 be RealXREAL-0M1 st  for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 tVar15"
    proof-
      have A1: " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using series_1_def_1 sorry
          also have "... =  |.COMPLEX1K10 (z P-dtSIN-COSK25).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).|"
            using valued_1_th_18 sorry
          also have "... =  |.COMPLEX1K10 z  |^COMSEQ-3K2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) .|"
            using sin_cos_def_24 sorry
          also have "... =  |.COMPLEX1K10 z /XCMPLX-0K7 \<two>\<^sub>M .|"
            using newton_th_14 sorry
          finally have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1  |.COMPLEX1K10 z /XCMPLX-0K7 \<two>\<^sub>M .|"
             sorry
          then have A2: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 \<two>\<^sub>M"
            using sin_cos_lm_13 sorry
          have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
            using series_1_def_1 sorry
          also have "... = ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M.|"
            using valued_1_th_18 sorry
          also have "... =  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).| +XCMPLX-0K2  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M.|"
            using valued_1_th_18 sorry
          also have "... =  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).| +XCMPLX-0K2  |.COMPLEX1K10 z.|"
            using sin_cos_lm_8 sorry
          also have "... = \<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 z.|"
            using sin_cos_lm_8 complex1_th_48 sorry
          finally have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 z.|"
             sorry
          then have A3: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 ( |.COMPLEX1K10 z.| -XCMPLX-0K6 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 \<two>\<^sub>M)"
            using A2 sorry
          let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 z.|"
            using complex1_th_46 sorry
          then have A4: "?X(0NUMBERSK6)"
            using A3 xreal_1_th_47 sorry
          have A5: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
            proof(rule ballI,rule impI)
              fix n assume [ty]: "n be NatNAT-1M1"
              assume A6: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
              have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                using series_1_def_1 sorry
              also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2  |.COMPLEX1K10 (z P-dtSIN-COSK25).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M).|"
                using valued_1_th_18 sorry
              also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2  |.COMPLEX1K10 z  |^COMSEQ-3K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) .|"
                using sin_cos_def_24 sorry
              also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2  |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<three>\<^sub>M)!SIN-COSK3) .|"
                 sorry
              finally have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2  |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<three>\<^sub>M)!SIN-COSK3) .|"
                 sorry
              then have A7: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 ( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<three>\<^sub>M)!SIN-COSK3)"
                using sin_cos_lm_13 sorry
              have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
                using series_1_def_1 sorry
              also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2  |.COMPLEX1K10 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<two>\<^sub>M).|"
                using valued_1_th_18 sorry
              also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2  |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) .|"
                using sin_cos_def_4 sorry
              also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2  |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) .|"
                 sorry
              finally have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2  |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) .|"
                 sorry
              then have A8: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
                using sin_cos_lm_13 sorry
              have "n +NAT-1K1 \<two>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<three>\<^sub>M"
                using xreal_1_th_6 sorry
              then have A9: "(n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3 <=XXREAL-0R1 (n +NAT-1K1 \<three>\<^sub>M)!SIN-COSK3"
                using sin_cos_th_39 sorry
              have " |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).| >=XXREAL-0R2 0NUMBERSK6"
                using complex1_th_46 sorry
              then have "( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) >=XXREAL-0R2 ( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<three>\<^sub>M)!SIN-COSK3)"
                using A9 xreal_1_th_118 sorry
              then have A10: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 ( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<three>\<^sub>M)!SIN-COSK3) <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 ( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
                using xreal_1_th_6 sorry
              have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 ( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<two>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
                using A6 xreal_1_th_6 sorry
              thus "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
                using A7 A8 A10 xxreal_0_th_2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " for n be NatNAT-1M1 holds ?X(n)"
            using nat_1_sch_2 A4 A5 sorry
          thus " not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A11: " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
        using seq_2_def_3 sorry
      have A12: " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
      proof-
        have " for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z ExpSeqSIN-COSK4 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
            using A1 sorry
          thus " not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
            using A11 xxreal_0_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " ex tVar15 be RealXREAL-0M1 st  for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 tVar15"
      proof(rule bexI[of _ "r"])
        show " for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
          using A12 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
  then have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) be bounded-aboveSEQ-2V3"
    using seq_2_def_3 sorry
  thus "z P-dtSIN-COSK25 be absolutely-summableCOMSEQ-3V2"
    using comseq_3_th_61 sorry
qed "sorry"

mtheorem sin_cos_th_57:
" for z be ComplexXCMPLX-0M1 holds z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25) =COMPLEX1R1 (SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 1rCOMPLEX1K7)-XCMPLX-0K6 z"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have A1: " for z be ComplexXCMPLX-0M1 holds z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<two>\<^sub>M"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ((z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<two>\<^sub>M).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 z *XCMPLX-0K3 (z P-dtSIN-COSK25).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = z *XCMPLX-0K3 (z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3))"
        using sin_cos_def_24 sorry
      finally have "(z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 z *XCMPLX-0K3 (z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3))"
         sorry
      then have "(z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (z *XCMPLX-0K3 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
         sorry
      also have "... = z  |^COMSEQ-3K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
        using newton_th_6 sorry
      also have "... = (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<two>\<^sub>M)"
        using sin_cos_def_4 sorry
      also have "... = ((z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<two>\<^sub>M).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using nat_1_def_3 sorry
      finally have "(z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<two>\<^sub>M).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      thus "(z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ((z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<two>\<^sub>M).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25) =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<two>\<^sub>M"
       sorry
  qed "sorry"
  have "SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M +XCMPLX-0K2 SumCOMSEQ-3K11 ((z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
    using comseq_3_th_60 sorry
  also have "... = Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M +XCMPLX-0K2 SumCOMSEQ-3K11 ((z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<two>\<^sub>M)"
     sorry
  finally have "SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M +XCMPLX-0K2 SumCOMSEQ-3K11 ((z ExpSeqSIN-COSK4)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<two>\<^sub>M)"
     sorry
  then have A2: "SumCOMSEQ-3K11 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25)) =HIDDENR1 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
    using A1 sorry
  also have "... = SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 (Partial-SumsCOMSEQ-3K10 (z ExpSeqSIN-COSK4) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M)"
    using series_1_def_1 sorry
  also have "... = SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 ((z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M)"
    using series_1_def_1 sorry
  also have "... = SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 (1rCOMPLEX1K7 +XCMPLX-0K2 (z ExpSeqSIN-COSK4).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M)"
    using sin_cos_lm_8 sorry
  also have "... = SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 (1rCOMPLEX1K7 +XCMPLX-0K2 z)"
    using sin_cos_lm_8 sorry
  also have "... = (SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 1rCOMPLEX1K7)-XCMPLX-0K6 z"
     sorry
  finally have "SumCOMSEQ-3K11 (z (#)VALUED-1K27\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> (z P-dtSIN-COSK25)) =HIDDENR1 (SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 1rCOMPLEX1K7)-XCMPLX-0K6 z"
     sorry
  obtain BBB where 
    [ty]:"BBB be absolutely-summableCOMSEQ-3V2\<bar>Complex-SequenceCOMSEQ-1M1" and BBBDef:"BBB = z P-dtSIN-COSK25"
    using sin_cos_th_56 sorry
  have "BBB be summableCOMSEQ-3V1"
     sorry
  thus "z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25) =COMPLEX1R1 (SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 1rCOMPLEX1K7)-XCMPLX-0K6 z"
    using A2 comseq_3_th_56 sorry
qed "sorry"

mtheorem sin_cos_th_58:
" for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex q be RealXREAL-0M1 st q >XXREAL-0R4 0NUMBERSK6 & ( for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 q implies  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 p))"
proof-
  have " for p0 be RealXREAL-0M1 holds p0 >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar16 be RealXREAL-0M1 st tVar16 >XXREAL-0R4 0NUMBERSK6 & ( for z be ComplexXCMPLX-0M1 holds  not ( not  |.COMPLEX1K10 z.| <XXREAL-0R3 tVar16 &  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 p0)))"
  proof(rule ballI,rule impI)
    have A1: " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <=XXREAL-0R1 SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|)"
    proof(rule ballI)
      fix z assume [ty]: "z be ComplexXCMPLX-0M1"
      have A2: " for k be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z P-dtSIN-COSK25).|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
      proof(rule ballI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (z P-dtSIN-COSK25) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z P-dtSIN-COSK25).|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          using valued_1_th_18 sorry
        thus "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z P-dtSIN-COSK25).|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          using comseq_3_th_30 sorry
      qed "sorry"
      have A3: "z P-dtSIN-COSK25 be absolutely-summableCOMSEQ-3V2"
        using sin_cos_th_56 sorry
      have A4: "z P-dtSIN-COSK25 be summableCOMSEQ-3V1"
        using sin_cos_th_56 comseq_3_th_63 sorry
      have A5: "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z P-dtSIN-COSK25).|) =COMPLEX1R1  |.COMPLEX1K10 limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 (z P-dtSIN-COSK25) .|"
        using A4 seq_2_th_27 sorry
      have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z P-dtSIN-COSK25).|) <=XXREAL-0R1 limSEQ-2K1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|)"
        using A2 A3 seq_2_th_18 sorry
      thus " |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <=XXREAL-0R1 SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|)"
        using A5 series_1_def_3 sorry
    qed "sorry"
    have A6: " for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI,rule ballI)
      fix z assume [ty]: "z be ComplexXCMPLX-0M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 (z P-dtSIN-COSK25).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) .|"
        using sin_cos_def_24 sorry
      also have "... =  |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) .|"
         sorry
      finally have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3) .|"
         sorry
      then have A7: "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.COMPLEX1K10 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M).|)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
        using sin_cos_lm_13 sorry
      also have "... = ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
        using sin_cos_lm_8 sorry
      finally have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
         sorry
      have A8: "( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 n"
        using prepower_def_1 sorry
      also have "... = ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M)"
        using newton_th_6 sorry
      finally have "( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have "(n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3 >=XXREAL-0R2 \<one>\<^sub>M & ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6"
        using sin_cos_th_39 complex1_th_46 newton_th_12 power_th_3 sorry
      then have "( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<one>\<^sub>M >=XXREAL-0R2 ( |.COMPLEX1K10 z.|) |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!SIN-COSK3)"
        using xreal_1_th_118 sorry
      thus "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A7 A8 sorry
    qed "sorry"
    fix p0 assume [ty]: "p0 be RealXREAL-0M1"
    assume A9: "p0 >XXREAL-0R4 0NUMBERSK6"
    obtain p where 
      [ty]:"p be RealXREAL-0M1" and pDef:"p = p0"
       sorry
    obtain q where
      [ty]:"q be RealXREAL-0M1" and 
      A10: "q =COMPLEX1R1 p /XCMPLX-0K7 (p +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    have "p +XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 p"
      using xreal_1_th_29 sorry
    then have A11: "q <XXREAL-0R3 \<one>\<^sub>M"
      using A9 A10 xreal_1_th_189 sorry
    have A12: " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 q implies  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 p"
    proof-
      have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 q implies  not  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 p"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be ComplexXCMPLX-0M1"
        assume A13: " |.COMPLEX1K10 z.| <XXREAL-0R3 q"
        then have A14: " |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M"
          using A11 xxreal_0_th_2 sorry
        have A15: " |.COMPLEX1K10  |.COMPLEX1K10 z.| .| <XXREAL-0R3 \<one>\<^sub>M"
          using A11 A13 xxreal_0_th_2 sorry
        then have A16: "( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1 be summableSERIES-1V1"
          using series_1_th_24 sorry
        have A17: "SumSERIES-1K4 (( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6  |.COMPLEX1K10 z.|)"
          using A15 series_1_th_24 sorry
        have A18: "( |.COMPLEX1K10 z.|)(#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1 be summableSERIES-1V1"
          using A16 series_1_th_10 sorry
        have A19: " for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)(#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A6 sorry
          thus "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (( |.COMPLEX1K10 z.|)(#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using seq_1_th_9 sorry
        qed "sorry"
        have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 (z P-dtSIN-COSK25).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
            using valued_1_th_18 sorry
          thus "0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using complex1_th_46 sorry
        qed "sorry"
        then have A20: "SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) <=XXREAL-0R1 SumSERIES-1K4 (( |.COMPLEX1K10 z.|)(#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1)"
          using A18 A19 series_1_th_20 sorry
        have A21: "SumSERIES-1K4 (( |.COMPLEX1K10 z.|)(#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 z.|)GeoSeqPREPOWERK1) =COMPLEX1R1 ( |.COMPLEX1K10 z.|)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6  |.COMPLEX1K10 z.|)"
          using A16 A17 series_1_th_10 sorry
        have A22: "( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (p +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 (p /XCMPLX-0K7 (p +XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 (p +XCMPLX-0K2 \<one>\<^sub>M)"
          using A9 A10 A13 xreal_1_th_68 sorry
        have "(p /XCMPLX-0K7 (p +XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 (p +XCMPLX-0K2 \<one>\<^sub>M) =COMPLEX1R1 p"
          using A9 xcmplx_1_th_87 sorry
        then have A23: "(p *XCMPLX-0K3 ( |.COMPLEX1K10 z.|) +XCMPLX-0K2  |.COMPLEX1K10 z.|)-XCMPLX-0K6 p *XCMPLX-0K3 ( |.COMPLEX1K10 z.|) <XXREAL-0R3 p -XCMPLX-0K6 p *XCMPLX-0K3 ( |.COMPLEX1K10 z.|)"
          using A22 xreal_1_th_9 sorry
        have A24: "\<one>\<^sub>M -XCMPLX-0K6  |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6"
          using A14 xreal_1_th_50 sorry
        then have "( |.COMPLEX1K10 z.|)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6  |.COMPLEX1K10 z.|) <XXREAL-0R3 (p *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6  |.COMPLEX1K10 z.|))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6  |.COMPLEX1K10 z.|)"
          using A23 xreal_1_th_74 sorry
        then have "( |.COMPLEX1K10 z.|)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6  |.COMPLEX1K10 z.|) <XXREAL-0R3 p"
          using A24 xcmplx_1_th_89 sorry
        then have A25: "SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|) <XXREAL-0R3 p"
          using A20 A21 xxreal_0_th_2 sorry
        have " |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <=XXREAL-0R1 SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> z P-dtSIN-COSK25 .|)"
          using A1 sorry
        thus " not  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 p"
          using A25 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " ex tVar16 be RealXREAL-0M1 st tVar16 >XXREAL-0R4 0NUMBERSK6 & ( for z be ComplexXCMPLX-0M1 holds  not ( not  |.COMPLEX1K10 z.| <XXREAL-0R3 tVar16 &  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 p0))"
    proof(rule bexI[of _ "q"],rule conjMI,rule ballI)
      show "q >XXREAL-0R4 0NUMBERSK6"
        using A9 A10 sorry
      fix z assume [ty]: "z be ComplexXCMPLX-0M1"
      show " not ( not  |.COMPLEX1K10 z.| <XXREAL-0R3 q &  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 p0)"
        using A12 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_59:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds SumCOMSEQ-3K11 ((z1 +XCMPLX-0K2 z)ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) =COMPLEX1R1 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 z +XCMPLX-0K2 (z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4)"
proof(rule ballI,rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
  have "SumCOMSEQ-3K11 ((z1 +XCMPLX-0K2 z)ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) =HIDDENR1 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 1rCOMPLEX1K7"
    using sin_cos_lm_3 sorry
  also have "... = SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 (((SumCOMSEQ-3K11 (z ExpSeqSIN-COSK4) -XCMPLX-0K6 1rCOMPLEX1K7)-XCMPLX-0K6 z)+XCMPLX-0K2 z)"
     sorry
  also have "... = SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 (z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25) +XCMPLX-0K2 z)"
    using sin_cos_th_57 sorry
  also have "... = SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 z +XCMPLX-0K2 (z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4)"
     sorry
  finally have "SumCOMSEQ-3K11 ((z1 +XCMPLX-0K2 z)ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) =HIDDENR1 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 z +XCMPLX-0K2 (z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4)"
     sorry
  thus "SumCOMSEQ-3K11 ((z1 +XCMPLX-0K2 z)ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) =COMPLEX1R1 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4) *XCMPLX-0K3 z +XCMPLX-0K2 (z *XCMPLX-0K3 SumCOMSEQ-3K11 (z P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 (z1 ExpSeqSIN-COSK4)"
     sorry
qed "sorry"

mtheorem sin_cos_th_60:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 p =COMPLEX1R1 (-XCMPLX-0K4 q *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 p)-XCMPLX-0K6 q *XCMPLX-0K3 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
proof(rule ballI,rule ballI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix q assume [ty]: "q be RealXREAL-0M1"
  have "(cosSIN-COSK19).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 p =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using sin_cos_def_18 sorry
  also have "... = ReCOMPLEX1K3 SumCOMSEQ-3K11 (((p +XCMPLX-0K2 q)*XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using sin_cos_def_18 sorry
  also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8) +XCMPLX-0K2 q *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))"
    using complex1_th_19 sorry
  also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 (q *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))"
    using sin_cos_th_59 sorry
  also have "... = ReCOMPLEX1K3 (((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (q *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))"
    using sin_cos_lm_4 sorry
  also have "... = ReCOMPLEX1K3 (((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (q *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_lm_4 sorry
  also have "... = ReCOMPLEX1K3 ((-XCMPLX-0K4 q *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 p)+XCMPLX-0K2 (q *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 (((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using complex1_th_8 sorry
  also have "... = (-XCMPLX-0K4 q *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 p)+XCMPLX-0K2 ReCOMPLEX1K3 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8))))"
    using complex1_th_12 sorry
  also have "... = (-XCMPLX-0K4 q *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 p)-XCMPLX-0K6 q *XCMPLX-0K3 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_lm_12 sorry
  finally have "(cosSIN-COSK19).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 p =HIDDENR1 (-XCMPLX-0K4 q *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 p)-XCMPLX-0K6 q *XCMPLX-0K3 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
     sorry
  thus "(cosSIN-COSK19).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 p =COMPLEX1R1 (-XCMPLX-0K4 q *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 p)-XCMPLX-0K6 q *XCMPLX-0K3 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
     sorry
qed "sorry"

mtheorem sin_cos_th_61:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 q *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
proof(rule ballI,rule ballI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix q assume [ty]: "q be RealXREAL-0M1"
  have "(sinSIN-COSK17).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using sin_cos_def_16 sorry
  also have "... = ImCOMPLEX1K4 SumCOMSEQ-3K11 (((p +XCMPLX-0K2 q)*XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) -REAL-1K5 ImCOMPLEX1K4 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
    using sin_cos_def_16 sorry
  also have "... = ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8) +XCMPLX-0K2 q *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))"
    using complex1_th_19 sorry
  also have "... = ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 (q *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))"
    using sin_cos_th_59 sorry
  also have "... = ImCOMPLEX1K4 (((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (q *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4))"
    using sin_cos_lm_4 sorry
  also have "... = ImCOMPLEX1K4 (((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (q *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_lm_4 sorry
  also have "... = ImCOMPLEX1K4 ((-XCMPLX-0K4 q *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 p)+XCMPLX-0K2 (q *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ImCOMPLEX1K4 (((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using complex1_th_8 sorry
  also have "... = q *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 ImCOMPLEX1K4 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8))))"
    using complex1_th_12 sorry
  also have "... = q *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_lm_12 sorry
  finally have "(sinSIN-COSK17).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =HIDDENR1 q *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
     sorry
  thus "(sinSIN-COSK17).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 q *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((q *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
     sorry
qed "sorry"

mtheorem sin_cos_th_62:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)*XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25)"
proof(rule ballI,rule ballI)
  fix p assume [ty]: "p be RealXREAL-0M1"
  fix q assume [ty]: "q be RealXREAL-0M1"
  have "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 ReCOMPLEX1K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4)"
    using sin_cos_th_48 sorry
  also have "... = ReCOMPLEX1K3 SumCOMSEQ-3K11 ((p +XCMPLX-0K2 q)ExpSeqSIN-COSK4) -REAL-1K5 ReCOMPLEX1K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4)"
    using sin_cos_th_48 sorry
  also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((p +XCMPLX-0K2 q)ExpSeqSIN-COSK4) -XCMPLX-0K6 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4))"
    using complex1_th_19 sorry
  also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) *XCMPLX-0K3 q +XCMPLX-0K2 (q *XCMPLX-0K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4))"
    using sin_cos_th_59 sorry
  also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) *XCMPLX-0K3 q) +REAL-1K3 ReCOMPLEX1K3 ((q *XCMPLX-0K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4))"
    using complex1_th_8 sorry
  also have "... = q *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4) +XCMPLX-0K2 ReCOMPLEX1K3 ((q *XCMPLX-0K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25))*XCMPLX-0K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4))"
    using sin_cos_lm_12 sorry
  also have "... = q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 ReCOMPLEX1K3 (q *XCMPLX-0K3 (SumCOMSEQ-3K11 (q P-dtSIN-COSK25) *XCMPLX-0K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4)))"
    using sin_cos_th_48 sorry
  also have "... = q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 (q P-dtSIN-COSK25) *XCMPLX-0K3 SumCOMSEQ-3K11 (p ExpSeqSIN-COSK4))"
    using sin_cos_lm_12 sorry
  also have "... = q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 (q P-dtSIN-COSK25) *XCMPLX-0K3 SumSERIES-1K4 (p rExpSeqSIN-COSK5))"
    using sin_cos_lm_9 sorry
  also have "... = q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 (q P-dtSIN-COSK25) *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))"
    using sin_cos_def_22 sorry
  also have "... = q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 q *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25))"
    using sin_cos_lm_12 sorry
  also have "... = q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)*XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25)"
     sorry
  finally have "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =HIDDENR1 q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)*XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25)"
     sorry
  thus "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (q *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)*XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (q P-dtSIN-COSK25)"
     sorry
qed "sorry"

mtheorem sin_cos_th_63:
" for p be RealXREAL-0M1 holds cosSIN-COSK19 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(cosSIN-COSK19,p) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds cosSIN-COSK19 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(cosSIN-COSK19,p) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have 
      [ty]:"p be ElementSUBSET-1M1-of REALNUMBERSK2"
      using xreal_0_def_1 sorry
    let ?U = "\<lambda>Lamb1. InSUBSET-1K10(-XCMPLX-0K4 Lamb1 *XCMPLX-0K3 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((Lamb1 *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8))),REALNUMBERSK2)"
    obtain Cr where
      [ty]:"Cr be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A1: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds Cr .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> th =COMPLEX1R1 ?U(th)"
      using funct_2_sch_4 sorry
    have " for hy1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1 holds hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI)
      fix hy1 assume [ty]: "hy1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
      have A2: " for n be NatNAT-1M1 holds (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A4: "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using valued_1_th_10 sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
           sorry
        have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> Cr =XBOOLE-0R4 REALNUMBERSK2"
          using funct_2_def_1 sorry
        then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> hy1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> Cr"
           sorry
        then have A5: "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using A4 funct_2_th_108 A3 sorry
        also have "... = (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 ?U(hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using A1 sorry
        also have "... = -REAL-1K1 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)*REAL-1K4 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 -REAL-1K1 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)*REAL-1K4 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        have "hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using seq_1_th_5 sorry
        then have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          using A5 xcmplx_0_def_7 sorry
        also have "... = -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        thus "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
      qed "sorry"
      let ?U = "\<lambda>Lamb1. -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .FUNCT-1K1 Lamb1 *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
      obtain rseq where
        [ty]:"rseq be Real-SequenceSEQ-1M1" and 
        A6: " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
        using seq_1_sch_1 sorry
      let ?U = "\<lambda>Lamb1. SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8))"
      obtain cq1 where
        [ty]:"cq1 be Complex-SequenceCOMSEQ-1M1" and 
        A7: " for n be NatNAT-1M1 holds cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ?U(n)"
        using comseq_1_sch_1 sorry
      have A8: " for q be RealXREAL-0M1 holds q >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
      proof-
        have " for q be RealXREAL-0M1 holds q >XXREAL-0R4 0NUMBERSK6 implies  not ( for k be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)))"
        proof(rule ballI,rule impI)
          fix q assume [ty]: "q be RealXREAL-0M1"
          assume A9: "q >XXREAL-0R4 0NUMBERSK6"
          have " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
          proof-
            have " ex tVar17 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  not (tVar17 <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
            proof-
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A10: "r >XXREAL-0R4 0NUMBERSK6"and A11: " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 r implies  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 q"
                using A9 sin_cos_th_58 sorry
              have "hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 hy1 =COMPLEX1R1 0NUMBERSK6"
                 sorry
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A12: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
                using A10 seq_2_def_7 sorry
              have A13: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
              proof(rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume A14: "k <=XXREAL-0R1 m"
                have A15: " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| =HIDDENR1  |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)) .|"
                  using A7 sorry
                also have "... = ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8) .|)"
                  using complex1_th_65 sorry
                also have "... = ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|)*XCMPLX-0K3 ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|)"
                  using sin_cos_lm_4 sorry
                also have "... = ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|)*XCMPLX-0K3 \<one>\<^sub>M"
                  using sin_cos_lm_6 sorry
                also have "... =  |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|"
                   sorry
                finally have " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| =HIDDENR1  |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|"
                   sorry
                have A16: " |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
                  using A12 A14 sorry
                have "hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8)"
                   sorry
                then have "ReCOMPLEX1K3 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
                  using complex1_th_12 sorry
                then have " |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8) .| =COMPLEX1R1  |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|"
                  using complex1_th_72 sorry
                thus " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
                  using A11 A15 A16 sorry
              qed "sorry"
              show " ex tVar17 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  not (tVar17 <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
              proof(rule bexI[of _ "k"])
                show " for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
                  using A13 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          thus " not ( for k be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have A17: "cq1 be convergentCOMSEQ-2V3"
        using comseq_2_def_5 sorry
      then have "limCOMSEQ-2K3 cq1 =COMPLEX1R1 0cCOMPLEX1K6"
        using A8 comseq_2_def_6 sorry
      then have A18: "limCOMSEQ-2K3 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1) =COMPLEX1R1 -XCMPLX-0K4 0cCOMPLEX1K6"
        using A17 comseq_2_th_22 sorry
      have A19: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof-
        have " for n be NatNAT-1M1 holds  not (n be ElementSUBSET-1M1-of NATNUMBERSK1 &  not ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        proof(rule ballI)
          have A20: " for n be NatNAT-1M1 holds ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMPLEX1K4 ((-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using comseq_3_def_6 sorry
            also have "... = ImCOMPLEX1K4 (-XCMPLX-0K4 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using valued_1_th_8 sorry
            also have "... = ImCOMPLEX1K4 (-XCMPLX-0K4 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
              using A7 sorry
            also have "... = -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
              using complex1_th_17 sorry
            finally have "ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
               sorry
            thus "ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
               sorry
          qed "sorry"
          fix n assume [ty]: "n be NatNAT-1M1"
          have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
            using A6 sorry
          thus " not (n be ElementSUBSET-1M1-of NATNUMBERSK1 &  not ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
            using A20 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 ImCOMPLEX1K4 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          using A6 sorry
        thus "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A2 sorry
      qed "sorry"
      then have "rseq =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1"
         sorry
      then have "hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(omegaORDINAL1K4,COMPLEXNUMBERSK3)\<^esub> cq1)"
        using A19 sorry
      thus "hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =COMPLEX1R1 0NUMBERSK6"
        using A17 A18 complex1_th_4 comseq_3_th_41 sorry
    qed "sorry"
    then obtain PR where 
      [ty]:"PR be RestFuncFDIFF-1M1" and PRDef:"PR = Cr"
      using fdiff_1_def_2 sorry
    let ?U1 = "\<lambda>Lamb1. InSUBSET-1K10(-XCMPLX-0K4 Lamb1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,REALNUMBERSK2)"
    obtain CL where
      [ty]:"CL be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A21: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds CL .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> th =COMPLEX1R1 ?U1(th)"
      using funct_2_sch_4 sorry
    have " ex r be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 r *XCMPLX-0K3 q"
    proof-
      have " ex tVar18 be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 tVar18 *XCMPLX-0K3 q"
      proof-
        have A22: " for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 (-REAL-1K1 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)*XCMPLX-0K3 q"
        proof(rule ballI)
          fix q assume [ty]: "q be RealXREAL-0M1"
          obtain qq where 
            [ty]:"qq be ElementSUBSET-1M1-of REALNUMBERSK2" and qqDef:"qq = q"
            using xreal_0_def_1 sorry
          have "CL .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> qq =HIDDENR1 ?U1(q)"
            using A21 sorry
          also have "... = (-REAL-1K1 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)*XCMPLX-0K3 q"
             sorry
          finally have "CL .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> qq =HIDDENR1 (-REAL-1K1 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)*XCMPLX-0K3 q"
             sorry
          thus "CL .FUNCT-1K1 q =COMPLEX1R1 (-REAL-1K1 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)*XCMPLX-0K3 q"
             sorry
        qed "sorry"
        show " ex tVar18 be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 tVar18 *XCMPLX-0K3 q"
        proof(rule bexI[of _ "-REAL-1K1 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p"])
          show " for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 (-REAL-1K1 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)*XCMPLX-0K3 q"
            using A22 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain PL where 
      [ty]:"PL be LinearFuncFDIFF-1M2" and PLDef:"PL = CL"
      using fdiff_1_def_3 sorry
    have A23: " ex N be NeighbourhoodRCOMP-1M1-of p st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 N implies (cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
    proof-
      have " ex tVar19 be NeighbourhoodRCOMP-1M1-of p st (tVar19 be NeighbourhoodRCOMP-1M1-of p & tVar19 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 tVar19 &  not (cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
      proof-
        have A24: " for r be RealXREAL-0M1 holds r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ implies (cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
        proof-
          have " for r be RealXREAL-0M1 holds  not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
          proof(rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            have A25: "r -XCMPLX-0K6 p inTARSKIR2 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            have "r =COMPLEX1R1 p +XCMPLX-0K2 (r -XCMPLX-0K6 p)"
               sorry
            then have "(cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =HIDDENR1 (-XCMPLX-0K4 (r -XCMPLX-0K6 p)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)-XCMPLX-0K6 (r -XCMPLX-0K6 p)*XCMPLX-0K3 ImCOMPLEX1K4 (SumCOMSEQ-3K11 (((r -XCMPLX-0K6 p)*XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
              using sin_cos_th_60 sorry
            also have "... = (-XCMPLX-0K4 (r -XCMPLX-0K6 p)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)+XCMPLX-0K2 ?U(r -XCMPLX-0K6 p)"
               sorry
            also have "... = (-XCMPLX-0K4 (r -XCMPLX-0K6 p)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)+XCMPLX-0K2 Cr .FUNCT-1K1 (r -XCMPLX-0K6 p)"
              using A1 A25 sorry
            also have "... = ?U1(r -XCMPLX-0K6 p) +XCMPLX-0K2 Cr .FUNCT-1K1 (r -XCMPLX-0K6 p)"
               sorry
            also have "... = PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
              using A21 A25 sorry
            finally have "(cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =HIDDENR1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
               sorry
            thus " not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " ex tVar19 be NeighbourhoodRCOMP-1M1-of p st (tVar19 be NeighbourhoodRCOMP-1M1-of p & tVar19 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 tVar19 &  not (cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
        proof(rule bexI[of _ "].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .["])
          show "(].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ be NeighbourhoodRCOMP-1M1-of p & ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (cosSIN-COSK19).FUNCT-1K1 r -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
            using A24 sin_cos_th_24 rcomp_1_def_6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then have A26: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 p"
      using fdiff_1_def_4 sorry
    obtain jj where 
      [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
      using sin_cos_lm_1 numbers_th_19 sorry
    have "PL .FUNCT-1K1 jj =HIDDENR1 ?U1(\<one>\<^sub>M)"
      using A21 sorry
    also have "... = -REAL-1K1 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p"
       sorry
    finally have "PL .FUNCT-1K1 jj =HIDDENR1 -REAL-1K1 (sinSIN-COSK17).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p"
       sorry
    thus "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(cosSIN-COSK19,p) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 p"
      using A23 A26 fdiff_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_64:
" for p be RealXREAL-0M1 holds sinSIN-COSK17 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(sinSIN-COSK17,p) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds sinSIN-COSK17 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(sinSIN-COSK17,p) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have 
      [ty]:"p be RealXREAL-0M1"
       sorry
    let ?U = "\<lambda>Lamb1. InSUBSET-1K10(Lamb1 *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((Lamb1 *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8))),REALNUMBERSK2)"
    obtain Cr where
      [ty]:"Cr be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A1: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds Cr .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> th =COMPLEX1R1 ?U(th)"
      using funct_2_sch_4 sorry
    have " for hy1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1 holds hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI)
      fix hy1 assume [ty]: "hy1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
      have A2: " for n be NatNAT-1M1 holds (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A4: "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using valued_1_th_10 sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
           sorry
        have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> Cr =XBOOLE-0R4 REALNUMBERSK2"
          using funct_2_def_1 sorry
        then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> hy1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> Cr"
           sorry
        then have A5: "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using A4 funct_2_th_108 A3 sorry
        also have "... = (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 ?U(hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using A1 sorry
        also have "... = ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)*REAL-1K4 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)*REAL-1K4 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        have "hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using seq_1_th_5 sorry
        then have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          using A5 xcmplx_0_def_7 sorry
        also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        thus "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
      qed "sorry"
      let ?U = "\<lambda>Lamb1. ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .FUNCT-1K1 Lamb1 *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
      obtain rseq where
        [ty]:"rseq be Real-SequenceSEQ-1M1" and 
        A6: " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
        using seq_1_sch_1 sorry
      let ?U = "\<lambda>Lamb1. SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8))"
      obtain cq1 where
        [ty]:"cq1 be Complex-SequenceCOMSEQ-1M1" and 
        A7: " for n be NatNAT-1M1 holds cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ?U(n)"
        using comseq_1_sch_1 sorry
      have A8: " for q be RealXREAL-0M1 holds q >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
      proof-
        have " for q be RealXREAL-0M1 holds q >XXREAL-0R4 0NUMBERSK6 implies  not ( for k be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)))"
        proof(rule ballI,rule impI)
          fix q assume [ty]: "q be RealXREAL-0M1"
          assume A9: "q >XXREAL-0R4 0NUMBERSK6"
          have " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
          proof-
            have " ex tVar20 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  not (tVar20 <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
            proof-
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A10: "r >XXREAL-0R4 0NUMBERSK6"and A11: " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 r implies  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 q"
                using A9 sin_cos_th_58 sorry
              have "hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 hy1 =COMPLEX1R1 0NUMBERSK6"
                 sorry
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A12: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
                using A10 seq_2_def_7 sorry
              have A13: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
              proof(rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume A14: "k <=XXREAL-0R1 m"
                have A15: " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| =HIDDENR1  |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)) .|"
                  using A7 sorry
                also have "... = ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8) .|)"
                  using complex1_th_65 sorry
                also have "... = ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|)*XCMPLX-0K3 ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((p *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4).|)"
                  using sin_cos_lm_4 sorry
                also have "... = ( |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|)*XCMPLX-0K3 \<one>\<^sub>M"
                  using sin_cos_lm_6 sorry
                also have "... =  |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|"
                   sorry
                finally have " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| =HIDDENR1  |.COMPLEX1K10 SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25).|"
                   sorry
                have A16: " |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
                  using A12 A14 sorry
                have "hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8)"
                   sorry
                then have "ReCOMPLEX1K3 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
                  using complex1_th_12 sorry
                then have " |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m *XCMPLX-0K3 (<i>COMPLEX1K8) .| =COMPLEX1R1  |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|"
                  using complex1_th_72 sorry
                thus " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
                  using A11 A15 A16 sorry
              qed "sorry"
              show " ex tVar20 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  not (tVar20 <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
              proof(rule bexI[of _ "k"])
                show " for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
                  using A13 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          thus " not ( for k be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have A17: "cq1 be convergentCOMSEQ-2V3"
        using comseq_2_def_5 sorry
      then have A18: "limCOMSEQ-2K3 cq1 =COMPLEX1R1 0cCOMPLEX1K6"
        using A8 comseq_2_def_6 sorry
      have A19: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 (cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
          using comseq_3_def_5 sorry
        also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          using A7 sorry
        finally have "ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
           sorry
        thus "ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A6 sorry
      qed "sorry"
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (SumCOMSEQ-3K11 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
          using A6 sorry
        thus "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A2 sorry
      qed "sorry"
      then have "rseq =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1"
         sorry
      then have "hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 cq1"
        using A19 sorry
      thus "hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =COMPLEX1R1 0NUMBERSK6"
        using A17 A18 complex1_th_4 comseq_3_th_41 sorry
    qed "sorry"
    then obtain PR where 
      [ty]:"PR be RestFuncFDIFF-1M1" and PRDef:"PR = Cr"
      using fdiff_1_def_2 sorry
    let ?U1 = "\<lambda>Lamb1. InSUBSET-1K10(Lamb1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p,REALNUMBERSK2)"
    obtain CL where
      [ty]:"CL be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A20: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds CL .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> th =COMPLEX1R1 ?U1(th)"
      using funct_2_sch_4 sorry
    have A21: " for d be RealXREAL-0M1 holds CL .FUNCT-1K1 d =COMPLEX1R1 d *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p"
    proof(rule ballI)
      fix d assume [ty]: "d be RealXREAL-0M1"
      have "d inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      then have "CL .FUNCT-1K1 d =COMPLEX1R1 ?U1(d)"
        using A20 sorry
      thus "CL .FUNCT-1K1 d =COMPLEX1R1 d *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p"
         sorry
    qed "sorry"
    have " ex r be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 r *XCMPLX-0K3 q"
    proof-
      have " ex tVar21 be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 tVar21 *XCMPLX-0K3 q"
      proof-
        show " ex tVar21 be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 tVar21 *XCMPLX-0K3 q"
        proof(rule bexI[of _ "(cosSIN-COSK19).FUNCT-1K1 p"])
          show " for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 p *XCMPLX-0K3 q"
            using A21 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain PL where 
      [ty]:"PL be LinearFuncFDIFF-1M2" and PLDef:"PL = CL"
      using fdiff_1_def_3 sorry
    have A22: " ex N be NeighbourhoodRCOMP-1M1-of p st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 N implies (sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
    proof-
      have " ex tVar22 be NeighbourhoodRCOMP-1M1-of p st (tVar22 be NeighbourhoodRCOMP-1M1-of p & tVar22 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 tVar22 &  not (sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
      proof-
        have A23: " for r be RealXREAL-0M1 holds r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ implies (sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
        proof-
          have " for r be RealXREAL-0M1 holds  not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
          proof(rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            have A24: "r -XCMPLX-0K6 p inTARSKIR2 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            have "r =COMPLEX1R1 p +XCMPLX-0K2 (r -XCMPLX-0K6 p)"
               sorry
            then have "(sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =HIDDENR1 (r -XCMPLX-0K6 p)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (r -XCMPLX-0K6 p)*XCMPLX-0K3 ReCOMPLEX1K3 (SumCOMSEQ-3K11 (((r -XCMPLX-0K6 p)*XCMPLX-0K3 (<i>COMPLEX1K8))P-dtSIN-COSK25) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 p *XCMPLX-0K3 (<i>COMPLEX1K8)))"
              using sin_cos_th_61 sorry
            also have "... = (r -XCMPLX-0K6 p)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 ?U(r -XCMPLX-0K6 p)"
               sorry
            also have "... = (r -XCMPLX-0K6 p)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p +XCMPLX-0K2 Cr .FUNCT-1K1 (r -XCMPLX-0K6 p)"
              using A1 A24 sorry
            also have "... = PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
              using A21 sorry
            finally have "(sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =HIDDENR1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
               sorry
            thus " not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " ex tVar22 be NeighbourhoodRCOMP-1M1-of p st (tVar22 be NeighbourhoodRCOMP-1M1-of p & tVar22 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 tVar22 &  not (sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
        proof(rule bexI[of _ "].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .["])
          show "(].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ be NeighbourhoodRCOMP-1M1-of p & ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (sinSIN-COSK17).FUNCT-1K1 r -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
            using A23 sin_cos_th_24 rcomp_1_def_6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then have A25: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 p"
      using fdiff_1_def_4 sorry
    have "PL .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 p"
      using A21 sorry
    thus "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(sinSIN-COSK17,p) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 p"
      using A22 A25 fdiff_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_65:
" for p be RealXREAL-0M1 holds exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(exp-RSIN-COSK23,p) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(exp-RSIN-COSK23,p) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    let ?U = "\<lambda>Lamb1. InSUBSET-1K10((Lamb1 *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)*XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (Lamb1 P-dtSIN-COSK25),REALNUMBERSK2)"
    obtain Cr where
      [ty]:"Cr be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A1: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds Cr .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> th =COMPLEX1R1 ?U(th)"
      using funct_2_sch_4 sorry
    have " for hy1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1 holds hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI)
      fix hy1 assume [ty]: "hy1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
      have A2: " for n be NatNAT-1M1 holds (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A4: "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using valued_1_th_10 sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
           sorry
        have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> Cr =XBOOLE-0R4 REALNUMBERSK2"
          using funct_2_def_1 sorry
        then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> hy1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> Cr"
           sorry
        then have A5: "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 Cr .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using A4 funct_2_th_108 A3 sorry
        also have "... = (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 ?U(hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using A1 sorry
        also have "... = ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25))"
           sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25))"
           sorry
        have "hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using seq_1_th_5 sorry
        then have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25))"
          using A5 xcmplx_0_def_7 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
           sorry
        finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
           sorry
        thus "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
           sorry
      qed "sorry"
      let ?U = "\<lambda>Lamb1. (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .FUNCT-1K1 Lamb1 P-dtSIN-COSK25)"
      obtain rseq where
        [ty]:"rseq be Real-SequenceSEQ-1M1" and 
        A6: " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
        using seq_1_sch_1 sorry
      let ?U = "\<lambda>Lamb1. SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 P-dtSIN-COSK25) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p"
      obtain cq1 where
        [ty]:"cq1 be Complex-SequenceCOMSEQ-1M1" and 
        A7: " for n be NatNAT-1M1 holds cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ?U(n)"
        using comseq_1_sch_1 sorry
      have A8: " for q be RealXREAL-0M1 holds q >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
      proof-
        have " for q be RealXREAL-0M1 holds q >XXREAL-0R4 0NUMBERSK6 implies  not ( for k be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)))"
        proof(rule ballI,rule impI)
          fix q assume [ty]: "q be RealXREAL-0M1"
          assume A9: "q >XXREAL-0R4 0NUMBERSK6"
          have " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
          proof-
            have " ex tVar23 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  not (tVar23 <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
            proof-
              have "(exp-RSIN-COSK23).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6"
                using sin_cos_th_54 sorry
              then obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A10: "r >XXREAL-0R4 0NUMBERSK6"and A11: " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 r implies  |.COMPLEX1K10 SumCOMSEQ-3K11 (z P-dtSIN-COSK25).| <XXREAL-0R3 q /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 p"
                using A9 sin_cos_th_58 sorry
              have "hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 hy1 =COMPLEX1R1 0NUMBERSK6"
                 sorry
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A12: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
                using A10 seq_2_def_7 sorry
              have A13: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
              proof(rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume A14: "k <=XXREAL-0R1 m"
                have A15: " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| =HIDDENR1  |.COMPLEX1K10 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m P-dtSIN-COSK25) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p .|"
                  using A7 sorry
                also have "... = ( |.COMPLEX1K10 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m P-dtSIN-COSK25).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (exp-RSIN-COSK23).FUNCT-1K1 p.|)"
                  using complex1_th_65 sorry
                also have "... = ( |.COMPLEX1K10 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m P-dtSIN-COSK25).|)*XCMPLX-0K3 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 ((exp-RSIN-COSK23).FUNCT-1K1 p))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 ((exp-RSIN-COSK23).FUNCT-1K1 p))^2SQUARE-1K1)"
                   sorry
                finally have " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| =HIDDENR1 ( |.COMPLEX1K10 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m P-dtSIN-COSK25).|)*XCMPLX-0K3 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 ((exp-RSIN-COSK23).FUNCT-1K1 p))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 ((exp-RSIN-COSK23).FUNCT-1K1 p))^2SQUARE-1K1)"
                   sorry
                have "(exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
                   sorry
                then have A16: "ReCOMPLEX1K3 ((exp-RSIN-COSK23).FUNCT-1K1 p) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p & ImCOMPLEX1K4 ((exp-RSIN-COSK23).FUNCT-1K1 p) =COMPLEX1R1 0NUMBERSK6"
                  using complex1_th_12 sorry
                have A17: "(exp-RSIN-COSK23).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6"
                  using sin_cos_th_54 sorry
                then have A18: " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| =COMPLEX1R1 ( |.COMPLEX1K10 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m P-dtSIN-COSK25).|)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p"
                  using A15 A16 square_1_th_22 sorry
                have " |.COMPLEX1K10 hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
                  using A12 A14 sorry
                then have " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 (q /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 p)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p"
                  using A11 A17 A18 xreal_1_th_68 sorry
                thus " |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q"
                  using A17 xcmplx_1_th_87 sorry
              qed "sorry"
              show " ex tVar23 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  not (tVar23 <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
              proof(rule bexI[of _ "k"])
                show " for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)"
                  using A13 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          thus " not ( for k be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (k <=XXREAL-0R1 m &  |.COMPLEX1K10 cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 q)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have A19: "cq1 be convergentCOMSEQ-2V3"
        using comseq_2_def_5 sorry
      then have A20: "limCOMSEQ-2K3 cq1 =COMPLEX1R1 0cCOMPLEX1K6"
        using A8 comseq_2_def_6 sorry
      have A21: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof-
        have " for n be NatNAT-1M1 holds  not (n be ElementSUBSET-1M1-of NATNUMBERSK1 &  not ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        proof(rule ballI)
          have A22: " for n be NatNAT-1M1 holds ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 (cq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using comseq_3_def_5 sorry
            also have "... = ReCOMPLEX1K3 (SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)"
              using A7 sorry
            also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
              using sin_cos_lm_12 sorry
            finally have "ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
               sorry
            thus "ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
               sorry
          qed "sorry"
          fix n assume [ty]: "n be NatNAT-1M1"
          have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
            using A6 sorry
          thus " not (n be ElementSUBSET-1M1-of NATNUMBERSK1 &  not ReCOMSEQ-3K7 cq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
            using A22 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n P-dtSIN-COSK25)"
          using A6 sorry
        thus "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A2 sorry
      qed "sorry"
      then have "rseq =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1"
         sorry
      then have "hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 cq1"
        using A21 sorry
      thus "hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be convergentCOMSEQ-2V3 & limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Cr /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =COMPLEX1R1 0NUMBERSK6"
        using A19 A20 complex1_th_4 comseq_3_th_41 sorry
    qed "sorry"
    then obtain PR where 
      [ty]:"PR be RestFuncFDIFF-1M1" and PRDef:"PR = Cr"
      using fdiff_1_def_2 sorry
    let ?U1 = "\<lambda>Lamb1. InSUBSET-1K10(Lamb1 *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p,REALNUMBERSK2)"
    obtain CL where
      [ty]:"CL be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A23: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds CL .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> th =COMPLEX1R1 ?U1(th)"
      using funct_2_sch_4 sorry
    have A24: " for d be RealXREAL-0M1 holds CL .FUNCT-1K1 d =COMPLEX1R1 d *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p"
    proof(rule ballI)
      fix d assume [ty]: "d be RealXREAL-0M1"
      have "d inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      then have "CL .FUNCT-1K1 d =COMPLEX1R1 ?U1(d)"
        using A23 sorry
      thus "CL .FUNCT-1K1 d =COMPLEX1R1 d *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p"
         sorry
    qed "sorry"
    have " ex r be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 r *XCMPLX-0K3 q"
    proof-
      have " ex tVar24 be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 tVar24 *XCMPLX-0K3 q"
      proof-
        show " ex tVar24 be RealXREAL-0M1 st  for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 tVar24 *XCMPLX-0K3 q"
        proof(rule bexI[of _ "(exp-RSIN-COSK23).FUNCT-1K1 p"])
          show " for q be RealXREAL-0M1 holds CL .FUNCT-1K1 q =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 q"
            using A24 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain PL where 
      [ty]:"PL be LinearFuncFDIFF-1M2" and PLDef:"PL = CL"
      using fdiff_1_def_3 sorry
    have A25: " ex N be NeighbourhoodRCOMP-1M1-of p st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 N implies (exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
    proof-
      have " ex tVar25 be NeighbourhoodRCOMP-1M1-of p st (tVar25 be NeighbourhoodRCOMP-1M1-of p & tVar25 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 tVar25 &  not (exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
      proof-
        have A26: " for r be RealXREAL-0M1 holds r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ implies (exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
        proof-
          have " for r be RealXREAL-0M1 holds  not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
          proof(rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            have 
              [ty]:"p be RealXREAL-0M1"
               sorry
            have A27: "r -XCMPLX-0K6 p inTARSKIR2 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            have "r =COMPLEX1R1 p +XCMPLX-0K2 (r -XCMPLX-0K6 p)"
               sorry
            then have "(exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =HIDDENR1 (r -XCMPLX-0K6 p)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 ((r -XCMPLX-0K6 p)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)*XCMPLX-0K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 ((r -XCMPLX-0K6 p)P-dtSIN-COSK25)"
              using sin_cos_th_62 sorry
            also have "... = (r -XCMPLX-0K6 p)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 ?U(r -XCMPLX-0K6 p)"
               sorry
            also have "... = (r -XCMPLX-0K6 p)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 Cr .FUNCT-1K1 (r -XCMPLX-0K6 p)"
              using A1 A27 sorry
            also have "... = PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
              using A24 sorry
            finally have "(exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =HIDDENR1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)"
               sorry
            thus " not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " ex tVar25 be NeighbourhoodRCOMP-1M1-of p st (tVar25 be NeighbourhoodRCOMP-1M1-of p & tVar25 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 tVar25 &  not (exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
        proof(rule bexI[of _ "].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .["])
          show "(].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ be NeighbourhoodRCOMP-1M1-of p & ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p =COMPLEX1R1 PL .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 PR .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
            using A26 sin_cos_th_47 rcomp_1_def_6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then have A28: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 p"
      using fdiff_1_def_4 sorry
    have "PL .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p"
      using A24 sorry
    thus "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(exp-RSIN-COSK23,p) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 p"
      using A25 A28 fdiff_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_66:
" for th be RealXREAL-0M1 holds exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(exp-RSIN-COSK23,th) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 th"
proof-
  have " for th be RealXREAL-0M1 holds exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(exp-RSIN-COSK23,th) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 th"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have A1: "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 & REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      using funct_2_def_1 sorry
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 REALNUMBERSK2 implies exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 r"
      using sin_cos_th_65 sorry
    thus "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(exp-RSIN-COSK23,th) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 th"
      using A1 sin_cos_th_65 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_67:
" for th be RealXREAL-0M1 holds cosSIN-COSK19 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(cosSIN-COSK19,th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
proof-
  have " for th be RealXREAL-0M1 holds cosSIN-COSK19 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(cosSIN-COSK19,th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have A1: "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 & REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
      using funct_2_def_1 sorry
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 REALNUMBERSK2 implies cosSIN-COSK19 is-differentiable-inFDIFF-1R1 r"
      using sin_cos_th_63 sorry
    thus "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(cosSIN-COSK19,th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
      using A1 sin_cos_th_63 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_68:
" for th be RealXREAL-0M1 holds sinSIN-COSK17 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(sinSIN-COSK17,th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th"
proof-
  have " for th be RealXREAL-0M1 holds sinSIN-COSK17 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(sinSIN-COSK17,th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have A1: "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 & REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
      using funct_2_def_1 sorry
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 REALNUMBERSK2 implies sinSIN-COSK17 is-differentiable-inFDIFF-1R1 r"
      using sin_cos_th_64 sorry
    thus "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(sinSIN-COSK17,th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th"
      using A1 sin_cos_th_64 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_69:
" for th be RealXREAL-0M1 holds th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] implies 0NUMBERSK6 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 th & (cosSIN-COSK19).FUNCT-1K1 th >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] implies  not 0NUMBERSK6 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 th & (cosSIN-COSK19).FUNCT-1K1 th >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule impI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume "th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
    then have A1: "0NUMBERSK6 <=XXREAL-0R1 th & th <=XXREAL-0R1 \<one>\<^sub>M"
      using xxreal_1_th_1 sorry
    have A2: "Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) be convergentCOMSEQ-2V3"
      using sin_cos_th_36 sorry
    have A3: "(cosSIN-COSK19).FUNCT-1K1 th =COMPLEX1R1 SumSERIES-1K4 (th P-cosSIN-COSK22)"
      using sin_cos_th_37 sorry
    let ?U = "\<lambda>Lamb1. \<two>\<^sub>M *XCMPLX-0K3 Lamb1 +XCMPLX-0K2 \<one>\<^sub>M"
    obtain bq where
      [ty]:"bq be Real-SequenceSEQ-1M1" and 
      Lm6: " for n be NatNAT-1M1 holds bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
      using seq_1_sch_1 sorry
    have "bq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    proof-
      have A1: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <XXREAL-0R3 k implies bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
      proof-
        have " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <XXREAL-0R3 k implies  not bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
        proof(rule ballI,rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "n <XXREAL-0R3 k"
          then have "\<two>\<^sub>M *XCMPLX-0K3 n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 k"
            using xreal_1_th_68 sorry
          then have "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M"
            using xreal_1_th_6 sorry
          then have "bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M"
            using Lm6 sorry
          thus " not bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            using Lm6 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be NatNAT-1M1 holds bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
           sorry
        thus "bq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using Lm6 sorry
      qed "sorry"
      thus "bq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
        using A1 seqm_3_th_1 seqm_3_th_13 sorry
    qed
    then have 
      [ty]:"bq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
       sorry
    have "limSEQ-2K1 (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq) =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22)"
      using A2 seq_4_th_17 sorry
    then have A4: "limSEQ-2K1 (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th"
      using A3 series_1_def_3 sorry
    have " for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A5: "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6))"
        using funct_2_th_15 sorry
      also have "... = Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)"
        using Lm6 sorry
      also have "... = Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))!SIN-COSK3) +XCMPLX-0K2 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
        using sin_cos_def_21 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (0NUMBERSK6) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))!SIN-COSK3) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
        using sin_cos_def_21 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))!SIN-COSK3) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
        using sin_cos_lm_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 \<one>\<^sub>M *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
        using newton_th_4 newton_th_12 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
         sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (th *XCMPLX-0K3 th))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)!SIN-COSK3)"
        using newton_th_81 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 th ^2SQUARE-1K1 /XCMPLX-0K7 \<two>\<^sub>M"
        using newton_th_14 sorry
      finally have "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 th ^2SQUARE-1K1 /XCMPLX-0K7 \<two>\<^sub>M"
         sorry
      let ?X = "\<lambda>Lamb1. (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
      have "th ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M ^2SQUARE-1K1"
        using A1 square_1_th_15 sorry
      then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M & th ^2SQUARE-1K1 /XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_72 sorry
      then have A6: "?X(0NUMBERSK6)"
        using A5 xreal_1_th_10 sorry
      have A7: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A8: "k inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume A9: "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
          have "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
            using funct_2_th_15 sorry
          also have "... = Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using Lm6 sorry
          also have "... = Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (bq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k) +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using Lm6 sorry
          also have "... = ((Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_th_15 A8 sorry
          finally have "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
             sorry
          then have A10: "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +REAL-1K3 (th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
             sorry
          have A11: "(th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
            using sin_cos_def_21 sorry
          also have "... = (\<one>\<^sub>M *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
            using sin_cos_lm_7 sorry
          also have "... = th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))) /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
             sorry
          finally have "(th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((\<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))) /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
             sorry
          have A12: "(th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M) |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
            using sin_cos_def_21 sorry
          also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
            using sin_cos_lm_7 sorry
          finally have "(th P-cosSIN-COSK22).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)"
             sorry
          have A13: "\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
            using xreal_1_th_29 xreal_1_th_68 sorry
          then have A14: "(\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3 <=XXREAL-0R1 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3"
            using sin_cos_th_39 sorry
          have A15: "th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))"
            using A1 A13 sin_cos_th_40 sorry
          have A16: "0NUMBERSK6 <=XXREAL-0R1 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)) & (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3 >XXREAL-0R4 0NUMBERSK6"
            using power_th_3 sorry
          have "\<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3)"
            using A14 xreal_1_th_85 sorry
          then have "th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3)) <=XXREAL-0R1 th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3))"
            using A15 A16 xreal_1_th_66 sorry
          then have "(th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))) *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M)))!SIN-COSK3) -XCMPLX-0K6 (th  |^COMSEQ-3K2 (\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((\<two>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))!SIN-COSK3) >=XXREAL-0R2 0NUMBERSK6"
            using xreal_1_th_48 sorry
          then have "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            using A10 A11 A12 xreal_1_th_49 sorry
          thus "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
            using A9 xxreal_0_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for n be NatNAT-1M1 holds ?X(n)"
        using nat_1_sch_2 A6 A7 sorry
      thus "(Partial-SumsSERIES-1K3 (th P-cosSIN-COSK22) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> bq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
         sorry
    qed "sorry"
    thus " not 0NUMBERSK6 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 th & (cosSIN-COSK19).FUNCT-1K1 th >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
      using A2 A4 prepower_th_1 seq_4_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef sin_cos_def_26 ("tanSIN-COSK27" 164 ) where
"func tanSIN-COSK27 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  (sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)"
proof-
  (*coherence*)
    show "(sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef sin_cos_def_27 ("cotSIN-COSK28" 164 ) where
"func cotSIN-COSK28 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  (cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
proof-
  (*coherence*)
    show "(cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem sin_cos_th_70:
"[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) & ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
proof-
  have A1: "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    using sin_cos_th_24 xboole_1_th_33 sorry
  have "([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
  proof-
    have "([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume "([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1"
      then obtain rr where
        [ty]:"rr be objectHIDDENM1" and 
        A2: "rr inHIDDENR3 ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using xboole_0_def_1 sorry
      have A3: "rr inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
        using A2 xboole_0_def_4 sorry
      have A4: "rr inHIDDENR3 (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A2 xboole_0_def_4 sorry
      have A5: "(cosSIN-COSK19).FUNCT-1K1 rr <>HIDDENR2 0NUMBERSK6"
        using A3 sin_cos_th_69 sorry
      have "(cosSIN-COSK19).FUNCT-1K1 rr inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using A4 funct_1_def_7 sorry
      thus " False "
        using A5 tarski_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  then have "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] missesXBOOLE-0R1 (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    using xboole_0_def_7 sorry
  then have "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    using A1 xboole_1_th_83 sorry
  then have "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
    using sin_cos_th_24 xboole_1_th_19 sorry
  then have A6: "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
    using rfunct_1_def_1 sorry
  have "].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ c=TARSKIR1 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
    using xxreal_1_th_25 sorry
  thus "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) & ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
    using A6 xboole_1_th_1 sorry
qed

mlemma sin_cos_lm_14:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] & ( for th be RealXREAL-0M1 holds th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] implies ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])).FUNCT-1K1 th =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 th)"
proof-
  have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] & ( for th be RealXREAL-0M1 holds  not (th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] &  not ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])).FUNCT-1K1 th =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 th))"
  proof-
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])"
      using relat_1_th_61 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
      using sin_cos_th_70 xboole_1_th_28 sorry
    thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] & ( for th be RealXREAL-0M1 holds  not (th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] &  not ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])).FUNCT-1K1 th =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 th))"
      using funct_1_th_47 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma sin_cos_lm_15:
"tanSIN-COSK27 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & ( for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ implies diffFDIFF-1K1(tanSIN-COSK27,th) >XXREAL-0R4 0NUMBERSK6)"
proof-
  have "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & ( for th be RealXREAL-0M1 holds  not (th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) >XXREAL-0R4 0NUMBERSK6))"
  proof-
    have A1: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & cosSIN-COSK19 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
      using sin_cos_th_67 sin_cos_th_68 fdiff_1_th_26 sorry
    have A2: " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ implies (cosSIN-COSK19).FUNCT-1K1 th <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ implies  not (cosSIN-COSK19).FUNCT-1K1 th <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix th assume [ty]: "th be RealXREAL-0M1"
        assume A3: "th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
        have "].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ c=TARSKIR1 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
          using xxreal_1_th_25 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 th <>HIDDENR2 0NUMBERSK6"
          using A3 sin_cos_th_69 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ implies diffFDIFF-1K1(tanSIN-COSK27,th) >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ implies  not diffFDIFF-1K1(tanSIN-COSK27,th) >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix th assume [ty]: "th be RealXREAL-0M1"
        assume A4: "th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
        have A5: "th be RealXREAL-0M1 & cosSIN-COSK19 is-differentiable-inFDIFF-1R1 th"
          using sin_cos_th_63 sorry
        have A6: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 th"
          using sin_cos_th_64 sorry
        have A7: "(cosSIN-COSK19).FUNCT-1K1 th <>HIDDENR2 0NUMBERSK6"
          using A2 A4 sorry
        then have A8: "diffFDIFF-1K1(tanSIN-COSK27,th) =HIDDENR1 ((diffFDIFF-1K1(sinSIN-COSK17,th))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th -XCMPLX-0K6 (diffFDIFF-1K1(cosSIN-COSK19,th))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1"
          using A5 A6 fdiff_2_th_14 sorry
        also have "... = ((cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th -XCMPLX-0K6 (diffFDIFF-1K1(cosSIN-COSK19,th))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1"
          using sin_cos_th_64 sorry
        also have "... = ((cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1"
          using sin_cos_th_63 sorry
        also have "... = (((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1"
           sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1"
          using sin_cos_th_28 sorry
        finally have "diffFDIFF-1K1(tanSIN-COSK27,th) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1"
           sorry
        have "((cosSIN-COSK19).FUNCT-1K1 th)^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
          using A7 square_1_th_12 sorry
        thus " not diffFDIFF-1K1(tanSIN-COSK27,th) >XXREAL-0R4 0NUMBERSK6"
          using A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & ( for th be RealXREAL-0M1 holds  not (th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) >XXREAL-0R4 0NUMBERSK6))"
      using A1 A2 fdiff_2_th_21 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_71:
"(tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) be continuousFCONT-1V1"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])) implies (tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) is-continuous-inFCONT-1R1 th"
  proof(rule ballI,rule impI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume A1: "th inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))"
    then have A2: "th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
      using relat_1_th_57 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) =XBOOLE-0R4 REALNUMBERSK2"
      using funct_2_def_1 sorry
    then have A3: "th inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)"
      using xreal_0_def_1 sorry
    have A4: "th inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 th"
      using sin_cos_th_68 fdiff_1_th_9 sorry
    then have A5: "sinSIN-COSK17 is-continuous-inFCONT-1R1 th"
      using fdiff_1_th_24 sorry
    have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 th"
      using A4 sin_cos_th_67 fdiff_1_th_9 sorry
    then have A6: "cosSIN-COSK19 is-continuous-inFCONT-1R1 th"
      using fdiff_1_th_24 sorry
    have "(cosSIN-COSK19).FUNCT-1K1 th <>HIDDENR2 0NUMBERSK6"
      using A2 sin_cos_th_69 sorry
    then have A7: "tanSIN-COSK27 is-continuous-inFCONT-1R1 th"
      using A3 A5 A6 fcont_1_th_11 sorry
    have " for rseq be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> rseq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])) & (rseq be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq =COMPLEX1R1 th) implies ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq be convergentCOMSEQ-2V3 & ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])).FUNCT-1K1 th =COMPLEX1R1 limSEQ-2K1 ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq"
    proof(rule ballI,rule impMI ,rule impI)
      fix rseq assume [ty]: "rseq be Real-SequenceSEQ-1M1"
      assume A8: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> rseq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))"
        and A9: "rseq be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq =COMPLEX1R1 th"
      have A10: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> rseq c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
        using A8 sin_cos_lm_14 sin_cos_th_70 xboole_1_th_1 sorry
      then have A11: "(tanSIN-COSK27).FUNCT-1K1 th =COMPLEX1R1 limSEQ-2K1 (tanSIN-COSK27)/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq"
        using A7 A9 fcont_1_def_1 sorry
      have " for k1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1 =COMPLEX1R1 (tanSIN-COSK27)/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1"
      proof(rule ballI)
        fix k1 assume [ty]: "k1 be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> rseq =XBOOLE-0R4 NATNUMBERSK1"
          using seq_1_th_1 sorry
        then have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> rseq"
          using funct_1_def_3 sorry
        then have A12: "((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])).FUNCT-1K1 (rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1) =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 (rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1)"
          using A8 sin_cos_lm_14 sorry
        have "((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])).FUNCT-1K1 (rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1) =COMPLEX1R1 ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1"
          using A8 funct_2_th_108 sorry
        thus "((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1 =COMPLEX1R1 (tanSIN-COSK27)/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k1"
          using A8 A12 sin_cos_lm_14 sin_cos_th_70 funct_2_th_108 xboole_1_th_1 sorry
      qed "sorry"
      then have "((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq"
         sorry
      thus "((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq be convergentCOMSEQ-2V3 & ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])).FUNCT-1K1 th =COMPLEX1R1 limSEQ-2K1 ((tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]))/*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> rseq"
        using A1 A7 A9 A10 A11 sin_cos_lm_14 fcont_1_def_1 sorry
    qed "sorry"
    thus "(tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) is-continuous-inFCONT-1R1 th"
      using fcont_1_def_1 sorry
  qed "sorry"
  thus "(tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) be continuousFCONT-1V1"
    using fcont_1_def_2 sorry
qed

mtheorem sin_cos_th_72:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & th2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[) & (tanSIN-COSK27).FUNCT-1K1 th1 =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 th2 implies th1 =COMPLEX1R1 th2"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & (th2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & (tanSIN-COSK27).FUNCT-1K1 th1 =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 th2) implies (th1 <>HIDDENR2 th2 implies  not  True )"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
      and A2: "th2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
      and A3: "(tanSIN-COSK27).FUNCT-1K1 th1 =COMPLEX1R1 (tanSIN-COSK27).FUNCT-1K1 th2"
    have A4: "0NUMBERSK6 <XXREAL-0R3 th1"
      using A1 xxreal_1_th_4 sorry
    have A5: "th1 <XXREAL-0R3 \<one>\<^sub>M"
      using A1 xxreal_1_th_4 sorry
    have A6: "0NUMBERSK6 <XXREAL-0R3 th2"
      using A2 xxreal_1_th_4 sorry
    have A7: "th2 <XXREAL-0R3 \<one>\<^sub>M"
      using A2 xxreal_1_th_4 sorry
    assume A8: "th1 <>HIDDENR2 th2"
    have " ex th be RealXREAL-0M1 st th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) =COMPLEX1R1 0NUMBERSK6"
    proof-
      show " ex th be RealXREAL-0M1 st th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) =COMPLEX1R1 0NUMBERSK6"
      proof-
        have cases: "th1 <XXREAL-0R3 th2 or th2 <XXREAL-0R3 th1"
          using A8 xxreal_0_th_1 sorry
        have case1: "th1 <XXREAL-0R3 th2 implies ( ex th be RealXREAL-0M1 st th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) =COMPLEX1R1 0NUMBERSK6)"
        proof(rule impI)
          assume A9: "th1 <XXREAL-0R3 th2"
          have A10: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds th inTARSKIR2 ].RCOMP-1K2 th1,th2 .[ implies th inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
          proof(rule ballI,rule impI)
            fix th assume [ty]: "th be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A11: "th inTARSKIR2 ].RCOMP-1K2 th1,th2 .["
            then have A12: "th1 <XXREAL-0R3 th"
              using xxreal_1_th_4 sorry
            have "th <XXREAL-0R3 th2"
              using A11 xxreal_1_th_4 sorry
            then have "th <XXREAL-0R3 \<one>\<^sub>M"
              using A7 xxreal_0_th_2 sorry
            thus "th inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
              using A4 A12 xxreal_1_th_4 sorry
          qed "sorry"
          have A13: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds th inTARSKIR2 [.RCOMP-1K1 th1,th2 .] implies th inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
          proof(rule ballI,rule impI)
            fix th assume [ty]: "th be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A14: "th inTARSKIR2 [.RCOMP-1K1 th1,th2 .]"
            then have A15: "th1 <=XXREAL-0R1 th"
              using xxreal_1_th_1 sorry
            have "th <=XXREAL-0R1 th2"
              using A14 xxreal_1_th_1 sorry
            then have "th <=XXREAL-0R1 \<one>\<^sub>M"
              using A7 xxreal_0_th_2 sorry
            thus "th inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
              using A4 A15 xxreal_1_th_1 sorry
          qed "sorry"
          have "].RCOMP-1K2 th1,th2 .[ c=TARSKIR1 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
            using A10 subset_1_th_2 sorry
          then have A16: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 th1,th2 .["
            using sin_cos_lm_15 fdiff_1_th_26 sorry
          have "[.RCOMP-1K1 th1,th2 .] c=TARSKIR1 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] & (tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 th1,th2 .]) be continuousFCONT-1V1"
            using A13 sin_cos_th_71 fcont_1_th_16 subset_1_th_2 sorry
          then obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A17: "r inHIDDENR3 ].RCOMP-1K2 th1,th2 .[ & diffFDIFF-1K1(tanSIN-COSK27,r) =COMPLEX1R1 0NUMBERSK6"
            using A3 A9 A16 sin_cos_th_70 rolle_th_1 xboole_1_th_1 sorry
          obtain th where 
            [ty]:"th be RealXREAL-0M1" and thDef:"th = r"
             sorry
          show " ex th be RealXREAL-0M1 st th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) =COMPLEX1R1 0NUMBERSK6"
          proof(rule bexI[of _ "th"])
            show "th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) =COMPLEX1R1 0NUMBERSK6"
              using A10 A17 sorry
          qed "sorry"
        qed
        have case2: "th2 <XXREAL-0R3 th1 implies ( ex th be RealXREAL-0M1 st th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) =COMPLEX1R1 0NUMBERSK6)"
        proof(rule impI)
          assume A18: "th2 <XXREAL-0R3 th1"
          have A19: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds th inTARSKIR2 ].RCOMP-1K2 th2,th1 .[ implies th inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
          proof(rule ballI,rule impI)
            fix th assume [ty]: "th be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A20: "th inTARSKIR2 ].RCOMP-1K2 th2,th1 .["
            then have A21: "th2 <XXREAL-0R3 th"
              using xxreal_1_th_4 sorry
            have "th <XXREAL-0R3 th1"
              using A20 xxreal_1_th_4 sorry
            then have "th <XXREAL-0R3 \<one>\<^sub>M"
              using A5 xxreal_0_th_2 sorry
            thus "th inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
              using A6 A21 xxreal_1_th_4 sorry
          qed "sorry"
          have A22: " for th be ElementSUBSET-1M1-of REALNUMBERSK2 holds th inTARSKIR2 [.RCOMP-1K1 th2,th1 .] implies th inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
          proof(rule ballI,rule impI)
            fix th assume [ty]: "th be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A23: "th inTARSKIR2 [.RCOMP-1K1 th2,th1 .]"
            then have A24: "th2 <=XXREAL-0R1 th"
              using xxreal_1_th_1 sorry
            have "th <=XXREAL-0R1 th1"
              using A23 xxreal_1_th_1 sorry
            then have "th <=XXREAL-0R1 \<one>\<^sub>M"
              using A5 xxreal_0_th_2 sorry
            thus "th inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
              using A6 A24 xxreal_1_th_1 sorry
          qed "sorry"
          have "].RCOMP-1K2 th2,th1 .[ c=TARSKIR1 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
            using A19 subset_1_th_2 sorry
          then have A25: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 th2,th1 .["
            using sin_cos_lm_15 fdiff_1_th_26 sorry
          have "[.RCOMP-1K1 th2,th1 .] c=TARSKIR1 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] & (tanSIN-COSK27) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 th2,th1 .]) be continuousFCONT-1V1"
            using A22 sin_cos_th_71 fcont_1_th_16 subset_1_th_2 sorry
          then obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A26: "r inHIDDENR3 ].RCOMP-1K2 th2,th1 .[ & diffFDIFF-1K1(tanSIN-COSK27,r) =COMPLEX1R1 0NUMBERSK6"
            using A3 A18 A25 sin_cos_th_70 rolle_th_1 xboole_1_th_1 sorry
          obtain th where 
            [ty]:"th be RealXREAL-0M1" and thDef:"th = r"
             sorry
          show " ex th be RealXREAL-0M1 st th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) =COMPLEX1R1 0NUMBERSK6"
          proof(rule bexI[of _ "th"])
            show "th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ & diffFDIFF-1K1(tanSIN-COSK27,th) =COMPLEX1R1 0NUMBERSK6"
              using A19 A26 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not  True "
      using sin_cos_lm_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos_lm_16:
"(tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 & (tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have "(tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 &  not (tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M"
  proof-
    have "0NUMBERSK6 inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    then have A1: "(tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6))\<inverse>XCMPLX-0K5"
      using sin_cos_th_70 rfunct_1_def_1 sorry
    also have "... = 0NUMBERSK6"
      using sin_cos_th_30 sorry
    finally have "(tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
    have "\<one>\<^sub>M inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
      using xxreal_1_th_1 sorry
    then have "(tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 \<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 \<one>\<^sub>M"
      using sin_cos_th_70 rfunct_1_def_1 sorry
    thus "(tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6 &  not (tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M"
      using A1 sin_cos_th_43 xreal_1_th_187 sorry
  qed
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef sin_cos_def_28 ("PISIN-COSK29" 164 ) where
"func PISIN-COSK29 \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. (tanSIN-COSK27).FUNCT-1K1 (it /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & it inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
proof-
  (*existence*)
    show " ex it be RealXREAL-0M1 st (tanSIN-COSK27).FUNCT-1K1 (it /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & it inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
    proof-
      have " ex th1 be setHIDDENM2 st (tanSIN-COSK27).FUNCT-1K1 (th1 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
      proof-
        have A1: "[.RCOMP-1K1 (tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6),(tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M .] =XBOOLE-0R4 {r where r be RealXREAL-0M1 : (tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) <=XXREAL-0R1 r & r <=XXREAL-0R1 (tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M }"
          using rcomp_1_def_1 sorry
        have "[.RCOMP-1K1 (tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M,(tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) .] =XBOOLE-0R4 {}XBOOLE-0K1"
          using sin_cos_lm_16 xxreal_1_th_29 sorry
        then have "\<one>\<^sub>M inTARSKIR2 [.RCOMP-1K1 (tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6),(tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 (tanSIN-COSK27).FUNCT-1K1 \<one>\<^sub>M,(tanSIN-COSK27).FUNCT-1K1 (0NUMBERSK6) .]"
          using A1 sin_cos_lm_16 sorry
        then obtain th where
          [ty]:"th be RealXREAL-0M1" and 
          A2: "th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"and A3: "(tanSIN-COSK27).FUNCT-1K1 th =COMPLEX1R1 \<one>\<^sub>M"
          using sin_cos_th_70 sin_cos_th_71 fcont_2_th_15 sorry
        have A4: "0NUMBERSK6 <=XXREAL-0R1 th"
          using A2 xxreal_1_th_1 sorry
        have A5: "th <=XXREAL-0R1 \<one>\<^sub>M"
          using A2 xxreal_1_th_1 sorry
        have A6: "0NUMBERSK6 <XXREAL-0R3 th"
          using A3 A4 sin_cos_lm_16 sorry
        have A7: "th <XXREAL-0R3 \<one>\<^sub>M"
          using A3 A5 sin_cos_lm_16 xxreal_0_th_1 sorry
        obtain th1 where 
          [ty]:"th1 be setHIDDENM2" and th1Def:"th1 = th *XCMPLX-0K3 \<four>\<^sub>M"
           sorry
        show " ex th1 be setHIDDENM2 st (tanSIN-COSK27).FUNCT-1K1 (th1 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
        proof(rule bexI[of _ "th1"],rule conjMI)
          show "(tanSIN-COSK27).FUNCT-1K1 (th1 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M"
            using A3 sorry
          have "th *XCMPLX-0K3 \<four>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M *NAT-1K2 \<four>\<^sub>M"
            using A7 xreal_1_th_68 sorry
          thus "th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
            using A6 xxreal_1_th_4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ((tanSIN-COSK27).FUNCT-1K1 (it1 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & it1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .[) & ((tanSIN-COSK27).FUNCT-1K1 (it2 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & it2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .[) implies it1 =HIDDENR1 it2"
    proof-
      have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (tanSIN-COSK27).FUNCT-1K1 (th1 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & (th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .[ & ((tanSIN-COSK27).FUNCT-1K1 (th2 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M & th2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .[)) implies th1 =HIDDENR1 th2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix th1 assume [ty]: "th1 be RealXREAL-0M1"
        fix th2 assume [ty]: "th2 be RealXREAL-0M1"
        assume A8: "(tanSIN-COSK27).FUNCT-1K1 (th1 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M"
          and A9: "th1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
          and A10: "(tanSIN-COSK27).FUNCT-1K1 (th2 /XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M"
          and A11: "th2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
        have A12: "0NUMBERSK6 <XXREAL-0R3 th1"
          using A9 xxreal_1_th_4 sorry
        have "th1 <XXREAL-0R3 \<four>\<^sub>M"
          using A9 xxreal_1_th_4 sorry
        then have "th1 /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 \<four>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
          using xreal_1_th_74 sorry
        then have A13: "th1 /XCMPLX-0K7 \<four>\<^sub>M inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
          using A12 xxreal_1_th_4 sorry
        have A14: "0NUMBERSK6 <XXREAL-0R3 th2"
          using A11 xxreal_1_th_4 sorry
        have "th2 <XXREAL-0R3 \<four>\<^sub>M"
          using A11 xxreal_1_th_4 sorry
        then have "th2 /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 \<four>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
          using xreal_1_th_74 sorry
        then have "th2 /XCMPLX-0K7 \<four>\<^sub>M inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
          using A14 xxreal_1_th_4 sorry
        then have "th1 /XCMPLX-0K7 \<four>\<^sub>M =COMPLEX1R1 th2 /XCMPLX-0K7 \<four>\<^sub>M"
          using A8 A10 A13 sin_cos_th_72 sorry
        thus "th1 =HIDDENR1 th2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem sin_cos_th_73:
"(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M)"
proof-
  have A1: "PISIN-COSK29 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
    using sin_cos_def_28 sorry
  then have A2: "0NUMBERSK6 <XXREAL-0R3 PISIN-COSK29"
    using xxreal_1_th_4 sorry
  have "PISIN-COSK29 <XXREAL-0R3 \<four>\<^sub>M"
    using A1 xxreal_1_th_4 sorry
  then have "(PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 \<four>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
    using xreal_1_th_74 sorry
  then have A3: "(PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
    using A2 xxreal_1_th_4 sorry
  have "(tanSIN-COSK27).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M"
    using sin_cos_def_28 sorry
  then have "(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M))\<inverse>XCMPLX-0K5 =COMPLEX1R1 \<one>\<^sub>M"
    using A3 sin_cos_th_70 rfunct_1_def_1 sorry
  thus "(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M)"
    using xcmplx_1_th_209 sorry
qed

(*begin*)
mtheorem sin_cos_th_74:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2 & (cosSIN-COSK19).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2 & (cosSIN-COSK19).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have 
      [ty]:"th1 be RealXREAL-0M1" and
      [ty]:"th2 be RealXREAL-0M1"
       sorry
    have A1: "(th1 +XCMPLX-0K2 th2)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 (0NUMBERSK6 +NAT-1K1 0NUMBERSK6)+XCMPLX-0K2 (th1 +XCMPLX-0K2 th2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    have A2: "SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((th2 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =HIDDENR1 SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8) +XCMPLX-0K2 th2 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_lm_3 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 sin_cos_lm_4 sorry
    finally have "SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((th2 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) *XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    have "SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((th2 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 th1 +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 SumCOMSEQ-3K11 ((th2 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4)"
      using sin_cos_lm_4 sorry
    also have "... = ((cosSIN-COSK19).FUNCT-1K1 th1 +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th2 *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using sin_cos_lm_4 sorry
    also have "... = ((cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2)+XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "SumCOMSEQ-3K11 ((th1 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) *XCMPLX-0K3 SumCOMSEQ-3K11 ((th2 *XCMPLX-0K3 (<i>COMPLEX1K8))ExpSeqSIN-COSK4) =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2)+XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "(sinSIN-COSK17).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2 & (cosSIN-COSK19).FUNCT-1K1 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
      using A2 complex1_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_75:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) & cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) =COMPLEX1R1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
  using sin_cos_th_74 sorry

mtheorem sin_cos_th_76:
"(((((((cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) =COMPLEX1R1 0NUMBERSK6) & (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6) & (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & (cosSIN-COSK19).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 \<one>\<^sub>M) & (sinSIN-COSK17).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 0NUMBERSK6"
proof-
  have "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 0NUMBERSK6 & ((sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M & ((cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & ((sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) =HIDDENR1 0NUMBERSK6 & ((cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 0NUMBERSK6 & ((sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & ((cosSIN-COSK19).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 \<one>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 0NUMBERSK6))))))"
  proof(rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    have A1: "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M)"
       sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M)"
      using sin_cos_th_73 sin_cos_th_74 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 0NUMBERSK6"
       sorry
    have A2: "(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M)"
       sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M)"
      using sin_cos_th_73 sin_cos_th_74 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_28 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have A3: "(cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    also have "... = (0NUMBERSK6)*NAT-1K2 (0NUMBERSK6) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 sin_cos_th_74 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
      using A2 sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
    have A4: "(sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_74 sorry
    also have "... = 0NUMBERSK6"
      using A1 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) =HIDDENR1 0NUMBERSK6"
       sorry
    have "(cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_74 sorry
    also have "... = 0NUMBERSK6"
      using A1 A4 sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 0NUMBERSK6"
       sorry
    have "(sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_74 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
      using A1 A2 A3 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
    have "(cosSIN-COSK19).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 PISIN-COSK29)"
       sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29)"
      using A3 sin_cos_th_74 sorry
    also have "... = \<one>\<^sub>M"
      using A4 sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have "(sinSIN-COSK17).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 PISIN-COSK29)"
       sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29)"
      using sin_cos_th_74 sorry
    also have "... = 0NUMBERSK6"
      using A4 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 0NUMBERSK6"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_77:
"((((((cosSIN-COSK20 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6 & sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M) & cosSIN-COSK20 (PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & sinSIN-COSK18 (PISIN-COSK29) =COMPLEX1R1 0NUMBERSK6) & cosSIN-COSK20 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6) & sinSIN-COSK18 (PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 \<one>\<^sub>M) & sinSIN-COSK18 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 0NUMBERSK6"
  using sin_cos_th_76 sorry

mtheorem sin_cos_th_78:
" for th be RealXREAL-0M1 holds (((((((sinSIN-COSK17).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th & (cosSIN-COSK19).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th) & (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th) & (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 th) & (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 th) & (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th) & (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th) & (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 th"
proof-
  have " for th be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 th & ((cosSIN-COSK19).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th & ((sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th & ((cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 th & ((sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th & ((cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th & ((sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th & (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 th))))))"
  proof(rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "(sinSIN-COSK17).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (0NUMBERSK6)"
      using sin_cos_th_74 sin_cos_th_76 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 th"
       sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 th"
       sorry
    have "(cosSIN-COSK19).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (0NUMBERSK6)"
      using sin_cos_th_74 sin_cos_th_76 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
    have "(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th)"
      using sin_cos_th_74 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th"
      using sin_cos_th_30 sin_cos_th_76 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
    have "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th)"
      using sin_cos_th_74 sorry
    also have "... = 0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th)"
      using sin_cos_th_30 sin_cos_th_76 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 th"
       sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 th"
       sorry
    have "(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th"
      using sin_cos_th_74 sin_cos_th_76 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
    have "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th"
      using sin_cos_th_74 sorry
    also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
      using sin_cos_th_76 sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
       sorry
    have "(sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th"
      using sin_cos_th_74 sorry
    also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
      using sin_cos_th_76 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
       sorry
    have "(cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th"
      using sin_cos_th_74 sin_cos_th_76 sorry
    also have "... = -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 th) =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_79:
" for th be RealXREAL-0M1 holds ((((((sinSIN-COSK18 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 sinSIN-COSK18 th & cosSIN-COSK20 (th +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 cosSIN-COSK20 th) & sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =COMPLEX1R1 cosSIN-COSK20 th) & cosSIN-COSK20 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) =COMPLEX1R1 sinSIN-COSK18 th) & sinSIN-COSK18 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =COMPLEX1R1 cosSIN-COSK20 th) & cosSIN-COSK20 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 th) & sinSIN-COSK18 (PISIN-COSK29 +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 th) & cosSIN-COSK20 (PISIN-COSK29 +XCMPLX-0K2 th) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 th"
  using sin_cos_th_78 sorry

mlemma sin_cos_lm_17:
" for th be RealXREAL-0M1 holds th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] implies (sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] implies (sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume A1: "th inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
    then have A2: "th <=XXREAL-0R1 \<one>\<^sub>M"
      using xxreal_1_th_1 sorry
    have "(sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6)"
    proof-
      have "(sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6)"
      proof-
        show "(sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6)"
        proof-
          have cases: "th =COMPLEX1R1 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 th"
            using A1 xxreal_1_th_1 sorry
          have case1: "th =COMPLEX1R1 0NUMBERSK6 implies (sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6)"
          proof(rule impI)
            assume "th =COMPLEX1R1 0NUMBERSK6"
            thus "(sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6)"
               sorry
          qed
          have case2: "0NUMBERSK6 <XXREAL-0R3 th implies (sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6)"
          proof(rule impI)
            assume A3: "0NUMBERSK6 <XXREAL-0R3 th"
            have "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
              using sin_cos_th_68 fdiff_1_th_25 sorry
            then have "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,th .]) be continuousFCONT-1V1"
              using fcont_1_th_16 sorry
            then obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A4: "r inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,th .["and A5: "diffFDIFF-1K1(sinSIN-COSK17,r) =COMPLEX1R1 ((sinSIN-COSK17).FUNCT-1K1 th -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6))/XCMPLX-0K7 (th -XCMPLX-0K6 0NUMBERSK6)"
              using A3 sin_cos_th_24 sin_cos_th_68 fdiff_1_th_26 rolle_th_3 sorry
            have A6: "r <XXREAL-0R3 th"
              using A4 xxreal_1_th_4 sorry
            have A7: "0NUMBERSK6 <XXREAL-0R3 r"
              using A4 xxreal_1_th_4 sorry
            have "r <XXREAL-0R3 \<one>\<^sub>M"
              using A2 A6 xxreal_0_th_2 sorry
            then have "r inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
              using A7 xxreal_1_th_1 sorry
            then have "(cosSIN-COSK19).FUNCT-1K1 r >XXREAL-0R4 0NUMBERSK6"
              using sin_cos_th_69 sorry
            then have "(sinSIN-COSK17).FUNCT-1K1 th -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) >XXREAL-0R4 0NUMBERSK6"
              using A3 A5 sin_cos_th_68 sorry
            thus "(sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6)"
              using xreal_1_th_47 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6)"
         sorry
    qed
    thus "(sinSIN-COSK17).FUNCT-1K1 th >=XXREAL-0R2 0NUMBERSK6"
      using sin_cos_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_80:
" for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies (cosSIN-COSK19).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ & (cosSIN-COSK19).FUNCT-1K1 th <=XXREAL-0R1 0NUMBERSK6 implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume A1: "th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      and A2: "(cosSIN-COSK19).FUNCT-1K1 th <=XXREAL-0R1 0NUMBERSK6"
    have "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
      using sin_cos_th_67 fdiff_1_th_25 sorry
    then have A3: "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,th .]) be continuousFCONT-1V1"
      using fcont_1_th_16 sorry
    have A4: "0NUMBERSK6 <XXREAL-0R3 th"
      using A1 xxreal_1_th_4 sorry
    have "[.RCOMP-1K1 (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6),(cosSIN-COSK19).FUNCT-1K1 th .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 (cosSIN-COSK19).FUNCT-1K1 th,(cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) .] =XBOOLE-0R4 [.RCOMP-1K1 (cosSIN-COSK19).FUNCT-1K1 th,(cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) .] & 0NUMBERSK6 inTARSKIR2 [.RCOMP-1K1 (cosSIN-COSK19).FUNCT-1K1 th,(cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) .]"
      using A2 sin_cos_th_30 xxreal_1_th_1 xxreal_1_th_222 sorry
    then have " ex th2 be RealXREAL-0M1 st th2 inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,th .] & (cosSIN-COSK19).FUNCT-1K1 th2 =COMPLEX1R1 0NUMBERSK6"
      using A3 A4 sin_cos_th_24 fcont_2_th_15 sorry
    then obtain th2 where
      [ty]:"th2 be RealXREAL-0M1" and 
      A5: "th2 inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,th .]"and "0NUMBERSK6 <XXREAL-0R3 th"and A6: "(cosSIN-COSK19).FUNCT-1K1 th2 =COMPLEX1R1 0NUMBERSK6"
      using A4 sorry
    have A7: "0NUMBERSK6 <=XXREAL-0R1 th2"
      using A5 xxreal_1_th_1 sorry
    have A8: "th2 <=XXREAL-0R1 th"
      using A5 xxreal_1_th_1 sorry
    have A9: "th <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 xxreal_1_th_4 sorry
    have A10: "0NUMBERSK6 <XXREAL-0R3 th2"
      using A6 A7 sin_cos_th_30 sorry
    have "th2 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A8 A9 xxreal_0_th_2 sorry
    then have A11: "th2 /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_74 sorry
    have "PISIN-COSK29 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
      using sin_cos_def_28 sorry
    then have "PISIN-COSK29 <XXREAL-0R3 \<four>\<^sub>M"
      using xxreal_1_th_4 sorry
    then have "(PISIN-COSK29)/XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 \<four>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
      using xreal_1_th_74 sorry
    then have A12: "th2 /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M"
      using A11 xxreal_0_th_2 sorry
    have "0NUMBERSK6 =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
      using A6 sorry
    also have "... = ((cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_74 sorry
    also have "... = ((cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    finally have "0NUMBERSK6 =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    then have A13: "(cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6 or (cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
       sorry
    have A14: "th2 /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["
      using A10 A12 xxreal_1_th_4 sorry
    have "].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ c=TARSKIR1 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
      using xxreal_1_th_25 sorry
    then have A15: "(cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) >=XXREAL-0R2 -XCMPLX-0K4 0NUMBERSK6"
      using A14 sin_cos_lm_17 sin_cos_th_69 sorry
    have "\<four>\<^sub>M *XCMPLX-0K3 (th2 /XCMPLX-0K7 \<two>\<^sub>M) <XXREAL-0R3 \<four>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using A12 xreal_1_th_68 sorry
    then have A16: "\<two>\<^sub>M *XCMPLX-0K3 th2 inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
      using A10 xxreal_1_th_4 sorry
    have "(sinSIN-COSK17).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (th2 /XCMPLX-0K7 \<two>\<^sub>M))\<inverse>XCMPLX-0K5 =COMPLEX1R1 \<one>\<^sub>M"
      using A13 A15 xcmplx_0_def_7 sorry
    then have "(tanSIN-COSK27).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 th2)/XCMPLX-0K7 \<four>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M"
      using A14 sin_cos_th_70 rfunct_1_def_1 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 th2 =COMPLEX1R1 PISIN-COSK29"
      using A16 sin_cos_def_28 sorry
    thus " False "
      using A1 A8 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_81:
" for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies cosSIN-COSK20 th >XXREAL-0R4 0NUMBERSK6"
  using sin_cos_th_80 sorry

(*begin*)
mtheorem sin_cos_th_82:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds sinSIN-COSK18 (a -XCMPLX-0K6 b) =COMPLEX1R1 (sinSIN-COSK18 a)*XCMPLX-0K3 (cosSIN-COSK20 b) -XCMPLX-0K6 (cosSIN-COSK20 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds sinSIN-COSK18 (a -XCMPLX-0K6 b) =HIDDENR1 (sinSIN-COSK18 a)*XCMPLX-0K3 (cosSIN-COSK20 b) -XCMPLX-0K6 (cosSIN-COSK20 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "sinSIN-COSK18 (a -XCMPLX-0K6 b) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 b) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 b)"
      using sin_cos_th_74 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 b +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 b)"
      using sin_cos_th_30 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 b +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 a *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 b)"
      using sin_cos_th_30 sorry
    also have "... = (sinSIN-COSK18 a)*XCMPLX-0K3 (cosSIN-COSK20 b) -XCMPLX-0K6 (cosSIN-COSK20 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
       sorry
    finally show "sinSIN-COSK18 (a -XCMPLX-0K6 b) =HIDDENR1 (sinSIN-COSK18 a)*XCMPLX-0K3 (cosSIN-COSK20 b) -XCMPLX-0K6 (cosSIN-COSK20 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_th_83:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds cosSIN-COSK20 (a -XCMPLX-0K6 b) =COMPLEX1R1 (cosSIN-COSK20 a)*XCMPLX-0K3 (cosSIN-COSK20 b) +XCMPLX-0K2 (sinSIN-COSK18 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds cosSIN-COSK20 (a -XCMPLX-0K6 b) =HIDDENR1 (cosSIN-COSK20 a)*XCMPLX-0K3 (cosSIN-COSK20 b) +XCMPLX-0K2 (sinSIN-COSK18 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "cosSIN-COSK20 (a -XCMPLX-0K6 b) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 b) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 b)"
      using sin_cos_th_74 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 b -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 b)"
      using sin_cos_th_30 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 b -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 a *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 b)"
      using sin_cos_th_30 sorry
    also have "... = (cosSIN-COSK20 a)*XCMPLX-0K3 (cosSIN-COSK20 b) +XCMPLX-0K2 (sinSIN-COSK18 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
       sorry
    finally show "cosSIN-COSK20 (a -XCMPLX-0K6 b) =HIDDENR1 (cosSIN-COSK20 a)*XCMPLX-0K3 (cosSIN-COSK20 b) +XCMPLX-0K2 (sinSIN-COSK18 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos_cl_6:
"cluster sinSIN-COSK17 as-term-is continuousFCONT-1V1"
proof
(*coherence*)
  show "sinSIN-COSK17 be continuousFCONT-1V1"
  proof-
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) =XBOOLE-0R4 REALNUMBERSK2 & (sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
      using sin_cos_th_68 fdiff_1_th_25 funct_2_def_1 sorry
    thus "sinSIN-COSK17 be continuousFCONT-1V1"
      using relat_1_th_69 sorry
  qed
qed "sorry"

mtheorem sin_cos_cl_7:
"cluster cosSIN-COSK19 as-term-is continuousFCONT-1V1"
proof
(*coherence*)
  show "cosSIN-COSK19 be continuousFCONT-1V1"
  proof-
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) =XBOOLE-0R4 REALNUMBERSK2 & (cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
      using sin_cos_th_67 fdiff_1_th_25 funct_2_def_1 sorry
    thus "cosSIN-COSK19 be continuousFCONT-1V1"
      using relat_1_th_69 sorry
  qed
qed "sorry"

mtheorem sin_cos_cl_8:
"cluster exp-RSIN-COSK23 as-term-is continuousFCONT-1V1"
proof
(*coherence*)
  show "exp-RSIN-COSK23 be continuousFCONT-1V1"
  proof-
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 REALNUMBERSK2 & (exp-RSIN-COSK23) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
      using sin_cos_th_66 fdiff_1_th_25 funct_2_def_1 sorry
    thus "exp-RSIN-COSK23 be continuousFCONT-1V1"
      using relat_1_th_69 sorry
  qed
qed "sorry"

end
