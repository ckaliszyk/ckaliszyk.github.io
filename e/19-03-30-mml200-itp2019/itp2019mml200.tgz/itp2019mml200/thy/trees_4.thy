theory trees_4
  imports trees_3
   "../mizar_extension/E_number"
begin
(*begin*)
abbreviation(input) TREES_4M1("NodeTREES-4M1-of  _ " [70]70) where
  "NodeTREES-4M1-of T \<equiv> ElementTREES-1M2-of domRELAT-1K1 T"

reserve x, y, z for "objectHIDDENM1"
reserve i, j, n for "NatNAT-1M1"
reserve p, q, r for "FinSequenceFINSEQ-1M1"
reserve v for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mlemma trees_4_lm_1:
" for x be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M3-of x holds y inHIDDENR3 domFINSEQ-1K5 p or y inHIDDENR3 domFINSEQ-1K5 p implies p .FUNCT-1K1 y inTARSKIR2 x"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be setHIDDENM2"
  fix y assume [ty]: "y be objectHIDDENM1"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of x"
  assume "y inHIDDENR3 domFINSEQ-1K5 p or y inHIDDENR3 domFINSEQ-1K5 p"
  then have A1: "p .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 p"
    using funct_1_def_3 sorry
  have "rngFUNCT-1K2 p c=TARSKIR1 x"
    using finseq_1_def_4 sorry
  thus "p .FUNCT-1K1 y inTARSKIR2 x"
    using A1 sorry
qed "sorry"

abbreviation(input) TREES_4R1(" _ =TREES-4R1  _ " [50,50]50) where
  "T1 =TREES-4R1 T2 \<equiv> T1 =HIDDENR1 T2"

mtheorem trees_4_def_1:
  mlet "T1 be DecoratedTreeTREES-2M4", "T2 be DecoratedTreeTREES-2M4"
"redefine pred T1 =TREES-4R1 T2 means
  domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p)"
proof
(*compatibility*)
  show "T1 =TREES-4R1 T2 iff domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p)"
  proof-
    have " not (T1 =HIDDENR1 T2 &  not (domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p))) &  not ((domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p)) &  not T1 =HIDDENR1 T2)"
    proof-
      have "( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p) & domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 T1 implies T1 .FUNCT-1K1 x =XBOOLE-0R4 T2 .FUNCT-1K1 x)"
         sorry
      thus " not (T1 =HIDDENR1 T2 &  not (domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p))) &  not ((domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be NodeTREES-4M1-of T1 holds T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p)) &  not T1 =HIDDENR1 T2)"
        using funct_1_th_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_4_th_1:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds elementary-treeTREES-1K2 i c=TARSKIR1 elementary-treeTREES-1K2 j implies i <=XXREAL-0R1 j"
proof-
  have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds elementary-treeTREES-1K2 i c=TARSKIR1 elementary-treeTREES-1K2 j & i >XXREAL-0R4 j implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    assume A1: "elementary-treeTREES-1K2 i c=TARSKIR1 elementary-treeTREES-1K2 j"
      and A2: "i >XXREAL-0R4 j"
    have 
      [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "<*TREES-3K14 j*> inTARSKIR2 elementary-treeTREES-1K2 i"
      using A2 trees_1_th_28 sorry
    then have A3: " ex n be NatNAT-1M1 st n <XXREAL-0R3 j & <*TREES-3K14 j*> =FINSEQ-1R1 <*TREES-3K14 n*>"
      using A1 trees_1_th_30 sorry
    have "(<*TREES-3K14 j*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 j"
      using finseq_1_th_40 sorry
    thus " not  True "
      using A3 finseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_2:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds elementary-treeTREES-1K2 i =TREES-2R1 elementary-treeTREES-1K2 j implies i =XBOOLE-0R4 j"
proof(rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  fix j assume [ty]: "j be NatNAT-1M1"
  assume "elementary-treeTREES-1K2 i =TREES-2R1 elementary-treeTREES-1K2 j"
  then have "i <=XXREAL-0R1 j & i >=XXREAL-0R2 j"
    using trees_4_th_1 sorry
  thus "i =XBOOLE-0R4 j"
    using xxreal_0_th_1 sorry
qed "sorry"

mlemma trees_4_lm_2:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
proof-
  have " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
    have "n >=XXREAL-0R2 0NUMBERSK6"
      using nat_1_th_2 sorry
    then have A2: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_7 sorry
    have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A1 nat_1_th_13 sorry
    then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
      using A2 finseq_3_th_25 sorry
    thus "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
      using funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma trees_4_lm_3:
" for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of x holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 x"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix x assume [ty]: "x be setHIDDENM2"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of x"
  assume "n <XXREAL-0R3 lenFINSEQ-1K4 p"
  then have A1: "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
    using trees_4_lm_2 sorry
  have "rngFUNCT-1K2 p c=TARSKIR1 x"
    using finseq_1_def_4 sorry
  thus "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 x"
    using A1 sorry
qed "sorry"

mdef trees_4_def_2 ("root-treeTREES-4K1  _ " [164]164 ) where
  mlet "x be objectHIDDENM1"
"func root-treeTREES-4K1 x \<rightarrow> DecoratedTreeTREES-2M4 equals
  elementary-treeTREES-1K2 (0NUMBERSK6) -->FUNCOP-1K7 x"
proof-
  (*coherence*)
    show "elementary-treeTREES-1K2 (0NUMBERSK6) -->FUNCOP-1K7 x be DecoratedTreeTREES-2M4"
       sorry
qed "sorry"

syntax TREES_4K2 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("root-treeTREES-4K2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "root-treeTREES-4K2\<^bsub>(D)\<^esub> d" \<rightharpoonup> "root-treeTREES-4K1 d"

mtheorem trees_4_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D"
"cluster root-treeTREES-4K1 d as-term-is ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
proof
(*coherence*)
  show "root-treeTREES-4K1 d be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
  proof-
    have "domRELAT-1K1 (elementary-treeTREES-1K2 (0NUMBERSK6) -->FUNCOP-1K8\<^bsub>(D)\<^esub> d) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
      using funcop_1_th_13 sorry
    thus "root-treeTREES-4K1 d be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
      using trees_3_def_8 sorry
  qed
qed "sorry"

mtheorem trees_4_th_3:
" for x be objectHIDDENM1 holds domRELAT-1K1 (root-treeTREES-4K1 x) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6) & (root-treeTREES-4K1 x).FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
proof-
  have " for x be objectHIDDENM1 holds domRELAT-1K1 (root-treeTREES-4K1 x) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6) & (root-treeTREES-4K1 x).FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have "{}XBOOLE-0K1 inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6)"
      using tarski_def_1 trees_1_th_29 sorry
    thus "domRELAT-1K1 (root-treeTREES-4K1 x) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6) & (root-treeTREES-4K1 x).FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
      using funcop_1_th_7 funcop_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_4:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds root-treeTREES-4K1 x =TREES-4R1 root-treeTREES-4K1 y implies x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (root-treeTREES-4K1 x =TREES-4R1 root-treeTREES-4K1 y &  not x =HIDDENR1 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "(root-treeTREES-4K1 x).FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
      using trees_4_th_3 sorry
    thus " not (root-treeTREES-4K1 x =TREES-4R1 root-treeTREES-4K1 y &  not x =HIDDENR1 y)"
      using trees_4_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_5:
" for T be DecoratedTreeTREES-2M4 holds domRELAT-1K1 T =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6) implies T =TREES-4R1 root-treeTREES-4K1 T .FUNCT-1K1 {}XBOOLE-0K1"
proof(rule ballI,rule impI)
  fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
  assume A1: "domRELAT-1K1 T =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
  then have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 T implies T .FUNCT-1K1 x =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1"
    using tarski_def_1 trees_1_th_29 sorry
  thus "T =TREES-4R1 root-treeTREES-4K1 T .FUNCT-1K1 {}XBOOLE-0K1"
    using A1 funcop_1_th_11 sorry
qed "sorry"

mtheorem trees_4_th_6:
" for x be objectHIDDENM1 holds root-treeTREES-4K1 x =FUNCT-1R1 {TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,x ] }"
proof-
  have " for x be objectHIDDENM1 holds root-treeTREES-4K1 x =HIDDENR1 {TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,x ] }"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have "root-treeTREES-4K1 x =HIDDENR1 [:ZFMISC-1K2 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 x} :]"
      using funcop_1_def_2 trees_1_th_29 sorry
    also have "... = {TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,x ] }"
      using zfmisc_1_th_29 sorry
    finally show "root-treeTREES-4K1 x =HIDDENR1 {TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,x ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_4_def_3 (" _ -flat-treeTREES-4K3  _ " [164,164]164 ) where
  mlet "x be objectHIDDENM1", "p be FinSequenceFINSEQ-1M1"
"func x -flat-treeTREES-4K3 p \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. (domRELAT-1K1 it =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be DecoratedTreeTREES-2M4 st (domRELAT-1K1 it =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have " ex tVar3 be DecoratedTreeTREES-2M4 st domRELAT-1K1 tVar3 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & (tVar3 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies tVar3 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
      proof-
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 =HIDDENR1 {}XBOOLE-0K1 & Lamb2 =HIDDENR1 x or ( ex n be NatNAT-1M1 st Lamb1 =HIDDENR1 <*TREES-3K14 n*> & Lamb2 =HIDDENR1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        have A1: " for z be objectHIDDENM1 holds z inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) implies ( ex y be objectHIDDENM1 st ?X(z,y))"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) implies  not ( for y be objectHIDDENM1 holds  not (z =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 x or ( ex n be NatNAT-1M1 st z =HIDDENR1 <*TREES-3K14 n*> & y =HIDDENR1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
            then have 
              [ty]:"z be ElementTREES-1M2-of elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
               sorry
            have 
              [ty]:"z be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
               sorry
            have A2: "z =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st n <XXREAL-0R3 lenFINSEQ-1K4 p & z =FINSEQ-1R1 <*TREES-3K14 n*>)"
              using trees_1_th_30 sorry
            have "( ex n be NatNAT-1M1 st z =FINSEQ-1R1 <*TREES-3K14 n*> & n <XXREAL-0R3 lenFINSEQ-1K4 p) implies ( ex y be setHIDDENM2 st  ex n be NatNAT-1M1 st z =FINSEQ-1R1 <*TREES-3K14 n*> & y =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
            proof(rule impI)
              assume Given: " ex n be NatNAT-1M1 st z =FINSEQ-1R1 <*TREES-3K14 n*> & n <XXREAL-0R3 lenFINSEQ-1K4 p"
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A3: "z =FINSEQ-1R1 <*TREES-3K14 n*>"and "n <XXREAL-0R3 lenFINSEQ-1K4 p"
                 sorry
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              show " ex y be setHIDDENM2 st  ex n be NatNAT-1M1 st z =FINSEQ-1R1 <*TREES-3K14 n*> & y =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              proof(rule bexI[of _ "y"])
                show " ex n be NatNAT-1M1 st z =FINSEQ-1R1 <*TREES-3K14 n*> & y =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                proof(rule bexI[of _ "n"])
                  show "z =FINSEQ-1R1 <*TREES-3K14 n*> & y =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                    using A3 sorry
                qed "sorry"
              qed "sorry"
            qed
            thus " not ( for y be objectHIDDENM1 holds  not (z =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 x or ( ex n be NatNAT-1M1 st z =HIDDENR1 <*TREES-3K14 n*> & y =HIDDENR1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
              using A2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A4: "domRELAT-1K1 f =XBOOLE-0R4 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & ( for y be objectHIDDENM1 holds y inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) implies ?X(y,f .FUNCT-1K1 y))"
          using classes1_sch_1 A1 sorry
        have 
          [ty]:"f be DecoratedTreeTREES-2M4"
          using A4 trees_2_def_8 sorry
        show " ex tVar3 be DecoratedTreeTREES-2M4 st domRELAT-1K1 tVar3 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & (tVar3 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies tVar3 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
        proof(rule bexI[of _ "f"],rule conjMI,rule conjMI,rule ballI,rule impI)
          show "domRELAT-1K1 f =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
            using A4 sorry
          have "{}XBOOLE-0K1 inTARSKIR2 domRELAT-1K1 f & ( for n be NatNAT-1M1 holds {}XBOOLE-0K1 =FINSEQ-1R1 <*TREES-3K14 n*> implies f .FUNCT-1K1 {}XBOOLE-0K1 <>HIDDENR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
            using trees_1_th_22 sorry
          thus "f .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
            using A4 sorry
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n <XXREAL-0R3 lenFINSEQ-1K4 p"
          then have "<*TREES-3K14 n*> inTARSKIR2 domRELAT-1K1 f"
            using A4 trees_1_th_28 sorry
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A5: "<*TREES-3K14 n*> =FINSEQ-1R1 <*TREES-3K14 k*>"and A6: "f .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
            using A4 sorry
          have "k =HIDDENR1 (<*TREES-3K14 n*>).FUNCT-1K1 \<one>\<^sub>M"
            using A5 finseq_1_th_40 sorry
          also have "... = n"
            using finseq_1_th_40 sorry
          finally have "k =HIDDENR1 n"
             sorry
          thus "f .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds ((domRELAT-1K1 it1 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & it1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it1 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) & ((domRELAT-1K1 it2 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & it2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it2 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
    proof-
      have " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 T1 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & (T1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x & (( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies T1 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & (domRELAT-1K1 T2 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & (T2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies T2 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))))) implies T1 =HIDDENR1 T2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
        fix T2 assume [ty]: "T2 be DecoratedTreeTREES-2M4"
        assume A7: "domRELAT-1K1 T1 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
          and A8: "T1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
          and A9: " for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies T1 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
          and A10: "domRELAT-1K1 T2 =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
          and A11: "T2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
          and A12: " for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies T2 .FUNCT-1K1 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) implies T1 .FUNCT-1K1 x =XBOOLE-0R4 T2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
          then obtain x9 where 
            [ty]:"x9 be ElementTREES-1M2-of elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)" and x9Def:"x9 = x"
             sorry
          have A13: "x9 =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st n <XXREAL-0R3 lenFINSEQ-1K4 p & x9 =FINSEQ-1R1 <*TREES-3K14 n*>)"
            using trees_1_th_30 sorry
          have "( ex n be NatNAT-1M1 st n <XXREAL-0R3 lenFINSEQ-1K4 p & x =HIDDENR1 <*TREES-3K14 n*>) implies T1 .FUNCT-1K1 x =HIDDENR1 T2 .FUNCT-1K1 x"
          proof(rule impI)
            assume Given: " ex n be NatNAT-1M1 st n <XXREAL-0R3 lenFINSEQ-1K4 p & x =HIDDENR1 <*TREES-3K14 n*>"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A14: "n <XXREAL-0R3 lenFINSEQ-1K4 p & x =HIDDENR1 <*TREES-3K14 n*>"
               sorry
            have "T1 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A9 A14 sorry
            also have "... = T2 .FUNCT-1K1 x"
              using A12 A14 sorry
            finally show "T1 .FUNCT-1K1 x =HIDDENR1 T2 .FUNCT-1K1 x"
               sorry
          qed
          thus "T1 .FUNCT-1K1 x =XBOOLE-0R4 T2 .FUNCT-1K1 x"
            using A8 A11 A13 sorry
        qed "sorry"
        thus "T1 =HIDDENR1 T2"
          using A7 A10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_4_th_7:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds x -flat-treeTREES-4K3 p =TREES-4R1 y -flat-treeTREES-4K3 q implies x =HIDDENR1 y & p =FINSEQ-1R1 q"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds x -flat-treeTREES-4K3 p =TREES-4R1 y -flat-treeTREES-4K3 q implies x =HIDDENR1 y & p =FINSEQ-1R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "x -flat-treeTREES-4K3 p =TREES-4R1 y -flat-treeTREES-4K3 q"
    have "(x -flat-treeTREES-4K3 p).FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
      using trees_4_def_3 sorry
    thus "x =HIDDENR1 y"
      using A1 trees_4_def_3 sorry
    have A2: "domRELAT-1K1 (x -flat-treeTREES-4K3 p) =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) & domRELAT-1K1 (y -flat-treeTREES-4K3 q) =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 q)"
      using trees_4_def_3 sorry
    then have A3: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
      using A1 trees_4_th_2 sorry
    have " for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
    proof(rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A4: "i >=XXREAL-0R2 \<one>\<^sub>M"
        and A5: "i <=XXREAL-0R1 lenFINSEQ-1K4 p"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A6: "i =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 n"
        using A4 nat_1_th_10 sorry
      have A7: "n inTARSKIR2 NATNUMBERSK1 & n <XXREAL-0R3 lenFINSEQ-1K4 p"
        using A5 A6 nat_1_th_13 ordinal1_def_12 sorry
      then have "p .FUNCT-1K1 i =XBOOLE-0R4 (x -flat-treeTREES-4K3 p).FUNCT-1K1 (<*TREES-3K14 n*>)"
        using A6 trees_4_def_3 sorry
      thus "p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
        using A1 A3 A6 A7 trees_4_def_3 sorry
    qed "sorry"
    thus "p =FINSEQ-1R1 q"
      using A1 A2 trees_4_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_8:
" for i be NatNAT-1M1 holds  for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds j <XXREAL-0R3 i implies elementary-treeTREES-1K2 i  |TREES-1K4 (<*TREES-3K14 j*>) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
proof-
  have " for i be NatNAT-1M1 holds  for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds j <XXREAL-0R3 i implies elementary-treeTREES-1K2 i  |TREES-1K4 (<*TREES-3K14 j*>) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be ElementSUBSET-1M1-of NATNUMBERSK1"
    let ?p = "i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6)"
    let ?T = "treeTREES-3K11 ?p"
    assume A1: "j <XXREAL-0R3 i"
    then have A2: "\<one>\<^sub>M +NAT-1K1 j >=XXREAL-0R2 \<one>\<^sub>M & j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
      using nat_1_th_11 nat_1_th_13 sorry
    have "lenFINSEQ-1K4 ?p =XBOOLE-0R4 i"
      using card_1_def_7 sorry
    then have A3: "elementary-treeTREES-1K2 i =TREES-2R1 ?T & ?T  |TREES-1K4 (<*TREES-3K14 j*>) =XBOOLE-0R4 ?p .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)"
      using A1 trees_3_th_49 trees_3_th_54 sorry
    have "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 i"
      using A2 sorry
    thus "elementary-treeTREES-1K2 i  |TREES-1K4 (<*TREES-3K14 j*>) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
      using A3 funcop_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_9:
" for x be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 p implies (x -flat-treeTREES-4K3 p) |TREES-2K5 (<*TREES-3K14 i*>) =TREES-4R1 root-treeTREES-4K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for x be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i <XXREAL-0R3 lenFINSEQ-1K4 p implies (x -flat-treeTREES-4K3 p) |TREES-2K5 (<*TREES-3K14 i*>) =TREES-4R1 root-treeTREES-4K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
    obtain t where 
      [ty]:"t be ElementTREES-1M2-of domRELAT-1K1 (x -flat-treeTREES-4K3 p)  |TREES-1K4 (<*TREES-3K14 i*>)" and tDef:"t = {}XBOOLE-0K1"
      using trees_1_th_22 sorry
    assume A1: "i <XXREAL-0R3 lenFINSEQ-1K4 p"
    then have A2: "(x -flat-treeTREES-4K3 p).FUNCT-1K1 (<*TREES-3K14 i*>) =XBOOLE-0R4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
      using trees_4_def_3 sorry
    have A3: "domRELAT-1K1 (x -flat-treeTREES-4K3 p) =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
      using trees_4_def_3 sorry
    have "elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)  |TREES-1K4 (<*TREES-3K14 i*>) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
      using A1 trees_4_th_8 sorry
    then have A4: "domRELAT-1K1 ((x -flat-treeTREES-4K3 p) |TREES-2K5 (<*TREES-3K14 i*>)) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
      using A3 trees_2_def_10 sorry
    have "(<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t =FINSEQ-1R1 <*TREES-3K14 i*> & ((x -flat-treeTREES-4K3 p) |TREES-2K5 (<*TREES-3K14 i*>)).FUNCT-1K1 t =XBOOLE-0R4 (x -flat-treeTREES-4K3 p).FUNCT-1K1 ((<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t)"
      using finseq_1_th_34 trees_2_def_10 sorry
    thus "(x -flat-treeTREES-4K3 p) |TREES-2K5 (<*TREES-3K14 i*>) =TREES-4R1 root-treeTREES-4K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
      using A2 A4 trees_4_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_4_def_4 (" _ -treeTREES-4K4  _ " [164,164]164 ) where
  mlet "x be objectHIDDENM1", "p be FinSequenceFINSEQ-1M1"
"assume p be DTree-yieldingTREES-3V6 func x -treeTREES-4K4 p \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. (( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show "p be DTree-yieldingTREES-3V6 implies ( ex it be DecoratedTreeTREES-2M4 st (( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
    proof(rule impI)
      assume Assume: "p be DTree-yieldingTREES-3V6"
      have A1: "p be DTree-yieldingTREES-3V6"
        using Assume sorry
      show " ex it be DecoratedTreeTREES-2M4 st (( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
      proof-
        have " ex tVar5 be DecoratedTreeTREES-2M4 st ( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 tVar5 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & (tVar5 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies tVar5  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
        proof-
          obtain pp where 
            [ty]:"pp be Function-yieldingFUNCOP-1V1\<bar>FinSequenceFINSEQ-1M1" and ppDef:"pp = p"
            using A1 sorry
          have A2: "domRELAT-1K1 (domsFUNCT-6K1 pp) =XBOOLE-0R4 domFINSEQ-1K5 p"
            using A1 trees_3_th_37 sorry
          obtain q where 
            [ty]:"q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1" and qDef:"q = domsFUNCT-6K1 pp"
            using A1 sorry
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 =HIDDENR1 {}XBOOLE-0K1 & Lamb2 =HIDDENR1 x or Lamb1 <>HIDDENR2 {}XBOOLE-0K1 & ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st Lamb1 =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 r & Lamb2 =HIDDENR1 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,r))"
          have A3: " for y be objectHIDDENM1 holds y inHIDDENR3 treeTREES-3K11 q implies ( ex z be objectHIDDENM1 st ?X(y,z))"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 treeTREES-3K11 q implies  not ( for z be objectHIDDENM1 holds  not (y =HIDDENR1 {}XBOOLE-0K1 & z =HIDDENR1 x or y <>HIDDENR2 {}XBOOLE-0K1 & ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st y =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 r & z =HIDDENR1 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,r))))"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 treeTREES-3K11 q"
              then obtain s where 
                [ty]:"s be ElementTREES-1M2-of treeTREES-3K11 q" and sDef:"s = y"
                 sorry
              have "y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex z be setHIDDENM2 st y =HIDDENR1 {}XBOOLE-0K1 & z =HIDDENR1 x or y <>HIDDENR2 {}XBOOLE-0K1 & ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st y =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 r & z =XBOOLE-0R4 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,r)))"
              proof(rule impI)
                assume "y <>HIDDENR2 {}XBOOLE-0K1"
                then obtain w n where
                  [ty]:"w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A4: "s =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> w"
                  using finseq_2_th_130 sorry
                have 
                  [ty]:"w be FinSequenceFINSEQ-1M1"
                   sorry
                obtain z where 
                  [ty]:"z be setHIDDENM2" and zDef:"z = p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,w)"
                   sorry
                show " ex z be setHIDDENM2 st y =HIDDENR1 {}XBOOLE-0K1 & z =HIDDENR1 x or y <>HIDDENR2 {}XBOOLE-0K1 & ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st y =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 r & z =XBOOLE-0R4 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,r))"
                proof(rule bexI[of _ "z"])
                  show "y =HIDDENR1 {}XBOOLE-0K1 & z =HIDDENR1 x or y <>HIDDENR2 {}XBOOLE-0K1 & ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st y =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 r & z =XBOOLE-0R4 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,r))"
                    using A4 sorry
                qed "sorry"
              qed
              thus " not ( for z be objectHIDDENM1 holds  not (y =HIDDENR1 {}XBOOLE-0K1 & z =HIDDENR1 x or y <>HIDDENR2 {}XBOOLE-0K1 & ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st y =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 r & z =HIDDENR1 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,r))))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain T where
            [ty]:"T be FunctionFUNCT-1M1" and 
            A5: "domRELAT-1K1 T =XBOOLE-0R4 treeTREES-3K11 q & ( for y be objectHIDDENM1 holds y inHIDDENR3 treeTREES-3K11 q implies ?X(y,T .FUNCT-1K1 y))"
            using classes1_sch_1 A3 sorry
          have 
            [ty]:"T be DecoratedTreeTREES-2M4"
            using A5 trees_2_def_8 sorry
          show " ex tVar5 be DecoratedTreeTREES-2M4 st ( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 tVar5 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & (tVar5 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies tVar5  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
          proof(rule bexI[of _ "T"],rule conjMI,rule conjMI,rule ballI,rule impI)
            show " ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 T =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q"
              using A1 A5 sorry
            have "{}XBOOLE-0K1 inTARSKIR2 treeTREES-3K11 q"
              using trees_1_th_22 sorry
            thus "T .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
              using A5 sorry
            have A6: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
              using A2 finseq_3_th_29 sorry
            fix n assume [ty]: "n be NatNAT-1M1"
            assume A7: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
            then have A8: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
              using trees_4_lm_2 sorry
            then obtain t where 
              [ty]:"t be DecoratedTreeTREES-2M4" and tDef:"t = p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A1 trees_3_th_24 sorry
            obtain nn where 
              [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
              using ordinal1_def_12 sorry
            have A9: "domRELAT-1K1 t =XBOOLE-0R4 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A8 funct_6_th_22 sorry
            have A10: "domRELAT-1K1 t =HIDDENR1 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A8 funct_6_th_22 sorry
            also have "... = domRELAT-1K1 T  |TREES-1K4 (<*TREES-3K14 nn*>)"
              using A5 A6 A7 trees_3_th_49 sorry
            finally have "domRELAT-1K1 t =HIDDENR1 domRELAT-1K1 T  |TREES-1K4 (<*TREES-3K14 nn*>)"
               sorry
            have A11: "domRELAT-1K1 T  |TREES-1K4 (<*TREES-3K14 n*>) =TREES-2R1 domRELAT-1K1 (T  |TREES-2K5 (<*TREES-3K14 n*>))"
              using trees_2_def_10 sorry
            have " for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds r inTARSKIR2 domRELAT-1K1 t implies (T  |TREES-2K5 (<*TREES-3K14 n*>)).FUNCT-1K1 r =XBOOLE-0R4 t .FUNCT-1K1 r"
            proof(rule ballI,rule impI)
              fix r assume [ty]: "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              assume A12: "r inTARSKIR2 domRELAT-1K1 t"
              then have "(<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r inTARSKIR2 domRELAT-1K1 T"
                using A5 A6 A7 A9 trees_3_def_15 sorry
              then obtain m s where
                [ty]:"m be NatNAT-1M1" "s be FinSequenceFINSEQ-1M1" and 
                A13: "(<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r =FINSEQ-1R1 (<*TREES-3K14 m*>)^FINSEQ-1K8 s"and A14: "T .FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) =XBOOLE-0R4 p ..FUNCT-6K4(m +NAT-1K1 \<one>\<^sub>M,s)"
                using A5 sorry
              have A15: "((<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & ((<*TREES-3K14 m*>)^FINSEQ-1K8 s).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m"
                using finseq_1_th_41 sorry
              then have "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & r =FINSEQ-1R1 s"
                using A7 A13 trees_4_lm_2 finseq_1_th_33 sorry
              then have "p ..FUNCT-6K4(m +NAT-1K1 \<one>\<^sub>M,s) =XBOOLE-0R4 t .FUNCT-1K1 r"
                using A12 A13 A15 funct_5_th_38 sorry
              thus "(T  |TREES-2K5 (<*TREES-3K14 n*>)).FUNCT-1K1 r =XBOOLE-0R4 t .FUNCT-1K1 r"
                using A10 A12 A14 trees_2_def_10 sorry
            qed "sorry"
            thus "T  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A10 A11 trees_2_th_31 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p be DTree-yieldingTREES-3V6 implies ( for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds ((( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it1 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it1  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) & ((( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it2 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it2  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p be DTree-yieldingTREES-3V6"
      have A1: "p be DTree-yieldingTREES-3V6"
        using Assume sorry
      show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds ((( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it1 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it1  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) & ((( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 it2 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q) & it2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies it2  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
      proof-
        have " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds ( ex q1 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q1 & domRELAT-1K1 T1 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q1) implies (T1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies T1  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) implies (( ex q2 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q2 & domRELAT-1K1 T2 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q2) implies (T2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies T2  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) implies T1 =HIDDENR1 T2)))"
        proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule impI,rule impMI ,rule impI)
          fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
          fix T2 assume [ty]: "T2 be DecoratedTreeTREES-2M4"
          assume Given: " ex q1 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q1 & domRELAT-1K1 T1 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q1"
          then obtain q1 where
            [ty]:"q1 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1" and 
            A16: "p =FINSEQ-1R1 q1"and A17: "domRELAT-1K1 T1 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q1"
             sorry
          assume A18: "T1 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
            and A19: " for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies T1  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
          assume Given: " ex q2 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q2 & domRELAT-1K1 T2 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q2"
          then obtain q2 where
            [ty]:"q2 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1" and 
            A20: "p =FINSEQ-1R1 q2 & domRELAT-1K1 T2 =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q2"
             sorry
          assume A21: "T2 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
            and A22: " for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies T2  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
          have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T1 implies T1 .FUNCT-1K1 q =XBOOLE-0R4 T2 .FUNCT-1K1 q"
          proof(rule ballI,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume A23: "q inTARSKIR2 domRELAT-1K1 T1"
            have "q <>HIDDENR2 {}XBOOLE-0K1 implies T1 .FUNCT-1K1 q =XBOOLE-0R4 T2 .FUNCT-1K1 q"
            proof(rule impI)
              assume "q <>HIDDENR2 {}XBOOLE-0K1"
              then obtain s n where
                [ty]:"s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A24: "q =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                using finseq_2_th_130 sorry
              have A25: "<*TREES-3K14 n*> inTARSKIR2 domRELAT-1K1 T1"
                using A23 A24 trees_1_th_21 sorry
              have A26: "n <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 q1)"
                using A17 A23 A24 trees_3_th_48 sorry
              have "lenFINSEQ-1K4 (domsFUNCT-6K1 q1) =XBOOLE-0R4 lenFINSEQ-1K4 p"
                using A16 trees_3_th_38 sorry
              then have A27: "T1  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & T2  |TREES-2K5 (<*TREES-3K14 n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                using A19 A22 A26 sorry
              have A28: "s inTARSKIR2 domRELAT-1K1 T1  |TREES-1K4 (<*TREES-3K14 n*>)"
                using A23 A24 A25 trees_1_def_6 sorry
              then have "T1 .FUNCT-1K1 q =XBOOLE-0R4 (T1  |TREES-2K5 (<*TREES-3K14 n*>)).FUNCT-1K1 s"
                using A24 trees_2_def_10 sorry
              thus "T1 .FUNCT-1K1 q =XBOOLE-0R4 T2 .FUNCT-1K1 q"
                using A16 A17 A20 A24 A27 A28 trees_2_def_10 sorry
            qed
            thus "T1 .FUNCT-1K1 q =XBOOLE-0R4 T2 .FUNCT-1K1 q"
              using A18 A21 sorry
          qed "sorry"
          thus "T1 =HIDDENR1 T2"
            using A16 A17 A20 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef trees_4_def_5 (" _ -treeTREES-4K5  _ " [164,164]164 ) where
  mlet "x be objectHIDDENM1", "T be DecoratedTreeTREES-2M4"
"func x -treeTREES-4K5 T \<rightarrow> DecoratedTreeTREES-2M4 equals
  x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)"
proof-
  (*coherence*)
    show "x -treeTREES-4K4 (<*FINSEQ-1K10 T*>) be DecoratedTreeTREES-2M4"
       sorry
qed "sorry"

mdef trees_4_def_6 (" _ -treeTREES-4K6'( _ , _ ')" [164,0,0]164 ) where
  mlet "x be objectHIDDENM1", "T1 be DecoratedTreeTREES-2M4", "T2 be DecoratedTreeTREES-2M4"
"func x -treeTREES-4K6(T1,T2) \<rightarrow> DecoratedTreeTREES-2M4 equals
  x -treeTREES-4K4 (<*FINSEQ-1K11 T1,T2 *>)"
proof-
  (*coherence*)
    show "x -treeTREES-4K4 (<*FINSEQ-1K11 T1,T2 *>) be DecoratedTreeTREES-2M4"
       sorry
qed "sorry"

mtheorem trees_4_th_10:
" for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 p"
proof-
  have " for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 p"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
    have " ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 q & domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q"
      using trees_4_def_4 sorry
    thus "domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_11:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds y inHIDDENR3 domRELAT-1K1 (x -treeTREES-4K4 p) iff y =HIDDENR1 {}XBOOLE-0K1 or ( ex i be NatNAT-1M1 st  ex T be DecoratedTreeTREES-2M4 st  ex q be NodeTREES-4M1-of T st (i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  not ((y inHIDDENR3 domRELAT-1K1 (x -treeTREES-4K4 p) &  not y =HIDDENR1 {}XBOOLE-0K1) & ( for i be NatNAT-1M1 holds  for T be DecoratedTreeTREES-2M4 holds  for q be NodeTREES-4M1-of T holds  not (( not i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))) &  not ( not ( not y =HIDDENR1 {}XBOOLE-0K1 & ( for i be NatNAT-1M1 holds  for T be DecoratedTreeTREES-2M4 holds  for q be NodeTREES-4M1-of T holds  not (( not i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))) &  not y inHIDDENR3 domRELAT-1K1 (x -treeTREES-4K4 p))"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix p assume [ty]: "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
    have A1: "domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 p"
      using trees_4_th_10 sorry
    have A2: "( ex i be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (i <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 p) & q inTARSKIR2 domsFUNCT-6K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K8 q) implies ( ex i be NatNAT-1M1 st  ex T be DecoratedTreeTREES-2M4 st  ex q be NodeTREES-4M1-of T st (i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)"
    proof(rule impI)
      assume Given: " ex i be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (i <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 p) & q inTARSKIR2 domsFUNCT-6K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K8 q"
      then obtain i q where
        [ty]:"i be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
        A3: "i <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 p)"and A4: "q inTARSKIR2 domsFUNCT-6K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"and A5: "y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K8 q"
         sorry
      have "lenFINSEQ-1K4 (domsFUNCT-6K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
        using trees_3_th_38 sorry
      then have A6: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        using A3 trees_4_lm_2 sorry
      then obtain T where 
        [ty]:"T be DecoratedTreeTREES-2M4" and TDef:"T = p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
        using trees_3_th_24 sorry
      show " ex i be NatNAT-1M1 st  ex T be DecoratedTreeTREES-2M4 st  ex q be NodeTREES-4M1-of T st (i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
      proof(rule bexI[of _ "i"])
        show " ex T be DecoratedTreeTREES-2M4 st  ex q be NodeTREES-4M1-of T st (i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
        proof(rule bexI[of _ "T"])
          have 
            [ty]:"q be NodeTREES-4M1-of T"
            using A4 A6 funct_6_th_22 sorry
          show " ex q be NodeTREES-4M1-of T st (i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
          proof(rule bexI[of _ "q"])
            show "(i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
              using A3 A5 trees_3_th_38 sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
    qed
    have "( ex i be NatNAT-1M1 st  ex T be DecoratedTreeTREES-2M4 st  ex q be NodeTREES-4M1-of T st (i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) implies ( ex i be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (i <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 p) & q inTARSKIR2 domsFUNCT-6K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K8 q)"
    proof(rule impI)
      assume Given: " ex i be NatNAT-1M1 st  ex T be DecoratedTreeTREES-2M4 st  ex q be NodeTREES-4M1-of T st (i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
      then obtain i T q where
        [ty]:"i be NatNAT-1M1" "T be DecoratedTreeTREES-2M4" "q be NodeTREES-4M1-of T" and 
        A7: "i <XXREAL-0R3 lenFINSEQ-1K4 p"and A8: "T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"and A9: "y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
         sorry
      have 
        [ty]:"q be FinSequenceFINSEQ-1M1"
         sorry
      show " ex i be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (i <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 p) & q inTARSKIR2 domsFUNCT-6K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K8 q"
      proof(rule bexI[of _ "i"])
        show " ex q be FinSequenceFINSEQ-1M1 st (i <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 p) & q inTARSKIR2 domsFUNCT-6K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K8 q"
        proof(rule bexI[of _ "q"])
          have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
            using A7 trees_4_lm_2 sorry
          then have "domsFUNCT-6K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 domRELAT-1K1 T"
            using A8 funct_6_th_22 sorry
          thus "(i <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 p) & q inTARSKIR2 domsFUNCT-6K1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K8 q"
            using A7 A9 trees_3_th_38 sorry
        qed "sorry"
      qed "sorry"
    qed
    thus " not ((y inHIDDENR3 domRELAT-1K1 (x -treeTREES-4K4 p) &  not y =HIDDENR1 {}XBOOLE-0K1) & ( for i be NatNAT-1M1 holds  for T be DecoratedTreeTREES-2M4 holds  for q be NodeTREES-4M1-of T holds  not (( not i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))) &  not ( not ( not y =HIDDENR1 {}XBOOLE-0K1 & ( for i be NatNAT-1M1 holds  for T be DecoratedTreeTREES-2M4 holds  for q be NodeTREES-4M1-of T holds  not (( not i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) & y =HIDDENR1 (<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))) &  not y inHIDDENR3 domRELAT-1K1 (x -treeTREES-4K4 p))"
      using A1 A2 trees_3_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_12:
" for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds  for T be DecoratedTreeTREES-2M4 holds  for q be NodeTREES-4M1-of T holds i <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies (x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T .FUNCT-1K1 q"
proof-
  have " for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds  for T be DecoratedTreeTREES-2M4 holds  for q be NodeTREES-4M1-of T holds n <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies (x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T .FUNCT-1K1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix q assume [ty]: "q be NodeTREES-4M1-of T"
    assume A1: "n <XXREAL-0R3 lenFINSEQ-1K4 p & T =FUNCT-1R1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A2: "(<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p)"
      using trees_4_th_11 A1 sorry
    then have "<*TREES-3K14 n*> inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p)"
      using trees_1_th_21 sorry
    then have "q inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p)  |TREES-1K4 (<*TREES-3K14 n*>)"
      using A2 trees_1_def_6 sorry
    then have "((x -treeTREES-4K4 p) |TREES-2K5 (<*TREES-3K14 n*>)).FUNCT-1K1 q =XBOOLE-0R4 (x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)"
      using trees_2_def_10 sorry
    thus "(x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T .FUNCT-1K1 q"
      using A1 trees_4_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_13:
" for x be objectHIDDENM1 holds  for T be DecoratedTreeTREES-2M4 holds domRELAT-1K1 (x -treeTREES-4K5 T) =TREES-2R1 ^TREES-3K12 domRELAT-1K1 T"
proof-
  have " for x be objectHIDDENM1 holds  for T be DecoratedTreeTREES-2M4 holds domRELAT-1K1 (x -treeTREES-4K5 T) =TREES-2R1 ^TREES-3K12 domRELAT-1K1 T"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    have "domRELAT-1K1 (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 (<*FINSEQ-1K10 T*>) & domsFUNCT-6K1 (<*FINSEQ-1K10 T*>) =FINSEQ-1R1 <*FINSEQ-1K10 domRELAT-1K1 T*>"
      using trees_4_th_10 finseq_3_th_132 sorry
    thus "domRELAT-1K1 (x -treeTREES-4K5 T) =TREES-2R1 ^TREES-3K12 domRELAT-1K1 T"
      using trees_3_def_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_14:
" for x be objectHIDDENM1 holds  for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 (x -treeTREES-4K6(T1,T2)) =TREES-2R1 treeTREES-3K13(domRELAT-1K1 T1,domRELAT-1K1 T2)"
proof-
  have " for x be objectHIDDENM1 holds  for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 (x -treeTREES-4K6(T1,T2)) =TREES-2R1 treeTREES-3K13(domRELAT-1K1 T1,domRELAT-1K1 T2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    fix T2 assume [ty]: "T2 be DecoratedTreeTREES-2M4"
    have "domRELAT-1K1 (x -treeTREES-4K4 (<*FINSEQ-1K11 T1,T2 *>)) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 (<*FINSEQ-1K11 T1,T2 *>) & domsFUNCT-6K1 (<*FINSEQ-1K11 T1,T2 *>) =FINSEQ-1R1 <*FINSEQ-1K11 domRELAT-1K1 T1,domRELAT-1K1 T2 *>"
      using trees_4_th_10 finseq_3_th_133 sorry
    thus "domRELAT-1K1 (x -treeTREES-4K6(T1,T2)) =TREES-2R1 treeTREES-3K13(domRELAT-1K1 T1,domRELAT-1K1 T2)"
      using trees_3_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_15:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds x -treeTREES-4K4 p =TREES-4R1 y -treeTREES-4K4 q implies x =HIDDENR1 y & p =FINSEQ-1R1 q"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds x -treeTREES-4K4 p =TREES-4R1 y -treeTREES-4K4 q implies x =HIDDENR1 y & p =FINSEQ-1R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix p assume [ty]: "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
    assume A1: "x -treeTREES-4K4 p =TREES-4R1 y -treeTREES-4K4 q"
    have "(x -treeTREES-4K4 p).FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
      using trees_4_def_4 sorry
    thus "x =HIDDENR1 y"
      using A1 trees_4_def_4 sorry
    have "domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 p & domRELAT-1K1 (y -treeTREES-4K4 q) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 q"
      using trees_4_th_10 sorry
    then have A2: "domsFUNCT-6K1 p =FINSEQ-1R1 domsFUNCT-6K1 q"
      using A1 trees_3_th_50 sorry
    have "domFINSEQ-1K5 p =XBOOLE-0R4 domFINSEQ-1K5 (domsFUNCT-6K1 p) & domFINSEQ-1K5 (domsFUNCT-6K1 q) =XBOOLE-0R4 domFINSEQ-1K5 q"
      using trees_3_th_37 sorry
    then have A3: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
      using A2 finseq_3_th_29 sorry
    have " for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 i =FUNCT-1R1 q .FUNCT-1K1 i"
    proof(rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A4: "i >=XXREAL-0R2 \<one>\<^sub>M"
        and A5: "i <=XXREAL-0R1 lenFINSEQ-1K4 p"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A6: "i =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 n"
        using A4 nat_1_th_10 sorry
      have 
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have A7: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
        using A5 A6 nat_1_th_13 sorry
      then have "p .FUNCT-1K1 i =FUNCT-1R1 (x -treeTREES-4K4 p) |TREES-2K5 (<*TREES-3K14 n*>)"
        using A6 trees_4_def_4 sorry
      thus "p .FUNCT-1K1 i =FUNCT-1R1 q .FUNCT-1K1 i"
        using A1 A3 A6 A7 trees_4_def_4 sorry
    qed "sorry"
    thus "p =FINSEQ-1R1 q"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_16:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds root-treeTREES-4K1 x =TREES-4R1 y -flat-treeTREES-4K3 p implies x =HIDDENR1 y & p =FINSEQ-1R1 {}XBOOLE-0K1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds root-treeTREES-4K1 x =TREES-4R1 y -flat-treeTREES-4K3 p implies x =HIDDENR1 y & p =FINSEQ-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "root-treeTREES-4K1 x =TREES-4R1 y -flat-treeTREES-4K3 p"
    have "x =HIDDENR1 (root-treeTREES-4K1 x).FUNCT-1K1 {}XBOOLE-0K1"
      using trees_4_th_3 sorry
    also have "... = y"
      using A1 trees_4_def_3 sorry
    finally show "x =HIDDENR1 y"
       sorry
    have "domRELAT-1K1 (y -flat-treeTREES-4K3 p) =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
      using trees_4_def_3 sorry
    thus "p =FINSEQ-1R1 {}XBOOLE-0K1"
      using A1 trees_4_th_2 trees_4_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_17:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds root-treeTREES-4K1 x =TREES-4R1 y -treeTREES-4K4 p & p be DTree-yieldingTREES-3V6 implies x =HIDDENR1 y & p =FINSEQ-1R1 {}XBOOLE-0K1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds root-treeTREES-4K1 x =TREES-4R1 y -treeTREES-4K4 p & p be DTree-yieldingTREES-3V6 implies x =HIDDENR1 y & p =FINSEQ-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "root-treeTREES-4K1 x =TREES-4R1 y -treeTREES-4K4 p"
      and A2: "p be DTree-yieldingTREES-3V6"
    obtain p9 where 
      [ty]:"p9 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1" and p9Def:"p9 = p"
      using A2 sorry
    have "x =HIDDENR1 (root-treeTREES-4K1 x).FUNCT-1K1 {}XBOOLE-0K1"
      using trees_4_th_3 sorry
    also have "... = y"
      using A1 A2 trees_4_def_4 sorry
    finally show "x =HIDDENR1 y"
       sorry
    have "domRELAT-1K1 (y -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 p9"
      using trees_4_th_10 sorry
    then have A3: "domsFUNCT-6K1 p9 =FINSEQ-1R1 {}XBOOLE-0K1"
      using A1 trees_4_th_3 trees_3_th_50 trees_3_th_52 sorry
    have "domFINSEQ-1K5 (domsFUNCT-6K1 p9) =XBOOLE-0R4 domFINSEQ-1K5 p"
      using trees_3_th_37 sorry
    thus "p =FINSEQ-1R1 {}XBOOLE-0K1"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_18:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds x -flat-treeTREES-4K3 p =TREES-4R1 y -treeTREES-4K4 q & q be DTree-yieldingTREES-3V6 implies (x =HIDDENR1 y & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies q .FUNCT-1K1 i =XBOOLE-0R4 root-treeTREES-4K1 p .FUNCT-1K1 i)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds x -flat-treeTREES-4K3 p =TREES-4R1 y -treeTREES-4K4 q & q be DTree-yieldingTREES-3V6 implies x =HIDDENR1 y & (lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies q .FUNCT-1K1 i =XBOOLE-0R4 root-treeTREES-4K1 p .FUNCT-1K1 i))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "x -flat-treeTREES-4K3 p =TREES-4R1 y -treeTREES-4K4 q"
      and A2: "q be DTree-yieldingTREES-3V6"
    obtain q9 where 
      [ty]:"q9 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1" and q9Def:"q9 = q"
      using A2 sorry
    have "x =HIDDENR1 (x -flat-treeTREES-4K3 p).FUNCT-1K1 {}XBOOLE-0K1"
      using trees_4_def_3 sorry
    also have "... = y"
      using A1 A2 trees_4_def_4 sorry
    finally show "x =HIDDENR1 y"
       sorry
    have "treeTREES-3K11 (lenFINSEQ-1K4 p  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6)) =HIDDENR1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
      using trees_3_th_54 sorry
    also have "... = domRELAT-1K1 (x -flat-treeTREES-4K3 p)"
      using trees_4_def_3 sorry
    also have "... = treeTREES-3K11 domsFUNCT-6K1 q9"
      using A1 trees_4_th_10 sorry
    finally have "treeTREES-3K11 (lenFINSEQ-1K4 p  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6)) =HIDDENR1 treeTREES-3K11 domsFUNCT-6K1 q9"
       sorry
    then have A3: "lenFINSEQ-1K4 p  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6) =FINSEQ-1R1 domsFUNCT-6K1 q9"
      using trees_3_th_50 sorry
    have "lenFINSEQ-1K4 (domsFUNCT-6K1 q9) =XBOOLE-0R4 lenFINSEQ-1K4 q"
      using trees_3_th_38 sorry
    thus A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
      using A3 card_1_def_7 sorry
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A5: "i inTARSKIR2 domFINSEQ-1K5 p"
    then have A6: "i >=XXREAL-0R2 \<one>\<^sub>M"
      using finseq_3_th_25 sorry
    have A7: "i <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A5 finseq_3_th_25 sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A8: "i =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 n"
      using A6 nat_1_th_10 sorry
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A9: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
      using A7 A8 nat_1_th_13 sorry
    then have "(x -flat-treeTREES-4K3 p) |TREES-2K5 (<*TREES-3K14 n*>) =TREES-4R1 root-treeTREES-4K1 p .FUNCT-1K1 i"
      using A8 trees_4_th_9 sorry
    thus "q .FUNCT-1K1 i =XBOOLE-0R4 root-treeTREES-4K1 p .FUNCT-1K1 i"
      using A1 A2 A4 A8 A9 trees_4_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_19:
" for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (<*TREES-3K14 n*>)^FINSEQ-1K8 q inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p) implies (x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K8 q) =XBOOLE-0R4 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,q)"
proof-
  have " for x be objectHIDDENM1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (<*TREES-3K14 n*>)^FINSEQ-1K8 q inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p) implies (x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K8 q) =XBOOLE-0R4 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,q)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "(<*TREES-3K14 n*>)^FINSEQ-1K8 q inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p)"
    then have "(<*TREES-3K14 n*>)^FINSEQ-1K8 q be NodeTREES-4M1-of x -treeTREES-4K4 p"
       sorry
    then obtain q9 where 
      [ty]:"q9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and q9Def:"q9 = q"
      using finseq_1_th_36 sorry
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A2: "<*TREES-3K14 n*> inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p)"
      using A1 trees_1_th_21 sorry
    have A3: "(<*TREES-3K14 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 domsFUNCT-6K1 p"
      using A1 trees_4_th_10 sorry
    have A4: "lenFINSEQ-1K4 (domsFUNCT-6K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
      using trees_3_th_38 sorry
    have A5: "q9 inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 p)  |TREES-1K4 (<*TREES-3K14 n*>)"
      using A1 A2 trees_1_def_6 sorry
    have A6: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
      using A3 A4 trees_3_th_48 sorry
    have A7: "domRELAT-1K1 ((x -treeTREES-4K4 p) |TREES-2K5 (<*TREES-3K14 n*>)) =TREES-2R1 domRELAT-1K1 (x -treeTREES-4K4 p)  |TREES-1K4 (<*TREES-3K14 n*>) & ((x -treeTREES-4K4 p) |TREES-2K5 (<*TREES-3K14 n*>)).FUNCT-1K1 q9 =XBOOLE-0R4 (x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K8 q)"
      using A5 trees_2_def_10 sorry
    have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 (x -treeTREES-4K4 p) |TREES-2K5 (<*TREES-3K14 n*>)"
      using A6 trees_4_def_4 trees_4_lm_2 sorry
    thus "(x -treeTREES-4K4 p).FUNCT-1K1 ((<*TREES-3K14 n*>)^FINSEQ-1K8 q) =XBOOLE-0R4 p ..FUNCT-6K4(n +NAT-1K1 \<one>\<^sub>M,q)"
      using A5 A7 funct_5_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_20:
" for x be objectHIDDENM1 holds x -flat-treeTREES-4K3 {}XBOOLE-0K1 =TREES-4R1 root-treeTREES-4K1 x & x -treeTREES-4K4 {}XBOOLE-0K1 =TREES-4R1 root-treeTREES-4K1 x"
proof-
  have " for x be objectHIDDENM1 holds x -flat-treeTREES-4K3 {}XBOOLE-0K1 =TREES-4R1 root-treeTREES-4K1 x & x -treeTREES-4K4 {}XBOOLE-0K1 =TREES-4R1 root-treeTREES-4K1 x"
  proof(rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have "lenFINSEQ-1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 0NUMBERSK6"
       sorry
    then have A1: "domRELAT-1K1 (x -flat-treeTREES-4K3 {}XBOOLE-0K1) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
      using trees_4_def_3 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6) implies (x -flat-treeTREES-4K3 {}XBOOLE-0K1).FUNCT-1K1 y =HIDDENR1 x"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6)"
      then have "y =HIDDENR1 {}XBOOLE-0K1"
        using tarski_def_1 trees_1_th_29 sorry
      thus "(x -flat-treeTREES-4K3 {}XBOOLE-0K1).FUNCT-1K1 y =HIDDENR1 x"
        using trees_4_def_3 sorry
    qed "sorry"
    thus "x -flat-treeTREES-4K3 {}XBOOLE-0K1 =TREES-4R1 root-treeTREES-4K1 x"
      using A1 funcop_1_th_11 sorry
    obtain e where 
      [ty]:"e be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1" and eDef:"e = {}XBOOLE-0K1"
       sorry
    have A2: "domRELAT-1K1 (x -treeTREES-4K4 {}XBOOLE-0K1) =HIDDENR1 treeTREES-3K11 domsFUNCT-6K1 e"
      using trees_4_th_10 sorry
    also have "... = elementary-treeTREES-1K2 (0NUMBERSK6)"
      using funct_6_th_23 trees_3_th_52 sorry
    finally have "domRELAT-1K1 (x -treeTREES-4K4 {}XBOOLE-0K1) =HIDDENR1 elementary-treeTREES-1K2 (0NUMBERSK6)"
       sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6) implies (x -treeTREES-4K4 e).FUNCT-1K1 y =HIDDENR1 x"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6)"
      then have "y =HIDDENR1 {}XBOOLE-0K1"
        using tarski_def_1 trees_1_th_29 sorry
      thus "(x -treeTREES-4K4 e).FUNCT-1K1 y =HIDDENR1 x"
        using trees_4_def_4 sorry
    qed "sorry"
    thus "x -treeTREES-4K4 {}XBOOLE-0K1 =TREES-4R1 root-treeTREES-4K1 x"
      using A2 funcop_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_21:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>) =TREES-4R1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,root-treeTREES-4K1 y)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>) =TREES-4R1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,root-treeTREES-4K1 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    let ?T = "(elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,root-treeTREES-4K1 y)"
    have A1: "domRELAT-1K1 (x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>)) =HIDDENR1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>))"
      using trees_4_def_3 sorry
    also have "... = elementary-treeTREES-1K2 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    finally have "domRELAT-1K1 (x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>)) =HIDDENR1 elementary-treeTREES-1K2 \<one>\<^sub>M"
       sorry
    have A2: "domRELAT-1K1 (root-treeTREES-4K1 y) =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
      using funcop_1_th_13 sorry
    have A3: "domRELAT-1K1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x) =TREES-2R1 elementary-treeTREES-1K2 \<one>\<^sub>M & <*TREES-3K14 0NUMBERSK6 *> inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M"
      using funcop_1_th_13 tarski_def_2 trees_1_th_51 sorry
    then have A4: "domRELAT-1K1 ?T =HIDDENR1 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,elementary-treeTREES-1K2 (0NUMBERSK6))"
      using A2 trees_2_def_11 sorry
    also have "... = elementary-treeTREES-1K2 \<one>\<^sub>M"
      using trees_3_th_58 trees_3_th_67 sorry
    finally have "domRELAT-1K1 ?T =HIDDENR1 elementary-treeTREES-1K2 \<one>\<^sub>M"
       sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 elementary-treeTREES-1K2 \<one>\<^sub>M implies ((elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,root-treeTREES-4K1 y)).FUNCT-1K1 z =XBOOLE-0R4 (x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>)).FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 elementary-treeTREES-1K2 \<one>\<^sub>M"
      then have A5: "z =HIDDENR1 {}XBOOLE-0K1 or z =HIDDENR1 <*TREES-3K14 0NUMBERSK6 *>"
        using tarski_def_2 trees_1_th_51 sorry
      have A6: "{}XBOOLE-0K1 inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M"
        using tarski_def_2 trees_1_th_51 sorry
      have A7: " not <*TREES-3K14 0NUMBERSK6 *> is-a-prefix-ofTREES-1R2 {}XBOOLE-0K1"
         sorry
      have A8: "lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>) =XBOOLE-0R4 \<one>\<^sub>M"
        using finseq_1_th_40 sorry
      have A9: "(<*FINSEQ-1K10 y*>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y & (x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>)).FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x"
        using trees_4_def_3 finseq_1_th_40 sorry
      have A10: "?T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x).FUNCT-1K1 {}XBOOLE-0K1"
        using A3 A6 A7 trees_3_th_45 sorry
      have A11: "(x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>)).FUNCT-1K1 (<*TREES-3K14 0NUMBERSK6 *>) =XBOOLE-0R4 (<*FINSEQ-1K10 y*>).FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
        using A8 trees_4_def_3 sorry
      have "?T .FUNCT-1K1 (<*TREES-3K14 0NUMBERSK6 *>) =XBOOLE-0R4 (root-treeTREES-4K1 y).FUNCT-1K1 {}XBOOLE-0K1"
        using A3 trees_3_th_44 sorry
      thus "((elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,root-treeTREES-4K1 y)).FUNCT-1K1 z =XBOOLE-0R4 (x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>)).FUNCT-1K1 z"
        using A5 A6 A9 A10 A11 trees_4_th_3 funcop_1_th_7 sorry
    qed "sorry"
    thus "x -flat-treeTREES-4K3 (<*FINSEQ-1K10 y*>) =TREES-4R1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,root-treeTREES-4K1 y)"
      using A1 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_22:
" for x be objectHIDDENM1 holds  for T be DecoratedTreeTREES-2M4 holds x -treeTREES-4K4 (<*FINSEQ-1K10 T*>) =TREES-4R1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)"
proof-
  have " for x be objectHIDDENM1 holds  for T be DecoratedTreeTREES-2M4 holds x -treeTREES-4K4 (<*FINSEQ-1K10 T*>) =TREES-4R1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    let ?D = "(elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)"
    let ?W = "elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,domRELAT-1K1 T)"
    have A1: "domRELAT-1K1 (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)) =HIDDENR1 treeTREES-3K11 domsFUNCT-6K1 (<*FINSEQ-1K10 T*>)"
      using trees_4_th_10 sorry
    also have "... = treeTREES-3K11 (<*FINSEQ-1K10 domRELAT-1K1 T*>)"
      using finseq_3_th_132 sorry
    also have "... = ^TREES-3K12 domRELAT-1K1 T"
      using trees_3_def_16 sorry
    also have "... = ?W"
      using trees_3_th_58 sorry
    finally have "domRELAT-1K1 (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)) =HIDDENR1 ?W"
       sorry
    have A2: "domRELAT-1K1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x) =TREES-2R1 elementary-treeTREES-1K2 \<one>\<^sub>M"
      using funcop_1_th_13 sorry
    obtain t1 t2 where 
      [ty]:"t1 be ElementTREES-1M2-of elementary-treeTREES-1K2 \<one>\<^sub>M" and t1Def:"t1 = {}XBOOLE-0K1" and
      [ty]:"t2 be ElementTREES-1M2-of elementary-treeTREES-1K2 \<one>\<^sub>M" and t2Def:"t2 = <*TREES-3K14 0NUMBERSK6 *>"
      using tarski_def_2 trees_1_th_51 sorry
    have "t2 =FINSEQ-1R1 t2"
       sorry
    then have A3: "domRELAT-1K1 ?D =TREES-2R1 ?W"
      using A2 trees_2_def_11 sorry
    have A4: "{}XBOOLE-0K1 inTARSKIR2 domRELAT-1K1 T"
      using trees_1_th_22 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,domRELAT-1K1 T) implies ((elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)).FUNCT-1K1 y =XBOOLE-0R4 (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 ?W"
      then obtain q where 
        [ty]:"q be ElementTREES-1M2-of ?W" and qDef:"q = y"
         sorry
      have "q inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M or ( ex v be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st v inTARSKIR2 domRELAT-1K1 T & q =FINSEQ-1R1 t2 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v)"
        using trees_1_def_9 sorry
      then have A5: "(q =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 t2 & t2 =FINSEQ-1R1 t2 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1) or ( ex v be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st v inTARSKIR2 domRELAT-1K1 T & q =FINSEQ-1R1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v)"
        using finseq_1_th_34 tarski_def_2 trees_1_th_51 sorry
      have " not t2 is-a-prefix-ofTREES-1R2 t1"
         sorry
      then have A6: "?D .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x).FUNCT-1K1 t1"
        using A2 trees_3_th_45 sorry
      also have "... = x"
        using funcop_1_th_7 sorry
      also have "... = (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 {}XBOOLE-0K1"
        using trees_4_def_4 sorry
      finally have "?D .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 {}XBOOLE-0K1"
         sorry
      have "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 domRELAT-1K1 T & q =FINSEQ-1R1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies ((elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)).FUNCT-1K1 q =XBOOLE-0R4 (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 q"
      proof(rule impI)
        assume Given: " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 domRELAT-1K1 T & q =FINSEQ-1R1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
        then obtain r where
          [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A7: "r inTARSKIR2 domRELAT-1K1 T"and A8: "q =FINSEQ-1R1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
           sorry
        have 
          [ty]:"r be NodeTREES-4M1-of T"
          using A7 sorry
        have "q =FINSEQ-1R1 t2 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
          using A8 sorry
        then have A9: "?D .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 r"
          using A2 trees_3_th_46 sorry
        have "lenFINSEQ-1K4 (<*FINSEQ-1K10 T*>) =XBOOLE-0R4 \<one>\<^sub>M & (<*FINSEQ-1K10 T*>).FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 T"
          using finseq_1_th_40 sorry
        then have A10: "(x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)) |TREES-2K5 t2 =TREES-4R1 T"
          using trees_4_def_4 sorry
        have "?W  |TREES-1K4 t2 =TREES-2R1 domRELAT-1K1 T"
          using trees_1_th_33 sorry
        thus "((elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)).FUNCT-1K1 q =XBOOLE-0R4 (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 q"
          using A1 A8 A9 A10 trees_2_def_10 sorry
      qed
      thus "((elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)).FUNCT-1K1 y =XBOOLE-0R4 (x -treeTREES-4K4 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 y"
        using A4 A5 A6 sorry
    qed "sorry"
    thus "x -treeTREES-4K4 (<*FINSEQ-1K10 T*>) =TREES-4R1 (elementary-treeTREES-1K2 \<one>\<^sub>M -->FUNCOP-1K7 x)with-replacementTREES-2K7(<*TREES-3K14 0NUMBERSK6 *>,T)"
      using A1 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_cl_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D", "p be FinSequenceFINSEQ-1M3-of D"
"cluster d -flat-treeTREES-4K3 p as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "d -flat-treeTREES-4K3 p be D -valuedRELAT-1V5"
  proof-
    let ?T = "d -flat-treeTREES-4K3 p"
    have "rngFUNCT-1K2 ?T c=TARSKIR1 D"
    proof-
      have "rngFUNCT-1K2 (d -flat-treeTREES-4K3 p) c=TARSKIR1 D"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (d -flat-treeTREES-4K3 p) implies x inHIDDENR3 D"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 ?T"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "y inHIDDENR3 domRELAT-1K1 ?T"and A2: "x =HIDDENR1 ?T .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have 
            [ty]:"y be NodeTREES-4M1-of ?T"
            using A1 sorry
          have A3: "domRELAT-1K1 ?T =TREES-2R1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
            using trees_4_def_3 sorry
          have A4: "?T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 d"
            using trees_4_def_3 sorry
          have "y <>HIDDENR2 {}XBOOLE-0K1 implies x inHIDDENR3 D"
          proof(rule impI)
            assume "y <>HIDDENR2 {}XBOOLE-0K1"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A5: "n <XXREAL-0R3 lenFINSEQ-1K4 p & y =FINSEQ-1R1 <*TREES-3K14 n*>"
              using A3 trees_1_th_30 sorry
            have A6: "?T .FUNCT-1K1 y =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
              using A5 trees_4_def_3 trees_4_lm_2 sorry
            have "rngFUNCT-1K2 p c=TARSKIR1 D"
              using finseq_1_def_4 sorry
            thus "x inHIDDENR3 D"
              using A2 A6 sorry
          qed
          thus "x inHIDDENR3 D"
            using A2 A4 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 (d -flat-treeTREES-4K3 p) c=TARSKIR1 D"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "d -flat-treeTREES-4K3 p be D -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem trees_4_cl_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D", "d be ElementSUBSET-1M1-of D", "p be FinSequenceFINSEQ-1M3-of F"
"cluster d -treeTREES-4K4 p as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "d -treeTREES-4K4 p be D -valuedRELAT-1V5"
  proof-
    let ?T = "d -treeTREES-4K4 p"
    have "rngFUNCT-1K2 ?T c=TARSKIR1 D"
    proof-
      have "rngFUNCT-1K2 (d -treeTREES-4K4 p) c=TARSKIR1 D"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (d -treeTREES-4K4 p) implies x inHIDDENR3 D"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 ?T"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "y inHIDDENR3 domRELAT-1K1 ?T"and A2: "x =HIDDENR1 ?T .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have 
            [ty]:"y be NodeTREES-4M1-of ?T"
            using A1 sorry
          have A3: "(treeTREES-3K11 domsFUNCT-6K1 p)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*TREES-3K14 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 p) }"
            using trees_3_th_49 sorry
          have A4: "?T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 d"
            using trees_4_def_4 sorry
          have A5: "treeTREES-3K11 domsFUNCT-6K1 p =TREES-2R1 domRELAT-1K1 ?T & lenFINSEQ-1K4 (domsFUNCT-6K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
            using trees_4_th_10 trees_3_th_38 sorry
          have "y <>HIDDENR2 {}XBOOLE-0K1 implies x inHIDDENR3 D"
          proof(rule impI)
            assume "y <>HIDDENR2 {}XBOOLE-0K1"
            then obtain q n where
              [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A6: "y =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
              using finseq_2_th_130 sorry
            have A7: "<*TREES-3K14 n*> inTARSKIR2 domRELAT-1K1 ?T"
              using A6 trees_1_th_21 sorry
            have A8: "lenFINSEQ-1K4 (<*TREES-3K14 n*>) =XBOOLE-0R4 \<one>\<^sub>M"
              using finseq_1_th_40 sorry
            have A9: "q inTARSKIR2 domRELAT-1K1 ?T  |TREES-1K4 (<*TREES-3K14 n*>)"
              using A6 A7 trees_1_def_6 sorry
            have A10: "<*TREES-3K14 n*> inTARSKIR2 domRELAT-1K1 ?T -levelTREES-2K2 \<one>\<^sub>M"
              using A7 A8 sorry
            have A11: "domRELAT-1K1 (?T  |TREES-2K5 (<*TREES-3K14 n*>)) =TREES-2R1 domRELAT-1K1 ?T  |TREES-1K4 (<*TREES-3K14 n*>)"
              using trees_2_def_10 sorry
            obtain i where
              [ty]:"i be NatNAT-1M1" and 
              A12: "<*TREES-3K14 n*> =FINSEQ-1R1 <*TREES-3K14 i*> & i <XXREAL-0R3 lenFINSEQ-1K4 p"
              using A3 A5 A10 sorry
            have A13: "(<*TREES-3K14 n*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & (<*TREES-3K14 i*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i"
              using finseq_1_th_40 sorry
            then have A14: "?T  |TREES-2K5 (<*TREES-3K14 n*>) =FUNCT-1R1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A12 trees_4_def_4 sorry
            have A15: "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
              using A12 A13 trees_4_lm_2 sorry
            have "rngFUNCT-1K2 p c=TARSKIR1 F"
              using finseq_1_def_4 sorry
            then obtain t where 
              [ty]:"t be ElementSUBSET-1M1-of F" and tDef:"t = p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A15 sorry
            have A16: "t .FUNCT-1K1 q =HIDDENR1 x"
              using A2 A6 A9 A14 trees_2_def_10 sorry
            have A17: "t .FUNCT-1K1 q inTARSKIR2 rngFUNCT-1K2 t"
              using A9 A11 A14 funct_1_def_3 sorry
            have "rngFUNCT-1K2 t c=TARSKIR1 D"
              using relat_1_def_19 sorry
            thus "x inHIDDENR3 D"
              using A16 A17 sorry
          qed
          thus "x inHIDDENR3 D"
            using A2 A4 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 (d -treeTREES-4K4 p) c=TARSKIR1 D"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "d -treeTREES-4K4 p be D -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem trees_4_cl_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D", "T be DecoratedTreeTREES-2M5-of D"
"cluster d -treeTREES-4K5 T as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "d -treeTREES-4K5 T be D -valuedRELAT-1V5"
  proof-
    have 
      [ty]:"T be ElementSUBSET-1M1-of TreesTREES-3K4 D"
      using trees_3_def_7 sorry
    obtain t where 
      [ty]:"t be ElementFINSEQ-2M2\<^bsub>(TreesTREES-3K4 D)\<^esub>-of (TreesTREES-3K4 D)* FINSEQ-2K3" and tDef:"t = <*FINSEQ-1K13\<^bsub>(TreesTREES-3K4 D)\<^esub> T*>"
      using finseq_1_def_11 sorry
    have "d -treeTREES-4K5 T =TREES-4R1 d -treeTREES-4K4 t"
       sorry
    thus "d -treeTREES-4K5 T be D -valuedRELAT-1V5"
       sorry
  qed
qed "sorry"

mtheorem trees_4_cl_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D", "T1 be DecoratedTreeTREES-2M5-of D", "T2 be DecoratedTreeTREES-2M5-of D"
"cluster d -treeTREES-4K6(T1,T2) as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "d -treeTREES-4K6(T1,T2) be D -valuedRELAT-1V5"
  proof-
    have 
      [ty]:"T1 be ElementSUBSET-1M1-of TreesTREES-3K4 D" and
      [ty]:"T2 be ElementSUBSET-1M1-of TreesTREES-3K4 D"
      using trees_3_def_7 sorry
    have "<*FINSEQ-1K11 T1,T2 *> =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(TreesTREES-3K4 D)\<^esub> T1*>)^FINSEQ-1K9\<^bsub>(TreesTREES-3K4 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(TreesTREES-3K4 D)\<^esub> T2*>)"
       sorry
    then obtain t where 
      [ty]:"t be ElementFINSEQ-2M2\<^bsub>(TreesTREES-3K4 D)\<^esub>-of (TreesTREES-3K4 D)* FINSEQ-2K3" and tDef:"t = <*FINSEQ-1K11 T1,T2 *>"
      using finseq_1_def_11 sorry
    have "d -treeTREES-4K6(T1,T2) =TREES-4R1 d -treeTREES-4K4 t"
       sorry
    thus "d -treeTREES-4K6(T1,T2) be D -valuedRELAT-1V5"
       sorry
  qed
qed "sorry"

syntax TREES_4K7 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("domsTREES-4K7\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "domsTREES-4K7\<^bsub>(D)\<^esub> p" \<rightharpoonup> "domsFUNCT-6K1 p"

mtheorem trees_4_add_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D"
"cluster domsFUNCT-6K1 p as-term-is FinSequenceFINSEQ-1M3-of FinTreesTREES-3K2"
proof
(*coherence*)
  show "domsFUNCT-6K1 p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K2"
  proof-
    have A1: "domFINSEQ-1K5 (domsFUNCT-6K1 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
      using trees_3_th_37 sorry
    have A2: "rngFUNCT-1K2 p c=TARSKIR1 FinTreesTREES-3K5 D"
      using finseq_1_def_4 sorry
    show "domsFUNCT-6K1 p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K2"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (domsFUNCT-6K1 p) implies x inHIDDENR3 FinTreesTREES-3K2"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (domsFUNCT-6K1 p)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "y inHIDDENR3 domFINSEQ-1K5 p"and A4: "x =HIDDENR1 domsFUNCT-6K1 p .FUNCT-1K1 y"
          using A1 funct_1_def_3 sorry
        obtain T where 
          [ty]:"T be DecoratedTreeTREES-2M4" and TDef:"T = p .FUNCT-1K1 y"
          using A3 trees_3_th_24 sorry
        have "T inTARSKIR2 rngFUNCT-1K2 p"
          using A3 funct_1_def_3 sorry
        then have "domRELAT-1K1 T inTARSKIR2 FinTreesTREES-3K2"
          using A2 trees_3_def_2 sorry
        thus "x inHIDDENR3 FinTreesTREES-3K2"
          using A3 A4 funct_6_th_22 sorry
      qed "sorry"
      thus "domsFUNCT-6K1 p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K2"
        using tarski_def_3 finseq_1_def_4 sorry
    qed
  qed
qed "sorry"

syntax TREES_4K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -treeTREES-4K8\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "d -treeTREES-4K8\<^bsub>(D)\<^esub> p" \<rightharpoonup> "d -treeTREES-4K4 p"

mtheorem trees_4_add_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D", "p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D"
"cluster d -treeTREES-4K4 p as-term-is ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
proof
(*coherence*)
  show "d -treeTREES-4K4 p be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
  proof-
    have "domRELAT-1K1 (d -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsTREES-4K7\<^bsub>(D)\<^esub> p"
      using trees_4_th_10 sorry
    thus "d -treeTREES-4K4 p be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
      using trees_3_def_8 sorry
  qed
qed "sorry"

syntax TREES_4M2 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("FinSequenceTREES-4M2\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70)
translations "FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of x" \<rightharpoonup> "FinSequenceFINSEQ-1M2-of x"

mtheorem trees_4_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be SubsetSUBSET-1M2-of D"
"cluster note-that FinSequenceFINSEQ-1M3-of D for FinSequenceFINSEQ-1M2-of x"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M2-of x holds it be FinSequenceFINSEQ-1M3-of D"
  proof-
    have " for p be FinSequenceFINSEQ-1M3-of x holds p be FinSequenceFINSEQ-1M3-of D"
    proof(rule ballI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of x"
      have Cut847: "rngFUNCT-1K2 p c=TARSKIR1 x"
        using finseq_1_def_4 sorry
      have "rngFUNCT-1K2 p c=TARSKIR1 D"
      proof-
        show "rngFUNCT-1K2 p c=TARSKIR1 D"
          using xboole_1_th_1 Cut847 sorry
      qed
      thus "p be FinSequenceFINSEQ-1M3-of D"
        using finseq_1_def_4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_4_cl_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>constituted-DTreesTREES-3V3\<bar>setHIDDENM2", "X be SubsetSUBSET-1M2-of D"
"cluster note-that DTree-yieldingTREES-3V6 for FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of X"
proof
(*coherence*)
  show " for it be FinSequenceTREES-4M2\<^bsub>(D)\<^esub>-of X holds it be DTree-yieldingTREES-3V6"
     sorry
qed "sorry"

(*begin*)
theorem trees_4_sch_1:
  fixes T1f0 T2f0 Pp1 
  assumes
[ty]: "T1f0 be TreeTREES-1M1" and
  [ty]: "T2f0 be TreeTREES-1M1"
  shows " ex T be TreeTREES-1M1 st  for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T iff p inTARSKIR2 T1f0 or ( ex q be ElementTREES-1M2-of T1f0 st  ex r be ElementTREES-1M2-of T2f0 st Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
  proof-
    have " ex tVar11 be TreeTREES-1M1 st  for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 tVar11 &  not p inTARSKIR2 T1f0) & ( for q be ElementTREES-1M2-of T1f0 holds  for r be ElementTREES-1M2-of T2f0 holds  not (Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))) &  not ( not ( not p inTARSKIR2 T1f0 & ( for q be ElementTREES-1M2-of T1f0 holds  for r be ElementTREES-1M2-of T2f0 holds  not (Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))) &  not p inTARSKIR2 tVar11)"
    proof-
      let ?X = "\<lambda>Lamb1. Lamb1 inHIDDENR3 T1f0 or ( ex q be ElementTREES-1M2-of T1f0 st  ex r be ElementTREES-1M2-of T2f0 st Pp1(q) & Lamb1 =HIDDENR1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
      obtain T where
        [ty]:"T be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 T iff x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3 & ?X(x)"
        using xboole_0_sch_1 sorry
      let ?t = "the ElementTREES-1M2-of T1f0"
      have "?t inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
        using finseq_1_def_11 sorry
      then have 
        [ty]:"T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
        using A1 sorry
      have "T be Tree-likeTREES-1V1"
      proof-
        have "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies ProperPrefixesTREES-1K1 p c=TARSKIR1 T) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>) inTARSKIR2 T & n <=XXREAL-0R1 k implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T))"
        proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          show "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
            using A1 sorry
          show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies ProperPrefixesTREES-1K1 p c=TARSKIR1 T"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume A2: "p inTARSKIR2 T"
            have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 p implies ( not x inHIDDENR3 T implies  not  True )"
            proof(rule ballI,rule impI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 ProperPrefixesTREES-1K1 p"
              then obtain q where
                [ty]:"q be FinSequenceFINSEQ-1M1" and 
                A3: "x =HIDDENR1 q"and A4: "q is-a-proper-prefix-ofTREES-1R3 p"
                using trees_1_def_2 sorry
              assume A5: " not x inHIDDENR3 T"
              have "q is-a-prefix-ofTREES-1R2 p"
                using A4 xboole_0_def_8 sorry
              then obtain r where
                [ty]:"r be FinSequenceFINSEQ-1M1" and 
                A6: "p =FINSEQ-1R1 q ^FINSEQ-1K8 r"
                using trees_1_th_1 sorry
              have 
                [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and
                [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                using A6 finseq_1_th_36 sorry
              have "(q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r inTARSKIR2 T1f0 & q inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3) & (q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r inTARSKIR2 T1f0 implies q inTARSKIR2 T1f0) or ( ex q be ElementTREES-1M2-of T1f0 st  ex r be ElementTREES-1M2-of T2f0 st Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
                using A1 A2 A6 finseq_1_def_11 trees_1_th_21 sorry
              then obtain q9 r9 where
                [ty]:"q9 be ElementTREES-1M2-of T1f0" "r9 be ElementTREES-1M2-of T2f0" and 
                A7: "Pp1(q9)"and A8: "q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r =FINSEQ-1R1 q9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r9"
                using A1 A3 A5 A6 sorry
              have "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 q9 implies  False "
              proof(rule impI)
                assume "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 q9"
                then have " ex s be FinSequenceFINSEQ-1M1 st q ^FINSEQ-1K8 s =FINSEQ-1R1 q9"
                  using A8 finseq_1_th_47 sorry
                then have A9: "q inTARSKIR2 T1f0"
                  using trees_1_th_21 sorry
                have "q inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
                  using finseq_1_def_11 sorry
                thus " False "
                  using A1 A3 A5 A9 sorry
              qed
              then obtain s where
                [ty]:"s be FinSequenceFINSEQ-1M1" and 
                A10: "q9 ^FINSEQ-1K8 s =FINSEQ-1R1 q"
                using A8 finseq_1_th_47 sorry
              have 
                [ty]:"s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                using A10 finseq_1_th_36 sorry
              have "q9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r9 =FINSEQ-1R1 q9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
                using A8 A10 finseq_1_th_32 sorry
              then have "s ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r =FINSEQ-1R1 r9"
                using finseq_1_th_33 sorry
              then have "q inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3 & s be ElementTREES-1M2-of T2f0"
                using finseq_1_def_11 trees_1_th_21 sorry
              thus " not  True "
                using A1 A3 A5 A7 A10 sorry
            qed "sorry"
            thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 T"
              using tarski_def_3 sorry
          qed "sorry"
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          fix k assume [ty]: "k be NatNAT-1M1"
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A11: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>) inTARSKIR2 T"
            and A12: "n <=XXREAL-0R1 k"
          have A13: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>) inTARSKIR2 T1f0 implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
          proof(rule impI)
            assume "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>) inTARSKIR2 T1f0"
            then have A14: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 n*>) inTARSKIR2 T1f0"
              using A12 trees_1_def_3 sorry
            have 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 n*>) inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
              using finseq_1_def_11 sorry
            thus "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
              using A1 A14 sorry
          qed
          have " not p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>) inTARSKIR2 T1f0 implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
          proof(rule impI)
            assume A15: " not p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>) inTARSKIR2 T1f0"
            then obtain q r where
              [ty]:"q be ElementTREES-1M2-of T1f0" "r be ElementTREES-1M2-of T2f0" and 
              A16: "Pp1(q)"and A17: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>) =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
              using A1 A11 sorry
            have "q ^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 q"
              using finseq_1_th_34 sorry
            then have "r <>HIDDENR2 {}XBOOLE-0K1"
              using A15 A17 sorry
            then obtain w z where
              [ty]:"w be FinSequenceFINSEQ-1M1" "z be objectHIDDENM1" and 
              A18: "r =FINSEQ-1R1 w ^FINSEQ-1K8 (<*FINSEQ-1K10 z*>)"
              using finseq_1_th_46 sorry
            have 
              [ty]:"w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              using A18 finseq_1_th_36 sorry
            have A19: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>) =FINSEQ-1R1 (q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> w)^FINSEQ-1K8 (<*FINSEQ-1K10 z*>)"
              using A17 A18 finseq_1_th_32 sorry
            have A20: "(p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 k & ((q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> w)^FINSEQ-1K8 (<*FINSEQ-1K10 z*>)).FUNCT-1K1 (lenFINSEQ-1K4 (q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> w) +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z"
              using finseq_1_th_42 sorry
            have A21: "lenFINSEQ-1K4 (<*TREES-3K14 k*>) =XBOOLE-0R4 \<one>\<^sub>M & lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>) =XBOOLE-0R4 \<one>\<^sub>M"
              using finseq_1_th_40 sorry
            have A22: "lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 k*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*TREES-3K14 k*>) & lenFINSEQ-1K4 ((q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> w)^FINSEQ-1K8 (<*FINSEQ-1K10 z*>)) =XBOOLE-0R4 lenFINSEQ-1K4 (q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> w) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 z*>)"
              using finseq_1_th_22 sorry
            then have A23: "p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> w"
              using A19 A20 A21 finseq_1_th_33 sorry
            have A24: "w ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 n*>) inTARSKIR2 T2f0"
              using A12 A18 A19 A20 A21 A22 trees_1_def_3 sorry
            have A25: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 n*>) =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (w ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 n*>))"
              using A23 finseq_1_th_32 sorry
            have 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 n*>) inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
              using finseq_1_def_11 sorry
            thus "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
              using A1 A16 A24 A25 sorry
          qed
          thus "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
            using A13 sorry
        qed "sorry"
        thus "T be Tree-likeTREES-1V1"
          using trees_1_def_3 sorry
      qed
      then have 
        [ty]:"T be TreeTREES-1M1"
         sorry
      show " ex tVar11 be TreeTREES-1M1 st  for p be FinSequenceFINSEQ-1M1 holds  not ((p inTARSKIR2 tVar11 &  not p inTARSKIR2 T1f0) & ( for q be ElementTREES-1M2-of T1f0 holds  for r be ElementTREES-1M2-of T2f0 holds  not (Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))) &  not ( not ( not p inTARSKIR2 T1f0 & ( for q be ElementTREES-1M2-of T1f0 holds  for r be ElementTREES-1M2-of T2f0 holds  not (Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))) &  not p inTARSKIR2 tVar11)"
      proof(rule bexI[of _ "T"],rule ballI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
        have "p be ElementTREES-1M2-of T1f0 or ( ex q be ElementTREES-1M2-of T1f0 st  ex r be ElementTREES-1M2-of T2f0 st Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies p inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
          using finseq_1_def_11 sorry
        thus " not ((p inTARSKIR2 T &  not p inTARSKIR2 T1f0) & ( for q be ElementTREES-1M2-of T1f0 holds  for r be ElementTREES-1M2-of T2f0 holds  not (Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))) &  not ( not ( not p inTARSKIR2 T1f0 & ( for q be ElementTREES-1M2-of T1f0 holds  for r be ElementTREES-1M2-of T2f0 holds  not (Pp1(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))) &  not p inTARSKIR2 T)"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef trees_4_def_7 ("'( _ , _ ')<-TREES-4K9  _ " [0,0,200]200 ) where
  mlet "T be DecoratedTreeTREES-2M4", "T9 be DecoratedTreeTREES-2M4", "x be setHIDDENM2"
"func (T,x)<-TREES-4K9 T9 \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. (( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 it iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies it .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies it .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q)"
proof-
  (*existence*)
    show " ex it be DecoratedTreeTREES-2M4 st (( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 it iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies it .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies it .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q)"
    proof-
      have " ex tVar16 be DecoratedTreeTREES-2M4 st ( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 tVar16 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies tVar16 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies tVar16 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q))"
      proof-
        let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 Lamb1 =XBOOLE-0R4 x"
        obtain W where
          [ty]:"W be TreeTREES-1M1" and 
          A1: " for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 W iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st ?X(q) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
          using trees_4_sch_1 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 be NodeTREES-4M1-of T & ( not Lamb1 inHIDDENR3 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 Lamb1 <>HIDDENR2 x)) & Lamb2 =HIDDENR1 T .FUNCT-1K1 Lamb1 or ( ex p be NodeTREES-4M1-of T st  ex q be NodeTREES-4M1-of T9 st ((Lamb1 =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q & p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 p =XBOOLE-0R4 x) & Lamb2 =HIDDENR1 T9 .FUNCT-1K1 q)"
        have A2: " for z be objectHIDDENM1 holds z inHIDDENR3 W implies ( ex y be objectHIDDENM1 st ?X(z,y))"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 W implies  not ( for y be objectHIDDENM1 holds  not ((z be NodeTREES-4M1-of T & ( not z inHIDDENR3 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 z <>HIDDENR2 x)) & y =HIDDENR1 T .FUNCT-1K1 z or ( ex p be NodeTREES-4M1-of T st  ex q be NodeTREES-4M1-of T9 st ((z =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q & p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 p =XBOOLE-0R4 x) & y =HIDDENR1 T9 .FUNCT-1K1 q)))"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 W"
            then obtain w where 
              [ty]:"w be ElementTREES-1M2-of W" and wDef:"w = z"
               sorry
            have A3: "( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & w =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies ( ex y be setHIDDENM2 st  ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st ((z =HIDDENR1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 q =XBOOLE-0R4 x) & y =XBOOLE-0R4 T9 .FUNCT-1K1 r)"
            proof(rule impI)
              assume Given: " ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & w =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
              then obtain q r where
                [ty]:"q be NodeTREES-4M1-of T" "r be NodeTREES-4M1-of T9" and 
                A4: "(q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & w =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                 sorry
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = T9 .FUNCT-1K1 r"
                 sorry
              show " ex y be setHIDDENM2 st  ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st ((z =HIDDENR1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 q =XBOOLE-0R4 x) & y =XBOOLE-0R4 T9 .FUNCT-1K1 r"
              proof(rule bexI[of _ "y"])
                show " ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st ((z =HIDDENR1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 q =XBOOLE-0R4 x) & y =XBOOLE-0R4 T9 .FUNCT-1K1 r"
                proof(rule bexI[of _ "q"])
                  show " ex r be NodeTREES-4M1-of T9 st ((z =HIDDENR1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 q =XBOOLE-0R4 x) & y =XBOOLE-0R4 T9 .FUNCT-1K1 r"
                  proof(rule bexI[of _ "r"])
                    show "((z =HIDDENR1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r & q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 q =XBOOLE-0R4 x) & y =XBOOLE-0R4 T9 .FUNCT-1K1 r"
                      using A4 sorry
                  qed "sorry"
                qed "sorry"
              qed "sorry"
            qed
            have " not ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & w =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies ( ex y be setHIDDENM2 st z be NodeTREES-4M1-of T & (( not z inHIDDENR3 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 z <>HIDDENR2 x) & y =XBOOLE-0R4 T .FUNCT-1K1 z))"
            proof(rule impI)
              assume A5: " not ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & w =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = T .FUNCT-1K1 z"
                 sorry
              show " ex y be setHIDDENM2 st z be NodeTREES-4M1-of T & (( not z inHIDDENR3 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 z <>HIDDENR2 x) & y =XBOOLE-0R4 T .FUNCT-1K1 z)"
              proof(rule bexI[of _ "y"],rule conjMI)
                show "z be NodeTREES-4M1-of T"
                  using A1 A5 sorry
                have 
                  [ty]:"w be NodeTREES-4M1-of T"
                  using A1 A5 sorry
                obtain e where 
                  [ty]:"e be NodeTREES-4M1-of T9" and eDef:"e = {}XBOOLE-0K1"
                  using trees_1_th_22 sorry
                have "w ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> e =FINSEQ-1R1 w"
                  using finseq_1_th_34 sorry
                thus "( not z inHIDDENR3 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 z <>HIDDENR2 x) & y =XBOOLE-0R4 T .FUNCT-1K1 z"
                  using A5 sorry
              qed "sorry"
            qed
            thus " not ( for y be objectHIDDENM1 holds  not ((z be NodeTREES-4M1-of T & ( not z inHIDDENR3 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 z <>HIDDENR2 x)) & y =HIDDENR1 T .FUNCT-1K1 z or ( ex p be NodeTREES-4M1-of T st  ex q be NodeTREES-4M1-of T9 st ((z =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q & p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 p =XBOOLE-0R4 x) & y =HIDDENR1 T9 .FUNCT-1K1 q)))"
              using A3 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A6: "domRELAT-1K1 f =XBOOLE-0R4 W & ( for z be objectHIDDENM1 holds z inHIDDENR3 W implies ?X(z,f .FUNCT-1K1 z))"
          using classes1_sch_1 A2 sorry
        have 
          [ty]:"f be DecoratedTreeTREES-2M4"
          using A6 trees_2_def_8 sorry
        show " ex tVar16 be DecoratedTreeTREES-2M4 st ( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 tVar16 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies tVar16 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies tVar16 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q))"
        proof(rule bexI[of _ "f"],rule conjMI,rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
          show " for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 f iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            using A1 A6 sorry
          show " for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies f .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be NodeTREES-4M1-of T"
            assume A7: " not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x"
            have A8: "p inTARSKIR2 W"
              using A1 sorry
            have "( ex p9 be NodeTREES-4M1-of T st  ex q be NodeTREES-4M1-of T9 st ((p =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q & p9 inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 p9 =XBOOLE-0R4 x) & f .FUNCT-1K1 p =XBOOLE-0R4 T9 .FUNCT-1K1 q) implies  False "
            proof(rule impI)
              assume Given: " ex p9 be NodeTREES-4M1-of T st  ex q be NodeTREES-4M1-of T9 st ((p =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q & p9 inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T) & T .FUNCT-1K1 p9 =XBOOLE-0R4 x) & f .FUNCT-1K1 p =XBOOLE-0R4 T9 .FUNCT-1K1 q"
              then obtain p9 q where
                [ty]:"p9 be NodeTREES-4M1-of T" "q be NodeTREES-4M1-of T9" and 
                A9: "p =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"and A10: "p9 inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T"and A11: "T .FUNCT-1K1 p9 =XBOOLE-0R4 x"and "f .FUNCT-1K1 p =XBOOLE-0R4 T9 .FUNCT-1K1 q"
                 sorry
              have "p9 is-a-prefix-ofTREES-1R2 p &  not p9 is-a-proper-prefix-ofTREES-1R3 p"
                using A9 A10 trees_1_th_1 trees_1_def_5 sorry
              thus " False "
                using A7 A10 A11 xboole_0_def_8 sorry
            qed
            thus "f .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p"
              using A6 A8 sorry
          qed "sorry"
          fix p assume [ty]: "p be NodeTREES-4M1-of T"
          fix q assume [ty]: "q be NodeTREES-4M1-of T9"
          assume A12: "p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T"
            and A13: "T .FUNCT-1K1 p =XBOOLE-0R4 x"
          have A14: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 W"
            using A1 A12 A13 sorry
          have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q be NodeTREES-4M1-of T implies p =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
          proof(rule impI)
            assume "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q be NodeTREES-4M1-of T"
            then have A15: " not p is-a-proper-prefix-ofTREES-1R3 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
              using A12 trees_1_def_5 sorry
            have "p is-a-prefix-ofTREES-1R2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
              using trees_1_th_1 sorry
            thus "p =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
              using A15 xboole_0_def_8 sorry
          qed
          then obtain p9 q9 where
            [ty]:"p9 be NodeTREES-4M1-of T" "q9 be NodeTREES-4M1-of T9" and 
            A16: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q9"and A17: "p9 inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T"and "T .FUNCT-1K1 p9 =XBOOLE-0R4 x"and A18: "f .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q9"
            using A6 A12 A13 A14 sorry
          have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be TreeTREES-1M1 holds p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q9 & ((p inTARSKIR2 LeavesTREES-1K3 T & p9 inTARSKIR2 LeavesTREES-1K3 T) & p <>HIDDENR2 p9) implies  False "
          proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            fix p9 assume [ty]: "p9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            fix q9 assume [ty]: "q9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            fix T assume [ty]: "T be TreeTREES-1M1"
            assume A19: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q9"
              and A20: "p inTARSKIR2 LeavesTREES-1K3 T & p9 inTARSKIR2 LeavesTREES-1K3 T"
              and A21: "p <>HIDDENR2 p9"
            have "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p9 implies  False "
            proof(rule impI)
              assume "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p9"
              then have " ex r be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 r =FINSEQ-1R1 p9"
                using A19 finseq_1_th_47 sorry
              then have "p is-a-prefix-ofTREES-1R2 p9"
                using trees_1_th_1 sorry
              then have "p is-a-proper-prefix-ofTREES-1R3 p9"
                using A21 xboole_0_def_8 sorry
              thus " False "
                using A20 trees_1_def_5 sorry
            qed
            then have " ex r be FinSequenceFINSEQ-1M1 st p9 ^FINSEQ-1K8 r =FINSEQ-1R1 p"
              using A19 finseq_1_th_47 sorry
            then have "p9 is-a-prefix-ofTREES-1R2 p"
              using trees_1_th_1 sorry
            then have "p9 is-a-proper-prefix-ofTREES-1R3 p"
              using A21 xboole_0_def_8 sorry
            thus " False "
              using A20 trees_1_def_5 sorry
          qed "sorry"
          then have "p =FINSEQ-1R1 p9"
            using A12 A16 A17 sorry
          thus "f .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q"
            using A16 A18 finseq_1_th_33 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds ((( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 it1 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies it1 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies it1 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q)) & ((( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 it2 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies it2 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies it2 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q)) implies it1 =HIDDENR1 it2"
    proof-
      have " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds ( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 T1 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies T1 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p) & (( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies T1 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q) & (( for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 T2 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (( for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies T2 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p) & ( for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies T2 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q))))) implies T1 =HIDDENR1 T2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
        fix T2 assume [ty]: "T2 be DecoratedTreeTREES-2M4"
        assume A22: " for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 T1 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
          and A23: " for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies T1 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p"
          and A24: " for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies T1 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q"
          and A25: " for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 domRELAT-1K1 T2 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
          and A26: " for p be NodeTREES-4M1-of T holds  not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies T2 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p"
          and A27: " for p be NodeTREES-4M1-of T holds  for q be NodeTREES-4M1-of T9 holds p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies T2 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q"
        have A28: "domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2"
        proof-
          have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 domRELAT-1K1 T1 &  not p inTARSKIR2 domRELAT-1K1 T2) &  not (p inTARSKIR2 domRELAT-1K1 T2 &  not p inTARSKIR2 domRELAT-1K1 T1)"
          proof(rule ballI)
            fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            have "p inTARSKIR2 domRELAT-1K1 T1 iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
              using A22 sorry
            thus " not (p inTARSKIR2 domRELAT-1K1 T1 &  not p inTARSKIR2 domRELAT-1K1 T2) &  not (p inTARSKIR2 domRELAT-1K1 T2 &  not p inTARSKIR2 domRELAT-1K1 T1)"
              using A25 sorry
          qed "sorry"
          thus "domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2"
            using trees_2_def_1 sorry
        qed
        obtain p9 where 
          [ty]:"p9 be NodeTREES-4M1-of T9" and p9Def:"p9 = {}XBOOLE-0K1"
          using trees_1_th_22 sorry
        have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 T1 implies T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 domRELAT-1K1 T1"
          then obtain p where 
            [ty]:"p be NodeTREES-4M1-of T1" and pDef:"p = y"
             sorry
          show "T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
          proof-
            have cases: "p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
              using A22 sorry
            have case1: "p inTARSKIR2 domRELAT-1K1 T implies T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
            proof(rule impI)
              assume "p inTARSKIR2 domRELAT-1K1 T"
              then have 
                [ty]:"p be NodeTREES-4M1-of T"
                 sorry
              show "T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
              proof-
                show "T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
                proof-
                  have cases: "p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x or ( not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x)"
                     sorry
                  have case1: "p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x implies T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
                  proof(rule impI)
                    assume A29: "p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 p =XBOOLE-0R4 x"
                    then have A30: "T1 .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p9) =XBOOLE-0R4 T9 .FUNCT-1K1 p9"
                      using A24 sorry
                    have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p9 =FINSEQ-1R1 p"
                      using finseq_1_th_34 sorry
                    thus "T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
                      using A27 A29 A30 sorry
                  qed
                  have case2: " not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x implies T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
                  proof(rule impI)
                    assume A31: " not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .FUNCT-1K1 p <>HIDDENR2 x"
                    then have "T1 .FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p"
                      using A23 sorry
                    thus "T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
                      using A26 A31 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
            qed
            have case2: "( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies T1 .FUNCT-1K1 y =HIDDENR1 T2 .FUNCT-1K1 y"
            proof(rule impI)
              assume " ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
              then obtain q r where
                [ty]:"q be NodeTREES-4M1-of T" "r be NodeTREES-4M1-of T9" and 
                A32: "(q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                 sorry
              have "T1 .FUNCT-1K1 y =HIDDENR1 T9 .FUNCT-1K1 r"
                using A24 A32 sorry
              also have "... = T2 .FUNCT-1K1 y"
                using A27 A32 sorry
              finally show "T1 .FUNCT-1K1 y =HIDDENR1 T2 .FUNCT-1K1 y"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "T1 =HIDDENR1 T2"
          using A28 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_4_cl_6:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "T9 be DecoratedTreeTREES-2M5-of D", "x be setHIDDENM2"
"cluster (T,x)<-TREES-4K9 T9 as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "(T,x)<-TREES-4K9 T9 be D -valuedRELAT-1V5"
  proof-
    have "rngFUNCT-1K2 ((T,x)<-TREES-4K9 T9) c=TARSKIR1 D"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 ((T,x)<-TREES-4K9 T9) implies y inHIDDENR3 D"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 ((T,x)<-TREES-4K9 T9)"
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A1: "z inHIDDENR3 domRELAT-1K1 ((T,x)<-TREES-4K9 T9)"and A2: "y =HIDDENR1 ((T,x)<-TREES-4K9 T9).FUNCT-1K1 z"
          using funct_1_def_3 sorry
        have 
          [ty]:"z be NodeTREES-4M1-of (T,x)<-TREES-4K9 T9"
          using A1 sorry
        obtain p9 where 
          [ty]:"p9 be NodeTREES-4M1-of T9" and p9Def:"p9 = {}XBOOLE-0K1"
          using trees_1_th_22 sorry
        show "y inHIDDENR3 D"
        proof-
          have cases: "z inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .TREES-2K3\<^bsub>(D)\<^esub> q =XBOOLE-0R4 x) & z =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            using trees_4_def_7 sorry
          have case1: "z inTARSKIR2 domRELAT-1K1 T implies y inHIDDENR3 D"
          proof(rule impI)
            assume "z inTARSKIR2 domRELAT-1K1 T"
            then obtain p where 
              [ty]:"p be NodeTREES-4M1-of T" and pDef:"p = z"
               sorry
            show "y inHIDDENR3 D"
            proof-
              show "y inHIDDENR3 D"
              proof-
                have cases: "p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .TREES-2K3\<^bsub>(D)\<^esub> p =XBOOLE-0R4 x or ( not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .TREES-2K3\<^bsub>(D)\<^esub> p <>HIDDENR2 x)"
                   sorry
                have case1: "p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .TREES-2K3\<^bsub>(D)\<^esub> p =XBOOLE-0R4 x implies y inHIDDENR3 D"
                proof(rule impI)
                  assume "p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .TREES-2K3\<^bsub>(D)\<^esub> p =XBOOLE-0R4 x"
                  then have A3: "((T,x)<-TREES-4K9 T9).FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p9) =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(D)\<^esub> p9"
                    using trees_4_def_7 sorry
                  have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p9 =FINSEQ-1R1 p"
                    using finseq_1_th_34 sorry
                  thus "y inHIDDENR3 D"
                    using A2 A3 sorry
                qed
                have case2: " not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .TREES-2K3\<^bsub>(D)\<^esub> p <>HIDDENR2 x implies y inHIDDENR3 D"
                proof(rule impI)
                  assume " not p inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T or T .TREES-2K3\<^bsub>(D)\<^esub> p <>HIDDENR2 x"
                  then have "((T,x)<-TREES-4K9 T9).FUNCT-1K1 p =XBOOLE-0R4 T .TREES-2K3\<^bsub>(D)\<^esub> p"
                    using trees_4_def_7 sorry
                  thus "y inHIDDENR3 D"
                    using A2 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
          qed
          have case2: "( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .TREES-2K3\<^bsub>(D)\<^esub> q =XBOOLE-0R4 x) & z =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies y inHIDDENR3 D"
          proof(rule impI)
            assume " ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .TREES-2K3\<^bsub>(D)\<^esub> q =XBOOLE-0R4 x) & z =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
            then obtain q r where
              [ty]:"q be NodeTREES-4M1-of T" "r be NodeTREES-4M1-of T9" and 
              A4: "(q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .TREES-2K3\<^bsub>(D)\<^esub> q =XBOOLE-0R4 x) & z =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
               sorry
            have "((T,x)<-TREES-4K9 T9).FUNCT-1K1 z =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(D)\<^esub> r"
              using A4 trees_4_def_7 sorry
            thus "y inHIDDENR3 D"
              using A2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "rngFUNCT-1K2 ((T,x)<-TREES-4K9 T9) c=TARSKIR1 D"
        using tarski_def_3 sorry
    qed
    thus "(T,x)<-TREES-4K9 T9 be D -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

reserve T, T9 for "DecoratedTreeTREES-2M4"
reserve x, y for "setHIDDENM2"
mtheorem trees_4_th_23:
" for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for x be setHIDDENM2 holds  not x inTARSKIR2 rngFUNCT-1K2 T or  not x inTARSKIR2 LeavesTREES-2K4 T implies (T,x)<-TREES-4K9 T9 =TREES-4R1 T"
proof-
  have " for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for x be setHIDDENM2 holds  not x inTARSKIR2 rngFUNCT-1K2 T or  not x inTARSKIR2 LeavesTREES-2K4 T implies (T,x)<-TREES-4K9 T9 =TREES-4R1 T"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    fix T9 assume [ty]: "T9 be DecoratedTreeTREES-2M4"
    fix x assume [ty]: "x be setHIDDENM2"
    have A1: "LeavesTREES-2K4 T c=TARSKIR1 rngFUNCT-1K2 T"
      using relat_1_th_111 sorry
    assume " not x inTARSKIR2 rngFUNCT-1K2 T or  not x inTARSKIR2 LeavesTREES-2K4 T"
    then have A2: " not x inTARSKIR2 LeavesTREES-2K4 T"
      using A1 sorry
    have "domRELAT-1K1 ((T,x)<-TREES-4K9 T9) =TREES-2R1 domRELAT-1K1 T & ( for p be NodeTREES-4M1-of (T,x)<-TREES-4K9 T9 holds ((T,x)<-TREES-4K9 T9).FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p)"
    proof(rule conjMI,rule ballI)
      show A3: "domRELAT-1K1 ((T,x)<-TREES-4K9 T9) =TREES-2R1 domRELAT-1K1 T"
      proof-
        have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 domRELAT-1K1 ((T,x)<-TREES-4K9 T9) &  not p inTARSKIR2 domRELAT-1K1 T) &  not (p inTARSKIR2 domRELAT-1K1 T &  not p inTARSKIR2 domRELAT-1K1 ((T,x)<-TREES-4K9 T9))"
        proof(rule ballI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          have "p inTARSKIR2 domRELAT-1K1 ((T,x)<-TREES-4K9 T9) iff p inTARSKIR2 domRELAT-1K1 T or ( ex q be NodeTREES-4M1-of T st  ex r be NodeTREES-4M1-of T9 st (q inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T & T .FUNCT-1K1 q =XBOOLE-0R4 x) & p =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            using trees_4_def_7 sorry
          thus " not (p inTARSKIR2 domRELAT-1K1 ((T,x)<-TREES-4K9 T9) &  not p inTARSKIR2 domRELAT-1K1 T) &  not (p inTARSKIR2 domRELAT-1K1 T &  not p inTARSKIR2 domRELAT-1K1 ((T,x)<-TREES-4K9 T9))"
            using A2 funct_1_def_6 sorry
        qed "sorry"
        thus "domRELAT-1K1 ((T,x)<-TREES-4K9 T9) =TREES-2R1 domRELAT-1K1 T"
          using trees_2_def_1 sorry
      qed
      fix p assume [ty]: "p be NodeTREES-4M1-of (T,x)<-TREES-4K9 T9"
      obtain p9 where 
        [ty]:"p9 be NodeTREES-4M1-of T" and p9Def:"p9 = p"
        using A3 sorry
      have "p9 inTARSKIR2 LeavesTREES-1K3 domRELAT-1K1 T implies T .FUNCT-1K1 p9 inTARSKIR2 LeavesTREES-2K4 T"
        using funct_1_def_6 sorry
      thus "((T,x)<-TREES-4K9 T9).FUNCT-1K1 p =XBOOLE-0R4 T .FUNCT-1K1 p"
        using A2 trees_4_def_7 sorry
    qed "sorry"
    thus "(T,x)<-TREES-4K9 T9 =TREES-4R1 T"
      using trees_4_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve D1, D2 for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve T for "DecoratedTreeTREES-3M2-of(D1,D2)"
reserve d1 for "ElementSUBSET-1M1-of D1"
reserve d2 for "ElementSUBSET-1M1-of D2"
reserve F for " non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2)"
reserve F1 for " non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D1"
reserve F2 for " non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D2"
mtheorem trees_4_th_24:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for T be DecoratedTreeTREES-3M2-of(D1,D2) holds domRELAT-1K1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T & domRELAT-1K1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
proof(rule ballI,rule ballI,rule ballI)
  fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix T assume [ty]: "T be DecoratedTreeTREES-3M2-of(D1,D2)"
  have A1: "T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 pr1TREES-3K6(D1,D2) *FUNCT-1K3 T & T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 pr2TREES-3K7(D1,D2) *FUNCT-1K3 T"
    using trees_3_def_12 trees_3_def_13 sorry
  have A2: "rngFUNCT-1K2 T c=TARSKIR1 [:ZFMISC-1K2 D1,D2 :] & domRELAT-1K1 (pr1TREES-3K6(D1,D2)) =XBOOLE-0R4 [:ZFMISC-1K2 D1,D2 :]"
    using funct_2_def_1 relat_1_def_19 sorry
  have "domRELAT-1K1 (pr2TREES-3K7(D1,D2)) =XBOOLE-0R4 [:ZFMISC-1K2 D1,D2 :]"
    using funct_2_def_1 sorry
  thus "domRELAT-1K1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T & domRELAT-1K1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
    using A1 A2 relat_1_th_27 sorry
qed "sorry"

mtheorem trees_4_th_25:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 root-treeTREES-4K2\<^bsub>(D1)\<^esub> d1 & (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 root-treeTREES-4K2\<^bsub>(D2)\<^esub> d2"
proof-
  have " for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =HIDDENR1 root-treeTREES-4K2\<^bsub>(D1)\<^esub> d1 & (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =HIDDENR1 root-treeTREES-4K2\<^bsub>(D2)\<^esub> d2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D2"
    obtain r where 
      [ty]:"r be NodeTREES-4M1-of root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ]" and rDef:"r = {}XBOOLE-0K1"
      using trees_1_th_22 sorry
    have A1: "domRELAT-1K1 (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])"
      using trees_4_th_24 sorry
    have A2: "domRELAT-1K1 (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])"
      using trees_4_th_24 sorry
    have A3: "(root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ]).TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> r =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ]"
      using trees_4_th_3 sorry
    have A4: "[DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] `1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub> =XBOOLE-0R4 d1"
       sorry
    have A5: "[DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] `2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub> =XBOOLE-0R4 d2"
       sorry
    have "(root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =HIDDENR1 root-treeTREES-4K1 (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 r"
      using A1 trees_4_th_3 trees_4_th_5 sorry
    also have "... = root-treeTREES-4K2\<^bsub>(D1)\<^esub> d1"
      using A3 A4 trees_3_th_39 sorry
    finally show "(root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =HIDDENR1 root-treeTREES-4K2\<^bsub>(D1)\<^esub> d1"
       sorry
    have "(root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =HIDDENR1 root-treeTREES-4K1 (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 r"
      using A2 trees_4_th_3 trees_4_th_5 sorry
    also have "... = root-treeTREES-4K2\<^bsub>(D2)\<^esub> d2"
      using A3 A5 trees_3_th_39 sorry
    finally show "(root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ])`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =HIDDENR1 root-treeTREES-4K2\<^bsub>(D2)\<^esub> d2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_26:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds <:FUNCT-3K14 root-treeTREES-4K1 x,root-treeTREES-4K1 y :> =TREES-4R1 root-treeTREES-4K1 [TARSKIK4 x,y ]"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds <:FUNCT-3K14 root-treeTREES-4K1 x,root-treeTREES-4K1 y :> =TREES-4R1 root-treeTREES-4K1 [TARSKIK4 x,y ]"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    obtain x9 where 
      [ty]:"x9 be ElementSUBSET-1M1-of {TARSKIK1 x}" and x9Def:"x9 = x"
      using tarski_def_1 sorry
    obtain y9 where 
      [ty]:"y9 be ElementSUBSET-1M1-of {TARSKIK1 y}" and y9Def:"y9 = y"
      using tarski_def_1 sorry
    have "(root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :])\<^esub> [DOMAIN-1K1\<^bsub>({TARSKIK1 x},{TARSKIK1 y})\<^esub> x9,y9 ])`1TREES-3K8\<^bsub>({TARSKIK1 x},{TARSKIK1 y})\<^esub> =TREES-4R1 root-treeTREES-4K1 x & (root-treeTREES-4K2\<^bsub>([:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :])\<^esub> [DOMAIN-1K1\<^bsub>({TARSKIK1 x},{TARSKIK1 y})\<^esub> x9,y9 ])`2TREES-3K9\<^bsub>({TARSKIK1 x},{TARSKIK1 y})\<^esub> =TREES-4R1 root-treeTREES-4K1 y"
      using trees_4_th_25 sorry
    thus "<:FUNCT-3K14 root-treeTREES-4K1 x,root-treeTREES-4K1 y :> =TREES-4R1 root-treeTREES-4K1 [TARSKIK4 x,y ]"
      using trees_3_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_27:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for F1 be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D1 holds  for p be FinSequenceFINSEQ-1M3-of F holds  for p1 be FinSequenceFINSEQ-1M3-of F1 holds domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>)) implies ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 p1"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
  fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D2"
  fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2)"
  fix F1 assume [ty]: "F1 be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D1"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of F"
  fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M3-of F1"
  assume A1: "domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p"
    and A2: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>)"
  let ?W = "[DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p"
  let ?W1 = "d1 -treeTREES-4K4 p1"
  have A3: "lenFINSEQ-1K4 (domsFUNCT-6K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
    using trees_3_th_38 sorry
  have A4: "lenFINSEQ-1K4 (domsFUNCT-6K1 p1) =XBOOLE-0R4 lenFINSEQ-1K4 p1"
    using trees_3_th_38 sorry
  have A5: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p1"
    using A1 finseq_3_th_29 sorry
  then have A6: "domFINSEQ-1K5 (domsFUNCT-6K1 p) =XBOOLE-0R4 domFINSEQ-1K5 (domsFUNCT-6K1 p1)"
    using A3 A4 finseq_3_th_29 sorry
  have A7: "domFINSEQ-1K5 (domsFUNCT-6K1 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
    using A3 finseq_3_th_29 sorry
  have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies domsFUNCT-6K1 p .FUNCT-1K1 i =XBOOLE-0R4 domsFUNCT-6K1 p1 .FUNCT-1K1 i"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A8: "i inTARSKIR2 domFINSEQ-1K5 p"
    then obtain T where 
      [ty]:"T be ElementSUBSET-1M1-of F" and TDef:"T = p .FUNCT-1K1 i"
      using trees_4_lm_1 sorry
    have A9: "p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
      using A2 A8 sorry
    have A10: "domsFUNCT-6K1 p .FUNCT-1K1 i =XBOOLE-0R4 domRELAT-1K1 T"
      using A8 funct_6_th_22 sorry
    have "domsFUNCT-6K1 p1 .FUNCT-1K1 i =XBOOLE-0R4 domRELAT-1K1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
      using A1 A8 A9 funct_6_th_22 sorry
    thus "domsFUNCT-6K1 p .FUNCT-1K1 i =XBOOLE-0R4 domsFUNCT-6K1 p1 .FUNCT-1K1 i"
      using A10 trees_4_th_24 sorry
  qed "sorry"
  then have A11: "domsFUNCT-6K1 p =FINSEQ-1R1 domsFUNCT-6K1 p1"
    using A6 A7 finseq_1_th_13 sorry
  have Cut1270: "domRELAT-1K1 ?W `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =HIDDENR1 domRELAT-1K1 ?W"
    using trees_4_th_24 sorry
  also have "... = treeTREES-3K11 domsFUNCT-6K1 p"
    using trees_4_th_10 sorry
  finally have "domRELAT-1K1 ?W `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =HIDDENR1 treeTREES-3K11 domsFUNCT-6K1 p"
     sorry
  have "domRELAT-1K1 ?W `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 ?W1 & ( for x be NodeTREES-4M1-of ?W `1TREES-3K8\<^bsub>(D1,D2)\<^esub> holds ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d1 -treeTREES-4K4 p1).FUNCT-1K1 x)"
  proof(rule conjMI,rule ballI)
    show "domRELAT-1K1 ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 (d1 -treeTREES-4K4 p1)"
      using A11 trees_4_th_10 Cut1270 sorry
    fix x assume [ty]: "x be NodeTREES-4M1-of ?W `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
    obtain a where 
      [ty]:"a be NodeTREES-4M1-of ?W" and aDef:"a = x"
      using trees_4_th_24 sorry
    have A12: "?W `1TREES-3K8\<^bsub>(D1,D2)\<^esub> .TREES-2K3\<^bsub>(D1)\<^esub> x =XBOOLE-0R4 (?W .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> a)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub>"
      using trees_3_th_39 sorry
    show "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d1 -treeTREES-4K4 p1).FUNCT-1K1 x"
    proof-
      have cases: "x =FINSEQ-1R1 {}XBOOLE-0K1 or x <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "x =FINSEQ-1R1 {}XBOOLE-0K1 implies ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d1 -treeTREES-4K4 p1).FUNCT-1K1 x"
      proof(rule impI)
        assume "x =FINSEQ-1R1 {}XBOOLE-0K1"
        then have "?W .FUNCT-1K1 x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] & ?W1 .FUNCT-1K1 x =XBOOLE-0R4 d1"
          using trees_4_def_4 sorry
        thus "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d1 -treeTREES-4K4 p1).FUNCT-1K1 x"
          using A12 sorry
      qed
      have case2: "x <>HIDDENR2 {}XBOOLE-0K1 implies ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d1 -treeTREES-4K4 p1).FUNCT-1K1 x"
      proof(rule impI)
        assume "x <>HIDDENR2 {}XBOOLE-0K1"
        then obtain n T q where
          [ty]:"n be NatNAT-1M1" "T be DecoratedTreeTREES-2M4" "q be NodeTREES-4M1-of T" and 
          A13: "n <XXREAL-0R3 lenFINSEQ-1K4 p"and A14: "T =FUNCT-1R1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A15: "a =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
          using trees_4_th_11 sorry
        have 
          [ty]:"T be ElementSUBSET-1M1-of F"
          using A13 A14 trees_4_lm_3 sorry
        have 
          [ty]:"q be NodeTREES-4M1-of T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
          using trees_4_th_24 sorry
        have A16: "p1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
          using A2 A13 A14 trees_4_lm_2 sorry
        have A17: "?W .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> a =XBOOLE-0R4 T .FUNCT-1K1 q"
          using A13 A14 A15 trees_4_th_12 sorry
        have "?W1 .FUNCT-1K1 a =XBOOLE-0R4 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> .TREES-2K3\<^bsub>(D1)\<^esub> q"
          using A5 A13 A15 A16 trees_4_th_12 sorry
        thus "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d1 -treeTREES-4K4 p1).FUNCT-1K1 x"
          using A12 A17 trees_3_th_39 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 p1"
    using trees_4_def_1 sorry
qed "sorry"

mtheorem trees_4_th_28:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for F2 be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D2 holds  for p be FinSequenceFINSEQ-1M3-of F holds  for p2 be FinSequenceFINSEQ-1M3-of F2 holds domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>)) implies ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 p2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
  fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D2"
  fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2)"
  fix F2 assume [ty]: "F2 be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D2"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of F"
  fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M3-of F2"
  assume A1: "domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p"
    and A2: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>)"
  let ?W = "[DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p"
  let ?W2 = "d2 -treeTREES-4K4 p2"
  have A3: "lenFINSEQ-1K4 (domsFUNCT-6K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
    using trees_3_th_38 sorry
  have A4: "lenFINSEQ-1K4 (domsFUNCT-6K1 p2) =XBOOLE-0R4 lenFINSEQ-1K4 p2"
    using trees_3_th_38 sorry
  have A5: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p2"
    using A1 finseq_3_th_29 sorry
  then have A6: "domFINSEQ-1K5 (domsFUNCT-6K1 p) =XBOOLE-0R4 domFINSEQ-1K5 (domsFUNCT-6K1 p2)"
    using A3 A4 finseq_3_th_29 sorry
  have A7: "domFINSEQ-1K5 (domsFUNCT-6K1 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
    using A3 finseq_3_th_29 sorry
  have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies domsFUNCT-6K1 p .FUNCT-1K1 i =XBOOLE-0R4 domsFUNCT-6K1 p2 .FUNCT-1K1 i"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A8: "i inTARSKIR2 domFINSEQ-1K5 p"
    then obtain T where 
      [ty]:"T be ElementSUBSET-1M1-of F" and TDef:"T = p .FUNCT-1K1 i"
      using trees_4_lm_1 sorry
    have A9: "p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
      using A2 A8 sorry
    have A10: "domsFUNCT-6K1 p .FUNCT-1K1 i =XBOOLE-0R4 domRELAT-1K1 T"
      using A8 funct_6_th_22 sorry
    have "domsFUNCT-6K1 p2 .FUNCT-1K1 i =XBOOLE-0R4 domRELAT-1K1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
      using A1 A8 A9 funct_6_th_22 sorry
    thus "domsFUNCT-6K1 p .FUNCT-1K1 i =XBOOLE-0R4 domsFUNCT-6K1 p2 .FUNCT-1K1 i"
      using A10 trees_4_th_24 sorry
  qed "sorry"
  then have A11: "domsFUNCT-6K1 p =FINSEQ-1R1 domsFUNCT-6K1 p2"
    using A6 A7 finseq_1_th_13 sorry
  have Cut1325: "domRELAT-1K1 ?W `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =HIDDENR1 domRELAT-1K1 ?W"
    using trees_4_th_24 sorry
  also have "... = treeTREES-3K11 domsFUNCT-6K1 p"
    using trees_4_th_10 sorry
  finally have "domRELAT-1K1 ?W `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =HIDDENR1 treeTREES-3K11 domsFUNCT-6K1 p"
     sorry
  have "domRELAT-1K1 ?W `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 ?W2 & ( for x be NodeTREES-4M1-of ?W `2TREES-3K9\<^bsub>(D1,D2)\<^esub> holds ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d2 -treeTREES-4K4 p2).FUNCT-1K1 x)"
  proof(rule conjMI,rule ballI)
    show "domRELAT-1K1 ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 (d2 -treeTREES-4K4 p2)"
      using A11 trees_4_th_10 Cut1325 sorry
    fix x assume [ty]: "x be NodeTREES-4M1-of ?W `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
    obtain a where 
      [ty]:"a be NodeTREES-4M1-of ?W" and aDef:"a = x"
      using trees_4_th_24 sorry
    have A12: "?W `2TREES-3K9\<^bsub>(D1,D2)\<^esub> .TREES-2K3\<^bsub>(D2)\<^esub> x =XBOOLE-0R4 (?W .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> a)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub>"
      using trees_3_th_39 sorry
    show "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d2 -treeTREES-4K4 p2).FUNCT-1K1 x"
    proof-
      have cases: "x =FINSEQ-1R1 {}XBOOLE-0K1 or x <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "x =FINSEQ-1R1 {}XBOOLE-0K1 implies ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d2 -treeTREES-4K4 p2).FUNCT-1K1 x"
      proof(rule impI)
        assume "x =FINSEQ-1R1 {}XBOOLE-0K1"
        then have "?W .FUNCT-1K1 x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] & ?W2 .FUNCT-1K1 x =XBOOLE-0R4 d2"
          using trees_4_def_4 sorry
        thus "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d2 -treeTREES-4K4 p2).FUNCT-1K1 x"
          using A12 sorry
      qed
      have case2: "x <>HIDDENR2 {}XBOOLE-0K1 implies ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d2 -treeTREES-4K4 p2).FUNCT-1K1 x"
      proof(rule impI)
        assume "x <>HIDDENR2 {}XBOOLE-0K1"
        then obtain n T q where
          [ty]:"n be NatNAT-1M1" "T be DecoratedTreeTREES-2M4" "q be NodeTREES-4M1-of T" and 
          A13: "n <XXREAL-0R3 lenFINSEQ-1K4 p"and A14: "T =FUNCT-1R1 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A15: "a =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
          using trees_4_th_11 sorry
        have 
          [ty]:"T be ElementSUBSET-1M1-of F"
          using A13 A14 trees_4_lm_3 sorry
        have 
          [ty]:"q be NodeTREES-4M1-of T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
          using trees_4_th_24 sorry
        have A16: "p2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
          using A2 A13 A14 trees_4_lm_2 sorry
        have A17: "?W .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> a =XBOOLE-0R4 T .FUNCT-1K1 q"
          using A13 A14 A15 trees_4_th_12 sorry
        have "?W2 .FUNCT-1K1 a =XBOOLE-0R4 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> .TREES-2K3\<^bsub>(D2)\<^esub> q"
          using A5 A13 A15 A16 trees_4_th_12 sorry
        thus "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 x =XBOOLE-0R4 (d2 -treeTREES-4K4 p2).FUNCT-1K1 x"
          using A12 A17 trees_3_th_39 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 p2"
    using trees_4_def_1 sorry
qed "sorry"

mtheorem trees_4_th_29:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for p be FinSequenceFINSEQ-1M3-of F holds  ex p1 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D1 st (domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 p1"
proof-
  have " for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for p be FinSequenceFINSEQ-1M3-of F holds  ex tVar19 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D1 st domFINSEQ-1K5 tVar19 =XBOOLE-0R4 domFINSEQ-1K5 p & (( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & tVar19 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>)) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 tVar19)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D2"
    fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2)"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of F"
    have A1: "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 Lamb1 & Lamb2 =XBOOLE-0R4 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
    have A2: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ( ex x be ElementSUBSET-1M1-of TreesTREES-3K4 D1 st ?X(i,x))"
    proof-
      have " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ( ex tVar17 be ElementSUBSET-1M1-of TreesTREES-3K4 D1 st  ex tVar18 be ElementSUBSET-1M1-of F st tVar18 =FUNCT-1R1 p .FUNCT-1K1 i & tVar17 =XBOOLE-0R4 tVar18 `1TREES-3K8\<^bsub>(D1,D2)\<^esub>)"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
        then obtain T where 
          [ty]:"T be ElementSUBSET-1M1-of F" and TDef:"T = p .FUNCT-1K1 i"
          using A1 trees_4_lm_1 sorry
        obtain y where 
          [ty]:"y be ElementSUBSET-1M1-of TreesTREES-3K4 D1" and yDef:"y = T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
          using trees_3_def_7 sorry
        show " ex tVar17 be ElementSUBSET-1M1-of TreesTREES-3K4 D1 st  ex tVar18 be ElementSUBSET-1M1-of F st tVar18 =FUNCT-1R1 p .FUNCT-1K1 i & tVar17 =XBOOLE-0R4 tVar18 `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
        proof(rule bexI[of _ "y"])
          show " ex tVar18 be ElementSUBSET-1M1-of F st tVar18 =FUNCT-1R1 p .FUNCT-1K1 i & y =XBOOLE-0R4 tVar18 `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
          proof(rule bexI[of _ "T"])
            show "T =FUNCT-1R1 p .FUNCT-1K1 i & y =XBOOLE-0R4 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
               sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain p1 where
      [ty]:"p1 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D1" and 
      A3: "domFINSEQ-1K5 p1 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ?X(i,p1 .FUNCT-1K1 i))"
      using finseq_1_sch_5 A2 sorry
    show " ex tVar19 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D1 st domFINSEQ-1K5 tVar19 =XBOOLE-0R4 domFINSEQ-1K5 p & (( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & tVar19 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>)) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 tVar19)"
    proof(rule bexI[of _ "p1"],rule conjMI,rule conjMI)
      show A4: "domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p"
        using A3 finseq_1_def_3 sorry
      thus " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>)"
        using A3 sorry
      have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>)"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume "i inTARSKIR2 domFINSEQ-1K5 p"
        then have " ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
          using A3 A4 sorry
        thus " for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
           sorry
      qed "sorry"
      thus "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 p1"
        using A4 trees_4_th_27 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_30:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for p be FinSequenceFINSEQ-1M3-of F holds  ex p2 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D2 st (domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 p2"
proof-
  have " for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2) holds  for p be FinSequenceFINSEQ-1M3-of F holds  ex tVar22 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D2 st domFINSEQ-1K5 tVar22 =XBOOLE-0R4 domFINSEQ-1K5 p & (( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & tVar22 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>)) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 tVar22)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D2"
    fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M3-of(D1,D2)"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of F"
    have A1: "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 Lamb1 & Lamb2 =XBOOLE-0R4 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
    have A2: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ( ex x be ElementSUBSET-1M1-of TreesTREES-3K4 D2 st ?X(i,x))"
    proof-
      have " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ( ex tVar20 be ElementSUBSET-1M1-of TreesTREES-3K4 D2 st  ex tVar21 be ElementSUBSET-1M1-of F st tVar21 =FUNCT-1R1 p .FUNCT-1K1 i & tVar20 =XBOOLE-0R4 tVar21 `2TREES-3K9\<^bsub>(D1,D2)\<^esub>)"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
        then obtain T where 
          [ty]:"T be ElementSUBSET-1M1-of F" and TDef:"T = p .FUNCT-1K1 i"
          using A1 trees_4_lm_1 sorry
        obtain y where 
          [ty]:"y be ElementSUBSET-1M1-of TreesTREES-3K4 D2" and yDef:"y = T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
          using trees_3_def_7 sorry
        show " ex tVar20 be ElementSUBSET-1M1-of TreesTREES-3K4 D2 st  ex tVar21 be ElementSUBSET-1M1-of F st tVar21 =FUNCT-1R1 p .FUNCT-1K1 i & tVar20 =XBOOLE-0R4 tVar21 `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
        proof(rule bexI[of _ "y"])
          show " ex tVar21 be ElementSUBSET-1M1-of F st tVar21 =FUNCT-1R1 p .FUNCT-1K1 i & y =XBOOLE-0R4 tVar21 `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
          proof(rule bexI[of _ "T"])
            show "T =FUNCT-1R1 p .FUNCT-1K1 i & y =XBOOLE-0R4 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
               sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain p2 where
      [ty]:"p2 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D2" and 
      A3: "domFINSEQ-1K5 p2 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ?X(i,p2 .FUNCT-1K1 i))"
      using finseq_1_sch_5 A2 sorry
    show " ex tVar22 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D2 st domFINSEQ-1K5 tVar22 =XBOOLE-0R4 domFINSEQ-1K5 p & (( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & tVar22 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>)) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 tVar22)"
    proof(rule bexI[of _ "p2"],rule conjMI,rule conjMI)
      show A4: "domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p"
        using A3 finseq_1_def_3 sorry
      thus " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>)"
        using A3 sorry
      have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>)"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume "i inTARSKIR2 domFINSEQ-1K5 p"
        then have " ex T be ElementSUBSET-1M1-of F st T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
          using A3 A4 sorry
        thus " for T be DecoratedTreeTREES-3M2-of(D1,D2) holds T =FUNCT-1R1 p .FUNCT-1K1 i implies p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
           sorry
      qed "sorry"
      thus "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K4 p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 p2"
        using A4 trees_4_th_28 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_31:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  ex p1 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D1 st (domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) st T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K8\<^bsub>(D1)\<^esub> p1"
proof-
  have " for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  not ( for p1 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D1 holds  not ((domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds  not (i inTARSKIR2 domFINSEQ-1K5 p & ( for T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  not (T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>))))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K8\<^bsub>(D1)\<^esub> p1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :])"
    obtain p1 where
      [ty]:"p1 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D1" and 
      A1: "domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) st T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>))"and A2: "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K4 p1"
      using trees_4_th_29 sorry
    have "rngFUNCT-1K2 p1 c=TARSKIR1 FinTreesTREES-3K5 D1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p1 implies x inHIDDENR3 FinTreesTREES-3K5 D1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 p1"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "y inHIDDENR3 domFINSEQ-1K5 p1"and A4: "x =HIDDENR1 p1 .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"y be NatNAT-1M1"
          using A3 sorry
        obtain T where
          [ty]:"T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :])" and 
          "T =FUNCT-1R1 p .FUNCT-1K1 y"and A5: "p1 .FUNCT-1K1 y =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>"
          using A1 A3 sorry
        have "domRELAT-1K1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
          using trees_4_th_24 sorry
        thus "x inHIDDENR3 FinTreesTREES-3K5 D1"
          using A4 A5 trees_3_def_8 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 p1 c=TARSKIR1 FinTreesTREES-3K5 D1"
        using tarski_def_3 sorry
    qed
    then have "p1 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D1"
      using finseq_1_def_4 sorry
    thus " not ( for p1 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D1 holds  not ((domFINSEQ-1K5 p1 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds  not (i inTARSKIR2 domFINSEQ-1K5 p & ( for T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  not (T =FUNCT-1R1 p .FUNCT-1K1 i & p1 .FUNCT-1K1 i =FUNCT-1R1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>))))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d1 -treeTREES-4K8\<^bsub>(D1)\<^esub> p1))"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_4_th_32:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  ex p2 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D2 st (domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) st T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K8\<^bsub>(D2)\<^esub> p2"
proof-
  have " for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D1 holds  for d2 be ElementSUBSET-1M1-of D2 holds  for p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  not ( for p2 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D2 holds  not ((domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds  not (i inTARSKIR2 domFINSEQ-1K5 p & ( for T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  not (T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>))))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K8\<^bsub>(D2)\<^esub> p2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :])"
    obtain p2 where
      [ty]:"p2 be FinSequenceFINSEQ-1M3-of TreesTREES-3K4 D2" and 
      A1: "domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies ( ex T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) st T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>))"and A2: "([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K4 p2"
      using trees_4_th_30 sorry
    have "rngFUNCT-1K2 p2 c=TARSKIR1 FinTreesTREES-3K5 D2"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p2 implies x inHIDDENR3 FinTreesTREES-3K5 D2"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 p2"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "y inHIDDENR3 domFINSEQ-1K5 p2"and A4: "x =HIDDENR1 p2 .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"y be NatNAT-1M1"
          using A3 sorry
        obtain T where
          [ty]:"T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :])" and 
          "T =FUNCT-1R1 p .FUNCT-1K1 y"and A5: "p2 .FUNCT-1K1 y =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>"
          using A1 A3 sorry
        have "domRELAT-1K1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
          using trees_4_th_24 sorry
        thus "x inHIDDENR3 FinTreesTREES-3K5 D2"
          using A4 A5 trees_3_def_8 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 p2 c=TARSKIR1 FinTreesTREES-3K5 D2"
        using tarski_def_3 sorry
    qed
    then have "p2 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D2"
      using finseq_1_def_4 sorry
    thus " not ( for p2 be FinSequenceFINSEQ-1M3-of FinTreesTREES-3K5 D2 holds  not ((domFINSEQ-1K5 p2 =XBOOLE-0R4 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds  not (i inTARSKIR2 domFINSEQ-1K5 p & ( for T be ElementSUBSET-1M1-of FinTreesTREES-3K5 ([:ZFMISC-1K2 D1,D2 :]) holds  not (T =FUNCT-1R1 p .FUNCT-1K1 i & p2 .FUNCT-1K1 i =FUNCT-1R1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub>))))) & ([DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> d1,d2 ] -treeTREES-4K8\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> p)`2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-4R1 d2 -treeTREES-4K8\<^bsub>(D2)\<^esub> p2))"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
