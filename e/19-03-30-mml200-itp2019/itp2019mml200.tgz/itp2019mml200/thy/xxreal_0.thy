theory xxreal_0
  imports arytm_0 xregular
begin
(*begin*)
mlemma xxreal_0_lm_1:
" not REALNUMBERSK2 inTARSKIR2 REALNUMBERSK2"
   sorry

mdef xxreal_0_def_1 ("ext-realXXREAL-0V1" 70 ) where
"attr ext-realXXREAL-0V1 for objectHIDDENM1 means
  (\<lambda>x. x inHIDDENR3 ExtREALNUMBERSK7)"..

mtheorem xxreal_0_cl_1:
"cluster ext-realXXREAL-0V1 for objectHIDDENM1"
proof
(*existence*)
  show " ex it be objectHIDDENM1 st it be ext-realXXREAL-0V1"
  proof-
    have " ex tVar1 be objectHIDDENM1 st tVar1 be ext-realXXREAL-0V1"
    proof-
      show " ex tVar1 be objectHIDDENM1 st tVar1 be ext-realXXREAL-0V1"
      proof(rule bexI[of _ "0NUMBERSK6"])
        have Cut47: "NATNUMBERSK1 c=TARSKIR1 ExtREALNUMBERSK7"
          using numbers_th_19 numbers_th_31 sorry
        have "0NUMBERSK6 inTARSKIR2 ExtREALNUMBERSK7"
        proof-
          show "0NUMBERSK6 inTARSKIR2 ExtREALNUMBERSK7"
            using Cut47 sorry
        qed
        thus "0NUMBERSK6 be ext-realXXREAL-0V1"
          using xxreal_0_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_0_cl_2:
"cluster ext-realXXREAL-0V1 for numberORDINAL1M2"
proof
(*existence*)
  show " ex it be numberORDINAL1M2 st it be ext-realXXREAL-0V1"
  proof-
    have " ex tVar2 be numberORDINAL1M2 st tVar2 be ext-realXXREAL-0V1"
    proof-
      show " ex tVar2 be numberORDINAL1M2 st tVar2 be ext-realXXREAL-0V1"
      proof(rule bexI[of _ "0NUMBERSK6"])
        have Cut54: "NATNUMBERSK1 c=TARSKIR1 ExtREALNUMBERSK7"
          using numbers_th_19 numbers_th_31 sorry
        have "0NUMBERSK6 inTARSKIR2 ExtREALNUMBERSK7"
        proof-
          show "0NUMBERSK6 inTARSKIR2 ExtREALNUMBERSK7"
            using Cut54 sorry
        qed
        thus "0NUMBERSK6 be ext-realXXREAL-0V1"
          using xxreal_0_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_0_cl_3:
"cluster note-that ext-realXXREAL-0V1 for ElementSUBSET-1M1-of ExtREALNUMBERSK7"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of ExtREALNUMBERSK7 holds it be ext-realXXREAL-0V1"
     sorry
qed "sorry"

syntax XXREAL_0M1 :: "Ty" ("ExtRealXXREAL-0M1" 70)
translations "ExtRealXXREAL-0M1" \<rightharpoonup> "ext-realXXREAL-0V1\<bar>NumberORDINAL1M1"

mtheorem xxreal_0_sethood_1:
"cluster sethood of ExtRealXXREAL-0M1"
proof
(*sethood*)
  show " ex cover be setHIDDENM2 st  for it be ExtRealXXREAL-0M1 holds it inHIDDENR3 cover"
  proof-
    have " ex tVar3 be setHIDDENM2 st  for VarFor1 be ExtRealXXREAL-0M1 holds VarFor1 inHIDDENR3 tVar3"
    proof-
      show " ex tVar3 be setHIDDENM2 st  for VarFor1 be ExtRealXXREAL-0M1 holds VarFor1 inHIDDENR3 tVar3"
      proof(rule bexI[of _ "ExtREALNUMBERSK7"])
        show " for VarFor1 be ExtRealXXREAL-0M1 holds VarFor1 inHIDDENR3 ExtREALNUMBERSK7"
          using xxreal_0_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef xxreal_0_def_2 ("+inftyXXREAL-0K1" 300 ) where
"func +inftyXXREAL-0K1 \<rightarrow> objectHIDDENM1 equals
  REALNUMBERSK2"
proof-
  (*coherence*)
    show "REALNUMBERSK2 be objectHIDDENM1"
       sorry
qed "sorry"

mdef xxreal_0_def_3 ("-inftyXXREAL-0K2" 300 ) where
"func -inftyXXREAL-0K2 \<rightarrow> objectHIDDENM1 equals
  [TARSKIK4 0NUMBERSK6,REALNUMBERSK2 ]"
proof-
  (*coherence*)
    show "[TARSKIK4 0NUMBERSK6,REALNUMBERSK2 ] be objectHIDDENM1"
       sorry
qed "sorry"

abbreviation(input) XXREAL_0K3("ExtREALXXREAL-0K3" 164) where
  "ExtREALXXREAL-0K3 \<equiv> ExtREALNUMBERSK7"

mtheorem xxreal_0_def_4:
"redefine func ExtREALXXREAL-0K3 \<rightarrow> setHIDDENM2 equals
  REALNUMBERSK2 \\/XBOOLE-0K2 {TARSKIK2 +inftyXXREAL-0K1,-inftyXXREAL-0K2 }"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 ExtREALXXREAL-0K3 iff it =HIDDENR1 REALNUMBERSK2 \\/XBOOLE-0K2 {TARSKIK2 +inftyXXREAL-0K1,-inftyXXREAL-0K2 }"
     sorry
qed "sorry"

mtheorem xxreal_0_cl_4:
"cluster +inftyXXREAL-0K1 as-term-is ext-realXXREAL-0V1"
proof
(*coherence*)
  show "+inftyXXREAL-0K1 be ext-realXXREAL-0V1"
  proof-
    have "+inftyXXREAL-0K1 inHIDDENR3 {TARSKIK2 REALNUMBERSK2,[TARSKIK4 0NUMBERSK6,REALNUMBERSK2 ] }"
      using tarski_def_2 sorry
    then have "+inftyXXREAL-0K1 inHIDDENR3 ExtREALXXREAL-0K3"
      using xboole_0_def_3 sorry
    thus "+inftyXXREAL-0K1 be ext-realXXREAL-0V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_0_cl_5:
"cluster -inftyXXREAL-0K2 as-term-is ext-realXXREAL-0V1"
proof
(*coherence*)
  show "-inftyXXREAL-0K2 be ext-realXXREAL-0V1"
  proof-
    have "-inftyXXREAL-0K2 inHIDDENR3 {TARSKIK2 REALNUMBERSK2,[TARSKIK4 0NUMBERSK6,REALNUMBERSK2 ] }"
      using tarski_def_2 sorry
    then have "-inftyXXREAL-0K2 inHIDDENR3 ExtREALXXREAL-0K3"
      using xboole_0_def_3 sorry
    thus "-inftyXXREAL-0K2 be ext-realXXREAL-0V1"
       sorry
  qed
qed "sorry"

mdef xxreal_0_def_5 (" _ <=XXREAL-0R1  _ " [50,50]50 ) where
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"pred x <=XXREAL-0R1 y means
   ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9 if x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2,
   ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9 if x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] otherwise (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1"
proof-
  (*consistency*)
    show "(x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) & (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) iff ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))"
      using arytm_0_th_5 xboole_0_th_3 sorry
qed "sorry"

mtheorem XXREAL_0R1_reflexivity:
" for y be ExtRealXXREAL-0M1 holds y <=XXREAL-0R1 y"
proof-
  have " for y be ExtRealXXREAL-0M1 holds (y inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)) & ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) & ( not (y inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (y inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or y =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1))"
  proof-
    have " for x be ExtRealXXREAL-0M1 holds  not (((x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)) & (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))) & ( not (x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1)) implies  not  True "
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume A1: " not (((x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)) & (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))) & ( not (x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1))"
      have "x inHIDDENR3 ExtREALXXREAL-0K3"
        using xxreal_0_def_1 sorry
      then have A2: "x inHIDDENR3 (REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])\\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } or x inHIDDENR3 {TARSKIK2 +inftyXXREAL-0K1,-inftyXXREAL-0K2 }"
        using xboole_0_def_3 sorry
      show " not  True "
      proof-
        have cases: "(x inHIDDENR3 REAL+ARYTM-2K2 &  not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) or x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] &  not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) or  not ( not x inHIDDENR3 REAL+ARYTM-2K2 &  not x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1)"
          using A1 sorry
        have case1: "x inHIDDENR3 REAL+ARYTM-2K2 &  not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) implies  not  True "
        proof(rule impMI ,rule impI)
          assume A3: "x inHIDDENR3 REAL+ARYTM-2K2"
            and A4: " not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)"
          obtain x9 where 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x"
            using A3 sorry
          have " not x9 <='ARYTM-2R1 x9"
            using A4 sorry
          thus " not  True "
             sorry
        qed
        have case2: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] &  not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9) implies  not  True "
        proof(rule impMI ,rule impI)
          assume A5: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            and A6: " not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)"
          obtain z x9 where
            [ty]:"z be objectHIDDENM1" "x9 be objectHIDDENM1" and 
            A7: "z inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A8: "x9 inHIDDENR3 REAL+ARYTM-2K2"and A9: "x =HIDDENR1 [TARSKIK4 z,x9 ]"
            using A5 zfmisc_1_th_84 sorry
          have 
            [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
            using A8 sorry
          have "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"
            using A7 A9 tarski_def_1 sorry
          then have " not x9 <='ARYTM-2R1 x9"
            using A6 sorry
          thus " not  True "
             sorry
        qed
        have case3: " not ( not x inHIDDENR3 REAL+ARYTM-2K2 &  not x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1) implies  not  True "
        proof(rule impI)
          assume " not ( not x inHIDDENR3 REAL+ARYTM-2K2 &  not x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (x inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1)"
          thus " not  True "
            using A2 tarski_def_2 xboole_0_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using xxreal_0_def_5 sorry
qed

mtheorem XXREAL_0R1_connectedness:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not x <=XXREAL-0R1 y implies y <=XXREAL-0R1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not ((x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)) & ((x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) & ( not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1))) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)) & ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) & ( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or y =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1))"
  proof-
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not (((x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)) & (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))) & ( not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1)) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2 implies ( ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 y9 & x =HIDDENR1 x9) & y9 <='ARYTM-2R1 x9)) & ( not ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))) &  not (((( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not y =HIDDENR1 -inftyXXREAL-0K2) &  not x =HIDDENR1 +inftyXXREAL-0K1))"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume A10: " not (((x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2 implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)) & (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))) & ( not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1))"
      have "x inHIDDENR3 ExtREALXXREAL-0K3"
        using xxreal_0_def_1 sorry
      then have A11: "x inHIDDENR3 (REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])\\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } or x inHIDDENR3 {TARSKIK2 +inftyXXREAL-0K1,-inftyXXREAL-0K2 }"
        using xboole_0_def_3 sorry
      have "y inHIDDENR3 ExtREALXXREAL-0K3"
        using xxreal_0_def_1 sorry
      then have A12: "y inHIDDENR3 (REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])\\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } or y inHIDDENR3 {TARSKIK2 +inftyXXREAL-0K1,-inftyXXREAL-0K2 }"
        using xboole_0_def_3 sorry
      show "(y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2 implies ( ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 y9 & x =HIDDENR1 x9) & y9 <='ARYTM-2R1 x9)) & ( not ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))) &  not (((( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not y =HIDDENR1 -inftyXXREAL-0K2) &  not x =HIDDENR1 +inftyXXREAL-0K1))"
      proof-
        have cases: "((x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) or (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) or  not ( not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1)"
          using A10 sorry
        have case1: "(x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2 implies ( ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 y9 & x =HIDDENR1 x9) & y9 <='ARYTM-2R1 x9)) & ( not ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))) &  not (((( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not y =HIDDENR1 -inftyXXREAL-0K2) &  not x =HIDDENR1 +inftyXXREAL-0K1))"
        proof(rule impMI ,rule impI,rule conjMI)
          assume A13: "x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2"
            and A14: " not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9)"
          show "y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2 implies ( ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 y9 & x =HIDDENR1 x9) & y9 <='ARYTM-2R1 x9)"
          proof(rule impI)
            assume "y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2"
            then obtain x9 y9 where 
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x" and
              [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = y"
               sorry
            show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 y9 & x =HIDDENR1 x9) & y9 <='ARYTM-2R1 x9"
            proof(rule bexI[of _ "y9"])
              show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 y9 & x =HIDDENR1 x9) & y9 <='ARYTM-2R1 x9"
              proof(rule bexI[of _ "x9"],rule conjMI)
                show "y =HIDDENR1 y9 & x =HIDDENR1 x9"
                   sorry
                show "y9 <='ARYTM-2R1 x9"
                  using A14 sorry
              qed "sorry"
            qed "sorry"
          qed
          show " not ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9))) &  not (((( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not y =HIDDENR1 -inftyXXREAL-0K2) &  not x =HIDDENR1 +inftyXXREAL-0K1)"
            using A13 arytm_0_th_5 xboole_0_th_3 sorry
        qed
        have case2: "(x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9) implies ( not ((y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9))) &  not ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)))) &  not (((( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not y =HIDDENR1 -inftyXXREAL-0K2) &  not x =HIDDENR1 +inftyXXREAL-0K1)"
        proof(rule impMI ,rule impI)
          assume A15: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            and A16: " not ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)"
          have "y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]) & x9 <='ARYTM-2R1 y9))"
          proof(rule impI,rule impI)
            assume "y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            then obtain z y9 where
              [ty]:"z be objectHIDDENM1" "y9 be objectHIDDENM1" and 
              A17: "z inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A18: "y9 inHIDDENR3 REAL+ARYTM-2K2"and A19: "y =HIDDENR1 [TARSKIK4 z,y9 ]"
              using zfmisc_1_th_84 sorry
            have A20: "z =HIDDENR1 0NUMBERSK6"
              using A17 tarski_def_1 sorry
            assume "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
            then obtain z x9 where
              [ty]:"z be objectHIDDENM1" "x9 be objectHIDDENM1" and 
              A21: "z inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A22: "x9 inHIDDENR3 REAL+ARYTM-2K2"and A23: "x =HIDDENR1 [TARSKIK4 z,x9 ]"
              using zfmisc_1_th_84 sorry
            have 
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and
              [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
              using A18 A22 sorry
            show " ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]) & x9 <='ARYTM-2R1 y9"
            proof(rule bexI[of _ "y9"])
              show " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]) & x9 <='ARYTM-2R1 y9"
              proof(rule bexI[of _ "x9"],rule conjMI)
                show "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"
                  using A17 A19 A21 A23 tarski_def_1 sorry
                have "z =HIDDENR1 0NUMBERSK6"
                  using A21 tarski_def_1 sorry
                thus "x9 <='ARYTM-2R1 y9"
                  using A16 A19 A20 A23 sorry
              qed "sorry"
            qed "sorry"
          qed
          thus "( not ((y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9))) &  not ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)))) &  not (((( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not y =HIDDENR1 -inftyXXREAL-0K2) &  not x =HIDDENR1 +inftyXXREAL-0K1)"
            using A15 arytm_0_th_5 xboole_0_th_3 sorry
        qed
        have case3: " not ( not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1) implies ( not ((y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9))) &  not ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)))) &  not (((( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not y =HIDDENR1 -inftyXXREAL-0K2) &  not x =HIDDENR1 +inftyXXREAL-0K1)"
        proof(rule impI)
          assume " not ( not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 REAL+ARYTM-2K2) &  not (x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or x =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1)"
          thus "( not ((y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 x9 & x =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9))) &  not ((y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((y =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & x =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)))) &  not (((( not (y inHIDDENR3 REAL+ARYTM-2K2 & x inHIDDENR3 REAL+ARYTM-2K2) &  not (y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (x inHIDDENR3 REAL+ARYTM-2K2 & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not y =HIDDENR1 -inftyXXREAL-0K2) &  not x =HIDDENR1 +inftyXXREAL-0K1)"
            using A11 A12 tarski_def_2 xboole_0_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using xxreal_0_def_5 sorry
qed

reserve a, b, c, d for "ExtRealXXREAL-0M1"
abbreviation(input) XXREAL_0R2(" _ >=XXREAL-0R2  _ " [50,50]50) where
  "b >=XXREAL-0R2 a \<equiv> a <=XXREAL-0R1 b"

syntax XXREAL_0R3 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ <XXREAL-0R3  _ " [50,50]50)
translations "b <XXREAL-0R3 a" \<rightharpoonup> " not a <=XXREAL-0R1 b"

syntax XXREAL_0R4 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ >XXREAL-0R4  _ " [50,50]50)
translations "a >XXREAL-0R4 b" \<rightharpoonup> " not a <=XXREAL-0R1 b"

mlemma xxreal_0_lm_2:
"0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
  using numbers_th_19 sorry

mlemma xxreal_0_lm_3:
"+inftyXXREAL-0K1 <>HIDDENR2 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ]"
proof-
  have "+inftyXXREAL-0K1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] implies  False "
  proof(rule impI)
    assume "+inftyXXREAL-0K1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ]"
    then have "+inftyXXREAL-0K1 =HIDDENR1 {TARSKIK2 {TARSKIK1 0NUMBERSK6 },{TARSKIK1 0NUMBERSK6 } }"
      using enumset1_th_29 sorry
    also have "... = {TARSKIK1 {TARSKIK1 0NUMBERSK6 } }"
      using enumset1_th_29 sorry
    finally have "+inftyXXREAL-0K1 =HIDDENR1 {TARSKIK1 {TARSKIK1 0NUMBERSK6 } }"
       sorry
    thus " False "
      using tarski_def_1 xxreal_0_lm_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma xxreal_0_lm_4:
" not +inftyXXREAL-0K1 inHIDDENR3 REAL+ARYTM-2K2"
  using arytm_0_th_1 ordinal1_th_5 sorry

mlemma xxreal_0_lm_5:
" not -inftyXXREAL-0K2 inHIDDENR3 REAL+ARYTM-2K2"
proof-
  have "{TARSKIK2 0NUMBERSK6,REALNUMBERSK2 } inTARSKIR2 {TARSKIK2 {TARSKIK2 0NUMBERSK6,REALNUMBERSK2 },{TARSKIK1 0NUMBERSK6 } } & REALNUMBERSK2 inTARSKIR2 {TARSKIK2 0NUMBERSK6,REALNUMBERSK2 }"
    using tarski_def_2 sorry
  thus " not -inftyXXREAL-0K2 inHIDDENR3 REAL+ARYTM-2K2"
    using arytm_0_th_1 xregular_th_7 sorry
qed

mlemma xxreal_0_lm_6:
" not +inftyXXREAL-0K1 inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
proof-
  have "+inftyXXREAL-0K1 inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  False "
  proof(rule impI)
    assume "+inftyXXREAL-0K1 inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
    then have "+inftyXXREAL-0K1 inHIDDENR3 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      using xboole_0_def_3 sorry
    then have "+inftyXXREAL-0K1 inHIDDENR3 REALNUMBERSK2"
      using xxreal_0_lm_3 zfmisc_1_th_56 sorry
    thus " False "
      using xxreal_0_lm_1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma xxreal_0_lm_7:
" not -inftyXXREAL-0K2 inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
proof-
  have "-inftyXXREAL-0K2 inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  False "
  proof(rule impI)
    assume "-inftyXXREAL-0K2 inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
    then have "REALNUMBERSK2 inTARSKIR2 REAL+ARYTM-2K2"
      using zfmisc_1_th_87 sorry
    thus " False "
      using arytm_0_th_1 ordinal1_th_5 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma xxreal_0_lm_8:
"-inftyXXREAL-0K2 <XXREAL-0R3 +inftyXXREAL-0K1"
proof-
  have " not -inftyXXREAL-0K2 <XXREAL-0R3 +inftyXXREAL-0K1"
  proof-
    have "-inftyXXREAL-0K2 <>HIDDENR2 +inftyXXREAL-0K1"
      using tarski_def_2 xxreal_0_lm_2 sorry
    thus " not -inftyXXREAL-0K2 <XXREAL-0R3 +inftyXXREAL-0K1"
      using xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_1:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 b & b <=XXREAL-0R1 a implies a =HIDDENR1 b"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be ExtRealXXREAL-0M1"
  fix b assume [ty]: "b be ExtRealXXREAL-0M1"
  assume A1: "a <=XXREAL-0R1 b"
    and A2: "b <=XXREAL-0R1 a"
  show "a =HIDDENR1 b"
  proof-
    have cases: "((((a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2 or a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or b inHIDDENR3 REAL+ARYTM-2K2 & a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or (a =HIDDENR1 -inftyXXREAL-0K2 or a =HIDDENR1 +inftyXXREAL-0K1) & (b =HIDDENR1 -inftyXXREAL-0K2 or b =HIDDENR1 +inftyXXREAL-0K1)) or ( not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2) &  not (a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & ( not (b inHIDDENR3 REAL+ARYTM-2K2 & a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]))"
       sorry
    have case1: "a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2 implies a =HIDDENR1 b"
    proof(rule impI)
      assume "a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2"
      then have "( ex a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (a =HIDDENR1 a9 & b =HIDDENR1 b9) & a9 <='ARYTM-2R1 b9) & ( ex b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex a99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (b =HIDDENR1 b99 & a =HIDDENR1 a99) & b99 <='ARYTM-2R1 a99)"
        using A1 A2 xxreal_0_def_5 sorry
      thus "a =HIDDENR1 b"
        using arytm_1_th_4 sorry
    qed
    have case2: "a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies a =HIDDENR1 b"
    proof(rule impI)
      assume A3: "a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      then have " not b inHIDDENR3 REAL+ARYTM-2K2 &  not a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using arytm_0_th_5 xboole_0_th_3 sorry
      thus "a =HIDDENR1 b"
        using A1 A3 xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_6 sorry
    qed
    have case3: "b inHIDDENR3 REAL+ARYTM-2K2 & a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies a =HIDDENR1 b"
    proof(rule impI)
      assume A4: "b inHIDDENR3 REAL+ARYTM-2K2 & a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      then have " not a inHIDDENR3 REAL+ARYTM-2K2 &  not b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using arytm_0_th_5 xboole_0_th_3 sorry
      thus "a =HIDDENR1 b"
        using A2 A4 xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_6 sorry
    qed
    have case4: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies a =HIDDENR1 b"
    proof(rule impI)
      assume A5: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      obtain a9 b9 where
        [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A6: "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 ] & b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b9 ]"and A7: "b9 <='ARYTM-2R1 a9"
        using A1 A5 xxreal_0_def_5 sorry
      obtain b99 a99 where
        [ty]:"b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "a99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A8: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b99 ] & a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a99 ]"and A9: "a99 <='ARYTM-2R1 b99"
        using A2 A5 xxreal_0_def_5 sorry
      have "a9 =XBOOLE-0R4 a99 & b9 =XBOOLE-0R4 b99"
        using A6 A8 xtuple_0_th_1 sorry
      thus "a =HIDDENR1 b"
        using A7 A8 A9 arytm_1_th_4 sorry
    qed
    have case5: "(a =HIDDENR1 -inftyXXREAL-0K2 or a =HIDDENR1 +inftyXXREAL-0K1) & (b =HIDDENR1 -inftyXXREAL-0K2 or b =HIDDENR1 +inftyXXREAL-0K1) implies a =HIDDENR1 b"
    proof(rule impI)
      assume "(a =HIDDENR1 -inftyXXREAL-0K2 or a =HIDDENR1 +inftyXXREAL-0K1) & (b =HIDDENR1 -inftyXXREAL-0K2 or b =HIDDENR1 +inftyXXREAL-0K1)"
      thus "a =HIDDENR1 b"
        using A1 A2 xxreal_0_lm_8 sorry
    qed
    have case6: "( not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2) &  not (a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & ( not (b inHIDDENR3 REAL+ARYTM-2K2 & a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) implies a =HIDDENR1 b"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A10: " not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2) &  not (a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        and A11: " not (b inHIDDENR3 REAL+ARYTM-2K2 & a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        and A12: " not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
      have "a =HIDDENR1 -inftyXXREAL-0K2 or b =HIDDENR1 +inftyXXREAL-0K1"
        using A1 A10 A11 xxreal_0_def_5 sorry
      thus "a =HIDDENR1 b"
        using A2 A10 A12 xxreal_0_def_5 xxreal_0_lm_8 sorry
    qed
    show " ?thesis "
      using cases case1 case2 case3 case4 case5 case6 sorry
  qed
qed "sorry"

mlemma xxreal_0_lm_9:
" for a be ExtRealXXREAL-0M1 holds -inftyXXREAL-0K2 >=XXREAL-0R2 a implies a =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  not (-inftyXXREAL-0K2 >=XXREAL-0R2 a &  not a =HIDDENR1 -inftyXXREAL-0K2)"
  proof(rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    have "a >=XXREAL-0R2 -inftyXXREAL-0K2"
      using xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_7 sorry
    thus " not (-inftyXXREAL-0K2 >=XXREAL-0R2 a &  not a =HIDDENR1 -inftyXXREAL-0K2)"
      using xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_0_lm_10:
" for a be ExtRealXXREAL-0M1 holds +inftyXXREAL-0K1 <=XXREAL-0R1 a implies a =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  not (+inftyXXREAL-0K1 <=XXREAL-0R1 a &  not a =HIDDENR1 +inftyXXREAL-0K1)"
  proof(rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    have "a <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_def_5 xxreal_0_lm_4 xxreal_0_lm_6 sorry
    thus " not (+inftyXXREAL-0K1 <=XXREAL-0R1 a &  not a =HIDDENR1 +inftyXXREAL-0K1)"
      using xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_2:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 b & b <=XXREAL-0R1 c implies a <=XXREAL-0R1 c"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be ExtRealXXREAL-0M1"
  fix b assume [ty]: "b be ExtRealXXREAL-0M1"
  fix c assume [ty]: "c be ExtRealXXREAL-0M1"
  assume A1: "a <=XXREAL-0R1 b"
    and A2: "b <=XXREAL-0R1 c"
  show "a <=XXREAL-0R1 c"
  proof-
    have cases: "((((a inHIDDENR3 REAL+ARYTM-2K2 & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 REAL+ARYTM-2K2) or a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 REAL+ARYTM-2K2) or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or  not ((a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2) & c inHIDDENR3 REAL+ARYTM-2K2) & ( not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( not (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( not (a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 REAL+ARYTM-2K2) &  not ((a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]))))"
       sorry
    have case1: "a inHIDDENR3 REAL+ARYTM-2K2 & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 REAL+ARYTM-2K2) implies a <=XXREAL-0R1 c"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A3: "a inHIDDENR3 REAL+ARYTM-2K2"
        and A4: "b inHIDDENR3 REAL+ARYTM-2K2"
        and A5: "c inHIDDENR3 REAL+ARYTM-2K2"
      obtain b99 c9 where
        [ty]:"b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A6: "b =HIDDENR1 b99"and A7: "c =HIDDENR1 c9"and A8: "b99 <='ARYTM-2R1 c9"
        using A2 A4 A5 xxreal_0_def_5 sorry
      obtain a9 b9 where
        [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A9: "a =HIDDENR1 a9"and A10: "b =HIDDENR1 b9 & a9 <='ARYTM-2R1 b9"
        using A1 A3 A4 xxreal_0_def_5 sorry
      have "a9 <='ARYTM-2R1 c9"
        using A10 A6 A8 arytm_1_th_3 sorry
      thus "a <=XXREAL-0R1 c"
        using A5 A9 A7 xxreal_0_def_5 sorry
    qed
    have case2: "a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies a <=XXREAL-0R1 c"
    proof(rule impI)
      assume A11: "a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      then have " not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2) &  not (a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using arytm_0_th_5 xboole_0_th_3 sorry
      thus "a <=XXREAL-0R1 c"
        using A1 A11 xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_6 sorry
    qed
    have case3: "b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies a <=XXREAL-0R1 c"
    proof(rule impI)
      assume A12: "b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      then have " not (c inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2) &  not (c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using arytm_0_th_5 xboole_0_th_3 sorry
      thus "a <=XXREAL-0R1 c"
        using A2 A12 xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_6 sorry
    qed
    have case4: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 REAL+ARYTM-2K2 implies a <=XXREAL-0R1 c"
    proof(rule impI)
      assume A13: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 REAL+ARYTM-2K2"
      have " not (a inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 REAL+ARYTM-2K2) &  not (a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using A13 arytm_0_th_5 xboole_0_th_3 sorry
      thus "a <=XXREAL-0R1 c"
        using A13 xxreal_0_def_5 sorry
    qed
    have case5: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies a <=XXREAL-0R1 c"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A14: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A15: "b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A16: "c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      obtain b99 c9 where
        [ty]:"b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A17: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b99 ]"and A18: "c =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 ]"and A19: "c9 <='ARYTM-2R1 b99"
        using A2 A15 A16 xxreal_0_def_5 sorry
      obtain a9 b9 where
        [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A20: "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 ]"and A21: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b9 ]"and A22: "b9 <='ARYTM-2R1 a9"
        using A1 A14 A15 xxreal_0_def_5 sorry
      have "b9 =XBOOLE-0R4 b99"
        using A21 A17 xtuple_0_th_1 sorry
      then have "c9 <='ARYTM-2R1 a9"
        using A22 A19 arytm_1_th_3 sorry
      thus "a <=XXREAL-0R1 c"
        using A14 A16 A20 A18 xxreal_0_def_5 sorry
    qed
    have case6: " not ((a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2) & c inHIDDENR3 REAL+ARYTM-2K2) & ( not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( not (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( not (a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 REAL+ARYTM-2K2) &  not ((a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])))) implies a <=XXREAL-0R1 c"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
      assume A23: " not ((a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2) & c inHIDDENR3 REAL+ARYTM-2K2)"
        and A24: " not (a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        and A25: " not (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        and A26: " not (a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 REAL+ARYTM-2K2)"
        and A27: " not ((a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
      have A28: "b =HIDDENR1 +inftyXXREAL-0K1 implies c =HIDDENR1 +inftyXXREAL-0K1"
        using A2 xxreal_0_lm_10 sorry
      have A29: "b =HIDDENR1 -inftyXXREAL-0K2 implies a =HIDDENR1 -inftyXXREAL-0K2"
        using A1 xxreal_0_lm_9 sorry
      have "((a =HIDDENR1 -inftyXXREAL-0K2 or b =HIDDENR1 +inftyXXREAL-0K1) or b =HIDDENR1 -inftyXXREAL-0K2) or c =HIDDENR1 +inftyXXREAL-0K1"
        using A1 A2 A23 A25 A26 A27 xxreal_0_def_5 sorry
      thus "a <=XXREAL-0R1 c"
        using A1 A2 A23 A24 A25 A27 A28 A29 xxreal_0_def_5 sorry
    qed
    show " ?thesis "
      using cases case1 case2 case3 case4 case5 case6 sorry
  qed
qed "sorry"

mtheorem xxreal_0_th_3:
" for a be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 +inftyXXREAL-0K1"
  using xxreal_0_def_5 xxreal_0_lm_4 xxreal_0_lm_6 sorry

mtheorem xxreal_0_th_4:
" for a be ExtRealXXREAL-0M1 holds +inftyXXREAL-0K1 <=XXREAL-0R1 a implies a =HIDDENR1 +inftyXXREAL-0K1"
  using xxreal_0_lm_10 sorry

mtheorem xxreal_0_th_5:
" for a be ExtRealXXREAL-0M1 holds a >=XXREAL-0R2 -inftyXXREAL-0K2"
  using xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_7 sorry

mtheorem xxreal_0_th_6:
" for a be ExtRealXXREAL-0M1 holds -inftyXXREAL-0K2 >=XXREAL-0R2 a implies a =HIDDENR1 -inftyXXREAL-0K2"
  using xxreal_0_lm_9 sorry

mtheorem xxreal_0_th_7:
"-inftyXXREAL-0K2 <XXREAL-0R3 +inftyXXREAL-0K1"
  using xxreal_0_lm_8 sorry

mtheorem xxreal_0_th_8:
" not +inftyXXREAL-0K1 inHIDDENR3 REALNUMBERSK2"
  using xxreal_0_lm_1 sorry

mlemma xxreal_0_lm_11:
" for a be ExtRealXXREAL-0M1 holds (a inHIDDENR3 REALNUMBERSK2 or a =HIDDENR1 +inftyXXREAL-0K1) or a =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  not (( not a inHIDDENR3 REALNUMBERSK2 &  not a =HIDDENR1 +inftyXXREAL-0K1) &  not a =HIDDENR1 -inftyXXREAL-0K2)"
  proof(rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    have "a inHIDDENR3 ExtREALXXREAL-0K3"
      using xxreal_0_def_1 sorry
    then have "a inHIDDENR3 REALNUMBERSK2 or a inHIDDENR3 {TARSKIK2 +inftyXXREAL-0K1,-inftyXXREAL-0K2 }"
      using xboole_0_def_3 sorry
    thus " not (( not a inHIDDENR3 REALNUMBERSK2 &  not a =HIDDENR1 +inftyXXREAL-0K1) &  not a =HIDDENR1 -inftyXXREAL-0K2)"
      using tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_9:
" for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 REALNUMBERSK2 implies +inftyXXREAL-0K1 >XXREAL-0R4 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 REALNUMBERSK2 implies  not +inftyXXREAL-0K1 >XXREAL-0R4 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    assume "a inHIDDENR3 REALNUMBERSK2"
    then have A1: "a <>HIDDENR2 +inftyXXREAL-0K1"
      using xxreal_0_lm_1 sorry
    have "+inftyXXREAL-0K1 >=XXREAL-0R2 a"
      using xxreal_0_def_5 xxreal_0_lm_4 xxreal_0_lm_6 sorry
    thus " not +inftyXXREAL-0K1 >XXREAL-0R4 a"
      using A1 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_10:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds a inHIDDENR3 REALNUMBERSK2 & b >=XXREAL-0R2 a implies b inHIDDENR3 REALNUMBERSK2 or b =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds a inHIDDENR3 REALNUMBERSK2 & b >=XXREAL-0R2 a implies ( not b inHIDDENR3 REALNUMBERSK2 implies b =HIDDENR1 +inftyXXREAL-0K1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    assume A1: "a inHIDDENR3 REALNUMBERSK2"
      and A2: "b >=XXREAL-0R2 a"
    assume A3: " not b inHIDDENR3 REALNUMBERSK2"
    have "b =HIDDENR1 -inftyXXREAL-0K2 implies a =HIDDENR1 -inftyXXREAL-0K2"
      using A2 xxreal_0_lm_9 sorry
    thus "b =HIDDENR1 +inftyXXREAL-0K1"
      using A1 A3 xxreal_0_lm_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_11:
" not -inftyXXREAL-0K2 inHIDDENR3 REALNUMBERSK2"
proof-
  have "-inftyXXREAL-0K2 inHIDDENR3 REALNUMBERSK2 implies  False "
  proof(rule impI)
    have A1: "{TARSKIK2 0NUMBERSK6,REALNUMBERSK2 } inTARSKIR2 {TARSKIK2 {TARSKIK2 0NUMBERSK6,REALNUMBERSK2 },{TARSKIK1 0NUMBERSK6 } } & REALNUMBERSK2 inTARSKIR2 {TARSKIK2 0NUMBERSK6,REALNUMBERSK2 }"
      using tarski_def_2 sorry
    assume "-inftyXXREAL-0K2 inHIDDENR3 REALNUMBERSK2"
    thus " False "
      using A1 xregular_th_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_12:
" for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 REALNUMBERSK2 implies -inftyXXREAL-0K2 <XXREAL-0R3 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  not (a inHIDDENR3 REALNUMBERSK2 & -inftyXXREAL-0K2 <XXREAL-0R3 a)"
  proof(rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    have "-inftyXXREAL-0K2 <=XXREAL-0R1 a"
      using xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_7 sorry
    thus " not (a inHIDDENR3 REALNUMBERSK2 & -inftyXXREAL-0K2 <XXREAL-0R3 a)"
      using xxreal_0_th_1 xxreal_0_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_13:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds a inHIDDENR3 REALNUMBERSK2 & b <=XXREAL-0R1 a implies b inHIDDENR3 REALNUMBERSK2 or b =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds a inHIDDENR3 REALNUMBERSK2 & b <=XXREAL-0R1 a implies ( not b inHIDDENR3 REALNUMBERSK2 implies b =HIDDENR1 -inftyXXREAL-0K2)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    assume A1: "a inHIDDENR3 REALNUMBERSK2"
      and A2: "b <=XXREAL-0R1 a"
    assume A3: " not b inHIDDENR3 REALNUMBERSK2"
    have "b =HIDDENR1 +inftyXXREAL-0K1 implies a =HIDDENR1 +inftyXXREAL-0K1"
      using A2 xxreal_0_lm_10 sorry
    thus "b =HIDDENR1 -inftyXXREAL-0K2"
      using A1 A3 xxreal_0_lm_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_14:
" for a be ExtRealXXREAL-0M1 holds (a inHIDDENR3 REALNUMBERSK2 or a =HIDDENR1 +inftyXXREAL-0K1) or a =HIDDENR1 -inftyXXREAL-0K2"
  using xxreal_0_lm_11 sorry

(*begin*)
mtheorem xxreal_0_cl_6:
"cluster naturalORDINAL1V7 also-is ext-realXXREAL-0V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be naturalORDINAL1V7 implies it be ext-realXXREAL-0V1"
    using numbers_th_19 xboole_0_def_3 sorry
qed "sorry"

mdef xxreal_0_def_6 ("positiveXXREAL-0V2" 70 ) where
"attr positiveXXREAL-0V2 for ExtRealXXREAL-0M1 means
  (\<lambda>a. a >XXREAL-0R4 0NUMBERSK6)"..

mdef xxreal_0_def_7 ("negativeXXREAL-0V3" 70 ) where
"attr negativeXXREAL-0V3 for ExtRealXXREAL-0M1 means
  (\<lambda>a. a <XXREAL-0R3 0NUMBERSK6)"..

(*\$CD*)
mtheorem xxreal_0_cl_7:
"cluster positiveXXREAL-0V2 also-is  non negativeXXREAL-0V3\<bar> non zeroORDINAL1V8 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it be positiveXXREAL-0V2 implies it be  non negativeXXREAL-0V3\<bar> non zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem xxreal_0_cl_8:
"cluster  non negativeXXREAL-0V3\<bar> non zeroORDINAL1V8 also-is positiveXXREAL-0V2 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it be  non negativeXXREAL-0V3\<bar> non zeroORDINAL1V8 implies it be positiveXXREAL-0V2"
    using xxreal_0_th_1 sorry
qed "sorry"

mtheorem xxreal_0_cl_9:
"cluster negativeXXREAL-0V3 also-is  non positiveXXREAL-0V2\<bar> non zeroORDINAL1V8 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it be negativeXXREAL-0V3 implies it be  non positiveXXREAL-0V2\<bar> non zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem xxreal_0_cl_10:
"cluster  non positiveXXREAL-0V2\<bar> non zeroORDINAL1V8 also-is negativeXXREAL-0V3 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it be  non positiveXXREAL-0V2\<bar> non zeroORDINAL1V8 implies it be negativeXXREAL-0V3"
     sorry
qed "sorry"

mtheorem xxreal_0_cl_11:
"cluster zeroORDINAL1V8 also-is  non negativeXXREAL-0V3\<bar> non positiveXXREAL-0V2 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it be zeroORDINAL1V8 implies it be  non negativeXXREAL-0V3\<bar> non positiveXXREAL-0V2"
     sorry
qed "sorry"

mtheorem xxreal_0_cl_12:
"cluster  non negativeXXREAL-0V3\<bar> non positiveXXREAL-0V2 also-is zeroORDINAL1V8 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it be  non negativeXXREAL-0V3\<bar> non positiveXXREAL-0V2 implies it be zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem xxreal_0_cl_13:
"cluster +inftyXXREAL-0K1 as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "+inftyXXREAL-0K1 be positiveXXREAL-0V2"
    using xxreal_0_th_9 xxreal_0_lm_2 sorry
qed "sorry"

mtheorem xxreal_0_cl_14:
"cluster -inftyXXREAL-0K2 as-term-is negativeXXREAL-0V3"
proof
(*coherence*)
  show "-inftyXXREAL-0K2 be negativeXXREAL-0V3"
    using xxreal_0_th_12 xxreal_0_lm_2 sorry
qed "sorry"

mtheorem xxreal_0_cl_15:
"cluster positiveXXREAL-0V2 for ExtRealXXREAL-0M1"
proof
(*existence*)
  show " ex it be ExtRealXXREAL-0M1 st it be positiveXXREAL-0V2"
  proof-
    have " ex tVar8 be ExtRealXXREAL-0M1 st tVar8 be positiveXXREAL-0V2"
    proof-
      show " ex tVar8 be ExtRealXXREAL-0M1 st tVar8 be positiveXXREAL-0V2"
      proof(rule bexI[of _ "+inftyXXREAL-0K1"])
        show "+inftyXXREAL-0K1 be positiveXXREAL-0V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_0_cl_16:
"cluster negativeXXREAL-0V3 for ExtRealXXREAL-0M1"
proof
(*existence*)
  show " ex it be ExtRealXXREAL-0M1 st it be negativeXXREAL-0V3"
  proof-
    have " ex tVar9 be ExtRealXXREAL-0M1 st tVar9 be negativeXXREAL-0V3"
    proof-
      show " ex tVar9 be ExtRealXXREAL-0M1 st tVar9 be negativeXXREAL-0V3"
      proof(rule bexI[of _ "-inftyXXREAL-0K2"])
        show "-inftyXXREAL-0K2 be negativeXXREAL-0V3"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_0_cl_17:
"cluster zeroORDINAL1V8 for ExtRealXXREAL-0M1"
proof
(*existence*)
  show " ex it be ExtRealXXREAL-0M1 st it be zeroORDINAL1V8"
  proof-
    have " ex tVar10 be ExtRealXXREAL-0M1 st tVar10 be zeroORDINAL1V8"
    proof-
      obtain z where 
        [ty]:"z be ExtRealXXREAL-0M1" and zDef:"z = 0NUMBERSK6"
         sorry
      show " ex tVar10 be ExtRealXXREAL-0M1 st tVar10 be zeroORDINAL1V8"
      proof(rule bexI[of _ "z"])
        have "z =HIDDENR1 0NUMBERSK6"
        proof-
          show "z =HIDDENR1 0NUMBERSK6"
             sorry
        qed
        thus "z be zeroORDINAL1V8"
          using ordinal1_def_14 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
mdef xxreal_0_def_9 ("minXXREAL-0K4'( _ , _ ')" [0,0]228 ) where
  mlet "a be ExtRealXXREAL-0M1", "b be ExtRealXXREAL-0M1"
"func minXXREAL-0K4(a,b) \<rightarrow> ExtRealXXREAL-0M1 equals
  a if a <=XXREAL-0R1 b otherwise b"
proof-
  (*coherence*)
    show "(a <=XXREAL-0R1 b implies a be ExtRealXXREAL-0M1) & ( not a <=XXREAL-0R1 b implies b be ExtRealXXREAL-0M1)"
       sorry
  (*consistency*)
    show " for it be ExtRealXXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem XXREAL_0K4_commutativity:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,b) =HIDDENR1 minXXREAL-0K4(b,a)"
proof-
  have " for it be ExtRealXXREAL-0M1 holds  for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds it =HIDDENR1 minXXREAL-0K4(a,b) implies it =HIDDENR1 minXXREAL-0K4(b,a)"
  proof-
    have " for it be ExtRealXXREAL-0M1 holds  for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds (a <=XXREAL-0R1 b implies it =HIDDENR1 a) & ( not a <=XXREAL-0R1 b implies it =HIDDENR1 b) implies (b <=XXREAL-0R1 a implies it =HIDDENR1 b) & ( not b <=XXREAL-0R1 a implies it =HIDDENR1 a)"
      using xxreal_0_th_1 sorry
    thus " ?thesis "
      using xxreal_0_def_9 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem XXREAL_0K4_idempotence:
" for b be ExtRealXXREAL-0M1 holds b =HIDDENR1 minXXREAL-0K4(b,b)"
proof-
  have " for b be ExtRealXXREAL-0M1 holds (b <=XXREAL-0R1 b implies it =HIDDENR1 b) & ( not b <=XXREAL-0R1 b implies it =HIDDENR1 b)"
     sorry
  thus " ?thesis "
    using xxreal_0_def_9 sorry
qed

mdef xxreal_0_def_10 ("maxXXREAL-0K5'( _ , _ ')" [0,0]228 ) where
  mlet "a be ExtRealXXREAL-0M1", "b be ExtRealXXREAL-0M1"
"func maxXXREAL-0K5(a,b) \<rightarrow> ExtRealXXREAL-0M1 equals
  a if b <=XXREAL-0R1 a otherwise b"
proof-
  (*coherence*)
    show "(b <=XXREAL-0R1 a implies a be ExtRealXXREAL-0M1) & ( not b <=XXREAL-0R1 a implies b be ExtRealXXREAL-0M1)"
       sorry
  (*consistency*)
    show " for it be ExtRealXXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem XXREAL_0K5_commutativity:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,b) =HIDDENR1 maxXXREAL-0K5(b,a)"
proof-
  have " for it be ExtRealXXREAL-0M1 holds  for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds it =HIDDENR1 maxXXREAL-0K5(a,b) implies it =HIDDENR1 maxXXREAL-0K5(b,a)"
  proof-
    have " for it be ExtRealXXREAL-0M1 holds  for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds (b <=XXREAL-0R1 a implies it =HIDDENR1 a) & ( not b <=XXREAL-0R1 a implies it =HIDDENR1 b) implies (a <=XXREAL-0R1 b implies it =HIDDENR1 b) & ( not a <=XXREAL-0R1 b implies it =HIDDENR1 a)"
      using xxreal_0_th_1 sorry
    thus " ?thesis "
      using xxreal_0_def_10 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem XXREAL_0K5_idempotence:
" for b be ExtRealXXREAL-0M1 holds b =HIDDENR1 maxXXREAL-0K5(b,b)"
proof-
  have " for b be ExtRealXXREAL-0M1 holds (b <=XXREAL-0R1 b implies it =HIDDENR1 b) & ( not b <=XXREAL-0R1 b implies it =HIDDENR1 b)"
     sorry
  thus " ?thesis "
    using xxreal_0_def_10 sorry
qed

mtheorem xxreal_0_th_15:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,b) =HIDDENR1 a or minXXREAL-0K4(a,b) =HIDDENR1 b"
  using xxreal_0_def_9 sorry

mtheorem xxreal_0_th_16:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,b) =HIDDENR1 a or maxXXREAL-0K5(a,b) =HIDDENR1 b"
  using xxreal_0_def_10 sorry

mtheorem xxreal_0_cl_18:
  mlet "a be ExtRealXXREAL-0M1", "b be ExtRealXXREAL-0M1"
"cluster minXXREAL-0K4(a,b) as-term-is ext-realXXREAL-0V1"
proof
(*coherence*)
  show "minXXREAL-0K4(a,b) be ext-realXXREAL-0V1"
     sorry
qed "sorry"

mtheorem xxreal_0_cl_19:
  mlet "a be ExtRealXXREAL-0M1", "b be ExtRealXXREAL-0M1"
"cluster maxXXREAL-0K5(a,b) as-term-is ext-realXXREAL-0V1"
proof
(*coherence*)
  show "maxXXREAL-0K5(a,b) be ext-realXXREAL-0V1"
     sorry
qed "sorry"

mtheorem xxreal_0_th_17:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,b) <=XXREAL-0R1 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,b) <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    have "a <=XXREAL-0R1 b or  not a <=XXREAL-0R1 b"
       sorry
    thus "minXXREAL-0K4(a,b) <=XXREAL-0R1 a"
      using xxreal_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_18:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  for d be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 d implies minXXREAL-0K4(a,c) <=XXREAL-0R1 minXXREAL-0K4(b,d)"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  for d be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 d implies minXXREAL-0K4(a,c) <=XXREAL-0R1 minXXREAL-0K4(b,d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    fix d assume [ty]: "d be ExtRealXXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
      and A2: "c <=XXREAL-0R1 d"
    have "minXXREAL-0K4(a,c) <=XXREAL-0R1 c"
      using xxreal_0_th_17 sorry
    then have A3: "minXXREAL-0K4(a,c) <=XXREAL-0R1 d"
      using A2 xxreal_0_th_2 sorry
    have "minXXREAL-0K4(a,c) <=XXREAL-0R1 a"
      using xxreal_0_th_17 sorry
    then have "minXXREAL-0K4(a,c) <=XXREAL-0R1 b"
      using A1 xxreal_0_th_2 sorry
    thus "minXXREAL-0K4(a,c) <=XXREAL-0R1 minXXREAL-0K4(b,d)"
      using A3 xxreal_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_19:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  for d be ExtRealXXREAL-0M1 holds a <XXREAL-0R3 b & c <XXREAL-0R3 d implies minXXREAL-0K4(a,c) <XXREAL-0R3 minXXREAL-0K4(b,d)"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  for d be ExtRealXXREAL-0M1 holds a <XXREAL-0R3 b & c <XXREAL-0R3 d implies  not minXXREAL-0K4(a,c) <XXREAL-0R3 minXXREAL-0K4(b,d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    fix d assume [ty]: "d be ExtRealXXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
      and A2: "c <XXREAL-0R3 d"
    have "minXXREAL-0K4(a,c) <=XXREAL-0R1 c"
      using xxreal_0_th_17 sorry
    then have A3: "minXXREAL-0K4(a,c) <XXREAL-0R3 d"
      using A2 xxreal_0_th_2 sorry
    have "minXXREAL-0K4(a,c) <=XXREAL-0R1 a"
      using xxreal_0_th_17 sorry
    then have "minXXREAL-0K4(a,c) <XXREAL-0R3 b"
      using A1 xxreal_0_th_2 sorry
    thus " not minXXREAL-0K4(a,c) <XXREAL-0R3 minXXREAL-0K4(b,d)"
      using A3 xxreal_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_20:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 b & a <=XXREAL-0R1 c implies a <=XXREAL-0R1 minXXREAL-0K4(b,c)"
  using xxreal_0_def_9 sorry

mtheorem xxreal_0_th_21:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <XXREAL-0R3 b & a <XXREAL-0R3 c implies a <XXREAL-0R3 minXXREAL-0K4(b,c)"
  using xxreal_0_def_9 sorry

mtheorem xxreal_0_th_22:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 minXXREAL-0K4(b,c) implies a <=XXREAL-0R1 b"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  not (a <=XXREAL-0R1 minXXREAL-0K4(b,c) &  not a <=XXREAL-0R1 b)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    have "minXXREAL-0K4(b,c) <=XXREAL-0R1 b"
      using xxreal_0_th_17 sorry
    thus " not (a <=XXREAL-0R1 minXXREAL-0K4(b,c) &  not a <=XXREAL-0R1 b)"
      using xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_23:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <XXREAL-0R3 minXXREAL-0K4(b,c) implies a <XXREAL-0R3 b"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  not ( not a <XXREAL-0R3 minXXREAL-0K4(b,c) & a <XXREAL-0R3 b)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    have "minXXREAL-0K4(b,c) <=XXREAL-0R1 b"
      using xxreal_0_th_17 sorry
    thus " not ( not a <XXREAL-0R3 minXXREAL-0K4(b,c) & a <XXREAL-0R3 b)"
      using xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_24:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds (c <=XXREAL-0R1 a & c <=XXREAL-0R1 b) & ( for d be ExtRealXXREAL-0M1 holds d <=XXREAL-0R1 a & d <=XXREAL-0R1 b implies d <=XXREAL-0R1 c) implies c =HIDDENR1 minXXREAL-0K4(a,b)"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds (c <=XXREAL-0R1 a & c <=XXREAL-0R1 b) & ( for d be ExtRealXXREAL-0M1 holds d <=XXREAL-0R1 a & d <=XXREAL-0R1 b implies d <=XXREAL-0R1 c) implies c =HIDDENR1 minXXREAL-0K4(a,b)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    assume A1: "c <=XXREAL-0R1 a & c <=XXREAL-0R1 b"
      and A2: " for d be ExtRealXXREAL-0M1 holds d <=XXREAL-0R1 a & d <=XXREAL-0R1 b implies d <=XXREAL-0R1 c"
    have "minXXREAL-0K4(a,b) <=XXREAL-0R1 a & minXXREAL-0K4(a,b) <=XXREAL-0R1 b"
      using xxreal_0_th_17 sorry
    then have A3: "minXXREAL-0K4(a,b) <=XXREAL-0R1 c"
      using A2 sorry
    have "c <=XXREAL-0R1 minXXREAL-0K4(a,b)"
      using A1 xxreal_0_def_9 sorry
    thus "c =HIDDENR1 minXXREAL-0K4(a,b)"
      using A3 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_25:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 maxXXREAL-0K5(a,b)"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 maxXXREAL-0K5(a,b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    have "a <=XXREAL-0R1 b or  not a <=XXREAL-0R1 b"
       sorry
    thus "a <=XXREAL-0R1 maxXXREAL-0K5(a,b)"
      using xxreal_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_26:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  for d be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 d implies maxXXREAL-0K5(a,c) <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  for d be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 d implies maxXXREAL-0K5(a,c) <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    fix d assume [ty]: "d be ExtRealXXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
      and A2: "c <=XXREAL-0R1 d"
    have "d <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
      using xxreal_0_th_25 sorry
    then have A3: "c <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
      using A2 xxreal_0_th_2 sorry
    have "b <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
      using xxreal_0_th_25 sorry
    then have "a <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
      using A1 xxreal_0_th_2 sorry
    thus "maxXXREAL-0K5(a,c) <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
      using A3 xxreal_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_27:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  for d be ExtRealXXREAL-0M1 holds a <XXREAL-0R3 b & c <XXREAL-0R3 d implies maxXXREAL-0K5(a,c) <XXREAL-0R3 maxXXREAL-0K5(b,d)"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  for d be ExtRealXXREAL-0M1 holds a <XXREAL-0R3 b & c <XXREAL-0R3 d implies  not maxXXREAL-0K5(a,c) <XXREAL-0R3 maxXXREAL-0K5(b,d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    fix d assume [ty]: "d be ExtRealXXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
      and A2: "c <XXREAL-0R3 d"
    have "d <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
      using xxreal_0_th_25 sorry
    then have A3: "c <XXREAL-0R3 maxXXREAL-0K5(b,d)"
      using A2 xxreal_0_th_2 sorry
    have "b <=XXREAL-0R1 maxXXREAL-0K5(b,d)"
      using xxreal_0_th_25 sorry
    then have "a <XXREAL-0R3 maxXXREAL-0K5(b,d)"
      using A1 xxreal_0_th_2 sorry
    thus " not maxXXREAL-0K5(a,c) <XXREAL-0R3 maxXXREAL-0K5(b,d)"
      using A3 xxreal_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_28:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds b <=XXREAL-0R1 a & c <=XXREAL-0R1 a implies maxXXREAL-0K5(b,c) <=XXREAL-0R1 a"
  using xxreal_0_def_10 sorry

mtheorem xxreal_0_th_29:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds b <XXREAL-0R3 a & c <XXREAL-0R3 a implies maxXXREAL-0K5(b,c) <XXREAL-0R3 a"
  using xxreal_0_def_10 sorry

mtheorem xxreal_0_th_30:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(b,c) <=XXREAL-0R1 a implies b <=XXREAL-0R1 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  not (maxXXREAL-0K5(b,c) <=XXREAL-0R1 a &  not b <=XXREAL-0R1 a)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    have "b <=XXREAL-0R1 maxXXREAL-0K5(b,c)"
      using xxreal_0_th_25 sorry
    thus " not (maxXXREAL-0K5(b,c) <=XXREAL-0R1 a &  not b <=XXREAL-0R1 a)"
      using xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_31:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(b,c) <XXREAL-0R3 a implies b <XXREAL-0R3 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds  not ( not maxXXREAL-0K5(b,c) <XXREAL-0R3 a & b <XXREAL-0R3 a)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    have "b <=XXREAL-0R1 maxXXREAL-0K5(b,c)"
      using xxreal_0_th_25 sorry
    thus " not ( not maxXXREAL-0K5(b,c) <XXREAL-0R3 a & b <XXREAL-0R3 a)"
      using xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_32:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds (a <=XXREAL-0R1 c & b <=XXREAL-0R1 c) & ( for d be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 d & b <=XXREAL-0R1 d implies c <=XXREAL-0R1 d) implies c =HIDDENR1 maxXXREAL-0K5(a,b)"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds (a <=XXREAL-0R1 c & b <=XXREAL-0R1 c) & ( for d be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 d & b <=XXREAL-0R1 d implies c <=XXREAL-0R1 d) implies c =HIDDENR1 maxXXREAL-0K5(a,b)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 c & b <=XXREAL-0R1 c"
      and A2: " for d be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 d & b <=XXREAL-0R1 d implies c <=XXREAL-0R1 d"
    have "a <=XXREAL-0R1 maxXXREAL-0K5(a,b) & b <=XXREAL-0R1 maxXXREAL-0K5(a,b)"
      using xxreal_0_th_25 sorry
    then have A3: "c <=XXREAL-0R1 maxXXREAL-0K5(a,b)"
      using A2 sorry
    have "maxXXREAL-0K5(a,b) <=XXREAL-0R1 c"
      using A1 xxreal_0_def_10 sorry
    thus "c =HIDDENR1 maxXXREAL-0K5(a,b)"
      using A3 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_33:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    show "minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
    proof-
      have cases: "(a <=XXREAL-0R1 b & a <=XXREAL-0R1 c or b <=XXREAL-0R1 a & b <=XXREAL-0R1 c) or c <=XXREAL-0R1 b & c <=XXREAL-0R1 a"
        using xxreal_0_th_2 sorry
      have case1: "a <=XXREAL-0R1 b & a <=XXREAL-0R1 c implies minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
      proof(rule impI)
        assume "a <=XXREAL-0R1 b & a <=XXREAL-0R1 c"
        then have "minXXREAL-0K4(a,b) =HIDDENR1 a & minXXREAL-0K4(a,c) =HIDDENR1 a"
          using xxreal_0_def_9 sorry
        thus "minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
          using xxreal_0_def_9 sorry
      qed
      have case2: "b <=XXREAL-0R1 a & b <=XXREAL-0R1 c implies minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
      proof(rule impI)
        assume "b <=XXREAL-0R1 a & b <=XXREAL-0R1 c"
        then have "minXXREAL-0K4(a,b) =HIDDENR1 b & minXXREAL-0K4(b,c) =HIDDENR1 b"
          using xxreal_0_def_9 sorry
        thus "minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
           sorry
      qed
      have case3: "c <=XXREAL-0R1 b & c <=XXREAL-0R1 a implies minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
      proof(rule impI)
        assume "c <=XXREAL-0R1 b & c <=XXREAL-0R1 a"
        then have "minXXREAL-0K4(b,c) =HIDDENR1 c & minXXREAL-0K4(a,c) =HIDDENR1 c"
          using xxreal_0_def_9 sorry
        thus "minXXREAL-0K4(minXXREAL-0K4(a,b),c) =HIDDENR1 minXXREAL-0K4(a,minXXREAL-0K4(b,c))"
          using xxreal_0_def_9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_34:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    show "maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
    proof-
      have cases: "(a <=XXREAL-0R1 b & a <=XXREAL-0R1 c or b <=XXREAL-0R1 a & b <=XXREAL-0R1 c) or c <=XXREAL-0R1 b & c <=XXREAL-0R1 a"
        using xxreal_0_th_2 sorry
      have case1: "a <=XXREAL-0R1 b & a <=XXREAL-0R1 c implies maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
      proof(rule impI)
        assume A1: "a <=XXREAL-0R1 b & a <=XXREAL-0R1 c"
        have A2: "maxXXREAL-0K5(b,c) =HIDDENR1 b or maxXXREAL-0K5(b,c) =HIDDENR1 c"
          using xxreal_0_def_10 sorry
        have "maxXXREAL-0K5(a,b) =HIDDENR1 b"
          using A1 xxreal_0_def_10 sorry
        thus "maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
          using A1 A2 xxreal_0_def_10 sorry
      qed
      have case2: "b <=XXREAL-0R1 a & b <=XXREAL-0R1 c implies maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
      proof(rule impI)
        assume A3: "b <=XXREAL-0R1 a & b <=XXREAL-0R1 c"
        then have "maxXXREAL-0K5(a,b) =HIDDENR1 a"
          using xxreal_0_def_10 sorry
        thus "maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
          using A3 xxreal_0_def_10 sorry
      qed
      have case3: "c <=XXREAL-0R1 b & c <=XXREAL-0R1 a implies maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
      proof(rule impI)
        assume A4: "c <=XXREAL-0R1 b & c <=XXREAL-0R1 a"
        have A5: "maxXXREAL-0K5(a,b) =HIDDENR1 b or maxXXREAL-0K5(a,b) =HIDDENR1 a"
          using xxreal_0_def_10 sorry
        have "maxXXREAL-0K5(b,c) =HIDDENR1 b"
          using A4 xxreal_0_def_10 sorry
        thus "maxXXREAL-0K5(maxXXREAL-0K5(a,b),c) =HIDDENR1 maxXXREAL-0K5(a,maxXXREAL-0K5(b,c))"
          using A4 A5 xxreal_0_def_10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_35:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds minXXREAL-0K4(maxXXREAL-0K5(a,b),b) =HIDDENR1 b"
  using xxreal_0_th_25 xxreal_0_def_9 sorry

mtheorem xxreal_0_th_36:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(minXXREAL-0K4(a,b),b) =HIDDENR1 b"
  using xxreal_0_th_17 xxreal_0_def_10 sorry

mtheorem xxreal_0_th_37:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 c implies maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 c implies maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 c"
    show "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
    proof-
      have cases: "a <=XXREAL-0R1 b or b <=XXREAL-0R1 a"
         sorry
      have case1: "a <=XXREAL-0R1 b implies maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
      proof(rule impI)
        assume A2: "a <=XXREAL-0R1 b"
        then have "a <=XXREAL-0R1 minXXREAL-0K4(b,c)"
          using A1 xxreal_0_def_9 sorry
        then have "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(b,c)"
          using xxreal_0_def_10 sorry
        also have "... = minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
          using A2 xxreal_0_def_10 sorry
        finally show "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
           sorry
      qed
      have case2: "b <=XXREAL-0R1 a implies maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
      proof(rule impI)
        assume A3: "b <=XXREAL-0R1 a"
        then have "b <=XXREAL-0R1 c"
          using A1 xxreal_0_th_2 sorry
        then have "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 maxXXREAL-0K5(a,b)"
          using xxreal_0_def_9 sorry
        also have "... = a"
          using A3 xxreal_0_def_10 sorry
        also have "... = minXXREAL-0K4(a,c)"
          using A1 xxreal_0_def_9 sorry
        also have "... = minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
          using A3 xxreal_0_def_10 sorry
        finally show "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_38:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    show "minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
    proof-
      have cases: "b <=XXREAL-0R1 c or c <=XXREAL-0R1 b"
         sorry
      have case1: "b <=XXREAL-0R1 c implies minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
      proof(rule impI)
        assume A1: "b <=XXREAL-0R1 c"
        then have A2: "minXXREAL-0K4(a,b) <=XXREAL-0R1 minXXREAL-0K4(a,c)"
          using xxreal_0_th_18 sorry
        have "minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 minXXREAL-0K4(a,c)"
          using A1 xxreal_0_def_10 sorry
        also have "... = maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
          using A2 xxreal_0_def_10 sorry
        finally show "minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
           sorry
      qed
      have case2: "c <=XXREAL-0R1 b implies minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
      proof(rule impI)
        assume A3: "c <=XXREAL-0R1 b"
        then have A4: "minXXREAL-0K4(a,c) <=XXREAL-0R1 minXXREAL-0K4(a,b)"
          using xxreal_0_th_18 sorry
        have "minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 minXXREAL-0K4(a,b)"
          using A3 xxreal_0_def_10 sorry
        also have "... = maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
          using A4 xxreal_0_def_10 sorry
        finally show "minXXREAL-0K4(a,maxXXREAL-0K5(b,c)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(a,c))"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_39:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    show "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
    proof-
      have cases: "b <=XXREAL-0R1 c or c <=XXREAL-0R1 b"
         sorry
      have case1: "b <=XXREAL-0R1 c implies maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
      proof(rule impI)
        assume A1: "b <=XXREAL-0R1 c"
        then have A2: "maxXXREAL-0K5(a,b) <=XXREAL-0R1 maxXXREAL-0K5(a,c)"
          using xxreal_0_th_26 sorry
        have "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 maxXXREAL-0K5(a,b)"
          using A1 xxreal_0_def_9 sorry
        also have "... = minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
          using A2 xxreal_0_def_9 sorry
        finally show "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
           sorry
      qed
      have case2: "c <=XXREAL-0R1 b implies maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
      proof(rule impI)
        assume A3: "c <=XXREAL-0R1 b"
        then have A4: "maxXXREAL-0K5(a,c) <=XXREAL-0R1 maxXXREAL-0K5(a,b)"
          using xxreal_0_th_26 sorry
        have "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 maxXXREAL-0K5(a,c)"
          using A3 xxreal_0_def_9 sorry
        also have "... = minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
          using A4 xxreal_0_def_9 sorry
        finally show "maxXXREAL-0K5(a,minXXREAL-0K4(b,c)) =HIDDENR1 minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(a,c))"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_40:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    show "maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
    proof-
      have cases: "a <=XXREAL-0R1 c or c <=XXREAL-0R1 a"
         sorry
      have case1: "a <=XXREAL-0R1 c implies maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
      proof(rule impI)
        assume A1: "a <=XXREAL-0R1 c"
        then have A2: "maxXXREAL-0K5(a,b) <=XXREAL-0R1 maxXXREAL-0K5(b,c)"
          using xxreal_0_th_26 sorry
        have "minXXREAL-0K4(a,b) <=XXREAL-0R1 minXXREAL-0K4(b,c)"
          using A1 xxreal_0_th_18 sorry
        then have "maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(b,c),minXXREAL-0K4(c,a))"
          using xxreal_0_def_10 sorry
        also have "... = maxXXREAL-0K5(minXXREAL-0K4(b,c),a)"
          using A1 xxreal_0_def_9 sorry
        also have "... = minXXREAL-0K4(maxXXREAL-0K5(a,b),c)"
          using A1 xxreal_0_th_37 sorry
        also have "... = minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(c,a))"
          using A1 xxreal_0_def_10 sorry
        also have "... = minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
          using A2 xxreal_0_def_9 sorry
        finally show "maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
           sorry
      qed
      have case2: "c <=XXREAL-0R1 a implies maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
      proof(rule impI)
        assume A3: "c <=XXREAL-0R1 a"
        then have A4: "maxXXREAL-0K5(a,b) >=XXREAL-0R2 maxXXREAL-0K5(b,c)"
          using xxreal_0_th_26 sorry
        have "minXXREAL-0K4(a,b) >=XXREAL-0R2 minXXREAL-0K4(b,c)"
          using A3 xxreal_0_th_18 sorry
        then have "maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(c,a))"
          using xxreal_0_def_10 sorry
        also have "... = maxXXREAL-0K5(minXXREAL-0K4(a,b),c)"
          using A3 xxreal_0_def_9 sorry
        also have "... = minXXREAL-0K4(maxXXREAL-0K5(c,b),a)"
          using A3 xxreal_0_th_37 sorry
        also have "... = minXXREAL-0K4(maxXXREAL-0K5(c,b),maxXXREAL-0K5(c,a))"
          using A3 xxreal_0_def_10 sorry
        also have "... = minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
          using A4 xxreal_0_def_9 sorry
        finally show "maxXXREAL-0K5(maxXXREAL-0K5(minXXREAL-0K4(a,b),minXXREAL-0K4(b,c)),minXXREAL-0K4(c,a)) =HIDDENR1 minXXREAL-0K4(minXXREAL-0K4(maxXXREAL-0K5(a,b),maxXXREAL-0K5(b,c)),maxXXREAL-0K5(c,a))"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_41:
" for a be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,+inftyXXREAL-0K1) =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have " for a be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,+inftyXXREAL-0K1) =HIDDENR1 +inftyXXREAL-0K1"
  proof(rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    have "a <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_def_5 xxreal_0_lm_4 xxreal_0_lm_6 sorry
    thus "maxXXREAL-0K5(a,+inftyXXREAL-0K1) =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_42:
" for a be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,+inftyXXREAL-0K1) =HIDDENR1 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,+inftyXXREAL-0K1) =HIDDENR1 a"
  proof(rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    have "a <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_def_5 xxreal_0_lm_4 xxreal_0_lm_6 sorry
    thus "minXXREAL-0K4(a,+inftyXXREAL-0K1) =HIDDENR1 a"
      using xxreal_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_43:
" for a be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,-inftyXXREAL-0K2) =HIDDENR1 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,-inftyXXREAL-0K2) =HIDDENR1 a"
  proof(rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    have "a >=XXREAL-0R2 -inftyXXREAL-0K2"
      using xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_7 sorry
    thus "maxXXREAL-0K5(a,-inftyXXREAL-0K2) =HIDDENR1 a"
      using xxreal_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_44:
" for a be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,-inftyXXREAL-0K2) =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for a be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,-inftyXXREAL-0K2) =HIDDENR1 -inftyXXREAL-0K2"
  proof(rule ballI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    have "a >=XXREAL-0R2 -inftyXXREAL-0K2"
      using xxreal_0_def_5 xxreal_0_lm_5 xxreal_0_lm_7 sorry
    thus "minXXREAL-0K4(a,-inftyXXREAL-0K2) =HIDDENR1 -inftyXXREAL-0K2"
      using xxreal_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xxreal_0_th_45:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds ((a inHIDDENR3 REALNUMBERSK2 & c inHIDDENR3 REALNUMBERSK2) & a <=XXREAL-0R1 b) & b <=XXREAL-0R1 c implies b inHIDDENR3 REALNUMBERSK2"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a inHIDDENR3 REALNUMBERSK2 & (c inHIDDENR3 REALNUMBERSK2 & (a <=XXREAL-0R1 b & b <=XXREAL-0R1 c)) implies b inHIDDENR3 REALNUMBERSK2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    assume A1: "a inHIDDENR3 REALNUMBERSK2"
      and A2: "c inHIDDENR3 REALNUMBERSK2"
      and A3: "a <=XXREAL-0R1 b"
      and A4: "b <=XXREAL-0R1 c"
    have "b inHIDDENR3 REALNUMBERSK2 or b =HIDDENR1 +inftyXXREAL-0K1"
      using A1 A3 xxreal_0_th_10 sorry
    thus "b inHIDDENR3 REALNUMBERSK2"
      using A2 A4 xxreal_0_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_46:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds (a inHIDDENR3 REALNUMBERSK2 & a <=XXREAL-0R1 b) & b <XXREAL-0R3 c implies b inHIDDENR3 REALNUMBERSK2"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds (a inHIDDENR3 REALNUMBERSK2 & a <=XXREAL-0R1 b) & b <XXREAL-0R3 c implies b inHIDDENR3 REALNUMBERSK2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    assume A1: "a inHIDDENR3 REALNUMBERSK2 & a <=XXREAL-0R1 b"
      and A2: "b <XXREAL-0R3 c"
    have "b inHIDDENR3 REALNUMBERSK2 or b =HIDDENR1 +inftyXXREAL-0K1"
      using A1 xxreal_0_th_10 sorry
    thus "b inHIDDENR3 REALNUMBERSK2"
      using A2 xxreal_0_lm_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_47:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds (c inHIDDENR3 REALNUMBERSK2 & a <XXREAL-0R3 b) & b <=XXREAL-0R1 c implies b inHIDDENR3 REALNUMBERSK2"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds c inHIDDENR3 REALNUMBERSK2 & (a <XXREAL-0R3 b & b <=XXREAL-0R1 c) implies b inHIDDENR3 REALNUMBERSK2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    assume A1: "c inHIDDENR3 REALNUMBERSK2"
      and A2: "a <XXREAL-0R3 b"
      and A3: "b <=XXREAL-0R1 c"
    have "b inHIDDENR3 REALNUMBERSK2 or b =HIDDENR1 -inftyXXREAL-0K2"
      using A1 A3 xxreal_0_th_13 sorry
    thus "b inHIDDENR3 REALNUMBERSK2"
      using A2 xxreal_0_lm_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_48:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <XXREAL-0R3 b & b <XXREAL-0R3 c implies b inHIDDENR3 REALNUMBERSK2"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds  for c be ExtRealXXREAL-0M1 holds a <XXREAL-0R3 b & b <XXREAL-0R3 c implies b inHIDDENR3 REALNUMBERSK2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b & b <XXREAL-0R3 c"
    have "(b inHIDDENR3 REALNUMBERSK2 or b =HIDDENR1 +inftyXXREAL-0K1) or b =HIDDENR1 -inftyXXREAL-0K2"
      using xxreal_0_lm_11 sorry
    thus "b inHIDDENR3 REALNUMBERSK2"
      using A1 xxreal_0_lm_9 xxreal_0_lm_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef xxreal_0_def_11 ("IFGTXXREAL-0K6'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"func IFGTXXREAL-0K6(x,y,a,b) \<rightarrow> objectHIDDENM1 equals
  a if x >XXREAL-0R4 y otherwise b"
proof-
  (*coherence*)
    show "(x >XXREAL-0R4 y implies a be objectHIDDENM1) & ( not x >XXREAL-0R4 y implies b be objectHIDDENM1)"
       sorry
  (*consistency*)
    show " for it be objectHIDDENM1 holds  True "
       sorry
qed "sorry"

mtheorem xxreal_0_cl_20:
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1", "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "b be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster IFGTXXREAL-0K6(x,y,a,b) as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "IFGTXXREAL-0K6(x,y,a,b) be naturalORDINAL1V7"
    using xxreal_0_def_11 sorry
qed "sorry"

mtheorem xxreal_0_th_49:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,b) <=XXREAL-0R1 a implies maxXXREAL-0K5(a,b) =HIDDENR1 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(a,b) <=XXREAL-0R1 a implies maxXXREAL-0K5(a,b) =HIDDENR1 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    assume "maxXXREAL-0K5(a,b) <=XXREAL-0R1 a"
    then have "maxXXREAL-0K5(a,b) <XXREAL-0R3 a or maxXXREAL-0K5(a,b) =HIDDENR1 a"
      using xxreal_0_th_1 sorry
    thus "maxXXREAL-0K5(a,b) =HIDDENR1 a"
      using xxreal_0_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_th_50:
" for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds a <=XXREAL-0R1 minXXREAL-0K4(a,b) implies minXXREAL-0K4(a,b) =HIDDENR1 a"
proof-
  have " for a be ExtRealXXREAL-0M1 holds  for b be ExtRealXXREAL-0M1 holds minXXREAL-0K4(a,b) >=XXREAL-0R2 a implies minXXREAL-0K4(a,b) =HIDDENR1 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
    assume "minXXREAL-0K4(a,b) >=XXREAL-0R2 a"
    then have "minXXREAL-0K4(a,b) >XXREAL-0R4 a or minXXREAL-0K4(a,b) =HIDDENR1 a"
      using xxreal_0_th_1 sorry
    thus "minXXREAL-0K4(a,b) =HIDDENR1 a"
      using xxreal_0_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_0_reduce_1:
  mlet "x be ExtRealXXREAL-0M1"
"reduce InSUBSET-1K10(x,ExtREALXXREAL-0K3) to x"
proof
(*reducibility*)
  show "InSUBSET-1K10(x,ExtREALXXREAL-0K3) =HIDDENR1 x"
    using xxreal_0_def_1 subset_1_def_8 sorry
qed "sorry"

end
