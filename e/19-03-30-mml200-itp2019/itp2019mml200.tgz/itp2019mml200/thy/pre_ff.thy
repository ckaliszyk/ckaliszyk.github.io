theory pre_ff
  imports power finseq_4 recdef_1
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem pre_ff_reduce_1:
  mlet "n be NatNAT-1M1", "k be NatNAT-1M1"
"reduce InSUBSET-1K10([TARSKIK4 n,k ],[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]) to [TARSKIK4 n,k ]"
proof
(*reducibility*)
  show "InSUBSET-1K10([TARSKIK4 n,k ],[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]) =HIDDENR1 [TARSKIK4 n,k ]"
  proof-
    have "n inTARSKIR2 NATNUMBERSK1 & k inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have "[TARSKIK4 n,k ] inHIDDENR3 [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]"
      using zfmisc_1_th_87 sorry
    thus "InSUBSET-1K10([TARSKIK4 n,k ],[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]) =HIDDENR1 [TARSKIK4 n,k ]"
      using subset_1_def_8 sorry
  qed
qed "sorry"

mdef pre_ff_def_1 ("FibPRE-FFK1  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func FibPRE-FFK1 n \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it.  ex fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])"
proof-
  (*existence*)
    show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])"
    proof-
      have " ex tVar1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex tVar2 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st tVar1 =XBOOLE-0R4 (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ] & ( for n be NatNAT-1M1 holds tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ]))"
      proof-
        let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10([DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> Lamb2 `2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,Lamb2 `1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 Lamb2 `2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ],[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
        obtain fib where
          [ty]:"fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]" and 
          A1: "fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ] & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?F(n,fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n))"
          using nat_1_sch_12 sorry
        obtain IT where 
          [ty]:"IT be ElementSUBSET-1M1-of NATNUMBERSK1" and ITDef:"IT = (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
           sorry
        show " ex tVar1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex tVar2 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st tVar1 =XBOOLE-0R4 (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ] & ( for n be NatNAT-1M1 holds tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ]))"
        proof(rule bexI[of _ "IT"])
          show " ex tVar2 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st IT =XBOOLE-0R4 (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ] & ( for n be NatNAT-1M1 holds tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (tVar2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ]))"
          proof(rule bexI[of _ "fib"],rule conjMI,rule conjMI,rule ballI)
            show "IT =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
               sorry
            show "fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]"
              using A1 sorry
            fix n assume [ty]: "n be NatNAT-1M1"
            have "fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?F(n,fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)"
              using A1 sorry
            thus "fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ]"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( ex fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it1 =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])) & ( ex fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it2 =XBOOLE-0R4 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])) implies it1 =HIDDENR1 it2"
    proof-
      have " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( ex fib1 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it1 =XBOOLE-0R4 (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])) implies (( ex fib2 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it2 =XBOOLE-0R4 (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])) implies it1 =HIDDENR1 it2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10([DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> Lamb2 `2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,Lamb2 `1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 Lamb2 `2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ],[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
        fix it1 assume [ty]: "it1 be ElementSUBSET-1M1-of NATNUMBERSK1"
        fix it2 assume [ty]: "it2 be ElementSUBSET-1M1-of NATNUMBERSK1"
        assume Given: " ex fib1 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it1 =XBOOLE-0R4 (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])"
        then obtain fib1 where
          [ty]:"fib1 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]" and 
          A2: "it1 =XBOOLE-0R4 (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"and A3: "fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]"and A4: " for n be NatNAT-1M1 holds fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ]"
           sorry
        have A5: " for n be NatNAT-1M1 holds fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?F(n,fib1 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)"
          using A4 sorry
        assume Given: " ex fib2 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :] st (it2 =XBOOLE-0R4 (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> & fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]) & ( for n be NatNAT-1M1 holds fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ])"
        then obtain fib2 where
          [ty]:"fib2 be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]" and 
          A6: "it2 =XBOOLE-0R4 (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"and A7: "fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]"and A8: " for n be NatNAT-1M1 holds fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ]"
           sorry
        have A9: " for n be NatNAT-1M1 holds fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?F(n,fib2 .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)"
          using A8 sorry
        have "fib1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> fib2"
          using nat_1_sch_16 A3 A5 A7 A9 sorry
        thus "it1 =HIDDENR1 it2"
          using A2 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem pre_ff_th_1:
"(FibPRE-FFK1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & FibPRE-FFK1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds FibPRE-FFK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FibPRE-FFK1 n +NAT-1K1 FibPRE-FFK1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have "FibPRE-FFK1 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6 & (FibPRE-FFK1 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds FibPRE-FFK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FibPRE-FFK1 n +NAT-1K1 FibPRE-FFK1 (n +NAT-1K1 \<one>\<^sub>M)))"
  proof(rule conjMI,rule conjMI,rule ballI)
    let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10([DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> Lamb2 `2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,Lamb2 `1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 Lamb2 `2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ],[:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])"
    obtain fib where
      [ty]:"fib be sequenceNAT-1M2-of [:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :]" and 
      A1: "fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ]"and A2: " for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?F(n,fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)"
      using nat_1_sch_12 sorry
    have A3: " for n be NatNAT-1M1 holds fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ]"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain i j where 
        [ty]:"i be NatNAT-1M1" and iDef:"i = (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>" and
        [ty]:"j be NatNAT-1M1" and jDef:"j = (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
         sorry
      have "fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?F(n,fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)"
        using A2 sorry
      also have "... = [TARSKIK4 i,j ]"
         sorry
      finally have "fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 [TARSKIK4 i,j ]"
         sorry
      thus "fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ]"
         sorry
    qed "sorry"
    have "FibPRE-FFK1 (0NUMBERSK6) =HIDDENR1 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ] `1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A1 A3 pre_ff_def_1 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally show "FibPRE-FFK1 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
    have "FibPRE-FFK1 \<one>\<^sub>M =HIDDENR1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A1 A3 pre_ff_def_1 sorry
    also have "... = [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6))`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6))`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (0NUMBERSK6))`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ] `1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A3 sorry
    also have "... = [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<one>\<^sub>M ] `2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A1 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally show "FibPRE-FFK1 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
       sorry
    fix n assume [ty]: "n be NatNAT-1M1"
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A4: "(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M))`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> =HIDDENR1 [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ] `1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A3 sorry
    also have "... = (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
       sorry
    finally have "(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M))`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> =HIDDENR1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
       sorry
    have "FibPRE-FFK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A1 A3 pre_ff_def_1 sorry
    also have "... = [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M))`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M))`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M))`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ] `1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A3 sorry
    also have "... = (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M))`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
       sorry
    also have "... = [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>,(fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> ] `2DOMAIN-1K3\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A3 sorry
    also have "... = (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> n)`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M))`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A4 sorry
    also have "... = FibPRE-FFK1 n +NAT-1K1 (fib .NAT-1K8\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,NATNUMBERSK1 :])\<^esub> (n +NAT-1K1 \<one>\<^sub>M))`1DOMAIN-1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub>"
      using A1 A3 pre_ff_def_1 sorry
    also have "... = FibPRE-FFK1 n +NAT-1K1 FibPRE-FFK1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A1 A3 pre_ff_def_1 sorry
    finally have "FibPRE-FFK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 FibPRE-FFK1 n +NAT-1K1 FibPRE-FFK1 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    thus "FibPRE-FFK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FibPRE-FFK1 n +NAT-1K1 FibPRE-FFK1 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_2:
" for i be IntegerINT-1M1 holds i divINT-1K5 \<one>\<^sub>M =HIDDENR1 i"
proof(rule ballI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  have "i divINT-1K5 \<one>\<^sub>M =HIDDENR1 [\\INT-1K2 i /XCMPLX-0K7 \<one>\<^sub>M /]"
    using int_1_def_9 sorry
  also have "... = i"
    using int_1_th_25 sorry
  finally show "i divINT-1K5 \<one>\<^sub>M =HIDDENR1 i"
     sorry
qed "sorry"

mtheorem pre_ff_th_3:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds j >XXREAL-0R4 0NUMBERSK6 & i divINT-1K5 j =HIDDENR1 0NUMBERSK6 implies i <XXREAL-0R3 j"
proof-
  have " for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds j >XXREAL-0R4 0NUMBERSK6 & i divINT-1K5 j =HIDDENR1 0NUMBERSK6 implies  not i <XXREAL-0R3 j"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix j assume [ty]: "j be IntegerINT-1M1"
    assume A1: "j >XXREAL-0R4 0NUMBERSK6"
      and A2: "i divINT-1K5 j =HIDDENR1 0NUMBERSK6"
    have "[\\INT-1K2 i /XCMPLX-0K7 j /] =HIDDENR1 0NUMBERSK6"
      using A2 int_1_def_9 sorry
    then have "i /XCMPLX-0K7 j -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6"
      using int_1_def_6 sorry
    then have "i /XCMPLX-0K7 j <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_19 sorry
    then have "(i /XCMPLX-0K7 j)*XCMPLX-0K3 j <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 j"
      using A1 xreal_1_th_68 sorry
    thus " not i <XXREAL-0R3 j"
      using A1 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_4:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 i & i <XXREAL-0R3 j implies i divINT-1K5 j =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix j assume [ty]: "j be IntegerINT-1M1"
  assume A1: "0NUMBERSK6 <=XXREAL-0R1 i & i <XXREAL-0R3 j"
  then have "i /XCMPLX-0K7 j <XXREAL-0R3 j /XCMPLX-0K7 j"
    using xreal_1_th_74 sorry
  then have "i /XCMPLX-0K7 j <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
    using A1 xcmplx_1_th_60 sorry
  then have "i /XCMPLX-0K7 j -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6"
    using xreal_1_th_19 sorry
  then have "[\\INT-1K2 i /XCMPLX-0K7 j /] =HIDDENR1 0NUMBERSK6"
    using A1 int_1_def_6 sorry
  thus "i divINT-1K5 j =HIDDENR1 0NUMBERSK6"
    using int_1_def_9 sorry
qed "sorry"

mtheorem pre_ff_th_5:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds  for k be IntegerINT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 implies (i divINT-1K5 j)divINT-1K5 k =HIDDENR1 i divINT-1K5 j *XCMPLX-0K3 k"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix j assume [ty]: "j be IntegerINT-1M1"
  fix k assume [ty]: "k be IntegerINT-1M1"
  let ?A = "[\\INT-1K2 ([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k /]"
  let ?D = "[\\INT-1K2 i /XCMPLX-0K7 (j *XCMPLX-0K3 k) /]"
  have "?A =HIDDENR1 [\\INT-1K2 i /XCMPLX-0K7 j /] divINT-1K5 k"
    using int_1_def_9 sorry
  then have A1: "?A =HIDDENR1 (i divINT-1K5 j)divINT-1K5 k"
    using int_1_def_9 sorry
  assume A2: "k >XXREAL-0R4 0NUMBERSK6"
  have A3: "[\\INT-1K2 ([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k /] <XXREAL-0R3 [\\INT-1K2 i /XCMPLX-0K7 (j *XCMPLX-0K3 k) /] implies  False "
  proof(rule impI)
    have "([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ?A"
      using int_1_def_6 sorry
    then have A4: "([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k <XXREAL-0R3 ?A +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_19 sorry
    assume "?A <XXREAL-0R3 ?D"
    then have "?A +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 ?D"
      using int_1_th_7 sorry
    then have "([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k <XXREAL-0R3 ?D"
      using A4 xxreal_0_th_2 sorry
    then have "(([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k)*XCMPLX-0K3 k <XXREAL-0R3 ?D *XCMPLX-0K3 k"
      using A2 xreal_1_th_68 sorry
    then have "[\\INT-1K2 i /XCMPLX-0K7 j /] <XXREAL-0R3 ?D *XCMPLX-0K3 k"
      using A2 xcmplx_1_th_87 sorry
    then have A5: "[\\INT-1K2 i /XCMPLX-0K7 j /] +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 ?D *XCMPLX-0K3 k"
      using int_1_th_7 sorry
    have "[\\INT-1K2 i /XCMPLX-0K7 (j *XCMPLX-0K3 k) /] <=XXREAL-0R1 i /XCMPLX-0K7 (j *XCMPLX-0K3 k)"
      using int_1_def_6 sorry
    then have "([\\INT-1K2 i /XCMPLX-0K7 (j *XCMPLX-0K3 k) /])*XCMPLX-0K3 k <=XXREAL-0R1 (i /XCMPLX-0K7 (j *XCMPLX-0K3 k))*XCMPLX-0K3 k"
      using A2 xreal_1_th_64 sorry
    then have "([\\INT-1K2 i /XCMPLX-0K7 (j *XCMPLX-0K3 k) /])*XCMPLX-0K3 k <=XXREAL-0R1 ((i /XCMPLX-0K7 j)/XCMPLX-0K7 k)*XCMPLX-0K3 k"
      using xcmplx_1_th_78 sorry
    then have A6: "([\\INT-1K2 i /XCMPLX-0K7 (j *XCMPLX-0K3 k) /])*XCMPLX-0K3 k <=XXREAL-0R1 i /XCMPLX-0K7 j"
      using A2 xcmplx_1_th_87 sorry
    have "i /XCMPLX-0K7 j -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 i /XCMPLX-0K7 j /]"
      using int_1_def_6 sorry
    then have "i /XCMPLX-0K7 j <XXREAL-0R3 [\\INT-1K2 i /XCMPLX-0K7 j /] +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_19 sorry
    thus " False "
      using A6 A5 xxreal_0_th_2 sorry
  qed
  have A7: "[\\INT-1K2 i /XCMPLX-0K7 (j *XCMPLX-0K3 k) /] <XXREAL-0R3 [\\INT-1K2 ([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k /] implies  False "
  proof(rule impI)
    have "[\\INT-1K2 i /XCMPLX-0K7 j /] <=XXREAL-0R1 i /XCMPLX-0K7 j"
      using int_1_def_6 sorry
    then have "([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k <=XXREAL-0R1 (i /XCMPLX-0K7 j)/XCMPLX-0K7 k"
      using A2 xreal_1_th_72 sorry
    then have "?A <=XXREAL-0R1 ([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k & ([\\INT-1K2 i /XCMPLX-0K7 j /])/XCMPLX-0K7 k <=XXREAL-0R1 i /XCMPLX-0K7 (j *XCMPLX-0K3 k)"
      using int_1_def_6 xcmplx_1_th_78 sorry
    then have A8: "?A <=XXREAL-0R1 i /XCMPLX-0K7 (j *XCMPLX-0K3 k)"
      using xxreal_0_th_2 sorry
    have "i /XCMPLX-0K7 (j *XCMPLX-0K3 k) -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ?D"
      using int_1_def_6 sorry
    then have A9: "i /XCMPLX-0K7 (j *XCMPLX-0K3 k) <XXREAL-0R3 ?D +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_19 sorry
    assume "?D <XXREAL-0R3 ?A"
    then have "?D +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 ?A"
      using int_1_th_7 sorry
    thus " False "
      using A9 A8 xxreal_0_th_2 sorry
  qed
  have "?D =HIDDENR1 i divINT-1K5 j *XCMPLX-0K3 k"
    using int_1_def_9 sorry
  thus "(i divINT-1K5 j)divINT-1K5 k =HIDDENR1 i divINT-1K5 j *XCMPLX-0K3 k"
    using A3 A7 A1 xxreal_0_th_1 sorry
qed "sorry"

mtheorem pre_ff_th_6:
" for i be IntegerINT-1M1 holds i modINT-1K6 \<two>\<^sub>M =HIDDENR1 0NUMBERSK6 or i modINT-1K6 \<two>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for i be IntegerINT-1M1 holds  not ( not i modINT-1K6 \<two>\<^sub>M =HIDDENR1 0NUMBERSK6 &  not i modINT-1K6 \<two>\<^sub>M =HIDDENR1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    let ?A = "(i divINT-1K5 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M"
    let ?M = "i modINT-1K6 \<two>\<^sub>M"
    have A1: "i divINT-1K5 \<two>\<^sub>M =HIDDENR1 [\\INT-1K2 i /XCMPLX-0K7 \<two>\<^sub>M /]"
      using int_1_def_9 sorry
    then have "i /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 i divINT-1K5 \<two>\<^sub>M"
      using int_1_def_6 sorry
    then have "(i /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M <XXREAL-0R3 ?A"
      using xreal_1_th_68 sorry
    then have "-XCMPLX-0K4 (i -XCMPLX-0K6 \<two>\<^sub>M) >XXREAL-0R4 -XCMPLX-0K4 ?A"
      using xreal_1_th_24 sorry
    then have "i +XCMPLX-0K2 (\<two>\<^sub>M -XCMPLX-0K6 i) >XXREAL-0R4 i +XCMPLX-0K2 (-XCMPLX-0K4 ?A)"
      using xreal_1_th_6 sorry
    then have "\<two>\<^sub>M >XXREAL-0R4 i -XCMPLX-0K6 ?A"
       sorry
    then have A2: "\<two>\<^sub>M >XXREAL-0R4 ?M"
      using int_1_def_10 sorry
    have "i divINT-1K5 \<two>\<^sub>M <=XXREAL-0R1 i /XCMPLX-0K7 \<two>\<^sub>M"
      using A1 int_1_def_6 sorry
    then have "?A <=XXREAL-0R1 (i /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M"
      using xreal_1_th_64 sorry
    then have "-XCMPLX-0K4 i <=XXREAL-0R1 -XCMPLX-0K4 ?A"
      using xreal_1_th_24 sorry
    then have "i +XCMPLX-0K2 (-XCMPLX-0K4 i) <=XXREAL-0R1 i +XCMPLX-0K2 (-XCMPLX-0K4 ?A)"
      using xreal_1_th_6 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 i -XCMPLX-0K6 ?A"
       sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 ?M"
      using int_1_def_10 sorry
    then obtain M where 
      [ty]:"M be ElementSUBSET-1M1-of NATNUMBERSK1" and MDef:"M = ?M"
      using int_1_th_3 sorry
    have "M inTARSKIR2 {k where k be NatNAT-1M1 : k <XXREAL-0R3 \<two>\<^sub>M }"
      using A2 sorry
    then have "M inTARSKIR2 \<two>\<^sub>M"
      using axioms_th_4 sorry
    thus " not ( not i modINT-1K6 \<two>\<^sub>M =HIDDENR1 0NUMBERSK6 &  not i modINT-1K6 \<two>\<^sub>M =HIDDENR1 \<one>\<^sub>M)"
      using card_1_th_50 tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_7:
" for i be IntegerINT-1M1 holds i be ElementSUBSET-1M1-of NATNUMBERSK1 implies i divINT-1K5 \<two>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
proof(rule ballI,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  assume "i be ElementSUBSET-1M1-of NATNUMBERSK1"
  then obtain n where 
    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = i"
     sorry
  have "i /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 i /XCMPLX-0K7 \<two>\<^sub>M /]"
    using int_1_def_6 sorry
  then have A1: "i /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 [\\INT-1K2 i /XCMPLX-0K7 \<two>\<^sub>M /] +XCMPLX-0K2 \<one>\<^sub>M"
    using xreal_1_th_19 sorry
  have "n >=XXREAL-0R2 0NUMBERSK6"
     sorry
  then have "i /XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 (0NUMBERSK6)/XCMPLX-0K7 \<two>\<^sub>M"
     sorry
  then have "[\\INT-1K2 i /XCMPLX-0K7 \<two>\<^sub>M /] be ElementSUBSET-1M1-of NATNUMBERSK1"
    using A1 int_1_th_3 int_1_th_7 sorry
  thus "i divINT-1K5 \<two>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
    using int_1_def_9 sorry
qed "sorry"

mtheorem pre_ff_th_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c >=XXREAL-0R2 \<one>\<^sub>M implies c to-powerPOWERK2 a <=XXREAL-0R1 c to-powerPOWERK2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies (c >=XXREAL-0R2 \<one>\<^sub>M implies c to-powerPOWERK2 a <=XXREAL-0R1 c to-powerPOWERK2 b)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b"
    then have A1: "a <XXREAL-0R3 b or a =HIDDENR1 b"
      using xxreal_0_th_1 sorry
    assume Cut259: "c >=XXREAL-0R2 \<one>\<^sub>M"
    show "c to-powerPOWERK2 a <=XXREAL-0R1 c to-powerPOWERK2 b"
    proof-
      have cases: "c >XXREAL-0R4 \<one>\<^sub>M or c =HIDDENR1 \<one>\<^sub>M"
        using xxreal_0_th_1 Cut259 sorry
      have case1: "c >XXREAL-0R4 \<one>\<^sub>M implies c to-powerPOWERK2 a <=XXREAL-0R1 c to-powerPOWERK2 b"
      proof(rule impI)
        assume "c >XXREAL-0R4 \<one>\<^sub>M"
        thus "c to-powerPOWERK2 a <=XXREAL-0R1 c to-powerPOWERK2 b"
          using A1 power_th_39 sorry
      qed
      have case2: "c =HIDDENR1 \<one>\<^sub>M implies c to-powerPOWERK2 a <=XXREAL-0R1 c to-powerPOWERK2 b"
      proof(rule impI)
        assume A2: "c =HIDDENR1 \<one>\<^sub>M"
        have "\<one>\<^sub>M to-powerPOWERK2 a =HIDDENR1 \<one>\<^sub>M & \<one>\<^sub>M to-powerPOWERK2 b =HIDDENR1 \<one>\<^sub>M"
          using power_th_26 sorry
        thus "c to-powerPOWERK2 a <=XXREAL-0R1 c to-powerPOWERK2 b"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_9:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r >=XXREAL-0R2 s implies [\\INT-1K2 r/] >=XXREAL-0R2 [\\INT-1K2 s/]"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r >=XXREAL-0R2 s implies ([\\INT-1K2 r/] <XXREAL-0R3 [\\INT-1K2 s/] implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume A1: "r >=XXREAL-0R2 s"
    have A2: "[\\INT-1K2 s/] <=XXREAL-0R1 s"
      using int_1_def_6 sorry
    have "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/]"
      using int_1_def_6 sorry
    then have A3: "(r -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    assume "[\\INT-1K2 r/] <XXREAL-0R3 [\\INT-1K2 s/]"
    then have "[\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 [\\INT-1K2 s/]"
      using int_1_th_7 sorry
    then have "r <XXREAL-0R3 [\\INT-1K2 s/]"
      using A3 xxreal_0_th_2 sorry
    thus " False "
      using A1 A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) & c >=XXREAL-0R2 b implies logPOWERK3(a,c) >=XXREAL-0R2 logPOWERK3(a,b)"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  fix c assume [ty]: "c be RealXREAL-0M1"
  assume A1: "a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6"
    and A2: "c >=XXREAL-0R2 b"
  have "c >XXREAL-0R4 b or c =HIDDENR1 b"
    using A2 xxreal_0_th_1 sorry
  thus "logPOWERK3(a,c) >=XXREAL-0R2 logPOWERK3(a,b)"
    using A1 power_th_57 sorry
qed "sorry"

mtheorem pre_ff_th_11:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] +XCMPLX-0K2 \<one>\<^sub>M <>HIDDENR2 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
proof-
  have " for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies ([\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/] implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?l22n = "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)"
    let ?l22np1 = "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)"
    let ?k = "[\\INT-1K2 ?l22n +XCMPLX-0K2 \<one>\<^sub>M /]"
    have "(?l22n +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ?k"
      using int_1_def_6 sorry
    then have A1: "\<two>\<^sub>M to-powerPOWERK2 ?l22n <XXREAL-0R3 \<two>\<^sub>M to-powerPOWERK2 ?k"
      using power_th_39 sorry
    assume A2: "n >XXREAL-0R4 0NUMBERSK6"
    then have "\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n"
       sorry
    then have A3: "\<two>\<^sub>M *XCMPLX-0K3 n <XXREAL-0R3 \<two>\<^sub>M to-powerPOWERK2 ?k"
      using A1 power_def_3 sorry
    assume "[\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
    then have A4: "[\\INT-1K2 ?l22n +XCMPLX-0K2 \<one>\<^sub>M /] =HIDDENR1 [\\INT-1K2 ?l22np1/]"
      using int_1_th_28 sorry
    then have "?k <=XXREAL-0R1 ?l22np1"
      using int_1_def_6 sorry
    then have "\<two>\<^sub>M to-powerPOWERK2 ?k <=XXREAL-0R1 \<two>\<^sub>M to-powerPOWERK2 ?l22np1"
      using pre_ff_th_8 sorry
    then have A5: "\<two>\<^sub>M to-powerPOWERK2 ?k <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M"
      using power_def_3 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_7 sorry
    then have "logPOWERK3(\<two>\<^sub>M,\<one>\<^sub>M) <=XXREAL-0R1 ?l22np1"
      using pre_ff_th_10 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 ?l22np1"
      using power_th_51 sorry
    then have "[\\INT-1K2 0NUMBERSK6 /] <=XXREAL-0R1 ?k"
      using A4 pre_ff_th_9 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 ?k"
      using int_1_th_25 sorry
    then obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = ?k"
      using int_1_th_3 sorry
    obtain T2tpk where 
      [ty]:"T2tpk be ElementSUBSET-1M1-of NATNUMBERSK1" and T2tpkDef:"T2tpk = \<two>\<^sub>M  |^NEWTONK11 k"
       sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 n <XXREAL-0R3 T2tpk"
      using A3 power_th_41 sorry
    then have A6: "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 T2tpk"
      using nat_1_th_13 sorry
    have "T2tpk <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M"
      using A5 power_th_41 sorry
    then have A7: "T2tpk =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M"
      using A6 xxreal_0_th_1 sorry
    show " False "
    proof-
      have cases: "k =XBOOLE-0R4 0NUMBERSK6 or ( ex m be NatNAT-1M1 st k =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M)"
        using nat_1_th_6 sorry
      have case1: "k =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "k =XBOOLE-0R4 0NUMBERSK6"
        then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A7 newton_th_4 sorry
        thus " False "
          using A2 sorry
      qed
      have case2: "( ex m be NatNAT-1M1 st k =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M) implies  False "
      proof(rule impI)
        assume " ex m be NatNAT-1M1 st k =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A8: "k =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
           sorry
        have 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 m +NAT-1K1 0NUMBERSK6 =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M"
          using A7 A8 newton_th_6 sorry
        then have "0NUMBERSK6 =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M"
          using nat_d_def_2 sorry
        thus " False "
          using nat_d_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_12:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
proof(rule ballI,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  let ?l22n = "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)"
  let ?l22np1 = "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)"
  assume A1: "n >XXREAL-0R4 0NUMBERSK6"
  then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
    using nat_1_th_13 sorry
  then have "\<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 n +XCMPLX-0K2 n"
    using xreal_1_th_8 sorry
  then have "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n"
    using xreal_1_th_8 sorry
  then have A2: "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 n))"
    using pre_ff_th_10 sorry
  have "\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n"
    using A1 sorry
  then have "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 n)) =HIDDENR1 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M) +XCMPLX-0K2 ?l22n"
    using power_th_53 sorry
  also have "... = ?l22n +XCMPLX-0K2 \<one>\<^sub>M"
    using power_th_52 sorry
  finally have "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 n)) =HIDDENR1 ?l22n +XCMPLX-0K2 \<one>\<^sub>M"
     sorry
  then have "[\\INT-1K2 ?l22np1/] <=XXREAL-0R1 [\\INT-1K2 ?l22n +XCMPLX-0K2 \<one>\<^sub>M /]"
    using A2 pre_ff_th_9 sorry
  thus "[\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
    using int_1_th_28 sorry
qed "sorry"

mtheorem pre_ff_th_13:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
proof(rule ballI,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  let ?l22n = "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)"
  let ?l22np1 = "logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)"
  assume A1: "n >XXREAL-0R4 0NUMBERSK6"
  then have "[\\INT-1K2 ?l22np1/] <>HIDDENR2 [\\INT-1K2 ?l22n/] +XCMPLX-0K2 \<one>\<^sub>M & [\\INT-1K2 ?l22np1/] <=XXREAL-0R1 [\\INT-1K2 ?l22n/] +XCMPLX-0K2 \<one>\<^sub>M"
    using pre_ff_th_11 pre_ff_th_12 sorry
  then have "[\\INT-1K2 ?l22np1/] <XXREAL-0R3 [\\INT-1K2 ?l22n/] +XCMPLX-0K2 \<one>\<^sub>M"
    using xxreal_0_th_1 sorry
  then have A2: "[\\INT-1K2 ?l22np1/] <=XXREAL-0R1 ([\\INT-1K2 ?l22n/] +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
    using int_1_th_7 sorry
  have "\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n"
    using A1 sorry
  then have "?l22n <=XXREAL-0R1 ?l22np1"
    using pre_ff_th_10 nat_1_th_11 sorry
  then have "[\\INT-1K2 ?l22n/] <=XXREAL-0R1 [\\INT-1K2 ?l22np1/]"
    using pre_ff_th_9 sorry
  thus "[\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/] =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
    using A2 xxreal_0_th_1 sorry
qed "sorry"

mtheorem pre_ff_th_14:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,n)/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
proof(rule ballI,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "n >XXREAL-0R4 0NUMBERSK6"
  then have "[\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/] =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n)/]"
    using pre_ff_th_13 sorry
  also have "... = [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M) +XCMPLX-0K2 logPOWERK3(\<two>\<^sub>M,n) /]"
    using A1 power_th_53 sorry
  also have "... = [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,n) +XCMPLX-0K2 \<one>\<^sub>M /]"
    using power_th_52 sorry
  also have "... = [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,n)/] +XCMPLX-0K2 \<one>\<^sub>M"
    using int_1_th_28 sorry
  finally have "[\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/] =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,n)/] +XCMPLX-0K2 \<one>\<^sub>M"
     sorry
  thus "[\\INT-1K2 logPOWERK3(\<two>\<^sub>M,n)/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [\\INT-1K2 logPOWERK3(\<two>\<^sub>M,\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)/]"
     sorry
qed "sorry"

mlemma pre_ff_lm_1:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  ex y be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 st ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies y =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies y =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
proof-
  have " for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  ex tVar3 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 st ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies tVar3 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies tVar3 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3"
    have "(n +NAT-1K1 \<two>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 or (n +NAT-1K1 \<two>\<^sub>M)modNAT-DK4 \<two>\<^sub>M <>HIDDENR2 0NUMBERSK6"
       sorry
    then obtain y where
      [ty]:"y be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
      A1: "(n +NAT-1K1 \<two>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 & y =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)*>) or (n +NAT-1K1 \<two>\<^sub>M)modNAT-DK4 \<two>\<^sub>M <>HIDDENR2 0NUMBERSK6 & y =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) *>)"
       sorry
    have 
      [ty]:"y be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3"
      using finseq_1_def_11 sorry
    show " ex tVar3 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 st ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies tVar3 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies tVar3 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
    proof(rule bexI[of _ "y"],rule conjMI)
      show " for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies y =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
        then have "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 0NUMBERSK6"
           sorry
        thus "y =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)"
          using A1 nat_d_def_1 nat_d_def_2 sorry
      qed "sorry"
      show " for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies y =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M"
        then have "(n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 k"
          using nat_d_def_1 sorry
        thus "y =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)"
          using A1 A2 nat_d_def_2 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pre_ff_lm_2:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  for y1 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  for y2 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds (( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies y1 =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies y1 =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))) & (( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies y2 =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies y2 =XBOOLE-0R4 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))) implies y1 =FINSEQ-1R1 y2"
proof-
  have " for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  for y1 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds  for y2 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 holds ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies y1 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies y1 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)) implies (( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies y2 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies y2 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)) implies y1 =FINSEQ-1R1 y2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3"
    fix y1 assume [ty]: "y1 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3"
    fix y2 assume [ty]: "y2 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3"
    assume A1: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies y1 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies y1 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
    have "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 ((n +NAT-1K1 \<two>\<^sub>M)modNAT-DK4 \<two>\<^sub>M)"
      using nat_d_th_2 sorry
    then have A2: "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 0NUMBERSK6 or n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      using nat_d_th_12 sorry
    assume "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies y2 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies y2 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
    then have "y1 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)*>) & y2 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)*>) or y1 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) *>) & y2 =FINSEQ-1R1 x ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 x /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) *>)"
      using A1 A2 sorry
    thus "y1 =FINSEQ-1R1 y2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef pre_ff_def_2 ("FuscPRE-FFK2  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func FuscPRE-FFK2 n \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6 if n =XBOOLE-0R4 0NUMBERSK6 otherwise \<lambda>it.  ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & it =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))"
proof-
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds  True "
       sorry
  (*existence*)
    show "(n =XBOOLE-0R4 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it =XBOOLE-0R4 0NUMBERSK6)) & ( not n =XBOOLE-0R4 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & it =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))))"
    proof-
      have "(n =XBOOLE-0R4 0NUMBERSK6 implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k =XBOOLE-0R4 0NUMBERSK6)) & (n <>HIDDENR2 0NUMBERSK6 implies ( ex tVar4 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st  not ( for fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 holds  not (((tVar5 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & tVar4 =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> tVar5)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds  not (n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k &  not fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>))) & ( for k be NatNAT-1M1 holds  not (n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M &  not fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))))))))"
      proof(rule conjMI,rule impI)
        obtain single1 where 
          [ty]:"single1 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3" and single1Def:"single1 = <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>"
          using finseq_1_def_11 sorry
        obtain fusc where
          [ty]:"fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3" and 
          Lm3: "fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 single1"and Lm4: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
          using recdef_1_sch_2 pre_ff_lm_1 sorry
        have Lm5: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
          using Lm4 sorry
        show "n =XBOOLE-0R4 0NUMBERSK6 implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k =XBOOLE-0R4 0NUMBERSK6)"
           sorry
        assume "n <>HIDDENR2 0NUMBERSK6"
        then obtain l where
          [ty]:"l be NatNAT-1M1" and 
          A1: "n =XBOOLE-0R4 l +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_6 sorry
        obtain IT where 
          [ty]:"IT be ElementSUBSET-1M1-of NATNUMBERSK1" and ITDef:"IT = (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n"
           sorry
        obtain l9 where 
          [ty]:"l9 be ElementSUBSET-1M1-of NATNUMBERSK1" and l9Def:"l9 = l"
          using ordinal1_def_12 sorry
        show " ex tVar4 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st  not ( for fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 holds  not (((tVar5 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & tVar4 =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> tVar5)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds  not (n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k &  not fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>))) & ( for k be NatNAT-1M1 holds  not (n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M &  not fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))))))"
        proof(rule bexI[of _ "IT"])
          show " ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st  not ( for fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 holds  not (((tVar5 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & IT =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> tVar5)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds  not (n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k &  not fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>))) & ( for k be NatNAT-1M1 holds  not (n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M &  not fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))))))"
          proof(rule bexI[of _ "l9"])
            show " not ( for fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 holds  not (((l9 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & IT =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l9)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds  not (n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k &  not fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>))) & ( for k be NatNAT-1M1 holds  not (n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M &  not fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))))))"
              using A1 Lm3 Lm5 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (n =XBOOLE-0R4 0NUMBERSK6 implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & ( not n =XBOOLE-0R4 0NUMBERSK6 implies (( ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & it1 =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))) & ( ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & it2 =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))) implies it1 =HIDDENR1 it2))"
    proof-
      have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((n =XBOOLE-0R4 0NUMBERSK6 & n1 =XBOOLE-0R4 0NUMBERSK6) & n2 =XBOOLE-0R4 0NUMBERSK6 implies n1 =XBOOLE-0R4 n2) & (n <>HIDDENR2 0NUMBERSK6 implies (( ex l1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc1 be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & n1 =XBOOLE-0R4 (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))) implies (( ex l2 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc2 be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l2 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & n2 =XBOOLE-0R4 (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l2)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))) implies n1 =HIDDENR1 n2)))"
      proof(rule ballI,rule ballI,rule conjMI,rule impI,rule impI,rule impI)
        obtain single1 where 
          [ty]:"single1 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3" and single1Def:"single1 = <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>"
          using finseq_1_def_11 sorry
        obtain fusc where
          [ty]:"fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3" and 
          Lm3: "fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 single1"and Lm4: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
          using recdef_1_sch_2 pre_ff_lm_1 sorry
        have Lm5: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
          using Lm4 sorry
        fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
        fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
        show "(n =XBOOLE-0R4 0NUMBERSK6 & n1 =XBOOLE-0R4 0NUMBERSK6) & n2 =XBOOLE-0R4 0NUMBERSK6 implies n1 =XBOOLE-0R4 n2"
           sorry
        assume "n <>HIDDENR2 0NUMBERSK6"
        assume Given: " ex l1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc1 be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & n1 =XBOOLE-0R4 (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))"
        then obtain l1 fusc1 where
          [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1" "fusc1 be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3" and 
          A2: "l1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & n1 =XBOOLE-0R4 (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n"and A3: "fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>"and A4: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
           sorry
        have A5: "fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 single1"
          using A3 sorry
        have A6: " for n be NatNAT-1M1 holds ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc1 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
          using A4 sorry
        assume Given: " ex l2 be ElementSUBSET-1M1-of NATNUMBERSK1 st  ex fusc2 be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st ((l2 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & n2 =XBOOLE-0R4 (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l2)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n) & fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>) & ( for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>)))"
        then obtain l2 fusc2 where
          [ty]:"l2 be ElementSUBSET-1M1-of NATNUMBERSK1" "fusc2 be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3" and 
          A7: "l2 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n & n2 =XBOOLE-0R4 (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> l2)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n"and A8: "fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>"and A9: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
           sorry
        have A10: " for n be NatNAT-1M1 holds ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k implies fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 k +NAT-1K1 \<one>\<^sub>M implies fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
          using A9 sorry
        have A11: "fusc2 .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 single1"
          using A8 sorry
        have "fusc1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> fusc2"
          using nat_1_sch_14 A5 A6 A11 A10 pre_ff_lm_2 sorry
        thus "n1 =HIDDENR1 n2"
          using A2 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem pre_ff_th_15:
"(FuscPRE-FFK2 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & FuscPRE-FFK2 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =XBOOLE-0R4 FuscPRE-FFK2 n & FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have "FuscPRE-FFK2 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & (FuscPRE-FFK2 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =XBOOLE-0R4 FuscPRE-FFK2 n & FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)))"
  proof(rule conjMI,rule conjMI,rule ballI)
    obtain single1 where 
      [ty]:"single1 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3" and single1Def:"single1 = <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>"
      using finseq_1_def_11 sorry
    obtain fusc where
      [ty]:"fusc be sequenceNAT-1M2-of NATNUMBERSK1 * FINSEQ-2K3" and 
      Lm3: "fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 single1"and Lm4: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
      using recdef_1_sch_2 pre_ff_lm_1 sorry
    have Lm5: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k*>)) & ( for k be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M implies fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> k +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) *>))"
      using Lm4 sorry
    show A1: "FuscPRE-FFK2 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
      using pre_ff_def_2 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M & \<one>\<^sub>M =XBOOLE-0R4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M"
      using finseq_4_th_16 sorry
    thus "FuscPRE-FFK2 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using pre_ff_def_2 Lm3 Lm5 sorry
    fix n assume [ty]: "n be NatNAT-1M1"
    show "FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =XBOOLE-0R4 FuscPRE-FFK2 n & FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have cases: "n =XBOOLE-0R4 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =XBOOLE-0R4 FuscPRE-FFK2 n & FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule impI)
        assume "n =XBOOLE-0R4 0NUMBERSK6"
        thus "FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =XBOOLE-0R4 FuscPRE-FFK2 n & FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
      qed
      have case2: "n <>HIDDENR2 0NUMBERSK6 implies FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =HIDDENR1 FuscPRE-FFK2 n & FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule impI,rule conjMI)
        assume "n <>HIDDENR2 0NUMBERSK6"
        then obtain l where
          [ty]:"l be NatNAT-1M1" and 
          A2: "n =XBOOLE-0R4 l +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_6 sorry
        let ?P = "\<lambda>Lamb1. lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> Lamb1) =XBOOLE-0R4 Lamb1 +NAT-1K1 \<one>\<^sub>M & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 Lamb1 implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> Lamb1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M))"
        have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for n be NatNAT-1M1 holds lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)) implies lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M))"
          proof(rule ballI,rule impMI ,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume A4: "lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
              and A5: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
            have A6: "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) *>) =XBOOLE-0R4 \<one>\<^sub>M"
              using finseq_1_th_40 sorry
            have "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 ((n +NAT-1K1 \<two>\<^sub>M)modNAT-DK4 \<two>\<^sub>M)"
              using nat_d_th_2 sorry
            then have A7: "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 0NUMBERSK6 or n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
              using nat_d_th_12 sorry
            have A8: "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)*>) =XBOOLE-0R4 \<one>\<^sub>M"
              using finseq_1_th_40 sorry
            show "lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M))"
            proof-
              have cases: "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) or n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
                using A7 sorry
              have case1: "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) implies lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M))"
              proof(rule impI,rule conjMI,rule ballI,rule impI)
                assume "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)"
                then have A9: "fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)*>)"
                  using Lm5 sorry
                thus "lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                  using A4 A8 finseq_1_th_22 sorry
                fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                have A10: "k <=XXREAL-0R1 n implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
                proof(rule impI)
                  assume A11: "k <=XXREAL-0R1 n"
                  then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                    using xreal_1_th_7 sorry
                  then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)"
                    using A4 finseq_3_th_25 sorry
                  then have "(fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                    using A9 finseq_4_th_68 sorry
                  also have "... = FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
                    using A5 A11 sorry
                  finally show "(fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
                     sorry
                qed
                assume "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                then have "k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M or k <=XXREAL-0R1 n"
                  using nat_1_th_8 sorry
                thus "(fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
                  using A10 pre_ff_def_2 Lm3 Lm5 sorry
              qed "sorry"
              have case2: "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M implies lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M))"
              proof(rule impI,rule conjMI,rule ballI,rule impI)
                assume "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
                then have A12: "fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (((n +NAT-1K1 \<two>\<^sub>M)divNAT-DK3 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) *>)"
                  using Lm5 sorry
                thus "lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                  using A4 A6 finseq_1_th_22 sorry
                fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                have A13: "k <=XXREAL-0R1 n implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
                proof(rule impI)
                  assume A14: "k <=XXREAL-0R1 n"
                  then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                    using xreal_1_th_7 sorry
                  then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)"
                    using A4 finseq_3_th_25 sorry
                  then have "(fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> n)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                    using A12 finseq_4_th_68 sorry
                  also have "... = FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
                    using A5 A14 sorry
                  finally show "(fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
                     sorry
                qed
                assume "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                then have "k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M or k <=XXREAL-0R1 n"
                  using nat_1_th_8 sorry
                thus "(fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
                  using A13 pre_ff_def_2 Lm3 Lm5 sorry
              qed "sorry"
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain n1 where 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and n1Def:"n1 = n"
          using ordinal1_def_12 sorry
        have "(\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ((\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
           sorry
        then have A15: "fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 n1) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M) ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n1 +NAT-1K1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (n1 +NAT-1K1 \<one>\<^sub>M) *>)"
          using A2 Lm5 sorry
        have A16: "?P(0NUMBERSK6)"
        proof-
          have "lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6)) =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 0NUMBERSK6 implies (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M))"
          proof(rule conjMI,rule ballI,rule impI)
            show "lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6)) =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
              using Lm3 finseq_1_th_40 sorry
            fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
            assume "k <=XXREAL-0R1 0NUMBERSK6"
            then have "k =XBOOLE-0R4 0NUMBERSK6"
               sorry
            thus "(fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (0NUMBERSK6))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 (k +NAT-1K1 \<one>\<^sub>M)"
              using pre_ff_def_2 Lm3 Lm5 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A17: " for n be NatNAT-1M1 holds ?P(n)"
          using nat_1_sch_2 A16 A3 sorry
        then have A18: "lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 (\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
           sorry
        have A19: "l +NAT-1K1 l =XBOOLE-0R4 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 l"
           sorry
        then have A20: "l <=XXREAL-0R1 \<two>\<^sub>M *NAT-1K2 l"
          using nat_1_th_11 sorry
        then have A21: "FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A2 A17 xreal_1_th_7 sorry
        have A22: "lenFINSEQ-1K4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l)) =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M"
          using A17 sorry
        have "\<two>\<^sub>M *NAT-1K2 l <=XXREAL-0R1 \<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have A23: "FuscPRE-FFK2 n =XBOOLE-0R4 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n"
          using A2 A17 A20 xxreal_0_th_2 sorry
        obtain nn where 
          [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = \<two>\<^sub>M *XCMPLX-0K3 n"
          using ordinal1_def_12 sorry
        have "\<two>\<^sub>M *XCMPLX-0K3 n =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
          using A2 sorry
        then have "fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l) ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n1*>)"
          using Lm5 sorry
        then have "FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =HIDDENR1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l) ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n*>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> ((\<two>\<^sub>M *NAT-1K2 l +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using A2 pre_ff_def_2 Lm3 Lm5 sorry
        also have "... = (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> (\<two>\<^sub>M *NAT-1K2 l))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> n"
          using A22 finseq_4_th_67 sorry
        also have "... = FuscPRE-FFK2 n"
          using A2 A17 A19 nat_1_th_11 sorry
        finally show "FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n) =HIDDENR1 FuscPRE-FFK2 n"
           sorry
        have "FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (fusc .FINSEQ-2K8\<^bsub>(NATNUMBERSK1,NATNUMBERSK1 * FINSEQ-2K3)\<^esub> nn)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)"
          using pre_ff_def_2 Lm3 Lm5 sorry
        also have "... = FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)"
          using A2 A18 A15 A23 A21 finseq_4_th_67 sorry
        finally show "FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_16:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n"
proof-
  have " for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 & \<two>\<^sub>M *XCMPLX-0K3 n <=XXREAL-0R1 n implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
      and A2: "\<two>\<^sub>M *XCMPLX-0K3 n <=XXREAL-0R1 n"
    show " False "
    proof-
      have cases: "\<two>\<^sub>M *XCMPLX-0K3 n =XBOOLE-0R4 n or \<two>\<^sub>M *XCMPLX-0K3 n <XXREAL-0R3 n"
        using A2 xxreal_0_th_1 sorry
      have case1: "\<two>\<^sub>M *XCMPLX-0K3 n =XBOOLE-0R4 n implies  False "
      proof(rule impI)
        assume "\<two>\<^sub>M *XCMPLX-0K3 n =XBOOLE-0R4 n"
        thus " False "
          using A1 sorry
      qed
      have case2: "\<two>\<^sub>M *XCMPLX-0K3 n <XXREAL-0R3 n implies  False "
      proof(rule impI)
        assume "\<two>\<^sub>M *XCMPLX-0K3 n <XXREAL-0R3 n"
        then have "\<two>\<^sub>M *XCMPLX-0K3 n +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 n) <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 n +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 n)"
          using xreal_1_th_6 sorry
        thus " False "
          using nat_1_th_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_17:
" for n be NatNAT-1M1 holds n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n implies  False "
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
    then have "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +XCMPLX-0K2 n"
      using nat_1_th_12 sorry
    thus " False "
      using nat_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_18:
" for A be NatNAT-1M1 holds  for B be NatNAT-1M1 holds B =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (0NUMBERSK6)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 \<one>\<^sub>M)"
  using pre_ff_th_15 sorry

mtheorem pre_ff_th_19:
" for n be NatNAT-1M1 holds  for A be NatNAT-1M1 holds  for B be NatNAT-1M1 holds  for N be NatNAT-1M1 holds FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)) implies FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 (B +XCMPLX-0K2 A)*XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for n be NatNAT-1M1 holds  for A be NatNAT-1M1 holds  for B be NatNAT-1M1 holds  for N be NatNAT-1M1 holds FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)) implies FuscPRE-FFK2 N =HIDDENR1 A *XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 (B +XCMPLX-0K2 A)*XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be NatNAT-1M1"
    fix B assume [ty]: "B be NatNAT-1M1"
    fix N assume [ty]: "N be NatNAT-1M1"
    assume A1: "FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
    have "(\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) & FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)"
      using pre_ff_th_15 sorry
    then have "FuscPRE-FFK2 N =HIDDENR1 (A *XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 A *XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
      using A1 pre_ff_th_15 sorry
    also have "... = A *XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 (B +XCMPLX-0K2 A)*XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    finally show "FuscPRE-FFK2 N =HIDDENR1 A *XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 (B +XCMPLX-0K2 A)*XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_ff_th_20:
" for n be NatNAT-1M1 holds  for A be NatNAT-1M1 holds  for B be NatNAT-1M1 holds  for N be NatNAT-1M1 holds FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)) implies FuscPRE-FFK2 N =XBOOLE-0R4 (A +XCMPLX-0K2 B)*XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for n be NatNAT-1M1 holds  for A be NatNAT-1M1 holds  for B be NatNAT-1M1 holds  for N be NatNAT-1M1 holds FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)) implies FuscPRE-FFK2 N =HIDDENR1 (A +XCMPLX-0K2 B)*XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be NatNAT-1M1"
    fix B assume [ty]: "B be NatNAT-1M1"
    fix N assume [ty]: "N be NatNAT-1M1"
    assume A1: "FuscPRE-FFK2 N =XBOOLE-0R4 A *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n)) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))"
    have "FuscPRE-FFK2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FuscPRE-FFK2 n +NAT-1K1 FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)"
      using pre_ff_th_15 sorry
    then have "FuscPRE-FFK2 N =HIDDENR1 A *XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 (B *XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M)))"
      using A1 pre_ff_th_15 sorry
    also have "... = (A +XCMPLX-0K2 B)*XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    finally show "FuscPRE-FFK2 N =HIDDENR1 (A +XCMPLX-0K2 B)*XCMPLX-0K3 (FuscPRE-FFK2 n) +XCMPLX-0K2 B *XCMPLX-0K3 (FuscPRE-FFK2 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
