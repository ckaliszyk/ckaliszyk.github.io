theory domain_1
  imports ordinal1 mcart_1 partfun1
begin
(*begin*)
reserve a, b, c, d for "setHIDDENM2"
reserve D, X1, X2, X3, X4 for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve x1, y1, z1 for "ElementSUBSET-1M1-of X1"
reserve x2 for "ElementSUBSET-1M1-of X2"
reserve x3 for "ElementSUBSET-1M1-of X3"
reserve x4 for "ElementSUBSET-1M1-of X4"
reserve A1, B1 for "SubsetSUBSET-1M2-of X1"
mtheorem domain_1_th_1:
" for a be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds a inTARSKIR2 [:ZFMISC-1K2 X1,X2 :] implies ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st a =HIDDENR1 [TARSKIK4 x1,x2 ])"
proof-
  have " for a be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds a inTARSKIR2 [:ZFMISC-1K2 X1,X2 :] implies ( ex tVar1 be ElementSUBSET-1M1-of X1 st  ex tVar2 be ElementSUBSET-1M1-of X2 st a =HIDDENR1 [TARSKIK4 tVar1,tVar2 ])"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume "a inTARSKIR2 [:ZFMISC-1K2 X1,X2 :]"
    then obtain x1 x2 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
      A1: "x1 inHIDDENR3 X1"and A2: "x2 inHIDDENR3 X2"and A3: "a =HIDDENR1 [TARSKIK4 x1,x2 ]"
      using zfmisc_1_def_2 sorry
    have 
      [ty]:"x2 be ElementSUBSET-1M1-of X2"
      using A2 sorry
    have 
      [ty]:"x1 be ElementSUBSET-1M1-of X1"
      using A1 sorry
    show " ex tVar1 be ElementSUBSET-1M1-of X1 st  ex tVar2 be ElementSUBSET-1M1-of X2 st a =HIDDENR1 [TARSKIK4 tVar1,tVar2 ]"
    proof(rule bexI[of _ "x1"])
      show " ex tVar2 be ElementSUBSET-1M1-of X2 st a =HIDDENR1 [TARSKIK4 x1,tVar2 ]"
      proof(rule bexI[of _ "x2"])
        show "a =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using A3 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_2:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds  for y be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1 & x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2 implies x =XBOOLE-0R4 y"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds  for y be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds  not ((x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1 & x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2) &  not x =XBOOLE-0R4 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
    have "[TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] =HIDDENR1 x"
       sorry
    thus " not ((x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1 & x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2) &  not x =XBOOLE-0R4 y)"
      using mcart_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax DOMAIN_1K1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[DOMAIN-1K1\<^bsub>'( _ , _ ')\<^esub> _ , _ ]" [0,0,0,0]356)
translations "[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ]" \<rightharpoonup> "[TARSKIK4 x1,x2 ]"

mtheorem domain_1_add_1:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of X1", "x2 be ElementSUBSET-1M1-of X2"
"cluster [TARSKIK4 x1,x2 ] as-term-is ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
proof
(*coherence*)
  show "[TARSKIK4 x1,x2 ] be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
    using zfmisc_1_th_87 sorry
qed "sorry"

syntax DOMAIN_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `1DOMAIN-1K2\<^bsub>'( _ , _ ')\<^esub>" [355,0,0]355)
translations "x `1DOMAIN-1K2\<^bsub>(X1,X2)\<^esub>" \<rightharpoonup> "x `1XTUPLE-0K1"

mtheorem domain_1_add_2:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
"cluster x `1XTUPLE-0K1 as-term-is ElementSUBSET-1M1-of X1"
proof
(*coherence*)
  show "x `1XTUPLE-0K1 be ElementSUBSET-1M1-of X1"
    using mcart_1_th_10 sorry
qed "sorry"

syntax DOMAIN_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `2DOMAIN-1K3\<^bsub>'( _ , _ ')\<^esub>" [355,0,0]355)
translations "x `2DOMAIN-1K3\<^bsub>(X1,X2)\<^esub>" \<rightharpoonup> "x `2XTUPLE-0K2"

mtheorem domain_1_add_3:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
"cluster x `2XTUPLE-0K2 as-term-is ElementSUBSET-1M1-of X2"
proof
(*coherence*)
  show "x `2XTUPLE-0K2 be ElementSUBSET-1M1-of X2"
    using mcart_1_th_10 sorry
qed "sorry"

mtheorem domain_1_th_3:
" for a be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds a inTARSKIR2 [:ZFMISC-1K3 X1,X2,X3 :] iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])"
proof-
  have " for a be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds (a inTARSKIR2 [:ZFMISC-1K3 X1,X2,X3 :] implies ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])) & (( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]) implies a inTARSKIR2 [:ZFMISC-1K3 X1,X2,X3 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    show "a inTARSKIR2 [:ZFMISC-1K3 X1,X2,X3 :] implies ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])"
    proof-
      have "a inTARSKIR2 [:ZFMISC-1K3 X1,X2,X3 :] implies  not ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds  not a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])"
      proof(rule impI)
        assume "a inTARSKIR2 [:ZFMISC-1K3 X1,X2,X3 :]"
        then have "a inTARSKIR2 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
          using zfmisc_1_def_3 sorry
        then obtain x12 x3 where
          [ty]:"x12 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
          A1: "x12 inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"and A2: "x3 inHIDDENR3 X3"and A3: "a =HIDDENR1 [TARSKIK4 x12,x3 ]"
          using zfmisc_1_def_2 sorry
        have 
          [ty]:"x3 be ElementSUBSET-1M1-of X3"
          using A2 sorry
        obtain x1 x2 where
          [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
          A4: "x1 inHIDDENR3 X1"and A5: "x2 inHIDDENR3 X2"and A6: "x12 =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using A1 zfmisc_1_def_2 sorry
        have 
          [ty]:"x2 be ElementSUBSET-1M1-of X2"
          using A5 sorry
        have 
          [ty]:"x1 be ElementSUBSET-1M1-of X1"
          using A4 sorry
        have "a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
          using A3 A6 sorry
        thus " not ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds  not a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
    then obtain x1 x2 x3 where
      [ty]:"x1 be ElementSUBSET-1M1-of X1" "x2 be ElementSUBSET-1M1-of X2" "x3 be ElementSUBSET-1M1-of X3" and 
      A7: "a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
       sorry
    have "a =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>([:ZFMISC-1K2 X1,X2 :],X3)\<^esub> [DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ],x3 ]"
      using A7 sorry
    then have "a inTARSKIR2 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
       sorry
    thus "a inTARSKIR2 [:ZFMISC-1K3 X1,X2,X3 :]"
      using zfmisc_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for a be setHIDDENM2 holds a inTARSKIR2 D iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])) implies D =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :]"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for a be setHIDDENM2 holds a inTARSKIR2 D iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])) implies D =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume A1: " for a be setHIDDENM2 holds a inTARSKIR2 D iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])"
    have " for a be objectHIDDENM1 holds (a inHIDDENR3 D implies a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]) & (a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :] implies a inHIDDENR3 D)"
    proof(rule ballI,rule conjMI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      show "a inHIDDENR3 D implies a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      proof(rule impI)
        assume "a inHIDDENR3 D"
        then obtain x1 x2 x3 where
          [ty]:"x1 be ElementSUBSET-1M1-of X1" "x2 be ElementSUBSET-1M1-of X2" "x3 be ElementSUBSET-1M1-of X3" and 
          A2: "a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
          using A1 sorry
        have "a =HIDDENR1 [DOMAIN-1K1\<^bsub>([:ZFMISC-1K2 X1,X2 :],X3)\<^esub> [DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ],x3 ]"
          using A2 sorry
        thus "a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
           sorry
      qed
      assume "a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      then obtain x12 x3 where
        [ty]:"x12 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
        A3: "x12 inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"and A4: "x3 inHIDDENR3 X3"and A5: "a =HIDDENR1 [TARSKIK4 x12,x3 ]"
        using zfmisc_1_def_2 sorry
      have 
        [ty]:"x3 be ElementSUBSET-1M1-of X3"
        using A4 sorry
      obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A6: "x1 inHIDDENR3 X1"and A7: "x2 inHIDDENR3 X2"and A8: "x12 =HIDDENR1 [TARSKIK4 x1,x2 ]"
        using A3 zfmisc_1_def_2 sorry
      have 
        [ty]:"x2 be ElementSUBSET-1M1-of X2"
        using A7 sorry
      have 
        [ty]:"x1 be ElementSUBSET-1M1-of X1"
        using A6 sorry
      have "a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
        using A5 A8 sorry
      thus "a inHIDDENR3 D"
        using A1 sorry
    qed "sorry"
    then have "D =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      using tarski_th_2 sorry
    thus "D =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :]"
      using zfmisc_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_5:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds D =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :] iff ( for a be setHIDDENM2 holds a inTARSKIR2 D iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]))"
  using domain_1_th_3 domain_1_th_4 sorry

reserve x, y for "ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
syntax DOMAIN_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[DOMAIN-1K4\<^bsub>'( _ , _ , _ ')\<^esub> _ , _ , _ ]" [0,0,0,0,0,0]356)
translations "[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ]" \<rightharpoonup> "[XTUPLE-0K3 x1,x2,x3 ]"

mtheorem domain_1_add_4:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of X1", "x2 be ElementSUBSET-1M1-of X2", "x3 be ElementSUBSET-1M1-of X3"
"cluster [XTUPLE-0K3 x1,x2,x3 ] as-term-is ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
proof
(*coherence*)
  show "[XTUPLE-0K3 x1,x2,x3 ] be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
    using mcart_1_th_69 sorry
qed "sorry"

mtheorem domain_1_th_6:
" for a be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds a =XBOOLE-0R4 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> iff ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds x =XBOOLE-0R4 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] implies a =XBOOLE-0R4 x1)"
  using mcart_1_th_65 sorry

mtheorem domain_1_th_7:
" for b be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds b =XBOOLE-0R4 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> iff ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds x =XBOOLE-0R4 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] implies b =XBOOLE-0R4 x2)"
  using mcart_1_th_66 sorry

mtheorem domain_1_th_8:
" for c be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds c =XBOOLE-0R4 x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> iff ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds x =XBOOLE-0R4 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] implies c =XBOOLE-0R4 x3)"
  using mcart_1_th_67 sorry

mlemma domain_1_lm_1:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds x =XBOOLE-0R4 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
   sorry

mtheorem domain_1_th_9:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds  for y be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds (x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> & x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>) & x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> implies x =XBOOLE-0R4 y"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds  for y be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds  not (((x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> & x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>) & x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>) &  not x =XBOOLE-0R4 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
    have "[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ] =XBOOLE-0R4 x"
       sorry
    thus " not (((x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> & x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>) & x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> =XBOOLE-0R4 y `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>) &  not x =XBOOLE-0R4 y)"
      using domain_1_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_10:
" for a be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds a inTARSKIR2 [:ZFMISC-1K4 X1,X2,X3,X4 :] iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])"
proof-
  have " for a be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds (a inTARSKIR2 [:ZFMISC-1K4 X1,X2,X3,X4 :] implies ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])) & (( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]) implies a inTARSKIR2 [:ZFMISC-1K4 X1,X2,X3,X4 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    show "a inTARSKIR2 [:ZFMISC-1K4 X1,X2,X3,X4 :] implies ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])"
    proof-
      have "a inTARSKIR2 [:ZFMISC-1K4 X1,X2,X3,X4 :] implies  not ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds  for x4 be ElementSUBSET-1M1-of X4 holds  not a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])"
      proof(rule impI)
        assume "a inTARSKIR2 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
        then have "a inTARSKIR2 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
          using zfmisc_1_def_4 sorry
        then obtain x123 x4 where
          [ty]:"x123 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
          A1: "x123 inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :]"and A2: "x4 inHIDDENR3 X4"and A3: "a =HIDDENR1 [TARSKIK4 x123,x4 ]"
          using zfmisc_1_def_2 sorry
        have 
          [ty]:"x4 be ElementSUBSET-1M1-of X4"
          using A2 sorry
        obtain x1 x2 x3 where
          [ty]:"x1 be ElementSUBSET-1M1-of X1" "x2 be ElementSUBSET-1M1-of X2" "x3 be ElementSUBSET-1M1-of X3" and 
          A4: "x123 =HIDDENR1 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ]"
          using A1 domain_1_th_3 sorry
        have "a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
          using A3 A4 sorry
        thus " not ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds  for x4 be ElementSUBSET-1M1-of X4 holds  not a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
    then obtain x1 x2 x3 x4 where
      [ty]:"x1 be ElementSUBSET-1M1-of X1" "x2 be ElementSUBSET-1M1-of X2" "x3 be ElementSUBSET-1M1-of X3" "x4 be ElementSUBSET-1M1-of X4" and 
      A5: "a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
       sorry
    have "a =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>([:ZFMISC-1K3 X1,X2,X3 :],X4)\<^esub> [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ],x4 ]"
      using A5 sorry
    then have "a inTARSKIR2 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
       sorry
    thus "a inTARSKIR2 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
      using zfmisc_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_11:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for a be setHIDDENM2 holds a inTARSKIR2 D iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])) implies D =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for a be setHIDDENM2 holds a inTARSKIR2 D iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])) implies D =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume A1: " for a be setHIDDENM2 holds a inTARSKIR2 D iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])"
    have " for a be objectHIDDENM1 holds (a inHIDDENR3 D implies a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]) & (a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :] implies a inHIDDENR3 D)"
    proof(rule ballI,rule conjMI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      show "a inHIDDENR3 D implies a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      proof(rule impI)
        assume "a inHIDDENR3 D"
        then obtain x1 x2 x3 x4 where
          [ty]:"x1 be ElementSUBSET-1M1-of X1" "x2 be ElementSUBSET-1M1-of X2" "x3 be ElementSUBSET-1M1-of X3" "x4 be ElementSUBSET-1M1-of X4" and 
          A2: "a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
          using A1 sorry
        have "a =HIDDENR1 [DOMAIN-1K1\<^bsub>([:ZFMISC-1K3 X1,X2,X3 :],X4)\<^esub> [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ],x4 ]"
          using A2 sorry
        thus "a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
           sorry
      qed
      assume "a inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      then obtain x123 x4 where
        [ty]:"x123 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
        A3: "x123 inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :]"and A4: "x4 inHIDDENR3 X4"and A5: "a =HIDDENR1 [TARSKIK4 x123,x4 ]"
        using zfmisc_1_def_2 sorry
      have 
        [ty]:"x4 be ElementSUBSET-1M1-of X4"
        using A4 sorry
      obtain x1 x2 x3 where
        [ty]:"x1 be ElementSUBSET-1M1-of X1" "x2 be ElementSUBSET-1M1-of X2" "x3 be ElementSUBSET-1M1-of X3" and 
        A6: "x123 =HIDDENR1 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ]"
        using A3 domain_1_th_3 sorry
      have "a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
        using A5 A6 sorry
      thus "a inHIDDENR3 D"
        using A1 sorry
    qed "sorry"
    then have "D =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      using tarski_th_2 sorry
    thus "D =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
      using zfmisc_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_12:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds D =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :] iff ( for a be setHIDDENM2 holds a inTARSKIR2 D iff ( ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]))"
  using domain_1_th_10 domain_1_th_11 sorry

reserve x for "ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
syntax DOMAIN_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[DOMAIN-1K5\<^bsub>'( _ , _ , _ , _ ')\<^esub> _ , _ , _ , _ ]" [0,0,0,0,0,0,0,0]356)
translations "[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ]" \<rightharpoonup> "[XTUPLE-0K7 x1,x2,x3,x4 ]"

mtheorem domain_1_add_5:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of X1", "x2 be ElementSUBSET-1M1-of X2", "x3 be ElementSUBSET-1M1-of X3", "x4 be ElementSUBSET-1M1-of X4"
"cluster [XTUPLE-0K7 x1,x2,x3,x4 ] as-term-is ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
proof
(*coherence*)
  show "[XTUPLE-0K7 x1,x2,x3,x4 ] be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    using mcart_1_th_80 sorry
qed "sorry"

mtheorem domain_1_th_13:
" for a be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds a =XBOOLE-0R4 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> iff ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds  for x4 be ElementSUBSET-1M1-of X4 holds x =XBOOLE-0R4 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] implies a =XBOOLE-0R4 x1)"
  using mcart_1_th_75 sorry

mtheorem domain_1_th_14:
" for b be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds b =XBOOLE-0R4 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> iff ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds  for x4 be ElementSUBSET-1M1-of X4 holds x =XBOOLE-0R4 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] implies b =XBOOLE-0R4 x2)"
  using mcart_1_th_76 sorry

mtheorem domain_1_th_15:
" for c be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds c =XBOOLE-0R4 x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> iff ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds  for x4 be ElementSUBSET-1M1-of X4 holds x =XBOOLE-0R4 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] implies c =XBOOLE-0R4 x3)"
  using mcart_1_th_77 sorry

mtheorem domain_1_th_16:
" for d be setHIDDENM2 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds d =XBOOLE-0R4 x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> iff ( for x1 be ElementSUBSET-1M1-of X1 holds  for x2 be ElementSUBSET-1M1-of X2 holds  for x3 be ElementSUBSET-1M1-of X3 holds  for x4 be ElementSUBSET-1M1-of X4 holds x =XBOOLE-0R4 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] implies d =XBOOLE-0R4 x4)"
  using mcart_1_th_78 sorry

mlemma domain_1_lm_2:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds x =XBOOLE-0R4 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
   sorry

mtheorem domain_1_th_17:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds  for y be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ((x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> & x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>) & x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>) & x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> implies x =XBOOLE-0R4 y"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds  for y be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds  not ((((x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> & x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>) & x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>) & x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>) &  not x =XBOOLE-0R4 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    have "[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ] =XBOOLE-0R4 x"
       sorry
    thus " not ((((x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> & x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>) & x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>) & x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 y `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>) &  not x =XBOOLE-0R4 y)"
      using domain_1_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve A2 for "SubsetSUBSET-1M2-of X2"
reserve A3 for "SubsetSUBSET-1M2-of X3"
reserve A4 for "SubsetSUBSET-1M2-of X4"
theorem domain_1_sch_1:
  fixes Pp1 
  shows " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) } be SubsetSUBSET-1M2-of X1"
  proof-
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) } be SubsetSUBSET-1M2-of X1"
    proof(rule ballI)
      fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      have "{x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) } c=TARSKIR1 X1"
      proof-
        have "{x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) } c=TARSKIR1 X1"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) } implies a inHIDDENR3 X1"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) }"
            then have " ex x1 be ElementSUBSET-1M1-of X1 st a =HIDDENR1 x1 & Pp1(x1)"
               sorry
            thus "a inHIDDENR3 X1"
               sorry
          qed "sorry"
          thus "{x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) } c=TARSKIR1 X1"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) } be SubsetSUBSET-1M2-of X1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem domain_1_sch_2:
  fixes Pp2 
  shows " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : Pp2(x1,x2) } be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X1,X2 :]"
  proof-
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : Pp2(x1,x2) } be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X1,X2 :]"
    proof(rule ballI,rule ballI)
      fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      have "{[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : Pp2(x1,x2) } c=TARSKIR1 [:ZFMISC-1K2 X1,X2 :]"
      proof-
        have "{[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : Pp2(x1,x2) } c=TARSKIR1 [:ZFMISC-1K2 X1,X2 :]"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : Pp2(x1,x2) } implies a inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : Pp2(x1,x2) }"
            then have " ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st a =HIDDENR1 [DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] & Pp2(x1,x2)"
               sorry
            thus "a inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"
               sorry
          qed "sorry"
          thus "{[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : Pp2(x1,x2) } c=TARSKIR1 [:ZFMISC-1K2 X1,X2 :]"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : Pp2(x1,x2) } be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X1,X2 :]"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem domain_1_sch_3:
  fixes Pp3 
  shows " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : Pp3(x1,x2,x3) } be SubsetSUBSET-1M2-of [:ZFMISC-1K3 X1,X2,X3 :]"
  proof-
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : Pp3(x1,x2,x3) } be SubsetSUBSET-1M2-of [:ZFMISC-1K3 X1,X2,X3 :]"
    proof(rule ballI,rule ballI,rule ballI)
      fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      have "{[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : Pp3(x1,x2,x3) } c=TARSKIR1 [:ZFMISC-1K3 X1,X2,X3 :]"
      proof-
        have "{[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : Pp3(x1,x2,x3) } c=TARSKIR1 [:ZFMISC-1K3 X1,X2,X3 :]"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : Pp3(x1,x2,x3) } implies a inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :]"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : Pp3(x1,x2,x3) }"
            then have " ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st a =HIDDENR1 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] & Pp3(x1,x2,x3)"
               sorry
            thus "a inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :]"
               sorry
          qed "sorry"
          thus "{[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : Pp3(x1,x2,x3) } c=TARSKIR1 [:ZFMISC-1K3 X1,X2,X3 :]"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : Pp3(x1,x2,x3) } be SubsetSUBSET-1M2-of [:ZFMISC-1K3 X1,X2,X3 :]"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem domain_1_sch_4:
  fixes Pp4 
  shows " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : Pp4(x1,x2,x3,x4) } be SubsetSUBSET-1M2-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
  proof-
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : Pp4(x1,x2,x3,x4) } be SubsetSUBSET-1M2-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    proof(rule ballI,rule ballI,rule ballI,rule ballI)
      fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      have "{[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : Pp4(x1,x2,x3,x4) } c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
      proof-
        have "{[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : Pp4(x1,x2,x3,x4) } c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : Pp4(x1,x2,x3,x4) } implies a inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : Pp4(x1,x2,x3,x4) }"
            then have " ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st a =HIDDENR1 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] & Pp4(x1,x2,x3,x4)"
               sorry
            thus "a inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
               sorry
          qed "sorry"
          thus "{[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : Pp4(x1,x2,x3,x4) } c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : Pp4(x1,x2,x3,x4) } be SubsetSUBSET-1M2-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem domain_1_sch_5:
  fixes Pp1 Qp1 
  shows " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds Pp1(x1) implies Qp1(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } c=TARSKIR1 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
  proof-
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds Pp1(x1) implies Qp1(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } c=TARSKIR1 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
    proof(rule ballI,rule impI)
      fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      assume A1: " for x1 be ElementSUBSET-1M1-of X1 holds Pp1(x1) implies Qp1(x1)"
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) } implies a inHIDDENR3 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : Pp1(x1) }"
        then obtain x1 where
          [ty]:"x1 be ElementSUBSET-1M1-of X1" and 
          A2: "a =HIDDENR1 x1"and A3: "Pp1(x1)"
           sorry
        have "Qp1(x1)"
          using A1 A3 sorry
        thus "a inHIDDENR3 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
          using A2 sorry
      qed "sorry"
      thus "{y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } c=TARSKIR1 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
        using tarski_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem domain_1_sch_6:
  fixes Pp1 Qp1 
  shows " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds Pp1(x1) iff Qp1(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } =XBOOLE-0R4 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
  proof-
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds Pp1(x1) iff Qp1(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } =XBOOLE-0R4 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
    proof(rule ballI,rule impI)
      fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      assume A1: " for x1 be ElementSUBSET-1M1-of X1 holds Pp1(x1) iff Qp1(x1)"
      have Cut358: " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds Pp1(x1) implies Qp1(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } c=TARSKIR1 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
        using domain_1_sch_5 sorry
      have "{y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } c=TARSKIR1 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) } & {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) } c=TARSKIR1 {y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) }"
      proof(rule conjMI)
        show "{y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } c=TARSKIR1 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
          using A1 Cut358 sorry
        have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds Qp1(x1) implies Pp1(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : Qp1(y1) } c=TARSKIR1 {z1 where z1 be ElementSUBSET-1M1-of X1 : Pp1(z1) }"
          using domain_1_sch_5 sorry
        thus "{z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) } c=TARSKIR1 {y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) }"
          using A1 sorry
      qed
      thus "{y1 where y1 be ElementSUBSET-1M1-of X1 : Pp1(y1) } =XBOOLE-0R4 {z1 where z1 be ElementSUBSET-1M1-of X1 : Qp1(z1) }"
        using xboole_0_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem domain_1_sch_7:
  fixes Df0 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows "{d where d be ElementSUBSET-1M1-of Df0 : Pp1(d) } be SubsetSUBSET-1M2-of Df0"
  proof-
    have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {d where d be ElementSUBSET-1M1-of D : Pp1(d) } be SubsetSUBSET-1M2-of D"
      using domain_1_sch_1 sorry
    thus "{d where d be ElementSUBSET-1M1-of Df0 : Pp1(d) } be SubsetSUBSET-1M2-of Df0"
       sorry
  qed

mtheorem domain_1_th_18:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds X1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  True  }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds X1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  True  }"
  proof(rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  not  False "
    have A1: " for y1 be ElementSUBSET-1M1-of X1 holds y1 inTARSKIR2 {x1 where x1 be ElementSUBSET-1M1-of X1 :  True  }"
       sorry
    have "{x1 where x1 be ElementSUBSET-1M1-of X1 : ?P(x1) } be SubsetSUBSET-1M2-of X1"
      using domain_1_sch_7 sorry
    thus "X1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  True  }"
      using A1 subset_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_19:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds [:ZFMISC-1K2 X1,X2 :] =XBOOLE-0R4 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 :  True  }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds [:ZFMISC-1K2 X1,X2 :] =XBOOLE-0R4 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 :  True  }"
  proof(rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  not  False "
    have A1: " for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds x inTARSKIR2 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 :  True  }"
    proof-
      have " for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds x inTARSKIR2 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 :  True  }"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
        have "x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x `1DOMAIN-1K2\<^bsub>(X1,X2)\<^esub>,x `2DOMAIN-1K3\<^bsub>(X1,X2)\<^esub> ]"
           sorry
        thus "x inTARSKIR2 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 :  True  }"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : ?P(x1,x2) } be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X1,X2 :]"
      using domain_1_sch_2 sorry
    then have "{[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 :  True  } be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X1,X2 :]"
       sorry
    thus "[:ZFMISC-1K2 X1,X2 :] =XBOOLE-0R4 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 :  True  }"
      using A1 subset_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_20:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds [:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 :  True  }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds [:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 :  True  }"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  not  False "
    have A1: " for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds x inTARSKIR2 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 :  True  }"
    proof-
      have " for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds x inTARSKIR2 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 :  True  }"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
        have "x =XBOOLE-0R4 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
           sorry
        thus "x inTARSKIR2 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 :  True  }"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : ?P(x1,x2,x3) } be SubsetSUBSET-1M2-of [:ZFMISC-1K3 X1,X2,X3 :]"
      using domain_1_sch_3 sorry
    then have "{[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 :  True  } be SubsetSUBSET-1M2-of [:ZFMISC-1K3 X1,X2,X3 :]"
       sorry
    thus "[:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 :  True  }"
      using A1 subset_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_21:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds [:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 :  True  }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds [:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 :  True  }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. \<lambda>Lamb4.  not  False "
    have A1: " for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds x inTARSKIR2 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 :  True  }"
    proof-
      have " for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds x inTARSKIR2 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 :  True  }"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
        have "x =XBOOLE-0R4 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
           sorry
        thus "x inTARSKIR2 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 :  True  }"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ?P(x1,x2,x3,x4) } be SubsetSUBSET-1M2-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
      using domain_1_sch_4 sorry
    then have "{[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 :  True  } be SubsetSUBSET-1M2-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
       sorry
    thus "[:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 :  True  }"
      using A1 subset_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_22:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds A1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds A1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 }"
  proof(rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    have "A1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 } & {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 } c=TARSKIR1 A1"
    proof(rule conjMI)
      show "A1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 }"
         sorry
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 } implies a inHIDDENR3 A1"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st a =HIDDENR1 x1 & x1 inTARSKIR2 A1"
           sorry
        thus "a inHIDDENR3 A1"
           sorry
      qed "sorry"
      thus "{x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 } c=TARSKIR1 A1"
        using tarski_def_3 sorry
    qed
    thus "A1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_23:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for A2 be SubsetSUBSET-1M2-of X2 holds [:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :] =XBOOLE-0R4 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for A2 be SubsetSUBSET-1M2-of X2 holds [:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :] =XBOOLE-0R4 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix A2 assume [ty]: "A2 be SubsetSUBSET-1M2-of X2"
    have "[:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :] c=TARSKIR1 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 } & {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 } c=TARSKIR1 [:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :]"
    proof(rule conjMI)
      show "[:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :] c=TARSKIR1 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
      proof-
        have "[:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :] c=TARSKIR1 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 [:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :] implies a inHIDDENR3 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A1: "a inHIDDENR3 [:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :]"
            then obtain x where 
              [ty]:"x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]" and xDef:"x = a"
               sorry
            have A2: "x =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x `1DOMAIN-1K2\<^bsub>(X1,X2)\<^esub>,x `2DOMAIN-1K3\<^bsub>(X1,X2)\<^esub> ]"
               sorry
            have "x `1DOMAIN-1K2\<^bsub>(X1,X2)\<^esub> inTARSKIR2 A1 & x `2DOMAIN-1K3\<^bsub>(X1,X2)\<^esub> inTARSKIR2 A2"
              using A1 mcart_1_th_10 sorry
            thus "a inHIDDENR3 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
              using A2 sorry
          qed "sorry"
          thus "[:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :] c=TARSKIR1 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 } implies a inHIDDENR3 [:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :]"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st (a =HIDDENR1 [DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] & x1 inTARSKIR2 A1) & x2 inTARSKIR2 A2"
           sorry
        thus "a inHIDDENR3 [:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :]"
          using zfmisc_1_th_87 sorry
      qed "sorry"
      thus "{[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 } c=TARSKIR1 [:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :]"
        using tarski_def_3 sorry
    qed
    thus "[:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :] =XBOOLE-0R4 {[DOMAIN-1K1\<^bsub>(X1,X2)\<^esub> x1,x2 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2 : x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_24:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for A2 be SubsetSUBSET-1M2-of X2 holds  for A3 be SubsetSUBSET-1M2-of X3 holds [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :] =XBOOLE-0R4 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for A2 be SubsetSUBSET-1M2-of X2 holds  for A3 be SubsetSUBSET-1M2-of X3 holds [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :] =XBOOLE-0R4 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix A2 assume [ty]: "A2 be SubsetSUBSET-1M2-of X2"
    fix A3 assume [ty]: "A3 be SubsetSUBSET-1M2-of X3"
    have "[:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :] c=TARSKIR1 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 } & {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 } c=TARSKIR1 [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :]"
    proof(rule conjMI)
      show "[:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :] c=TARSKIR1 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
      proof-
        have "[:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :] c=TARSKIR1 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :] implies a inHIDDENR3 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A1: "a inHIDDENR3 [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :]"
            have 
              [ty]:"A1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X1"
              using A1 mcart_1_th_31 sorry
            have 
              [ty]:"A2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X2"
              using A1 mcart_1_th_31 sorry
            have 
              [ty]:"A3 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X3"
              using A1 mcart_1_th_31 sorry
            have A2: "a inHIDDENR3 [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :]"
              using A1 sorry
            obtain x where 
              [ty]:"x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]" and xDef:"x = a"
              using A2 sorry
            have A3: "x =XBOOLE-0R4 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
               sorry
            have A4: "x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A3"
              using A2 mcart_1_th_72 sorry
            have "x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A1 & x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A2"
              using A2 mcart_1_th_72 sorry
            thus "a inHIDDENR3 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
              using A4 A3 sorry
          qed "sorry"
          thus "[:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :] c=TARSKIR1 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 } implies a inHIDDENR3 [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :]"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st ((a =HIDDENR1 [DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] & x1 inTARSKIR2 A1) & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3"
           sorry
        thus "a inHIDDENR3 [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :]"
          using mcart_1_th_69 sorry
      qed "sorry"
      thus "{[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 } c=TARSKIR1 [:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :]"
        using tarski_def_3 sorry
    qed
    thus "[:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :] =XBOOLE-0R4 {[DOMAIN-1K4\<^bsub>(X1,X2,X3)\<^esub> x1,x2,x3 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3 : (x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_25:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for A2 be SubsetSUBSET-1M2-of X2 holds  for A3 be SubsetSUBSET-1M2-of X3 holds  for A4 be SubsetSUBSET-1M2-of X4 holds [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :] =XBOOLE-0R4 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for A2 be SubsetSUBSET-1M2-of X2 holds  for A3 be SubsetSUBSET-1M2-of X3 holds  for A4 be SubsetSUBSET-1M2-of X4 holds [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :] =XBOOLE-0R4 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix A2 assume [ty]: "A2 be SubsetSUBSET-1M2-of X2"
    fix A3 assume [ty]: "A3 be SubsetSUBSET-1M2-of X3"
    fix A4 assume [ty]: "A4 be SubsetSUBSET-1M2-of X4"
    have "[:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :] c=TARSKIR1 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 } & {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 } c=TARSKIR1 [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :]"
    proof(rule conjMI)
      show "[:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :] c=TARSKIR1 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
      proof-
        have "[:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :] c=TARSKIR1 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :] implies a inHIDDENR3 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A1: "a inHIDDENR3 [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :]"
            have 
              [ty]:"A1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X1"
              using A1 mcart_1_th_51 sorry
            have 
              [ty]:"A2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X2"
              using A1 mcart_1_th_51 sorry
            have 
              [ty]:"A3 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X3"
              using A1 mcart_1_th_51 sorry
            have 
              [ty]:"A4 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X4"
              using A1 mcart_1_th_51 sorry
            have A2: "a inHIDDENR3 [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :]"
              using A1 sorry
            then obtain x where 
              [ty]:"x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]" and xDef:"x = a"
               sorry
            have A3: "x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A3 & x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A4"
              using A2 mcart_1_th_83 sorry
            have A4: "x =XBOOLE-0R4 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
               sorry
            have "x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A1 & x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A2"
              using A2 mcart_1_th_83 sorry
            thus "a inHIDDENR3 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
              using A4 A3 sorry
          qed "sorry"
          thus "[:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :] c=TARSKIR1 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 } implies a inHIDDENR3 [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :]"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st  ex x2 be ElementSUBSET-1M1-of X2 st  ex x3 be ElementSUBSET-1M1-of X3 st  ex x4 be ElementSUBSET-1M1-of X4 st (((a =HIDDENR1 [DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] & x1 inTARSKIR2 A1) & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4"
           sorry
        thus "a inHIDDENR3 [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :]"
          using mcart_1_th_80 sorry
      qed "sorry"
      thus "{[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 } c=TARSKIR1 [:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :]"
        using tarski_def_3 sorry
    qed
    thus "[:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :] =XBOOLE-0R4 {[DOMAIN-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> x1,x2,x3,x4 ] where x1 be ElementSUBSET-1M1-of X1, x2 be ElementSUBSET-1M1-of X2, x3 be ElementSUBSET-1M1-of X3, x4 be ElementSUBSET-1M1-of X4 : ((x1 inTARSKIR2 A1 & x2 inTARSKIR2 A2) & x3 inTARSKIR2 A3) & x4 inTARSKIR2 A4 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_26:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {}SUBSET-1K1 X1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  False  }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {}SUBSET-1K1 X1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not  True  }"
  proof(rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have "{}SUBSET-1K1 X1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  False  } & {x1 where x1 be ElementSUBSET-1M1-of X1 :  not  True  } c=TARSKIR1 {}SUBSET-1K1 X1"
    proof(rule conjMI)
      show "{}SUBSET-1K1 X1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  False  }"
         sorry
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  False  } implies a inHIDDENR3 {}SUBSET-1K1 X1"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  False  }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st a =HIDDENR1 x1 &  False "
           sorry
        thus "a inHIDDENR3 {}SUBSET-1K1 X1"
           sorry
      qed "sorry"
      thus "{x1 where x1 be ElementSUBSET-1M1-of X1 :  not  True  } c=TARSKIR1 {}SUBSET-1K1 X1"
        using tarski_def_3 sorry
    qed
    thus "{}SUBSET-1K1 X1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not  True  }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_27:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds A1 `SUBSET-1K3\<^bsub>(X1)\<^esub> =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds A1 `SUBSET-1K3\<^bsub>(X1)\<^esub> =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
  proof(rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    have "A1 `SUBSET-1K3\<^bsub>(X1)\<^esub> c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 } & {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 } c=TARSKIR1 A1 `SUBSET-1K3\<^bsub>(X1)\<^esub>"
    proof(rule conjMI)
      show "A1 `SUBSET-1K3\<^bsub>(X1)\<^esub> c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
      proof-
        have "A1 `SUBSET-1K3\<^bsub>(X1)\<^esub> c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 A1 `SUBSET-1K3\<^bsub>(X1)\<^esub> implies a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A1: "a inHIDDENR3 A1 `SUBSET-1K3\<^bsub>(X1)\<^esub>"
            then have " not a inHIDDENR3 A1"
              using xboole_0_def_5 sorry
            thus "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
              using A1 sorry
          qed "sorry"
          thus "A1 `SUBSET-1K3\<^bsub>(X1)\<^esub> c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 } implies a inHIDDENR3 A1 `SUBSET-1K3\<^bsub>(X1)\<^esub>"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st a =HIDDENR1 x1 &  not x1 inTARSKIR2 A1"
           sorry
        thus "a inHIDDENR3 A1 `SUBSET-1K3\<^bsub>(X1)\<^esub>"
          using subset_1_th_29 sorry
      qed "sorry"
      thus "{x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 } c=TARSKIR1 A1 `SUBSET-1K3\<^bsub>(X1)\<^esub>"
        using tarski_def_3 sorry
    qed
    thus "A1 `SUBSET-1K3\<^bsub>(X1)\<^esub> =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_28:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix B1 assume [ty]: "B1 be SubsetSUBSET-1M2-of X1"
    have "A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 } & {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 } c=TARSKIR1 A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1"
    proof(rule conjMI)
      show "A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
      proof-
        have "A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1 implies a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A1: "a inHIDDENR3 A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1"
            then obtain x where 
              [ty]:"x be ElementSUBSET-1M1-of X1" and xDef:"x = a"
               sorry
            have "x inTARSKIR2 A1 & x inTARSKIR2 B1"
              using A1 xboole_0_def_4 sorry
            thus "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
               sorry
          qed "sorry"
          thus "A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 } implies a inHIDDENR3 A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st (a =HIDDENR1 x1 & x1 inTARSKIR2 A1) & x1 inTARSKIR2 B1"
           sorry
        thus "a inHIDDENR3 A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1"
          using xboole_0_def_4 sorry
      qed "sorry"
      thus "{x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 } c=TARSKIR1 A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1"
        using tarski_def_3 sorry
    qed
    thus "A1 /\\SUBSET-1K9\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_29:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 or x1 inTARSKIR2 B1 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) }"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix B1 assume [ty]: "B1 be SubsetSUBSET-1M2-of X1"
    have "A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 or x1 inTARSKIR2 B1 } & {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) } c=TARSKIR1 A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1"
    proof(rule conjMI)
      show "A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 or x1 inTARSKIR2 B1 }"
      proof-
        have "A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) }"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1 implies a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) }"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A1: "a inHIDDENR3 A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1"
            then obtain x where 
              [ty]:"x be ElementSUBSET-1M1-of X1" and xDef:"x = a"
               sorry
            have "x inTARSKIR2 A1 or x inTARSKIR2 B1"
              using A1 xboole_0_def_3 sorry
            thus "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) }"
               sorry
          qed "sorry"
          thus "A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 or x1 inTARSKIR2 B1 } implies a inHIDDENR3 A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 or x1 inTARSKIR2 B1 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st a =HIDDENR1 x1 & (x1 inTARSKIR2 A1 or x1 inTARSKIR2 B1)"
           sorry
        thus "a inHIDDENR3 A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "{x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) } c=TARSKIR1 A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1"
        using tarski_def_3 sorry
    qed
    thus "A1 \\/SUBSET-1K4\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_30:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix B1 assume [ty]: "B1 be SubsetSUBSET-1M2-of X1"
    have "A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 } & {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 } c=TARSKIR1 A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1"
    proof(rule conjMI)
      show "A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
      proof-
        have "A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1 implies a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A1: "a inHIDDENR3 A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1"
            then obtain x where 
              [ty]:"x be ElementSUBSET-1M1-of X1" and xDef:"x = a"
               sorry
            have "x inTARSKIR2 A1 &  not x inTARSKIR2 B1"
              using A1 xboole_0_def_5 sorry
            thus "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
               sorry
          qed "sorry"
          thus "A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 } implies a inHIDDENR3 A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st (a =HIDDENR1 x1 & x1 inTARSKIR2 A1) &  not x1 inTARSKIR2 B1"
           sorry
        thus "a inHIDDENR3 A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1"
          using xboole_0_def_5 sorry
      qed "sorry"
      thus "{x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 } c=TARSKIR1 A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1"
        using tarski_def_3 sorry
    qed
    thus "A1 \\SUBSET-1K7\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_31:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 or  not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)) }"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix B1 assume [ty]: "B1 be SubsetSUBSET-1M2-of X1"
    have "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 or  not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 } & {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)) } c=TARSKIR1 A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1"
    proof(rule conjMI)
      show "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 or  not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
      proof-
        have "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)) }"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 implies a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)) }"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A1: "a inHIDDENR3 A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1"
            then obtain x where 
              [ty]:"x be ElementSUBSET-1M1-of X1" and xDef:"x = a"
               sorry
            have "x inTARSKIR2 A1 &  not x inTARSKIR2 B1 or  not x inTARSKIR2 A1 & x inTARSKIR2 B1"
              using A1 xboole_0_th_1 sorry
            thus "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)) }"
               sorry
          qed "sorry"
          thus "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 c=TARSKIR1 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)) }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 or  not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 } implies a inHIDDENR3 A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 or  not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
        then have " ex x1 be ElementSUBSET-1M1-of X1 st a =HIDDENR1 x1 & (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 or  not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)"
           sorry
        thus "a inHIDDENR3 A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1"
          using xboole_0_th_1 sorry
      qed "sorry"
      thus "{x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)) } c=TARSKIR1 A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1"
        using tarski_def_3 sorry
    qed
    thus "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1)) }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_32:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 iff x1 inTARSKIR2 B1 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not (x1 inTARSKIR2 B1 & x1 inTARSKIR2 A1) }"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix B1 assume [ty]: "B1 be SubsetSUBSET-1M2-of X1"
    have A1: " for x1 be ElementSUBSET-1M1-of X1 holds x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 or  not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 iff ( not x1 inTARSKIR2 A1 iff x1 inTARSKIR2 B1)"
       sorry
    let ?Q = "\<lambda>Lamb1.  not Lamb1 inTARSKIR2 A1 iff Lamb1 inTARSKIR2 B1"
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A1 &  not Lamb1 inTARSKIR2 B1 or  not Lamb1 inTARSKIR2 A1 & Lamb1 inTARSKIR2 B1"
    have A2: "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1 or  not x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1 }"
      using domain_1_th_31 sorry
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds ?P(x1) iff ?Q(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : ?P(y1) } =XBOOLE-0R4 {z1 where z1 be ElementSUBSET-1M1-of X1 : ?Q(z1) }"
      using domain_1_sch_6 sorry
    thus "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not (x1 inTARSKIR2 B1 & x1 inTARSKIR2 A1) }"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_33:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 : x1 inTARSKIR2 A1 iff  not x1 inTARSKIR2 B1 }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not (x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 B1 &  not x1 inTARSKIR2 A1) }"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix B1 assume [ty]: "B1 be SubsetSUBSET-1M2-of X1"
    have A1: " for x1 be ElementSUBSET-1M1-of X1 holds ( not x1 inTARSKIR2 A1 iff x1 inTARSKIR2 B1) iff (x1 inTARSKIR2 A1 iff  not x1 inTARSKIR2 B1)"
       sorry
    let ?Q = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A1 iff  not Lamb1 inTARSKIR2 B1"
    let ?P = "\<lambda>Lamb1.  not Lamb1 inTARSKIR2 A1 iff Lamb1 inTARSKIR2 B1"
    have A2: "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 iff x1 inTARSKIR2 B1 }"
      using domain_1_th_32 sorry
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds ?P(x1) iff ?Q(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : ?P(y1) } =XBOOLE-0R4 {z1 where z1 be ElementSUBSET-1M1-of X1 : ?Q(z1) }"
      using domain_1_sch_6 sorry
    thus "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not (x1 inTARSKIR2 A1 & x1 inTARSKIR2 B1) &  not ( not x1 inTARSKIR2 B1 &  not x1 inTARSKIR2 A1) }"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem domain_1_th_34:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not (x1 inTARSKIR2 A1 iff x1 inTARSKIR2 B1) }"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be SubsetSUBSET-1M2-of X1 holds  for B1 be SubsetSUBSET-1M2-of X1 holds A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not (x1 inTARSKIR2 B1 &  not x1 inTARSKIR2 A1)) }"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of X1"
    fix B1 assume [ty]: "B1 be SubsetSUBSET-1M2-of X1"
    have A1: " for x1 be ElementSUBSET-1M1-of X1 holds ( not x1 inTARSKIR2 A1 iff x1 inTARSKIR2 B1) iff  not (x1 inTARSKIR2 A1 iff x1 inTARSKIR2 B1)"
       sorry
    let ?Q = "\<lambda>Lamb1.  not (Lamb1 inTARSKIR2 A1 iff Lamb1 inTARSKIR2 B1)"
    let ?P = "\<lambda>Lamb1.  not Lamb1 inTARSKIR2 A1 iff Lamb1 inTARSKIR2 B1"
    have A2: "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not x1 inTARSKIR2 A1 iff x1 inTARSKIR2 B1 }"
      using domain_1_th_32 sorry
    have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x1 be ElementSUBSET-1M1-of X1 holds ?P(x1) iff ?Q(x1)) implies {y1 where y1 be ElementSUBSET-1M1-of X1 : ?P(y1) } =XBOOLE-0R4 {z1 where z1 be ElementSUBSET-1M1-of X1 : ?Q(z1) }"
      using domain_1_sch_6 sorry
    thus "A1 \\+\\SUBSET-1K5\<^bsub>(X1)\<^esub> B1 =XBOOLE-0R4 {x1 where x1 be ElementSUBSET-1M1-of X1 :  not ( not (x1 inTARSKIR2 A1 &  not x1 inTARSKIR2 B1) &  not (x1 inTARSKIR2 B1 &  not x1 inTARSKIR2 A1)) }"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax DOMAIN_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("{DOMAIN-1K6\<^bsub>'( _ ')\<^esub>  _ }" [0,0]356)
translations "{DOMAIN-1K6\<^bsub>(D)\<^esub> x1}" \<rightharpoonup> "{TARSKIK1 x1}"

mtheorem domain_1_add_6:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D"
"cluster {TARSKIK1 x1} as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "{TARSKIK1 x1} be SubsetSUBSET-1M2-of D"
    using subset_1_th_33 sorry
qed "sorry"

syntax DOMAIN_1K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{DOMAIN-1K7\<^bsub>'( _ ')\<^esub> _ , _ }" [0,0,0]356)
translations "{DOMAIN-1K7\<^bsub>(D)\<^esub> x1,x2 }" \<rightharpoonup> "{TARSKIK2 x1,x2 }"

mtheorem domain_1_add_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D"
"cluster {TARSKIK2 x1,x2 } as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "{TARSKIK2 x1,x2 } be SubsetSUBSET-1M2-of D"
    using subset_1_th_34 sorry
qed "sorry"

syntax DOMAIN_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{DOMAIN-1K8\<^bsub>'( _ ')\<^esub> _ , _ , _ }" [0,0,0,0]356)
translations "{DOMAIN-1K8\<^bsub>(D)\<^esub> x1,x2,x3 }" \<rightharpoonup> "{ENUMSET1K1 x1,x2,x3 }"

mtheorem domain_1_add_8:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D", "x3 be ElementSUBSET-1M1-of D"
"cluster {ENUMSET1K1 x1,x2,x3 } as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "{ENUMSET1K1 x1,x2,x3 } be SubsetSUBSET-1M2-of D"
    using subset_1_th_35 sorry
qed "sorry"

syntax DOMAIN_1K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{DOMAIN-1K9\<^bsub>'( _ ')\<^esub> _ , _ , _ , _ }" [0,0,0,0,0]356)
translations "{DOMAIN-1K9\<^bsub>(D)\<^esub> x1,x2,x3,x4 }" \<rightharpoonup> "{ENUMSET1K2 x1,x2,x3,x4 }"

mtheorem domain_1_add_9:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D", "x3 be ElementSUBSET-1M1-of D", "x4 be ElementSUBSET-1M1-of D"
"cluster {ENUMSET1K2 x1,x2,x3,x4 } as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "{ENUMSET1K2 x1,x2,x3,x4 } be SubsetSUBSET-1M2-of D"
    using subset_1_th_36 sorry
qed "sorry"

syntax DOMAIN_1K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{DOMAIN-1K10\<^bsub>'( _ ')\<^esub> _ , _ , _ , _ , _ }" [0,0,0,0,0,0]356)
translations "{DOMAIN-1K10\<^bsub>(D)\<^esub> x1,x2,x3,x4,x5 }" \<rightharpoonup> "{ENUMSET1K3 x1,x2,x3,x4,x5 }"

mtheorem domain_1_add_10:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D", "x3 be ElementSUBSET-1M1-of D", "x4 be ElementSUBSET-1M1-of D", "x5 be ElementSUBSET-1M1-of D"
"cluster {ENUMSET1K3 x1,x2,x3,x4,x5 } as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "{ENUMSET1K3 x1,x2,x3,x4,x5 } be SubsetSUBSET-1M2-of D"
    using subset_1_th_37 sorry
qed "sorry"

syntax DOMAIN_1K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{DOMAIN-1K11\<^bsub>'( _ ')\<^esub> _ , _ , _ , _ , _ , _ }" [0,0,0,0,0,0,0]356)
translations "{DOMAIN-1K11\<^bsub>(D)\<^esub> x1,x2,x3,x4,x5,x6 }" \<rightharpoonup> "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"

mtheorem domain_1_add_11:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D", "x3 be ElementSUBSET-1M1-of D", "x4 be ElementSUBSET-1M1-of D", "x5 be ElementSUBSET-1M1-of D", "x6 be ElementSUBSET-1M1-of D"
"cluster {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } be SubsetSUBSET-1M2-of D"
    using subset_1_th_38 sorry
qed "sorry"

syntax DOMAIN_1K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{DOMAIN-1K12\<^bsub>'( _ ')\<^esub> _ , _ , _ , _ , _ , _ , _ }" [0,0,0,0,0,0,0,0]356)
translations "{DOMAIN-1K12\<^bsub>(D)\<^esub> x1,x2,x3,x4,x5,x6,x7 }" \<rightharpoonup> "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 }"

mtheorem domain_1_add_12:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D", "x3 be ElementSUBSET-1M1-of D", "x4 be ElementSUBSET-1M1-of D", "x5 be ElementSUBSET-1M1-of D", "x6 be ElementSUBSET-1M1-of D", "x7 be ElementSUBSET-1M1-of D"
"cluster {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } be SubsetSUBSET-1M2-of D"
    using subset_1_th_39 sorry
qed "sorry"

syntax DOMAIN_1K13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{DOMAIN-1K13\<^bsub>'( _ ')\<^esub> _ , _ , _ , _ , _ , _ , _ , _ }" [0,0,0,0,0,0,0,0,0]356)
translations "{DOMAIN-1K13\<^bsub>(D)\<^esub> x1,x2,x3,x4,x5,x6,x7,x8 }" \<rightharpoonup> "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 }"

mtheorem domain_1_add_13:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D", "x3 be ElementSUBSET-1M1-of D", "x4 be ElementSUBSET-1M1-of D", "x5 be ElementSUBSET-1M1-of D", "x6 be ElementSUBSET-1M1-of D", "x7 be ElementSUBSET-1M1-of D", "x8 be ElementSUBSET-1M1-of D"
"cluster {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } be SubsetSUBSET-1M2-of D"
    using subset_1_th_40 sorry
qed "sorry"

(*begin*)
theorem domain_1_sch_8:
  fixes Af0 Df0 Ff1 Pp1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0"
  shows "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } be SubsetSUBSET-1M2-of Df0"
  proof-
    let ?X = "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) }"
    have "?X c=TARSKIR1 Df0"
    proof-
      have "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } c=TARSKIR1 Df0"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 {Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } implies y inHIDDENR3 Df0"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 ?X"
          then have " ex z be ElementSUBSET-1M1-of Af0 st y =HIDDENR1 Ff1(z) & Pp1(z)"
             sorry
          thus "y inHIDDENR3 Df0"
             sorry
        qed "sorry"
        thus "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } c=TARSKIR1 Df0"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } be SubsetSUBSET-1M2-of Df0"
       sorry
  qed

theorem domain_1_sch_9:
  fixes Af0 Bf0 Df0 Ff2 Pp2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Df0"
  shows "{Ff2(x,y) where x be ElementSUBSET-1M1-of Af0, y be ElementSUBSET-1M1-of Bf0 : Pp2(x,y) } be SubsetSUBSET-1M2-of Df0"
  proof-
    let ?X = "{Ff2(x,y) where x be ElementSUBSET-1M1-of Af0, y be ElementSUBSET-1M1-of Bf0 : Pp2(x,y) }"
    have "?X c=TARSKIR1 Df0"
    proof-
      have "{Ff2(x,y) where x be ElementSUBSET-1M1-of Af0, y be ElementSUBSET-1M1-of Bf0 : Pp2(x,y) } c=TARSKIR1 Df0"
      proof-
        have " for w be objectHIDDENM1 holds w inHIDDENR3 {Ff2(x,y) where x be ElementSUBSET-1M1-of Af0, y be ElementSUBSET-1M1-of Bf0 : Pp2(x,y) } implies w inHIDDENR3 Df0"
        proof(rule ballI,rule impI)
          fix w assume [ty]: "w be objectHIDDENM1"
          assume "w inHIDDENR3 ?X"
          then have " ex x be ElementSUBSET-1M1-of Af0 st  ex y be ElementSUBSET-1M1-of Bf0 st w =HIDDENR1 Ff2(x,y) & Pp2(x,y)"
             sorry
          thus "w inHIDDENR3 Df0"
             sorry
        qed "sorry"
        thus "{Ff2(x,y) where x be ElementSUBSET-1M1-of Af0, y be ElementSUBSET-1M1-of Bf0 : Pp2(x,y) } c=TARSKIR1 Df0"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "{Ff2(x,y) where x be ElementSUBSET-1M1-of Af0, y be ElementSUBSET-1M1-of Bf0 : Pp2(x,y) } be SubsetSUBSET-1M2-of Df0"
       sorry
  qed

syntax DOMAIN_1K14 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `11DOMAIN-1K14\<^bsub>'( _ , _ , _ ')\<^esub>" [355,0,0,0]355)
translations "x `11DOMAIN-1K14\<^bsub>(D1,D2,D3)\<^esub>" \<rightharpoonup> "x `11MCART-1K13"

mtheorem domain_1_add_14:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 [:ZFMISC-1K2 D1,D2 :],D3 :]"
"cluster x `11MCART-1K13 as-term-is ElementSUBSET-1M1-of D1"
proof
(*coherence*)
  show "x `11MCART-1K13 be ElementSUBSET-1M1-of D1"
  proof-
    have "x `11MCART-1K13 =XBOOLE-0R4 (x `1DOMAIN-1K2\<^bsub>([:ZFMISC-1K2 D1,D2 :],D3)\<^esub>)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub>"
      using mcart_1_def_14 sorry
    thus "x `11MCART-1K13 be ElementSUBSET-1M1-of D1"
       sorry
  qed
qed "sorry"

syntax DOMAIN_1K15 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `12DOMAIN-1K15\<^bsub>'( _ , _ , _ ')\<^esub>" [355,0,0,0]355)
translations "x `12DOMAIN-1K15\<^bsub>(D1,D2,D3)\<^esub>" \<rightharpoonup> "x `12MCART-1K14"

mtheorem domain_1_add_15:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 [:ZFMISC-1K2 D1,D2 :],D3 :]"
"cluster x `12MCART-1K14 as-term-is ElementSUBSET-1M1-of D2"
proof
(*coherence*)
  show "x `12MCART-1K14 be ElementSUBSET-1M1-of D2"
  proof-
    have "x `12MCART-1K14 =XBOOLE-0R4 (x `1DOMAIN-1K2\<^bsub>([:ZFMISC-1K2 D1,D2 :],D3)\<^esub>)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub>"
      using mcart_1_def_15 sorry
    thus "x `12MCART-1K14 be ElementSUBSET-1M1-of D2"
       sorry
  qed
qed "sorry"

syntax DOMAIN_1K16 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `21DOMAIN-1K16\<^bsub>'( _ , _ , _ ')\<^esub>" [355,0,0,0]355)
translations "x `21DOMAIN-1K16\<^bsub>(D1,D2,D3)\<^esub>" \<rightharpoonup> "x `21MCART-1K15"

mtheorem domain_1_add_16:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 D1,[:ZFMISC-1K2 D2,D3 :] :]"
"cluster x `21MCART-1K15 as-term-is ElementSUBSET-1M1-of D2"
proof
(*coherence*)
  show "x `21MCART-1K15 be ElementSUBSET-1M1-of D2"
  proof-
    have "x `21MCART-1K15 =XBOOLE-0R4 (x `2DOMAIN-1K3\<^bsub>(D1,[:ZFMISC-1K2 D2,D3 :])\<^esub>)`1DOMAIN-1K2\<^bsub>(D2,D3)\<^esub>"
      using mcart_1_def_16 sorry
    thus "x `21MCART-1K15 be ElementSUBSET-1M1-of D2"
       sorry
  qed
qed "sorry"

syntax DOMAIN_1K17 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `22DOMAIN-1K17\<^bsub>'( _ , _ , _ ')\<^esub>" [355,0,0,0]355)
translations "x `22DOMAIN-1K17\<^bsub>(D1,D2,D3)\<^esub>" \<rightharpoonup> "x `22MCART-1K16"

mtheorem domain_1_add_17:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 D1,[:ZFMISC-1K2 D2,D3 :] :]"
"cluster x `22MCART-1K16 as-term-is ElementSUBSET-1M1-of D3"
proof
(*coherence*)
  show "x `22MCART-1K16 be ElementSUBSET-1M1-of D3"
  proof-
    have "x `22MCART-1K16 =XBOOLE-0R4 (x `2DOMAIN-1K3\<^bsub>(D1,[:ZFMISC-1K2 D2,D3 :])\<^esub>)`2DOMAIN-1K3\<^bsub>(D2,D3)\<^esub>"
      using mcart_1_def_17 sorry
    thus "x `22MCART-1K16 be ElementSUBSET-1M1-of D3"
       sorry
  qed
qed "sorry"

theorem domain_1_sch_10:
  fixes Af0 Pp1 Qp1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows "{a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) } =XBOOLE-0R4 ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) })"
  proof-
    let ?A = "{a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) }"
    let ?A1 = "{a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) }"
    let ?A2 = "{a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) }"
    have "{a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) } c=TARSKIR1 ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) }) & ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) }) c=TARSKIR1 {a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) }"
    proof(rule conjMI)
      show "{a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) } c=TARSKIR1 ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) })"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) } implies x inHIDDENR3 ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) })"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?A"
          then obtain a where
            [ty]:"a be ElementSUBSET-1M1-of Af0" and 
            A1: "x =HIDDENR1 a"and A2: "Pp1(a) & Qp1(a)"
             sorry
          have "a inTARSKIR2 ?A1 & a inTARSKIR2 ?A2"
            using A2 sorry
          thus "x inHIDDENR3 ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) })"
            using A1 xboole_0_def_4 sorry
        qed "sorry"
        thus "{a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) } c=TARSKIR1 ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) })"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) }) implies x inHIDDENR3 {a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 ?A1 /\\XBOOLE-0K3 ?A2"
        then have "x inHIDDENR3 ?A2"
          using xboole_0_def_4 sorry
        then have A4: " ex a be ElementSUBSET-1M1-of Af0 st x =HIDDENR1 a & Qp1(a)"
           sorry
        have "x inHIDDENR3 ?A1"
          using A3 xboole_0_def_4 sorry
        then have " ex a be ElementSUBSET-1M1-of Af0 st x =HIDDENR1 a & Pp1(a)"
           sorry
        thus "x inHIDDENR3 {a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) }"
          using A4 sorry
      qed "sorry"
      thus "({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) }) c=TARSKIR1 {a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) }"
        using tarski_def_3 sorry
    qed
    thus "{a where a be ElementSUBSET-1M1-of Af0 : Pp1(a) & Qp1(a) } =XBOOLE-0R4 ({a1 where a1 be ElementSUBSET-1M1-of Af0 : Pp1(a1) })/\\XBOOLE-0K3 ({a2 where a2 be ElementSUBSET-1M1-of Af0 : Qp1(a2) })"
      using xboole_0_def_10 sorry
  qed

mtheorem domain_1_cl_1:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster c=-linearORDINAL1V6\<bar> non emptyXBOOLE-0V1 for SubsetSUBSET-1M2-of A"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of A st it be c=-linearORDINAL1V6\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar3 be SubsetSUBSET-1M2-of A st tVar3 be c=-linearORDINAL1V6 &  not tVar3 be emptyXBOOLE-0V1"
    proof-
      let ?a = "the ElementSUBSET-1M1-of A"
      obtain B where 
        [ty]:"B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A" and BDef:"B = {DOMAIN-1K6\<^bsub>(A)\<^esub> ?a}"
         sorry
      show " ex tVar3 be SubsetSUBSET-1M2-of A st tVar3 be c=-linearORDINAL1V6 &  not tVar3 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "B"])
        have "B be c=-linearORDINAL1V6"
        proof-
          have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 B & y inTARSKIR2 B implies (x,y)are-c=-comparableXBOOLE-0R3"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be setHIDDENM2"
            fix y assume [ty]: "y be setHIDDENM2"
            assume A1: "x inTARSKIR2 B"
              and A2: "y inTARSKIR2 B"
            have "x =XBOOLE-0R4 ?a"
              using A1 tarski_def_1 sorry
            thus "(x,y)are-c=-comparableXBOOLE-0R3"
              using A2 tarski_def_1 sorry
          qed "sorry"
          thus "B be c=-linearORDINAL1V6"
            using ordinal1_def_8 sorry
        qed
        thus "B be c=-linearORDINAL1V6 &  not B be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

end
