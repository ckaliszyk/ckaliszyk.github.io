theory seq_1
  imports valued_1 absvalue
   "../mizar_extension/E_number"
begin
(*begin*)
reserve f for "FunctionFUNCT-1M1"
reserve n, k, n1 for "NatNAT-1M1"
reserve r, p for "RealXREAL-0M1"
reserve x, y, z for "objectHIDDENM1"
syntax SEQ_1M1 :: "Ty" ("Real-SequenceSEQ-1M1" 70)
translations "Real-SequenceSEQ-1M1" \<rightharpoonup> "sequenceNAT-1M2-of REALNUMBERSK2"

reserve seq, seq1, seq2, seq3, seq9, seq19 for "Real-SequenceSEQ-1M1"
mtheorem seq_1_th_1:
" for f be FunctionFUNCT-1M1 holds f be Real-SequenceSEQ-1M1 iff domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x be realXREAL-0V1)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be Real-SequenceSEQ-1M1 implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x be realXREAL-0V1)) & (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x be realXREAL-0V1) implies f be Real-SequenceSEQ-1M1)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be Real-SequenceSEQ-1M1 implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x be realXREAL-0V1)"
      using funct_2_def_1 sorry
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x be realXREAL-0V1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 f"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A3: "x inHIDDENR3 domRELAT-1K1 f"and A4: "y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have "f .FUNCT-1K1 x be realXREAL-0V1"
        using A1 A2 A3 sorry
      thus "y inHIDDENR3 REALNUMBERSK2"
        using A4 xreal_0_def_1 sorry
    qed "sorry"
    then have "rngFUNCT-1K2 f c=TARSKIR1 REALNUMBERSK2"
      using tarski_def_3 sorry
    thus "f be Real-SequenceSEQ-1M1"
      using A1 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_2:
" for f be FunctionFUNCT-1M1 holds f be Real-SequenceSEQ-1M1 iff domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be realXREAL-0V1)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be Real-SequenceSEQ-1M1 implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be realXREAL-0V1)) & (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be realXREAL-0V1) implies f be Real-SequenceSEQ-1M1)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be Real-SequenceSEQ-1M1 implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be realXREAL-0V1)"
      using seq_1_th_1 sorry
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
      and A2: " for n be NatNAT-1M1 holds f .FUNCT-1K1 n be realXREAL-0V1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x be realXREAL-0V1"
      using A2 sorry
    thus "f be Real-SequenceSEQ-1M1"
      using A1 seq_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_cl_1:
"cluster non-zeroORDINAL1V9 for PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) st it be non-zeroORDINAL1V9"
  proof-
    have " ex tVar1 be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) st tVar1 be non-zeroORDINAL1V9"
    proof-
      have "\<one>\<^sub>M inTARSKIR2 NATNUMBERSK1"
         sorry
      then have "\<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
        using numbers_th_19 sorry
      then obtain p where 
        [ty]:"p be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2)" and pDef:"p = NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M"
        using funcop_1_th_46 sorry
      show " ex tVar1 be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) st tVar1 be non-zeroORDINAL1V9"
      proof(rule bexI[of _ "p"])
        have Cut89: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
          using funcop_1_th_8 sorry
        have " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> p"
        proof-
          show " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> p"
            using tarski_def_1 Cut89 sorry
        qed
        thus "p be non-zeroORDINAL1V9"
          using ordinal1_def_15 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_1_th_3:
" for f be non-zeroORDINAL1V9\<bar>PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 REALNUMBERSK2 \\SUBSET-1K6 {TARSKIK1 0NUMBERSK6 }"
  using ordinal1_def_15 zfmisc_1_th_34 sorry

mtheorem seq_1_th_4:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be non-zeroORDINAL1V9 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)) & (( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies seq be non-zeroORDINAL1V9)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be non-zeroORDINAL1V9 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
    proof-
      have "seq be non-zeroORDINAL1V9 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies  not seq .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
      proof(rule impI,rule ballI,rule impI)
        assume A1: "seq be non-zeroORDINAL1V9"
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq"
          using seq_1_th_2 sorry
        then have "seq .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq"
          using funct_1_def_3 sorry
        thus " not seq .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using A1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A2: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have "0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq implies  False "
    proof(rule impI)
      assume "0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq & seq .FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6"
        using funct_1_def_3 sorry
      thus " False "
        using A2 sorry
    qed
    thus "seq be non-zeroORDINAL1V9"
      using ordinal1_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_5:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 iff ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be non-zeroORDINAL1V9 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6)) & (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6) implies seq be non-zeroORDINAL1V9)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be non-zeroORDINAL1V9 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6)"
      using ordinal1_def_12 seq_1_th_4 sorry
    assume " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
    then have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
       sorry
    thus "seq be non-zeroORDINAL1V9"
      using seq_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_6:
" for r be RealXREAL-0M1 holds  ex seq be Real-SequenceSEQ-1M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> seq =XBOOLE-0R4 {TARSKIK1 r}"
proof-
  have " for r be RealXREAL-0M1 holds  ex tVar2 be Real-SequenceSEQ-1M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> tVar2 =XBOOLE-0R4 {TARSKIK1 r}"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 r}"
      using funct_1_th_5 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 r} implies x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have "rngFUNCT-1K2 f c=TARSKIR1 REALNUMBERSK2"
      using A2 tarski_def_3 sorry
    then have 
      [ty]:"f be Real-SequenceSEQ-1M1"
      using A1 funct_2_def_1 relset_1_th_4 sorry
    show " ex tVar2 be Real-SequenceSEQ-1M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> tVar2 =XBOOLE-0R4 {TARSKIK1 r}"
    proof(rule bexI[of _ "f"])
      show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {TARSKIK1 r}"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem seq_1_sch_1:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be RealXREAL-0M1"
  shows " ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff1(n)"
  proof-
    have " ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff1(n)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be NatNAT-1M1 st n =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 Ff1(n)"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st  ex n be NatNAT-1M1 st n =HIDDENR1 x & y =HIDDENR1 Ff1(n))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A2: "n =HIDDENR1 x"
           sorry
        obtain r2 where 
          [ty]:"r2 be objectHIDDENM1" and r2Def:"r2 = Ff1(n)"
           sorry
        obtain y where 
          [ty]:"y be objectHIDDENM1" and yDef:"y = r2"
           sorry
        show " ex y be objectHIDDENM1 st  ex n be NatNAT-1M1 st n =HIDDENR1 x & y =HIDDENR1 Ff1(n)"
        proof(rule bexI[of _ "y"])
          show " ex n be NatNAT-1M1 st n =HIDDENR1 x & y =HIDDENR1 Ff1(n)"
            using A2 sorry
        qed "sorry"
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,f .FUNCT-1K1 x)"
        using classes1_sch_1 A1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then have " ex n be NatNAT-1M1 st n =HIDDENR1 x & f .FUNCT-1K1 x =HIDDENR1 Ff1(n)"
          using A4 sorry
        thus "f .FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      then have 
        [ty]:"f be Real-SequenceSEQ-1M1"
        using A3 seq_1_th_1 sorry
      obtain seq where 
        [ty]:"seq be Real-SequenceSEQ-1M1" and seqDef:"seq = f"
         sorry
      show " ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff1(n)"
      proof(rule bexI[of _ "seq"],rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have " ex k be NatNAT-1M1 st k =COMPLEX1R1 n & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff1(k)"
          using A4 sorry
        thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Ff1(n)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem seq_1_sch_2:
  fixes Df0 Cf0 Pp2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows " ex f be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))) & ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies Pp2(d,f .FUNCT-1K1 d))"
  proof-
    have " ex tVar5 be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar5 iff ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))) & ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar5 implies Pp2(d,tVar5 .FUNCT-1K1 d))"
    proof-
      let ?X = "\<lambda>Lamb1.  ex c be ElementSUBSET-1M1-of Cf0 st Pp2(Lamb1,c)"
      let ?x = "the ElementSUBSET-1M1-of Cf0"
      let ?X2 = "\<lambda>Lamb1. \<lambda>Lamb2. (( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(Lamb1,c)) implies Pp2(Lamb1,Lamb2)) & (( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(Lamb1,c)) implies Lamb2 =XBOOLE-0R4 ?x)"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Df0 & ?X(x)"
        using xboole_0_sch_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Df0"
        using A1 sorry
      then have 
        [ty]:"X be SubsetSUBSET-1M2-of Df0"
        using tarski_def_3 sorry
      have A2: " for d be ElementSUBSET-1M1-of Df0 holds  ex z be ElementSUBSET-1M1-of Cf0 st ?X2(d,z)"
      proof-
        have " for d be ElementSUBSET-1M1-of Df0 holds  not ( for z be ElementSUBSET-1M1-of Cf0 holds  not ((( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)) implies Pp2(d,z)) & (( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(d,c)) implies z =XBOOLE-0R4 the ElementSUBSET-1M1-of Cf0)))"
        proof(rule ballI)
          fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
          have "( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(d,c)) implies ( ex z be objectHIDDENM1 st (( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)) implies Pp2(d,z)) & (( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(d,c)) implies z =HIDDENR1 ?x))"
             sorry
          thus " not ( for z be ElementSUBSET-1M1-of Cf0 holds  not ((( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)) implies Pp2(d,z)) & (( for c be ElementSUBSET-1M1-of Cf0 holds  not Pp2(d,c)) implies z =XBOOLE-0R4 the ElementSUBSET-1M1-of Cf0)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain g where
        [ty]:"g be FunctionFUNCT-2M1-of(Df0,Cf0)" and 
        A3: " for d be ElementSUBSET-1M1-of Df0 holds ?X2(d,g .FUNCT-2K3\<^bsub>(Df0,Cf0)\<^esub> d)"
        using funct_2_sch_3 A2 sorry
      obtain f where 
        [ty]:"f be PartFuncPARTFUN1M1-of(Df0,Cf0)" and fDef:"f = g  |PARTFUN1K2\<^bsub>(Df0,Cf0)\<^esub> X"
         sorry
      show " ex tVar5 be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar5 iff ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))) & ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar5 implies Pp2(d,tVar5 .FUNCT-1K1 d))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
        have A4: "domRELSET-1K1\<^bsub>(Df0)\<^esub> g =XBOOLE-0R4 Df0"
          using funct_2_def_1 sorry
        show " for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))"
        proof-
          have " for d be ElementSUBSET-1M1-of Df0 holds (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))) & (( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)) implies d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f)"
          proof(rule ballI,rule conjMI,rule impI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
            have "domRELSET-1K1\<^bsub>(Df0)\<^esub> f c=TARSKIR1 X"
              using relat_1_th_58 sorry
            thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies ( ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c))"
              using A1 sorry
            assume " ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)"
            then have "d inTARSKIR2 X"
              using A1 sorry
            then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> g /\\SUBSET-1K9\<^bsub>(Df0)\<^esub> X"
              using A4 xboole_0_def_4 sorry
            thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f"
              using relat_1_th_61 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
        assume A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f"
        have "domRELSET-1K1\<^bsub>(Df0)\<^esub> f c=TARSKIR1 X"
          using relat_1_th_58 sorry
        then have " ex c be ElementSUBSET-1M1-of Cf0 st Pp2(d,c)"
          using A1 A5 sorry
        then have "Pp2(d,g .FUNCT-2K3\<^bsub>(Df0,Cf0)\<^esub> d)"
          using A3 sorry
        thus "Pp2(d,f .FUNCT-1K1 d)"
          using A5 funct_1_th_47 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem seq_1_sch_3:
  fixes Df0 Cf0 Ff1 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Cf0"
  shows " ex f be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff Pp1(d)) & ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies f .FUNCT-1K1 d =XBOOLE-0R4 Ff1(d))"
  proof-
    have " ex tVar6 be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar6 iff Pp1(d)) & ( for d be ElementSUBSET-1M1-of Df0 holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar6 &  not tVar6 .FUNCT-1K1 d =XBOOLE-0R4 Ff1(d)))"
    proof-
      let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. Pp1(Lamb1) & Lamb2 =XBOOLE-0R4 Ff1(Lamb1)"
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of(Df0,Cf0)" and 
        A1: " for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff ( ex c be ElementSUBSET-1M1-of Cf0 st ?X(d,c))"and A2: " for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies ?X(d,f .FUNCT-1K1 d)"
        using seq_1_sch_2 sorry
      show " ex tVar6 be PartFuncPARTFUN1M1-of(Df0,Cf0) st ( for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar6 iff Pp1(d)) & ( for d be ElementSUBSET-1M1-of Df0 holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> tVar6 &  not tVar6 .FUNCT-1K1 d =XBOOLE-0R4 Ff1(d)))"
      proof(rule bexI[of _ "f"],rule conjMI)
        show " for d be ElementSUBSET-1M1-of Df0 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f iff Pp1(d)"
        proof-
          have " for d be ElementSUBSET-1M1-of Df0 holds (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies Pp1(d)) & (Pp1(d) implies d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f)"
          proof(rule ballI,rule conjMI,rule impI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
            show "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f implies Pp1(d)"
            proof(rule impI)
              assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f"
              then have " ex c be ElementSUBSET-1M1-of Cf0 st Pp1(d) & c =XBOOLE-0R4 Ff1(d)"
                using A1 sorry
              thus "Pp1(d)"
                 sorry
            qed
            assume "Pp1(d)"
            then have " ex c be ElementSUBSET-1M1-of Cf0 st Pp1(d) & c =XBOOLE-0R4 Ff1(d)"
               sorry
            thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f"
              using A1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for d be ElementSUBSET-1M1-of Df0 holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(Df0)\<^esub> f &  not f .FUNCT-1K1 d =XBOOLE-0R4 Ff1(d))"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem seq_1_sch_4:
  fixes Cf0 Df0 Xf0 Ff1 
  assumes
[ty]: "Cf0 be setHIDDENM2" and
  [ty]: "Df0 be setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " for f be PartFuncPARTFUN1M1-of(Cf0,Df0) holds  for g be PartFuncPARTFUN1M1-of(Cf0,Df0) holds (domRELSET-1K1\<^bsub>(Cf0)\<^esub> f =XBOOLE-0R4 Xf0 & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c))) & (domRELSET-1K1\<^bsub>(Cf0)\<^esub> g =XBOOLE-0R4 Xf0 & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> g implies g .FUNCT-1K1 c =HIDDENR1 Ff1(c))) implies f =RELSET-1R2\<^bsub>(Cf0,Df0)\<^esub> g"
  proof-
    have " for f be PartFuncPARTFUN1M1-of(Cf0,Df0) holds  for g be PartFuncPARTFUN1M1-of(Cf0,Df0) holds domRELSET-1K1\<^bsub>(Cf0)\<^esub> f =XBOOLE-0R4 Xf0 & (( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & (domRELSET-1K1\<^bsub>(Cf0)\<^esub> g =XBOOLE-0R4 Xf0 & ( for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> g implies g .FUNCT-1K1 c =HIDDENR1 Ff1(c)))) implies f =RELSET-1R2\<^bsub>(Cf0,Df0)\<^esub> g"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
      fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(Cf0,Df0)"
      fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(Cf0,Df0)"
      assume A1: "domRELSET-1K1\<^bsub>(Cf0)\<^esub> f =XBOOLE-0R4 Xf0"
        and A2: " for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
        and A3: "domRELSET-1K1\<^bsub>(Cf0)\<^esub> g =XBOOLE-0R4 Xf0"
        and A4: " for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> g implies g .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
      have " for c be ElementSUBSET-1M1-of Cf0 holds c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f implies f .FUNCT-1K1 c =HIDDENR1 g .FUNCT-1K1 c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of Cf0"
        assume A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(Cf0)\<^esub> f"
        then have "f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
          using A2 sorry
        also have "... = g .FUNCT-1K1 c"
          using A1 A3 A4 A5 sorry
        finally show "f .FUNCT-1K1 c =HIDDENR1 g .FUNCT-1K1 c"
           sorry
      qed "sorry"
      thus "f =RELSET-1R2\<^bsub>(Cf0,Df0)\<^esub> g"
        using A1 A3 partfun1_th_5 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

mtheorem seq_1_th_7:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 iff ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds (seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    show "seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof(rule impI,rule ballI)
      assume A1: "seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
      fix n assume [ty]: "n be NatNAT-1M1"
      have A2: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq =XBOOLE-0R4 NATNUMBERSK1"
        using funct_2_def_1 sorry
      thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 valued_1_def_1 A2 sorry
    qed "sorry"
    assume " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    then have A3: " for n be objectHIDDENM1 holds n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq implies seq .FUNCT-1K1 n =COMPLEX1R1 seq1 .FUNCT-1K1 n +XCMPLX-0K2 seq2 .FUNCT-1K1 n"
       sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq =HIDDENR1 NATNUMBERSK1 /\\XBOOLE-0K3 NATNUMBERSK1"
      using funct_2_def_1 sorry
    also have "... = NATNUMBERSK1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
      using funct_2_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
      using funct_2_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
       sorry
    thus "seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
      using A3 valued_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_8:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 iff ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds (seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    show "seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof(rule impI,rule ballI)
      assume A1: "seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
      fix n assume [ty]: "n be NatNAT-1M1"
      have A2: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq =XBOOLE-0R4 NATNUMBERSK1"
        using funct_2_def_1 sorry
      thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 valued_1_def_4 A2 sorry
    qed "sorry"
    assume " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    then have A3: " for n be objectHIDDENM1 holds n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq implies seq .FUNCT-1K1 n =COMPLEX1R1 seq1 .FUNCT-1K1 n *XCMPLX-0K3 seq2 .FUNCT-1K1 n"
       sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq =HIDDENR1 NATNUMBERSK1 /\\XBOOLE-0K3 NATNUMBERSK1"
      using funct_2_def_1 sorry
    also have "... = NATNUMBERSK1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
      using funct_2_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
      using funct_2_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
       sorry
    thus "seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
      using A3 valued_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_9:
" for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 iff ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds (seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    show "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using valued_1_th_6 sorry
    assume " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    then have A1: " for n be objectHIDDENM1 holds n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 implies seq1 .FUNCT-1K1 n =COMPLEX1R1 r *XCMPLX-0K3 seq2 .FUNCT-1K1 n"
       sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 =HIDDENR1 NATNUMBERSK1"
      using funct_2_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
      using funct_2_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
       sorry
    thus "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
      using A1 valued_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_10:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 iff ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds (seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    show "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using valued_1_th_8 sorry
    assume " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 -REAL-1K1 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    then have A1: " for n be objectHIDDENM1 holds n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 implies seq1 .FUNCT-1K1 n =COMPLEX1R1 -XCMPLX-0K4 seq2 .FUNCT-1K1 n"
       sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 =HIDDENR1 NATNUMBERSK1"
      using funct_2_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
      using funct_2_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq2"
       sorry
    thus "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
      using A1 valued_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_11:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)"
   sorry

mtheorem seq_1_th_12:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq iff ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)) & (( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|) implies seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    show "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|)"
      using valued_1_th_18 sorry
    assume " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
    then have A1: " for n be objectHIDDENM1 holds n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 implies seq1 .FUNCT-1K1 n =COMPLEX1R1  |.COMPLEX1K10 seq .FUNCT-1K1 n.|"
       sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 =HIDDENR1 NATNUMBERSK1"
      using funct_2_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq"
      using funct_2_def_1 sorry
    finally have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq1 =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq"
       sorry
    thus "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
      using A1 valued_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_13:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)+REAL-1K3 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 (seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
         sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_14:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
         sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "((seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_15:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
      also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_16:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq3 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
  using seq_1_th_15 sorry

mtheorem seq_1_th_17:
" for seq be Real-SequenceSEQ-1M1 holds -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
   sorry

mtheorem seq_1_th_18:
" for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
proof-
  have " for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 r *XCMPLX-0K3 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = r *XCMPLX-0K3 (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using seq_1_th_8 sorry
      also have "... = (r *XCMPLX-0K3 seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*XCMPLX-0K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = ((r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_19:
" for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)"
proof-
  have " for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 r *XCMPLX-0K3 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = r *XCMPLX-0K3 (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using seq_1_th_8 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (r *XCMPLX-0K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
         sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_20:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =HIDDENR1 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Real-SequenceSEQ-1M1"
    have "(seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =HIDDENR1 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
      using seq_1_th_15 sorry
    also have "... = seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
      using seq_1_th_18 sorry
    finally show "(seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 =HIDDENR1 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_21:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq3 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)"
  using seq_1_th_20 sorry

mtheorem seq_1_th_22:
" for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
proof-
  have " for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 r *XCMPLX-0K3 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = r *XCMPLX-0K3 (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using seq_1_th_7 sorry
      also have "... = r *XCMPLX-0K3 seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 r *XCMPLX-0K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 r *XCMPLX-0K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_23:
" for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (r *XCMPLX-0K3 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)"
proof-
  have " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (r *XCMPLX-0K3 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((r *XCMPLX-0K3 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((r *XCMPLX-0K3 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r *XCMPLX-0K3 p)*XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = r *XCMPLX-0K3 (p *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
         sorry
      also have "... = r *XCMPLX-0K3 (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      finally show "((r *XCMPLX-0K3 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(r *XCMPLX-0K3 p)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_24:
" for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
proof-
  have " for r be RealXREAL-0M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =HIDDENR1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =HIDDENR1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)"
      using seq_1_th_22 sorry
    also have "... = r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 r)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
      using seq_1_th_23 sorry
    also have "... = r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
      using seq_1_th_23 sorry
    finally show "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2) =HIDDENR1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_25:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
       sorry
    also have "... = (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
      using seq_1_th_18 sorry
    finally show "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_26:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Real-SequenceSEQ-1M1"
    have "seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3)"
      using seq_1_th_22 sorry
    also have "... = (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
      using seq_1_th_13 sorry
    finally show "seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_27:
" for seq be Real-SequenceSEQ-1M1 holds \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (\<one>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(\<one>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
      finally show "(\<one>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "\<one>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem seq_1_th_29:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
   sorry

mtheorem seq_1_th_30:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Real-SequenceSEQ-1M1"
    have "seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3))"
      using seq_1_th_24 sorry
    also have "... = (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
      using seq_1_th_13 sorry
    finally show "seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_31:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Real-SequenceSEQ-1M1"
    have "seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3)"
      using seq_1_th_13 sorry
    also have "... = (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
       sorry
    finally show "seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3) =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)-VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_32:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 & seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2"
  using seq_1_th_18 sorry

mtheorem seq_1_th_33:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 &  not seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9 implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: " not seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9"
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A3: "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1 =COMPLEX1R1 0NUMBERSK6"
      using A2 seq_1_th_5 sorry
    have "(seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1)\<inverse>REAL-1K2 =COMPLEX1R1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1"
      using valued_1_th_10 sorry
    thus " False "
      using A1 A3 seq_1_th_5 xcmplx_1_th_202 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem seq_1_th_35:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 iff seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 implies seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9) & (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9 implies seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    show "seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 implies seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9"
    proof(rule impI)
      assume A1: "seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9"
      have " for n be NatNAT-1M1 holds (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A2: "(seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using A1 seq_1_th_5 sorry
        thus "(seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using A2 xcmplx_1_th_6 sorry
      qed "sorry"
      thus "seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9"
        using seq_1_th_5 sorry
    qed
    assume A3: "seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9"
    have " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "(seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
        using A3 seq_1_th_5 sorry
    qed "sorry"
    thus "seq be non-zeroORDINAL1V9"
      using seq_1_th_5 sorry
    have " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "(seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      thus "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
        using A3 seq_1_th_5 sorry
    qed "sorry"
    thus "seq1 be non-zeroORDINAL1V9"
      using seq_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_36:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using valued_1_th_10 sorry
      also have "... = (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using valued_1_th_10 sorry
      also have "... = (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using xcmplx_1_th_204 sorry
      also have "... = ((seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using seq_1_th_8 sorry
      also have "... = (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "(seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_37:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1"
  proof(rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A2: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
        using A1 seq_1_th_5 sorry
      have "((seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2)*REAL-1K4 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
         sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 \<one>\<^sub>M"
        using A2 xcmplx_0_def_7 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
      finally show "((seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_38:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq19 be Real-SequenceSEQ-1M1 holds (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq19 be Real-SequenceSEQ-1M1 holds (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    fix seq19 assume [ty]: "seq19 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 (seq19 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using seq_1_th_8 sorry
      also have "... = seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq19 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
         sorry
      also have "... = seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq19 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using seq_1_th_8 sorry
      also have "... = (seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq19 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
      also have "... = (seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq19 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_36 sorry
      also have "... = (seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = ((seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "((seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_39:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 implies seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 implies seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: "seq1 be non-zeroORDINAL1V9"
    have "seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9"
      using A2 seq_1_th_33 sorry
    thus "seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-zeroORDINAL1V9"
      using A1 seq_1_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_40:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_36 sorry
      also have "... = (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
      finally show "(seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_41:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    have "seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
       sorry
    also have "... = (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
      using seq_1_th_14 sorry
    finally show "seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_42:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    have "seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
      using seq_1_th_40 sorry
    also have "... = seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
       sorry
    also have "... = (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
      using seq_1_th_14 sorry
    finally show "seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_43:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be non-zeroORDINAL1V9 implies seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds seq1 be non-zeroORDINAL1V9 implies seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be non-zeroORDINAL1V9"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A2: "seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
        using A1 seq_1_th_5 sorry
      have "(seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2))*REAL-1K4 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A2 xcmplx_0_def_7 sorry
      also have "... = (seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 ((seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
         sorry
      also have "... = (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using seq_1_th_8 sorry
      also have "... = (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using valued_1_th_10 sorry
      also have "... = (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_36 sorry
      also have "... = ((seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "(seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "seq2 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq2 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_44:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds r <>HIDDENR2 0NUMBERSK6 & seq be non-zeroORDINAL1V9 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-zeroORDINAL1V9"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds r <>HIDDENR2 0NUMBERSK6 & (seq be non-zeroORDINAL1V9 &  not r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-zeroORDINAL1V9) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
      and A2: "seq be non-zeroORDINAL1V9"
      and A3: " not r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-zeroORDINAL1V9"
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A4: "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1 =COMPLEX1R1 0NUMBERSK6"
      using A3 seq_1_th_5 sorry
    have A5: "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1 <>HIDDENR2 0NUMBERSK6"
      using A2 seq_1_th_5 sorry
    have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1 =COMPLEX1R1 0NUMBERSK6"
      using A4 seq_1_th_9 sorry
    thus " False "
      using A1 A5 xcmplx_1_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_45:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-zeroORDINAL1V9"
  using seq_1_th_44 sorry

mtheorem seq_1_th_46:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using valued_1_th_10 sorry
      also have "... = (r *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>XCMPLX-0K5"
        using seq_1_th_9 sorry
      also have "... = r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using xcmplx_1_th_204 sorry
      also have "... = r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      also have "... = (r \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_1_lm_1:
"(-XCMPLX-0K4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
   sorry

mtheorem seq_1_th_47:
" for seq be Real-SequenceSEQ-1M1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
  using seq_1_lm_1 seq_1_th_46 sorry

mtheorem seq_1_th_48:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq & seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq & seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    have "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
       sorry
    also have "... = (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
      using seq_1_th_18 sorry
    finally show "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
    have "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
      using seq_1_lm_1 seq_1_th_46 sorry
    also have "... = -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
      using seq_1_th_19 sorry
    finally show "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_49:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq19 be Real-SequenceSEQ-1M1 holds seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq & seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq19 be Real-SequenceSEQ-1M1 holds seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq & seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq19 assume [ty]: "seq19 be Real-SequenceSEQ-1M1"
    have "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using seq_1_th_15 sorry
    also have "... = (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
    have "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using seq_1_th_20 sorry
    also have "... = (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =HIDDENR1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_50:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq19 be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq9 be non-zeroORDINAL1V9 implies seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) & seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq19 be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq9 be non-zeroORDINAL1V9 implies seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) & seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    fix seq19 assume [ty]: "seq19 be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: "seq9 be non-zeroORDINAL1V9"
    have "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9"
      using A2 seq_1_th_43 sorry
    also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
      using A1 seq_1_th_43 sorry
    also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using seq_1_th_15 sorry
    also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
       sorry
    have "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9"
      using A2 seq_1_th_43 sorry
    also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
      using A1 seq_1_th_43 sorry
    also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using seq_1_th_20 sorry
    also have "... = (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_51:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq19 be Real-SequenceSEQ-1M1 holds (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq19 be Real-SequenceSEQ-1M1 holds (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    fix seq19 assume [ty]: "seq19 be Real-SequenceSEQ-1M1"
    have "(seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 (seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq9 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
      using seq_1_th_36 sorry
    also have "... = ((seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using seq_1_th_14 sorry
    also have "... = (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using seq_1_th_14 sorry
    also have "... = seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
      using seq_1_th_14 sorry
    also have "... = seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>))"
      using seq_1_th_14 sorry
    also have "... = (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
      using seq_1_th_14 sorry
    also have "... = (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
      using seq_1_th_36 sorry
    finally show "(seq19 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 (seq19 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_52:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .|"
        using seq_1_th_8 sorry
      also have "... = ( |.COMPLEX1K10 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|)"
        using complex1_th_65 sorry
      also have "... = absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|)"
        using seq_1_th_12 sorry
      also have "... = absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_12 sorry
      also have "... = (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_53:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-zeroORDINAL1V9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-zeroORDINAL1V9"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
    have " for n be NatNAT-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
        using A1 seq_1_th_5 sorry
      then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <>HIDDENR2 0NUMBERSK6"
        using complex1_th_47 sorry
      thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
        using seq_1_th_12 sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-zeroORDINAL1V9"
      using seq_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_54:
" for seq be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2.|"
        using valued_1_th_10 sorry
      also have "... =  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .|"
        using xcmplx_1_th_215 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|)"
        using absvalue_th_7 sorry
      also have "... = ( |.COMPLEX1K10 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|)\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_215 sorry
      also have "... = (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using seq_1_th_12 sorry
      also have "... = absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_55:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
      using seq_1_th_52 sorry
    also have "... = absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
      using seq_1_th_54 sorry
    finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_1_th_56:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 r *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .|"
        using seq_1_th_9 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|)"
        using complex1_th_65 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_12 sorry
      also have "... = (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_1_def_1 ("seq-constSEQ-1K1  _ " [164]164 ) where
  mlet "b be RealXREAL-0M1"
"func seq-constSEQ-1K1 b \<rightarrow> Real-SequenceSEQ-1M1 equals
  NATNUMBERSK1 -->FUNCOP-1K7 b"
proof-
  (*coherence*)
    show "NATNUMBERSK1 -->FUNCOP-1K7 b be Real-SequenceSEQ-1M1"
    proof-
      have 
        [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> b be Real-SequenceSEQ-1M1"
         sorry
      thus "NATNUMBERSK1 -->FUNCOP-1K7 b be Real-SequenceSEQ-1M1"
         sorry
    qed
qed "sorry"

mtheorem seq_1_cl_2:
  mlet "b be RealXREAL-0M1"
"cluster seq-constSEQ-1K1 b as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "seq-constSEQ-1K1 b be constantFUNCT-1V5"
     sorry
qed "sorry"

mtheorem seq_1_cl_3:
  mlet "b be  non zeroORDINAL1V8\<bar>RealXREAL-0M1"
"cluster seq-constSEQ-1K1 b as-term-is non-zeroORDINAL1V9"
proof
(*coherence*)
  show "seq-constSEQ-1K1 b be non-zeroORDINAL1V9"
  proof-
    have Cut848: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (seq-constSEQ-1K1 b) =XBOOLE-0R4 {TARSKIK1 b}"
      using funcop_1_th_8 sorry
    have " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (seq-constSEQ-1K1 b)"
    proof-
      show " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (seq-constSEQ-1K1 b)"
        using tarski_def_1 Cut848 sorry
    qed
    thus "seq-constSEQ-1K1 b be non-zeroORDINAL1V9"
      using ordinal1_def_15 sorry
  qed
qed "sorry"

mtheorem seq_1_cl_4:
"cluster constantFUNCT-1V5 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be constantFUNCT-1V5"
  proof-
    have " ex tVar7 be Real-SequenceSEQ-1M1 st tVar7 be constantFUNCT-1V5"
    proof-
      show " ex tVar7 be Real-SequenceSEQ-1M1 st tVar7 be constantFUNCT-1V5"
      proof(rule bexI[of _ "seq-constSEQ-1K1 (0NUMBERSK6)"])
        show "seq-constSEQ-1K1 (0NUMBERSK6) be constantFUNCT-1V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_1_th_57:
" for a be RealXREAL-0M1 holds  for k be NatNAT-1M1 holds (seq-constSEQ-1K1 a).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 a"
  using ordinal1_def_12 funcop_1_th_7 sorry

end
