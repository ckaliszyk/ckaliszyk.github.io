theory glib_000
  imports domain_1 pboole finseq_4 nat_d binop_2 ordinal3
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem glib_000_cl_1:
"cluster finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4"
  proof-
    have " ex tVar1 be FunctionFUNCT-1M1 st tVar1 be finiteFINSET-1V1 & tVar1 be NATNUMBERSK1 -definedRELAT-1V4"
    proof-
      show " ex tVar1 be FunctionFUNCT-1M1 st tVar1 be finiteFINSET-1V1 & tVar1 be NATNUMBERSK1 -definedRELAT-1V4"
      proof(rule bexI[of _ "{}XBOOLE-0K1"],rule conjMI)
        show "{}XBOOLE-0K1 be finiteFINSET-1V1"
           sorry
        have "domFINSEQ-1K5 ({}XBOOLE-0K1) c=ORDINAL1R1 NATNUMBERSK1"
        proof-
          show "domFINSEQ-1K5 ({}XBOOLE-0K1) c=ORDINAL1R1 NATNUMBERSK1"
             sorry
        qed
        thus "{}XBOOLE-0K1 be NATNUMBERSK1 -definedRELAT-1V4"
          using relat_1_def_18 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax GLIB_000M1 :: "Ty" ("GraphStructGLIB-000M1" 70)
translations "GraphStructGLIB-000M1" \<rightharpoonup> "finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"

mdef glib_000_def_1 ("VertexSelectorGLIB-000K1" 164 ) where
"func VertexSelectorGLIB-000K1 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_2 ("EdgeSelectorGLIB-000K2" 164 ) where
"func EdgeSelectorGLIB-000K2 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<two>\<^sub>M"
proof-
  (*coherence*)
    show "\<two>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_3 ("SourceSelectorGLIB-000K3" 164 ) where
"func SourceSelectorGLIB-000K3 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<three>\<^sub>M"
proof-
  (*coherence*)
    show "\<three>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_4 ("TargetSelectorGLIB-000K4" 164 ) where
"func TargetSelectorGLIB-000K4 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<four>\<^sub>M"
proof-
  (*coherence*)
    show "\<four>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_5 ("-GraphSelectorsGLIB-000K5" 164 ) where
"func -GraphSelectorsGLIB-000K5 \<rightarrow>  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 equals
  {DOMAIN-1K9\<^bsub>(NATNUMBERSK1)\<^esub> VertexSelectorGLIB-000K1,EdgeSelectorGLIB-000K2,SourceSelectorGLIB-000K3,TargetSelectorGLIB-000K4 }"
proof-
  (*coherence*)
    show "{DOMAIN-1K9\<^bsub>(NATNUMBERSK1)\<^esub> VertexSelectorGLIB-000K1,EdgeSelectorGLIB-000K2,SourceSelectorGLIB-000K3,TargetSelectorGLIB-000K4 } be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef glib_000_def_6 ("the-Vertices-ofGLIB-000K6  _ " [164]164 ) where
  mlet "G be GraphStructGLIB-000M1"
"func the-Vertices-ofGLIB-000K6 G \<rightarrow> setHIDDENM2 equals
  G .FUNCT-1K1 (VertexSelectorGLIB-000K1)"
proof-
  (*coherence*)
    show "G .FUNCT-1K1 (VertexSelectorGLIB-000K1) be setHIDDENM2"
       sorry
qed "sorry"

mdef glib_000_def_7 ("the-Edges-ofGLIB-000K7  _ " [164]164 ) where
  mlet "G be GraphStructGLIB-000M1"
"func the-Edges-ofGLIB-000K7 G \<rightarrow> setHIDDENM2 equals
  G .FUNCT-1K1 (EdgeSelectorGLIB-000K2)"
proof-
  (*coherence*)
    show "G .FUNCT-1K1 (EdgeSelectorGLIB-000K2) be setHIDDENM2"
       sorry
qed "sorry"

mdef glib_000_def_8 ("the-Source-ofGLIB-000K8  _ " [164]164 ) where
  mlet "G be GraphStructGLIB-000M1"
"func the-Source-ofGLIB-000K8 G \<rightarrow> setHIDDENM2 equals
  G .FUNCT-1K1 (SourceSelectorGLIB-000K3)"
proof-
  (*coherence*)
    show "G .FUNCT-1K1 (SourceSelectorGLIB-000K3) be setHIDDENM2"
       sorry
qed "sorry"

mdef glib_000_def_9 ("the-Target-ofGLIB-000K9  _ " [164]164 ) where
  mlet "G be GraphStructGLIB-000M1"
"func the-Target-ofGLIB-000K9 G \<rightarrow> setHIDDENM2 equals
  G .FUNCT-1K1 (TargetSelectorGLIB-000K4)"
proof-
  (*coherence*)
    show "G .FUNCT-1K1 (TargetSelectorGLIB-000K4) be setHIDDENM2"
       sorry
qed "sorry"

mdef glib_000_def_10 ("[Graph-like]GLIB-000V1" 70 ) where
"attr [Graph-like]GLIB-000V1 for GraphStructGLIB-000M1 means
  (\<lambda>G. (((((VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G) & SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G) & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G) & the-Vertices-ofGLIB-000K6 G be  non emptyXBOOLE-0V1\<bar>setHIDDENM2) & the-Source-ofGLIB-000K8 G be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)) & the-Target-ofGLIB-000K9 G be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G))"..

mtheorem glib_000_cl_2:
"cluster [Graph-like]GLIB-000V1 for GraphStructGLIB-000M1"
proof
(*existence*)
  show " ex it be GraphStructGLIB-000M1 st it be [Graph-like]GLIB-000V1"
  proof-
    have " not ( for VarFor1 be GraphStructGLIB-000M1 holds  not VarFor1 be [Graph-like]GLIB-000V1)"
    proof-
      let ?V = "{DOMAIN-1K6\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M}"
      let ?E = "{}XBOOLE-0K1"
      obtain S where 
        [ty]:"S be FunctionFUNCT-2M1-of(?E,?V)" and SDef:"S = {}XBOOLE-0K1"
        using relset_1_th_12 sorry
      let ?G = "<*FINSEQ-4K7 ?V,?E,S,S *>"
      have "lenFINSEQ-1K4 ?G =XBOOLE-0R4 \<four>\<^sub>M"
        using finseq_4_th_76 sorry
      then have A1: "domFINSEQ-1K5 ?G =XBOOLE-0R4 SegFINSEQ-1K2 \<four>\<^sub>M"
        using finseq_1_def_3 sorry
      obtain G where 
        [ty]:"G be GraphStructGLIB-000M1" and GDef:"G = ?G"
         sorry
      have A2: "SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
        using A1 finseq_1_th_1 sorry
      have A3: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 ?V & the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 ?E"
        using finseq_4_th_76 sorry
      have A4: "the-Source-ofGLIB-000K8 G =XBOOLE-0R4 S & the-Target-ofGLIB-000K9 G =XBOOLE-0R4 S"
        using finseq_4_th_76 sorry
      have "VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
        using A1 finseq_1_th_1 sorry
      then have "G be [Graph-like]GLIB-000V1"
        using A3 A4 A2 sorry
      thus " not ( for VarFor1 be GraphStructGLIB-000M1 holds  not VarFor1 be [Graph-like]GLIB-000V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax GLIB_000M2 :: "Ty" ("-GraphGLIB-000M2" 70)
translations "-GraphGLIB-000M2" \<rightharpoonup> "[Graph-like]GLIB-000V1\<bar>GraphStructGLIB-000M1"

mtheorem glib_000_cl_3:
  mlet "G be -GraphGLIB-000M2"
"cluster the-Vertices-ofGLIB-000K6 G as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "the-Vertices-ofGLIB-000K6 G be  non emptyXBOOLE-0V1"
    using glib_000_def_10 sorry
qed "sorry"

abbreviation(input) GLIB_000K10("the-Source-ofGLIB-000K10  _ " [164]164) where
  "the-Source-ofGLIB-000K10 G \<equiv> the-Source-ofGLIB-000K8 G"

mtheorem glib_000_add_1:
  mlet "G be -GraphGLIB-000M2"
"cluster the-Source-ofGLIB-000K8 G as-term-is FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)"
proof
(*coherence*)
  show "the-Source-ofGLIB-000K8 G be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)"
    using glib_000_def_10 sorry
qed "sorry"

abbreviation(input) GLIB_000K11("the-Target-ofGLIB-000K11  _ " [164]164) where
  "the-Target-ofGLIB-000K11 G \<equiv> the-Target-ofGLIB-000K9 G"

mtheorem glib_000_add_2:
  mlet "G be -GraphGLIB-000M2"
"cluster the-Target-ofGLIB-000K9 G as-term-is FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)"
proof
(*coherence*)
  show "the-Target-ofGLIB-000K9 G be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)"
    using glib_000_def_10 sorry
qed "sorry"

mdef glib_000_def_11 ("createGraphGLIB-000K12'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "V be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be setHIDDENM2", "S be FunctionFUNCT-2M1-of(E,V)", "T be FunctionFUNCT-2M1-of(E,V)"
"func createGraphGLIB-000K12(V,E,S,T) \<rightarrow> -GraphGLIB-000M2 equals
  <*FINSEQ-4K7 V,E,S,T *>"
proof-
  (*coherence*)
    show "<*FINSEQ-4K7 V,E,S,T *> be -GraphGLIB-000M2"
    proof-
      let ?G = "<*FINSEQ-4K7 V,E,S,T *>"
      have "lenFINSEQ-1K4 ?G =XBOOLE-0R4 \<four>\<^sub>M"
        using finseq_4_th_76 sorry
      then have A1: "domFINSEQ-1K5 ?G =XBOOLE-0R4 SegFINSEQ-1K2 \<four>\<^sub>M"
        using finseq_1_def_3 sorry
      obtain G where 
        [ty]:"G be GraphStructGLIB-000M1" and GDef:"G = ?G"
         sorry
      have A2: "SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
        using A1 finseq_1_th_1 sorry
      have A3: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 V & the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 E"
        using finseq_4_th_76 sorry
      have A4: "the-Source-ofGLIB-000K8 G =XBOOLE-0R4 S & the-Target-ofGLIB-000K9 G =XBOOLE-0R4 T"
        using finseq_4_th_76 sorry
      have "VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
        using A1 finseq_1_th_1 sorry
      thus "<*FINSEQ-4K7 V,E,S,T *> be -GraphGLIB-000M2"
        using A3 A4 A2 glib_000_def_10 sorry
    qed
qed "sorry"

mdef glib_000_def_12 (" _ .setGLIB-000K13'( _ , _ ')" [260,0,0]260 ) where
  mlet "G be GraphStructGLIB-000M1", "n be NatNAT-1M1", "x be setHIDDENM2"
"func G .setGLIB-000K13(n,x) \<rightarrow> GraphStructGLIB-000M1 equals
  G +*FUNCT-4K1 (n .-->FUNCOP-1K17 x)"
proof-
  (*coherence*)
    show "G +*FUNCT-4K1 (n .-->FUNCOP-1K17 x) be GraphStructGLIB-000M1"
    proof-
      let ?IT = "G +*FUNCT-4K1 (n .-->FUNCOP-1K17 x)"
      have A1: "domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x) =XBOOLE-0R4 {TARSKIK1 n}"
        using funcop_1_th_13 sorry
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have A2: "{TARSKIK1 n} c=TARSKIR1 NATNUMBERSK1"
        using zfmisc_1_th_31 sorry
      have "domRELAT-1K1 ?IT =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G \\/XBOOLE-0K2 domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x) & domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G c=TARSKIR1 NATNUMBERSK1"
        using funct_4_def_1 sorry
      then have "domRELAT-1K1 ?IT c=TARSKIR1 NATNUMBERSK1"
        using A2 A1 xboole_1_th_8 sorry
      thus "G +*FUNCT-4K1 (n .-->FUNCOP-1K17 x) be GraphStructGLIB-000M1"
        using relat_1_def_18 sorry
    qed
qed "sorry"

mlemma glib_000_lm_1:
" for GS be GraphStructGLIB-000M1 holds GS be [Graph-like]GLIB-000V1 iff ((-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS & the-Vertices-ofGLIB-000K6 GS be  non emptyXBOOLE-0V1) & the-Source-ofGLIB-000K8 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) & the-Target-ofGLIB-000K9 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)"
proof-
  have " for GS be GraphStructGLIB-000M1 holds  not (GS be [Graph-like]GLIB-000V1 &  not (((-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS &  not the-Vertices-ofGLIB-000K6 GS be emptyXBOOLE-0V1) & the-Source-ofGLIB-000K8 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) & the-Target-ofGLIB-000K9 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS))) &  not ((((-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS &  not the-Vertices-ofGLIB-000K6 GS be emptyXBOOLE-0V1) & the-Source-ofGLIB-000K8 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) & the-Target-ofGLIB-000K9 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) &  not GS be [Graph-like]GLIB-000V1)"
  proof(rule ballI)
    fix GS assume [ty]: "GS be GraphStructGLIB-000M1"
    have "(((VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS implies -GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & (-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS implies ((VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS)"
    proof(rule conjMI,rule impI)
      show "((VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS implies -GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS"
        using enumset1_def_2 sorry
      have A1: "VertexSelectorGLIB-000K1 inTARSKIR2 -GraphSelectorsGLIB-000K5 & EdgeSelectorGLIB-000K2 inTARSKIR2 -GraphSelectorsGLIB-000K5"
        using enumset1_def_2 sorry
      have A2: "SourceSelectorGLIB-000K3 inTARSKIR2 -GraphSelectorsGLIB-000K5 & TargetSelectorGLIB-000K4 inTARSKIR2 -GraphSelectorsGLIB-000K5"
        using enumset1_def_2 sorry
      assume "-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS"
      thus "((VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS) & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS"
        using A1 A2 sorry
    qed
    thus " not (GS be [Graph-like]GLIB-000V1 &  not (((-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS &  not the-Vertices-ofGLIB-000K6 GS be emptyXBOOLE-0V1) & the-Source-ofGLIB-000K8 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) & the-Target-ofGLIB-000K9 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS))) &  not ((((-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS &  not the-Vertices-ofGLIB-000K6 GS be emptyXBOOLE-0V1) & the-Source-ofGLIB-000K8 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) & the-Target-ofGLIB-000K9 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) &  not GS be [Graph-like]GLIB-000V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_cl_4:
  mlet "G be -GraphGLIB-000M2"
"cluster G  |RELAT-1K8 (-GraphSelectorsGLIB-000K5) as-term-is [Graph-like]GLIB-000V1"
proof
(*coherence*)
  show "G  |RELAT-1K8 (-GraphSelectorsGLIB-000K5) be [Graph-like]GLIB-000V1"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 -GraphSelectorsGLIB-000K5 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 -GraphSelectorsGLIB-000K5"
      then have "((x =HIDDENR1 VertexSelectorGLIB-000K1 or x =HIDDENR1 EdgeSelectorGLIB-000K2) or x =HIDDENR1 SourceSelectorGLIB-000K3) or x =HIDDENR1 TargetSelectorGLIB-000K4"
        using enumset1_def_2 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
        using glib_000_def_10 sorry
    qed "sorry"
    then have A1: "-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
       sorry
    let ?G2 = "G  |RELAT-1K8 (-GraphSelectorsGLIB-000K5)"
    have "VertexSelectorGLIB-000K1 inTARSKIR2 -GraphSelectorsGLIB-000K5"
      using enumset1_def_2 sorry
    then have A2: "the-Vertices-ofGLIB-000K6 ?G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G"
      using funct_1_th_49 sorry
    have "EdgeSelectorGLIB-000K2 inTARSKIR2 -GraphSelectorsGLIB-000K5"
      using enumset1_def_2 sorry
    then have A3: "the-Edges-ofGLIB-000K7 ?G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G"
      using funct_1_th_49 sorry
    have "TargetSelectorGLIB-000K4 inTARSKIR2 -GraphSelectorsGLIB-000K5"
      using enumset1_def_2 sorry
    then have A4: "the-Target-ofGLIB-000K9 ?G2 =XBOOLE-0R4 the-Target-ofGLIB-000K11 G"
      using funct_1_th_49 sorry
    have "SourceSelectorGLIB-000K3 inTARSKIR2 -GraphSelectorsGLIB-000K5"
      using enumset1_def_2 sorry
    then have A5: "the-Source-ofGLIB-000K8 ?G2 =XBOOLE-0R4 the-Source-ofGLIB-000K10 G"
      using funct_1_th_49 sorry
    have "domRELSET-1K1\<^bsub>(-GraphSelectorsGLIB-000K5)\<^esub> ?G2 =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (-GraphSelectorsGLIB-000K5)"
      using relat_1_th_61 sorry
    also have "... = -GraphSelectorsGLIB-000K5"
      using A1 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(-GraphSelectorsGLIB-000K5)\<^esub> ?G2 =HIDDENR1 -GraphSelectorsGLIB-000K5"
       sorry
    thus "G  |RELAT-1K8 (-GraphSelectorsGLIB-000K5) be [Graph-like]GLIB-000V1"
      using A2 A3 A5 A4 glib_000_lm_1 sorry
  qed
qed "sorry"

mdef glib_000_def_13 (" _ JoinsGLIB-000R1'( _ , _ , _ ')" [50,0,0,0]50 ) where
  mlet "G be -GraphGLIB-000M2", "x be objectHIDDENM1", "y be objectHIDDENM1", "e be objectHIDDENM1"
"pred e JoinsGLIB-000R1(x,y,G) means
  e inHIDDENR3 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =HIDDENR1 x & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =HIDDENR1 y or (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =HIDDENR1 y & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =HIDDENR1 x)"..

mdef glib_000_def_14 (" _ DJoinsGLIB-000R2'( _ , _ , _ ')" [50,0,0,0]50 ) where
  mlet "G be -GraphGLIB-000M2", "x be objectHIDDENM1", "y be objectHIDDENM1", "e be objectHIDDENM1"
"pred e DJoinsGLIB-000R2(x,y,G) means
  (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =HIDDENR1 x) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =HIDDENR1 y"..

mdef glib_000_def_15 (" _ SJoinsGLIB-000R3'( _ , _ , _ ')" [50,0,0,0]50 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2", "Y be setHIDDENM2", "e be objectHIDDENM1"
"pred e SJoinsGLIB-000R3(X,Y,G) means
  e inHIDDENR3 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 Y or (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 Y & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X)"..

mdef glib_000_def_16 (" _ DSJoinsGLIB-000R4'( _ , _ , _ ')" [50,0,0,0]50 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2", "Y be setHIDDENM2", "e be objectHIDDENM1"
"pred e DSJoinsGLIB-000R4(X,Y,G) means
  (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 Y"..

mdef glib_000_def_17 ("finiteGLIB-000V2" 70 ) where
"attr finiteGLIB-000V2 for -GraphGLIB-000M2 means
  (\<lambda>G. the-Vertices-ofGLIB-000K6 G be finiteFINSET-1V1 & the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1)"..

mdef glib_000_def_18 ("looplessGLIB-000V3" 70 ) where
"attr looplessGLIB-000V3 for -GraphGLIB-000M2 means
  (\<lambda>G.  not ( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e))"..

mdef glib_000_def_19 ("trivialGLIB-000V4" 70 ) where
"attr trivialGLIB-000V4 for -GraphGLIB-000M2 means
  (\<lambda>G. cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G) =XBOOLE-0R4 \<one>\<^sub>M)"..

mdef glib_000_def_20 ("non-multiGLIB-000V5" 70 ) where
"attr non-multiGLIB-000V5 for -GraphGLIB-000M2 means
  (\<lambda>G.  for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,G) & e2 JoinsGLIB-000R1(v1,v2,G) implies e1 =HIDDENR1 e2)"..

mdef glib_000_def_21 ("non-DmultiGLIB-000V6" 70 ) where
"attr non-DmultiGLIB-000V6 for -GraphGLIB-000M2 means
  (\<lambda>G.  for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 DJoinsGLIB-000R2(v1,v2,G) & e2 DJoinsGLIB-000R2(v1,v2,G) implies e1 =HIDDENR1 e2)"..

mdef glib_000_def_22 ("simpleGLIB-000V7" 70 ) where
"attr simpleGLIB-000V7 for -GraphGLIB-000M2 means
  (\<lambda>G. G be looplessGLIB-000V3 & G be non-multiGLIB-000V5)"..

mdef glib_000_def_23 ("DsimpleGLIB-000V8" 70 ) where
"attr DsimpleGLIB-000V8 for -GraphGLIB-000M2 means
  (\<lambda>G. G be looplessGLIB-000V3 & G be non-DmultiGLIB-000V6)"..

mlemma glib_000_lm_2:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1 implies G be simpleGLIB-000V7"
proof(rule ballI,rule impI)
  fix G assume [ty]: "G be -GraphGLIB-000M2"
  assume A1: "the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1"
  then have A2: "G be looplessGLIB-000V3"
     sorry
  have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,G) & e2 JoinsGLIB-000R1(v1,v2,G) implies e1 =HIDDENR1 e2"
    using A1 sorry
  then have "G be non-multiGLIB-000V5"
     sorry
  thus "G be simpleGLIB-000V7"
    using A2 sorry
qed "sorry"

mtheorem glib_000_cl_5:
"cluster non-multiGLIB-000V5 also-is non-DmultiGLIB-000V6 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be non-multiGLIB-000V5 implies it be non-DmultiGLIB-000V6"
  proof-
    have " for G be -GraphGLIB-000M2 holds G be non-multiGLIB-000V5 implies G be non-DmultiGLIB-000V6"
    proof(rule ballI,rule impI)
      fix G assume [ty]: "G be -GraphGLIB-000M2"
      assume A1: "G be non-multiGLIB-000V5"
      have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 DJoinsGLIB-000R2(v1,v2,G) & e2 DJoinsGLIB-000R2(v1,v2,G) implies e1 =HIDDENR1 e2"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
        fix e1 assume [ty]: "e1 be objectHIDDENM1"
        fix e2 assume [ty]: "e2 be objectHIDDENM1"
        fix v1 assume [ty]: "v1 be objectHIDDENM1"
        fix v2 assume [ty]: "v2 be objectHIDDENM1"
        assume "e1 DJoinsGLIB-000R2(v1,v2,G) & e2 DJoinsGLIB-000R2(v1,v2,G)"
        then have "e1 JoinsGLIB-000R1(v1,v2,G) & e2 JoinsGLIB-000R1(v1,v2,G)"
           sorry
        thus "e1 =HIDDENR1 e2"
          using A1 sorry
      qed "sorry"
      thus "G be non-DmultiGLIB-000V6"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_6:
"cluster simpleGLIB-000V7 also-is looplessGLIB-000V3\<bar>non-multiGLIB-000V5 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be simpleGLIB-000V7 implies it be looplessGLIB-000V3\<bar>non-multiGLIB-000V5"
     sorry
qed "sorry"

mtheorem glib_000_cl_7:
"cluster looplessGLIB-000V3\<bar>non-multiGLIB-000V5 also-is simpleGLIB-000V7 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be looplessGLIB-000V3\<bar>non-multiGLIB-000V5 implies it be simpleGLIB-000V7"
     sorry
qed "sorry"

mtheorem glib_000_cl_8:
"cluster looplessGLIB-000V3\<bar>non-DmultiGLIB-000V6 also-is DsimpleGLIB-000V8 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be looplessGLIB-000V3\<bar>non-DmultiGLIB-000V6 implies it be DsimpleGLIB-000V8"
     sorry
qed "sorry"

mtheorem glib_000_cl_9:
"cluster DsimpleGLIB-000V8 also-is looplessGLIB-000V3\<bar>non-DmultiGLIB-000V6 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be DsimpleGLIB-000V8 implies it be looplessGLIB-000V3\<bar>non-DmultiGLIB-000V6"
     sorry
qed "sorry"

mtheorem glib_000_cl_10:
"cluster trivialGLIB-000V4\<bar>looplessGLIB-000V3 also-is finiteFINSET-1V1 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be trivialGLIB-000V4\<bar>looplessGLIB-000V3 implies it be finiteFINSET-1V1"
  proof-
    have " for G be -GraphGLIB-000M2 holds G be trivialGLIB-000V4 & G be looplessGLIB-000V3 implies G be finiteGLIB-000V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix G assume [ty]: "G be -GraphGLIB-000M2"
      assume A2: "G be trivialGLIB-000V4"
        and A3: "G be looplessGLIB-000V3"
      have "cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G) =XBOOLE-0R4 \<one>\<^sub>M"
        using A2 sorry
      then obtain v where
        [ty]:"v be objectHIDDENM1" and 
        A4: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {TARSKIK1 v}"
        using card_2_th_42 sorry
      have "the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
      proof-
        show "the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
        proof-
          have cases: "the-Edges-ofGLIB-000K7 G be emptyXBOOLE-0V1 or the-Edges-ofGLIB-000K7 G be  non emptyXBOOLE-0V1"
             sorry
          have case1: "the-Edges-ofGLIB-000K7 G be emptyXBOOLE-0V1 implies the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
          proof(rule impI)
            assume "the-Edges-ofGLIB-000K7 G be emptyXBOOLE-0V1"
            thus "the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
               sorry
          qed
          have case2: "the-Edges-ofGLIB-000K7 G be  non emptyXBOOLE-0V1 implies the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
          proof(rule impI)
            assume "the-Edges-ofGLIB-000K7 G be  non emptyXBOOLE-0V1"
            then obtain e where
              [ty]:"e be objectHIDDENM1" and 
              A5: "e inHIDDENR3 the-Edges-ofGLIB-000K7 G"
              using xboole_0_def_1 sorry
            have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
              using A5 funct_2_th_5 sorry
            then have A6: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =HIDDENR1 v"
              using A4 tarski_def_1 sorry
            have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
              using A5 funct_2_th_5 sorry
            then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =HIDDENR1 v"
              using A4 tarski_def_1 sorry
            thus "the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
              using A3 A5 A6 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "G be finiteGLIB-000V2"
        using A4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_11:
"cluster trivialGLIB-000V4\<bar>non-DmultiGLIB-000V6 also-is finiteFINSET-1V1 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it be trivialGLIB-000V4\<bar>non-DmultiGLIB-000V6 implies it be finiteFINSET-1V1"
  proof-
    have " for G be -GraphGLIB-000M2 holds G be trivialGLIB-000V4 & G be non-DmultiGLIB-000V6 implies G be finiteGLIB-000V2"
    proof(rule ballI,rule impMI ,rule impI)
      fix G assume [ty]: "G be -GraphGLIB-000M2"
      assume A7: "G be trivialGLIB-000V4"
        and A8: "G be non-DmultiGLIB-000V6"
      have "cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G) =XBOOLE-0R4 \<one>\<^sub>M"
        using A7 sorry
      then obtain v where
        [ty]:"v be objectHIDDENM1" and 
        A9: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {TARSKIK1 v}"
        using card_2_th_42 sorry
      have " not the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1 implies  False "
      proof(rule impI)
        let ?e1 = "the ElementSUBSET-1M1-of the-Edges-ofGLIB-000K7 G"
        let ?v1 = "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 ?e1"
        let ?v2 = "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 ?e1"
        assume A10: " not the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
        then have A11: "the-Edges-ofGLIB-000K7 G <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have "?v2 inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
          using A10 funct_2_th_5 sorry
        then have A12: "?v2 =HIDDENR1 v"
          using A9 tarski_def_1 sorry
        have "?v1 inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
          using A10 funct_2_th_5 sorry
        then have "?v1 =HIDDENR1 v"
          using A9 tarski_def_1 sorry
        then have A13: "?e1 DJoinsGLIB-000R2(v,v,G)"
          using A11 A12 sorry
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 {TARSKIK1 the ElementSUBSET-1M1-of the-Edges-ofGLIB-000K7 G } implies x inHIDDENR3 the-Edges-ofGLIB-000K7 G) & (x inHIDDENR3 the-Edges-ofGLIB-000K7 G implies x inHIDDENR3 {TARSKIK1 the ElementSUBSET-1M1-of the-Edges-ofGLIB-000K7 G })"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          let ?v1 = "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 x"
          let ?v2 = "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 x"
          show "x inHIDDENR3 {TARSKIK1 the ElementSUBSET-1M1-of the-Edges-ofGLIB-000K7 G } implies x inHIDDENR3 the-Edges-ofGLIB-000K7 G"
          proof(rule impI)
            assume "x inHIDDENR3 {TARSKIK1 ?e1}"
            then have "x =HIDDENR1 ?e1"
              using tarski_def_1 sorry
            thus "x inHIDDENR3 the-Edges-ofGLIB-000K7 G"
              using A11 sorry
          qed
          assume A14: "x inHIDDENR3 the-Edges-ofGLIB-000K7 G"
          then have "?v2 inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
            using funct_2_th_5 sorry
          then have A15: "?v2 =HIDDENR1 v"
            using A9 tarski_def_1 sorry
          have "?v1 inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
            using A14 funct_2_th_5 sorry
          then have "?v1 =HIDDENR1 v"
            using A9 tarski_def_1 sorry
          then have "x DJoinsGLIB-000R2(v,v,G)"
            using A14 A15 sorry
          then have "x =HIDDENR1 ?e1"
            using A8 A13 sorry
          thus "x inHIDDENR3 {TARSKIK1 the ElementSUBSET-1M1-of the-Edges-ofGLIB-000K7 G }"
            using tarski_def_1 sorry
        qed "sorry"
        thus " False "
          using A10 tarski_th_2 sorry
      qed
      thus "G be finiteGLIB-000V2"
        using A9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_12:
"cluster trivialGLIB-000V4\<bar>simpleGLIB-000V7 for -GraphGLIB-000M2"
proof
(*existence*)
  show " ex it be -GraphGLIB-000M2 st it be trivialGLIB-000V4\<bar>simpleGLIB-000V7"
  proof-
    have " ex tVar2 be -GraphGLIB-000M2 st tVar2 be trivialGLIB-000V4 & tVar2 be simpleGLIB-000V7"
    proof-
      let ?V = "{DOMAIN-1K6\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M}"
      let ?E = "{}XBOOLE-0K1"
      obtain S where 
        [ty]:"S be FunctionFUNCT-2M1-of(?E,?V)" and SDef:"S = {}XBOOLE-0K1"
        using relset_1_th_12 sorry
      let ?G = "createGraphGLIB-000K12(?V,?E,S,S)"
      show " ex tVar2 be -GraphGLIB-000M2 st tVar2 be trivialGLIB-000V4 & tVar2 be simpleGLIB-000V7"
      proof(rule bexI[of _ "?G"],rule conjMI)
        have "the-Vertices-ofGLIB-000K6 ?G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M}"
          using finseq_4_th_76 sorry
        then have "cardCARD-1K1 (the-Vertices-ofGLIB-000K6 ?G) =XBOOLE-0R4 \<one>\<^sub>M"
          using card_1_th_30 sorry
        thus "createGraphGLIB-000K12({DOMAIN-1K6\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M},{}XBOOLE-0K1,S,S) be trivialGLIB-000V4"
           sorry
        have "the-Edges-ofGLIB-000K7 ?G =XBOOLE-0R4 {}XBOOLE-0K1"
          using finseq_4_th_76 sorry
        then have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,?G) & e2 JoinsGLIB-000R1(v1,v2,?G) implies e1 =HIDDENR1 e2"
           sorry
        then have A1: "?G be non-multiGLIB-000V5"
           sorry
        have " not ( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K7 ?G & (the-Source-ofGLIB-000K10 ?G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 ?G).FUNCT-1K1 e)"
          using finseq_4_th_76 sorry
        then have "?G be looplessGLIB-000V3"
           sorry
        thus "createGraphGLIB-000K12({DOMAIN-1K6\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M},{}XBOOLE-0K1,S,S) be simpleGLIB-000V7"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_13:
"cluster finiteFINSET-1V1\<bar> non trivialGLIB-000V4\<bar>simpleGLIB-000V7 for -GraphGLIB-000M2"
proof
(*existence*)
  show " ex it be -GraphGLIB-000M2 st it be finiteFINSET-1V1\<bar> non trivialGLIB-000V4\<bar>simpleGLIB-000V7"
  proof-
    have " ex tVar3 be -GraphGLIB-000M2 st tVar3 be finiteGLIB-000V2 & (tVar3 be  non trivialGLIB-000V4 & tVar3 be simpleGLIB-000V7)"
    proof-
      let ?V = "{DOMAIN-1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M }"
      let ?E = "{}XBOOLE-0K1"
      obtain S where 
        [ty]:"S be FunctionFUNCT-2M1-of(?E,?V)" and SDef:"S = {}XBOOLE-0K1"
        using relset_1_th_12 sorry
      let ?G = "createGraphGLIB-000K12(?V,?E,S,S)"
      show " ex tVar3 be -GraphGLIB-000M2 st tVar3 be finiteGLIB-000V2 & (tVar3 be  non trivialGLIB-000V4 & tVar3 be simpleGLIB-000V7)"
      proof(rule bexI[of _ "?G"],rule conjMI,rule conjMI)
        have A2: "the-Edges-ofGLIB-000K7 ?G =XBOOLE-0R4 {}XBOOLE-0K1"
          using finseq_4_th_76 sorry
        have A3: "the-Vertices-ofGLIB-000K6 ?G =XBOOLE-0R4 {DOMAIN-1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M }"
          using finseq_4_th_76 sorry
        thus "createGraphGLIB-000K12({DOMAIN-1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M },{}XBOOLE-0K1,S,S) be finiteGLIB-000V2"
          using A2 sorry
        have "cardCARD-1K1 (the-Vertices-ofGLIB-000K6 ?G) <>HIDDENR2 \<one>\<^sub>M"
          using A3 card_2_th_57 sorry
        thus "createGraphGLIB-000K12({DOMAIN-1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M },{}XBOOLE-0K1,S,S) be  non trivialGLIB-000V4"
           sorry
        have " not ( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K7 ?G & (the-Source-ofGLIB-000K10 ?G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 ?G).FUNCT-1K1 e)"
          using finseq_4_th_76 sorry
        then have A4: "?G be looplessGLIB-000V3"
           sorry
        have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,?G) & e2 JoinsGLIB-000R1(v1,v2,?G) implies e1 =HIDDENR1 e2"
          using A2 sorry
        then have "?G be non-multiGLIB-000V5"
           sorry
        thus "createGraphGLIB-000K12({DOMAIN-1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M },{}XBOOLE-0K1,S,S) be simpleGLIB-000V7"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_14:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster the-Vertices-ofGLIB-000K6 G as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "the-Vertices-ofGLIB-000K6 G be finiteFINSET-1V1"
    using glib_000_def_17 sorry
qed "sorry"

mtheorem glib_000_cl_15:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster the-Edges-ofGLIB-000K7 G as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "the-Edges-ofGLIB-000K7 G be finiteFINSET-1V1"
    using glib_000_def_17 sorry
qed "sorry"

mtheorem glib_000_cl_16:
  mlet "G be trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
"cluster the-Vertices-ofGLIB-000K6 G as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "the-Vertices-ofGLIB-000K6 G be finiteFINSET-1V1"
  proof-
    have "cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G) =XBOOLE-0R4 \<one>\<^sub>M"
      using glib_000_def_19 sorry
    thus "the-Vertices-ofGLIB-000K6 G be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_17:
  mlet "V be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "E be finiteFINSET-1V1\<bar>setHIDDENM2", "S be FunctionFUNCT-2M1-of(E,V)", "T be FunctionFUNCT-2M1-of(E,V)"
"cluster createGraphGLIB-000K12(V,E,S,T) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "createGraphGLIB-000K12(V,E,S,T) be finiteFINSET-1V1"
    using finseq_4_th_76 sorry
qed "sorry"

mtheorem glib_000_cl_18:
  mlet "V be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be emptyXBOOLE-0V1\<bar>setHIDDENM2", "S be FunctionFUNCT-2M1-of(E,V)", "T be FunctionFUNCT-2M1-of(E,V)"
"cluster createGraphGLIB-000K12(V,E,S,T) as-term-is simpleGLIB-000V7"
proof
(*coherence*)
  show "createGraphGLIB-000K12(V,E,S,T) be simpleGLIB-000V7"
  proof-
    let ?G = "createGraphGLIB-000K12(V,E,S,T)"
    have "the-Edges-ofGLIB-000K7 ?G =XBOOLE-0R4 E"
      using finseq_4_th_76 sorry
    then have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,?G) & e2 JoinsGLIB-000R1(v1,v2,?G) implies e1 =HIDDENR1 e2"
       sorry
    then have A1: "?G be non-multiGLIB-000V5"
       sorry
    have " not ( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K7 ?G & (the-Source-ofGLIB-000K10 ?G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 ?G).FUNCT-1K1 e)"
      using finseq_4_th_76 sorry
    then have "?G be looplessGLIB-000V3"
       sorry
    thus "createGraphGLIB-000K12(V,E,S,T) be simpleGLIB-000V7"
      using A1 sorry
  qed
qed "sorry"

mtheorem glib_000_cl_19:
  mlet "v be setHIDDENM2", "E be setHIDDENM2", "S be FunctionFUNCT-2M1-of(E,{TARSKIK1 v})", "T be FunctionFUNCT-2M1-of(E,{TARSKIK1 v})"
"cluster createGraphGLIB-000K12({TARSKIK1 v},E,S,T) as-term-is trivialGLIB-000V4"
proof
(*coherence*)
  show "createGraphGLIB-000K12({TARSKIK1 v},E,S,T) be trivialGLIB-000V4"
  proof-
    let ?G = "createGraphGLIB-000K12({TARSKIK1 v},E,S,T)"
    have "the-Vertices-ofGLIB-000K6 ?G =XBOOLE-0R4 {TARSKIK1 v}"
      using finseq_4_th_76 sorry
    then have "cardCARD-1K1 (the-Vertices-ofGLIB-000K6 ?G) =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 sorry
    thus "createGraphGLIB-000K12({TARSKIK1 v},E,S,T) be trivialGLIB-000V4"
       sorry
  qed
qed "sorry"

mdef glib_000_def_24 (" _ .order'(')GLIB-000K14" [260]260 ) where
  mlet "G be -GraphGLIB-000M2"
"func G .order()GLIB-000K14 \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G)"
proof-
  (*coherence*)
    show "cardCARD-1K1 (the-Vertices-ofGLIB-000K6 G) be CardinalCARD-1M1"
       sorry
qed "sorry"

abbreviation(input) GLIB_000K15(" _ .order'(')GLIB-000K15" [260]260) where
  "G .order()GLIB-000K15 \<equiv> G .order()GLIB-000K14"

mtheorem glib_000_add_3:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster G .order()GLIB-000K14 as-term-is  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "G .order()GLIB-000K14 be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "G .order()GLIB-000K14 =XBOOLE-0R4 cardCARD-1K4 (the-Vertices-ofGLIB-000K6 G)"
       sorry
    thus "G .order()GLIB-000K14 be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

mdef glib_000_def_25 (" _ .size'(')GLIB-000K16" [260]260 ) where
  mlet "G be -GraphGLIB-000M2"
"func G .size()GLIB-000K16 \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 (the-Edges-ofGLIB-000K7 G)"
proof-
  (*coherence*)
    show "cardCARD-1K1 (the-Edges-ofGLIB-000K7 G) be CardinalCARD-1M1"
       sorry
qed "sorry"

abbreviation(input) GLIB_000K17(" _ .size'(')GLIB-000K17" [260]260) where
  "G .size()GLIB-000K17 \<equiv> G .size()GLIB-000K16"

mtheorem glib_000_add_4:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster G .size()GLIB-000K16 as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "G .size()GLIB-000K16 be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "G .size()GLIB-000K16 =XBOOLE-0R4 cardCARD-1K4 (the-Edges-ofGLIB-000K7 G)"
       sorry
    thus "G .size()GLIB-000K16 be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

mdef glib_000_def_26 (" _ .edgesIntoGLIB-000K18  _ " [260,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2"
"func G .edgesIntoGLIB-000K18 X \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G means
  \<lambda>it.  for e be setHIDDENM2 holds e inTARSKIR2 it iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be setHIDDENM2 holds e inTARSKIR2 it iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
    proof-
      have " ex tVar4 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be setHIDDENM2 holds  not (e inTARSKIR2 tVar4 &  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X)) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) &  not e inTARSKIR2 tVar4)"
      proof-
        let ?P = "\<lambda>Lamb1. (the-Target-ofGLIB-000K11 G).FUNCT-1K1 Lamb1 inTARSKIR2 X"
        obtain IT where
          [ty]:"IT be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G" and 
          A1: " for e be setHIDDENM2 holds e inTARSKIR2 IT iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ?P(e)"
          using subset_1_sch_1 sorry
        show " ex tVar4 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be setHIDDENM2 holds  not (e inTARSKIR2 tVar4 &  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X)) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) &  not e inTARSKIR2 tVar4)"
        proof(rule bexI[of _ "IT"])
          show " for e be setHIDDENM2 holds  not (e inTARSKIR2 IT &  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X)) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) &  not e inTARSKIR2 IT)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for it2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be setHIDDENM2 holds e inTARSKIR2 it1 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) & ( for e be setHIDDENM2 holds e inTARSKIR2 it2 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for IT2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be setHIDDENM2 holds e inTARSKIR2 IT1 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) & ( for e be setHIDDENM2 holds e inTARSKIR2 IT2 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) implies IT1 =HIDDENR1 IT2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix IT1 assume [ty]: "IT1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
        fix IT2 assume [ty]: "IT2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
        assume A2: " for e be setHIDDENM2 holds e inTARSKIR2 IT1 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
          and A3: " for e be setHIDDENM2 holds e inTARSKIR2 IT2 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
        have " for e be objectHIDDENM1 holds (e inHIDDENR3 IT1 implies e inHIDDENR3 IT2) & (e inHIDDENR3 IT2 implies e inHIDDENR3 IT1)"
        proof(rule ballI,rule conjMI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          show "e inHIDDENR3 IT1 implies e inHIDDENR3 IT2"
          proof(rule impI)
            assume A4: "e inHIDDENR3 IT1"
            then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
              using A2 sorry
            thus "e inHIDDENR3 IT2"
              using A3 A4 sorry
          qed
          assume A5: "e inHIDDENR3 IT2"
          then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
            using A3 sorry
          thus "e inHIDDENR3 IT1"
            using A2 A5 sorry
        qed "sorry"
        thus "IT1 =HIDDENR1 IT2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef glib_000_def_27 (" _ .edgesOutOfGLIB-000K19  _ " [260,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2"
"func G .edgesOutOfGLIB-000K19 X \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G means
  \<lambda>it.  for e be setHIDDENM2 holds e inTARSKIR2 it iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be setHIDDENM2 holds e inTARSKIR2 it iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
    proof-
      have " ex tVar5 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be setHIDDENM2 holds  not (e inTARSKIR2 tVar5 &  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X)) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) &  not e inTARSKIR2 tVar5)"
      proof-
        let ?P = "\<lambda>Lamb1. (the-Source-ofGLIB-000K10 G).FUNCT-1K1 Lamb1 inTARSKIR2 X"
        obtain IT where
          [ty]:"IT be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G" and 
          A6: " for e be setHIDDENM2 holds e inTARSKIR2 IT iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ?P(e)"
          using subset_1_sch_1 sorry
        show " ex tVar5 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be setHIDDENM2 holds  not (e inTARSKIR2 tVar5 &  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X)) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) &  not e inTARSKIR2 tVar5)"
        proof(rule bexI[of _ "IT"])
          show " for e be setHIDDENM2 holds  not (e inTARSKIR2 IT &  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X)) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) &  not e inTARSKIR2 IT)"
            using A6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for it2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be setHIDDENM2 holds e inTARSKIR2 it1 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & ( for e be setHIDDENM2 holds e inTARSKIR2 it2 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for IT2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be setHIDDENM2 holds e inTARSKIR2 IT1 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & ( for e be setHIDDENM2 holds e inTARSKIR2 IT2 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) implies IT1 =HIDDENR1 IT2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix IT1 assume [ty]: "IT1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
        fix IT2 assume [ty]: "IT2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
        assume A7: " for e be setHIDDENM2 holds e inTARSKIR2 IT1 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
          and A8: " for e be setHIDDENM2 holds e inTARSKIR2 IT2 iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
        have " for e be objectHIDDENM1 holds (e inHIDDENR3 IT1 implies e inHIDDENR3 IT2) & (e inHIDDENR3 IT2 implies e inHIDDENR3 IT1)"
        proof(rule ballI,rule conjMI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          show "e inHIDDENR3 IT1 implies e inHIDDENR3 IT2"
          proof(rule impI)
            assume A9: "e inHIDDENR3 IT1"
            then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
              using A7 sorry
            thus "e inHIDDENR3 IT2"
              using A8 A9 sorry
          qed
          assume A10: "e inHIDDENR3 IT2"
          then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
            using A8 sorry
          thus "e inHIDDENR3 IT1"
            using A7 A10 sorry
        qed "sorry"
        thus "IT1 =HIDDENR1 IT2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef glib_000_def_28 (" _ .edgesInOutGLIB-000K20  _ " [260,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2"
"func G .edgesInOutGLIB-000K20 X \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesIntoGLIB-000K18 X \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> G .edgesOutOfGLIB-000K19 X"
proof-
  (*coherence*)
    show "G .edgesIntoGLIB-000K18 X \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> G .edgesOutOfGLIB-000K19 X be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mdef glib_000_def_29 (" _ .edgesBetweenGLIB-000K21  _ " [260,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2"
"func G .edgesBetweenGLIB-000K21 X \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesIntoGLIB-000K18 X /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> G .edgesOutOfGLIB-000K19 X"
proof-
  (*coherence*)
    show "G .edgesIntoGLIB-000K18 X /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> G .edgesOutOfGLIB-000K19 X be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mdef glib_000_def_30 (" _ .edgesBetweenGLIB-000K22'( _ , _ ')" [260,0,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2", "Y be setHIDDENM2"
"func G .edgesBetweenGLIB-000K22(X,Y) \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G means
  \<lambda>it.  for e be objectHIDDENM1 holds e inHIDDENR3 it iff e SJoinsGLIB-000R3(X,Y,G)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be objectHIDDENM1 holds e inHIDDENR3 it iff e SJoinsGLIB-000R3(X,Y,G)"
    proof-
      have " ex tVar6 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be objectHIDDENM1 holds (e inHIDDENR3 tVar6 implies e SJoinsGLIB-000R3(X,Y,G)) & (e SJoinsGLIB-000R3(X,Y,G) implies e inHIDDENR3 tVar6)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 SJoinsGLIB-000R3(X,Y,G)"
        obtain IT where
          [ty]:"IT be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G" and 
          A1: " for e be setHIDDENM2 holds e inTARSKIR2 IT iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ?P(e)"
          using subset_1_sch_1 sorry
        show " ex tVar6 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be objectHIDDENM1 holds (e inHIDDENR3 tVar6 implies e SJoinsGLIB-000R3(X,Y,G)) & (e SJoinsGLIB-000R3(X,Y,G) implies e inHIDDENR3 tVar6)"
        proof(rule bexI[of _ "IT"],rule ballI,rule conjMI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          show "e inHIDDENR3 IT implies e SJoinsGLIB-000R3(X,Y,G)"
            using A1 sorry
          assume A2: "e SJoinsGLIB-000R3(X,Y,G)"
          show "e inHIDDENR3 IT"
            using A1 A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for it2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be objectHIDDENM1 holds e inHIDDENR3 it1 iff e SJoinsGLIB-000R3(X,Y,G)) & ( for e be objectHIDDENM1 holds e inHIDDENR3 it2 iff e SJoinsGLIB-000R3(X,Y,G)) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for IT2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be objectHIDDENM1 holds e inHIDDENR3 IT1 iff e SJoinsGLIB-000R3(X,Y,G)) & ( for e be objectHIDDENM1 holds e inHIDDENR3 IT2 iff e SJoinsGLIB-000R3(X,Y,G)) implies IT1 =HIDDENR1 IT2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix IT1 assume [ty]: "IT1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
        fix IT2 assume [ty]: "IT2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
        assume A3: " for e be objectHIDDENM1 holds e inHIDDENR3 IT1 iff e SJoinsGLIB-000R3(X,Y,G)"
          and A4: " for e be objectHIDDENM1 holds e inHIDDENR3 IT2 iff e SJoinsGLIB-000R3(X,Y,G)"
        have " for e be objectHIDDENM1 holds e inHIDDENR3 IT2 iff e inHIDDENR3 IT1"
          using A3 A4 sorry
        thus "IT1 =HIDDENR1 IT2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef glib_000_def_31 (" _ .edgesDBetweenGLIB-000K23'( _ , _ ')" [260,0,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "X be setHIDDENM2", "Y be setHIDDENM2"
"func G .edgesDBetweenGLIB-000K23(X,Y) \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G means
  \<lambda>it.  for e be objectHIDDENM1 holds e inHIDDENR3 it iff e DSJoinsGLIB-000R4(X,Y,G)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be objectHIDDENM1 holds e inHIDDENR3 it iff e DSJoinsGLIB-000R4(X,Y,G)"
    proof-
      have " ex tVar7 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be objectHIDDENM1 holds (e inHIDDENR3 tVar7 implies e DSJoinsGLIB-000R4(X,Y,G)) & (e DSJoinsGLIB-000R4(X,Y,G) implies e inHIDDENR3 tVar7)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 DSJoinsGLIB-000R4(X,Y,G)"
        obtain IT where
          [ty]:"IT be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G" and 
          A5: " for e be setHIDDENM2 holds e inTARSKIR2 IT iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ?P(e)"
          using subset_1_sch_1 sorry
        show " ex tVar7 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G st  for e be objectHIDDENM1 holds (e inHIDDENR3 tVar7 implies e DSJoinsGLIB-000R4(X,Y,G)) & (e DSJoinsGLIB-000R4(X,Y,G) implies e inHIDDENR3 tVar7)"
        proof(rule bexI[of _ "IT"],rule ballI,rule conjMI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          show "e inHIDDENR3 IT implies e DSJoinsGLIB-000R4(X,Y,G)"
            using A5 sorry
          assume A6: "e DSJoinsGLIB-000R4(X,Y,G)"
          show "e inHIDDENR3 IT"
            using A5 A6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for it2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be objectHIDDENM1 holds e inHIDDENR3 it1 iff e DSJoinsGLIB-000R4(X,Y,G)) & ( for e be objectHIDDENM1 holds e inHIDDENR3 it2 iff e DSJoinsGLIB-000R4(X,Y,G)) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds  for IT2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G holds ( for e be objectHIDDENM1 holds e inHIDDENR3 IT1 iff e DSJoinsGLIB-000R4(X,Y,G)) & ( for e be objectHIDDENM1 holds e inHIDDENR3 IT2 iff e DSJoinsGLIB-000R4(X,Y,G)) implies IT1 =HIDDENR1 IT2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix IT1 assume [ty]: "IT1 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
        fix IT2 assume [ty]: "IT2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
        assume A7: " for e be objectHIDDENM1 holds e inHIDDENR3 IT1 iff e DSJoinsGLIB-000R4(X,Y,G)"
          and A8: " for e be objectHIDDENM1 holds e inHIDDENR3 IT2 iff e DSJoinsGLIB-000R4(X,Y,G)"
        have " for e be objectHIDDENM1 holds e inHIDDENR3 IT2 iff e inHIDDENR3 IT1"
          using A7 A8 sorry
        thus "IT1 =HIDDENR1 IT2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

theorem glib_000_sch_1:
  fixes Pp1 
  assumes
    A1: " for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds G .order()GLIB-000K15 =XBOOLE-0R4 \<one>\<^sub>M implies Pp1(G)" and
   A2: " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ( for Gk be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Gk .order()GLIB-000K15 =XBOOLE-0R4 k implies Pp1(Gk)) implies ( for Gk1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Gk1 .order()GLIB-000K15 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies Pp1(Gk1))"
  shows " for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Pp1(G)"
  proof(rule ballI)
    let ?P2 = "\<lambda>Lamb1.  for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds G .order()GLIB-000K15 =XBOOLE-0R4 Lamb1 implies Pp1(G)"
    have A3: " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ?P2(k) implies ?P2(k +NAT-1K1 \<one>\<^sub>M)"
      using A2 sorry
    fix G assume [ty]: "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
    have A4: "G .order()GLIB-000K15 =XBOOLE-0R4 G .order()GLIB-000K15"
       sorry
    have A5: "?P2(\<one>\<^sub>M)"
      using A1 sorry
    have " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ?P2(k)"
      using nat_1_sch_10 A5 A3 sorry
    thus "Pp1(G)"
      using A4 sorry
  qed "sorry"

theorem glib_000_sch_2:
  fixes Pp1 
  assumes
    A1: " for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds G .size()GLIB-000K17 =XBOOLE-0R4 0NUMBERSK6 implies Pp1(G)" and
   A2: " for k be NatNAT-1M1 holds ( for Gk be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Gk .size()GLIB-000K17 =XBOOLE-0R4 k implies Pp1(Gk)) implies ( for Gk1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Gk1 .size()GLIB-000K17 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies Pp1(Gk1))"
  shows " for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds Pp1(G)"
  proof(rule ballI)
    let ?P2 = "\<lambda>Lamb1.  for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds G .size()GLIB-000K17 =XBOOLE-0R4 Lamb1 implies Pp1(G)"
    have A3: " for k be NatNAT-1M1 holds ?P2(k) implies ?P2(k +NAT-1K1 \<one>\<^sub>M)"
      using A2 sorry
    fix G assume [ty]: "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
    have A4: "G .size()GLIB-000K17 =XBOOLE-0R4 G .size()GLIB-000K17"
       sorry
    have A5: "?P2(0NUMBERSK6)"
      using A1 sorry
    have " for k be NatNAT-1M1 holds ?P2(k)"
      using nat_1_sch_2 A5 A3 sorry
    thus "Pp1(G)"
      using A4 sorry
  qed "sorry"

mdef glib_000_def_32 ("SubgraphGLIB-000M3-of  _ " [70]70 ) where
  mlet "G be -GraphGLIB-000M2"
"mode SubgraphGLIB-000M3-of G \<rightarrow> -GraphGLIB-000M2 means
  (\<lambda>it. (the-Vertices-ofGLIB-000K6 it c=TARSKIR1 the-Vertices-ofGLIB-000K6 G & the-Edges-ofGLIB-000K7 it c=TARSKIR1 the-Edges-ofGLIB-000K7 G) & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 it implies (the-Source-ofGLIB-000K10 it).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 it).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e))"
proof-
  (*existence*)
    show " ex it be -GraphGLIB-000M2 st (the-Vertices-ofGLIB-000K6 it c=TARSKIR1 the-Vertices-ofGLIB-000K6 G & the-Edges-ofGLIB-000K7 it c=TARSKIR1 the-Edges-ofGLIB-000K7 G) & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 it implies (the-Source-ofGLIB-000K10 it).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 it).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e)"
    proof-
      have " ex tVar8 be -GraphGLIB-000M2 st (the-Vertices-ofGLIB-000K6 tVar8 c=TARSKIR1 the-Vertices-ofGLIB-000K6 tVar8 & the-Edges-ofGLIB-000K7 tVar8 c=TARSKIR1 the-Edges-ofGLIB-000K7 tVar8) & ( for e be setHIDDENM2 holds  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 tVar8 &  not ((the-Source-ofGLIB-000K10 tVar8).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 tVar8).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 tVar8).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 tVar8).FUNCT-1K1 e)))"
      proof-
        show " ex tVar8 be -GraphGLIB-000M2 st (the-Vertices-ofGLIB-000K6 tVar8 c=TARSKIR1 the-Vertices-ofGLIB-000K6 tVar8 & the-Edges-ofGLIB-000K7 tVar8 c=TARSKIR1 the-Edges-ofGLIB-000K7 tVar8) & ( for e be setHIDDENM2 holds  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 tVar8 &  not ((the-Source-ofGLIB-000K10 tVar8).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 tVar8).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 tVar8).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 tVar8).FUNCT-1K1 e)))"
        proof(rule bexI[of _ "G"])
          show "(the-Vertices-ofGLIB-000K6 G c=TARSKIR1 the-Vertices-ofGLIB-000K6 G & the-Edges-ofGLIB-000K7 G c=TARSKIR1 the-Edges-ofGLIB-000K7 G) & ( for e be setHIDDENM2 holds  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G &  not ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e)))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

syntax GLIB_000K24 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("the-Vertices-ofGLIB-000K24\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2" \<rightharpoonup> "the-Vertices-ofGLIB-000K6 G2"

mtheorem glib_000_add_5:
  mlet "G1 be -GraphGLIB-000M2", "G2 be SubgraphGLIB-000M3-of G1"
"cluster the-Vertices-ofGLIB-000K6 G2 as-term-is  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1"
proof
(*coherence*)
  show "the-Vertices-ofGLIB-000K6 G2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1"
    using glib_000_def_32 sorry
qed "sorry"

syntax GLIB_000K25 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("the-Edges-ofGLIB-000K25\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2" \<rightharpoonup> "the-Edges-ofGLIB-000K7 G2"

mtheorem glib_000_add_6:
  mlet "G1 be -GraphGLIB-000M2", "G2 be SubgraphGLIB-000M3-of G1"
"cluster the-Edges-ofGLIB-000K7 G2 as-term-is SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G1"
proof
(*coherence*)
  show "the-Edges-ofGLIB-000K7 G2 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G1"
    using glib_000_def_32 sorry
qed "sorry"

mtheorem glib_000_cl_20:
  mlet "G be -GraphGLIB-000M2"
"cluster trivialGLIB-000V4\<bar>simpleGLIB-000V7 for SubgraphGLIB-000M3-of G"
proof
(*existence*)
  show " ex it be SubgraphGLIB-000M3-of G st it be trivialGLIB-000V4\<bar>simpleGLIB-000V7"
  proof-
    have " ex tVar9 be SubgraphGLIB-000M3-of G st tVar9 be trivialGLIB-000V4 & tVar9 be simpleGLIB-000V7"
    proof-
      let ?v = "the ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G"
      let ?V = "{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> ?v}"
      let ?E = "{}XBOOLE-0K1"
      obtain S where 
        [ty]:"S be FunctionFUNCT-2M1-of(?E,?V)" and SDef:"S = {}XBOOLE-0K1"
        using relset_1_th_12 sorry
      let ?IT = "createGraphGLIB-000K12(?V,?E,S,S)"
      have A1: "the-Vertices-ofGLIB-000K6 ?IT =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> ?v} & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 ?IT implies (the-Source-ofGLIB-000K10 ?IT).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 ?IT).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e)"
        using finseq_4_th_76 sorry
      have "the-Edges-ofGLIB-000K7 ?IT =XBOOLE-0R4 {}XBOOLE-0K1"
        using finseq_4_th_76 sorry
      then have "the-Edges-ofGLIB-000K7 ?IT c=TARSKIR1 the-Edges-ofGLIB-000K7 G"
         sorry
      then obtain IT where 
        [ty]:"IT be SubgraphGLIB-000M3-of G" and ITDef:"IT = ?IT"
        using A1 glib_000_def_32 sorry
      show " ex tVar9 be SubgraphGLIB-000M3-of G st tVar9 be trivialGLIB-000V4 & tVar9 be simpleGLIB-000V7"
      proof(rule bexI[of _ "IT"])
        show "IT be trivialGLIB-000V4 & IT be simpleGLIB-000V7"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma glib_000_lm_3:
" for G be -GraphGLIB-000M2 holds G be SubgraphGLIB-000M3-of G"
proof(rule ballI)
  fix G assume [ty]: "G be -GraphGLIB-000M2"
  have " for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 G implies (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
     sorry
  thus "G be SubgraphGLIB-000M3-of G"
    using glib_000_def_32 sorry
qed "sorry"

mlemma glib_000_lm_4:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for e be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G2) implies e JoinsGLIB-000R1(x,y,G1)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
  fix x assume [ty]: "x be objectHIDDENM1"
  fix y assume [ty]: "y be objectHIDDENM1"
  fix e assume [ty]: "e be objectHIDDENM1"
  assume A1: "e JoinsGLIB-000R1(x,y,G2)"
  then have A2: "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
     sorry
  have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =HIDDENR1 x & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =HIDDENR1 y or (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =HIDDENR1 y & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =HIDDENR1 x"
    using A1 sorry
  then have "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =HIDDENR1 x & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =HIDDENR1 y or (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =HIDDENR1 y & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =HIDDENR1 x"
    using A2 glib_000_def_32 sorry
  thus "e JoinsGLIB-000R1(x,y,G1)"
    using A2 sorry
qed "sorry"

mtheorem glib_000_cl_21:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
"cluster note-that finiteGLIB-000V2 for SubgraphGLIB-000M3-of G"
proof
(*coherence*)
  show " for it be SubgraphGLIB-000M3-of G holds it be finiteGLIB-000V2"
  proof-
    have " for G2 be SubgraphGLIB-000M3-of G holds G2 be finiteGLIB-000V2"
    proof(rule ballI)
      fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G"
      have "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 be finiteFINSET-1V1 & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 be finiteFINSET-1V1"
         sorry
      thus "G2 be finiteGLIB-000V2"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_22:
  mlet "G be looplessGLIB-000V3\<bar>-GraphGLIB-000M2"
"cluster note-that looplessGLIB-000V3 for SubgraphGLIB-000M3-of G"
proof
(*coherence*)
  show " for it be SubgraphGLIB-000M3-of G holds it be looplessGLIB-000V3"
  proof-
    have " for G2 be SubgraphGLIB-000M3-of G holds G2 be looplessGLIB-000V3"
    proof(rule ballI)
      fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G"
      have "( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 & (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e) implies  False "
      proof(rule impI)
        assume Given: " ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 & (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
        then obtain e where
          [ty]:"e be objectHIDDENM1" and 
          A1: "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"and A2: "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
           sorry
        have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
          using A1 glib_000_def_32 sorry
        thus " False "
          using A1 A2 glib_000_def_18 sorry
      qed
      thus "G2 be looplessGLIB-000V3"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_23:
  mlet "G be trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
"cluster note-that trivialGLIB-000V4 for SubgraphGLIB-000M3-of G"
proof
(*coherence*)
  show " for it be SubgraphGLIB-000M3-of G holds it be trivialGLIB-000V4"
  proof-
    have " for G2 be SubgraphGLIB-000M3-of G holds G2 be trivialGLIB-000V4"
    proof(rule ballI)
      fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G"
      have "cardCARD-1K4 (the-Vertices-ofGLIB-000K6 G) =XBOOLE-0R4 \<one>\<^sub>M"
        using glib_000_def_19 sorry
      then obtain v where
        [ty]:"v be objectHIDDENM1" and 
        A1: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {TARSKIK1 v}"
        using card_2_th_42 sorry
      have "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 =XBOOLE-0R4 {TARSKIK1 v}"
        using A1 zfmisc_1_th_33 sorry
      then have "cardCARD-1K4 (the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2) =XBOOLE-0R4 \<one>\<^sub>M"
        using card_1_th_30 sorry
      thus "G2 be trivialGLIB-000V4"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_24:
  mlet "G be non-multiGLIB-000V5\<bar>-GraphGLIB-000M2"
"cluster note-that non-multiGLIB-000V5 for SubgraphGLIB-000M3-of G"
proof
(*coherence*)
  show " for it be SubgraphGLIB-000M3-of G holds it be non-multiGLIB-000V5"
  proof-
    have " for G2 be SubgraphGLIB-000M3-of G holds G2 be non-multiGLIB-000V5"
    proof(rule ballI)
      fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G"
      have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,G2) & e2 JoinsGLIB-000R1(v1,v2,G2) implies e1 =HIDDENR1 e2"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
        fix e1 assume [ty]: "e1 be objectHIDDENM1"
        fix e2 assume [ty]: "e2 be objectHIDDENM1"
        fix v1 assume [ty]: "v1 be objectHIDDENM1"
        fix v2 assume [ty]: "v2 be objectHIDDENM1"
        assume "e1 JoinsGLIB-000R1(v1,v2,G2) & e2 JoinsGLIB-000R1(v1,v2,G2)"
        then have "e1 JoinsGLIB-000R1(v1,v2,G) & e2 JoinsGLIB-000R1(v1,v2,G)"
          using glib_000_lm_4 sorry
        thus "e1 =HIDDENR1 e2"
          using glib_000_def_20 sorry
      qed "sorry"
      thus "G2 be non-multiGLIB-000V5"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef glib_000_def_33 ("spanningGLIB-000V9\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "G1 be -GraphGLIB-000M2"
"attr spanningGLIB-000V9\<^bsub>(G1)\<^esub> for SubgraphGLIB-000M3-of G1 means
  (\<lambda>G2. the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1)"..

mtheorem glib_000_cl_25:
  mlet "G be -GraphGLIB-000M2"
"cluster spanningGLIB-000V9\<^bsub>(G)\<^esub> for SubgraphGLIB-000M3-of G"
proof
(*existence*)
  show " ex it be SubgraphGLIB-000M3-of G st it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
  proof-
    have " ex tVar10 be SubgraphGLIB-000M3-of G st tVar10 be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
    proof-
      obtain G9 where 
        [ty]:"G9 be SubgraphGLIB-000M3-of G" and G9Def:"G9 = G"
        using glib_000_lm_3 sorry
      show " ex tVar10 be SubgraphGLIB-000M3-of G st tVar10 be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
      proof(rule bexI[of _ "G9"])
        show "G9 be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef glib_000_def_34 (" _ ==GLIB-000R5  _ " [50,50]50 ) where
  mlet "G1 be -GraphGLIB-000M2", "G2 be -GraphGLIB-000M2"
"pred G1 ==GLIB-000R5 G2 means
  ((the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2) & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"..

mtheorem GLIB_000R5_reflexivity:
" for G2 be -GraphGLIB-000M2 holds G2 ==GLIB-000R5 G2"
proof-
  have " for G2 be -GraphGLIB-000M2 holds ((the-Vertices-ofGLIB-000K6 G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & the-Source-ofGLIB-000K10 G2 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2) & the-Target-ofGLIB-000K11 G2 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
     sorry
  thus " ?thesis "
    using glib_000_def_34 sorry
qed

mtheorem GLIB_000R5_symmetry:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 implies G2 ==GLIB-000R5 G1"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds ((the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2) & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2 implies ((the-Vertices-ofGLIB-000K6 G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 & the-Edges-ofGLIB-000K7 G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1) & the-Source-ofGLIB-000K10 G2 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G1) & the-Target-ofGLIB-000K11 G2 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G1"
     sorry
  thus " ?thesis "
    using glib_000_def_34 sorry
qed

syntax GLIB_000R6 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ !=GLIB-000R6  _ " [50,50]50)
translations "G1 !=GLIB-000R6 G2" \<rightharpoonup> " not G1 ==GLIB-000R5 G2"

mdef glib_000_def_35 (" _ c=GLIB-000R7  _ " [50,50]50 ) where
  mlet "G1 be -GraphGLIB-000M2", "G2 be -GraphGLIB-000M2"
"pred G1 c=GLIB-000R7 G2 means
  G1 be SubgraphGLIB-000M3-of G2"..

mtheorem GLIB_000R7_reflexivity:
" for G2 be -GraphGLIB-000M2 holds G2 c=GLIB-000R7 G2"
proof-
  have " for G2 be -GraphGLIB-000M2 holds G2 be SubgraphGLIB-000M3-of G2"
    using glib_000_lm_3 sorry
  thus " ?thesis "
    using glib_000_def_35 sorry
qed

mdef glib_000_def_36 (" _ c<GLIB-000R8  _ " [50,50]50 ) where
  mlet "G1 be -GraphGLIB-000M2", "G2 be -GraphGLIB-000M2"
"pred G1 c<GLIB-000R8 G2 means
  G1 c=GLIB-000R7 G2 & G1 !=GLIB-000R6 G2"..

mtheorem GLIB_000R8_irreflexivity:
" for G2 be -GraphGLIB-000M2 holds  not G2 c<GLIB-000R8 G2"
proof-
  have " for G2 be -GraphGLIB-000M2 holds  not (G2 c=GLIB-000R7 G2 & G2 !=GLIB-000R6 G2)"
     sorry
  thus " ?thesis "
    using glib_000_def_36 sorry
qed

mdef glib_000_def_37 ("inducedSubgraphGLIB-000M4-of'( _ , _ , _ ')" [0,0,0]70 ) where
  mlet "G be -GraphGLIB-000M2", "V be setHIDDENM2", "E be setHIDDENM2"
"mode inducedSubgraphGLIB-000M4-of(G,V,E) \<rightarrow> SubgraphGLIB-000M3-of G means
  (\<lambda>it. the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> it =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> it =XBOOLE-0R4 E if V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V otherwise \<lambda>it. it ==GLIB-000R5 G)"
proof-
  (*existence*)
    show "(V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V implies ( ex it be SubgraphGLIB-000M3-of G st the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> it =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> it =XBOOLE-0R4 E)) & ( not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V) implies ( ex it be SubgraphGLIB-000M3-of G st it ==GLIB-000R5 G))"
    proof-
      have "(V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V implies ( ex IT be SubgraphGLIB-000M3-of G st the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 E)) &  not ( not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V) & ( for VarFor1 be SubgraphGLIB-000M3-of G holds  not VarFor1 ==GLIB-000R5 G))"
      proof(rule conjMI)
        show "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V implies ( ex IT be SubgraphGLIB-000M3-of G st the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 E)"
        proof(rule impMI ,rule impI)
          assume A1: "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
            and A2: "E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V"
          obtain E9 where 
            [ty]:"E9 be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G" and E9Def:"E9 = E"
            using A2 xboole_1_th_1 sorry
          let ?S = "(the-Source-ofGLIB-000K10 G) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> E9"
          let ?T = "(the-Target-ofGLIB-000K11 G) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> E9"
          obtain V9 where 
            [ty]:"V9 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G" and V9Def:"V9 = V"
            using A1 sorry
          have "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Target-ofGLIB-000K11 G) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G"
            using funct_2_def_1 sorry
          then have A3: "domRELSET-1K1\<^bsub>(E9)\<^esub> ?T =XBOOLE-0R4 E9"
            using relat_1_th_62 sorry
          have " for e be objectHIDDENM1 holds e inHIDDENR3 E9 implies ((the-Target-ofGLIB-000K11 G) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> E9).FUNCT-1K1 e inTARSKIR2 V"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume A4: "e inHIDDENR3 E9"
            then have "e inHIDDENR3 G .edgesIntoGLIB-000K18 V"
              using A2 xboole_0_def_4 sorry
            then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 V"
              using glib_000_def_26 sorry
            thus "((the-Target-ofGLIB-000K11 G) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> E9).FUNCT-1K1 e inTARSKIR2 V"
              using A4 funct_1_th_49 sorry
          qed "sorry"
          then obtain T where 
            [ty]:"T be FunctionFUNCT-2M1-of(E9,V9)" and TDef:"T = ?T"
            using A3 funct_2_th_3 sorry
          have "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Source-ofGLIB-000K10 G) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G"
            using funct_2_def_1 sorry
          then have A5: "domRELSET-1K1\<^bsub>(E9)\<^esub> ?S =XBOOLE-0R4 E9"
            using relat_1_th_62 sorry
          have " for e be objectHIDDENM1 holds e inHIDDENR3 E9 implies ((the-Source-ofGLIB-000K10 G) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> E9).FUNCT-1K1 e inTARSKIR2 V"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume A6: "e inHIDDENR3 E9"
            then have "e inHIDDENR3 G .edgesOutOfGLIB-000K19 V"
              using A2 xboole_0_def_4 sorry
            then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 V"
              using glib_000_def_27 sorry
            thus "((the-Source-ofGLIB-000K10 G) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> E9).FUNCT-1K1 e inTARSKIR2 V"
              using A6 funct_1_th_49 sorry
          qed "sorry"
          then obtain S where 
            [ty]:"S be FunctionFUNCT-2M1-of(E9,V9)" and SDef:"S = ?S"
            using A5 funct_2_th_3 sorry
          let ?IT = "createGraphGLIB-000K12(V9,E9,S,T)"
          have A7: "the-Edges-ofGLIB-000K7 ?IT =XBOOLE-0R4 E"
            using finseq_4_th_76 sorry
          have "the-Source-ofGLIB-000K10 ?IT =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 (createGraphGLIB-000K12(V9,E9,S,T)),the-Vertices-ofGLIB-000K6 (createGraphGLIB-000K12(V9,E9,S,T)),E9,V9)\<^esub> S & the-Target-ofGLIB-000K11 ?IT =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 (createGraphGLIB-000K12(V9,E9,S,T)),the-Vertices-ofGLIB-000K6 (createGraphGLIB-000K12(V9,E9,S,T)),E9,V9)\<^esub> T"
            using finseq_4_th_76 sorry
          then have "the-Vertices-ofGLIB-000K6 ?IT =XBOOLE-0R4 V & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 ?IT implies (the-Source-ofGLIB-000K10 ?IT).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 ?IT).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e)"
            using A7 finseq_4_th_76 funct_1_th_49 sorry
          then obtain IT where 
            [ty]:"IT be SubgraphGLIB-000M3-of G" and ITDef:"IT = ?IT"
            using A7 glib_000_def_32 sorry
          show " ex IT be SubgraphGLIB-000M3-of G st the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 E"
          proof(rule bexI[of _ "IT"])
            show "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 E"
              using finseq_4_th_76 sorry
          qed "sorry"
        qed
        have "G be SubgraphGLIB-000M3-of G"
          using glib_000_lm_3 sorry
        thus " not ( not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V) & ( for VarFor1 be SubgraphGLIB-000M3-of G holds  not VarFor1 ==GLIB-000R5 G))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be SubgraphGLIB-000M3-of G holds  True "
       sorry
qed "sorry"

syntax GLIB_000M5 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("inducedSubgraphGLIB-000M5-of'( _ , _ ')" [0,0]70)
translations "inducedSubgraphGLIB-000M5-of(G,V)" \<rightharpoonup> "inducedSubgraphGLIB-000M4-of(G,V,G .edgesBetweenGLIB-000K21 V)"

mtheorem glib_000_cl_26:
  mlet "G be -GraphGLIB-000M2", "V be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G", "E be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of G .edgesBetweenGLIB-000K21 V"
"cluster note-that finiteGLIB-000V2 for inducedSubgraphGLIB-000M4-of(G,V,E)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,V,E) holds it be finiteGLIB-000V2"
    using glib_000_def_37 sorry
qed "sorry"

mtheorem glib_000_cl_27:
  mlet "G be -GraphGLIB-000M2", "v be ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G", "E be SubsetSUBSET-1M2-of G .edgesBetweenGLIB-000K21 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
"cluster note-that trivialGLIB-000V4 for inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},E)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},E) holds it be trivialGLIB-000V4"
  proof-
    have " for IT be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},E) holds IT be trivialGLIB-000V4"
    proof(rule ballI)
      fix IT assume [ty]: "IT be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},E)"
      have "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
        using glib_000_def_37 sorry
      then have "cardCARD-1K1 (the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> IT) =XBOOLE-0R4 \<one>\<^sub>M"
        using card_1_th_30 sorry
      thus "IT be trivialGLIB-000V4"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_28:
  mlet "G be -GraphGLIB-000M2", "v be ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G"
"cluster note-that finiteGLIB-000V2\<bar>trivialGLIB-000V4 for inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},{}XBOOLE-0K1)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},{}XBOOLE-0K1) holds it be finiteGLIB-000V2\<bar>trivialGLIB-000V4"
  proof-
    have " for IT be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},{}XBOOLE-0K1) holds IT be finiteGLIB-000V2 & IT be trivialGLIB-000V4"
    proof(rule ballI)
      obtain E where 
        [ty]:"E be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of G .edgesBetweenGLIB-000K21 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}" and EDef:"E = {}XBOOLE-0K1"
        using xboole_1_th_2 sorry
      fix IT assume [ty]: "IT be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},{}XBOOLE-0K1)"
      have "IT be inducedSubgraphGLIB-000M4-of(G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},E)"
         sorry
      thus "IT be finiteGLIB-000V2 & IT be trivialGLIB-000V4"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_29:
  mlet "G be -GraphGLIB-000M2", "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
"cluster note-that simpleGLIB-000V7 for inducedSubgraphGLIB-000M4-of(G,V,{}XBOOLE-0K1)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,V,{}XBOOLE-0K1) holds it be simpleGLIB-000V7"
  proof-
    have " for IT be inducedSubgraphGLIB-000M4-of(G,V,{}XBOOLE-0K1) holds IT be simpleGLIB-000V7"
    proof(rule ballI)
      fix IT assume [ty]: "IT be inducedSubgraphGLIB-000M4-of(G,V,{}XBOOLE-0K1)"
      obtain E where 
        [ty]:"E be SubsetSUBSET-1M2-of G .edgesBetweenGLIB-000K21 V" and EDef:"E = {}XBOOLE-0K1"
        using xboole_1_th_2 sorry
      have "IT be inducedSubgraphGLIB-000M4-of(G,V,E)"
         sorry
      then have "the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> IT =XBOOLE-0R4 {}XBOOLE-0K1"
        using glib_000_def_37 sorry
      thus "IT be simpleGLIB-000V7"
        using glib_000_lm_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma glib_000_lm_5:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for X be setHIDDENM2 holds (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X iff e inTARSKIR2 G .edgesBetweenGLIB-000K21 X"
proof-
  have " for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for X be setHIDDENM2 holds ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X implies e inTARSKIR2 G .edgesBetweenGLIB-000K21 X) & (e inTARSKIR2 G .edgesBetweenGLIB-000K21 X implies (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    show "(e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X implies e inTARSKIR2 G .edgesBetweenGLIB-000K21 X"
    proof(rule impI)
      assume "(e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
      then have "e inTARSKIR2 G .edgesIntoGLIB-000K18 X & e inTARSKIR2 G .edgesOutOfGLIB-000K19 X"
        using glib_000_def_26 glib_000_def_27 sorry
      thus "e inTARSKIR2 G .edgesBetweenGLIB-000K21 X"
        using xboole_0_def_4 sorry
    qed
    assume "e inTARSKIR2 G .edgesBetweenGLIB-000K21 X"
    then have "e inTARSKIR2 G .edgesIntoGLIB-000K18 X & e inTARSKIR2 G .edgesOutOfGLIB-000K19 X"
      using xboole_0_def_4 sorry
    thus "(e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
      using glib_000_def_26 glib_000_def_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma glib_000_lm_6:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
proof(rule ballI)
  fix G assume [ty]: "G be -GraphGLIB-000M2"
  let ?EG = "the-Edges-ofGLIB-000K7 G"
  let ?SG = "the-Source-ofGLIB-000K10 G"
  let ?TG = "the-Target-ofGLIB-000K11 G"
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 the-Edges-ofGLIB-000K7 G implies x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)) & (x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G) implies x inHIDDENR3 the-Edges-ofGLIB-000K7 G)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 the-Edges-ofGLIB-000K7 G implies x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
    proof(rule impI)
      assume A1: "x inHIDDENR3 ?EG"
      then have "?SG .FUNCT-1K1 x inTARSKIR2 the-Vertices-ofGLIB-000K6 G & ?TG .FUNCT-1K1 x inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
        using funct_2_th_5 sorry
      thus "x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
        using A1 glib_000_lm_5 sorry
    qed
    assume "x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
    thus "x inHIDDENR3 the-Edges-ofGLIB-000K7 G"
       sorry
  qed "sorry"
  thus "the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
    using tarski_th_2 sorry
qed "sorry"

mtheorem glib_000_cl_30:
  mlet "G be -GraphGLIB-000M2", "E be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
"cluster note-that spanningGLIB-000V9\<^bsub>(G)\<^esub> for inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,E)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,E) holds it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
  proof-
    have " for G1 be inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,E) holds G1 be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
    proof(rule ballI)
      fix G1 assume [ty]: "G1 be inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,E)"
      have "G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G & the-Vertices-ofGLIB-000K6 G c=TARSKIR1 the-Vertices-ofGLIB-000K6 G"
        using glib_000_lm_6 sorry
      then have "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G"
        using glib_000_def_37 sorry
      thus "G1 be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_31:
  mlet "G be -GraphGLIB-000M2"
"cluster note-that spanningGLIB-000V9\<^bsub>(G)\<^esub> for inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,{}XBOOLE-0K1)"
proof
(*coherence*)
  show " for it be inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,{}XBOOLE-0K1) holds it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
  proof-
    have " for G1 be inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,{}XBOOLE-0K1) holds G1 be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
    proof(rule ballI)
      fix G1 assume [ty]: "G1 be inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,{}XBOOLE-0K1)"
      have "the-Vertices-ofGLIB-000K6 G c=TARSKIR1 the-Vertices-ofGLIB-000K6 G & {}XBOOLE-0K1 c=RELAT-1R2 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
         sorry
      then have "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G"
        using glib_000_def_37 sorry
      thus "G1 be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) GLIB_000M6("removeVertexGLIB-000M6-of'( _ , _ ')" [0,0]70) where
  "removeVertexGLIB-000M6-of(G,v) \<equiv> inducedSubgraphGLIB-000M5-of(G,the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 {TARSKIK1 v})"

abbreviation(input) GLIB_000M7("removeVerticesGLIB-000M7-of'( _ , _ ')" [0,0]70) where
  "removeVerticesGLIB-000M7-of(G,V) \<equiv> inducedSubgraphGLIB-000M5-of(G,the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 V)"

syntax GLIB_000M8 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("removeEdgeGLIB-000M8-of'( _ , _ ')" [0,0]70)
translations "removeEdgeGLIB-000M8-of(G,e)" \<rightharpoonup> "inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 {TARSKIK1 e})"

syntax GLIB_000M9 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("removeEdgesGLIB-000M9-of'( _ , _ ')" [0,0]70)
translations "removeEdgesGLIB-000M9-of(G,E)" \<rightharpoonup> "inducedSubgraphGLIB-000M4-of(G,the-Vertices-ofGLIB-000K6 G,the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 E)"

mtheorem glib_000_cl_32:
  mlet "G be -GraphGLIB-000M2", "e be setHIDDENM2"
"cluster note-that spanningGLIB-000V9\<^bsub>(G)\<^esub> for removeEdgeGLIB-000M8-of(G,e)"
proof
(*coherence*)
  show " for it be removeEdgeGLIB-000M8-of(G,e) holds it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
     sorry
qed "sorry"

mtheorem glib_000_cl_33:
  mlet "G be -GraphGLIB-000M2", "E be setHIDDENM2"
"cluster note-that spanningGLIB-000V9\<^bsub>(G)\<^esub> for removeEdgesGLIB-000M9-of(G,E)"
proof
(*coherence*)
  show " for it be removeEdgesGLIB-000M9-of(G,E) holds it be spanningGLIB-000V9\<^bsub>(G)\<^esub>"
     sorry
qed "sorry"

abbreviation(input) GLIB_000M10("VertexGLIB-000M10-of  _ " [70]70) where
  "VertexGLIB-000M10-of G \<equiv> ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G"

mdef glib_000_def_38 (" _ .edgesIn'(')GLIB-000K26\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesIntoGLIB-000K18 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
proof-
  (*coherence*)
    show "G .edgesIntoGLIB-000K18 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mdef glib_000_def_39 (" _ .edgesOut'(')GLIB-000K27\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesOutOfGLIB-000K19 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
proof-
  (*coherence*)
    show "G .edgesOutOfGLIB-000K19 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mdef glib_000_def_40 (" _ .edgesInOut'(')GLIB-000K28\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G equals
  G .edgesInOutGLIB-000K20 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
proof-
  (*coherence*)
    show "G .edgesInOutGLIB-000K20 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G"
       sorry
qed "sorry"

mlemma glib_000_lm_7:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be setHIDDENM2 holds e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
proof-
  have " for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be setHIDDENM2 holds (e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> implies e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) & (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v implies e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    fix e assume [ty]: "e be setHIDDENM2"
    show "e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> implies e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
    proof(rule impI)
      assume A1: "e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
      then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
        using glib_000_def_26 sorry
      thus "e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
        using A1 tarski_def_1 sorry
    qed
    assume A2: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G"
      and A3: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
    have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
      using A3 tarski_def_1 sorry
    thus "e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
      using A2 glib_000_def_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma glib_000_lm_8:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be setHIDDENM2 holds e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
proof-
  have " for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be setHIDDENM2 holds (e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> implies e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) & (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v implies e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    fix e assume [ty]: "e be setHIDDENM2"
    show "e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> implies e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
    proof(rule impI)
      assume A1: "e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
      then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
        using glib_000_def_27 sorry
      thus "e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
        using A1 tarski_def_1 sorry
    qed
    assume A2: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G"
      and A3: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
    have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
      using A3 tarski_def_1 sorry
    thus "e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
      using A2 glib_000_def_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef glib_000_def_41 (" _ .adjGLIB-000K29\<^bsub>'( _ ')\<^esub>  _ " [260,0,260]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G", "e be objectHIDDENM1"
"func v .adjGLIB-000K29\<^bsub>(G)\<^esub> e \<rightarrow> VertexGLIB-000M10-of G equals
  (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e if e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v,
  (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e if (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v otherwise v"
proof-
  (*coherence*)
    show "(e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v implies (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e be VertexGLIB-000M10-of G) & (((e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v implies (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e be VertexGLIB-000M10-of G) & ( not (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not ((e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) implies v be VertexGLIB-000M10-of G))"
      using funct_2_th_5 sorry
  (*consistency*)
    show " for it be VertexGLIB-000M10-of G holds (e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) & ((e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v) &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) implies (it =HIDDENR1 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e iff it =HIDDENR1 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e)"
       sorry
qed "sorry"

mdef glib_000_def_42 (" _ .inDegree'(')GLIB-000K30\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "cardCARD-1K1 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> be CardinalCARD-1M1"
       sorry
qed "sorry"

mdef glib_000_def_43 (" _ .outDegree'(')GLIB-000K31\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "cardCARD-1K1 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> be CardinalCARD-1M1"
       sorry
qed "sorry"

abbreviation(input) GLIB_000K32(" _ .inDegree'(')GLIB-000K32\<^bsub>'( _ ')\<^esub>" [260,0]260) where
  "v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> \<equiv> v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub>"

mtheorem glib_000_add_7:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"cluster v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> =XBOOLE-0R4 cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
       sorry
    thus "v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

abbreviation(input) GLIB_000K33(" _ .outDegree'(')GLIB-000K33\<^bsub>'( _ ')\<^esub>" [260,0]260) where
  "v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub> \<equiv> v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub>"

mtheorem glib_000_add_8:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"cluster v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> =XBOOLE-0R4 cardCARD-1K4 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
       sorry
    thus "v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

mdef glib_000_def_44 (" _ .degree'(')GLIB-000K34\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .degree()GLIB-000K34\<^bsub>(G)\<^esub> \<rightarrow> CardinalCARD-1M1 equals
  v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> +`CARD-2K1 v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "v .inDegree()GLIB-000K30\<^bsub>(G)\<^esub> +`CARD-2K1 v .outDegree()GLIB-000K31\<^bsub>(G)\<^esub> be CardinalCARD-1M1"
       sorry
qed "sorry"

abbreviation(input) GLIB_000K35(" _ .degree'(')GLIB-000K35\<^bsub>'( _ ')\<^esub>" [260,0]260) where
  "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> \<equiv> v .degree()GLIB-000K34\<^bsub>(G)\<^esub>"

mtheorem glib_000_def_45:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"redefine func v .degree()GLIB-000K35\<^bsub>(G)\<^esub> \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds it =HIDDENR1 v .degree()GLIB-000K35\<^bsub>(G)\<^esub> iff it =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
  proof-
    have "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (VarFor1 =HIDDENR1 v .degree()GLIB-000K34\<^bsub>(G)\<^esub> &  not VarFor1 =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>) &  not (VarFor1 =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub> &  not VarFor1 =HIDDENR1 v .degree()GLIB-000K34\<^bsub>(G)\<^esub>))"
    proof-
      have "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> =HIDDENR1 cardCARD-1K1 (v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +^ORDINAL2K10 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>)"
        using card_2_def_1 sorry
      also have "... = cardCARD-1K4 (v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>)"
        using card_2_th_36 sorry
      also have "... = v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
         sorry
      finally have "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
         sorry
      thus "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (VarFor1 =HIDDENR1 v .degree()GLIB-000K34\<^bsub>(G)\<^esub> &  not VarFor1 =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>) &  not (VarFor1 =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub> &  not VarFor1 =HIDDENR1 v .degree()GLIB-000K34\<^bsub>(G)\<^esub>))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_add_9:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"cluster v .degree()GLIB-000K34\<^bsub>(G)\<^esub> as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (VarFor1 =HIDDENR1 v .degree()GLIB-000K34\<^bsub>(G)\<^esub> &  not VarFor1 =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>) &  not (VarFor1 =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub> &  not VarFor1 =HIDDENR1 v .degree()GLIB-000K34\<^bsub>(G)\<^esub>))"
    proof-
      have "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> =HIDDENR1 cardCARD-1K1 (v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +^ORDINAL2K10 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>)"
        using card_2_def_1 sorry
      also have "... = cardCARD-1K4 (v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>)"
        using card_2_th_36 sorry
      also have "... = v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
         sorry
      finally have "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
         sorry
      thus "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (VarFor1 =HIDDENR1 v .degree()GLIB-000K34\<^bsub>(G)\<^esub> &  not VarFor1 =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>) &  not (VarFor1 =HIDDENR1 v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> +NAT-1K1 v .outDegree()GLIB-000K33\<^bsub>(G)\<^esub> &  not VarFor1 =HIDDENR1 v .degree()GLIB-000K34\<^bsub>(G)\<^esub>))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef glib_000_def_46 (" _ .inNeighbors'(')GLIB-000K36\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G equals
  (the-Source-ofGLIB-000K10 G).:RELSET-1K7\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "(the-Source-ofGLIB-000K10 G).:RELSET-1K7\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
       sorry
qed "sorry"

mdef glib_000_def_47 (" _ .outNeighbors'(')GLIB-000K37\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G equals
  (the-Target-ofGLIB-000K11 G).:RELSET-1K7\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "(the-Target-ofGLIB-000K11 G).:RELSET-1K7\<^bsub>(the-Edges-ofGLIB-000K7 G,the-Vertices-ofGLIB-000K6 G)\<^esub> v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
       sorry
qed "sorry"

mdef glib_000_def_48 (" _ .allNeighbors'(')GLIB-000K38\<^bsub>'( _ ')\<^esub>" [260,0]260 ) where
  mlet "G be -GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"func v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G equals
  v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
proof-
  (*coherence*)
    show "v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G"
       sorry
qed "sorry"

mdef glib_000_def_49 ("isolatedGLIB-000V10\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "G be -GraphGLIB-000M2"
"attr isolatedGLIB-000V10\<^bsub>(G)\<^esub> for VertexGLIB-000M10-of G means
  (\<lambda>v. v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1)"..

abbreviation(input) GLIB_000V11("isolatedGLIB-000V11\<^bsub>'( _ ')\<^esub>" [0]70) where
  "isolatedGLIB-000V11\<^bsub>(G)\<^esub> \<equiv> isolatedGLIB-000V10\<^bsub>(G)\<^esub>"

mtheorem glib_000_def_50:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"redefine attr isolatedGLIB-000V11\<^bsub>(G)\<^esub> for VertexGLIB-000M10-of G means
  (\<lambda>v. v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6)"
proof
(*compatibility*)
  show " for v be VertexGLIB-000M10-of G holds v be isolatedGLIB-000V11\<^bsub>(G)\<^esub> iff v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI)
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "v be isolatedGLIB-000V11\<^bsub>(G)\<^esub> iff v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have "(v be isolatedGLIB-000V10\<^bsub>(G)\<^esub> implies v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6) & (v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6 implies v be isolatedGLIB-000V10\<^bsub>(G)\<^esub>)"
      proof(rule conjMI,rule impI)
        show "v be isolatedGLIB-000V10\<^bsub>(G)\<^esub> implies v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6"
        proof(rule impI)
          assume "v be isolatedGLIB-000V10\<^bsub>(G)\<^esub>"
          then have A1: "v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
             sorry
          then have "v .inDegree()GLIB-000K32\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6"
            using card_1_th_27 xboole_1_th_15 sorry
          thus "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6"
            using A1 card_1_th_27 xboole_1_th_15 sorry
        qed
        assume A2: "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6"
        then have "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
           sorry
        thus "v be isolatedGLIB-000V10\<^bsub>(G)\<^esub>"
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mdef glib_000_def_51 ("endvertexGLIB-000V12\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "G be -GraphGLIB-000M2"
"attr endvertexGLIB-000V12\<^bsub>(G)\<^esub> for VertexGLIB-000M10-of G means
  (\<lambda>v.  ex e be objectHIDDENM1 st v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} &  not e JoinsGLIB-000R1(v,v,G))"..

abbreviation(input) GLIB_000V13("endvertexGLIB-000V13\<^bsub>'( _ ')\<^esub>" [0]70) where
  "endvertexGLIB-000V13\<^bsub>(G)\<^esub> \<equiv> endvertexGLIB-000V12\<^bsub>(G)\<^esub>"

mtheorem glib_000_def_52:
  mlet "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2", "v be VertexGLIB-000M10-of G"
"redefine attr endvertexGLIB-000V13\<^bsub>(G)\<^esub> for VertexGLIB-000M10-of G means
  (\<lambda>v. v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M)"
proof
(*compatibility*)
  show " for v be VertexGLIB-000M10-of G holds v be endvertexGLIB-000V13\<^bsub>(G)\<^esub> iff v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "v be endvertexGLIB-000V13\<^bsub>(G)\<^esub> iff v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
    proof-
      have "(v be endvertexGLIB-000V12\<^bsub>(G)\<^esub> implies v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M) & (v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M implies v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>)"
      proof(rule conjMI,rule impI)
        show "v be endvertexGLIB-000V12\<^bsub>(G)\<^esub> implies v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
        proof(rule impI)
          assume "v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>"
          then obtain e where
            [ty]:"e be objectHIDDENM1" and 
            A1: "v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"and A2: " not e JoinsGLIB-000R1(v,v,G)"
             sorry
          have "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
          proof-
            show "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
            proof-
              have cases: "(v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} or v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1 & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}) or v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
                using A1 zfmisc_1_th_37 sorry
              have case1: "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} implies v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
              proof(rule impI)
                assume A3: "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"
                then have "e inHIDDENR3 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
                  using tarski_def_1 sorry
                then have A4: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
                  using glib_000_lm_8 sorry
                have A5: "e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
                  using A3 tarski_def_1 sorry
                then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
                  using glib_000_lm_7 sorry
                thus "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
                  using A2 A5 A4 sorry
              qed
              have case2: "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1 & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} implies v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
              proof(rule impI)
                assume "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1 & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"
                thus "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
                  using card_1_th_30 sorry
              qed
              have case3: "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1 implies v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
              proof(rule impI)
                assume "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
                thus "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
                  using card_1_th_30 sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed
          thus "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
             sorry
        qed
        assume A6: "v .degree()GLIB-000K35\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
        have "v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>"
        proof-
          show "v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>"
          proof-
            have cases: "cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6 or cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6 implies v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>"
            proof(rule impI)
              assume A7: "cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 0NUMBERSK6"
              then obtain e where
                [ty]:"e be objectHIDDENM1" and 
                A8: "v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"
                using A6 card_2_th_42 sorry
              have A9: "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
                using A7 sorry
              then have A10: " not e JoinsGLIB-000R1(v,v,G)"
                using glib_000_lm_7 sorry
              have "v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"
                using A9 A8 sorry
              thus "v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>"
                using A10 sorry
            qed
            have case2: "cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> <>HIDDENR2 0NUMBERSK6 implies v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>"
            proof(rule impI)
              assume "cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> <>HIDDENR2 0NUMBERSK6"
              then have "0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
                 sorry
              then have A11: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
                using nat_1_th_13 sorry
              have "cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> <=XXREAL-0R1 \<one>\<^sub>M"
                using A6 nat_1_th_11 sorry
              then have A12: "cardCARD-1K4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 \<one>\<^sub>M"
                using A11 xxreal_0_th_1 sorry
              then obtain e where
                [ty]:"e be objectHIDDENM1" and 
                A13: "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"
                using card_2_th_42 sorry
              have A14: "v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
                using A6 A12 sorry
              then have A15: " not e JoinsGLIB-000R1(v,v,G)"
                using glib_000_lm_8 sorry
              have "v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"
                using A13 A14 sorry
              thus "v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>"
                using A15 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "v be endvertexGLIB-000V12\<^bsub>(G)\<^esub>"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mlemma glib_000_lm_9:
" for F be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for n be objectHIDDENM1 holds n be NatNAT-1M1 iff n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
proof-
  have " for F be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  for n be objectHIDDENM1 holds (n be NatNAT-1M1 implies n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F) & (n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies n be NatNAT-1M1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix F assume [ty]: "F be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
    fix n assume [ty]: "n be objectHIDDENM1"
    show "n be NatNAT-1M1 implies n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
    proof(rule impI)
      assume "n be NatNAT-1M1"
      then have "n inHIDDENR3 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      thus "n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
        using partfun1_def_2 sorry
    qed
    assume "n inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
    thus "n be NatNAT-1M1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef glib_000_def_53 ("Graph-yieldingGLIB-000V14" 70 ) where
"attr Graph-yieldingGLIB-000V14 for FunctionFUNCT-1M1 means
  (\<lambda>F.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x be -GraphGLIB-000M2)"..

abbreviation(input) GLIB_000V15("Graph-yieldingGLIB-000V15" 70) where
  "Graph-yieldingGLIB-000V15 \<equiv> Graph-yieldingGLIB-000V14"

mtheorem glib_000_def_54:
  mlet "F be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
"redefine attr Graph-yieldingGLIB-000V15 for ManySortedSetPBOOLEM1-of NATNUMBERSK1 means
  (\<lambda>F.  for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2)"
proof
(*compatibility*)
  show " for F be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds F be Graph-yieldingGLIB-000V15 iff ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2)"
  proof(rule ballI)
    fix F assume [ty]: "F be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
    show "F be Graph-yieldingGLIB-000V15 iff ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2)"
    proof-
      have "(F be Graph-yieldingGLIB-000V14 implies ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2)) & (( for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2) implies F be Graph-yieldingGLIB-000V14)"
      proof(rule conjMI,rule impI)
        show "F be Graph-yieldingGLIB-000V14 implies ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2)"
        proof(rule impI,rule ballI)
          assume A1: "F be Graph-yieldingGLIB-000V14"
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
            using glib_000_lm_9 sorry
          thus "F .FUNCT-1K1 n be -GraphGLIB-000M2"
            using A1 sorry
        qed "sorry"
        assume A2: " for n be NatNAT-1M1 holds F .FUNCT-1K1 n be -GraphGLIB-000M2"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies F .FUNCT-1K1 x be -GraphGLIB-000M2"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
          thus "F .FUNCT-1K1 x be -GraphGLIB-000M2"
            using A2 sorry
        qed "sorry"
        thus "F be Graph-yieldingGLIB-000V14"
          using glib_000_def_53 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mdef glib_000_def_55 ("haltingGLIB-000V16" 70 ) where
"attr haltingGLIB-000V16 for ManySortedSetPBOOLEM1-of NATNUMBERSK1 means
  (\<lambda>F.  ex n be NatNAT-1M1 st F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"..

mdef glib_000_def_56 (" _ .Lifespan'(')GLIB-000K39" [260]260 ) where
  mlet "F be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
"func F .Lifespan()GLIB-000K39 \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. F .FUNCT-1K1 it =XBOOLE-0R4 F .FUNCT-1K1 (it +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies it <=XXREAL-0R1 n) if F be haltingGLIB-000V16 otherwise \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*existence*)
    show "(F be haltingGLIB-000V16 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st F .FUNCT-1K1 it =XBOOLE-0R4 F .FUNCT-1K1 (it +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies it <=XXREAL-0R1 n))) & ( not F be haltingGLIB-000V16 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it =XBOOLE-0R4 0NUMBERSK6))"
    proof-
      have "(F be haltingGLIB-000V16 implies ( ex IT be ElementSUBSET-1M1-of NATNUMBERSK1 st F .FUNCT-1K1 IT =XBOOLE-0R4 F .FUNCT-1K1 (IT +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT <=XXREAL-0R1 n))) &  not ( not F be haltingGLIB-000V16 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
      proof(rule conjMI)
        let ?P = "\<lambda>Lamb1. F .FUNCT-1K1 Lamb1 =XBOOLE-0R4 F .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
        show "F be haltingGLIB-000V16 implies ( ex IT be ElementSUBSET-1M1-of NATNUMBERSK1 st F .FUNCT-1K1 IT =XBOOLE-0R4 F .FUNCT-1K1 (IT +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT <=XXREAL-0R1 n))"
        proof(rule impI)
          assume "F be haltingGLIB-000V16"
          then have A1: " ex n be NatNAT-1M1 st ?P(n)"
             sorry
          have " ex IT be NatNAT-1M1 st ?P(IT) & ( for n be NatNAT-1M1 holds ?P(n) implies IT <=XXREAL-0R1 n)"
            using nat_1_sch_5 A1 sorry
          then obtain IT where
            [ty]:"IT be NatNAT-1M1" and 
            A2: "?P(IT) & ( for n be NatNAT-1M1 holds ?P(n) implies IT <=XXREAL-0R1 n)"
             sorry
          have "IT inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          thus " ex IT be ElementSUBSET-1M1-of NATNUMBERSK1 st F .FUNCT-1K1 IT =XBOOLE-0R4 F .FUNCT-1K1 (IT +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT <=XXREAL-0R1 n)"
            using A2 sorry
        qed
        show " not ( not F be haltingGLIB-000V16 & ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (F be haltingGLIB-000V16 implies ((F .FUNCT-1K1 it1 =XBOOLE-0R4 F .FUNCT-1K1 (it1 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies it1 <=XXREAL-0R1 n)) & (F .FUNCT-1K1 it2 =XBOOLE-0R4 F .FUNCT-1K1 (it2 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies it2 <=XXREAL-0R1 n)) implies it1 =HIDDENR1 it2)) & ( not F be haltingGLIB-000V16 implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
    proof-
      have " for IT1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for IT2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (F be haltingGLIB-000V16 implies (F .FUNCT-1K1 IT1 =XBOOLE-0R4 F .FUNCT-1K1 (IT1 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT1 <=XXREAL-0R1 n) implies (F .FUNCT-1K1 IT2 =XBOOLE-0R4 F .FUNCT-1K1 (IT2 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT2 <=XXREAL-0R1 n) implies IT1 =XBOOLE-0R4 IT2))) &  not ((( not F be haltingGLIB-000V16 & IT1 =XBOOLE-0R4 0NUMBERSK6) & IT2 =XBOOLE-0R4 0NUMBERSK6) &  not IT1 =HIDDENR1 IT2)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix IT1 assume [ty]: "IT1 be ElementSUBSET-1M1-of NATNUMBERSK1"
        fix IT2 assume [ty]: "IT2 be ElementSUBSET-1M1-of NATNUMBERSK1"
        show "F be haltingGLIB-000V16 implies (F .FUNCT-1K1 IT1 =XBOOLE-0R4 F .FUNCT-1K1 (IT1 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT1 <=XXREAL-0R1 n) implies (F .FUNCT-1K1 IT2 =XBOOLE-0R4 F .FUNCT-1K1 (IT2 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT2 <=XXREAL-0R1 n) implies IT1 =XBOOLE-0R4 IT2))"
        proof(rule impI,rule impI,rule impI)
          assume "F be haltingGLIB-000V16"
          assume A3: "F .FUNCT-1K1 IT1 =XBOOLE-0R4 F .FUNCT-1K1 (IT1 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT1 <=XXREAL-0R1 n)"
          assume "F .FUNCT-1K1 IT2 =XBOOLE-0R4 F .FUNCT-1K1 (IT2 +NAT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds F .FUNCT-1K1 n =XBOOLE-0R4 F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies IT2 <=XXREAL-0R1 n)"
          then have "IT1 <=XXREAL-0R1 IT2 & IT2 <=XXREAL-0R1 IT1"
            using A3 sorry
          thus "IT1 =XBOOLE-0R4 IT2"
            using xxreal_0_th_1 sorry
        qed
        show " not ((( not F be haltingGLIB-000V16 & IT1 =XBOOLE-0R4 0NUMBERSK6) & IT2 =XBOOLE-0R4 0NUMBERSK6) &  not IT1 =HIDDENR1 IT2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of NATNUMBERSK1 holds  True "
       sorry
qed "sorry"

mdef glib_000_def_57 (" _ .Result'(')GLIB-000K40" [260]260 ) where
  mlet "F be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
"func F .Result()GLIB-000K40 \<rightarrow> setHIDDENM2 equals
  F .FUNCT-1K1 F .Lifespan()GLIB-000K39"
proof-
  (*coherence*)
    show "F .FUNCT-1K1 F .Lifespan()GLIB-000K39 be setHIDDENM2"
       sorry
qed "sorry"

mtheorem glib_000_cl_34:
  mlet "G be -GraphGLIB-000M2"
"cluster NATNUMBERSK1 -->FUNCOP-1K7 G as-term-is Graph-yieldingGLIB-000V15"
proof
(*coherence*)
  show "NATNUMBERSK1 -->FUNCOP-1K7 G be Graph-yieldingGLIB-000V15"
  proof-
    have "NATNUMBERSK1 -->FUNCOP-1K7 G be Graph-yieldingGLIB-000V14"
    proof-
      let ?F = "NATNUMBERSK1 -->FUNCOP-1K7 G"
      have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?F =XBOOLE-0R4 NATNUMBERSK1"
        using funcop_1_th_13 sorry
      obtain F where 
        [ty]:"F be ManySortedSetPBOOLEM1-of NATNUMBERSK1" and FDef:"F = ?F"
         sorry
      have " for x be NatNAT-1M1 holds (NATNUMBERSK1 -->FUNCOP-1K7 G).FUNCT-1K1 x be -GraphGLIB-000M2"
      proof(rule ballI)
        fix x assume [ty]: "x be NatNAT-1M1"
        have "x inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
          using A1 funct_1_th_3 sorry
        then have "F .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 G}"
          using funcop_1_th_8 sorry
        thus "(NATNUMBERSK1 -->FUNCOP-1K7 G).FUNCT-1K1 x be -GraphGLIB-000M2"
          using tarski_def_1 sorry
      qed "sorry"
      thus "NATNUMBERSK1 -->FUNCOP-1K7 G be Graph-yieldingGLIB-000V14"
        using glib_000_def_54 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_35:
"cluster Graph-yieldingGLIB-000V15 for ManySortedSetPBOOLEM1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ManySortedSetPBOOLEM1-of NATNUMBERSK1 st it be Graph-yieldingGLIB-000V15"
  proof-
    have " ex tVar12 be ManySortedSetPBOOLEM1-of NATNUMBERSK1 st tVar12 be Graph-yieldingGLIB-000V15"
    proof-
      let ?G = "the -GraphGLIB-000M2"
      let ?F = "NATNUMBERSK1 -->FUNCOP-1K7 ?G"
      obtain F where 
        [ty]:"F be ManySortedSetPBOOLEM1-of NATNUMBERSK1" and FDef:"F = ?F"
         sorry
      show " ex tVar12 be ManySortedSetPBOOLEM1-of NATNUMBERSK1 st tVar12 be Graph-yieldingGLIB-000V15"
      proof(rule bexI[of _ "F"])
        show "F be Graph-yieldingGLIB-000V15"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax GLIB_000M11 :: "Ty" ("GraphSeqGLIB-000M11" 70)
translations "GraphSeqGLIB-000M11" \<rightharpoonup> "Graph-yieldingGLIB-000V15\<bar>ManySortedSetPBOOLEM1-of NATNUMBERSK1"

mtheorem glib_000_cl_36:
"cluster note-that  non emptyXBOOLE-0V1 for GraphSeqGLIB-000M11"
proof
(*coherence*)
  show " for it be GraphSeqGLIB-000M11 holds it be  non emptyXBOOLE-0V1"
  proof-
    have " for GSeq be GraphSeqGLIB-000M11 holds  not GSeq be emptyXBOOLE-0V1"
    proof(rule ballI)
      fix GSeq assume [ty]: "GSeq be GraphSeqGLIB-000M11"
      have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSeq =XBOOLE-0R4 NATNUMBERSK1"
        using partfun1_def_2 sorry
      thus " not GSeq be emptyXBOOLE-0V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_37:
"cluster  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14"
  proof-
    have " ex tVar13 be FunctionFUNCT-1M1 st  not tVar13 be emptyXBOOLE-0V1 & tVar13 be Graph-yieldingGLIB-000V14"
    proof-
      show " ex tVar13 be FunctionFUNCT-1M1 st  not tVar13 be emptyXBOOLE-0V1 & tVar13 be Graph-yieldingGLIB-000V14"
      proof(rule bexI[of _ "the GraphSeqGLIB-000M11"])
        show " not the GraphSeqGLIB-000M11 be emptyXBOOLE-0V1 & the GraphSeqGLIB-000M11 be Graph-yieldingGLIB-000V14"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_38:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
    using glib_000_def_53 sorry
qed "sorry"

mtheorem glib_000_cl_39:
  mlet "GSq be GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "GSq .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
    using glib_000_def_54 sorry
qed "sorry"

mtheorem glib_000_cl_40:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
    using glib_000_def_53 sorry
qed "sorry"

mtheorem glib_000_cl_41:
  mlet "GSq be GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
proof
(*coherence*)
  show "GSq .FUNCT-1K1 x be NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
    using glib_000_def_54 sorry
qed "sorry"

mtheorem glib_000_cl_42:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is [Graph-like]GLIB-000V1"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be [Graph-like]GLIB-000V1"
    using glib_000_def_53 sorry
qed "sorry"

mtheorem glib_000_cl_43:
  mlet "GSq be GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is [Graph-like]GLIB-000V1"
proof
(*coherence*)
  show "GSq .FUNCT-1K1 x be [Graph-like]GLIB-000V1"
    using glib_000_def_54 sorry
qed "sorry"

mdef glib_000_def_58 ("finiteGLIB-000V17" 70 ) where
"attr finiteGLIB-000V17 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be finiteGLIB-000V2))"..

mdef glib_000_def_59 ("looplessGLIB-000V18" 70 ) where
"attr looplessGLIB-000V18 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be looplessGLIB-000V3))"..

mdef glib_000_def_60 ("trivialGLIB-000V19" 70 ) where
"attr trivialGLIB-000V19 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be trivialGLIB-000V4))"..

mdef glib_000_def_61 ("non-trivialGLIB-000V20" 70 ) where
"attr non-trivialGLIB-000V20 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be  non trivialGLIB-000V4))"..

mdef glib_000_def_62 ("non-multiGLIB-000V21" 70 ) where
"attr non-multiGLIB-000V21 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be non-multiGLIB-000V5))"..

mdef glib_000_def_63 ("non-DmultiGLIB-000V22" 70 ) where
"attr non-DmultiGLIB-000V22 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be non-DmultiGLIB-000V6))"..

mdef glib_000_def_64 ("simpleGLIB-000V23" 70 ) where
"attr simpleGLIB-000V23 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be simpleGLIB-000V7))"..

mdef glib_000_def_65 ("DsimpleGLIB-000V24" 70 ) where
"attr DsimpleGLIB-000V24 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex G be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 G & G be DsimpleGLIB-000V8))"..

mtheorem glib_000_cl_44:
"cluster emptyXBOOLE-0V1 also-is finiteGLIB-000V17\<bar>looplessGLIB-000V18\<bar>trivialGLIB-000V19\<bar>non-trivialGLIB-000V20\<bar>non-multiGLIB-000V21\<bar>non-DmultiGLIB-000V22\<bar>simpleGLIB-000V23\<bar>DsimpleGLIB-000V24 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be finiteGLIB-000V17\<bar>looplessGLIB-000V18\<bar>trivialGLIB-000V19\<bar>non-trivialGLIB-000V20\<bar>non-multiGLIB-000V21\<bar>non-DmultiGLIB-000V22\<bar>simpleGLIB-000V23\<bar>DsimpleGLIB-000V24"
  proof-
    have " for GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be emptyXBOOLE-0V1 implies ((((((GF be finiteGLIB-000V17 & GF be looplessGLIB-000V18) & GF be trivialGLIB-000V19) & GF be non-trivialGLIB-000V20) & GF be non-multiGLIB-000V21) & GF be non-DmultiGLIB-000V22) & GF be simpleGLIB-000V23) & GF be DsimpleGLIB-000V24"
    proof(rule ballI,rule impI)
      fix GF assume [ty]: "GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
      assume "GF be emptyXBOOLE-0V1"
      thus "((((((GF be finiteGLIB-000V17 & GF be looplessGLIB-000V18) & GF be trivialGLIB-000V19) & GF be non-trivialGLIB-000V20) & GF be non-multiGLIB-000V21) & GF be non-DmultiGLIB-000V22) & GF be simpleGLIB-000V23) & GF be DsimpleGLIB-000V24"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) GLIB_000V25("finiteGLIB-000V25" 70) where
  "finiteGLIB-000V25 \<equiv> finiteGLIB-000V17"

mtheorem glib_000_def_66:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr finiteGLIB-000V25 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be finiteGLIB-000V25 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2)"
  proof(rule ballI)
    fix GF assume [ty]: "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
    show "GF be finiteGLIB-000V25 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2)"
    proof-
      have "(GF be finiteGLIB-000V17 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2)) & (( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2) implies GF be finiteGLIB-000V17)"
      proof(rule conjMI,rule impI)
        show "GF be finiteGLIB-000V17 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2)"
        proof(rule impI,rule ballI)
          assume A1: "GF be finiteGLIB-000V17"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
          obtain G where
            [ty]:"G be -GraphGLIB-000M2" and 
            A2: "GF .FUNCT-1K1 x =FUNCT-1R1 G & G be finiteGLIB-000V2"
            using A1 sorry
          show "GF .FUNCT-1K1 x be finiteGLIB-000V2"
            using A2 sorry
        qed "sorry"
        assume A3: " for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be finiteGLIB-000V2"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex tVar14 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar14 & tVar14 be finiteGLIB-000V2)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 GF"
          then obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of domRELAT-1K1 GF" and yDef:"y = x"
             sorry
          show " ex tVar14 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar14 & tVar14 be finiteGLIB-000V2"
          proof(rule bexI[of _ "GF .FUNCT-1K1 y"])
            show "GF .FUNCT-1K1 x =XBOOLE-0R4 GF .FUNCT-1K1 y & GF .FUNCT-1K1 y be finiteGLIB-000V2"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus "GF be finiteGLIB-000V17"
          using glib_000_def_58 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V26("looplessGLIB-000V26" 70) where
  "looplessGLIB-000V26 \<equiv> looplessGLIB-000V18"

mtheorem glib_000_def_67:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr looplessGLIB-000V26 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be looplessGLIB-000V26 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3)"
  proof(rule ballI)
    fix GF assume [ty]: "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
    show "GF be looplessGLIB-000V26 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3)"
    proof-
      have "(GF be looplessGLIB-000V18 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3)) & (( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3) implies GF be looplessGLIB-000V18)"
      proof(rule conjMI,rule impI)
        show "GF be looplessGLIB-000V18 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3)"
        proof(rule impI,rule ballI)
          assume A1: "GF be looplessGLIB-000V18"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
          obtain G where
            [ty]:"G be -GraphGLIB-000M2" and 
            A2: "GF .FUNCT-1K1 x =FUNCT-1R1 G & G be looplessGLIB-000V3"
            using A1 sorry
          show "GF .FUNCT-1K1 x be looplessGLIB-000V3"
            using A2 sorry
        qed "sorry"
        assume A3: " for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be looplessGLIB-000V3"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex tVar15 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar15 & tVar15 be looplessGLIB-000V3)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 GF"
          then obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of domRELAT-1K1 GF" and yDef:"y = x"
             sorry
          show " ex tVar15 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar15 & tVar15 be looplessGLIB-000V3"
          proof(rule bexI[of _ "GF .FUNCT-1K1 y"])
            show "GF .FUNCT-1K1 x =XBOOLE-0R4 GF .FUNCT-1K1 y & GF .FUNCT-1K1 y be looplessGLIB-000V3"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus "GF be looplessGLIB-000V18"
          using glib_000_def_59 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V27("trivialGLIB-000V27" 70) where
  "trivialGLIB-000V27 \<equiv> trivialGLIB-000V19"

mtheorem glib_000_def_68:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr trivialGLIB-000V27 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be trivialGLIB-000V27 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4)"
  proof(rule ballI)
    fix GF assume [ty]: "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
    show "GF be trivialGLIB-000V27 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4)"
    proof-
      have "(GF be trivialGLIB-000V19 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4)) & (( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4) implies GF be trivialGLIB-000V19)"
      proof(rule conjMI,rule impI)
        show "GF be trivialGLIB-000V19 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4)"
        proof(rule impI,rule ballI)
          assume A1: "GF be trivialGLIB-000V19"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
          obtain G where
            [ty]:"G be -GraphGLIB-000M2" and 
            A2: "GF .FUNCT-1K1 x =FUNCT-1R1 G & G be trivialGLIB-000V4"
            using A1 sorry
          show "GF .FUNCT-1K1 x be trivialGLIB-000V4"
            using A2 sorry
        qed "sorry"
        assume A3: " for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be trivialGLIB-000V4"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex tVar16 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar16 & tVar16 be trivialGLIB-000V4)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 GF"
          then obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of domRELAT-1K1 GF" and yDef:"y = x"
             sorry
          show " ex tVar16 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar16 & tVar16 be trivialGLIB-000V4"
          proof(rule bexI[of _ "GF .FUNCT-1K1 y"])
            show "GF .FUNCT-1K1 x =XBOOLE-0R4 GF .FUNCT-1K1 y & GF .FUNCT-1K1 y be trivialGLIB-000V4"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus "GF be trivialGLIB-000V19"
          using glib_000_def_60 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V28("non-trivialGLIB-000V28" 70) where
  "non-trivialGLIB-000V28 \<equiv> non-trivialGLIB-000V20"

mtheorem glib_000_def_69:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr non-trivialGLIB-000V28 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be non-trivialGLIB-000V28 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4)"
  proof(rule ballI)
    fix GF assume [ty]: "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
    show "GF be non-trivialGLIB-000V28 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4)"
    proof-
      have "(GF be non-trivialGLIB-000V20 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4)) & (( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4) implies GF be non-trivialGLIB-000V20)"
      proof(rule conjMI,rule impI)
        show "GF be non-trivialGLIB-000V20 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4)"
        proof(rule impI,rule ballI)
          assume A1: "GF be non-trivialGLIB-000V20"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
          obtain G where
            [ty]:"G be -GraphGLIB-000M2" and 
            A2: "GF .FUNCT-1K1 x =FUNCT-1R1 G & G be  non trivialGLIB-000V4"
            using A1 sorry
          show "GF .FUNCT-1K1 x be  non trivialGLIB-000V4"
            using A2 sorry
        qed "sorry"
        assume A3: " for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be  non trivialGLIB-000V4"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex tVar17 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar17 &  not tVar17 be trivialGLIB-000V4)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 GF"
          then obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of domRELAT-1K1 GF" and yDef:"y = x"
             sorry
          show " ex tVar17 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar17 &  not tVar17 be trivialGLIB-000V4"
          proof(rule bexI[of _ "GF .FUNCT-1K1 y"])
            show "GF .FUNCT-1K1 x =XBOOLE-0R4 GF .FUNCT-1K1 y &  not GF .FUNCT-1K1 y be trivialGLIB-000V4"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus "GF be non-trivialGLIB-000V20"
          using glib_000_def_61 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V29("non-multiGLIB-000V29" 70) where
  "non-multiGLIB-000V29 \<equiv> non-multiGLIB-000V21"

mtheorem glib_000_def_70:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr non-multiGLIB-000V29 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be non-multiGLIB-000V29 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5)"
  proof(rule ballI)
    fix GF assume [ty]: "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
    show "GF be non-multiGLIB-000V29 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5)"
    proof-
      have "(GF be non-multiGLIB-000V21 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5)) & (( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5) implies GF be non-multiGLIB-000V21)"
      proof(rule conjMI,rule impI)
        show "GF be non-multiGLIB-000V21 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5)"
        proof(rule impI,rule ballI)
          assume A1: "GF be non-multiGLIB-000V21"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
          obtain G where
            [ty]:"G be -GraphGLIB-000M2" and 
            A2: "GF .FUNCT-1K1 x =FUNCT-1R1 G & G be non-multiGLIB-000V5"
            using A1 sorry
          show "GF .FUNCT-1K1 x be non-multiGLIB-000V5"
            using A2 sorry
        qed "sorry"
        assume A3: " for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-multiGLIB-000V5"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex tVar18 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar18 & tVar18 be non-multiGLIB-000V5)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 GF"
          then obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of domRELAT-1K1 GF" and yDef:"y = x"
             sorry
          show " ex tVar18 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar18 & tVar18 be non-multiGLIB-000V5"
          proof(rule bexI[of _ "GF .FUNCT-1K1 y"])
            show "GF .FUNCT-1K1 x =XBOOLE-0R4 GF .FUNCT-1K1 y & GF .FUNCT-1K1 y be non-multiGLIB-000V5"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus "GF be non-multiGLIB-000V21"
          using glib_000_def_62 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V30("non-DmultiGLIB-000V30" 70) where
  "non-DmultiGLIB-000V30 \<equiv> non-DmultiGLIB-000V22"

mtheorem glib_000_def_71:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr non-DmultiGLIB-000V30 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be non-DmultiGLIB-000V30 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
  proof(rule ballI)
    fix GF assume [ty]: "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
    show "GF be non-DmultiGLIB-000V30 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
    proof-
      have "(GF be non-DmultiGLIB-000V22 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6)) & (( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6) implies GF be non-DmultiGLIB-000V22)"
      proof(rule conjMI,rule impI)
        show "GF be non-DmultiGLIB-000V22 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
        proof(rule impI,rule ballI)
          assume A1: "GF be non-DmultiGLIB-000V22"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
          obtain G where
            [ty]:"G be -GraphGLIB-000M2" and 
            A2: "GF .FUNCT-1K1 x =FUNCT-1R1 G & G be non-DmultiGLIB-000V6"
            using A1 sorry
          show "GF .FUNCT-1K1 x be non-DmultiGLIB-000V6"
            using A2 sorry
        qed "sorry"
        assume A3: " for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be non-DmultiGLIB-000V6"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex tVar19 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar19 & tVar19 be non-DmultiGLIB-000V6)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 GF"
          then obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of domRELAT-1K1 GF" and yDef:"y = x"
             sorry
          show " ex tVar19 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar19 & tVar19 be non-DmultiGLIB-000V6"
          proof(rule bexI[of _ "GF .FUNCT-1K1 y"])
            show "GF .FUNCT-1K1 x =XBOOLE-0R4 GF .FUNCT-1K1 y & GF .FUNCT-1K1 y be non-DmultiGLIB-000V6"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus "GF be non-DmultiGLIB-000V22"
          using glib_000_def_63 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V31("simpleGLIB-000V31" 70) where
  "simpleGLIB-000V31 \<equiv> simpleGLIB-000V23"

mtheorem glib_000_def_72:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr simpleGLIB-000V31 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be simpleGLIB-000V31 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7)"
  proof(rule ballI)
    fix GF assume [ty]: "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
    show "GF be simpleGLIB-000V31 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7)"
    proof-
      have "(GF be simpleGLIB-000V23 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7)) & (( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7) implies GF be simpleGLIB-000V23)"
      proof(rule conjMI,rule impI)
        show "GF be simpleGLIB-000V23 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7)"
        proof(rule impI,rule ballI)
          assume A1: "GF be simpleGLIB-000V23"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
          obtain G where
            [ty]:"G be -GraphGLIB-000M2" and 
            A2: "GF .FUNCT-1K1 x =FUNCT-1R1 G & G be simpleGLIB-000V7"
            using A1 sorry
          show "GF .FUNCT-1K1 x be simpleGLIB-000V7"
            using A2 sorry
        qed "sorry"
        assume A3: " for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be simpleGLIB-000V7"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex tVar20 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar20 & tVar20 be simpleGLIB-000V7)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 GF"
          then obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of domRELAT-1K1 GF" and yDef:"y = x"
             sorry
          show " ex tVar20 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar20 & tVar20 be simpleGLIB-000V7"
          proof(rule bexI[of _ "GF .FUNCT-1K1 y"])
            show "GF .FUNCT-1K1 x =XBOOLE-0R4 GF .FUNCT-1K1 y & GF .FUNCT-1K1 y be simpleGLIB-000V7"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus "GF be simpleGLIB-000V23"
          using glib_000_def_64 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V32("DsimpleGLIB-000V32" 70) where
  "DsimpleGLIB-000V32 \<equiv> DsimpleGLIB-000V24"

mtheorem glib_000_def_73:
  mlet "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
"redefine attr DsimpleGLIB-000V32 for  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 means
  (\<lambda>GF.  for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8)"
proof
(*compatibility*)
  show " for GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds GF be DsimpleGLIB-000V32 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8)"
  proof(rule ballI)
    fix GF assume [ty]: "GF be  non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
    show "GF be DsimpleGLIB-000V32 iff ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8)"
    proof-
      have "(GF be DsimpleGLIB-000V24 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8)) & (( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8) implies GF be DsimpleGLIB-000V24)"
      proof(rule conjMI,rule impI)
        show "GF be DsimpleGLIB-000V24 implies ( for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8)"
        proof(rule impI,rule ballI)
          assume A1: "GF be DsimpleGLIB-000V24"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
          obtain G where
            [ty]:"G be -GraphGLIB-000M2" and 
            A2: "GF .FUNCT-1K1 x =FUNCT-1R1 G & G be DsimpleGLIB-000V8"
            using A1 sorry
          show "GF .FUNCT-1K1 x be DsimpleGLIB-000V8"
            using A2 sorry
        qed "sorry"
        assume A3: " for x be ElementSUBSET-1M1-of domRELAT-1K1 GF holds GF .FUNCT-1K1 x be DsimpleGLIB-000V8"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 GF implies ( ex tVar21 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar21 & tVar21 be DsimpleGLIB-000V8)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 GF"
          then obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of domRELAT-1K1 GF" and yDef:"y = x"
             sorry
          show " ex tVar21 be -GraphGLIB-000M2 st GF .FUNCT-1K1 x =XBOOLE-0R4 tVar21 & tVar21 be DsimpleGLIB-000V8"
          proof(rule bexI[of _ "GF .FUNCT-1K1 y"])
            show "GF .FUNCT-1K1 x =XBOOLE-0R4 GF .FUNCT-1K1 y & GF .FUNCT-1K1 y be DsimpleGLIB-000V8"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus "GF be DsimpleGLIB-000V24"
          using glib_000_def_65 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V33("finiteGLIB-000V33" 70) where
  "finiteGLIB-000V33 \<equiv> finiteGLIB-000V17"

mtheorem glib_000_def_74:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr finiteGLIB-000V33 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be finiteGLIB-000V33 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2)"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be finiteGLIB-000V33 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2)"
    proof-
      have "(GSq be finiteGLIB-000V25 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2)) & (( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2) implies GSq be finiteGLIB-000V17)"
      proof(rule conjMI,rule impI)
        show "GSq be finiteGLIB-000V25 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2)"
        proof(rule impI,rule ballI)
          assume A1: "GSq be finiteGLIB-000V25"
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
            using glib_000_lm_9 sorry
          thus "GSq .FUNCT-1K1 x be finiteGLIB-000V2"
            using A1 sorry
        qed "sorry"
        assume A2: " for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be finiteGLIB-000V2"
        have " for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq holds GSq .FUNCT-1K1 x be finiteGLIB-000V2"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
          show "GSq .FUNCT-1K1 x be finiteGLIB-000V2"
            using A2 sorry
        qed "sorry"
        thus "GSq be finiteGLIB-000V17"
          using glib_000_def_66 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V34("looplessGLIB-000V34" 70) where
  "looplessGLIB-000V34 \<equiv> looplessGLIB-000V18"

mtheorem glib_000_def_75:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr looplessGLIB-000V34 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be looplessGLIB-000V34 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3)"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be looplessGLIB-000V34 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3)"
    proof-
      have "(GSq be looplessGLIB-000V26 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3)) & (( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3) implies GSq be looplessGLIB-000V18)"
      proof(rule conjMI,rule impI)
        show "GSq be looplessGLIB-000V26 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3)"
        proof(rule impI,rule ballI)
          assume A1: "GSq be looplessGLIB-000V26"
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
            using glib_000_lm_9 sorry
          thus "GSq .FUNCT-1K1 x be looplessGLIB-000V3"
            using A1 sorry
        qed "sorry"
        assume A2: " for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be looplessGLIB-000V3"
        have " for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq holds GSq .FUNCT-1K1 x be looplessGLIB-000V3"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
          show "GSq .FUNCT-1K1 x be looplessGLIB-000V3"
            using A2 sorry
        qed "sorry"
        thus "GSq be looplessGLIB-000V18"
          using glib_000_def_67 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V35("trivialGLIB-000V35" 70) where
  "trivialGLIB-000V35 \<equiv> trivialGLIB-000V19"

mtheorem glib_000_def_76:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr trivialGLIB-000V35 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be trivialGLIB-000V35 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4)"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be trivialGLIB-000V35 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4)"
    proof-
      have "(GSq be trivialGLIB-000V27 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4)) & (( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4) implies GSq be trivialGLIB-000V19)"
      proof(rule conjMI,rule impI)
        show "GSq be trivialGLIB-000V27 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4)"
        proof(rule impI,rule ballI)
          assume A1: "GSq be trivialGLIB-000V27"
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
            using glib_000_lm_9 sorry
          thus "GSq .FUNCT-1K1 x be trivialGLIB-000V4"
            using A1 sorry
        qed "sorry"
        assume A2: " for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be trivialGLIB-000V4"
        have " for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq holds GSq .FUNCT-1K1 x be trivialGLIB-000V4"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
          show "GSq .FUNCT-1K1 x be trivialGLIB-000V4"
            using A2 sorry
        qed "sorry"
        thus "GSq be trivialGLIB-000V19"
          using glib_000_def_68 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V36("non-trivialGLIB-000V36" 70) where
  "non-trivialGLIB-000V36 \<equiv> non-trivialGLIB-000V20"

mtheorem glib_000_def_77:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr non-trivialGLIB-000V36 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be non-trivialGLIB-000V36 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4)"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be non-trivialGLIB-000V36 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4)"
    proof-
      have "(GSq be non-trivialGLIB-000V28 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4)) & (( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4) implies GSq be non-trivialGLIB-000V20)"
      proof(rule conjMI,rule impI)
        show "GSq be non-trivialGLIB-000V28 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4)"
        proof(rule impI,rule ballI)
          assume A1: "GSq be non-trivialGLIB-000V28"
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
            using glib_000_lm_9 sorry
          thus "GSq .FUNCT-1K1 x be  non trivialGLIB-000V4"
            using A1 sorry
        qed "sorry"
        assume A2: " for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be  non trivialGLIB-000V4"
        have " for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq holds  not GSq .FUNCT-1K1 x be trivialGLIB-000V4"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
          show " not GSq .FUNCT-1K1 x be trivialGLIB-000V4"
            using A2 sorry
        qed "sorry"
        thus "GSq be non-trivialGLIB-000V20"
          using glib_000_def_69 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V37("non-multiGLIB-000V37" 70) where
  "non-multiGLIB-000V37 \<equiv> non-multiGLIB-000V21"

mtheorem glib_000_def_78:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr non-multiGLIB-000V37 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be non-multiGLIB-000V37 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5)"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be non-multiGLIB-000V37 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5)"
    proof-
      have "(GSq be non-multiGLIB-000V29 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5)) & (( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5) implies GSq be non-multiGLIB-000V21)"
      proof(rule conjMI,rule impI)
        show "GSq be non-multiGLIB-000V29 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5)"
        proof(rule impI,rule ballI)
          assume A1: "GSq be non-multiGLIB-000V29"
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
            using glib_000_lm_9 sorry
          thus "GSq .FUNCT-1K1 x be non-multiGLIB-000V5"
            using A1 sorry
        qed "sorry"
        assume A2: " for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5"
        have " for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq holds GSq .FUNCT-1K1 x be non-multiGLIB-000V5"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
          show "GSq .FUNCT-1K1 x be non-multiGLIB-000V5"
            using A2 sorry
        qed "sorry"
        thus "GSq be non-multiGLIB-000V21"
          using glib_000_def_70 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V38("non-DmultiGLIB-000V38" 70) where
  "non-DmultiGLIB-000V38 \<equiv> non-DmultiGLIB-000V22"

mtheorem glib_000_def_79:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr non-DmultiGLIB-000V38 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be non-DmultiGLIB-000V38 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be non-DmultiGLIB-000V38 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
    proof-
      have "(GSq be non-DmultiGLIB-000V30 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6)) & (( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6) implies GSq be non-DmultiGLIB-000V22)"
      proof(rule conjMI,rule impI)
        show "GSq be non-DmultiGLIB-000V30 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6)"
        proof(rule impI,rule ballI)
          assume A1: "GSq be non-DmultiGLIB-000V30"
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
            using glib_000_lm_9 sorry
          thus "GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6"
            using A1 sorry
        qed "sorry"
        assume A2: " for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6"
        have " for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq holds GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
          show "GSq .FUNCT-1K1 x be non-DmultiGLIB-000V6"
            using A2 sorry
        qed "sorry"
        thus "GSq be non-DmultiGLIB-000V22"
          using glib_000_def_71 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V39("simpleGLIB-000V39" 70) where
  "simpleGLIB-000V39 \<equiv> simpleGLIB-000V23"

mtheorem glib_000_def_80:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr simpleGLIB-000V39 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be simpleGLIB-000V39 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7)"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be simpleGLIB-000V39 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7)"
    proof-
      have "(GSq be simpleGLIB-000V31 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7)) & (( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7) implies GSq be simpleGLIB-000V23)"
      proof(rule conjMI,rule impI)
        show "GSq be simpleGLIB-000V31 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7)"
        proof(rule impI,rule ballI)
          assume A1: "GSq be simpleGLIB-000V31"
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
            using glib_000_lm_9 sorry
          thus "GSq .FUNCT-1K1 x be simpleGLIB-000V7"
            using A1 sorry
        qed "sorry"
        assume A2: " for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be simpleGLIB-000V7"
        have " for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq holds GSq .FUNCT-1K1 x be simpleGLIB-000V7"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
          show "GSq .FUNCT-1K1 x be simpleGLIB-000V7"
            using A2 sorry
        qed "sorry"
        thus "GSq be simpleGLIB-000V23"
          using glib_000_def_72 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V40("DsimpleGLIB-000V40" 70) where
  "DsimpleGLIB-000V40 \<equiv> DsimpleGLIB-000V24"

mtheorem glib_000_def_81:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr DsimpleGLIB-000V40 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8)"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be DsimpleGLIB-000V40 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8)"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be DsimpleGLIB-000V40 iff ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8)"
    proof-
      have "(GSq be DsimpleGLIB-000V32 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8)) & (( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8) implies GSq be DsimpleGLIB-000V24)"
      proof(rule conjMI,rule impI)
        show "GSq be DsimpleGLIB-000V32 implies ( for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8)"
        proof(rule impI,rule ballI)
          assume A1: "GSq be DsimpleGLIB-000V32"
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
            using glib_000_lm_9 sorry
          thus "GSq .FUNCT-1K1 x be DsimpleGLIB-000V8"
            using A1 sorry
        qed "sorry"
        assume A2: " for x be NatNAT-1M1 holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8"
        have " for x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq holds GSq .FUNCT-1K1 x be DsimpleGLIB-000V8"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GSq"
          show "GSq .FUNCT-1K1 x be DsimpleGLIB-000V8"
            using A2 sorry
        qed "sorry"
        thus "GSq be DsimpleGLIB-000V24"
          using glib_000_def_73 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) GLIB_000V41("haltingGLIB-000V41" 70) where
  "haltingGLIB-000V41 \<equiv> haltingGLIB-000V16"

mtheorem glib_000_def_82:
  mlet "GSq be GraphSeqGLIB-000M11"
"redefine attr haltingGLIB-000V41 for GraphSeqGLIB-000M11 means
  (\<lambda>GSq.  ex n be NatNAT-1M1 st GSq .FUNCT-1K1 n =FUNCT-1R1 GSq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for GSq be GraphSeqGLIB-000M11 holds GSq be haltingGLIB-000V41 iff ( ex n be NatNAT-1M1 st GSq .FUNCT-1K1 n =FUNCT-1R1 GSq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix GSq assume [ty]: "GSq be GraphSeqGLIB-000M11"
    show "GSq be haltingGLIB-000V41 iff ( ex n be NatNAT-1M1 st GSq .FUNCT-1K1 n =FUNCT-1R1 GSq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
qed "sorry"

mtheorem glib_000_cl_45:
"cluster haltingGLIB-000V41\<bar>finiteGLIB-000V33\<bar>looplessGLIB-000V34\<bar>trivialGLIB-000V35\<bar>non-multiGLIB-000V37\<bar>non-DmultiGLIB-000V38\<bar>simpleGLIB-000V39\<bar>DsimpleGLIB-000V40 for GraphSeqGLIB-000M11"
proof
(*existence*)
  show " ex it be GraphSeqGLIB-000M11 st it be haltingGLIB-000V41\<bar>finiteGLIB-000V33\<bar>looplessGLIB-000V34\<bar>trivialGLIB-000V35\<bar>non-multiGLIB-000V37\<bar>non-DmultiGLIB-000V38\<bar>simpleGLIB-000V39\<bar>DsimpleGLIB-000V40"
  proof-
    have " ex tVar22 be GraphSeqGLIB-000M11 st tVar22 be haltingGLIB-000V41 & ((((((tVar22 be finiteGLIB-000V33 & tVar22 be looplessGLIB-000V34) & tVar22 be trivialGLIB-000V35) & tVar22 be non-multiGLIB-000V37) & tVar22 be non-DmultiGLIB-000V38) & tVar22 be simpleGLIB-000V39) & tVar22 be DsimpleGLIB-000V40)"
    proof-
      let ?G = "the finiteFINSET-1V1\<bar>looplessGLIB-000V3\<bar>trivialGLIB-000V4\<bar>non-multiGLIB-000V5\<bar>non-DmultiGLIB-000V6\<bar>simpleGLIB-000V7\<bar>DsimpleGLIB-000V8\<bar>-GraphGLIB-000M2"
      let ?F = "NATNUMBERSK1 -->FUNCOP-1K7 ?G"
      have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?F =XBOOLE-0R4 NATNUMBERSK1"
        using funcop_1_th_13 sorry
      obtain F where 
        [ty]:"F be ManySortedSetPBOOLEM1-of NATNUMBERSK1" and FDef:"F = ?F"
         sorry
      have 
        [ty]:"F be GraphSeqGLIB-000M11"
         sorry
      have "F .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 F"
        using A1 funct_1_th_3 sorry
      then have "F .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {TARSKIK1 ?G}"
        using funcop_1_th_8 sorry
      then have A2: "F .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 ?G"
        using tarski_def_1 sorry
      show " ex tVar22 be GraphSeqGLIB-000M11 st tVar22 be haltingGLIB-000V41 & ((((((tVar22 be finiteGLIB-000V33 & tVar22 be looplessGLIB-000V34) & tVar22 be trivialGLIB-000V35) & tVar22 be non-multiGLIB-000V37) & tVar22 be non-DmultiGLIB-000V38) & tVar22 be simpleGLIB-000V39) & tVar22 be DsimpleGLIB-000V40)"
      proof(rule bexI[of _ "F"],rule conjMI)
        have "F .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 F"
          using A1 funct_1_th_3 sorry
        then have "F .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 {TARSKIK1 ?G}"
          using funcop_1_th_8 sorry
        then have "F .FUNCT-1K1 \<one>\<^sub>M =FUNCT-1R1 ?G"
          using tarski_def_1 sorry
        thus "F be haltingGLIB-000V41"
          using A2 sorry
        have " for x be NatNAT-1M1 holds (((((F .FUNCT-1K1 x be finiteGLIB-000V2 & F .FUNCT-1K1 x be looplessGLIB-000V3) & F .FUNCT-1K1 x be trivialGLIB-000V4) & F .FUNCT-1K1 x be non-multiGLIB-000V5) & F .FUNCT-1K1 x be non-DmultiGLIB-000V6) & F .FUNCT-1K1 x be simpleGLIB-000V7) & F .FUNCT-1K1 x be DsimpleGLIB-000V8"
        proof(rule ballI)
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
            using A1 funct_1_th_3 sorry
          then have "F .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 ?G}"
            using funcop_1_th_8 sorry
          thus "(((((F .FUNCT-1K1 x be finiteGLIB-000V2 & F .FUNCT-1K1 x be looplessGLIB-000V3) & F .FUNCT-1K1 x be trivialGLIB-000V4) & F .FUNCT-1K1 x be non-multiGLIB-000V5) & F .FUNCT-1K1 x be non-DmultiGLIB-000V6) & F .FUNCT-1K1 x be simpleGLIB-000V7) & F .FUNCT-1K1 x be DsimpleGLIB-000V8"
            using tarski_def_1 sorry
        qed "sorry"
        thus "(((((F be finiteGLIB-000V33 & F be looplessGLIB-000V34) & F be trivialGLIB-000V35) & F be non-multiGLIB-000V37) & F be non-DmultiGLIB-000V38) & F be simpleGLIB-000V39) & F be DsimpleGLIB-000V40"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_46:
"cluster haltingGLIB-000V41\<bar>finiteGLIB-000V33\<bar>looplessGLIB-000V34\<bar>non-trivialGLIB-000V36\<bar>non-multiGLIB-000V37\<bar>non-DmultiGLIB-000V38\<bar>simpleGLIB-000V39\<bar>DsimpleGLIB-000V40 for GraphSeqGLIB-000M11"
proof
(*existence*)
  show " ex it be GraphSeqGLIB-000M11 st it be haltingGLIB-000V41\<bar>finiteGLIB-000V33\<bar>looplessGLIB-000V34\<bar>non-trivialGLIB-000V36\<bar>non-multiGLIB-000V37\<bar>non-DmultiGLIB-000V38\<bar>simpleGLIB-000V39\<bar>DsimpleGLIB-000V40"
  proof-
    have " ex tVar23 be GraphSeqGLIB-000M11 st tVar23 be haltingGLIB-000V41 & ((((((tVar23 be finiteGLIB-000V33 & tVar23 be looplessGLIB-000V34) & tVar23 be non-trivialGLIB-000V36) & tVar23 be non-multiGLIB-000V37) & tVar23 be non-DmultiGLIB-000V38) & tVar23 be simpleGLIB-000V39) & tVar23 be DsimpleGLIB-000V40)"
    proof-
      let ?G = "the finiteFINSET-1V1\<bar>looplessGLIB-000V3\<bar> non trivialGLIB-000V4\<bar>non-multiGLIB-000V5\<bar>non-DmultiGLIB-000V6\<bar>simpleGLIB-000V7\<bar>DsimpleGLIB-000V8\<bar>-GraphGLIB-000M2"
      let ?F = "NATNUMBERSK1 -->FUNCOP-1K7 ?G"
      have A3: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?F =XBOOLE-0R4 NATNUMBERSK1"
        using funcop_1_th_13 sorry
      obtain F where 
        [ty]:"F be ManySortedSetPBOOLEM1-of NATNUMBERSK1" and FDef:"F = ?F"
         sorry
      have 
        [ty]:"F be GraphSeqGLIB-000M11"
         sorry
      have "F .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 F"
        using A3 funct_1_th_3 sorry
      then have "F .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {TARSKIK1 ?G}"
        using funcop_1_th_8 sorry
      then have A4: "F .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 ?G"
        using tarski_def_1 sorry
      show " ex tVar23 be GraphSeqGLIB-000M11 st tVar23 be haltingGLIB-000V41 & ((((((tVar23 be finiteGLIB-000V33 & tVar23 be looplessGLIB-000V34) & tVar23 be non-trivialGLIB-000V36) & tVar23 be non-multiGLIB-000V37) & tVar23 be non-DmultiGLIB-000V38) & tVar23 be simpleGLIB-000V39) & tVar23 be DsimpleGLIB-000V40)"
      proof(rule bexI[of _ "F"],rule conjMI)
        have "F .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 F"
          using A3 funct_1_th_3 sorry
        then have "F .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 {TARSKIK1 ?G}"
          using funcop_1_th_8 sorry
        then have "F .FUNCT-1K1 \<one>\<^sub>M =FUNCT-1R1 ?G"
          using tarski_def_1 sorry
        thus "F be haltingGLIB-000V41"
          using A4 sorry
        have " for x be NatNAT-1M1 holds (((((F .FUNCT-1K1 x be finiteGLIB-000V2 & F .FUNCT-1K1 x be looplessGLIB-000V3) & F .FUNCT-1K1 x be  non trivialGLIB-000V4) & F .FUNCT-1K1 x be non-multiGLIB-000V5) & F .FUNCT-1K1 x be non-DmultiGLIB-000V6) & F .FUNCT-1K1 x be simpleGLIB-000V7) & F .FUNCT-1K1 x be DsimpleGLIB-000V8"
        proof(rule ballI)
          fix x assume [ty]: "x be NatNAT-1M1"
          have "x inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
            using A3 funct_1_th_3 sorry
          then have "F .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 ?G}"
            using funcop_1_th_8 sorry
          thus "(((((F .FUNCT-1K1 x be finiteGLIB-000V2 & F .FUNCT-1K1 x be looplessGLIB-000V3) & F .FUNCT-1K1 x be  non trivialGLIB-000V4) & F .FUNCT-1K1 x be non-multiGLIB-000V5) & F .FUNCT-1K1 x be non-DmultiGLIB-000V6) & F .FUNCT-1K1 x be simpleGLIB-000V7) & F .FUNCT-1K1 x be DsimpleGLIB-000V8"
            using tarski_def_1 sorry
        qed "sorry"
        thus "(((((F be finiteGLIB-000V33 & F be looplessGLIB-000V34) & F be non-trivialGLIB-000V36) & F be non-multiGLIB-000V37) & F be non-DmultiGLIB-000V38) & F be simpleGLIB-000V39) & F be DsimpleGLIB-000V40"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_47:
  mlet "GF be finiteGLIB-000V25\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is finiteGLIB-000V2"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be finiteGLIB-000V2"
    using glib_000_def_66 sorry
qed "sorry"

mtheorem glib_000_cl_48:
  mlet "GSq be finiteGLIB-000V33\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is finiteGLIB-000V2"
proof
(*coherence*)
  show "GSq .FUNCT-1K1 x be finiteGLIB-000V2"
    using glib_000_def_74 sorry
qed "sorry"

mtheorem glib_000_cl_49:
  mlet "GF be looplessGLIB-000V26\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is looplessGLIB-000V3"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be looplessGLIB-000V3"
    using glib_000_def_67 sorry
qed "sorry"

mtheorem glib_000_cl_50:
  mlet "GSq be looplessGLIB-000V34\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is looplessGLIB-000V3 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be looplessGLIB-000V3"
    using glib_000_def_75 sorry
qed "sorry"

mtheorem glib_000_cl_51:
  mlet "GF be trivialGLIB-000V27\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is trivialGLIB-000V4"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be trivialGLIB-000V4"
    using glib_000_def_68 sorry
qed "sorry"

mtheorem glib_000_cl_52:
  mlet "GSq be trivialGLIB-000V35\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is trivialGLIB-000V4 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be trivialGLIB-000V4"
    using glib_000_def_76 sorry
qed "sorry"

mtheorem glib_000_cl_53:
  mlet "GF be non-trivialGLIB-000V28\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is  non trivialGLIB-000V4"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be  non trivialGLIB-000V4"
    using glib_000_def_69 sorry
qed "sorry"

mtheorem glib_000_cl_54:
  mlet "GSq be non-trivialGLIB-000V36\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is  non trivialGLIB-000V4 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be  non trivialGLIB-000V4"
    using glib_000_def_77 sorry
qed "sorry"

mtheorem glib_000_cl_55:
  mlet "GF be non-multiGLIB-000V29\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is non-multiGLIB-000V5"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be non-multiGLIB-000V5"
    using glib_000_def_70 sorry
qed "sorry"

mtheorem glib_000_cl_56:
  mlet "GSq be non-multiGLIB-000V37\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is non-multiGLIB-000V5 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be non-multiGLIB-000V5"
    using glib_000_def_78 sorry
qed "sorry"

mtheorem glib_000_cl_57:
  mlet "GF be non-DmultiGLIB-000V30\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is non-DmultiGLIB-000V6"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be non-DmultiGLIB-000V6"
    using glib_000_def_71 sorry
qed "sorry"

mtheorem glib_000_cl_58:
  mlet "GSq be non-DmultiGLIB-000V38\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is non-DmultiGLIB-000V6 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be non-DmultiGLIB-000V6"
    using glib_000_def_79 sorry
qed "sorry"

mtheorem glib_000_cl_59:
  mlet "GF be simpleGLIB-000V31\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is simpleGLIB-000V7"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be simpleGLIB-000V7"
    using glib_000_def_72 sorry
qed "sorry"

mtheorem glib_000_cl_60:
  mlet "GSq be simpleGLIB-000V39\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is simpleGLIB-000V7 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be simpleGLIB-000V7"
    using glib_000_def_80 sorry
qed "sorry"

mtheorem glib_000_cl_61:
  mlet "GF be DsimpleGLIB-000V32\<bar> non emptyXBOOLE-0V1\<bar>Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1", "x be ElementSUBSET-1M1-of domRELAT-1K1 GF"
"cluster GF .FUNCT-1K1 x as-term-is DsimpleGLIB-000V8"
proof
(*coherence*)
  show "GF .FUNCT-1K1 x be DsimpleGLIB-000V8"
    using glib_000_def_73 sorry
qed "sorry"

mtheorem glib_000_cl_62:
  mlet "GSq be DsimpleGLIB-000V40\<bar>GraphSeqGLIB-000M11", "x be NatNAT-1M1"
"cluster GSq .FUNCT-1K1 x as-term-is DsimpleGLIB-000V8 for -GraphGLIB-000M2"
proof
(*coherence*)
  show " for it be -GraphGLIB-000M2 holds it =HIDDENR1 GSq .FUNCT-1K1 x implies it be DsimpleGLIB-000V8"
    using glib_000_def_81 sorry
qed "sorry"

mtheorem glib_000_cl_63:
"cluster non-multiGLIB-000V21 also-is non-DmultiGLIB-000V22 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be non-multiGLIB-000V21 implies it be non-DmultiGLIB-000V22"
  proof-
    have " for GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds  not (GF be non-multiGLIB-000V21 &  not GF be non-DmultiGLIB-000V22)"
    proof(rule ballI)
      fix GF assume [ty]: "GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
      show " not (GF be non-multiGLIB-000V21 &  not GF be non-DmultiGLIB-000V22)"
      proof-
        have cases: "GF be emptyXBOOLE-0V1 or GF be  non emptyXBOOLE-0V1"
           sorry
        have case1: "GF be emptyXBOOLE-0V1 implies  not (GF be non-multiGLIB-000V21 &  not GF be non-DmultiGLIB-000V22)"
        proof(rule impI)
          assume "GF be emptyXBOOLE-0V1"
          thus " not (GF be non-multiGLIB-000V21 &  not GF be non-DmultiGLIB-000V22)"
             sorry
        qed
        have case2: "GF be  non emptyXBOOLE-0V1 implies  not (GF be non-multiGLIB-000V21 &  not GF be non-DmultiGLIB-000V22)"
        proof(rule impI)
          assume "GF be  non emptyXBOOLE-0V1"
          thus " not (GF be non-multiGLIB-000V21 &  not GF be non-DmultiGLIB-000V22)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_64:
"cluster simpleGLIB-000V23 also-is looplessGLIB-000V18\<bar>non-multiGLIB-000V21 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be simpleGLIB-000V23 implies it be looplessGLIB-000V18\<bar>non-multiGLIB-000V21"
  proof-
    have " for GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds  not (GF be simpleGLIB-000V23 &  not (GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21))"
    proof(rule ballI)
      fix GF assume [ty]: "GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
      show " not (GF be simpleGLIB-000V23 &  not (GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21))"
      proof-
        have cases: "GF be emptyXBOOLE-0V1 or GF be  non emptyXBOOLE-0V1"
           sorry
        have case1: "GF be emptyXBOOLE-0V1 implies  not (GF be simpleGLIB-000V23 &  not (GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21))"
        proof(rule impI)
          assume "GF be emptyXBOOLE-0V1"
          thus " not (GF be simpleGLIB-000V23 &  not (GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21))"
             sorry
        qed
        have case2: "GF be  non emptyXBOOLE-0V1 implies  not (GF be simpleGLIB-000V23 &  not (GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21))"
        proof(rule impI)
          assume "GF be  non emptyXBOOLE-0V1"
          thus " not (GF be simpleGLIB-000V23 &  not (GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_65:
"cluster looplessGLIB-000V18\<bar>non-multiGLIB-000V21 also-is simpleGLIB-000V23 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be looplessGLIB-000V18\<bar>non-multiGLIB-000V21 implies it be simpleGLIB-000V23"
  proof-
    have " for GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds  not ((GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21) &  not GF be simpleGLIB-000V23)"
    proof(rule ballI)
      fix GF assume [ty]: "GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
      show " not ((GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21) &  not GF be simpleGLIB-000V23)"
      proof-
        have cases: "GF be emptyXBOOLE-0V1 or GF be  non emptyXBOOLE-0V1"
           sorry
        have case1: "GF be emptyXBOOLE-0V1 implies  not ((GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21) &  not GF be simpleGLIB-000V23)"
        proof(rule impI)
          assume "GF be emptyXBOOLE-0V1"
          thus " not ((GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21) &  not GF be simpleGLIB-000V23)"
             sorry
        qed
        have case2: "GF be  non emptyXBOOLE-0V1 implies  not ((GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21) &  not GF be simpleGLIB-000V23)"
        proof(rule impI)
          assume "GF be  non emptyXBOOLE-0V1"
          thus " not ((GF be looplessGLIB-000V18 & GF be non-multiGLIB-000V21) &  not GF be simpleGLIB-000V23)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_66:
"cluster looplessGLIB-000V18\<bar>non-DmultiGLIB-000V22 also-is DsimpleGLIB-000V24 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be looplessGLIB-000V18\<bar>non-DmultiGLIB-000V22 implies it be DsimpleGLIB-000V24"
  proof-
    have " for GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds  not ((GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22) &  not GF be DsimpleGLIB-000V24)"
    proof(rule ballI)
      fix GF assume [ty]: "GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
      show " not ((GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22) &  not GF be DsimpleGLIB-000V24)"
      proof-
        have cases: "GF be emptyXBOOLE-0V1 or GF be  non emptyXBOOLE-0V1"
           sorry
        have case1: "GF be emptyXBOOLE-0V1 implies  not ((GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22) &  not GF be DsimpleGLIB-000V24)"
        proof(rule impI)
          assume "GF be emptyXBOOLE-0V1"
          thus " not ((GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22) &  not GF be DsimpleGLIB-000V24)"
             sorry
        qed
        have case2: "GF be  non emptyXBOOLE-0V1 implies  not ((GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22) &  not GF be DsimpleGLIB-000V24)"
        proof(rule impI)
          assume "GF be  non emptyXBOOLE-0V1"
          thus " not ((GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22) &  not GF be DsimpleGLIB-000V24)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_67:
"cluster DsimpleGLIB-000V24 also-is looplessGLIB-000V18\<bar>non-DmultiGLIB-000V22 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be DsimpleGLIB-000V24 implies it be looplessGLIB-000V18\<bar>non-DmultiGLIB-000V22"
  proof-
    have " for GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds  not (GF be DsimpleGLIB-000V24 &  not (GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22))"
    proof(rule ballI)
      fix GF assume [ty]: "GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
      show " not (GF be DsimpleGLIB-000V24 &  not (GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22))"
      proof-
        have cases: "GF be emptyXBOOLE-0V1 or GF be  non emptyXBOOLE-0V1"
           sorry
        have case1: "GF be emptyXBOOLE-0V1 implies  not (GF be DsimpleGLIB-000V24 &  not (GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22))"
        proof(rule impI)
          assume "GF be emptyXBOOLE-0V1"
          thus " not (GF be DsimpleGLIB-000V24 &  not (GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22))"
             sorry
        qed
        have case2: "GF be  non emptyXBOOLE-0V1 implies  not (GF be DsimpleGLIB-000V24 &  not (GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22))"
        proof(rule impI)
          assume "GF be  non emptyXBOOLE-0V1"
          thus " not (GF be DsimpleGLIB-000V24 &  not (GF be looplessGLIB-000V18 & GF be non-DmultiGLIB-000V22))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_68:
"cluster trivialGLIB-000V19\<bar>looplessGLIB-000V18 also-is finiteGLIB-000V17 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be trivialGLIB-000V19\<bar>looplessGLIB-000V18 implies it be finiteGLIB-000V17"
  proof-
    have " for GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds  not ((GF be trivialGLIB-000V19 & GF be looplessGLIB-000V18) &  not GF be finiteGLIB-000V17)"
    proof(rule ballI)
      fix GF assume [ty]: "GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
      show " not ((GF be trivialGLIB-000V19 & GF be looplessGLIB-000V18) &  not GF be finiteGLIB-000V17)"
      proof-
        have cases: "GF be emptyXBOOLE-0V1 or GF be  non emptyXBOOLE-0V1"
           sorry
        have case1: "GF be emptyXBOOLE-0V1 implies  not ((GF be trivialGLIB-000V19 & GF be looplessGLIB-000V18) &  not GF be finiteGLIB-000V17)"
        proof(rule impI)
          assume "GF be emptyXBOOLE-0V1"
          thus " not ((GF be trivialGLIB-000V19 & GF be looplessGLIB-000V18) &  not GF be finiteGLIB-000V17)"
             sorry
        qed
        have case2: "GF be  non emptyXBOOLE-0V1 implies  not ((GF be trivialGLIB-000V19 & GF be looplessGLIB-000V18) &  not GF be finiteGLIB-000V17)"
        proof(rule impI)
          assume "GF be  non emptyXBOOLE-0V1"
          thus " not ((GF be trivialGLIB-000V19 & GF be looplessGLIB-000V18) &  not GF be finiteGLIB-000V17)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem glib_000_cl_69:
"cluster trivialGLIB-000V19\<bar>non-DmultiGLIB-000V22 also-is finiteGLIB-000V17 for Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds it be trivialGLIB-000V19\<bar>non-DmultiGLIB-000V22 implies it be finiteGLIB-000V17"
  proof-
    have " for GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1 holds  not ((GF be trivialGLIB-000V19 & GF be non-DmultiGLIB-000V22) &  not GF be finiteGLIB-000V17)"
    proof(rule ballI)
      fix GF assume [ty]: "GF be Graph-yieldingGLIB-000V14\<bar>FunctionFUNCT-1M1"
      show " not ((GF be trivialGLIB-000V19 & GF be non-DmultiGLIB-000V22) &  not GF be finiteGLIB-000V17)"
      proof-
        have cases: "GF be emptyXBOOLE-0V1 or GF be  non emptyXBOOLE-0V1"
           sorry
        have case1: "GF be emptyXBOOLE-0V1 implies  not ((GF be trivialGLIB-000V19 & GF be non-DmultiGLIB-000V22) &  not GF be finiteGLIB-000V17)"
        proof(rule impI)
          assume "GF be emptyXBOOLE-0V1"
          thus " not ((GF be trivialGLIB-000V19 & GF be non-DmultiGLIB-000V22) &  not GF be finiteGLIB-000V17)"
             sorry
        qed
        have case2: "GF be  non emptyXBOOLE-0V1 implies  not ((GF be trivialGLIB-000V19 & GF be non-DmultiGLIB-000V22) &  not GF be finiteGLIB-000V17)"
        proof(rule impI)
          assume "GF be  non emptyXBOOLE-0V1"
          thus " not ((GF be trivialGLIB-000V19 & GF be non-DmultiGLIB-000V22) &  not GF be finiteGLIB-000V17)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
reserve GS for "GraphStructGLIB-000M1"
reserve G, G1, G2, G3 for "-GraphGLIB-000M2"
reserve e, x, x1, x2, y, y1, y2, E, V, X, Y for "setHIDDENM2"
reserve n, n1, n2 for "NatNAT-1M1"
reserve v, v1, v2 for "VertexGLIB-000M10-of G"
mtheorem glib_000_th_1:
"((VertexSelectorGLIB-000K1 =XBOOLE-0R4 \<one>\<^sub>M & EdgeSelectorGLIB-000K2 =XBOOLE-0R4 \<two>\<^sub>M) & SourceSelectorGLIB-000K3 =XBOOLE-0R4 \<three>\<^sub>M) & TargetSelectorGLIB-000K4 =XBOOLE-0R4 \<four>\<^sub>M"
   sorry

mtheorem glib_000_th_2:
" for G be -GraphGLIB-000M2 holds -GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
proof-
  have " for G be -GraphGLIB-000M2 holds -GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
  proof(rule ballI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 -GraphSelectorsGLIB-000K5 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 -GraphSelectorsGLIB-000K5"
      then have "((x =HIDDENR1 VertexSelectorGLIB-000K1 or x =HIDDENR1 EdgeSelectorGLIB-000K2) or x =HIDDENR1 SourceSelectorGLIB-000K3) or x =HIDDENR1 TargetSelectorGLIB-000K4"
        using enumset1_def_2 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
        using glib_000_def_10 sorry
    qed "sorry"
    thus "-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_3:
" for GS be GraphStructGLIB-000M1 holds ((the-Vertices-ofGLIB-000K6 GS =XBOOLE-0R4 GS .FUNCT-1K1 (VertexSelectorGLIB-000K1) & the-Edges-ofGLIB-000K7 GS =XBOOLE-0R4 GS .FUNCT-1K1 (EdgeSelectorGLIB-000K2)) & the-Source-ofGLIB-000K8 GS =XBOOLE-0R4 GS .FUNCT-1K1 (SourceSelectorGLIB-000K3)) & the-Target-ofGLIB-000K9 GS =XBOOLE-0R4 GS .FUNCT-1K1 (TargetSelectorGLIB-000K4)"
   sorry

mtheorem glib_000_th_4:
" for G be -GraphGLIB-000M2 holds ((domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Source-ofGLIB-000K10 G) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G & domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Target-ofGLIB-000K11 G) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G) & rngRELSET-1K2\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> (the-Source-ofGLIB-000K10 G) c=TARSKIR1 the-Vertices-ofGLIB-000K6 G) & rngRELSET-1K2\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> (the-Target-ofGLIB-000K11 G) c=TARSKIR1 the-Vertices-ofGLIB-000K6 G"
  using funct_2_def_1 sorry

mtheorem glib_000_th_5:
" for GS be GraphStructGLIB-000M1 holds GS be [Graph-like]GLIB-000V1 iff ((-GraphSelectorsGLIB-000K5 c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS & the-Vertices-ofGLIB-000K6 GS be  non emptyXBOOLE-0V1) & the-Source-ofGLIB-000K8 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)) & the-Target-ofGLIB-000K9 GS be FunctionFUNCT-2M1-of(the-Edges-ofGLIB-000K7 GS,the-Vertices-ofGLIB-000K6 GS)"
  using glib_000_lm_1 sorry

mtheorem glib_000_th_6:
" for V be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be setHIDDENM2 holds  for S be FunctionFUNCT-2M1-of(E,V) holds  for T be FunctionFUNCT-2M1-of(E,V) holds ((the-Vertices-ofGLIB-000K6 (createGraphGLIB-000K12(V,E,S,T)) =XBOOLE-0R4 V & the-Edges-ofGLIB-000K7 (createGraphGLIB-000K12(V,E,S,T)) =XBOOLE-0R4 E) & the-Source-ofGLIB-000K10 (createGraphGLIB-000K12(V,E,S,T)) =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 (createGraphGLIB-000K12(V,E,S,T)),the-Vertices-ofGLIB-000K6 (createGraphGLIB-000K12(V,E,S,T)),E,V)\<^esub> S) & the-Target-ofGLIB-000K11 (createGraphGLIB-000K12(V,E,S,T)) =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 (createGraphGLIB-000K12(V,E,S,T)),the-Vertices-ofGLIB-000K6 (createGraphGLIB-000K12(V,E,S,T)),E,V)\<^esub> T"
  using finseq_4_th_76 sorry

mtheorem glib_000_th_7:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS .setGLIB-000K13(n,x) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS \\/XBOOLE-0K2 {TARSKIK1 n}"
proof-
  have " for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS .setGLIB-000K13(n,x) =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS \\/XBOOLE-0K2 {TARSKIK1 n}"
  proof(rule ballI,rule ballI,rule ballI)
    fix GS assume [ty]: "GS be GraphStructGLIB-000M1"
    fix x assume [ty]: "x be setHIDDENM2"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?G2 = "GS .setGLIB-000K13(n,x)"
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS .setGLIB-000K13(n,x) =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS \\/XBOOLE-0K2 domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x)"
      using funct_4_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS \\/XBOOLE-0K2 {TARSKIK1 n}"
      using funcop_1_th_13 sorry
    finally show "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS .setGLIB-000K13(n,x) =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS \\/XBOOLE-0K2 {TARSKIK1 n}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_8:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds GS .setGLIB-000K13(n,x) .FUNCT-1K1 n =XBOOLE-0R4 x"
proof-
  have " for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds GS .setGLIB-000K13(n,x) .FUNCT-1K1 n =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule ballI)
    fix GS assume [ty]: "GS be GraphStructGLIB-000M1"
    fix x assume [ty]: "x be setHIDDENM2"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?G2 = "GS .setGLIB-000K13(n,x)"
    have "domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x) =XBOOLE-0R4 {TARSKIK1 n}"
      using funcop_1_th_13 sorry
    then have "n inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x)"
      using tarski_def_1 sorry
    then have "GS .setGLIB-000K13(n,x) .FUNCT-1K1 n =HIDDENR1 (n .-->FUNCOP-1K17 x).FUNCT-1K1 n"
      using funct_4_th_13 sorry
    also have "... = x"
      using funcop_1_th_72 sorry
    finally show "GS .setGLIB-000K13(n,x) .FUNCT-1K1 n =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_9:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds n1 <>HIDDENR2 n2 implies GS .FUNCT-1K1 n2 =XBOOLE-0R4 GS .setGLIB-000K13(n1,x) .FUNCT-1K1 n2"
proof-
  have " for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds n1 <>HIDDENR2 n2 implies GS .FUNCT-1K1 n2 =XBOOLE-0R4 GS .setGLIB-000K13(n1,x) .FUNCT-1K1 n2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix GS assume [ty]: "GS be GraphStructGLIB-000M1"
    fix x assume [ty]: "x be setHIDDENM2"
    fix n1 assume [ty]: "n1 be NatNAT-1M1"
    fix n2 assume [ty]: "n2 be NatNAT-1M1"
    assume "n1 <>HIDDENR2 n2"
    then have " not n2 inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 n1})\<^esub> (n1 .-->FUNCOP-1K17 x)"
      using tarski_def_1 sorry
    thus "GS .FUNCT-1K1 n2 =XBOOLE-0R4 GS .setGLIB-000K13(n1,x) .FUNCT-1K1 n2"
      using funct_4_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_10:
" for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds  not n inTARSKIR2 -GraphSelectorsGLIB-000K5 implies (((the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G .setGLIB-000K13(n,x) & the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G .setGLIB-000K13(n,x)) & the-Source-ofGLIB-000K10 G =XBOOLE-0R4 the-Source-ofGLIB-000K8 G .setGLIB-000K13(n,x)) & the-Target-ofGLIB-000K11 G =XBOOLE-0R4 the-Target-ofGLIB-000K9 G .setGLIB-000K13(n,x)) & G .setGLIB-000K13(n,x) be -GraphGLIB-000M2"
proof-
  have " for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for n be NatNAT-1M1 holds  not n inTARSKIR2 -GraphSelectorsGLIB-000K5 implies (((the-Vertices-ofGLIB-000K6 G .setGLIB-000K13(n,x) =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G & the-Edges-ofGLIB-000K7 G .setGLIB-000K13(n,x) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G) & the-Source-ofGLIB-000K8 G .setGLIB-000K13(n,x) =XBOOLE-0R4 the-Source-ofGLIB-000K10 G) & the-Target-ofGLIB-000K9 G .setGLIB-000K13(n,x) =XBOOLE-0R4 the-Target-ofGLIB-000K11 G) & G .setGLIB-000K13(n,x) be -GraphGLIB-000M2"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?G2 = "G .setGLIB-000K13(n,x)"
    have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?G2"
      using funct_4_th_10 sorry
    assume A2: " not n inTARSKIR2 -GraphSelectorsGLIB-000K5"
    then have "EdgeSelectorGLIB-000K2 <>HIDDENR2 n"
      using enumset1_def_2 sorry
    then have A3: " not EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x)"
      using tarski_def_1 sorry
    have "TargetSelectorGLIB-000K4 <>HIDDENR2 n"
      using A2 enumset1_def_2 sorry
    then have A4: " not TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x)"
      using tarski_def_1 sorry
    have "SourceSelectorGLIB-000K3 <>HIDDENR2 n"
      using A2 enumset1_def_2 sorry
    then have A5: " not SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x)"
      using tarski_def_1 sorry
    have "VertexSelectorGLIB-000K1 <>HIDDENR2 n"
      using A2 enumset1_def_2 sorry
    then have " not VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>({TARSKIK1 n})\<^esub> (n .-->FUNCOP-1K17 x)"
      using tarski_def_1 sorry
    thus A6: "((the-Vertices-ofGLIB-000K6 G .setGLIB-000K13(n,x) =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G & the-Edges-ofGLIB-000K7 G .setGLIB-000K13(n,x) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G) & the-Source-ofGLIB-000K8 G .setGLIB-000K13(n,x) =XBOOLE-0R4 the-Source-ofGLIB-000K10 G) & the-Target-ofGLIB-000K9 G .setGLIB-000K13(n,x) =XBOOLE-0R4 the-Target-ofGLIB-000K11 G"
      using A3 A5 A4 funct_4_th_11 sorry
    have A7: "SourceSelectorGLIB-000K3 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G & TargetSelectorGLIB-000K4 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
      using glib_000_def_10 sorry
    have "VertexSelectorGLIB-000K1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G & EdgeSelectorGLIB-000K2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G"
      using glib_000_def_10 sorry
    thus "G .setGLIB-000K13(n,x) be -GraphGLIB-000M2"
      using A7 A1 A6 glib_000_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_11:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds ((the-Vertices-ofGLIB-000K6 GS .setGLIB-000K13(VertexSelectorGLIB-000K1,x) =XBOOLE-0R4 x & the-Edges-ofGLIB-000K7 GS .setGLIB-000K13(EdgeSelectorGLIB-000K2,x) =XBOOLE-0R4 x) & the-Source-ofGLIB-000K8 GS .setGLIB-000K13(SourceSelectorGLIB-000K3,x) =XBOOLE-0R4 x) & the-Target-ofGLIB-000K9 GS .setGLIB-000K13(TargetSelectorGLIB-000K4,x) =XBOOLE-0R4 x"
  using glib_000_th_8 sorry

mtheorem glib_000_th_12:
" for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds n1 <>HIDDENR2 n2 implies ((n1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) & n2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y)) & (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n1 =XBOOLE-0R4 x) & (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n2 =XBOOLE-0R4 y"
proof-
  have " for GS be GraphStructGLIB-000M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds n1 <>HIDDENR2 n2 implies n1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) & (n2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) & ((GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n1 =HIDDENR1 x & (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n2 =XBOOLE-0R4 y))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix GS assume [ty]: "GS be GraphStructGLIB-000M1"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix n1 assume [ty]: "n1 be NatNAT-1M1"
    fix n2 assume [ty]: "n2 be NatNAT-1M1"
    assume A1: "n1 <>HIDDENR2 n2"
    let ?G2 = "GS .setGLIB-000K13(n1,x)"
    let ?G3 = "?G2 .setGLIB-000K13(n2,y)"
    have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?G3 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?G2 \\/XBOOLE-0K2 {TARSKIK1 n2}"
      using glib_000_th_7 sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?G2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> GS \\/XBOOLE-0K2 {TARSKIK1 n1} & n1 inTARSKIR2 {TARSKIK1 n1}"
      using glib_000_th_7 tarski_def_1 sorry
    then have "n1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?G2"
      using xboole_0_def_3 sorry
    thus "n1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y)"
      using A2 xboole_0_def_3 sorry
    have "n2 inTARSKIR2 {TARSKIK1 n2}"
      using tarski_def_1 sorry
    thus "n2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y)"
      using A2 xboole_0_def_3 sorry
    have "(GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n1 =HIDDENR1 GS .setGLIB-000K13(n1,x) .FUNCT-1K1 n1"
      using A1 glib_000_th_9 sorry
    also have "... = x"
      using glib_000_th_8 sorry
    finally show "(GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n1 =HIDDENR1 x"
       sorry
    show "(GS .setGLIB-000K13(n1,x)).setGLIB-000K13(n2,y) .FUNCT-1K1 n2 =XBOOLE-0R4 y"
      using glib_000_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_13:
" for G be -GraphGLIB-000M2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G) implies x inHIDDENR3 the-Vertices-ofGLIB-000K6 G & y inHIDDENR3 the-Vertices-ofGLIB-000K6 G"
  using funct_2_th_5 sorry

mtheorem glib_000_th_14:
" for G be -GraphGLIB-000M2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G) implies e JoinsGLIB-000R1(y,x,G)"
   sorry

mtheorem glib_000_th_15:
" for G be -GraphGLIB-000M2 holds  for e be objectHIDDENM1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds e JoinsGLIB-000R1(x1,y1,G) & e JoinsGLIB-000R1(x2,y2,G) implies x1 =HIDDENR1 x2 & y1 =HIDDENR1 y2 or x1 =HIDDENR1 y2 & y1 =HIDDENR1 x2"
   sorry

mtheorem glib_000_th_16:
" for G be -GraphGLIB-000M2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G) iff e DJoinsGLIB-000R2(x,y,G) or e DJoinsGLIB-000R2(y,x,G)"
   sorry

mtheorem glib_000_th_17:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e JoinsGLIB-000R1(x,y,G) & (x inHIDDENR3 X & y inHIDDENR3 Y or x inHIDDENR3 Y & y inHIDDENR3 X) implies e SJoinsGLIB-000R3(X,Y,G)"
   sorry

mtheorem glib_000_th_18:
" for G be -GraphGLIB-000M2 holds G be looplessGLIB-000V3 iff ( for v be objectHIDDENM1 holds  not ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,v,G)))"
proof-
  have " for G be -GraphGLIB-000M2 holds (G be looplessGLIB-000V3 implies ( for v be objectHIDDENM1 holds  not ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,v,G)))) & (( for v be objectHIDDENM1 holds  not ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,v,G))) implies G be looplessGLIB-000V3)"
  proof(rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    show "G be looplessGLIB-000V3 implies ( for v be objectHIDDENM1 holds  not ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,v,G)))"
       sorry
    assume A1: " for v be objectHIDDENM1 holds  not ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,v,G))"
    have "( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e) implies  False "
    proof(rule impI)
      assume Given: " ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
      then obtain e where
        [ty]:"e be objectHIDDENM1" and 
        A2: "e inHIDDENR3 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
         sorry
      let ?v = "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e"
      have "e JoinsGLIB-000R1(?v,?v,G)"
        using A2 sorry
      thus " False "
        using A1 sorry
    qed
    thus "G be looplessGLIB-000V3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_19:
" for G be looplessGLIB-000V3\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds v .degree()GLIB-000K34\<^bsub>(G)\<^esub> =XBOOLE-0R4 cardCARD-1K1 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
proof(rule ballI,rule ballI)
  fix G assume [ty]: "G be looplessGLIB-000V3\<bar>-GraphGLIB-000M2"
  fix v assume [ty]: "v be VertexGLIB-000M10-of G"
  let ?In = "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
  let ?Out = "v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
  have "( ex e be objectHIDDENM1 st e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) implies  False "
  proof(rule impI)
    assume Given: " ex e be objectHIDDENM1 st e inHIDDENR3 ?In /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> ?Out"
    then obtain e where
      [ty]:"e be objectHIDDENM1" and 
      A1: "e inHIDDENR3 ?In /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> ?Out"
       sorry
    have "e inHIDDENR3 ?Out"
      using A1 xboole_0_def_4 sorry
    then have A2: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using glib_000_lm_8 sorry
    have "e inHIDDENR3 ?In"
      using A1 xboole_0_def_4 sorry
    then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using glib_000_lm_7 sorry
    thus " False "
      using A1 A2 glib_000_def_18 sorry
  qed
  then have "?In /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> ?Out =XBOOLE-0R4 {}XBOOLE-0K1"
    using xboole_0_def_1 sorry
  then have "?In missesXBOOLE-0R1 ?Out"
    using xboole_0_def_7 sorry
  thus "v .degree()GLIB-000K34\<^bsub>(G)\<^esub> =XBOOLE-0R4 cardCARD-1K1 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
    using card_2_th_35 sorry
qed "sorry"

mtheorem glib_000_th_20:
" for G be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be  non emptyXBOOLE-0V1"
proof-
  have " for G be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  not the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be emptyXBOOLE-0V1"
  proof(rule ballI,rule ballI)
    fix G assume [ty]: "G be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    let ?VG = "the-Vertices-ofGLIB-000K6 G"
    have "the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume "?VG \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "?VG c=TARSKIR1 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
        using xboole_1_th_37 sorry
      then have "?VG =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
        using zfmisc_1_th_33 sorry
      then have "cardCARD-1K1 ?VG =XBOOLE-0R4 \<one>\<^sub>M"
        using card_1_th_30 sorry
      thus " False "
        using glib_000_def_19 sorry
    qed
    thus " not the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v} be emptyXBOOLE-0V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_21:
" for G be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  ex v1 be VertexGLIB-000M10-of G st  ex v2 be VertexGLIB-000M10-of G st v1 <>HIDDENR2 v2"
proof-
  have " for G be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  ex v1 be ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G st  ex tVar25 be VertexGLIB-000M10-of G st  not v1 <>HIDDENR2 tVar25"
  proof(rule ballI)
    fix G assume [ty]: "G be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
    let ?VG = "the-Vertices-ofGLIB-000K6 G"
    obtain v1 where 
      [ty]:"v1 be ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G" and v1Def:"v1 = the ElementSUBSET-1M1-of ?VG"
       sorry
    show " ex v1 be ElementSUBSET-1M1-of the-Vertices-ofGLIB-000K6 G st  ex tVar25 be VertexGLIB-000M10-of G st  not v1 <>HIDDENR2 tVar25"
    proof(rule bexI[of _ "v1"])
      let ?VG2 = "?VG \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v1}"
      have "the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v1} =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
      proof(rule impI)
        assume A1: "?VG2 =XBOOLE-0R4 {}XBOOLE-0K1"
        have "cardCARD-1K1 (?VG2 \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v1}) =HIDDENR1 cardCARD-1K1 ?VG2 +`CARD-2K1 cardCARD-1K4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v1}"
          using card_2_th_35 xboole_1_th_79 sorry
        also have "... = 0NUMBERSK6 +`CARD-2K1 \<one>\<^sub>M"
          using A1 card_1_th_30 sorry
        also have "... = cardCARD-1K1 (0NUMBERSK6 +^ORDINAL2K10 \<one>\<^sub>M)"
          using card_2_def_1 sorry
        also have "... = cardCARD-1K4 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
          using card_2_th_36 sorry
        also have "... = \<one>\<^sub>M"
           sorry
        finally have "cardCARD-1K1 (?VG2 \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v1}) =HIDDENR1 \<one>\<^sub>M"
           sorry
        then have "cardCARD-1K1 ?VG =XBOOLE-0R4 \<one>\<^sub>M"
          using xboole_1_th_45 sorry
        thus " False "
          using glib_000_def_19 sorry
      qed
      then obtain VG2 where 
        [ty]:"VG2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and VG2Def:"VG2 = ?VG2"
         sorry
      let ?v2 = "the ElementSUBSET-1M1-of VG2"
      have A2: " not ?v2 inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v1}"
        using xboole_0_def_5 sorry
      obtain v2 where 
        [ty]:"v2 be VertexGLIB-000M10-of G" and v2Def:"v2 = ?v2"
        using xboole_0_def_5 sorry
      show " ex tVar25 be VertexGLIB-000M10-of G st  not v1 <>HIDDENR2 tVar25"
      proof(rule bexI[of _ "v2"])
        show " not v1 <>HIDDENR2 v2"
          using A2 tarski_def_1 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_22:
" for G be trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
proof-
  have " for G be trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  ex tVar26 be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> tVar26}"
  proof(rule ballI)
    fix G assume [ty]: "G be trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
    have "cardCARD-1K4 (the-Vertices-ofGLIB-000K6 G) =XBOOLE-0R4 \<one>\<^sub>M"
      using glib_000_def_19 sorry
    then obtain v where
      [ty]:"v be objectHIDDENM1" and 
      A1: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {TARSKIK1 v}"
      using card_2_th_42 sorry
    have 
      [ty]:"v be VertexGLIB-000M10-of G"
      using A1 tarski_def_1 sorry
    show " ex tVar26 be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> tVar26}"
    proof(rule bexI[of _ "v"])
      show "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_23:
" for G be trivialGLIB-000V4\<bar>looplessGLIB-000V3\<bar>-GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1"
proof(rule ballI)
  fix G assume [ty]: "G be trivialGLIB-000V4\<bar>looplessGLIB-000V3\<bar>-GraphGLIB-000M2"
  obtain v where
    [ty]:"v be VertexGLIB-000M10-of G" and 
    A1: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
    using glib_000_th_22 sorry
  have "the-Edges-ofGLIB-000K7 G <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule impI)
    assume "the-Edges-ofGLIB-000K7 G <>HIDDENR2 {}XBOOLE-0K1"
    then obtain e where
      [ty]:"e be objectHIDDENM1" and 
      A2: "e inHIDDENR3 the-Edges-ofGLIB-000K7 G"
      using xboole_0_def_1 sorry
    have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
      using A1 A2 funct_2_th_5 sorry
    then have A3: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using tarski_def_1 sorry
    have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
      using A1 A2 funct_2_th_5 sorry
    then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using tarski_def_1 sorry
    thus " False "
      using A2 A3 glib_000_def_18 sorry
  qed
  thus "the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1"
     sorry
qed "sorry"

mtheorem glib_000_th_24:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1 implies G be simpleGLIB-000V7"
proof-
  have " for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1 implies G be simpleGLIB-000V7"
  proof(rule ballI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    assume A1: "the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A2: "G be looplessGLIB-000V3"
       sorry
    have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,G) & e2 JoinsGLIB-000R1(v1,v2,G) implies e1 =HIDDENR1 e2"
      using A1 sorry
    then have "G be non-multiGLIB-000V5"
       sorry
    thus "G be simpleGLIB-000V7"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_25:
" for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds G .order()GLIB-000K15 >=XXREAL-0R2 \<one>\<^sub>M"
proof(rule ballI)
  fix G assume [ty]: "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
  have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 G .order()GLIB-000K15 +NAT-1K1 \<one>\<^sub>M"
    using nat_1_th_3 xreal_1_th_8 sorry
  thus "G .order()GLIB-000K15 >=XXREAL-0R2 \<one>\<^sub>M"
    using nat_1_th_13 sorry
qed "sorry"

mtheorem glib_000_th_26:
" for G be -GraphGLIB-000M2 holds G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M iff G be trivialGLIB-000V4"
   sorry

mtheorem glib_000_th_27:
" for G be -GraphGLIB-000M2 holds G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M iff ( ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})"
proof-
  have " for G be -GraphGLIB-000M2 holds (G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M implies ( ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})) & (( ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}) implies G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M)"
  proof(rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    show "G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M implies ( ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})"
    proof(rule impI)
      assume "G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M"
      then obtain v where
        [ty]:"v be objectHIDDENM1" and 
        A1: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {TARSKIK1 v}"
        using card_2_th_42 sorry
      have 
        [ty]:"v be VertexGLIB-000M10-of G"
        using A1 tarski_def_1 sorry
      show " ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
      proof(rule bexI[of _ "v"])
        show "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
          using A1 sorry
      qed "sorry"
    qed
    assume Given: " ex v be VertexGLIB-000M10-of G st the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
    then obtain v where
      [ty]:"v be VertexGLIB-000M10-of G" and 
      A2: "the-Vertices-ofGLIB-000K6 G =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
       sorry
    show "G .order()GLIB-000K14 =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 card_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_28:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for X be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) iff e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
proof-
  have " for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for X be setHIDDENM2 holds (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) implies e inTARSKIR2 G .edgesInOutGLIB-000K20 X) & (e inTARSKIR2 G .edgesInOutGLIB-000K20 X implies e inTARSKIR2 the-Edges-ofGLIB-000K7 G &  not ( not (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    show "e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X) implies e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
    proof(rule impMI ,rule impI)
      assume A1: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G"
        and A2: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
      have "e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
      proof-
        show "e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
        proof-
          have cases: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
            using A2 sorry
          have case1: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X implies e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
          proof(rule impI)
            assume "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X"
            then have "e inTARSKIR2 G .edgesOutOfGLIB-000K19 X"
              using A1 glib_000_def_27 sorry
            thus "e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
              using xboole_0_def_3 sorry
          qed
          have case2: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X implies e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
          proof(rule impI)
            assume "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X"
            then have "e inTARSKIR2 G .edgesIntoGLIB-000K18 X"
              using A1 glib_000_def_26 sorry
            thus "e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
              using xboole_0_def_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
         sorry
    qed
    assume "e inTARSKIR2 G .edgesInOutGLIB-000K20 X"
    then have "e inTARSKIR2 G .edgesIntoGLIB-000K18 X or e inTARSKIR2 G .edgesOutOfGLIB-000K19 X"
      using xboole_0_def_3 sorry
    thus "e inTARSKIR2 the-Edges-ofGLIB-000K7 G &  not ( not (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X &  not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X)"
      using glib_000_def_26 glib_000_def_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_29:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds G .edgesIntoGLIB-000K18 X c=TARSKIR1 G .edgesInOutGLIB-000K20 X & G .edgesOutOfGLIB-000K19 X c=TARSKIR1 G .edgesInOutGLIB-000K20 X"
  using xboole_0_def_3 sorry

mtheorem glib_000_th_30:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G)"
proof-
  have " for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G)"
  proof(rule ballI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    let ?EG = "the-Edges-ofGLIB-000K7 G"
    let ?SG = "the-Source-ofGLIB-000K10 G"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 the-Edges-ofGLIB-000K7 G implies x inHIDDENR3 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G)) & (x inHIDDENR3 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G) implies x inHIDDENR3 the-Edges-ofGLIB-000K7 G)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 the-Edges-ofGLIB-000K7 G implies x inHIDDENR3 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G)"
      proof(rule impI)
        assume A1: "x inHIDDENR3 ?EG"
        then have "?SG .FUNCT-1K1 x inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
          using funct_2_th_5 sorry
        thus "x inHIDDENR3 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G)"
          using A1 glib_000_th_28 sorry
      qed
      assume "x inHIDDENR3 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G)"
      thus "x inHIDDENR3 the-Edges-ofGLIB-000K7 G"
         sorry
    qed "sorry"
    thus "the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesInOutGLIB-000K20 (the-Vertices-ofGLIB-000K6 G)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_31:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for X be setHIDDENM2 holds (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 X) & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 X iff e inTARSKIR2 G .edgesBetweenGLIB-000K21 X"
  using glib_000_lm_5 sorry

mtheorem glib_000_th_32:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & e JoinsGLIB-000R1(x,y,G) implies e inHIDDENR3 G .edgesBetweenGLIB-000K21 X"
  using glib_000_lm_5 sorry

mtheorem glib_000_th_33:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds G .edgesBetweenGLIB-000K21 X c=TARSKIR1 G .edgesInOutGLIB-000K20 X"
proof-
  have " for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds G .edgesBetweenGLIB-000K21 X c=TARSKIR1 G .edgesInOutGLIB-000K20 X"
  proof(rule ballI,rule ballI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix X assume [ty]: "X be setHIDDENM2"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 G .edgesBetweenGLIB-000K21 X implies z inHIDDENR3 G .edgesInOutGLIB-000K20 X"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 G .edgesBetweenGLIB-000K21 X"
      then have "z inHIDDENR3 G .edgesIntoGLIB-000K18 X"
        using xboole_0_def_4 sorry
      thus "z inHIDDENR3 G .edgesInOutGLIB-000K20 X"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "G .edgesBetweenGLIB-000K21 X c=TARSKIR1 G .edgesInOutGLIB-000K20 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_34:
" for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
proof-
  have " for G be -GraphGLIB-000M2 holds the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
  proof(rule ballI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    let ?EG = "the-Edges-ofGLIB-000K7 G"
    let ?SG = "the-Source-ofGLIB-000K10 G"
    let ?TG = "the-Target-ofGLIB-000K11 G"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 the-Edges-ofGLIB-000K7 G implies x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)) & (x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G) implies x inHIDDENR3 the-Edges-ofGLIB-000K7 G)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 the-Edges-ofGLIB-000K7 G implies x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
      proof(rule impI)
        assume A1: "x inHIDDENR3 ?EG"
        then have "?SG .FUNCT-1K1 x inTARSKIR2 the-Vertices-ofGLIB-000K6 G & ?TG .FUNCT-1K1 x inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
          using funct_2_th_5 sorry
        thus "x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
          using A1 glib_000_lm_5 sorry
      qed
      assume "x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
      thus "x inHIDDENR3 the-Edges-ofGLIB-000K7 G"
         sorry
    qed "sorry"
    thus "the-Edges-ofGLIB-000K7 G =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_35:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 G .edgesInOutGLIB-000K20 X =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 X)"
proof-
  have " for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 G .edgesInOutGLIB-000K20 X =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 X)"
  proof(rule ballI,rule ballI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix X assume [ty]: "X be setHIDDENM2"
    let ?EG = "the-Edges-ofGLIB-000K7 G"
    let ?VG = "the-Vertices-ofGLIB-000K6 G"
    let ?EIO = "G .edgesInOutGLIB-000K20 X"
    let ?EB = "G .edgesBetweenGLIB-000K21 (?VG \\SUBSET-1K6 X)"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 G .edgesInOutGLIB-000K20 X implies x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 X)) & (x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 X) implies x inHIDDENR3 the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 G .edgesInOutGLIB-000K20 X)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 G .edgesInOutGLIB-000K20 X implies x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 X)"
      proof(rule impI)
        assume A1: "x inHIDDENR3 ?EG \\SUBSET-1K6 ?EIO"
        then have A2: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 x inTARSKIR2 ?VG"
          using funct_2_th_5 sorry
        have A3: " not x inHIDDENR3 ?EIO"
          using A1 xboole_0_def_5 sorry
        then have " not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 x inTARSKIR2 X"
          using A1 glib_000_th_28 sorry
        then have A4: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 x inTARSKIR2 ?VG \\SUBSET-1K6 X"
          using A2 xboole_0_def_5 sorry
        have A5: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 x inTARSKIR2 ?VG"
          using A1 funct_2_th_5 sorry
        have " not (the-Source-ofGLIB-000K10 G).FUNCT-1K1 x inTARSKIR2 X"
          using A1 A3 glib_000_th_28 sorry
        then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 x inTARSKIR2 ?VG \\SUBSET-1K6 X"
          using A5 xboole_0_def_5 sorry
        thus "x inHIDDENR3 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 X)"
          using A1 A4 glib_000_lm_5 sorry
      qed
      assume A6: "x inHIDDENR3 ?EB"
      then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 x inTARSKIR2 ?VG \\SUBSET-1K6 X"
        using glib_000_lm_5 sorry
      then have A7: " not (the-Target-ofGLIB-000K11 G).FUNCT-1K1 x inTARSKIR2 X"
        using xboole_0_def_5 sorry
      have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 x inTARSKIR2 ?VG \\SUBSET-1K6 X"
        using A6 glib_000_lm_5 sorry
      then have " not (the-Source-ofGLIB-000K10 G).FUNCT-1K1 x inTARSKIR2 X"
        using xboole_0_def_5 sorry
      then have " not x inHIDDENR3 ?EIO"
        using A7 glib_000_th_28 sorry
      thus "x inHIDDENR3 the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 G .edgesInOutGLIB-000K20 X"
        using A6 xboole_0_def_5 sorry
    qed "sorry"
    thus "the-Edges-ofGLIB-000K7 G \\SUBSET-1K6 G .edgesInOutGLIB-000K20 X =XBOOLE-0R4 G .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G \\SUBSET-1K6 X)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_36:
" for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies G .edgesBetweenGLIB-000K21 X c=TARSKIR1 G .edgesBetweenGLIB-000K21 Y"
proof-
  have " for G be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies G .edgesBetweenGLIB-000K21 X c=TARSKIR1 G .edgesBetweenGLIB-000K21 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 G .edgesBetweenGLIB-000K21 X implies x inHIDDENR3 G .edgesBetweenGLIB-000K21 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 G .edgesBetweenGLIB-000K21 X"
      then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 x inTARSKIR2 X & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 x inTARSKIR2 X"
        using glib_000_lm_5 sorry
      thus "x inHIDDENR3 G .edgesBetweenGLIB-000K21 Y"
        using A1 A2 glib_000_lm_5 sorry
    qed "sorry"
    thus "G .edgesBetweenGLIB-000K21 X c=TARSKIR1 G .edgesBetweenGLIB-000K21 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_37:
" for G be -GraphGLIB-000M2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2 implies G .edgesBetweenGLIB-000K22(X1,Y1) c=TARSKIR1 G .edgesBetweenGLIB-000K22(X2,Y2)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix G assume [ty]: "G be -GraphGLIB-000M2"
  fix X1 assume [ty]: "X1 be setHIDDENM2"
  fix X2 assume [ty]: "X2 be setHIDDENM2"
  fix Y1 assume [ty]: "Y1 be setHIDDENM2"
  fix Y2 assume [ty]: "Y2 be setHIDDENM2"
  assume A1: "X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2"
  have " for e be objectHIDDENM1 holds e inHIDDENR3 G .edgesBetweenGLIB-000K22(X1,Y1) implies e inHIDDENR3 G .edgesBetweenGLIB-000K22(X2,Y2)"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    assume "e inHIDDENR3 G .edgesBetweenGLIB-000K22(X1,Y1)"
    then have "e SJoinsGLIB-000R3(X1,Y1,G)"
      using glib_000_def_30 sorry
    then have "e SJoinsGLIB-000R3(X2,Y2,G)"
      using A1 sorry
    thus "e inHIDDENR3 G .edgesBetweenGLIB-000K22(X2,Y2)"
      using glib_000_def_30 sorry
  qed "sorry"
  thus "G .edgesBetweenGLIB-000K22(X1,Y1) c=TARSKIR1 G .edgesBetweenGLIB-000K22(X2,Y2)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem glib_000_th_38:
" for G be -GraphGLIB-000M2 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2 implies G .edgesDBetweenGLIB-000K23(X1,Y1) c=TARSKIR1 G .edgesDBetweenGLIB-000K23(X2,Y2)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix G assume [ty]: "G be -GraphGLIB-000M2"
  fix X1 assume [ty]: "X1 be setHIDDENM2"
  fix X2 assume [ty]: "X2 be setHIDDENM2"
  fix Y1 assume [ty]: "Y1 be setHIDDENM2"
  fix Y2 assume [ty]: "Y2 be setHIDDENM2"
  assume A1: "X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2"
  have " for e be objectHIDDENM1 holds e inHIDDENR3 G .edgesDBetweenGLIB-000K23(X1,Y1) implies e inHIDDENR3 G .edgesDBetweenGLIB-000K23(X2,Y2)"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    assume "e inHIDDENR3 G .edgesDBetweenGLIB-000K23(X1,Y1)"
    then have "e DSJoinsGLIB-000R4(X1,Y1,G)"
      using glib_000_def_31 sorry
    then have "e DSJoinsGLIB-000R4(X2,Y2,G)"
      using A1 sorry
    thus "e inHIDDENR3 G .edgesDBetweenGLIB-000K23(X2,Y2)"
      using glib_000_def_31 sorry
  qed "sorry"
  thus "G .edgesDBetweenGLIB-000K23(X1,Y1) c=TARSKIR1 G .edgesDBetweenGLIB-000K23(X2,Y2)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem glib_000_th_39:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 G .edgesDBetweenGLIB-000K23(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}) & v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 G .edgesDBetweenGLIB-000K23({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G)"
proof(rule ballI,rule ballI,rule conjMI)
  fix G assume [ty]: "G be -GraphGLIB-000M2"
  fix v assume [ty]: "v be VertexGLIB-000M10-of G"
  have " for e be objectHIDDENM1 holds (e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> implies e inHIDDENR3 G .edgesDBetweenGLIB-000K23(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})) & (e inHIDDENR3 G .edgesDBetweenGLIB-000K23(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}) implies e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule conjMI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    show "e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> implies e inHIDDENR3 G .edgesDBetweenGLIB-000K23(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})"
    proof(rule impI)
      assume A1: "e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
      then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
        using glib_000_lm_7 sorry
      then have A2: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
        using tarski_def_1 sorry
      have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
        using A1 funct_2_th_5 sorry
      then have "e DSJoinsGLIB-000R4(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},G)"
        using A1 A2 sorry
      thus "e inHIDDENR3 G .edgesDBetweenGLIB-000K23(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})"
        using glib_000_def_31 sorry
    qed
    assume A3: "e inHIDDENR3 G .edgesDBetweenGLIB-000K23(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})"
    then have "e DSJoinsGLIB-000R4(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},G)"
      using glib_000_def_31 sorry
    then have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using tarski_def_1 sorry
    thus "e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
      using A3 glib_000_lm_7 sorry
  qed "sorry"
  thus "v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> =XBOOLE-0R4 G .edgesDBetweenGLIB-000K23(the-Vertices-ofGLIB-000K6 G,{DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v})"
    using tarski_th_2 sorry
  have " for e be objectHIDDENM1 holds (e inHIDDENR3 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> implies e inHIDDENR3 G .edgesDBetweenGLIB-000K23({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G)) & (e inHIDDENR3 G .edgesDBetweenGLIB-000K23({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G) implies e inHIDDENR3 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule conjMI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    show "e inHIDDENR3 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> implies e inHIDDENR3 G .edgesDBetweenGLIB-000K23({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G)"
    proof(rule impI)
      assume A4: "e inHIDDENR3 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
      then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
        using glib_000_lm_8 sorry
      then have A5: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v}"
        using tarski_def_1 sorry
      have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e inTARSKIR2 the-Vertices-ofGLIB-000K6 G"
        using A4 funct_2_th_5 sorry
      then have "e DSJoinsGLIB-000R4({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G,G)"
        using A4 A5 sorry
      thus "e inHIDDENR3 G .edgesDBetweenGLIB-000K23({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G)"
        using glib_000_def_31 sorry
    qed
    assume A6: "e inHIDDENR3 G .edgesDBetweenGLIB-000K23({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G)"
    then have "e DSJoinsGLIB-000R4({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G,G)"
      using glib_000_def_31 sorry
    then have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using tarski_def_1 sorry
    thus "e inHIDDENR3 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
      using A6 glib_000_lm_8 sorry
  qed "sorry"
  thus "v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> =XBOOLE-0R4 G .edgesDBetweenGLIB-000K23({DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v},the-Vertices-ofGLIB-000K6 G)"
    using tarski_th_2 sorry
qed "sorry"

mtheorem glib_000_th_40:
" for G be -GraphGLIB-000M2 holds G be SubgraphGLIB-000M3-of G"
  using glib_000_lm_3 sorry

mtheorem glib_000_th_41:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 be SubgraphGLIB-000M3-of G2 & G2 be SubgraphGLIB-000M3-of G1 iff ((the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2) & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds (G1 be SubgraphGLIB-000M3-of G2 & G2 be SubgraphGLIB-000M3-of G1 implies (the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & (the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2 & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2)) & ((the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & (the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2 & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2) implies G1 be SubgraphGLIB-000M3-of G2 & G2 be SubgraphGLIB-000M3-of G1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be -GraphGLIB-000M2"
    show "G1 be SubgraphGLIB-000M3-of G2 & G2 be SubgraphGLIB-000M3-of G1 implies (the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2) & (the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2 & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2)"
    proof(rule impMI ,rule impI,rule conjMI,rule conjMI)
      assume A1: "G1 be SubgraphGLIB-000M3-of G2"
        and A2: "G2 be SubgraphGLIB-000M3-of G1"
      have A3: "the-Vertices-ofGLIB-000K6 G2 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G1 & the-Edges-ofGLIB-000K7 G2 c=TARSKIR1 the-Edges-ofGLIB-000K7 G1"
        using A2 glib_000_def_32 sorry
      have "the-Vertices-ofGLIB-000K6 G1 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 c=TARSKIR1 the-Edges-ofGLIB-000K7 G2"
        using A1 glib_000_def_32 sorry
      thus A4: "the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2"
        using A3 xboole_0_def_10 sorry
      then have A5: "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Source-ofGLIB-000K10 G1) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 & domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Source-ofGLIB-000K10 G2) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1"
        using funct_2_def_1 sorry
      have " for e be objectHIDDENM1 holds e inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Source-ofGLIB-000K10 G1) implies (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
        using A1 glib_000_def_32 sorry
      thus "the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2"
        using A5 funct_1_th_2 sorry
      have A6: "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Target-ofGLIB-000K11 G1) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 & domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Target-ofGLIB-000K11 G2) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1"
        using A4 funct_2_def_1 sorry
      have " for e be objectHIDDENM1 holds e inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Target-ofGLIB-000K11 G1) implies (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
        using A1 glib_000_def_32 sorry
      thus "the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
        using A6 funct_1_th_2 sorry
    qed
    assume A7: "the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2 & the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2"
      and A8: "the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2 & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
    have " for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 implies (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
      using A8 sorry
    thus "G1 be SubgraphGLIB-000M3-of G2 & G2 be SubgraphGLIB-000M3-of G1"
      using A7 glib_000_def_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_42:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be setHIDDENM2 holds (x inTARSKIR2 the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 implies x inTARSKIR2 the-Vertices-ofGLIB-000K6 G1) & (x inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 implies x inTARSKIR2 the-Edges-ofGLIB-000K7 G1)"
   sorry

mtheorem glib_000_th_43:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for G3 be SubgraphGLIB-000M3-of G2 holds G3 be SubgraphGLIB-000M3-of G1"
proof(rule ballI,rule ballI,rule ballI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
  fix G3 assume [ty]: "G3 be SubgraphGLIB-000M3-of G2"
  have A1: "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 c=TARSKIR1 the-Edges-ofGLIB-000K7 G1"
     sorry
  have A2: "the-Vertices-ofGLIB-000K24\<^bsub>(G2)\<^esub> G3 c=TARSKIR1 the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2"
     sorry
  have "the-Vertices-ofGLIB-000K24\<^bsub>(G2)\<^esub> G3 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G1 & (the-Edges-ofGLIB-000K25\<^bsub>(G2)\<^esub> G3 c=TARSKIR1 the-Edges-ofGLIB-000K7 G1 & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G2)\<^esub> G3 implies (the-Source-ofGLIB-000K10 G3).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G3).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e))"
  proof(rule conjMI,rule conjMI,rule ballI,rule impI,rule conjMI)
    show "the-Vertices-ofGLIB-000K24\<^bsub>(G2)\<^esub> G3 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G1"
      using A2 xboole_1_th_1 sorry
    show "the-Edges-ofGLIB-000K25\<^bsub>(G2)\<^esub> G3 c=TARSKIR1 the-Edges-ofGLIB-000K7 G1"
      using A1 sorry
    fix e assume [ty]: "e be setHIDDENM2"
    assume A3: "e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G2)\<^esub> G3"
    then have "(the-Source-ofGLIB-000K10 G3).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
      using glib_000_def_32 sorry
    also have "... = (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e"
      using A3 glib_000_def_32 sorry
    finally show "(the-Source-ofGLIB-000K10 G3).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e"
       sorry
    have "(the-Target-ofGLIB-000K11 G3).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
      using A3 glib_000_def_32 sorry
    also have "... = (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
      using A3 glib_000_def_32 sorry
    finally show "(the-Target-ofGLIB-000K11 G3).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
       sorry
  qed "sorry"
  thus "G3 be SubgraphGLIB-000M3-of G1"
    using glib_000_def_32 sorry
qed "sorry"

mtheorem glib_000_th_44:
" for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c=TARSKIR1 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c=TARSKIR1 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 implies G1 be SubgraphGLIB-000M3-of G2"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix G assume [ty]: "G be -GraphGLIB-000M2"
  fix G1 assume [ty]: "G1 be SubgraphGLIB-000M3-of G"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G"
  assume A1: "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c=TARSKIR1 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2"
    and A2: "the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c=TARSKIR1 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
  have " for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 implies (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
  proof(rule ballI,rule impI,rule conjMI)
    fix e assume [ty]: "e be setHIDDENM2"
    assume A3: "e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1"
    then have "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e"
      using glib_000_def_32 sorry
    also have "... = (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
      using A2 A3 glib_000_def_32 sorry
    finally show "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
       sorry
    have "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
      using A3 glib_000_def_32 sorry
    also have "... = (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
      using A2 A3 glib_000_def_32 sorry
    finally show "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
       sorry
  qed "sorry"
  thus "G1 be SubgraphGLIB-000M3-of G2"
    using A1 A2 glib_000_def_32 sorry
qed "sorry"

mtheorem glib_000_th_45:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds the-Source-ofGLIB-000K10 G2 =FUNCT-1R1 (the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) & the-Target-ofGLIB-000K11 G2 =FUNCT-1R1 (the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
proof(rule ballI,rule ballI,rule conjMI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
  let ?S2 = "(the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
  let ?T2 = "(the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
  have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Source-ofGLIB-000K10 G2) implies (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 x =HIDDENR1 ((the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)).FUNCT-1K1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Source-ofGLIB-000K10 G2)"
    then have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 x =HIDDENR1 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 x"
      using glib_000_def_32 sorry
    also have "... = ((the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)).FUNCT-1K1 x"
      using A2 funct_1_th_49 sorry
    finally show "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 x =HIDDENR1 ((the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)).FUNCT-1K1 x"
       sorry
  qed "sorry"
  have "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Source-ofGLIB-000K10 G1) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1"
    using funct_2_def_1 sorry
  then have "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Source-ofGLIB-000K10 G2) =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 & domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> ?S2 =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
    using funct_2_def_1 relat_1_th_62 sorry
  thus "the-Source-ofGLIB-000K10 G2 =FUNCT-1R1 (the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
    using A1 funct_1_th_2 sorry
  have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Target-ofGLIB-000K11 G2) implies (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 x =HIDDENR1 ((the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)).FUNCT-1K1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Target-ofGLIB-000K11 G2)"
    then have "(the-Target-ofGLIB-000K11 G2).FUNCT-1K1 x =HIDDENR1 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 x"
      using glib_000_def_32 sorry
    also have "... = ((the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)).FUNCT-1K1 x"
      using A4 funct_1_th_49 sorry
    finally show "(the-Target-ofGLIB-000K11 G2).FUNCT-1K1 x =HIDDENR1 ((the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)).FUNCT-1K1 x"
       sorry
  qed "sorry"
  have "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Target-ofGLIB-000K11 G1) =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1"
    using funct_2_def_1 sorry
  then have "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Target-ofGLIB-000K11 G2) =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 & domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> ?T2 =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
    using funct_2_def_1 relat_1_th_62 sorry
  thus "the-Target-ofGLIB-000K11 G2 =FUNCT-1R1 (the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
    using A3 funct_1_th_2 sorry
qed "sorry"

mtheorem glib_000_th_46:
" for G be -GraphGLIB-000M2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for E1 be setHIDDENM2 holds  for E2 be setHIDDENM2 holds  for G1 be inducedSubgraphGLIB-000M4-of(G,V1,E1) holds  for G2 be inducedSubgraphGLIB-000M4-of(G,V2,E2) holds ((V2 c=TARSKIR1 V1 & E2 c=TARSKIR1 E1) & V2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G) & E2 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V2 implies G2 be SubgraphGLIB-000M3-of G1"
proof-
  have " for G be -GraphGLIB-000M2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for E1 be setHIDDENM2 holds  for E2 be setHIDDENM2 holds  for G1 be inducedSubgraphGLIB-000M4-of(G,V1,E1) holds  for G2 be inducedSubgraphGLIB-000M4-of(G,V2,E2) holds (V2 c=TARSKIR1 V1 & E2 c=TARSKIR1 E1) & (V2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E2 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V2) implies G2 be SubgraphGLIB-000M3-of G1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix V1 assume [ty]: "V1 be setHIDDENM2"
    fix V2 assume [ty]: "V2 be setHIDDENM2"
    fix E1 assume [ty]: "E1 be setHIDDENM2"
    fix E2 assume [ty]: "E2 be setHIDDENM2"
    fix G1 assume [ty]: "G1 be inducedSubgraphGLIB-000M4-of(G,V1,E1)"
    fix G2 assume [ty]: "G2 be inducedSubgraphGLIB-000M4-of(G,V2,E2)"
    assume A1: "V2 c=TARSKIR1 V1 & E2 c=TARSKIR1 E1"
      and A2: "V2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E2 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V2"
    have A3: "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 =XBOOLE-0R4 V2 & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 =XBOOLE-0R4 E2"
      using A2 glib_000_def_37 sorry
    have "G2 be SubgraphGLIB-000M3-of G1"
    proof-
      show "G2 be SubgraphGLIB-000M3-of G1"
      proof-
        have cases: "V1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E1 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V1 or  not (V1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E1 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V1)"
           sorry
        have case1: "V1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E1 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V1 implies G2 be SubgraphGLIB-000M3-of G1"
        proof(rule impI)
          assume "V1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E1 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V1"
          then have "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 V1 & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 E1"
            using glib_000_def_37 sorry
          thus "G2 be SubgraphGLIB-000M3-of G1"
            using A1 A3 glib_000_th_44 sorry
        qed
        have case2: " not (V1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E1 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V1) implies G2 be SubgraphGLIB-000M3-of G1"
        proof(rule impI)
          assume " not (V1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E1 c=TARSKIR1 G .edgesBetweenGLIB-000K21 V1)"
          then have "G1 ==GLIB-000R5 G"
            using glib_000_def_37 sorry
          thus "G2 be SubgraphGLIB-000M3-of G1"
            using A3 glib_000_th_44 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "G2 be SubgraphGLIB-000M3-of G1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_47:
" for G1 be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G1 holds  for G2 be removeVertexGLIB-000M6-of(G1,v) holds the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v} & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v})"
proof(rule ballI,rule ballI,rule ballI)
  fix G1 assume [ty]: "G1 be  non trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
  fix v assume [ty]: "v be VertexGLIB-000M10-of G1"
  fix G2 assume [ty]: "G2 be removeVertexGLIB-000M6-of(G1,v)"
  let ?VG = "the-Vertices-ofGLIB-000K6 G1"
  let ?V = "?VG \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v}"
  have "the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v} be emptyXBOOLE-0V1 implies  False "
  proof(rule impI)
    assume "?V be emptyXBOOLE-0V1"
    then have "?VG c=TARSKIR1 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v}"
      using xboole_1_th_37 sorry
    then have "?VG =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v}"
      using zfmisc_1_th_33 sorry
    then have "cardCARD-1K1 ?VG =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 sorry
    thus " False "
      using glib_000_def_19 sorry
  qed
  then obtain V where 
    [ty]:"V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ?VG" and VDef:"V = ?V"
     sorry
  have "G2 be inducedSubgraphGLIB-000M5-of(G1,V)"
     sorry
  thus "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v} & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v})"
    using glib_000_def_37 sorry
qed "sorry"

mtheorem glib_000_th_48:
" for G1 be finiteFINSET-1V1\<bar> non trivialGLIB-000V4\<bar>-GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G1 holds  for G2 be removeVertexGLIB-000M6-of(G1,v) holds G2 .order()GLIB-000K15 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 G1 .order()GLIB-000K15 & G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 v .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 G1 .size()GLIB-000K17"
proof(rule ballI,rule ballI,rule ballI,rule conjMI)
  fix G1 assume [ty]: "G1 be finiteFINSET-1V1\<bar> non trivialGLIB-000V4\<bar>-GraphGLIB-000M2"
  fix v assume [ty]: "v be VertexGLIB-000M10-of G1"
  fix G2 assume [ty]: "G2 be removeVertexGLIB-000M6-of(G1,v)"
  let ?VG1 = "the-Vertices-ofGLIB-000K6 G1"
  let ?VG2 = "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2"
  let ?EG1 = "the-Edges-ofGLIB-000K7 G1"
  let ?EG2 = "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
  let ?EV = "v .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
  have A1: "?VG2 =XBOOLE-0R4 ?VG1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v}"
    using glib_000_th_47 sorry
  have "v inTARSKIR2 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v}"
    using tarski_def_1 sorry
  then have " not v inTARSKIR2 ?VG2"
    using A1 xboole_0_def_5 sorry
  then have "cardCARD-1K4 ((?VG1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v})\\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v}) =XBOOLE-0R4 G2 .order()GLIB-000K15 +NAT-1K1 \<one>\<^sub>M"
    using A1 card_2_th_41 sorry
  thus "G2 .order()GLIB-000K15 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 G1 .order()GLIB-000K15"
    using xboole_1_th_45 sorry
  have A2: "?EG2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (?VG1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v}) & G1 .edgesBetweenGLIB-000K21 (?VG1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> v}) =XBOOLE-0R4 ?EG1 \\SUBSET-1K6 ?EV"
    using glib_000_th_35 glib_000_th_47 sorry
  then have "?EG1 =XBOOLE-0R4 ?EG2 \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> ?EV"
    using xboole_1_th_45 sorry
  thus "G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 v .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 G1 .size()GLIB-000K17"
    using A2 card_2_th_40 xboole_1_th_79 sorry
qed "sorry"

mtheorem glib_000_th_49:
" for G1 be -GraphGLIB-000M2 holds  for V be setHIDDENM2 holds  for G2 be removeVerticesGLIB-000M7-of(G1,V) holds V c<XBOOLE-0R2 the-Vertices-ofGLIB-000K6 G1 implies the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 V & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 V)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix V assume [ty]: "V be setHIDDENM2"
  fix G2 assume [ty]: "G2 be removeVerticesGLIB-000M7-of(G1,V)"
  let ?VG2 = "the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 V"
  assume A1: "V c<XBOOLE-0R2 the-Vertices-ofGLIB-000K6 G1"
  have "the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 V be emptyXBOOLE-0V1 implies  False "
  proof(rule impI)
    assume "?VG2 be emptyXBOOLE-0V1"
    then have "the-Vertices-ofGLIB-000K6 G1 c=TARSKIR1 V"
      using xboole_1_th_37 sorry
    thus " False "
      using A1 xboole_0_def_8 sorry
  qed
  then obtain VG2 where 
    [ty]:"VG2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1" and VG2Def:"VG2 = ?VG2"
     sorry
  have "G2 be inducedSubgraphGLIB-000M5-of(G1,VG2)"
     sorry
  thus "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 V & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G1 \\SUBSET-1K6 V)"
    using glib_000_def_37 sorry
qed "sorry"

mtheorem glib_000_th_50:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for V be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1 holds  for G2 be removeVerticesGLIB-000M7-of(G1,V) holds V <>HIDDENR2 the-Vertices-ofGLIB-000K6 G1 implies G2 .order()GLIB-000K15 +NAT-1K1 cardCARD-1K4 V =XBOOLE-0R4 G1 .order()GLIB-000K15 & G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 G1 .edgesInOutGLIB-000K20 V =XBOOLE-0R4 G1 .size()GLIB-000K17"
proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
  fix G1 assume [ty]: "G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
  fix V assume [ty]: "V be SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1"
  fix G2 assume [ty]: "G2 be removeVerticesGLIB-000M7-of(G1,V)"
  let ?VG1 = "the-Vertices-ofGLIB-000K6 G1"
  let ?VG2 = "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2"
  let ?EG1 = "the-Edges-ofGLIB-000K7 G1"
  let ?EG2 = "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
  have A1: "G1 .edgesBetweenGLIB-000K21 (?VG1 \\SUBSET-1K6 V) =XBOOLE-0R4 ?EG1 \\SUBSET-1K6 G1 .edgesInOutGLIB-000K20 V"
    using glib_000_th_35 sorry
  assume "V <>HIDDENR2 ?VG1"
  then have A2: "V c<XBOOLE-0R2 ?VG1"
    using xboole_0_def_8 sorry
  then have A3: "?VG2 =XBOOLE-0R4 ?VG1 \\SUBSET-1K6 V"
    using glib_000_th_49 sorry
  then have "cardCARD-1K4 (?VG2 \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G1)\<^esub> V) =XBOOLE-0R4 cardCARD-1K4 ?VG2 +NAT-1K1 cardCARD-1K4 V"
    using card_2_th_40 xboole_1_th_79 sorry
  thus "G2 .order()GLIB-000K15 +NAT-1K1 cardCARD-1K4 V =XBOOLE-0R4 G1 .order()GLIB-000K15"
    using A3 xboole_1_th_45 sorry
  have A4: "?EG2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (?VG1 \\SUBSET-1K6 V)"
    using A2 glib_000_th_49 sorry
  then have "?EG1 =XBOOLE-0R4 ?EG2 \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> G1 .edgesInOutGLIB-000K20 V"
    using A1 xboole_1_th_45 sorry
  thus "G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 G1 .edgesInOutGLIB-000K20 V =XBOOLE-0R4 G1 .size()GLIB-000K17"
    using A4 A1 card_2_th_40 xboole_1_th_79 sorry
qed "sorry"

mtheorem glib_000_th_51:
" for G1 be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for G2 be removeEdgeGLIB-000M8-of(G1,e) holds the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 {TARSKIK1 e}"
proof(rule ballI,rule ballI,rule ballI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix e assume [ty]: "e be setHIDDENM2"
  fix G2 assume [ty]: "G2 be removeEdgeGLIB-000M8-of(G1,e)"
  let ?V = "the-Vertices-ofGLIB-000K6 G1"
  have "?V c=TARSKIR1 ?V"
     sorry
  then obtain V where 
    [ty]:"V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1" and VDef:"V = ?V"
     sorry
  let ?E = "the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 {TARSKIK1 e}"
  obtain E where 
    [ty]:"E be SubsetSUBSET-1M2-of G1 .edgesBetweenGLIB-000K21 V" and EDef:"E = ?E"
    using glib_000_th_34 sorry
  have "G2 be inducedSubgraphGLIB-000M4-of(G1,V,E)"
     sorry
  thus "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 {TARSKIK1 e}"
    using glib_000_def_37 sorry
qed "sorry"

mtheorem glib_000_th_52:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for G2 be removeEdgeGLIB-000M8-of(G1,e) holds G1 .order()GLIB-000K15 =XBOOLE-0R4 G2 .order()GLIB-000K15 & (e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 implies G2 .size()GLIB-000K17 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 G1 .size()GLIB-000K17)"
proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
  fix G1 assume [ty]: "G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
  fix e assume [ty]: "e be setHIDDENM2"
  fix G2 assume [ty]: "G2 be removeEdgeGLIB-000M8-of(G1,e)"
  have A1: "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 {TARSKIK1 e}"
    using glib_000_th_51 sorry
  show "G1 .order()GLIB-000K15 =XBOOLE-0R4 G2 .order()GLIB-000K15"
    using glib_000_th_51 sorry
  assume "e inTARSKIR2 the-Edges-ofGLIB-000K7 G1"
  then have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 e} implies x inHIDDENR3 the-Edges-ofGLIB-000K7 G1"
    using tarski_def_1 sorry
  then have "{TARSKIK1 e} c=TARSKIR1 the-Edges-ofGLIB-000K7 G1"
     sorry
  then have A2: "the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 \\/XBOOLE-0K2 {TARSKIK1 e}"
    using A1 xboole_1_th_45 sorry
  have "e inTARSKIR2 {TARSKIK1 e}"
    using tarski_def_1 sorry
  then have " not e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
    using A1 xboole_0_def_5 sorry
  thus "G2 .size()GLIB-000K17 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 G1 .size()GLIB-000K17"
    using A2 card_2_th_41 sorry
qed "sorry"

mtheorem glib_000_th_53:
" for G1 be -GraphGLIB-000M2 holds  for E be setHIDDENM2 holds  for G2 be removeEdgesGLIB-000M9-of(G1,E) holds the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 E"
proof(rule ballI,rule ballI,rule ballI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix E assume [ty]: "E be setHIDDENM2"
  fix G2 assume [ty]: "G2 be removeEdgesGLIB-000M9-of(G1,E)"
  let ?V = "the-Vertices-ofGLIB-000K6 G1"
  have "?V c=TARSKIR1 ?V"
     sorry
  then obtain V where 
    [ty]:"V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1" and VDef:"V = ?V"
     sorry
  let ?E2 = "the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 E"
  obtain E2 where 
    [ty]:"E2 be SubsetSUBSET-1M2-of G1 .edgesBetweenGLIB-000K21 V" and E2Def:"E2 = ?E2"
    using glib_000_th_34 sorry
  have "G2 be inducedSubgraphGLIB-000M4-of(G1,V,E2)"
     sorry
  thus "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1 & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 E"
    using glib_000_def_37 sorry
qed "sorry"

mtheorem glib_000_th_54:
" for G1 be -GraphGLIB-000M2 holds  for E be setHIDDENM2 holds  for G2 be removeEdgesGLIB-000M9-of(G1,E) holds G1 .order()GLIB-000K14 =XBOOLE-0R4 G2 .order()GLIB-000K14"
  using glib_000_th_53 sorry

mtheorem glib_000_th_55:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for E be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G1 holds  for G2 be removeEdgesGLIB-000M9-of(G1,E) holds G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 E =XBOOLE-0R4 G1 .size()GLIB-000K17"
proof(rule ballI,rule ballI,rule ballI)
  fix G1 assume [ty]: "G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
  fix E assume [ty]: "E be SubsetSUBSET-1M2-of the-Edges-ofGLIB-000K7 G1"
  fix G2 assume [ty]: "G2 be removeEdgesGLIB-000M9-of(G1,E)"
  have A1: "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1 \\SUBSET-1K6 E"
    using glib_000_th_53 sorry
  then have "the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> E"
    using xboole_1_th_45 sorry
  thus "G2 .size()GLIB-000K17 +NAT-1K1 cardCARD-1K4 E =XBOOLE-0R4 G1 .size()GLIB-000K17"
    using A1 card_2_th_40 xboole_1_th_79 sorry
qed "sorry"

mtheorem glib_000_th_56:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
  using glib_000_lm_7 sorry

mtheorem glib_000_th_57:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> iff ( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(x,v,G))"
proof-
  have " for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds (e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> implies ( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(x,v,G))) & (( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(x,v,G)) implies e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> implies ( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(x,v,G))"
    proof(rule impI)
      let ?x = "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e"
      assume A1: "e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
      show " ex x be setHIDDENM2 st e DJoinsGLIB-000R2(x,v,G)"
      proof(rule bexI[of _ "x"])
        have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
          using A1 glib_000_lm_7 sorry
        thus "e DJoinsGLIB-000R2(x,v,G)"
          using A1 sorry
      qed "sorry"
    qed
    assume Given: " ex x be setHIDDENM2 st e DJoinsGLIB-000R2(x,v,G)"
    then obtain x where
      [ty]:"x be setHIDDENM2" and 
      A2: "e DJoinsGLIB-000R2(x,v,G)"
       sorry
    have "e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using A2 sorry
    thus "e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
      using glib_000_lm_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_58:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
  using glib_000_lm_8 sorry

mtheorem glib_000_th_59:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> iff ( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(v,x,G))"
proof-
  have " for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds (e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> implies ( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(v,x,G))) & (( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(v,x,G)) implies e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> implies ( ex x be setHIDDENM2 st e DJoinsGLIB-000R2(v,x,G))"
    proof(rule impI)
      let ?x = "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
      assume A1: "e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
      show " ex x be setHIDDENM2 st e DJoinsGLIB-000R2(v,x,G)"
      proof(rule bexI[of _ "x"])
        have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
          using A1 glib_000_lm_8 sorry
        thus "e DJoinsGLIB-000R2(v,x,G)"
          using A1 sorry
      qed "sorry"
    qed
    assume Given: " ex x be setHIDDENM2 st e DJoinsGLIB-000R2(v,x,G)"
    then obtain x where
      [ty]:"x be setHIDDENM2" and 
      A2: "e DJoinsGLIB-000R2(v,x,G)"
       sorry
    have "e inTARSKIR2 the-Edges-ofGLIB-000K7 G & (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using A2 sorry
    thus "e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
      using glib_000_lm_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_60:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> =XBOOLE-0R4 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
   sorry

mtheorem glib_000_th_61:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> iff e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v)"
proof-
  have " for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds (e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> implies e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v)) & (e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v) implies e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> implies e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v)"
    proof(rule impI,rule conjMI)
      assume A1: "e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
      thus "e inTARSKIR2 the-Edges-ofGLIB-000K7 G"
         sorry
      have "e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> or e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
        using A1 xboole_0_def_3 sorry
      thus "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
        using glib_000_lm_7 glib_000_lm_8 sorry
    qed
    assume "e inTARSKIR2 the-Edges-ofGLIB-000K7 G & ((the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v)"
    then have "e inTARSKIR2 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> or e inTARSKIR2 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
      using glib_000_lm_7 glib_000_lm_8 sorry
    thus "e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
      using xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_62:
" for G be -GraphGLIB-000M2 holds  for v1 be VertexGLIB-000M10-of G holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds e JoinsGLIB-000R1(v1,x,G) implies e inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
  using glib_000_th_61 sorry

mtheorem glib_000_th_63:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G holds  for v2 be VertexGLIB-000M10-of G holds e JoinsGLIB-000R1(v1,v2,G) implies e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> or e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
proof-
  have " for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G holds  for v2 be VertexGLIB-000M10-of G holds e JoinsGLIB-000R1(v1,v2,G) implies  not ( not (e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) &  not (e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G"
    assume A1: "e JoinsGLIB-000R1(v1,v2,G)"
    then have A2: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G"
       sorry
    have " not ( not (e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) &  not (e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>))"
    proof-
      show " not ( not (e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) &  not (e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>))"
      proof-
        have cases: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v2 or (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v2 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1"
          using A1 sorry
        have case1: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v2 implies  not ( not (e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) &  not (e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>))"
        proof(rule impI)
          assume "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v2"
          thus " not ( not (e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) &  not (e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>))"
            using A2 glib_000_lm_7 glib_000_lm_8 sorry
        qed
        have case2: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v2 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1 implies  not ( not (e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) &  not (e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>))"
        proof(rule impI)
          assume "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v2 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1"
          thus " not ( not (e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) &  not (e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>))"
            using A2 glib_000_lm_7 glib_000_lm_8 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not (e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>) &  not (e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_64:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G holds e inTARSKIR2 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> iff ( ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G))"
proof-
  have " for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G holds (e inTARSKIR2 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> implies ( ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G))) & (( ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G)) implies e inTARSKIR2 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G"
    show "e inTARSKIR2 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> implies ( ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G))"
    proof(rule impI)
      assume A1: "e inTARSKIR2 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
      have " ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G)"
      proof-
        show " ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G)"
        proof-
          have cases: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1 or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1"
            using A1 glib_000_th_61 sorry
          have case1: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1 implies ( ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G))"
          proof(rule impI)
            assume A2: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1"
            let ?v2 = "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
            obtain v2 where 
              [ty]:"v2 be VertexGLIB-000M10-of G" and v2Def:"v2 = ?v2"
              using A1 funct_2_th_5 sorry
            show " ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G)"
            proof(rule bexI[of _ "v2"])
              show "e JoinsGLIB-000R1(v1,v2,G)"
                using A1 A2 sorry
            qed "sorry"
          qed
          have case2: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1 implies ( ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G))"
          proof(rule impI)
            assume A3: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1"
            let ?v2 = "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e"
            obtain v2 where 
              [ty]:"v2 be VertexGLIB-000M10-of G" and v2Def:"v2 = ?v2"
              using A1 funct_2_th_5 sorry
            show " ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G)"
            proof(rule bexI[of _ "v2"])
              show "e JoinsGLIB-000R1(v1,v2,G)"
                using A1 A3 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G)"
         sorry
    qed
    assume Given: " ex v2 be VertexGLIB-000M10-of G st e JoinsGLIB-000R1(v1,v2,G)"
    then obtain v2 where
      [ty]:"v2 be VertexGLIB-000M10-of G" and 
      A4: "e JoinsGLIB-000R1(v1,v2,G)"
       sorry
    show "e inTARSKIR2 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
      using A4 glib_000_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_65:
" for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e inHIDDENR3 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> & e JoinsGLIB-000R1(x,y,G) implies v =HIDDENR1 x or v =HIDDENR1 y"
proof-
  have " for G be -GraphGLIB-000M2 holds  for v be VertexGLIB-000M10-of G holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds e inHIDDENR3 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> & e JoinsGLIB-000R1(x,y,G) implies  not ( not v =HIDDENR1 x &  not v =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    fix e assume [ty]: "e be objectHIDDENM1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "e inHIDDENR3 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
      and A2: "e JoinsGLIB-000R1(x,y,G)"
    have "v <>HIDDENR2 x implies v =HIDDENR1 y"
    proof(rule impI)
      assume A3: "v <>HIDDENR2 x"
      have "v =HIDDENR1 y"
      proof-
        show "v =HIDDENR1 y"
        proof-
          have cases: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
            using A1 glib_000_th_61 sorry
          have case1: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v implies v =HIDDENR1 y"
          proof(rule impI)
            assume "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
            thus "v =HIDDENR1 y"
              using A2 A3 sorry
          qed
          have case2: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v implies v =HIDDENR1 y"
          proof(rule impI)
            assume "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
            thus "v =HIDDENR1 y"
              using A2 A3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "v =HIDDENR1 y"
         sorry
    qed
    thus " not ( not v =HIDDENR1 x &  not v =HIDDENR1 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_66:
" for G be -GraphGLIB-000M2 holds  for v1 be VertexGLIB-000M10-of G holds  for v2 be VertexGLIB-000M10-of G holds  for e be objectHIDDENM1 holds e JoinsGLIB-000R1(v1,v2,G) implies v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2 & v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
proof-
  have " for G be -GraphGLIB-000M2 holds  for v1 be VertexGLIB-000M10-of G holds  for v2 be VertexGLIB-000M10-of G holds  for e be objectHIDDENM1 holds e JoinsGLIB-000R1(v1,v2,G) implies v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2 & v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G"
    fix e assume [ty]: "e be objectHIDDENM1"
    assume A1: "e JoinsGLIB-000R1(v1,v2,G)"
    then have A2: "e inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
      using glib_000_th_62 sorry
    have "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2 & v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
    proof-
      show "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2 & v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
      proof-
        have cases: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v2 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1 or (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v2"
          using A1 sorry
        have case1: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v2 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1 implies v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2 & v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
        proof(rule impI,rule conjMI)
          assume A3: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v2 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v1"
          thus "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2"
            using A2 glib_000_def_41 sorry
          have "v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
          proof-
            show "v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
            proof-
              have cases: "v1 =XBOOLE-0R4 v2 or v1 <>HIDDENR2 v2"
                 sorry
              have case1: "v1 =XBOOLE-0R4 v2 implies v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
              proof(rule impI)
                assume "v1 =XBOOLE-0R4 v2"
                thus "v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
                  using A2 A3 glib_000_def_41 sorry
              qed
              have case2: "v1 <>HIDDENR2 v2 implies v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
              proof(rule impI)
                assume "v1 <>HIDDENR2 v2"
                thus "v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
                  using A2 A3 glib_000_def_41 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
             sorry
        qed
        have case2: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v2 implies v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2 & v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
        proof(rule impI,rule conjMI)
          assume A4: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v2"
          have "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2"
          proof-
            show "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2"
            proof-
              have cases: "v1 =XBOOLE-0R4 v2 or v1 <>HIDDENR2 v2"
                 sorry
              have case1: "v1 =XBOOLE-0R4 v2 implies v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2"
              proof(rule impI)
                assume "v1 =XBOOLE-0R4 v2"
                thus "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2"
                  using A2 A4 glib_000_def_41 sorry
              qed
              have case2: "v1 <>HIDDENR2 v2 implies v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2"
              proof(rule impI)
                assume "v1 <>HIDDENR2 v2"
                thus "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2"
                  using A2 A4 glib_000_def_41 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2"
             sorry
          show "v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
            using A2 A4 glib_000_def_41 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "v1 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v2 & v2 .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 v1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_67:
" for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> iff e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
proof-
  have " for G be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds (e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> implies e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)) & (e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G) implies e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub> implies e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
    proof(rule impI)
      assume A1: "e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
      then have A2: "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
        using glib_000_th_61 sorry
      have "e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
      proof-
        show "e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
        proof-
          have cases: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v or (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e <>HIDDENR2 v"
             sorry
          have case1: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v implies e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
          proof(rule impI)
            assume A3: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
            then have "v .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e"
              using A1 glib_000_def_41 sorry
            thus "e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
              using A1 A3 sorry
          qed
          have case2: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e <>HIDDENR2 v implies e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
          proof(rule impI)
            assume A4: "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e <>HIDDENR2 v"
            then have "v .adjGLIB-000K29\<^bsub>(G)\<^esub> e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
              using A1 A2 glib_000_def_41 sorry
            thus "e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
              using A1 A2 A4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
         sorry
    qed
    assume "e JoinsGLIB-000R1(v,v .adjGLIB-000K29\<^bsub>(G)\<^esub> e,G)"
    thus "e inTARSKIR2 v .edgesInOut()GLIB-000K28\<^bsub>(G)\<^esub>"
      using glib_000_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_68:
" for G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G holds  for v2 be VertexGLIB-000M10-of G holds e JoinsGLIB-000R1(v1,v2,G) implies \<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub> & \<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix G assume [ty]: "G be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
  fix e assume [ty]: "e be setHIDDENM2"
  fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G"
  fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G"
  assume A1: "e JoinsGLIB-000R1(v1,v2,G)"
  have "\<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub> & \<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
  proof-
    show "\<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub> & \<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
    proof-
      have cases: "e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> or e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
        using A1 glib_000_th_63 sorry
      have case1: "e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> implies \<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub> & \<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
      proof(rule impI,rule conjMI)
        assume A2: "e inTARSKIR2 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
        then have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 e} implies x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
          using tarski_def_1 sorry
        then have "{TARSKIK1 e} c=TARSKIR1 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
           sorry
        then have "cardCARD-1K4 {TARSKIK1 e} <=XXREAL-0R1 cardCARD-1K4 v1 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
          using nat_1_th_43 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 v1 .inDegree()GLIB-000K32\<^bsub>(G)\<^esub>"
          using card_1_th_30 sorry
        thus "\<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
          using nat_1_th_12 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 e} implies x inHIDDENR3 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
          using A2 tarski_def_1 sorry
        then have "{TARSKIK1 e} c=TARSKIR1 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
           sorry
        then have "cardCARD-1K4 {TARSKIK1 e} <=XXREAL-0R1 cardCARD-1K4 v2 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
          using nat_1_th_43 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 v2 .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
          using card_1_th_30 sorry
        thus "\<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
          using nat_1_th_12 sorry
      qed
      have case2: "e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub> implies \<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub> & \<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
      proof(rule impI,rule conjMI)
        assume A3: "e inTARSKIR2 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub> & e inTARSKIR2 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
        then have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 e} implies x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
          using tarski_def_1 sorry
        then have "{TARSKIK1 e} c=TARSKIR1 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
           sorry
        then have "cardCARD-1K4 {TARSKIK1 e} <=XXREAL-0R1 cardCARD-1K4 v1 .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
          using nat_1_th_43 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 v1 .outDegree()GLIB-000K33\<^bsub>(G)\<^esub>"
          using card_1_th_30 sorry
        thus "\<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
          using nat_1_th_12 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 e} implies x inHIDDENR3 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
          using A3 tarski_def_1 sorry
        then have "{TARSKIK1 e} c=TARSKIR1 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
           sorry
        then have "cardCARD-1K4 {TARSKIK1 e} <=XXREAL-0R1 cardCARD-1K4 v2 .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
          using nat_1_th_43 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 v2 .inDegree()GLIB-000K32\<^bsub>(G)\<^esub>"
          using card_1_th_30 sorry
        thus "\<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
          using nat_1_th_12 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "\<one>\<^sub>M <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G)\<^esub> & \<one>\<^sub>M <=XXREAL-0R1 v2 .degree()GLIB-000K35\<^bsub>(G)\<^esub>"
     sorry
qed "sorry"

mtheorem glib_000_th_69:
" for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> iff ( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(x,v,G))"
proof-
  have " for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds (x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> implies ( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(x,v,G))) & (( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(x,v,G)) implies x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> implies ( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(x,v,G))"
    proof(rule impI)
      assume "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub>"
      then obtain e where
        [ty]:"e be objectHIDDENM1" and 
        A1: "e inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Source-ofGLIB-000K10 G)"and A2: "e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"and A3: "x =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e"
        using funct_1_def_6 sorry
      show " ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(x,v,G)"
      proof(rule bexI[of _ "e"])
        have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
          using A2 glib_000_lm_7 sorry
        thus "e DJoinsGLIB-000R2(x,v,G)"
          using A1 A3 sorry
      qed "sorry"
    qed
    assume Given: " ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(x,v,G)"
    then obtain e where
      [ty]:"e be objectHIDDENM1" and 
      A4: "e DJoinsGLIB-000R2(x,v,G)"
       sorry
    have A5: "e inHIDDENR3 the-Edges-ofGLIB-000K7 G"
      using A4 sorry
    then have A6: "e inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Source-ofGLIB-000K10 G)"
      using funct_2_def_1 sorry
    have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using A4 sorry
    then have A7: "e inHIDDENR3 v .edgesIn()GLIB-000K26\<^bsub>(G)\<^esub>"
      using A5 glib_000_lm_7 sorry
    have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 x"
      using A4 sorry
    thus "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub>"
      using A7 A6 funct_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_70:
" for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> iff ( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(v,x,G))"
proof-
  have " for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds (x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> implies ( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(v,x,G))) & (( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(v,x,G)) implies x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> implies ( ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(v,x,G))"
    proof(rule impI)
      assume "x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
      then obtain e where
        [ty]:"e be objectHIDDENM1" and 
        A1: "e inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Target-ofGLIB-000K11 G)"and A2: "e inHIDDENR3 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"and A3: "x =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
        using funct_1_def_6 sorry
      show " ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(v,x,G)"
      proof(rule bexI[of _ "e"])
        have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
          using A2 glib_000_lm_8 sorry
        thus "e DJoinsGLIB-000R2(v,x,G)"
          using A1 A3 sorry
      qed "sorry"
    qed
    assume Given: " ex e be objectHIDDENM1 st e DJoinsGLIB-000R2(v,x,G)"
    then obtain e where
      [ty]:"e be objectHIDDENM1" and 
      A4: "e DJoinsGLIB-000R2(v,x,G)"
       sorry
    have A5: "e inHIDDENR3 the-Edges-ofGLIB-000K7 G"
      using A4 sorry
    then have A6: "e inHIDDENR3 domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G)\<^esub> (the-Target-ofGLIB-000K11 G)"
      using funct_2_def_1 sorry
    have "(the-Source-ofGLIB-000K10 G).FUNCT-1K1 e =XBOOLE-0R4 v"
      using A4 sorry
    then have A7: "e inHIDDENR3 v .edgesOut()GLIB-000K27\<^bsub>(G)\<^esub>"
      using A5 glib_000_lm_8 sorry
    have "(the-Target-ofGLIB-000K11 G).FUNCT-1K1 e =XBOOLE-0R4 x"
      using A4 sorry
    thus "x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
      using A7 A6 funct_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_71:
" for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds x inTARSKIR2 v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub> iff ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G))"
proof-
  have " for G be -GraphGLIB-000M2 holds  for x be setHIDDENM2 holds  for v be VertexGLIB-000M10-of G holds (x inTARSKIR2 v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub> implies ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G))) & (( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G)) implies x inTARSKIR2 v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix v assume [ty]: "v be VertexGLIB-000M10-of G"
    show "x inTARSKIR2 v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub> implies ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G))"
    proof(rule impI)
      assume A1: "x inTARSKIR2 v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub>"
      have " ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G)"
      proof-
        show " ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G)"
        proof-
          have cases: "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> or x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
            using A1 xboole_0_def_3 sorry
          have case1: "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> implies ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G))"
          proof(rule impI)
            assume "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub>"
            then obtain e where
              [ty]:"e be objectHIDDENM1" and 
              A2: "e DJoinsGLIB-000R2(x,v,G)"
              using glib_000_th_69 sorry
            show " ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G)"
            proof(rule bexI[of _ "e"])
              show "e JoinsGLIB-000R1(v,x,G)"
                using A2 sorry
            qed "sorry"
          qed
          have case2: "x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub> implies ( ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G))"
          proof(rule impI)
            assume "x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
            then obtain e where
              [ty]:"e be objectHIDDENM1" and 
              A3: "e DJoinsGLIB-000R2(v,x,G)"
              using glib_000_th_70 sorry
            show " ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G)"
            proof(rule bexI[of _ "e"])
              show "e JoinsGLIB-000R1(v,x,G)"
                using A3 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G)"
         sorry
    qed
    assume Given: " ex e be objectHIDDENM1 st e JoinsGLIB-000R1(v,x,G)"
    then obtain e where
      [ty]:"e be objectHIDDENM1" and 
      A4: "e JoinsGLIB-000R1(v,x,G)"
       sorry
    have "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
    proof-
      show "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
      proof-
        have cases: "e DJoinsGLIB-000R2(x,v,G) or e DJoinsGLIB-000R2(v,x,G)"
          using A4 sorry
        have case1: "e DJoinsGLIB-000R2(x,v,G) implies x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
        proof(rule impI)
          assume "e DJoinsGLIB-000R2(x,v,G)"
          then have "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub>"
            using glib_000_th_69 sorry
          thus "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
            using xboole_0_def_3 sorry
        qed
        have case2: "e DJoinsGLIB-000R2(v,x,G) implies x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
        proof(rule impI)
          assume "e DJoinsGLIB-000R2(v,x,G)"
          then have "x inTARSKIR2 v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
            using glib_000_th_70 sorry
          thus "x inTARSKIR2 v .inNeighbors()GLIB-000K36\<^bsub>(G)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Vertices-ofGLIB-000K6 G)\<^esub> v .outNeighbors()GLIB-000K37\<^bsub>(G)\<^esub>"
            using xboole_0_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "x inTARSKIR2 v .allNeighbors()GLIB-000K38\<^bsub>(G)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_72:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for e be objectHIDDENM1 holds (((e JoinsGLIB-000R1(x,y,G2) implies e JoinsGLIB-000R1(x,y,G1)) & (e DJoinsGLIB-000R2(x,y,G2) implies e DJoinsGLIB-000R2(x,y,G1))) & (e SJoinsGLIB-000R3(x,y,G2) implies e SJoinsGLIB-000R3(x,y,G1))) & (e DSJoinsGLIB-000R4(x,y,G2) implies e DSJoinsGLIB-000R4(x,y,G1))"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for e be objectHIDDENM1 holds (e JoinsGLIB-000R1(x,y,G2) implies e JoinsGLIB-000R1(x,y,G1)) & ((e DJoinsGLIB-000R2(x,y,G2) implies e DJoinsGLIB-000R2(x,y,G1)) & ((e SJoinsGLIB-000R3(x,y,G2) implies e SJoinsGLIB-000R3(x,y,G1)) & (e DSJoinsGLIB-000R4(x,y,G2) implies e DSJoinsGLIB-000R4(x,y,G1))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix e assume [ty]: "e be objectHIDDENM1"
    show "e JoinsGLIB-000R1(x,y,G2) implies e JoinsGLIB-000R1(x,y,G1)"
      using glib_000_lm_4 sorry
    show "e DJoinsGLIB-000R2(x,y,G2) implies e DJoinsGLIB-000R2(x,y,G1)"
    proof(rule impI)
      assume A1: "e DJoinsGLIB-000R2(x,y,G2)"
      then have A2: "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
         sorry
      have "(the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 y"
        using A1 sorry
      then have A3: "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 y"
        using A2 glib_000_def_32 sorry
      have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 x"
        using A1 sorry
      then have "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 x"
        using A2 glib_000_def_32 sorry
      thus "e DJoinsGLIB-000R2(x,y,G1)"
        using A2 A3 sorry
    qed
    show "e SJoinsGLIB-000R3(x,y,G2) implies e SJoinsGLIB-000R3(x,y,G1)"
    proof(rule impI)
      assume A4: "e SJoinsGLIB-000R3(x,y,G2)"
      then have A5: "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e inTARSKIR2 x & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e inTARSKIR2 y or (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e inTARSKIR2 y & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e inTARSKIR2 x"
         sorry
      have A6: "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
        using A4 sorry
      then have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
        using glib_000_def_32 sorry
      thus "e SJoinsGLIB-000R3(x,y,G1)"
        using A6 A5 sorry
    qed
    assume A7: "e DSJoinsGLIB-000R4(x,y,G2)"
    then have A8: "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e inTARSKIR2 x & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e inTARSKIR2 y"
       sorry
    have A9: "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
      using A7 sorry
    then have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
      using glib_000_def_32 sorry
    thus "e DSJoinsGLIB-000R4(x,y,G1)"
      using A9 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_73:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 implies (((e JoinsGLIB-000R1(x,y,G1) implies e JoinsGLIB-000R1(x,y,G2)) & (e DJoinsGLIB-000R2(x,y,G1) implies e DJoinsGLIB-000R2(x,y,G2))) & (e SJoinsGLIB-000R3(x,y,G1) implies e SJoinsGLIB-000R3(x,y,G2))) & (e DSJoinsGLIB-000R4(x,y,G1) implies e DSJoinsGLIB-000R4(x,y,G2))"
  using glib_000_def_32 sorry

mtheorem glib_000_th_74:
" for G1 be -GraphGLIB-000M2 holds  for G2 be spanningGLIB-000V9\<^bsub>(G1)\<^esub>\<bar>SubgraphGLIB-000M3-of G1 holds  for G3 be spanningGLIB-000V9\<^bsub>(G2)\<^esub>\<bar>SubgraphGLIB-000M3-of G2 holds G3 be spanningGLIB-000V9\<^bsub>(G1)\<^esub>\<bar>SubgraphGLIB-000M3-of G1"
proof(rule ballI,rule ballI,rule ballI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be spanningGLIB-000V9\<^bsub>(G1)\<^esub>\<bar>SubgraphGLIB-000M3-of G1"
  fix G3 assume [ty]: "G3 be spanningGLIB-000V9\<^bsub>(G2)\<^esub>\<bar>SubgraphGLIB-000M3-of G2"
  have "the-Vertices-ofGLIB-000K24\<^bsub>(G2)\<^esub> G3 =HIDDENR1 the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2"
    using glib_000_def_33 sorry
  also have "... = the-Vertices-ofGLIB-000K6 G1"
    using glib_000_def_33 sorry
  finally have "the-Vertices-ofGLIB-000K24\<^bsub>(G2)\<^esub> G3 =HIDDENR1 the-Vertices-ofGLIB-000K6 G1"
     sorry
  thus "G3 be spanningGLIB-000V9\<^bsub>(G1)\<^esub>\<bar>SubgraphGLIB-000M3-of G1"
    using glib_000_def_33 glib_000_th_43 sorry
qed "sorry"

mtheorem glib_000_th_75:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds G2 .order()GLIB-000K15 <=XXREAL-0R1 G1 .order()GLIB-000K15 & G2 .size()GLIB-000K17 <=XXREAL-0R1 G1 .size()GLIB-000K17"
proof(rule ballI,rule ballI,rule conjMI)
  fix G1 assume [ty]: "G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
  have "cardCARD-1K4 (the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2) <=XXREAL-0R1 cardCARD-1K4 (the-Vertices-ofGLIB-000K6 G1)"
    using nat_1_th_43 sorry
  thus "G2 .order()GLIB-000K15 <=XXREAL-0R1 G1 .order()GLIB-000K15"
     sorry
  have "cardCARD-1K4 (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) <=XXREAL-0R1 cardCARD-1K4 (the-Edges-ofGLIB-000K7 G1)"
    using nat_1_th_43 sorry
  thus "G2 .size()GLIB-000K17 <=XXREAL-0R1 G1 .size()GLIB-000K17"
     sorry
qed "sorry"

mtheorem glib_000_th_76:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for X be setHIDDENM2 holds ((G2 .edgesIntoGLIB-000K18 X c=TARSKIR1 G1 .edgesIntoGLIB-000K18 X & G2 .edgesOutOfGLIB-000K19 X c=TARSKIR1 G1 .edgesOutOfGLIB-000K19 X) & G2 .edgesInOutGLIB-000K20 X c=TARSKIR1 G1 .edgesInOutGLIB-000K20 X) & G2 .edgesBetweenGLIB-000K21 X c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 X"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for X be setHIDDENM2 holds G2 .edgesIntoGLIB-000K18 X c=TARSKIR1 G1 .edgesIntoGLIB-000K18 X & (G2 .edgesOutOfGLIB-000K19 X c=TARSKIR1 G1 .edgesOutOfGLIB-000K19 X & (G2 .edgesInOutGLIB-000K20 X c=TARSKIR1 G1 .edgesInOutGLIB-000K20 X & G2 .edgesBetweenGLIB-000K21 X c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 X))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
    fix X assume [ty]: "X be setHIDDENM2"
    have " for e be objectHIDDENM1 holds e inHIDDENR3 G2 .edgesIntoGLIB-000K18 X implies e inHIDDENR3 G1 .edgesIntoGLIB-000K18 X"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume A1: "e inHIDDENR3 G2 .edgesIntoGLIB-000K18 X"
      then have A2: "(the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
        using glib_000_def_32 sorry
      have "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e inTARSKIR2 X"
        using A1 glib_000_def_26 sorry
      thus "e inHIDDENR3 G1 .edgesIntoGLIB-000K18 X"
        using A2 glib_000_def_26 sorry
    qed "sorry"
    thus A3: "G2 .edgesIntoGLIB-000K18 X c=TARSKIR1 G1 .edgesIntoGLIB-000K18 X"
       sorry
    then have A4: "G2 .edgesIntoGLIB-000K18 X c=TARSKIR1 G1 .edgesInOutGLIB-000K20 X"
      using xboole_1_th_10 sorry
    have " for e be objectHIDDENM1 holds e inHIDDENR3 G2 .edgesOutOfGLIB-000K19 X implies e inHIDDENR3 G1 .edgesOutOfGLIB-000K19 X"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume A5: "e inHIDDENR3 G2 .edgesOutOfGLIB-000K19 X"
      then have A6: "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e"
        using glib_000_def_32 sorry
      have "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 & (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e inTARSKIR2 X"
        using A5 glib_000_def_27 sorry
      thus "e inHIDDENR3 G1 .edgesOutOfGLIB-000K19 X"
        using A6 glib_000_def_27 sorry
    qed "sorry"
    thus A7: "G2 .edgesOutOfGLIB-000K19 X c=TARSKIR1 G1 .edgesOutOfGLIB-000K19 X"
       sorry
    then have "G2 .edgesOutOfGLIB-000K19 X c=TARSKIR1 G1 .edgesInOutGLIB-000K20 X"
      using xboole_1_th_10 sorry
    thus "G2 .edgesInOutGLIB-000K20 X c=TARSKIR1 G1 .edgesInOutGLIB-000K20 X"
      using A4 xboole_1_th_8 sorry
    show "G2 .edgesBetweenGLIB-000K21 X c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 X"
      using A3 A7 xboole_1_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_77:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds G2 .edgesBetweenGLIB-000K22(X,Y) c=TARSKIR1 G1 .edgesBetweenGLIB-000K22(X,Y) & G2 .edgesDBetweenGLIB-000K23(X,Y) c=TARSKIR1 G1 .edgesDBetweenGLIB-000K23(X,Y)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 G2 .edgesBetweenGLIB-000K22(X,Y) implies x inHIDDENR3 G1 .edgesBetweenGLIB-000K22(X,Y)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 G2 .edgesBetweenGLIB-000K22(X,Y)"
    then have "x SJoinsGLIB-000R3(X,Y,G2)"
      using glib_000_def_30 sorry
    then have "x SJoinsGLIB-000R3(X,Y,G1)"
      using glib_000_th_72 sorry
    thus "x inHIDDENR3 G1 .edgesBetweenGLIB-000K22(X,Y)"
      using glib_000_def_30 sorry
  qed "sorry"
  thus "G2 .edgesBetweenGLIB-000K22(X,Y) c=TARSKIR1 G1 .edgesBetweenGLIB-000K22(X,Y)"
     sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 G2 .edgesDBetweenGLIB-000K23(X,Y) implies x inHIDDENR3 G1 .edgesDBetweenGLIB-000K23(X,Y)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 G2 .edgesDBetweenGLIB-000K23(X,Y)"
    then have "x DSJoinsGLIB-000R4(X,Y,G2)"
      using glib_000_def_31 sorry
    then have "x DSJoinsGLIB-000R4(X,Y,G1)"
      using glib_000_th_72 sorry
    thus "x inHIDDENR3 G1 .edgesDBetweenGLIB-000K23(X,Y)"
      using glib_000_def_31 sorry
  qed "sorry"
  thus "G2 .edgesDBetweenGLIB-000K23(X,Y) c=TARSKIR1 G1 .edgesDBetweenGLIB-000K23(X,Y)"
     sorry
qed "sorry"

mtheorem glib_000_th_78:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies (v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> & v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>) & v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> & (v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> & v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
    assume A1: "v1 =XBOOLE-0R4 v2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> implies x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub>"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub>"
      then have "(the-Target-ofGLIB-000K11 G2).FUNCT-1K1 x =XBOOLE-0R4 v2"
        using glib_000_lm_7 sorry
      then have A3: "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 x =XBOOLE-0R4 v1"
        using A1 A2 glib_000_def_32 sorry
      have "x inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
        using A2 sorry
      thus "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub>"
        using A3 glib_000_lm_7 sorry
    qed "sorry"
    thus "v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub>"
       sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> implies x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub>"
      then have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 x =XBOOLE-0R4 v2"
        using glib_000_lm_8 sorry
      then have A5: "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 x =XBOOLE-0R4 v1"
        using A1 A4 glib_000_def_32 sorry
      have "x inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
        using A4 sorry
      thus "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
        using A5 glib_000_lm_8 sorry
    qed "sorry"
    thus "v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
       sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> implies x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
      then have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 x =XBOOLE-0R4 v2 or (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 x =XBOOLE-0R4 v2"
        using glib_000_th_61 sorry
      then have A7: "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 x =XBOOLE-0R4 v1 or (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 x =XBOOLE-0R4 v1"
        using A1 A6 glib_000_def_32 sorry
      have "x inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
        using A6 sorry
      thus "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
        using A7 glib_000_th_61 sorry
    qed "sorry"
    thus "v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_79:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies (v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) & v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)) & v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) & (v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) & v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
    assume A1: "v1 =XBOOLE-0R4 v2"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> implies x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)) & (x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) implies x inHIDDENR3 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub>)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> implies x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      proof(rule impI)
        assume A2: "x inHIDDENR3 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub>"
        have "v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub>"
          using A1 glib_000_th_78 sorry
        thus "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
          using A2 xboole_0_def_4 sorry
      qed
      assume A3: "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      then have A4: "x inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
        using xboole_0_def_4 sorry
      have "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub>"
        using A3 xboole_0_def_4 sorry
      then have "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 x =XBOOLE-0R4 v1"
        using glib_000_lm_7 sorry
      then have "(the-Target-ofGLIB-000K11 G2).FUNCT-1K1 x =XBOOLE-0R4 v2"
        using A1 A4 glib_000_def_32 sorry
      thus "x inHIDDENR3 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub>"
        using A4 glib_000_lm_7 sorry
    qed "sorry"
    thus A5: "v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      using tarski_th_2 sorry
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> implies x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)) & (x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) implies x inHIDDENR3 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub>)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> implies x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      proof(rule impI)
        assume A6: "x inHIDDENR3 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub>"
        have "v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
          using A1 glib_000_th_78 sorry
        thus "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
          using A6 xboole_0_def_4 sorry
      qed
      assume A7: "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      then have A8: "x inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
        using xboole_0_def_4 sorry
      have "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
        using A7 xboole_0_def_4 sorry
      then have "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 x =XBOOLE-0R4 v1"
        using glib_000_lm_8 sorry
      then have "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 x =XBOOLE-0R4 v2"
        using A1 A8 glib_000_def_32 sorry
      thus "x inHIDDENR3 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub>"
        using A8 glib_000_lm_8 sorry
    qed "sorry"
    thus A9: "v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      using tarski_th_2 sorry
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) implies x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>) & (x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> implies x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) implies x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
      proof(rule impI)
        assume A10: "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
        then have A11: "x inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
          using xboole_0_def_4 sorry
        have A12: "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
          using A10 xboole_0_def_4 sorry
        have "x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
        proof-
          show "x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
          proof-
            have cases: "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> or x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
              using A12 xboole_0_def_3 sorry
            have case1: "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> implies x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
            proof(rule impI)
              assume "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub>"
              then have "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
                using A11 xboole_0_def_4 sorry
              thus "x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
                using A5 xboole_0_def_3 sorry
            qed
            have case2: "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> implies x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
            proof(rule impI)
              assume "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
              then have "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
                using A11 xboole_0_def_4 sorry
              thus "x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
                using A9 xboole_0_def_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
           sorry
      qed
      assume A13: "x inHIDDENR3 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
      have "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      proof-
        show "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
        proof-
          have cases: "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) or x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
            using A5 A9 A13 xboole_0_def_3 sorry
          have case1: "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) implies x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
          proof(rule impI)
            assume A14: "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
            then have "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub>"
              using xboole_0_def_4 sorry
            then have A15: "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
              using xboole_0_def_3 sorry
            have "x inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
              using A14 xboole_0_def_4 sorry
            thus "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
              using A15 xboole_0_def_4 sorry
          qed
          have case2: "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2) implies x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
          proof(rule impI)
            assume A16: "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
            then have "x inHIDDENR3 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
              using xboole_0_def_4 sorry
            then have A17: "x inHIDDENR3 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> \\/SUBSET-1K4\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
              using xboole_0_def_3 sorry
            have "x inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
              using A16 xboole_0_def_4 sorry
            thus "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
              using A17 xboole_0_def_4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "x inHIDDENR3 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
         sorry
    qed "sorry"
    thus "v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_80:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds  for e be setHIDDENM2 holds v1 =XBOOLE-0R4 v2 & e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 implies v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =XBOOLE-0R4 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
  fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
  fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
  fix e assume [ty]: "e be setHIDDENM2"
  assume A1: "v1 =XBOOLE-0R4 v2"
    and A2: "e inTARSKIR2 the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2"
  have A3: "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
    using A2 glib_000_def_32 sorry
  have "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
  proof-
    show "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
    proof-
      have cases: "((the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1 or (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e <>HIDDENR2 v1) or (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e <>HIDDENR2 v1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e <>HIDDENR2 v1"
         sorry
      have case1: "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1 implies v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
      proof(rule impI)
        assume A4: "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1"
        then have "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e"
          using A2 glib_000_def_41 sorry
        also have "... = v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
          using A1 A2 A3 A4 glib_000_def_41 sorry
        finally show "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
           sorry
      qed
      have case2: "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e <>HIDDENR2 v1 implies v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
      proof(rule impI)
        assume A5: "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e <>HIDDENR2 v1"
        then have "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
          using A2 glib_000_def_41 sorry
        also have "... = v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
          using A1 A2 A3 A5 glib_000_def_41 sorry
        finally show "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
           sorry
      qed
      have case3: "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e <>HIDDENR2 v1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e <>HIDDENR2 v1 implies v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
      proof(rule impI)
        assume A6: "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e <>HIDDENR2 v1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e <>HIDDENR2 v1"
        then have "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2"
          using A1 glib_000_def_41 sorry
        also have "... = v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
          using A1 A3 A6 glib_000_def_41 sorry
        finally show "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed
  thus "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =XBOOLE-0R4 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
     sorry
qed "sorry"

mtheorem glib_000_th_81:
" for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies (v2 .inDegree()GLIB-000K32\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .inDegree()GLIB-000K32\<^bsub>(G1)\<^esub> & v2 .outDegree()GLIB-000K33\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .outDegree()GLIB-000K33\<^bsub>(G1)\<^esub>) & v2 .degree()GLIB-000K35\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G1)\<^esub>"
proof-
  have " for G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies v2 .inDegree()GLIB-000K32\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .inDegree()GLIB-000K32\<^bsub>(G1)\<^esub> & (v2 .outDegree()GLIB-000K33\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .outDegree()GLIB-000K33\<^bsub>(G1)\<^esub> & v2 .degree()GLIB-000K35\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G1)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix G1 assume [ty]: "G1 be finiteFINSET-1V1\<bar>-GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
    assume A1: "v1 =XBOOLE-0R4 v2"
    then have "v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      using glib_000_th_79 sorry
    thus A2: "v2 .inDegree()GLIB-000K32\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .inDegree()GLIB-000K32\<^bsub>(G1)\<^esub>"
      using nat_1_th_43 xboole_1_th_17 sorry
    have A3: "v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> =XBOOLE-0R4 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> /\\SUBSET-1K9\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2)"
      using A1 glib_000_th_79 sorry
    thus "v2 .outDegree()GLIB-000K33\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .outDegree()GLIB-000K33\<^bsub>(G1)\<^esub>"
      using nat_1_th_43 xboole_1_th_17 sorry
    have "v2 .outDegree()GLIB-000K33\<^bsub>(G2)\<^esub> <=XXREAL-0R1 cardCARD-1K4 v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub>"
      using A3 nat_1_th_43 xboole_1_th_17 sorry
    thus "v2 .degree()GLIB-000K35\<^bsub>(G2)\<^esub> <=XXREAL-0R1 v1 .degree()GLIB-000K35\<^bsub>(G1)\<^esub>"
      using A2 xreal_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_82:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies (v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub> & v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub>) & v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub>"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 implies v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub> & (v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub> & v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
    assume A1: "v1 =XBOOLE-0R4 v2"
    have " for v be objectHIDDENM1 holds v inHIDDENR3 v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub> implies v inHIDDENR3 v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub>"
    proof(rule ballI,rule impI)
      fix v assume [ty]: "v be objectHIDDENM1"
      assume "v inHIDDENR3 v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub>"
      then obtain e where
        [ty]:"e be objectHIDDENM1" and 
        A2: "e DJoinsGLIB-000R2(v,v2,G2)"
        using glib_000_th_69 sorry
      have "e DJoinsGLIB-000R2(v,v1,G1)"
        using A1 A2 glib_000_th_72 sorry
      thus "v inHIDDENR3 v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub>"
        using glib_000_th_69 sorry
    qed "sorry"
    thus "v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub>"
       sorry
    have " for v be objectHIDDENM1 holds v inHIDDENR3 v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub> implies v inHIDDENR3 v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub>"
    proof(rule ballI,rule impI)
      fix v assume [ty]: "v be objectHIDDENM1"
      assume "v inHIDDENR3 v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub>"
      then obtain e where
        [ty]:"e be objectHIDDENM1" and 
        A3: "e DJoinsGLIB-000R2(v2,v,G2)"
        using glib_000_th_70 sorry
      have "e DJoinsGLIB-000R2(v1,v,G1)"
        using A1 A3 glib_000_th_72 sorry
      thus "v inHIDDENR3 v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub>"
        using glib_000_th_70 sorry
    qed "sorry"
    thus "v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub>"
       sorry
    have " for v be objectHIDDENM1 holds v inHIDDENR3 v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub> implies v inHIDDENR3 v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub>"
    proof(rule ballI,rule impI)
      fix v assume [ty]: "v be objectHIDDENM1"
      assume "v inHIDDENR3 v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub>"
      then obtain e where
        [ty]:"e be objectHIDDENM1" and 
        A4: "e JoinsGLIB-000R1(v2,v,G2)"
        using glib_000_th_71 sorry
      have "e JoinsGLIB-000R1(v1,v,G1)"
        using A1 A4 glib_000_lm_4 sorry
      thus "v inHIDDENR3 v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub>"
        using glib_000_th_71 sorry
    qed "sorry"
    thus "v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub>"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_83:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & v1 be isolatedGLIB-000V10\<^bsub>(G1)\<^esub> implies v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
  fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
  fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
  assume "v1 =XBOOLE-0R4 v2 & v1 be isolatedGLIB-000V10\<^bsub>(G1)\<^esub>"
  then have "v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1 & v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
    using glib_000_th_78 sorry
  thus "v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>"
     sorry
qed "sorry"

mtheorem glib_000_th_84:
" for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & v1 be endvertexGLIB-000V12\<^bsub>(G1)\<^esub> implies v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub> or v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be SubgraphGLIB-000M3-of G1 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & v1 be endvertexGLIB-000V12\<^bsub>(G1)\<^esub> implies  not ( not v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub> &  not v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G1"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
    assume A1: "v1 =XBOOLE-0R4 v2"
      and A2: "v1 be endvertexGLIB-000V12\<^bsub>(G1)\<^esub>"
    obtain e where
      [ty]:"e be objectHIDDENM1" and 
      A3: "v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"and A4: " not e JoinsGLIB-000R1(v1,v1,G1)"
      using A2 sorry
    have "v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> c=TARSKIR1 v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub>"
      using A1 glib_000_th_78 sorry
    then have A5: "v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1 or v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> =XBOOLE-0R4 {TARSKIK1 e}"
      using A3 zfmisc_1_th_33 sorry
    have " not v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub> implies v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub>"
      using A5 A1 A4 glib_000_lm_4 sorry
    thus " not ( not v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub> &  not v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_85:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for G3 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 & G2 ==GLIB-000R5 G3 implies G1 ==GLIB-000R5 G3"
   sorry

mtheorem glib_000_th_86:
" for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 implies G1 ==GLIB-000R5 G2"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix G assume [ty]: "G be -GraphGLIB-000M2"
  fix G1 assume [ty]: "G1 be SubgraphGLIB-000M3-of G"
  fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G"
  assume A1: "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2"
    and A2: "the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
  have A3: "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Target-ofGLIB-000K11 G1) =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 & domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Target-ofGLIB-000K11 G2) =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
    using funct_2_def_1 sorry
  have " for e be objectHIDDENM1 holds e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 implies (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    assume A4: "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1"
    then have "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G).FUNCT-1K1 e"
      using glib_000_def_32 sorry
    thus "(the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
      using A2 A4 glib_000_def_32 sorry
  qed "sorry"
  then have A5: "the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
    using A2 A3 funct_1_th_2 sorry
  have A6: " for e be objectHIDDENM1 holds e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 implies (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    assume A7: "e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1"
    then have "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G).FUNCT-1K1 e"
      using glib_000_def_32 sorry
    thus "(the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
      using A2 A7 glib_000_def_32 sorry
  qed "sorry"
  have "domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Source-ofGLIB-000K10 G1) =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 & domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G2)\<^esub> (the-Source-ofGLIB-000K10 G2) =XBOOLE-0R4 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
    using funct_2_def_1 sorry
  then have "the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2"
    using A2 A6 funct_1_th_2 sorry
  thus "G1 ==GLIB-000R5 G2"
    using A1 A2 A5 sorry
qed "sorry"

mtheorem glib_000_th_87:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 iff G1 be SubgraphGLIB-000M3-of G2 & G2 be SubgraphGLIB-000M3-of G1"
  using glib_000_th_41 sorry

mtheorem glib_000_th_88:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for e be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds G1 ==GLIB-000R5 G2 implies (((e JoinsGLIB-000R1(x,y,G1) implies e JoinsGLIB-000R1(x,y,G2)) & (e DJoinsGLIB-000R2(x,y,G1) implies e DJoinsGLIB-000R2(x,y,G2))) & (e SJoinsGLIB-000R3(X,Y,G1) implies e SJoinsGLIB-000R3(X,Y,G2))) & (e DSJoinsGLIB-000R4(X,Y,G1) implies e DSJoinsGLIB-000R4(X,Y,G2))"
   sorry

mtheorem glib_000_th_89:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 implies ((((((G1 be finiteGLIB-000V2 implies G2 be finiteGLIB-000V2) & (G1 be looplessGLIB-000V3 implies G2 be looplessGLIB-000V3)) & (G1 be trivialGLIB-000V4 implies G2 be trivialGLIB-000V4)) & (G1 be non-multiGLIB-000V5 implies G2 be non-multiGLIB-000V5)) & (G1 be non-DmultiGLIB-000V6 implies G2 be non-DmultiGLIB-000V6)) & (G1 be simpleGLIB-000V7 implies G2 be simpleGLIB-000V7)) & (G1 be DsimpleGLIB-000V8 implies G2 be DsimpleGLIB-000V8)"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 implies (G1 be finiteGLIB-000V2 implies G2 be finiteGLIB-000V2) & ((G1 be looplessGLIB-000V3 implies G2 be looplessGLIB-000V3) & ((G1 be trivialGLIB-000V4 implies G2 be trivialGLIB-000V4) & ((G1 be non-multiGLIB-000V5 implies G2 be non-multiGLIB-000V5) & ((G1 be non-DmultiGLIB-000V6 implies G2 be non-DmultiGLIB-000V6) & ((G1 be simpleGLIB-000V7 implies G2 be simpleGLIB-000V7) &  not (G1 be DsimpleGLIB-000V8 &  not G2 be DsimpleGLIB-000V8))))))"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be -GraphGLIB-000M2"
    assume A1: "G1 ==GLIB-000R5 G2"
    then have A2: "the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2"
       sorry
    have "the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2"
      using A1 sorry
    thus "G1 be finiteGLIB-000V2 implies G2 be finiteGLIB-000V2"
      using A2 sorry
    have A3: "the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2 & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
      using A1 sorry
    have A4: "G1 be looplessGLIB-000V3 implies G2 be looplessGLIB-000V3"
      using A2 A3 sorry
    thus "G1 be looplessGLIB-000V3 implies G2 be looplessGLIB-000V3"
       sorry
    show "G1 be trivialGLIB-000V4 implies G2 be trivialGLIB-000V4"
      using A1 sorry
    have A5: "G1 be non-multiGLIB-000V5 implies G2 be non-multiGLIB-000V5"
    proof(rule impI)
      assume A6: "G1 be non-multiGLIB-000V5"
      have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 JoinsGLIB-000R1(v1,v2,G2) & e2 JoinsGLIB-000R1(v1,v2,G2) implies e1 =HIDDENR1 e2"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
        fix e1 assume [ty]: "e1 be objectHIDDENM1"
        fix e2 assume [ty]: "e2 be objectHIDDENM1"
        fix v1 assume [ty]: "v1 be objectHIDDENM1"
        fix v2 assume [ty]: "v2 be objectHIDDENM1"
        assume "e1 JoinsGLIB-000R1(v1,v2,G2) & e2 JoinsGLIB-000R1(v1,v2,G2)"
        then have "e1 JoinsGLIB-000R1(v1,v2,G1) & e2 JoinsGLIB-000R1(v1,v2,G1)"
          using A1 sorry
        thus "e1 =HIDDENR1 e2"
          using A6 sorry
      qed "sorry"
      thus "G2 be non-multiGLIB-000V5"
         sorry
    qed
    thus "G1 be non-multiGLIB-000V5 implies G2 be non-multiGLIB-000V5"
       sorry
    have A7: "G1 be non-DmultiGLIB-000V6 implies G2 be non-DmultiGLIB-000V6"
    proof(rule impI)
      assume A8: "G1 be non-DmultiGLIB-000V6"
      have " for e1 be objectHIDDENM1 holds  for e2 be objectHIDDENM1 holds  for v1 be objectHIDDENM1 holds  for v2 be objectHIDDENM1 holds e1 DJoinsGLIB-000R2(v1,v2,G2) & e2 DJoinsGLIB-000R2(v1,v2,G2) implies e1 =HIDDENR1 e2"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
        fix e1 assume [ty]: "e1 be objectHIDDENM1"
        fix e2 assume [ty]: "e2 be objectHIDDENM1"
        fix v1 assume [ty]: "v1 be objectHIDDENM1"
        fix v2 assume [ty]: "v2 be objectHIDDENM1"
        assume "e1 DJoinsGLIB-000R2(v1,v2,G2) & e2 DJoinsGLIB-000R2(v1,v2,G2)"
        then have "e1 DJoinsGLIB-000R2(v1,v2,G1) & e2 DJoinsGLIB-000R2(v1,v2,G1)"
          using A1 sorry
        thus "e1 =HIDDENR1 e2"
          using A8 sorry
      qed "sorry"
      thus "G2 be non-DmultiGLIB-000V6"
         sorry
    qed
    thus "G1 be non-DmultiGLIB-000V6 implies G2 be non-DmultiGLIB-000V6"
       sorry
    show "G1 be simpleGLIB-000V7 implies G2 be simpleGLIB-000V7"
      using A4 A5 sorry
    show " not (G1 be DsimpleGLIB-000V8 &  not G2 be DsimpleGLIB-000V8)"
      using A4 A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_90:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds G1 ==GLIB-000R5 G2 implies (((((G1 .order()GLIB-000K14 =XBOOLE-0R4 G2 .order()GLIB-000K14 & G1 .size()GLIB-000K16 =XBOOLE-0R4 G2 .size()GLIB-000K16) & G1 .edgesIntoGLIB-000K18 X =XBOOLE-0R4 G2 .edgesIntoGLIB-000K18 X) & G1 .edgesOutOfGLIB-000K19 X =XBOOLE-0R4 G2 .edgesOutOfGLIB-000K19 X) & G1 .edgesInOutGLIB-000K20 X =XBOOLE-0R4 G2 .edgesInOutGLIB-000K20 X) & G1 .edgesBetweenGLIB-000K21 X =XBOOLE-0R4 G2 .edgesBetweenGLIB-000K21 X) & G1 .edgesDBetweenGLIB-000K23(X,Y) =XBOOLE-0R4 G2 .edgesDBetweenGLIB-000K23(X,Y)"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds G1 ==GLIB-000R5 G2 implies G1 .order()GLIB-000K14 =XBOOLE-0R4 G2 .order()GLIB-000K14 & (G1 .size()GLIB-000K16 =XBOOLE-0R4 G2 .size()GLIB-000K16 & (G1 .edgesIntoGLIB-000K18 X =XBOOLE-0R4 G2 .edgesIntoGLIB-000K18 X & (G1 .edgesOutOfGLIB-000K19 X =XBOOLE-0R4 G2 .edgesOutOfGLIB-000K19 X & (G1 .edgesInOutGLIB-000K20 X =XBOOLE-0R4 G2 .edgesInOutGLIB-000K20 X & (G1 .edgesBetweenGLIB-000K21 X =XBOOLE-0R4 G2 .edgesBetweenGLIB-000K21 X & G1 .edgesDBetweenGLIB-000K23(X,Y) =XBOOLE-0R4 G2 .edgesDBetweenGLIB-000K23(X,Y))))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be -GraphGLIB-000M2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "G1 ==GLIB-000R5 G2"
    thus "G1 .order()GLIB-000K14 =XBOOLE-0R4 G2 .order()GLIB-000K14"
       sorry
    show "G1 .size()GLIB-000K16 =XBOOLE-0R4 G2 .size()GLIB-000K16"
      using A1 sorry
    have A2: "the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2"
      using A1 sorry
    have A3: "the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
      using A1 sorry
    have A4: " for e be objectHIDDENM1 holds e inHIDDENR3 G1 .edgesIntoGLIB-000K18 X iff e inHIDDENR3 G2 .edgesIntoGLIB-000K18 X"
    proof(rule ballI)
      fix e assume [ty]: "e be objectHIDDENM1"
      have "e inHIDDENR3 G1 .edgesIntoGLIB-000K18 X iff e inHIDDENR3 the-Edges-ofGLIB-000K7 G2 & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e inTARSKIR2 X"
        using A2 A3 glib_000_def_26 sorry
      thus "e inHIDDENR3 G1 .edgesIntoGLIB-000K18 X iff e inHIDDENR3 G2 .edgesIntoGLIB-000K18 X"
        using glib_000_def_26 sorry
    qed "sorry"
    thus A5: "G1 .edgesIntoGLIB-000K18 X =XBOOLE-0R4 G2 .edgesIntoGLIB-000K18 X"
      using tarski_th_2 sorry
    have A6: "the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2"
      using A1 sorry
    have A7: " for e be objectHIDDENM1 holds e inHIDDENR3 G1 .edgesOutOfGLIB-000K19 X iff e inHIDDENR3 G2 .edgesOutOfGLIB-000K19 X"
    proof(rule ballI)
      fix e assume [ty]: "e be objectHIDDENM1"
      have "e inHIDDENR3 G1 .edgesOutOfGLIB-000K19 X iff e inHIDDENR3 the-Edges-ofGLIB-000K7 G2 & (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e inTARSKIR2 X"
        using A2 A6 glib_000_def_27 sorry
      thus "e inHIDDENR3 G1 .edgesOutOfGLIB-000K19 X iff e inHIDDENR3 G2 .edgesOutOfGLIB-000K19 X"
        using glib_000_def_27 sorry
    qed "sorry"
    thus A8: "G1 .edgesOutOfGLIB-000K19 X =XBOOLE-0R4 G2 .edgesOutOfGLIB-000K19 X"
      using tarski_th_2 sorry
    show "G1 .edgesInOutGLIB-000K20 X =XBOOLE-0R4 G2 .edgesInOutGLIB-000K20 X"
      using A5 A7 tarski_th_2 sorry
    show "G1 .edgesBetweenGLIB-000K21 X =XBOOLE-0R4 G2 .edgesBetweenGLIB-000K21 X"
      using A4 A8 tarski_th_2 sorry
    have " for e be objectHIDDENM1 holds e inHIDDENR3 G2 .edgesDBetweenGLIB-000K23(X,Y) iff e inHIDDENR3 G1 .edgesDBetweenGLIB-000K23(X,Y)"
    proof(rule ballI)
      fix e assume [ty]: "e be objectHIDDENM1"
      have "e inHIDDENR3 G1 .edgesDBetweenGLIB-000K23(X,Y) iff e DSJoinsGLIB-000R4(X,Y,G1)"
        using glib_000_def_31 sorry
      then have "e inHIDDENR3 G1 .edgesDBetweenGLIB-000K23(X,Y) iff e DSJoinsGLIB-000R4(X,Y,G2)"
        using A1 sorry
      thus "e inHIDDENR3 G2 .edgesDBetweenGLIB-000K23(X,Y) iff e inHIDDENR3 G1 .edgesDBetweenGLIB-000K23(X,Y)"
        using glib_000_def_31 sorry
    qed "sorry"
    thus "G1 .edgesDBetweenGLIB-000K23(X,Y) =XBOOLE-0R4 G2 .edgesDBetweenGLIB-000K23(X,Y)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_91:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for G3 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 & G3 be SubgraphGLIB-000M3-of G1 implies G3 be SubgraphGLIB-000M3-of G2"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for G3 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 & G3 be SubgraphGLIB-000M3-of G1 implies G3 be SubgraphGLIB-000M3-of G2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be -GraphGLIB-000M2"
    fix G3 assume [ty]: "G3 be -GraphGLIB-000M2"
    assume A1: "G1 ==GLIB-000R5 G2"
      and A2: "G3 be SubgraphGLIB-000M3-of G1"
    have Cut3771: "the-Vertices-ofGLIB-000K6 G3 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G1"
      using A2 glib_000_def_32 sorry
    have "the-Vertices-ofGLIB-000K6 G3 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G2 & (the-Edges-ofGLIB-000K7 G3 c=TARSKIR1 the-Edges-ofGLIB-000K7 G2 & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 G3 implies (the-Source-ofGLIB-000K10 G3).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G3).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e))"
    proof(rule conjMI,rule conjMI,rule ballI,rule impI,rule conjMI)
      show "the-Vertices-ofGLIB-000K6 G3 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G2"
        using A1 Cut3771 sorry
      have "the-Edges-ofGLIB-000K7 G3 c=TARSKIR1 the-Edges-ofGLIB-000K7 G1"
        using A2 glib_000_def_32 sorry
      thus "the-Edges-ofGLIB-000K7 G3 c=TARSKIR1 the-Edges-ofGLIB-000K7 G2"
        using A1 sorry
      fix e assume [ty]: "e be setHIDDENM2"
      assume A3: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G3"
      then have "(the-Source-ofGLIB-000K10 G3).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e"
        using A2 glib_000_def_32 sorry
      also have "... = (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
        using A1 sorry
      finally show "(the-Source-ofGLIB-000K10 G3).FUNCT-1K1 e =HIDDENR1 (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
         sorry
      have "(the-Target-ofGLIB-000K11 G3).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
        using A2 A3 glib_000_def_32 sorry
      also have "... = (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
        using A1 sorry
      finally show "(the-Target-ofGLIB-000K11 G3).FUNCT-1K1 e =HIDDENR1 (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
         sorry
    qed "sorry"
    thus "G3 be SubgraphGLIB-000M3-of G2"
      using glib_000_def_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_92:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for G3 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 & G1 be SubgraphGLIB-000M3-of G3 implies G2 be SubgraphGLIB-000M3-of G3"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for G3 be -GraphGLIB-000M2 holds G1 ==GLIB-000R5 G2 & G1 be SubgraphGLIB-000M3-of G3 implies G2 be SubgraphGLIB-000M3-of G3"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be -GraphGLIB-000M2"
    fix G3 assume [ty]: "G3 be -GraphGLIB-000M2"
    assume A1: "G1 ==GLIB-000R5 G2"
      and A2: "G1 be SubgraphGLIB-000M3-of G3"
    have A3: "the-Edges-ofGLIB-000K7 G1 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G2"
      using A1 sorry
    have A4: "the-Source-ofGLIB-000K10 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Source-ofGLIB-000K10 G2 & the-Target-ofGLIB-000K11 G1 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1,the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2)\<^esub> the-Target-ofGLIB-000K11 G2"
      using A1 sorry
    have Cut3793: "the-Vertices-ofGLIB-000K6 G1 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G2"
      using A1 sorry
    have "(the-Vertices-ofGLIB-000K6 G2 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G3 & the-Edges-ofGLIB-000K7 G2 c=TARSKIR1 the-Edges-ofGLIB-000K7 G3) & ( for e be setHIDDENM2 holds e inTARSKIR2 the-Edges-ofGLIB-000K7 G2 implies (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G3).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G3).FUNCT-1K1 e)"
    proof(rule conjMI,rule ballI,rule impI)
      show "the-Vertices-ofGLIB-000K6 G2 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G3 & the-Edges-ofGLIB-000K7 G2 c=TARSKIR1 the-Edges-ofGLIB-000K7 G3"
        using A2 A3 glib_000_def_32 Cut3793 sorry
      fix e assume [ty]: "e be setHIDDENM2"
      assume "e inTARSKIR2 the-Edges-ofGLIB-000K7 G2"
      thus "(the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Source-ofGLIB-000K10 G3).FUNCT-1K1 e & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 (the-Target-ofGLIB-000K11 G3).FUNCT-1K1 e"
        using A2 A3 A4 glib_000_def_32 sorry
    qed "sorry"
    thus "G2 be SubgraphGLIB-000M3-of G3"
      using glib_000_def_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_93:
" for G be -GraphGLIB-000M2 holds  for E be setHIDDENM2 holds  for V be setHIDDENM2 holds  for G1 be inducedSubgraphGLIB-000M4-of(G,V,E) holds  for G2 be inducedSubgraphGLIB-000M4-of(G,V,E) holds G1 ==GLIB-000R5 G2"
proof-
  have " for G be -GraphGLIB-000M2 holds  for E be setHIDDENM2 holds  for V be setHIDDENM2 holds  for G1 be inducedSubgraphGLIB-000M4-of(G,V,E) holds  for G2 be inducedSubgraphGLIB-000M4-of(G,V,E) holds G1 ==GLIB-000R5 G2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix E assume [ty]: "E be setHIDDENM2"
    fix V assume [ty]: "V be setHIDDENM2"
    fix G1 assume [ty]: "G1 be inducedSubgraphGLIB-000M4-of(G,V,E)"
    fix G2 assume [ty]: "G2 be inducedSubgraphGLIB-000M4-of(G,V,E)"
    have "G1 ==GLIB-000R5 G2"
    proof-
      show "G1 ==GLIB-000R5 G2"
      proof-
        have cases: "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V or  not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V)"
           sorry
        have case1: "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V implies G1 ==GLIB-000R5 G2"
        proof(rule impI)
          assume A1: "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V"
          then have A2: "the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 E & the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 =XBOOLE-0R4 E"
            using glib_000_def_37 sorry
          have "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 =XBOOLE-0R4 V & the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 =XBOOLE-0R4 V"
            using A1 glib_000_def_37 sorry
          thus "G1 ==GLIB-000R5 G2"
            using A2 glib_000_th_86 sorry
        qed
        have case2: " not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V) implies G1 ==GLIB-000R5 G2"
        proof(rule impI)
          assume " not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G & E c=TARSKIR1 G .edgesBetweenGLIB-000K21 V)"
          then have "G1 ==GLIB-000R5 G & G2 ==GLIB-000R5 G"
            using glib_000_def_37 sorry
          thus "G1 ==GLIB-000R5 G2"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "G1 ==GLIB-000R5 G2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_94:
" for G1 be -GraphGLIB-000M2 holds  for G2 be inducedSubgraphGLIB-000M5-of(G1,the-Vertices-ofGLIB-000K6 G1) holds G1 ==GLIB-000R5 G2"
proof(rule ballI,rule ballI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be inducedSubgraphGLIB-000M5-of(G1,the-Vertices-ofGLIB-000K6 G1)"
  have A1: "the-Vertices-ofGLIB-000K6 G1 c=TARSKIR1 the-Vertices-ofGLIB-000K6 G1"
     sorry
  then have "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 G1 .edgesBetweenGLIB-000K21 (the-Vertices-ofGLIB-000K6 G1)"
    using glib_000_def_37 sorry
  then have A2: "the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Edges-ofGLIB-000K7 G1"
    using glib_000_th_34 sorry
  then have "the-Source-ofGLIB-000K10 G2 =FUNCT-1R1 (the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K7 G1)"
    using glib_000_th_45 sorry
  then have "the-Source-ofGLIB-000K10 G2 =FUNCT-1R1 (the-Source-ofGLIB-000K10 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Source-ofGLIB-000K10 G1)"
     sorry
  then have A3: "the-Source-ofGLIB-000K10 G2 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2,the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> the-Source-ofGLIB-000K10 G1"
     sorry
  have "the-Target-ofGLIB-000K11 G2 =FUNCT-1R1 (the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> (the-Edges-ofGLIB-000K7 G1)"
    using A2 glib_000_th_45 sorry
  then have "the-Target-ofGLIB-000K11 G2 =FUNCT-1R1 (the-Target-ofGLIB-000K11 G1) |RELSET-1K5\<^bsub>(the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> domRELSET-1K1\<^bsub>(the-Edges-ofGLIB-000K7 G1)\<^esub> (the-Target-ofGLIB-000K11 G1)"
     sorry
  then have A4: "the-Target-ofGLIB-000K11 G2 =FUNCT-2R1\<^bsub>(the-Edges-ofGLIB-000K7 G2,the-Vertices-ofGLIB-000K6 G2,the-Edges-ofGLIB-000K7 G1,the-Vertices-ofGLIB-000K6 G1)\<^esub> the-Target-ofGLIB-000K11 G1"
     sorry
  have "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G2 =XBOOLE-0R4 the-Vertices-ofGLIB-000K6 G1"
    using A1 glib_000_def_37 sorry
  thus "G1 ==GLIB-000R5 G2"
    using A2 A3 A4 sorry
qed "sorry"

mtheorem glib_000_th_95:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for V be setHIDDENM2 holds  for E be setHIDDENM2 holds  for G3 be inducedSubgraphGLIB-000M4-of(G1,V,E) holds G1 ==GLIB-000R5 G2 implies G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
  fix G2 assume [ty]: "G2 be -GraphGLIB-000M2"
  fix V assume [ty]: "V be setHIDDENM2"
  fix E assume [ty]: "E be setHIDDENM2"
  fix G3 assume [ty]: "G3 be inducedSubgraphGLIB-000M4-of(G1,V,E)"
  assume A1: "G1 ==GLIB-000R5 G2"
  have "G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
  proof-
    show "G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
    proof-
      have cases: "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1 & E c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 V or  not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1 & E c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 V)"
         sorry
      have case1: "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1 & E c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 V implies G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
      proof(rule impI)
        assume A2: "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1 & E c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 V"
        then have A3: "the-Vertices-ofGLIB-000K24\<^bsub>(G1)\<^esub> G3 =XBOOLE-0R4 V & the-Edges-ofGLIB-000K25\<^bsub>(G1)\<^esub> G3 =XBOOLE-0R4 E"
          using glib_000_def_37 sorry
        have A4: "G3 be SubgraphGLIB-000M3-of G2"
          using A1 glib_000_th_91 sorry
        have "V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G2 & E c=TARSKIR1 G2 .edgesBetweenGLIB-000K21 V"
          using A1 A2 glib_000_th_90 sorry
        thus "G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
          using A3 A4 glib_000_def_37 sorry
      qed
      have case2: " not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1 & E c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 V) implies G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
      proof(rule impI)
        assume A5: " not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G1 & E c=TARSKIR1 G1 .edgesBetweenGLIB-000K21 V)"
        then have A6: " not (V be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of the-Vertices-ofGLIB-000K6 G2 & E c=TARSKIR1 G2 .edgesBetweenGLIB-000K21 V)"
          using A1 glib_000_th_90 sorry
        have "G3 ==GLIB-000R5 G1"
          using A5 glib_000_def_37 sorry
        then have A7: "G3 ==GLIB-000R5 G2"
          using A1 sorry
        then have "G3 be SubgraphGLIB-000M3-of G2"
          using glib_000_th_87 sorry
        thus "G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
          using A6 A7 glib_000_def_37 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "G3 be inducedSubgraphGLIB-000M4-of(G2,V,E)"
     sorry
qed "sorry"

mtheorem glib_000_th_96:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & G1 ==GLIB-000R5 G2 implies ((((((((v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> & v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub>) & v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>) & v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =XBOOLE-0R4 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e) & v1 .inDegree()GLIB-000K30\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .inDegree()GLIB-000K30\<^bsub>(G2)\<^esub>) & v1 .outDegree()GLIB-000K31\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .outDegree()GLIB-000K31\<^bsub>(G2)\<^esub>) & v1 .degree()GLIB-000K34\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .degree()GLIB-000K34\<^bsub>(G2)\<^esub>) & v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub>) & v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub>) & v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub>"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for e be setHIDDENM2 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & G1 ==GLIB-000R5 G2 implies v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub> & (v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub> & (v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> & (v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =XBOOLE-0R4 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e & (v1 .inDegree()GLIB-000K30\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .inDegree()GLIB-000K30\<^bsub>(G2)\<^esub> & (v1 .outDegree()GLIB-000K31\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .outDegree()GLIB-000K31\<^bsub>(G2)\<^esub> & (v1 .degree()GLIB-000K34\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .degree()GLIB-000K34\<^bsub>(G2)\<^esub> & (v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub> & (v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub> & v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub>))))))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be -GraphGLIB-000M2"
    fix e assume [ty]: "e be setHIDDENM2"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
    assume A1: "v1 =XBOOLE-0R4 v2"
      and A2: "G1 ==GLIB-000R5 G2"
    show A3: "v1 .edgesIn()GLIB-000K26\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesIn()GLIB-000K26\<^bsub>(G2)\<^esub>"
      using A1 A2 glib_000_th_90 sorry
    show A4: "v1 .edgesOut()GLIB-000K27\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesOut()GLIB-000K27\<^bsub>(G2)\<^esub>"
      using A1 A2 glib_000_th_90 sorry
    show "v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub>"
      using A1 A2 glib_000_th_90 sorry
    have "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
    proof-
      show "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
      proof-
        have cases: "(e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1 or (e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) or  not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1)"
           sorry
        have case1: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1 implies v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
        proof(rule impI)
          assume A5: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1"
          then have A6: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G2 & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 v2"
            using A1 A2 sorry
          have "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e"
            using A5 glib_000_def_41 sorry
          also have "... = (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e"
            using A2 sorry
          also have "... = v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
            using A6 glib_000_def_41 sorry
          finally show "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
             sorry
        qed
        have case2: "(e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1 implies v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
        proof(rule impI)
          assume A7: "(e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1"
          then have A8: " not (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 v2"
            using A1 A2 sorry
          have A9: "e inTARSKIR2 the-Edges-ofGLIB-000K7 G2 & (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 v2"
            using A1 A2 A7 sorry
          have "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e"
            using A7 glib_000_def_41 sorry
          also have "... = (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e"
            using A2 sorry
          also have "... = v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
            using A9 A8 glib_000_def_41 sorry
          finally show "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
             sorry
        qed
        have case3: " not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) implies v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
        proof(rule impI)
          assume A10: " not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G1 & (the-Source-ofGLIB-000K10 G1).FUNCT-1K1 e =XBOOLE-0R4 v1) &  not (the-Target-ofGLIB-000K11 G1).FUNCT-1K1 e =XBOOLE-0R4 v1)"
          then have A11: " not (e inTARSKIR2 the-Edges-ofGLIB-000K7 G2 & (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 v2) &  not ((e inTARSKIR2 the-Edges-ofGLIB-000K7 G2 & (the-Source-ofGLIB-000K10 G2).FUNCT-1K1 e =XBOOLE-0R4 v2) &  not (the-Target-ofGLIB-000K11 G2).FUNCT-1K1 e =XBOOLE-0R4 v2)"
            using A1 A2 sorry
          have "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2"
            using A1 A10 glib_000_def_41 sorry
          also have "... = v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
            using A11 glib_000_def_41 sorry
          finally show "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =HIDDENR1 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "v1 .adjGLIB-000K29\<^bsub>(G1)\<^esub> e =XBOOLE-0R4 v2 .adjGLIB-000K29\<^bsub>(G2)\<^esub> e"
       sorry
    show "v1 .inDegree()GLIB-000K30\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .inDegree()GLIB-000K30\<^bsub>(G2)\<^esub>"
      using A1 A2 glib_000_th_90 sorry
    show "v1 .outDegree()GLIB-000K31\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .outDegree()GLIB-000K31\<^bsub>(G2)\<^esub>"
      using A1 A2 glib_000_th_90 sorry
    thus "v1 .degree()GLIB-000K34\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .degree()GLIB-000K34\<^bsub>(G2)\<^esub>"
      using A1 A2 glib_000_th_90 sorry
    show "v1 .inNeighbors()GLIB-000K36\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .inNeighbors()GLIB-000K36\<^bsub>(G2)\<^esub>"
      using A2 A3 sorry
    show "v1 .outNeighbors()GLIB-000K37\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .outNeighbors()GLIB-000K37\<^bsub>(G2)\<^esub>"
      using A2 A4 sorry
    thus "v1 .allNeighbors()GLIB-000K38\<^bsub>(G1)\<^esub> =XBOOLE-0R4 v2 .allNeighbors()GLIB-000K38\<^bsub>(G2)\<^esub>"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_97:
" for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & G1 ==GLIB-000R5 G2 implies (v1 be isolatedGLIB-000V10\<^bsub>(G1)\<^esub> implies v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>) & (v1 be endvertexGLIB-000V12\<^bsub>(G1)\<^esub> implies v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub>)"
proof-
  have " for G1 be -GraphGLIB-000M2 holds  for G2 be -GraphGLIB-000M2 holds  for v1 be VertexGLIB-000M10-of G1 holds  for v2 be VertexGLIB-000M10-of G2 holds v1 =XBOOLE-0R4 v2 & G1 ==GLIB-000R5 G2 implies (v1 be isolatedGLIB-000V10\<^bsub>(G1)\<^esub> implies v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>) & (v1 be endvertexGLIB-000V12\<^bsub>(G1)\<^esub> implies v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix G1 assume [ty]: "G1 be -GraphGLIB-000M2"
    fix G2 assume [ty]: "G2 be -GraphGLIB-000M2"
    fix v1 assume [ty]: "v1 be VertexGLIB-000M10-of G1"
    fix v2 assume [ty]: "v2 be VertexGLIB-000M10-of G2"
    assume A1: "v1 =XBOOLE-0R4 v2 & G1 ==GLIB-000R5 G2"
    thus "v1 be isolatedGLIB-000V10\<^bsub>(G1)\<^esub> implies v2 be isolatedGLIB-000V10\<^bsub>(G2)\<^esub>"
      using glib_000_th_96 sorry
    assume "v1 be endvertexGLIB-000V12\<^bsub>(G1)\<^esub>"
    then obtain e where
      [ty]:"e be objectHIDDENM1" and 
      A2: "v1 .edgesInOut()GLIB-000K28\<^bsub>(G1)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} &  not e JoinsGLIB-000R1(v1,v1,G1)"
       sorry
    have "v2 .edgesInOut()GLIB-000K28\<^bsub>(G2)\<^esub> =XBOOLE-0R4 {TARSKIK1 e} &  not e JoinsGLIB-000R1(v2,v2,G2)"
      using A1 A2 glib_000_th_96 sorry
    thus "v2 be endvertexGLIB-000V12\<^bsub>(G2)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_98:
" for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds G1 c<GLIB-000R8 G2 implies the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 or the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
proof-
  have " for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds G1 c<GLIB-000R8 G2 implies  not ( not the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix G1 assume [ty]: "G1 be SubgraphGLIB-000M3-of G"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G"
    assume A1: "G1 c<GLIB-000R8 G2"
    then have "G1 c=GLIB-000R7 G2"
       sorry
    then have A2: "G1 be SubgraphGLIB-000M3-of G2"
       sorry
    then have A3: "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c=TARSKIR1 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2"
      using glib_000_def_32 sorry
    have A4: "the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c=TARSKIR1 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
      using A2 glib_000_def_32 sorry
    have A5: " not G1 ==GLIB-000R5 G2"
      using A1 sorry
    have " not ( not the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2)"
    proof-
      show " not ( not the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2)"
      proof-
        have cases: "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 <>HIDDENR2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 or the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 <>HIDDENR2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
          using A5 glib_000_th_86 sorry
        have case1: "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 <>HIDDENR2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 implies  not ( not the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2)"
        proof(rule impI)
          assume "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 <>HIDDENR2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2"
          thus " not ( not the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2)"
            using A3 xboole_0_def_8 sorry
        qed
        have case2: "the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 <>HIDDENR2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 implies  not ( not the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2)"
        proof(rule impI)
          assume "the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 <>HIDDENR2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
          thus " not ( not the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2)"
            using A4 xboole_0_def_8 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem glib_000_th_99:
" for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds G1 c<GLIB-000R8 G2 implies ( ex v be objectHIDDENM1 st v inHIDDENR3 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not v inHIDDENR3 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1) or ( ex e be objectHIDDENM1 st e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 &  not e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1)"
proof-
  have " for G be -GraphGLIB-000M2 holds  for G1 be SubgraphGLIB-000M3-of G holds  for G2 be SubgraphGLIB-000M3-of G holds G1 c<GLIB-000R8 G2 implies  not (( for v be objectHIDDENM1 holds  not (v inHIDDENR3 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not v inHIDDENR3 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1)) & ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 &  not e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix G assume [ty]: "G be -GraphGLIB-000M2"
    fix G1 assume [ty]: "G1 be SubgraphGLIB-000M3-of G"
    fix G2 assume [ty]: "G2 be SubgraphGLIB-000M3-of G"
    assume "G1 c<GLIB-000R8 G2"
    then have "the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 or the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1 c<XBOOLE-0R2 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2"
      using glib_000_th_98 sorry
    thus " not (( for v be objectHIDDENM1 holds  not (v inHIDDENR3 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G2 &  not v inHIDDENR3 the-Vertices-ofGLIB-000K24\<^bsub>(G)\<^esub> G1)) & ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G2 &  not e inHIDDENR3 the-Edges-ofGLIB-000K25\<^bsub>(G)\<^esub> G1)))"
      using xboole_0_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
