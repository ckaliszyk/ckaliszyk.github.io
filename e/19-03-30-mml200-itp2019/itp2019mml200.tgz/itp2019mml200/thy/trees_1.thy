theory trees_1
  imports finseq_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve X, x, y, z for "setHIDDENM2"
reserve k, n, m for "NatNAT-1M1"
reserve f for "FunctionFUNCT-1M1"
reserve p, q, r for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
abbreviation(input) TREES_1R1(" _ is-a-prefix-ofTREES-1R1  _ " [50,50]50) where
  "p is-a-prefix-ofTREES-1R1 q \<equiv> p c=RELAT-1R2 q"

abbreviation(input) TREES_1R2(" _ is-a-prefix-ofTREES-1R2  _ " [50,50]50) where
  "p is-a-prefix-ofTREES-1R2 q \<equiv> p c=TARSKIR1 q"

mtheorem trees_1_def_1:
  mlet "p be FinSequenceFINSEQ-1M1", "q be FinSequenceFINSEQ-1M1"
"redefine pred p is-a-prefix-ofTREES-1R2 q means
   ex n be NatNAT-1M1 st p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 n"
proof
(*compatibility*)
  show "p is-a-prefix-ofTREES-1R2 q iff ( ex n be NatNAT-1M1 st p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 n)"
  proof-
    have "(p c=RELAT-1R2 q implies ( ex n be NatNAT-1M1 st p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 n)) &  not ( not ( for n be NatNAT-1M1 holds  not p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 n) &  not p c=TARSKIR1 q)"
    proof(rule conjMI)
      show "p c=RELAT-1R2 q implies ( ex n be NatNAT-1M1 st p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 n)"
      proof-
        have "p c=RELAT-1R2 q implies ( ex tVar1 be NatNAT-1M1 st p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 tVar1)"
        proof(rule impI)
          assume A1: "p c=RELAT-1R2 q"
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A2: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 n"
            using finseq_1_def_2 sorry
          have 
            [ty]:"n be NatNAT-1M1"
             sorry
          show " ex tVar1 be NatNAT-1M1 st p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 tVar1"
          proof(rule bexI[of _ "n"])
            show "p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 n"
              using A1 A2 grfunc_1_th_23 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      show " not ( not ( for n be NatNAT-1M1 holds  not p =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 n) &  not p c=TARSKIR1 q)"
        using relat_1_th_59 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_1_th_1:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p is-a-prefix-ofTREES-1R2 q iff ( ex r be FinSequenceFINSEQ-1M1 st q =FINSEQ-1R1 p ^FINSEQ-1K8 r)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (p is-a-prefix-ofTREES-1R2 q implies ( ex r be FinSequenceFINSEQ-1M1 st q =FINSEQ-1R1 p ^FINSEQ-1K8 r)) & (( ex r be FinSequenceFINSEQ-1M1 st q =FINSEQ-1R1 p ^FINSEQ-1K8 r) implies p is-a-prefix-ofTREES-1R2 q)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    show "p is-a-prefix-ofTREES-1R2 q implies ( ex r be FinSequenceFINSEQ-1M1 st q =FINSEQ-1R1 p ^FINSEQ-1K8 r)"
      using finseq_1_th_80 sorry
    assume Given: " ex r be FinSequenceFINSEQ-1M1 st q =FINSEQ-1R1 p ^FINSEQ-1K8 r"
    then obtain r where
      [ty]:"r be FinSequenceFINSEQ-1M1" and 
      A1: "q =FINSEQ-1R1 p ^FINSEQ-1K8 r"
       sorry
    have "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) & p =FUNCT-1R1 q  |RELAT-1K8 domFINSEQ-1K5 p"
      using A1 finseq_1_th_21 finseq_1_def_3 sorry
    thus "p is-a-prefix-ofTREES-1R2 q"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem trees_1_th_3:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds <*FINSEQ-1K10 x*> is-a-prefix-ofTREES-1R2 <*FINSEQ-1K10 y*> implies x =XBOOLE-0R4 y"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds <*FINSEQ-1K10 x*> is-a-prefix-ofTREES-1R2 <*FINSEQ-1K10 y*> implies x =XBOOLE-0R4 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume A1: "<*FINSEQ-1K10 x*> is-a-prefix-ofTREES-1R2 <*FINSEQ-1K10 y*>"
    have "lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 \<one>\<^sub>M & lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    then have A2: "<*FINSEQ-1K10 x*> =FINSEQ-1R1 <*FINSEQ-1K10 y*>"
      using A1 card_2_th_102 sorry
    have "(<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x"
      using finseq_1_th_40 sorry
    thus "x =XBOOLE-0R4 y"
      using A2 finseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) TREES_1R3(" _ is-a-proper-prefix-ofTREES-1R3  _ " [50,50]50) where
  "p is-a-proper-prefix-ofTREES-1R3 q \<equiv> p c<XBOOLE-0R2 q"

mtheorem trees_1_th_4:
" for p be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for q be finiteFINSET-1V1\<bar>setHIDDENM2 holds (p,q)are-c=-comparableXBOOLE-0R3 & cardCARD-1K4 p =XBOOLE-0R4 cardCARD-1K4 q implies p =XBOOLE-0R4 q"
  using card_2_th_102 sorry

reserve p1, p2, p3 for "FinSequenceFINSEQ-1M1"
mtheorem trees_1_th_5:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (<*FINSEQ-1K10 x*>,<*FINSEQ-1K10 y*>)are-c=-comparableXBOOLE-0R3 implies x =XBOOLE-0R4 y"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (<*FINSEQ-1K10 x*>,<*FINSEQ-1K10 y*>)are-c=-comparableXBOOLE-0R3 implies x =XBOOLE-0R4 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume A1: "(<*FINSEQ-1K10 x*>,<*FINSEQ-1K10 y*>)are-c=-comparableXBOOLE-0R3"
    have "lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 \<one>\<^sub>M & lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    then have A2: "<*FINSEQ-1K10 x*> =FINSEQ-1R1 <*FINSEQ-1K10 y*>"
      using A1 trees_1_th_4 sorry
    have "(<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x"
      using finseq_1_th_40 sorry
    thus "x =XBOOLE-0R4 y"
      using A2 finseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_6:
" for p be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for q be finiteFINSET-1V1\<bar>setHIDDENM2 holds p c<XBOOLE-0R2 q implies cardCARD-1K4 p <XXREAL-0R3 cardCARD-1K4 q"
proof-
  have " for p be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for q be finiteFINSET-1V1\<bar>setHIDDENM2 holds  not (p c<XBOOLE-0R2 q & cardCARD-1K4 p <XXREAL-0R3 cardCARD-1K4 q)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be finiteFINSET-1V1\<bar>setHIDDENM2"
    fix q assume [ty]: "q be finiteFINSET-1V1\<bar>setHIDDENM2"
    have "p c=TARSKIR1 q & p <>HIDDENR2 q implies  not cardCARD-1K4 p <XXREAL-0R3 cardCARD-1K4 q"
    proof(rule impMI ,rule impI)
      assume A1: "p c=TARSKIR1 q"
        and A2: "p <>HIDDENR2 q"
      have A3: "cardCARD-1K4 p <=XXREAL-0R1 cardCARD-1K4 q"
        using A1 nat_1_th_43 sorry
      have "(p,q)are-c=-comparableXBOOLE-0R3"
        using A1 sorry
      thus " not cardCARD-1K4 p <XXREAL-0R3 cardCARD-1K4 q"
        using A3 A2 trees_1_th_4 xxreal_0_th_1 sorry
    qed
    thus " not (p c<XBOOLE-0R2 q & cardCARD-1K4 p <XXREAL-0R3 cardCARD-1K4 q)"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_7:
" for x be setHIDDENM2 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) is-a-prefix-ofTREES-1R2 p2 implies p1 is-a-proper-prefix-ofTREES-1R3 p2"
proof-
  have " for x be setHIDDENM2 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) is-a-prefix-ofTREES-1R2 p2 implies p1 is-a-proper-prefix-ofTREES-1R3 p2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    assume "p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) is-a-prefix-ofTREES-1R2 p2"
    then obtain p3 where
      [ty]:"p3 be FinSequenceFINSEQ-1M1" and 
      A1: "p2 =FINSEQ-1R1 (p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 p3"
      using trees_1_th_1 sorry
    have Cut142: "p2 =FINSEQ-1R1 p1 ^FINSEQ-1K8 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 p3)"
      using A1 finseq_1_th_32 sorry
    have "p1 is-a-prefix-ofTREES-1R2 p2 & (p1 =FINSEQ-1R1 p2 implies  False )"
    proof(rule conjMI,rule impI)
      show "p1 is-a-prefix-ofTREES-1R2 p2"
        using trees_1_th_1 Cut142 sorry
      assume "p1 =FINSEQ-1R1 p2"
      then have "lenFINSEQ-1K4 p1 =HIDDENR1 lenFINSEQ-1K4 (p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +NAT-1K1 lenFINSEQ-1K4 p3"
        using A1 finseq_1_th_22 sorry
      also have "... = (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))+NAT-1K1 lenFINSEQ-1K4 p3"
        using finseq_1_th_22 sorry
      also have "... = (lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 p3"
        using finseq_1_th_39 sorry
      finally have "lenFINSEQ-1K4 p1 =HIDDENR1 (lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 p3"
         sorry
      then have "lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p1"
        using nat_1_th_11 sorry
      thus " False "
        using nat_1_th_13 sorry
    qed
    thus "p1 is-a-proper-prefix-ofTREES-1R3 p2"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_8:
" for x be setHIDDENM2 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 is-a-prefix-ofTREES-1R2 p2 implies p1 is-a-proper-prefix-ofTREES-1R3 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
proof-
  have " for x be setHIDDENM2 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 is-a-prefix-ofTREES-1R2 p2 implies p1 is-a-proper-prefix-ofTREES-1R3 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    assume "p1 is-a-prefix-ofTREES-1R2 p2"
    then obtain p3 where
      [ty]:"p3 be FinSequenceFINSEQ-1M1" and 
      A1: "p2 =FINSEQ-1R1 p1 ^FINSEQ-1K8 p3"
      using trees_1_th_1 sorry
    have Cut158: "p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 p1 ^FINSEQ-1K8 (p3 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
      using A1 finseq_1_th_32 sorry
    have "p1 is-a-prefix-ofTREES-1R2 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) & (p1 =FINSEQ-1R1 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) implies  False )"
    proof(rule conjMI,rule impI)
      show "p1 is-a-prefix-ofTREES-1R2 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
        using trees_1_th_1 Cut158 sorry
      assume "p1 =FINSEQ-1R1 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
      then have "lenFINSEQ-1K4 p2 =HIDDENR1 lenFINSEQ-1K4 (p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +NAT-1K1 lenFINSEQ-1K4 p3"
        using A1 finseq_1_th_22 sorry
      also have "... = (lenFINSEQ-1K4 p2 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))+NAT-1K1 lenFINSEQ-1K4 p3"
        using finseq_1_th_22 sorry
      also have "... = (lenFINSEQ-1K4 p2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 p3"
        using finseq_1_th_39 sorry
      finally have "lenFINSEQ-1K4 p2 =HIDDENR1 (lenFINSEQ-1K4 p2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 p3"
         sorry
      then have "lenFINSEQ-1K4 p2 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p2"
        using nat_1_th_11 sorry
      thus " False "
        using nat_1_th_13 sorry
    qed
    thus "p1 is-a-proper-prefix-ofTREES-1R3 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_9:
" for x be setHIDDENM2 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 is-a-proper-prefix-ofTREES-1R3 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) implies p1 is-a-prefix-ofTREES-1R2 p2"
proof-
  have " for x be setHIDDENM2 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  not (p1 is-a-proper-prefix-ofTREES-1R3 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) &  not p1 is-a-prefix-ofTREES-1R2 p2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    have "p1 is-a-prefix-ofTREES-1R2 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) & p1 <>HIDDENR2 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) implies p1 is-a-prefix-ofTREES-1R2 p2"
    proof(rule impMI ,rule impI)
      assume A1: "p1 is-a-prefix-ofTREES-1R2 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
        and A2: "p1 <>HIDDENR2 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
      have A3: " ex p3 be FinSequenceFINSEQ-1M1 st p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 p1 ^FINSEQ-1K8 p3"
        using A1 trees_1_th_1 sorry
      have A4: "lenFINSEQ-1K4 p1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
        using A1 nat_1_th_43 sorry
      have "lenFINSEQ-1K4 (p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p2 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) & lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 \<one>\<^sub>M"
        using finseq_1_th_22 finseq_1_th_39 sorry
      then have "lenFINSEQ-1K4 p1 <XXREAL-0R3 lenFINSEQ-1K4 p2 +NAT-1K1 \<one>\<^sub>M"
        using A1 A2 A4 card_2_th_102 xxreal_0_th_1 sorry
      then have "lenFINSEQ-1K4 p1 <=XXREAL-0R1 lenFINSEQ-1K4 p2"
        using nat_1_th_13 sorry
      then have " ex p3 be FinSequenceFINSEQ-1M1 st p1 ^FINSEQ-1K8 p3 =FINSEQ-1R1 p2"
        using A3 finseq_1_th_47 sorry
      thus "p1 is-a-prefix-ofTREES-1R2 p2"
        using trees_1_th_1 sorry
    qed
    thus " not (p1 is-a-proper-prefix-ofTREES-1R3 p2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) &  not p1 is-a-prefix-ofTREES-1R2 p2)"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_10:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds {}XBOOLE-0K1 is-a-proper-prefix-ofTREES-1R3 p2 or {}XBOOLE-0K1 <>HIDDENR2 p2 implies p1 is-a-proper-prefix-ofTREES-1R3 p1 ^FINSEQ-1K8 p2"
proof-
  have " for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds {}XBOOLE-0K1 is-a-proper-prefix-ofTREES-1R3 p2 or {}XBOOLE-0K1 <>HIDDENR2 p2 implies p1 is-a-proper-prefix-ofTREES-1R3 p1 ^FINSEQ-1K8 p2"
  proof(rule ballI,rule ballI,rule impI)
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    assume A1: "{}XBOOLE-0K1 is-a-proper-prefix-ofTREES-1R3 p2 or {}XBOOLE-0K1 <>HIDDENR2 p2"
    have "p1 is-a-prefix-ofTREES-1R2 p1 ^FINSEQ-1K8 p2 & (p1 =FINSEQ-1R1 p1 ^FINSEQ-1K8 p2 implies  False )"
    proof(rule conjMI,rule impI)
      show "p1 is-a-prefix-ofTREES-1R2 p1 ^FINSEQ-1K8 p2"
        using trees_1_th_1 sorry
      assume "p1 =FINSEQ-1R1 p1 ^FINSEQ-1K8 p2"
      then have "lenFINSEQ-1K4 p1 =XBOOLE-0R4 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2"
        using finseq_1_th_22 sorry
      then have "p2 =FINSEQ-1R1 {}XBOOLE-0K1"
         sorry
      thus " False "
        using A1 sorry
    qed
    thus "p1 is-a-proper-prefix-ofTREES-1R3 p1 ^FINSEQ-1K8 p2"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_1_def_2 ("ProperPrefixesTREES-1K1  _ " [228]228 ) where
  mlet "p be FinSequenceFINSEQ-1M1"
"func ProperPrefixesTREES-1K1 p \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)"
    proof-
      have " ex tVar2 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar2 implies ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)) & (( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p) implies x inHIDDENR3 tVar2)"
      proof-
        let ?E = "rngFUNCT-1K2 p"
        let ?X = "\<lambda>Lamb1.  ex q be FinSequenceFINSEQ-1M1 st Lamb1 =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 ?E * FINSEQ-2K3 & ?X(x)"
          using xboole_0_sch_1 sorry
        show " ex tVar2 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar2 implies ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)) & (( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p) implies x inHIDDENR3 tVar2)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 X implies ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)"
            using A1 sorry
          assume Given: " ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p"
          then obtain q where
            [ty]:"q be FinSequenceFINSEQ-1M1" and 
            A2: "x =HIDDENR1 q"and A3: "q is-a-proper-prefix-ofTREES-1R3 p"
             sorry
          have "q is-a-prefix-ofTREES-1R2 p"
            using A3 sorry
          then have " ex n be NatNAT-1M1 st q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n"
             sorry
          then have "rngFUNCT-1K2 q c=TARSKIR1 ?E"
            using relat_1_th_70 sorry
          then have 
            [ty]:"q be FinSequenceFINSEQ-1M3-of ?E"
            using finseq_1_def_4 sorry
          have "q inTARSKIR2 ?E * FINSEQ-2K3"
            using finseq_1_def_11 sorry
          thus "x inHIDDENR3 X"
            using A1 A2 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)) implies it1 =HIDDENR1 it2"
    proof-
      have " for S1 be setHIDDENM2 holds  for S2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 S1 iff ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 S2 iff ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)) implies S1 =HIDDENR1 S2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix S1 assume [ty]: "S1 be setHIDDENM2"
        fix S2 assume [ty]: "S2 be setHIDDENM2"
        assume A4: " for x be objectHIDDENM1 holds x inHIDDENR3 S1 iff ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)"
          and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 S2 iff ( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p)"
        let ?X = "\<lambda>Lamb1.  ex q be FinSequenceFINSEQ-1M1 st Lamb1 =HIDDENR1 q & q is-a-proper-prefix-ofTREES-1R3 p"
        have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 S1 iff ?X(x)"
          using A4 sorry
        have A7: " for x be objectHIDDENM1 holds x inHIDDENR3 S2 iff ?X(x)"
          using A5 sorry
        show "S1 =HIDDENR1 S2"
          using xboole_0_sch_2 A6 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_1_th_11:
" for x be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 ProperPrefixesTREES-1K1 p implies x be FinSequenceFINSEQ-1M1"
proof-
  have " for x be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 ProperPrefixesTREES-1K1 p implies x be FinSequenceFINSEQ-1M1"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume "x inTARSKIR2 ProperPrefixesTREES-1K1 p"
    then have " ex q be FinSequenceFINSEQ-1M1 st x =XBOOLE-0R4 q & q is-a-proper-prefix-ofTREES-1R3 p"
      using trees_1_def_2 sorry
    thus "x be FinSequenceFINSEQ-1M1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_12:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 ProperPrefixesTREES-1K1 q iff p is-a-proper-prefix-ofTREES-1R3 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (p inTARSKIR2 ProperPrefixesTREES-1K1 q implies p is-a-proper-prefix-ofTREES-1R3 q) &  not (p is-a-proper-prefix-ofTREES-1R3 q &  not p inTARSKIR2 ProperPrefixesTREES-1K1 q)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    show "p inTARSKIR2 ProperPrefixesTREES-1K1 q implies p is-a-proper-prefix-ofTREES-1R3 q"
    proof(rule impI)
      assume "p inTARSKIR2 ProperPrefixesTREES-1K1 q"
      then have " ex r be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 r & r is-a-proper-prefix-ofTREES-1R3 q"
        using trees_1_def_2 sorry
      thus "p is-a-proper-prefix-ofTREES-1R3 q"
         sorry
    qed
    show " not (p is-a-proper-prefix-ofTREES-1R3 q &  not p inTARSKIR2 ProperPrefixesTREES-1K1 q)"
      using trees_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_13:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 ProperPrefixesTREES-1K1 q implies lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 q"
  using trees_1_th_12 trees_1_th_6 sorry

mtheorem trees_1_th_14:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds q ^FINSEQ-1K8 r inTARSKIR2 ProperPrefixesTREES-1K1 p implies q inTARSKIR2 ProperPrefixesTREES-1K1 p"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
  fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
  assume A1: "q ^FINSEQ-1K8 r inTARSKIR2 ProperPrefixesTREES-1K1 p"
  have A2: "q is-a-prefix-ofTREES-1R2 q ^FINSEQ-1K8 r"
    using trees_1_th_1 sorry
  have "q ^FINSEQ-1K8 r is-a-proper-prefix-ofTREES-1R3 p"
    using A1 trees_1_th_12 sorry
  then have "q is-a-proper-prefix-ofTREES-1R3 p"
    using A2 xboole_1_th_59 sorry
  thus "q inTARSKIR2 ProperPrefixesTREES-1K1 p"
    using trees_1_th_12 sorry
qed "sorry"

mtheorem trees_1_th_15:
"ProperPrefixesTREES-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " not ProperPrefixesTREES-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
  proof(rule impI)
    let ?x = "the ElementSUBSET-1M1-of ProperPrefixesTREES-1K1 ({}XBOOLE-0K1)"
    assume A1: " not ProperPrefixesTREES-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
    then obtain x where 
      [ty]:"x be FinSequenceFINSEQ-1M1" and xDef:"x = ?x"
      using trees_1_th_11 sorry
    have "x is-a-proper-prefix-ofTREES-1R3 {}XBOOLE-0K1"
      using A1 trees_1_th_12 sorry
    thus " False "
      using xboole_1_th_62 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_16:
" for x be setHIDDENM2 holds ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for x be setHIDDENM2 holds ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  proof(rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    have "ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 } & {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>)"
    proof(rule conjMI)
      show "ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>) implies y inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>)"
          then obtain p where
            [ty]:"p be FinSequenceFINSEQ-1M1" and 
            A1: "y =HIDDENR1 p"and A2: "p is-a-proper-prefix-ofTREES-1R3 <*FINSEQ-1K10 x*>"
            using trees_1_def_2 sorry
          have A3: "lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>)"
            using A2 trees_1_th_6 sorry
          have "lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 \<one>\<^sub>M & \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
            using finseq_1_th_39 sorry
          then have "p =FINSEQ-1R1 {}XBOOLE-0K1"
            using A3 nat_1_th_13 sorry
          thus "y inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
            using A1 tarski_def_1 sorry
        qed "sorry"
        thus "ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies y inHIDDENR3 ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        then have A4: "y =HIDDENR1 {}XBOOLE-0K1"
          using tarski_def_1 sorry
        have "{}XBOOLE-0K1 is-a-prefix-ofTREES-1R2 <*FINSEQ-1K10 x*>"
           sorry
        then have "{}XBOOLE-0K1 is-a-proper-prefix-ofTREES-1R3 <*FINSEQ-1K10 x*>"
           sorry
        thus "y inHIDDENR3 ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>)"
          using A4 trees_1_def_2 sorry
      qed "sorry"
      thus "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>)"
        using tarski_def_3 sorry
    qed
    thus "ProperPrefixesTREES-1K1 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_17:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p is-a-prefix-ofTREES-1R2 q implies ProperPrefixesTREES-1K1 p c=TARSKIR1 ProperPrefixesTREES-1K1 q"
proof(rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
  assume A1: "p is-a-prefix-ofTREES-1R2 q"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 p implies x inHIDDENR3 ProperPrefixesTREES-1K1 q"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A2: "x inHIDDENR3 ProperPrefixesTREES-1K1 p"
    then obtain r where 
      [ty]:"r be FinSequenceFINSEQ-1M1" and rDef:"r = x"
      using trees_1_th_11 sorry
    have "r is-a-proper-prefix-ofTREES-1R3 p"
      using A2 trees_1_th_12 sorry
    then have "r is-a-proper-prefix-ofTREES-1R3 q"
      using A1 xboole_1_th_58 sorry
    thus "x inHIDDENR3 ProperPrefixesTREES-1K1 q"
      using trees_1_th_12 sorry
  qed "sorry"
  thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 ProperPrefixesTREES-1K1 q"
    using tarski_def_3 sorry
qed "sorry"

mtheorem trees_1_th_18:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds q inTARSKIR2 ProperPrefixesTREES-1K1 p & r inTARSKIR2 ProperPrefixesTREES-1K1 p implies (q,r)are-c=-comparableXBOOLE-0R3"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds q inTARSKIR2 ProperPrefixesTREES-1K1 p implies (r inTARSKIR2 ProperPrefixesTREES-1K1 p implies (q,r)are-c=-comparableXBOOLE-0R3)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
    assume "q inTARSKIR2 ProperPrefixesTREES-1K1 p"
    then have A1: " ex q1 be FinSequenceFINSEQ-1M1 st q =FINSEQ-1R1 q1 & q1 is-a-proper-prefix-ofTREES-1R3 p"
      using trees_1_def_2 sorry
    assume "r inTARSKIR2 ProperPrefixesTREES-1K1 p"
    then have A2: " ex r1 be FinSequenceFINSEQ-1M1 st r =FINSEQ-1R1 r1 & r1 is-a-proper-prefix-ofTREES-1R3 p"
      using trees_1_def_2 sorry
    have "q is-a-prefix-ofTREES-1R2 p"
      using A1 sorry
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A3: "q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n"
       sorry
    have "r is-a-prefix-ofTREES-1R2 p"
      using A2 sorry
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: "r =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 k"
       sorry
    have A5: "n <=XXREAL-0R1 k implies (q,r)are-c=-comparableXBOOLE-0R3"
    proof(rule impI)
      assume "n <=XXREAL-0R1 k"
      then have "SegFINSEQ-1K2 n c=TARSKIR1 SegFINSEQ-1K2 k"
        using finseq_1_th_5 sorry
      then have "q =FUNCT-1R1 r  |RELAT-1K8 SegFINSEQ-1K2 n"
        using A3 A4 funct_1_th_51 sorry
      then have "q is-a-prefix-ofTREES-1R2 r"
         sorry
      thus "(q,r)are-c=-comparableXBOOLE-0R3"
         sorry
    qed
    have "k <=XXREAL-0R1 n implies (q,r)are-c=-comparableXBOOLE-0R3"
    proof(rule impI)
      assume "k <=XXREAL-0R1 n"
      then have "SegFINSEQ-1K2 k c=TARSKIR1 SegFINSEQ-1K2 n"
        using finseq_1_th_5 sorry
      then have "r =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 k"
        using A3 A4 funct_1_th_51 sorry
      then have "r is-a-prefix-ofTREES-1R2 q"
         sorry
      thus "(q,r)are-c=-comparableXBOOLE-0R3"
         sorry
    qed
    thus "(q,r)are-c=-comparableXBOOLE-0R3"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_1_def_3 ("Tree-likeTREES-1V1" 70 ) where
"attr Tree-likeTREES-1V1 for setHIDDENM2 means
  (\<lambda>X. (X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 X implies ProperPrefixesTREES-1K1 p c=TARSKIR1 X)) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 X & n <=XXREAL-0R1 k implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X))"..

mtheorem trees_1_cl_1:
"cluster {TARSKIK1 {}XBOOLE-0K1 } as-term-is Tree-likeTREES-1V1"
proof
(*coherence*)
  show "{TARSKIK1 {}XBOOLE-0K1 } be Tree-likeTREES-1V1"
  proof-
    have "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  not ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } & n <=XXREAL-0R1 k) &  not p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 })))"
    proof(rule conjMI,rule conjMI)
      show "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
          then have "x =HIDDENR1 {}XBOOLE-0K1"
            using tarski_def_1 sorry
          thus "x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
            using finseq_1_th_49 sorry
        qed "sorry"
        thus "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
          using tarski_def_3 sorry
      qed
      show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
        using tarski_def_1 trees_1_th_15 sorry
      show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  not ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } & n <=XXREAL-0R1 k) &  not p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 })"
        using tarski_def_1 sorry
    qed
    thus "{TARSKIK1 {}XBOOLE-0K1 } be Tree-likeTREES-1V1"
      using trees_1_def_3 sorry
  qed
qed "sorry"

mtheorem trees_1_cl_2:
"cluster  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
  proof-
    have " ex D be setHIDDENM2 st  not D be emptyXBOOLE-0V1 & D be Tree-likeTREES-1V1"
    proof-
      obtain D where 
        [ty]:"D be setHIDDENM2" and DDef:"D = {TARSKIK1 <*>FINSEQ-1K7 NATNUMBERSK1 }"
         sorry
      show " ex D be setHIDDENM2 st  not D be emptyXBOOLE-0V1 & D be Tree-likeTREES-1V1"
      proof(rule bexI[of _ "D"])
        show " not D be emptyXBOOLE-0V1 & D be Tree-likeTREES-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax TREES_1M1 :: "Ty" ("TreeTREES-1M1" 70)
translations "TreeTREES-1M1" \<rightharpoonup> "Tree-likeTREES-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"

reserve T, T1 for "TreeTREES-1M1"
mtheorem trees_1_th_19:
" for x be setHIDDENM2 holds  for T be TreeTREES-1M1 holds x inTARSKIR2 T implies x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
proof-
  have " for x be setHIDDENM2 holds  for T be TreeTREES-1M1 holds  not (x inTARSKIR2 T &  not x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix T assume [ty]: "T be TreeTREES-1M1"
    have "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
      using trees_1_def_3 sorry
    thus " not (x inTARSKIR2 T &  not x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1)"
      using finseq_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) TREES_1M2("ElementTREES-1M2-of  _ " [70]70) where
  "ElementTREES-1M2-of T \<equiv> ElementSUBSET-1M1-of T"

mtheorem trees_1_add_1:
  mlet "T be TreeTREES-1M1"
"cluster note-that FinSequenceFINSEQ-1M3-of NATNUMBERSK1 for ElementSUBSET-1M1-of T"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of T holds it be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    using trees_1_th_19 sorry
qed "sorry"

mtheorem trees_1_th_20:
" for T be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T & q is-a-prefix-ofTREES-1R2 p implies q inTARSKIR2 T"
proof-
  have " for T be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T & q is-a-prefix-ofTREES-1R2 p implies q inTARSKIR2 T"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "p inTARSKIR2 T"
      and A2: "q is-a-prefix-ofTREES-1R2 p"
    obtain r where 
      [ty]:"r be ElementTREES-1M2-of T" and rDef:"r = p"
      using A1 sorry
    have A3: "ProperPrefixesTREES-1K1 r c=TARSKIR1 T"
      using trees_1_def_3 sorry
    have "q is-a-proper-prefix-ofTREES-1R3 p or q =FINSEQ-1R1 p"
      using A2 sorry
    then have "q inTARSKIR2 ProperPrefixesTREES-1K1 p or p =FINSEQ-1R1 q"
      using trees_1_th_12 sorry
    thus "q inTARSKIR2 T"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_21:
" for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be TreeTREES-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds q ^FINSEQ-1K8 r inTARSKIR2 T implies q inTARSKIR2 T"
proof-
  have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be TreeTREES-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds q ^FINSEQ-1K8 r inTARSKIR2 T implies q inTARSKIR2 T"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
    assume A1: "q ^FINSEQ-1K8 r inTARSKIR2 T"
    then obtain p where 
      [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and pDef:"p = q ^FINSEQ-1K8 r"
      using trees_1_th_19 sorry
    obtain s where 
      [ty]:"s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and sDef:"s = p  |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using finseq_1_th_18 sorry
    have "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 r"
      using finseq_1_th_22 sorry
    then have "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using nat_1_th_11 sorry
    then have A2: "lenFINSEQ-1K4 s =XBOOLE-0R4 lenFINSEQ-1K4 q"
      using finseq_1_th_17 sorry
    have " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 q implies q .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 n"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume "\<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 q"
      then have A3: "n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
        using finseq_1_th_1 sorry
      have "SegFINSEQ-1K2 (lenFINSEQ-1K4 q) =XBOOLE-0R4 domFINSEQ-1K5 q"
        using finseq_1_def_3 sorry
      then have "p .FUNCT-1K1 n =XBOOLE-0R4 q .FUNCT-1K1 n"
        using A3 finseq_1_def_7 sorry
      thus "q .FUNCT-1K1 n =XBOOLE-0R4 s .FUNCT-1K1 n"
        using A3 funct_1_th_49 sorry
    qed "sorry"
    then have "q =FINSEQ-1R1 s"
      using A2 finseq_1_th_14 sorry
    then have A4: "q is-a-prefix-ofTREES-1R2 p"
       sorry
    have "q <>HIDDENR2 p implies q inTARSKIR2 T"
    proof(rule impI)
      assume "q <>HIDDENR2 p"
      then have "q is-a-proper-prefix-ofTREES-1R3 p"
        using A4 sorry
      then have A5: "q inTARSKIR2 ProperPrefixesTREES-1K1 p"
        using trees_1_def_2 sorry
      have "ProperPrefixesTREES-1K1 p c=TARSKIR1 T"
        using A1 trees_1_def_3 sorry
      thus "q inTARSKIR2 T"
        using A5 sorry
    qed
    thus "q inTARSKIR2 T"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_22:
" for T be TreeTREES-1M1 holds {}XBOOLE-0K1 inTARSKIR2 T & <*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 T"
proof-
  have " for T be TreeTREES-1M1 holds {}XBOOLE-0K1 inTARSKIR2 T & <*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 T"
  proof(rule ballI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    obtain x where 
      [ty]:"x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and xDef:"x = the ElementTREES-1M2-of T"
       sorry
    have "x inTARSKIR2 T"
       sorry
    then have A1: "{}XBOOLE-0K1 ^FINSEQ-1K8 x inTARSKIR2 T"
      using finseq_1_th_34 sorry
    have "{}XBOOLE-0K1 =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1"
       sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 T & <*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 T"
      using A1 trees_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_23:
"{TARSKIK1 {}XBOOLE-0K1 } be TreeTREES-1M1"
   sorry

mtheorem trees_1_cl_3:
  mlet "T be TreeTREES-1M1", "T1 be TreeTREES-1M1"
"cluster T \\/XBOOLE-0K2 T1 as-term-is Tree-likeTREES-1V1"
proof
(*coherence*)
  show "T \\/XBOOLE-0K2 T1 be Tree-likeTREES-1V1"
  proof-
    let ?D = "T \\/XBOOLE-0K2 T1"
    have Cut493: "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & T1 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
      using trees_1_def_3 sorry
    have "T \\/XBOOLE-0K2 T1 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T \\/XBOOLE-0K2 T1 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 T \\/XBOOLE-0K2 T1) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T \\/XBOOLE-0K2 T1 & n <=XXREAL-0R1 k implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T \\/XBOOLE-0K2 T1))"
    proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      show "T \\/XBOOLE-0K2 T1 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
        using xboole_1_th_8 Cut493 sorry
      show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T \\/XBOOLE-0K2 T1 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 T \\/XBOOLE-0K2 T1"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume "p inTARSKIR2 ?D"
        then have "p inTARSKIR2 T or p inTARSKIR2 T1"
          using xboole_0_def_3 sorry
        then have A1: "ProperPrefixesTREES-1K1 p c=TARSKIR1 T or ProperPrefixesTREES-1K1 p c=TARSKIR1 T1"
          using trees_1_def_3 sorry
        have "T c=TARSKIR1 ?D & T1 c=TARSKIR1 ?D"
          using xboole_1_th_7 sorry
        thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 T \\/XBOOLE-0K2 T1"
          using A1 sorry
      qed "sorry"
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      fix k assume [ty]: "k be NatNAT-1M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A2: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 ?D"
        and A3: "n <=XXREAL-0R1 k"
      have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T or p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T1"
        using A2 xboole_0_def_3 sorry
      then have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T or p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T1"
        using A3 trees_1_def_3 sorry
      thus "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T \\/XBOOLE-0K2 T1"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "T \\/XBOOLE-0K2 T1 be Tree-likeTREES-1V1"
      using trees_1_def_3 sorry
  qed
qed "sorry"

mtheorem trees_1_cl_4:
  mlet "T be TreeTREES-1M1", "T1 be TreeTREES-1M1"
"cluster T /\\XBOOLE-0K3 T1 as-term-is Tree-likeTREES-1V1\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "T /\\XBOOLE-0K3 T1 be Tree-likeTREES-1V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have "T /\\XBOOLE-0K3 T1 be Tree-likeTREES-1V1 &  not T /\\XBOOLE-0K3 T1 be emptyXBOOLE-0V1"
    proof(rule conjMI)
      let ?D = "T /\\XBOOLE-0K3 T1"
      show "T /\\XBOOLE-0K3 T1 be Tree-likeTREES-1V1"
      proof-
        have Cut520: "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & T /\\XBOOLE-0K3 T1 c=TARSKIR1 T"
          using trees_1_def_3 xboole_1_th_17 sorry
        have "T /\\XBOOLE-0K3 T1 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T /\\XBOOLE-0K3 T1 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 T /\\XBOOLE-0K3 T1) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T /\\XBOOLE-0K3 T1 & n <=XXREAL-0R1 k implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T /\\XBOOLE-0K3 T1))"
        proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          show "T /\\XBOOLE-0K3 T1 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
            using Cut520 sorry
          show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T /\\XBOOLE-0K3 T1 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 T /\\XBOOLE-0K3 T1"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume A4: "p inTARSKIR2 ?D"
            then have A5: "p inTARSKIR2 T"
              using xboole_0_def_4 sorry
            have A6: "p inTARSKIR2 T1"
              using A4 xboole_0_def_4 sorry
            have A7: "ProperPrefixesTREES-1K1 p c=TARSKIR1 T"
              using A5 trees_1_def_3 sorry
            have "ProperPrefixesTREES-1K1 p c=TARSKIR1 T1"
              using A6 trees_1_def_3 sorry
            thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 T /\\XBOOLE-0K3 T1"
              using A7 xboole_1_th_19 sorry
          qed "sorry"
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          fix k assume [ty]: "k be NatNAT-1M1"
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A8: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 ?D"
            and A9: "n <=XXREAL-0R1 k"
          have A10: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T"
            using A8 xboole_0_def_4 sorry
          have A11: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T1"
            using A8 xboole_0_def_4 sorry
          have A12: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
            using A9 A10 trees_1_def_3 sorry
          have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T1"
            using A9 A11 trees_1_def_3 sorry
          thus "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T /\\XBOOLE-0K3 T1"
            using A12 xboole_0_def_4 sorry
        qed "sorry"
        thus "T /\\XBOOLE-0K3 T1 be Tree-likeTREES-1V1"
          using trees_1_def_3 sorry
      qed
      have "{}XBOOLE-0K1 inTARSKIR2 T & {}XBOOLE-0K1 inTARSKIR2 T1"
        using trees_1_th_22 sorry
      thus " not T /\\XBOOLE-0K3 T1 be emptyXBOOLE-0V1"
        using xboole_0_def_4 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_1_th_24:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds T \\/XBOOLE-0K2 T1 be TreeTREES-1M1"
   sorry

mtheorem trees_1_th_25:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds T /\\XBOOLE-0K3 T1 be TreeTREES-1M1"
   sorry

mtheorem trees_1_cl_5:
"cluster finiteFINSET-1V1 for TreeTREES-1M1"
proof
(*existence*)
  show " ex it be TreeTREES-1M1 st it be finiteFINSET-1V1"
  proof-
    have " ex tVar4 be TreeTREES-1M1 st tVar4 be finiteFINSET-1V1"
    proof-
      show " ex tVar4 be TreeTREES-1M1 st tVar4 be finiteFINSET-1V1"
      proof(rule bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 }"])
        show "{TARSKIK1 {}XBOOLE-0K1 } be finiteFINSET-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve fT, fT1 for "finiteFINSET-1V1\<bar>TreeTREES-1M1"
mtheorem trees_1_th_26:
" for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for fT1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds fT \\/XBOOLE-0K2 fT1 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
   sorry

mtheorem trees_1_th_27:
" for T be TreeTREES-1M1 holds  for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds fT /\\XBOOLE-0K3 T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
   sorry

mdef trees_1_def_4 ("elementary-treeTREES-1K2  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func elementary-treeTREES-1K2 n \<rightarrow> TreeTREES-1M1 equals
  ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  (*coherence*)
    show "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } be TreeTREES-1M1"
    proof-
      have "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } be TreeTREES-1M1"
      proof-
        let ?IT = "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }"
        have "?IT be Tree-likeTREES-1V1"
        proof-
          have "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } be Tree-likeTREES-1V1"
          proof-
            have "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } implies (m <=XXREAL-0R1 k implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 })))"
            proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
              show "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
              proof-
                have "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                proof-
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 ?IT"
                    then have A1: "x inHIDDENR3 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
                      using xboole_0_def_3 sorry
                    have A2: "{}XBOOLE-0K1 inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
                      using finseq_1_th_49 sorry
                    have "x inHIDDENR3 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n } implies x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                    proof(rule impI)
                      assume "x inHIDDENR3 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n }"
                      then obtain k where
                        [ty]:"k be NatNAT-1M1" and 
                        A3: "x =HIDDENR1 <*FINSEQ-1K10 k*> & k <XXREAL-0R3 n"
                         sorry
                      have 
                        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      have "x =HIDDENR1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>"
                        using A3 sorry
                      thus "x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                        using finseq_1_def_11 sorry
                    qed
                    thus "x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                      using A1 A2 tarski_def_1 sorry
                  qed "sorry"
                  thus "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }"
              proof-
                have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }"
                proof(rule ballI,rule impI)
                  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  assume "p inTARSKIR2 ?IT"
                  then have A4: "p inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n } or p inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
                    using xboole_0_def_3 sorry
                  have "p inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }"
                  proof(rule impI)
                    assume "p inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n }"
                    then have " ex k be NatNAT-1M1 st p =FINSEQ-1R1 <*FINSEQ-1K10 k*> & k <XXREAL-0R3 n"
                       sorry
                    then have "ProperPrefixesTREES-1K1 p =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
                      using trees_1_th_16 sorry
                    thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }"
                      using xboole_1_th_7 sorry
                  qed
                  thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }"
                    using A4 trees_1_th_15 tarski_def_1 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              fix k assume [ty]: "k be NatNAT-1M1"
              fix m assume [ty]: "m be NatNAT-1M1"
              assume "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 ?IT"
              then have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 n } or p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
                using xboole_0_def_3 sorry
              then obtain l where
                [ty]:"l be NatNAT-1M1" and 
                A5: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 <*FINSEQ-1K10 l*>"and A6: "l <XXREAL-0R3 n"
                using tarski_def_1 sorry
              have "lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 k*>) =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>)"
                using A5 finseq_1_th_22 sorry
              also have "... = \<one>\<^sub>M"
                using finseq_1_th_39 sorry
              finally have "lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 k*>) =HIDDENR1 \<one>\<^sub>M"
                 sorry
              then have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
                using finseq_1_th_39 sorry
              then have A7: "p =FINSEQ-1R1 {}XBOOLE-0K1"
                 sorry
              then have A8: "<*FINSEQ-1K10 k*> =FINSEQ-1R1 <*FINSEQ-1K10 l*>"
                using A5 finseq_1_th_34 sorry
              have "(<*FINSEQ-1K10 k*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k"
                using finseq_1_def_8 sorry
              then have A9: "k =XBOOLE-0R4 l"
                using A8 finseq_1_def_8 sorry
              assume A10: "m <=XXREAL-0R1 k"
              have A11: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) =FINSEQ-1R1 <*FINSEQ-1K10 m*>"
                using A7 finseq_1_th_34 sorry
              have "m <XXREAL-0R3 n"
                using A6 A9 A10 xxreal_0_th_2 sorry
              then have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 {<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 n }"
                using A11 sorry
              thus "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 ({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 }"
                using xboole_0_def_3 sorry
            qed "sorry"
            thus "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } be Tree-likeTREES-1V1"
              using trees_1_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "({<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n })\\/XBOOLE-0K2 {TARSKIK1 {}XBOOLE-0K1 } be TreeTREES-1M1"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_1_cl_6:
  mlet "n be NatNAT-1M1"
"cluster elementary-treeTREES-1K2 n as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "elementary-treeTREES-1K2 n be finiteFINSET-1V1"
  proof-
    let ?IT = "elementary-treeTREES-1K2 n"
    have "(?IT,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))are-equipotentTARSKIR3"
    proof-
      have "(elementary-treeTREES-1K2 n,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))are-equipotentTARSKIR3"
      proof-
        let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 =HIDDENR1 {}XBOOLE-0K1 & Lamb2 =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st Lamb1 =HIDDENR1 <*FINSEQ-1K10 n*> & Lamb2 =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M)"
        have A1: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds (x inTARSKIR2 ?IT & ?F(x,y)) & ?F(x,z) implies y =XBOOLE-0R4 z"
        proof-
          have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x inTARSKIR2 elementary-treeTREES-1K2 n & ((x =XBOOLE-0R4 {}XBOOLE-0K1 & y =XBOOLE-0R4 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n*> & y =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M)) & (x =XBOOLE-0R4 {}XBOOLE-0K1 & z =XBOOLE-0R4 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n*> & z =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M))) implies y =XBOOLE-0R4 z"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be setHIDDENM2"
            fix y assume [ty]: "y be setHIDDENM2"
            fix z assume [ty]: "z be setHIDDENM2"
            assume "x inTARSKIR2 ?IT"
              and A2: "(x =XBOOLE-0R4 {}XBOOLE-0K1 & y =XBOOLE-0R4 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n*> & y =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M)) & (x =XBOOLE-0R4 {}XBOOLE-0K1 & z =XBOOLE-0R4 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n*> & z =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M))"
            have "( ex n1 be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n1*> & y =XBOOLE-0R4 n1 +NAT-1K1 \<two>\<^sub>M) implies (( ex n2 be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n2*> & z =XBOOLE-0R4 n2 +NAT-1K1 \<two>\<^sub>M) implies y =XBOOLE-0R4 z)"
            proof(rule impI,rule impI)
              assume Given: " ex n1 be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n1*> & y =XBOOLE-0R4 n1 +NAT-1K1 \<two>\<^sub>M"
              then obtain n1 where
                [ty]:"n1 be NatNAT-1M1" and 
                A3: "x =XBOOLE-0R4 <*FINSEQ-1K10 n1*> & y =XBOOLE-0R4 n1 +NAT-1K1 \<two>\<^sub>M"
                 sorry
              assume Given: " ex n2 be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n2*> & z =XBOOLE-0R4 n2 +NAT-1K1 \<two>\<^sub>M"
              then obtain n2 where
                [ty]:"n2 be NatNAT-1M1" and 
                A4: "x =XBOOLE-0R4 <*FINSEQ-1K10 n2*> & z =XBOOLE-0R4 n2 +NAT-1K1 \<two>\<^sub>M"
                 sorry
              have "(<*FINSEQ-1K10 n1*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n1"
                using finseq_1_def_8 sorry
              thus "y =XBOOLE-0R4 z"
                using A3 A4 finseq_1_def_8 sorry
            qed
            thus "y =XBOOLE-0R4 z"
              using A2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 ?IT implies ( ex y be objectHIDDENM1 st ?F(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 elementary-treeTREES-1K2 n implies  not ( for y be objectHIDDENM1 holds  not (x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M)))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A6: "x inHIDDENR3 ?IT"
            have A7: "x inHIDDENR3 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n } implies ( ex y be setHIDDENM2 st x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M))"
            proof(rule impI)
              assume "x inHIDDENR3 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n }"
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A8: "x =HIDDENR1 <*FINSEQ-1K10 k*>"and "k <XXREAL-0R3 n"
                 sorry
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = k +NAT-1K1 \<two>\<^sub>M"
                 sorry
              show " ex y be setHIDDENM2 st x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M)"
              proof(rule bexI[of _ "y"])
                show "x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M)"
                  using A8 sorry
              qed "sorry"
            qed
            have "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies ( ex y be setHIDDENM2 st x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M))"
            proof(rule impI)
              assume A9: "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = \<one>\<^sub>M"
                 sorry
              show " ex y be setHIDDENM2 st x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M)"
              proof(rule bexI[of _ "y"])
                show "x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M)"
                  using A9 tarski_def_1 sorry
              qed "sorry"
            qed
            thus " not ( for y be objectHIDDENM1 holds  not (x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<two>\<^sub>M)))"
              using A6 A7 xboole_0_def_3 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A10: "domRELAT-1K1 f =XBOOLE-0R4 ?IT & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?IT implies ?F(x,f .FUNCT-1K1 x))"
          using classes1_sch_1 A5 sorry
        have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 elementary-treeTREES-1K2 n & rngRELAT-1K2 f =HIDDENR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))"
        proof(rule conjMI,rule conjMI)
          show "f be one-to-oneFUNCT-1V2"
          proof-
            have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & (y inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y) implies x =HIDDENR1 y"
            proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A11: "x inHIDDENR3 domRELAT-1K1 f"
                and A12: "y inHIDDENR3 domRELAT-1K1 f"
                and A13: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
              have A14: "x =HIDDENR1 {}XBOOLE-0K1 & f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & f .FUNCT-1K1 x =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M)"
                using A10 A11 sorry
              have A15: "y =HIDDENR1 {}XBOOLE-0K1 & f .FUNCT-1K1 y =XBOOLE-0R4 \<one>\<^sub>M or ( ex n be NatNAT-1M1 st y =HIDDENR1 <*FINSEQ-1K10 n*> & f .FUNCT-1K1 y =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M)"
                using A10 A12 sorry
              have A16: "x =HIDDENR1 {}XBOOLE-0K1 & f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M implies (( ex n be NatNAT-1M1 st y =HIDDENR1 <*FINSEQ-1K10 n*> & f .FUNCT-1K1 y =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M) implies  False )"
              proof(rule impMI ,rule impI,rule impI)
                assume "x =HIDDENR1 {}XBOOLE-0K1"
                  and A17: "f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
                assume Given: " ex n be NatNAT-1M1 st y =HIDDENR1 <*FINSEQ-1K10 n*> & f .FUNCT-1K1 y =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M"
                then obtain n where
                  [ty]:"n be NatNAT-1M1" and 
                  "y =HIDDENR1 <*FINSEQ-1K10 n*>"and A18: "f .FUNCT-1K1 y =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M"
                   sorry
                have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                  using A13 A17 A18 sorry
                thus " False "
                   sorry
              qed
              have "y =HIDDENR1 {}XBOOLE-0K1 & f .FUNCT-1K1 y =XBOOLE-0R4 \<one>\<^sub>M implies (( ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & f .FUNCT-1K1 x =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M) implies  False )"
              proof(rule impMI ,rule impI,rule impI)
                assume "y =HIDDENR1 {}XBOOLE-0K1"
                  and A19: "f .FUNCT-1K1 y =XBOOLE-0R4 \<one>\<^sub>M"
                assume Given: " ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & f .FUNCT-1K1 x =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M"
                then obtain n where
                  [ty]:"n be NatNAT-1M1" and 
                  "x =HIDDENR1 <*FINSEQ-1K10 n*>"and A20: "f .FUNCT-1K1 x =XBOOLE-0R4 n +NAT-1K1 \<two>\<^sub>M"
                   sorry
                have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                  using A13 A19 A20 sorry
                thus " False "
                   sorry
              qed
              thus "x =HIDDENR1 y"
                using A13 A14 A15 A16 sorry
            qed "sorry"
            thus "f be one-to-oneFUNCT-1V2"
              using funct_1_def_4 sorry
          qed
          show "domRELAT-1K1 f =XBOOLE-0R4 elementary-treeTREES-1K2 n"
            using A10 sorry
          have "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 rngRELAT-1K2 f"
          proof(rule conjMI)
            show "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 f"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A21: "y inHIDDENR3 domRELAT-1K1 f"and A22: "x =HIDDENR1 f .FUNCT-1K1 y"
                  using funct_1_def_3 sorry
                have "\<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 n"
                  using nat_1_th_11 sorry
                then have A23: "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                  using finseq_1_th_1 sorry
                have "( ex k be NatNAT-1M1 st y =HIDDENR1 <*FINSEQ-1K10 k*> & x =HIDDENR1 k +NAT-1K1 \<two>\<^sub>M) implies x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                proof(rule impI)
                  assume Given: " ex k be NatNAT-1M1 st y =HIDDENR1 <*FINSEQ-1K10 k*> & x =HIDDENR1 k +NAT-1K1 \<two>\<^sub>M"
                  then obtain k where
                    [ty]:"k be NatNAT-1M1" and 
                    A24: "y =HIDDENR1 <*FINSEQ-1K10 k*>"and A25: "x =HIDDENR1 k +NAT-1K1 \<two>\<^sub>M"
                     sorry
                  have "y inHIDDENR3 {<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 n } or y inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
                    using A10 A21 xboole_0_def_3 sorry
                  then obtain l where
                    [ty]:"l be NatNAT-1M1" and 
                    A26: "y =HIDDENR1 <*FINSEQ-1K10 l*> & l <XXREAL-0R3 n"
                    using A24 tarski_def_1 sorry
                  have "(<*FINSEQ-1K10 k*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k & (<*FINSEQ-1K10 l*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 l"
                    using finseq_1_def_8 sorry
                  then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                    using A24 A26 nat_1_th_13 sorry
                  then have "\<one>\<^sub>M +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M & (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                    using xreal_1_th_7 sorry
                  thus "x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                    using A25 finseq_1_th_1 sorry
                qed
                thus "x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A10 A21 A22 A23 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies x inHIDDENR3 rngRELAT-1K2 f"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A27: "x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
              then obtain k where 
                [ty]:"k be NatNAT-1M1" and kDef:"k = x"
                 sorry
              have A28: "\<one>\<^sub>M <=XXREAL-0R1 k"
                using A27 finseq_1_th_1 sorry
              have A29: "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                using A27 finseq_1_th_1 sorry
              have "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
                using tarski_def_1 sorry
              then have A30: "{}XBOOLE-0K1 inTARSKIR2 ?IT"
                using xboole_0_def_3 sorry
              then have "?F({}XBOOLE-0K1,f .FUNCT-1K1 {}XBOOLE-0K1)"
                using A10 sorry
              then have A31: "\<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
                using A10 A30 funct_1_def_3 sorry
              have "\<one>\<^sub>M <XXREAL-0R3 k implies k inTARSKIR2 rngFUNCT-1K2 f"
              proof(rule impI)
                assume "\<one>\<^sub>M <XXREAL-0R3 k"
                then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
                  using nat_1_th_13 sorry
                then obtain m where
                  [ty]:"m be NatNAT-1M1" and 
                  A32: "k =XBOOLE-0R4 \<two>\<^sub>M +XCMPLX-0K2 m"
                  using nat_1_th_10 sorry
                have 
                  [ty]:"m be NatNAT-1M1"
                   sorry
                have "(\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 m =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 m)"
                   sorry
                then have "\<one>\<^sub>M +XCMPLX-0K2 m <=XXREAL-0R1 n"
                  using A29 A32 xreal_1_th_6 sorry
                then have "m <XXREAL-0R3 n"
                  using nat_1_th_13 sorry
                then have "<*FINSEQ-1K10 m*> inTARSKIR2 {<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 n }"
                   sorry
                then have A33: "<*FINSEQ-1K10 m*> inTARSKIR2 ?IT"
                  using xboole_0_def_3 sorry
                then have "?F(<*FINSEQ-1K10 m*>,f .FUNCT-1K1 (<*FINSEQ-1K10 m*>))"
                  using A10 sorry
                then have "k =XBOOLE-0R4 f .FUNCT-1K1 (<*FINSEQ-1K10 m*>)"
                  using A1 A32 A33 sorry
                thus "k inTARSKIR2 rngFUNCT-1K2 f"
                  using A10 A33 funct_1_def_3 sorry
              qed
              thus "x inHIDDENR3 rngRELAT-1K2 f"
                using A28 A31 xxreal_0_th_1 sorry
            qed "sorry"
            thus "SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 rngRELAT-1K2 f"
              using tarski_def_3 sorry
          qed
          thus "rngRELAT-1K2 f =HIDDENR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
            using xboole_0_def_10 sorry
        qed
        thus "(elementary-treeTREES-1K2 n,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))are-equipotentTARSKIR3"
          using bexI[of _ "f"] wellord2_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "elementary-treeTREES-1K2 n be finiteFINSET-1V1"
      using card_1_th_38 sorry
  qed
qed "sorry"

mtheorem trees_1_th_28:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <XXREAL-0R3 n implies <*FINSEQ-1K10 k*> inTARSKIR2 elementary-treeTREES-1K2 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <XXREAL-0R3 n implies <*FINSEQ-1K10 k*> inTARSKIR2 elementary-treeTREES-1K2 n"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "k <XXREAL-0R3 n"
    then have "<*FINSEQ-1K10 k*> inTARSKIR2 {<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 n }"
       sorry
    thus "<*FINSEQ-1K10 k*> inTARSKIR2 elementary-treeTREES-1K2 n"
      using xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_29:
"elementary-treeTREES-1K2 (0NUMBERSK6) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have "{<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule impI)
    let ?x = "the ElementSUBSET-1M1-of {<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 0NUMBERSK6 }"
    assume "{<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1"
    then have "?x inTARSKIR2 {<*FINSEQ-1K10 j*> where j be NatNAT-1M1 : j <XXREAL-0R3 0NUMBERSK6 }"
       sorry
    then have " ex k be NatNAT-1M1 st ?x =XBOOLE-0R4 <*FINSEQ-1K10 k*> & k <XXREAL-0R3 0NUMBERSK6"
       sorry
    thus " False "
       sorry
  qed
  thus "elementary-treeTREES-1K2 (0NUMBERSK6) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
     sorry
qed

mtheorem trees_1_th_30:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 elementary-treeTREES-1K2 n implies p =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex k be NatNAT-1M1 st k <XXREAL-0R3 n & p =FINSEQ-1R1 <*FINSEQ-1K10 k*>)"
proof-
  have " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 elementary-treeTREES-1K2 n implies  not ( not p =FINSEQ-1R1 {}XBOOLE-0K1 & ( for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 n & p =FINSEQ-1R1 <*FINSEQ-1K10 k*>)))"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume "p inTARSKIR2 elementary-treeTREES-1K2 n"
    then have A1: "p inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } or p inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n }"
      using xboole_0_def_3 sorry
    have "p inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n } implies ( ex k be NatNAT-1M1 st p =FINSEQ-1R1 <*FINSEQ-1K10 k*> & k <XXREAL-0R3 n)"
       sorry
    thus " not ( not p =FINSEQ-1R1 {}XBOOLE-0K1 & ( for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 n & p =FINSEQ-1R1 <*FINSEQ-1K10 k*>)))"
      using A1 tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_1_def_5 ("LeavesTREES-1K3  _ " [164]164 ) where
  mlet "T be TreeTREES-1M1"
"func LeavesTREES-1K3 T \<rightarrow> SubsetSUBSET-1M2-of T means
  \<lambda>it.  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 it iff p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of T st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 it iff p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)"
    proof-
      have " ex tVar8 be SubsetSUBSET-1M2-of T st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 tVar8 implies p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)) & (p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q) implies p inTARSKIR2 tVar8)"
      proof-
        let ?X = "\<lambda>Lamb1.  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds Lamb1 =HIDDENR1 p implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 T implies  not p is-a-proper-prefix-ofTREES-1R3 q)"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 T & ?X(x)"
          using xboole_0_sch_1 sorry
        have "X c=TARSKIR1 T"
          using A1 sorry
        then have 
          [ty]:"X be SubsetSUBSET-1M2-of T"
           sorry
        show " ex tVar8 be SubsetSUBSET-1M2-of T st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 tVar8 implies p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)) & (p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q) implies p inTARSKIR2 tVar8)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impMI ,rule impI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          show "p inTARSKIR2 X implies p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)"
            using A1 sorry
          assume A2: "p inTARSKIR2 T"
            and A3: " not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)"
          have " for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =FINSEQ-1R1 r implies ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 T implies  not r is-a-proper-prefix-ofTREES-1R3 q)"
            using A3 sorry
          thus "p inTARSKIR2 X"
            using A1 A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of T holds  for it2 be SubsetSUBSET-1M2-of T holds ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 it1 iff p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 it2 iff p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)) implies it1 =HIDDENR1 it2"
    proof-
      have " for L1 be SubsetSUBSET-1M2-of T holds  for L2 be SubsetSUBSET-1M2-of T holds ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 L1 iff p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 L2 iff p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)) implies L1 =HIDDENR1 L2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix L1 assume [ty]: "L1 be SubsetSUBSET-1M2-of T"
        fix L2 assume [ty]: "L2 be SubsetSUBSET-1M2-of T"
        assume A4: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 L1 iff p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)"
          and A5: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 L2 iff p inTARSKIR2 T &  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)"
        have A6: "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
          using trees_1_def_3 sorry
        then have A7: "L1 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
           sorry
        have A8: "L2 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
          using A6 sorry
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 L1 implies x inHIDDENR3 L2) & (x inHIDDENR3 L2 implies x inHIDDENR3 L1)"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 L1 implies x inHIDDENR3 L2"
          proof(rule impI)
            assume A9: "x inHIDDENR3 L1"
            then obtain p where 
              [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and pDef:"p = x"
              using A7 finseq_1_def_11 sorry
            have " not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)"
              using A4 A9 sorry
            thus "x inHIDDENR3 L2"
              using A5 A9 sorry
          qed
          assume A10: "x inHIDDENR3 L2"
          then obtain p where 
            [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and pDef:"p = x"
            using A8 finseq_1_def_11 sorry
          have " not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q inTARSKIR2 T & p is-a-proper-prefix-ofTREES-1R3 q)"
            using A5 A10 sorry
          thus "x inHIDDENR3 L1"
            using A4 A10 sorry
        qed "sorry"
        thus "L1 =HIDDENR1 L2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef trees_1_def_6 (" _  |TREES-1K4  _ " [200,200]200 ) where
  mlet "T be TreeTREES-1M1", "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
"assume p inTARSKIR2 T func T  |TREES-1K4 p \<rightarrow> TreeTREES-1M1 means
  \<lambda>it.  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
proof-
  (*existence*)
    show "p inTARSKIR2 T implies ( ex it be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T)"
    proof(rule impI)
      assume Assume: "p inTARSKIR2 T"
      have A11: "p inTARSKIR2 T"
        using Assume sorry
      show " ex it be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
      proof-
        have " ex tVar9 be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 tVar9 implies p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T) & (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T implies q inTARSKIR2 tVar9)"
        proof-
          let ?X = "\<lambda>Lamb1.  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds Lamb1 =HIDDENR1 q implies p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
          obtain X where
            [ty]:"X be setHIDDENM2" and 
            A12: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3 & ?X(x)"
            using xboole_0_sch_1 sorry
          have "<*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3 & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds <*>FINSEQ-1K7 NATNUMBERSK1 =FINSEQ-1R1 q implies p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T)"
            using A11 finseq_1_th_34 finseq_1_def_11 sorry
          then have 
            [ty]:"X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
            using A12 sorry
          have A13: "X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
            using A12 sorry
          have A14: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 X implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
          proof(rule ballI,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume A15: "q inTARSKIR2 X"
            show "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 q implies x inHIDDENR3 X"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 ProperPrefixesTREES-1K1 q"
                then obtain r where
                  [ty]:"r be FinSequenceFINSEQ-1M1" and 
                  A16: "x =HIDDENR1 r"and A17: "r is-a-proper-prefix-ofTREES-1R3 q"
                  using trees_1_def_2 sorry
                have "r is-a-prefix-ofTREES-1R2 q"
                  using A17 sorry
                then have A18: " ex n be NatNAT-1M1 st r =FUNCT-1R1 q  |RELAT-1K8 SegFINSEQ-1K2 n"
                   sorry
                then have 
                  [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  using finseq_1_th_18 sorry
                obtain s where
                  [ty]:"s be FinSequenceFINSEQ-1M1" and 
                  A19: "q =FINSEQ-1R1 r ^FINSEQ-1K8 s"
                  using A18 finseq_1_th_80 sorry
                have A20: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
                  using A12 A15 sorry
                have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =FINSEQ-1R1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)^FINSEQ-1K8 s"
                  using A19 finseq_1_th_32 sorry
                then have "r inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3 & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds r =FINSEQ-1R1 q implies p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T)"
                  using A20 trees_1_th_21 finseq_1_def_11 sorry
                thus "x inHIDDENR3 X"
                  using A12 A16 sorry
              qed "sorry"
              thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                using tarski_def_3 sorry
            qed
          qed "sorry"
          have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 X & n <=XXREAL-0R1 k implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            fix k assume [ty]: "k be NatNAT-1M1"
            fix n assume [ty]: "n be NatNAT-1M1"
            assume A21: "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 X"
              and A22: "n <=XXREAL-0R1 k"
            obtain kk nn where 
              [ty]:"kk be ElementSUBSET-1M1-of NATNUMBERSK1" and kkDef:"kk = k" and
              [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
              using ordinal1_def_12 sorry
            have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> kk*>)) inTARSKIR2 T"
              using A12 A21 sorry
            then have "(p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T"
              using finseq_1_th_32 sorry
            then have "(p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
              using A22 trees_1_def_3 sorry
            then have "q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> nn*>) inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3 & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds r =FINSEQ-1R1 q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> nn*>) implies p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r inTARSKIR2 T)"
              using finseq_1_th_32 finseq_1_def_11 sorry
            thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
              using A12 sorry
          qed "sorry"
          then have 
            [ty]:"X be TreeTREES-1M1"
            using A13 A14 trees_1_def_3 sorry
          show " ex tVar9 be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 tVar9 implies p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T) & (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T implies q inTARSKIR2 tVar9)"
          proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            show "q inTARSKIR2 X implies p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
              using A12 sorry
            assume "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
            then have "q inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3 & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q =FINSEQ-1R1 r implies p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r inTARSKIR2 T)"
              using finseq_1_def_11 sorry
            thus "q inTARSKIR2 X"
              using A12 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p inTARSKIR2 T implies ( for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it1 iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it2 iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p inTARSKIR2 T"
      have A11: "p inTARSKIR2 T"
        using Assume sorry
      show " for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it1 iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it2 iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T) implies it1 =HIDDENR1 it2"
      proof-
        have " for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 T1 iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 T2 iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T) implies T1 =HIDDENR1 T2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix T1 assume [ty]: "T1 be TreeTREES-1M1"
          fix T2 assume [ty]: "T2 be TreeTREES-1M1"
          assume A23: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 T1 iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
            and A24: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 T2 iff p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
          have " for x be objectHIDDENM1 holds (x inHIDDENR3 T1 implies x inHIDDENR3 T2) & (x inHIDDENR3 T2 implies x inHIDDENR3 T1)"
          proof(rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 T1 implies x inHIDDENR3 T2"
            proof(rule impI)
              assume A25: "x inHIDDENR3 T1"
              then obtain q where 
                [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
                using trees_1_th_19 sorry
              have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
                using A23 A25 sorry
              thus "x inHIDDENR3 T2"
                using A24 sorry
            qed
            assume A26: "x inHIDDENR3 T2"
            then obtain q where 
              [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
              using trees_1_th_19 sorry
            have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
              using A24 A26 sorry
            thus "x inHIDDENR3 T1"
              using A23 sorry
          qed "sorry"
          thus "T1 =HIDDENR1 T2"
            using tarski_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem trees_1_th_31:
" for T be TreeTREES-1M1 holds T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1 =XBOOLE-0R4 T"
proof-
  have " for T be TreeTREES-1M1 holds T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1 =XBOOLE-0R4 T"
  proof(rule ballI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    have A1: "<*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 T"
      using trees_1_th_22 sorry
    have "T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1 c=TARSKIR1 T & T c=TARSKIR1 T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1"
    proof(rule conjMI)
      show "T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1 c=TARSKIR1 T"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1 implies x inHIDDENR3 T"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1"
          then obtain p where 
            [ty]:"p be ElementTREES-1M2-of T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1" and pDef:"p = x"
             sorry
          have "{}XBOOLE-0K1 ^FINSEQ-1K8 p =FINSEQ-1R1 p"
            using finseq_1_th_34 sorry
          thus "x inHIDDENR3 T"
            using A1 trees_1_def_6 sorry
        qed "sorry"
        thus "T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1 c=TARSKIR1 T"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 T implies x inHIDDENR3 T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 T"
        then obtain p where 
          [ty]:"p be ElementTREES-1M2-of T" and pDef:"p = x"
           sorry
        have "{}XBOOLE-0K1 ^FINSEQ-1K8 p =FINSEQ-1R1 p"
          using finseq_1_th_34 sorry
        thus "x inHIDDENR3 T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1"
          using A1 trees_1_def_6 sorry
      qed "sorry"
      thus "T c=TARSKIR1 T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1"
        using tarski_def_3 sorry
    qed
    thus "T  |TREES-1K4 <*>FINSEQ-1K7 NATNUMBERSK1 =XBOOLE-0R4 T"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_cl_7:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1", "p be ElementTREES-1M2-of T"
"cluster T  |TREES-1K4 p as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "T  |TREES-1K4 p be finiteFINSET-1V1"
  proof-
    obtain t where
      [ty]:"t be FunctionFUNCT-1M1" and 
      A1: "rngFUNCT-1K2 t =XBOOLE-0R4 T"and A2: "domRELAT-1K1 t inTARSKIR2 omegaORDINAL1K4"
      using finset_1_def_1 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st t .FUNCT-1K1 Lamb1 =XBOOLE-0R4 q & (( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st Lamb2 =HIDDENR1 r & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) or ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q <>HIDDENR2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & Lamb2 =HIDDENR1 <*>FINSEQ-1K7 NATNUMBERSK1)"
    have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 t implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 t implies  not ( for y be objectHIDDENM1 holds  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st t .FUNCT-1K1 x =XBOOLE-0R4 q & (( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st y =HIDDENR1 r & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) or ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q <>HIDDENR2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & y =HIDDENR1 <*>FINSEQ-1K7 NATNUMBERSK1)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 t"
        then have "t .FUNCT-1K1 x inTARSKIR2 T"
          using A1 funct_1_def_3 sorry
        then obtain q where 
          [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = t .FUNCT-1K1 x"
          using trees_1_th_19 sorry
        have "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies  not ( for y be objectHIDDENM1 holds  not ?P(x,y))"
           sorry
        thus " not ( for y be objectHIDDENM1 holds  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st t .FUNCT-1K1 x =XBOOLE-0R4 q & (( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st y =HIDDENR1 r & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) or ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q <>HIDDENR2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & y =HIDDENR1 <*>FINSEQ-1K7 NATNUMBERSK1)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A4: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 t & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 t implies ?P(x,f .FUNCT-1K1 x))"
      using classes1_sch_1 A3 sorry
    have "T  |TREES-1K4 p be finiteFINSET-1V1"
    proof-
      have "rngFUNCT-1K2 f c=TARSKIR1 T  |TREES-1K4 p & (T  |TREES-1K4 p c=TARSKIR1 rngFUNCT-1K2 f & domRELAT-1K1 f inTARSKIR2 omegaORDINAL1K4)"
      proof(rule conjMI,rule conjMI)
        show "rngFUNCT-1K2 f c=TARSKIR1 T  |TREES-1K4 p"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies ( not x inHIDDENR3 T  |TREES-1K4 p implies  False )"
          proof(rule ballI,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A5: "y inHIDDENR3 domRELAT-1K1 f"and A6: "x =HIDDENR1 f .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            obtain q where
              [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
              A7: "t .FUNCT-1K1 y =XBOOLE-0R4 q"and A8: "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st x =HIDDENR1 r & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) or ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q <>HIDDENR2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =HIDDENR1 <*>FINSEQ-1K7 NATNUMBERSK1"
              using A4 A5 A6 sorry
            assume A9: " not x inHIDDENR3 T  |TREES-1K4 p"
            have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> <*>FINSEQ-1K7 NATNUMBERSK1 =FINSEQ-1R1 p & q inTARSKIR2 T"
              using A1 A4 A5 A7 finseq_1_th_34 funct_1_def_3 sorry
            thus " False "
              using A8 A9 trees_1_def_6 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 T  |TREES-1K4 p"
            using tarski_def_3 sorry
        qed
        show "T  |TREES-1K4 p c=TARSKIR1 rngFUNCT-1K2 f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 T  |TREES-1K4 p implies x inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A10: "x inHIDDENR3 T  |TREES-1K4 p"
            then obtain q where 
              [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
              using trees_1_th_19 sorry
            have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
              using A10 trees_1_def_6 sorry
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A11: "y inHIDDENR3 domRELAT-1K1 t"and A12: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =XBOOLE-0R4 t .FUNCT-1K1 y"
              using A1 funct_1_def_3 sorry
            have "?P(y,f .FUNCT-1K1 y)"
              using A4 A11 sorry
            then have "x =HIDDENR1 f .FUNCT-1K1 y"
              using A12 finseq_1_th_33 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 f"
              using A4 A11 funct_1_def_3 sorry
          qed "sorry"
          thus "T  |TREES-1K4 p c=TARSKIR1 rngFUNCT-1K2 f"
            using tarski_def_3 sorry
        qed
        show "domRELAT-1K1 f inTARSKIR2 omegaORDINAL1K4"
          using A2 A4 sorry
      qed
      then have "rngRELAT-1K2 f =HIDDENR1 T  |TREES-1K4 p & domRELAT-1K1 f inTARSKIR2 omegaORDINAL1K4"
        using xboole_0_def_10 sorry
      thus "T  |TREES-1K4 p be finiteFINSET-1V1"
        using bexI[of _ "f"] finset_1_def_1 sorry
    qed
    thus "T  |TREES-1K4 p be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mdef trees_1_def_7 ("LeafTREES-1M3-of  _ " [70]70 ) where
  mlet "T be TreeTREES-1M1"
"assume LeavesTREES-1K3 T <>HIDDENR2 {}XBOOLE-0K1 mode LeafTREES-1M3-of T \<rightarrow> ElementTREES-1M2-of T means
  (\<lambda>it. it inTARSKIR2 LeavesTREES-1K3 T)"
proof-
  (*existence*)
    show "LeavesTREES-1K3 T <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be ElementTREES-1M2-of T st it inTARSKIR2 LeavesTREES-1K3 T)"
    proof(rule impI)
      assume Assume: "LeavesTREES-1K3 T <>HIDDENR2 {}XBOOLE-0K1"
      have A1: "LeavesTREES-1K3 T <>HIDDENR2 {}XBOOLE-0K1"
        using Assume sorry
      show " ex it be ElementTREES-1M2-of T st it inTARSKIR2 LeavesTREES-1K3 T"
      proof-
        have " ex tVar11 be ElementTREES-1M2-of T st tVar11 inTARSKIR2 LeavesTREES-1K3 T"
        proof-
          let ?x = "the ElementSUBSET-1M1-of LeavesTREES-1K3 T"
          obtain x where 
            [ty]:"x be ElementTREES-1M2-of T" and xDef:"x = ?x"
            using A1 tarski_def_3 sorry
          show " ex tVar11 be ElementTREES-1M2-of T st tVar11 inTARSKIR2 LeavesTREES-1K3 T"
          proof(rule bexI[of _ "x"])
            show "x inTARSKIR2 LeavesTREES-1K3 T"
              using A1 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef trees_1_def_8 ("SubtreeTREES-1M4-of  _ " [70]70 ) where
  mlet "T be TreeTREES-1M1"
"mode SubtreeTREES-1M4-of T \<rightarrow> TreeTREES-1M1 means
  (\<lambda>it.  ex p be ElementTREES-1M2-of T st it =XBOOLE-0R4 T  |TREES-1K4 p)"
proof-
  (*existence*)
    show " ex it be TreeTREES-1M1 st  ex p be ElementTREES-1M2-of T st it =XBOOLE-0R4 T  |TREES-1K4 p"
    proof-
      have " ex tVar12 be TreeTREES-1M1 st  ex tVar13 be ElementTREES-1M2-of T st T  |TREES-1K4 tVar13 =XBOOLE-0R4 T  |TREES-1K4 tVar13"
      proof-
        let ?p = "the ElementTREES-1M2-of T"
        show " ex tVar12 be TreeTREES-1M1 st  ex tVar13 be ElementTREES-1M2-of T st T  |TREES-1K4 tVar13 =XBOOLE-0R4 T  |TREES-1K4 tVar13"
        proof(rule bexI[of _ "T  |TREES-1K4 ?p"])
          show " ex tVar13 be ElementTREES-1M2-of T st T  |TREES-1K4 tVar13 =XBOOLE-0R4 T  |TREES-1K4 tVar13"
          proof(rule bexI[of _ "?p"])
            show "T  |TREES-1K4 (the ElementTREES-1M2-of T) =XBOOLE-0R4 T  |TREES-1K4 (the ElementTREES-1M2-of T)"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

reserve t for "ElementTREES-1M2-of T"
mdef trees_1_def_9 (" _ with-replacementTREES-1K5'( _ , _ ')" [164,0,0]164 ) where
  mlet "T be TreeTREES-1M1", "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1", "T1 be TreeTREES-1M1"
"assume p inTARSKIR2 T func T with-replacementTREES-1K5(p,T1) \<rightarrow> TreeTREES-1M1 means
  \<lambda>it.  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
proof-
  (*existence*)
    show "p inTARSKIR2 T implies ( ex it be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r))"
    proof(rule impI)
      assume Assume: "p inTARSKIR2 T"
      have A1: "p inTARSKIR2 T"
        using Assume sorry
      show " ex it be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
      proof-
        have " ex tVar14 be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 tVar14 implies q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies q inTARSKIR2 tVar14)"
        proof-
          obtain p9 where 
            [ty]:"p9 be ElementTREES-1M2-of T" and p9Def:"p9 = p"
            using A1 sorry
          have " not p is-a-proper-prefix-ofTREES-1R3 p9"
             sorry
          then have "p inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
             sorry
          then obtain X where 
            [ty]:"X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and XDef:"X = ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
             sorry
          have A2: " for x be setHIDDENM2 holds x inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } implies (x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 & x inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3) & x inTARSKIR2 T"
          proof-
            have " for x be setHIDDENM2 holds x inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } implies x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 & (x inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3 & x inTARSKIR2 T)"
            proof(rule ballI,rule impI,rule conjMI)
              fix x assume [ty]: "x be setHIDDENM2"
              assume "x inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
              then have A3: " ex t be ElementTREES-1M2-of T st x =XBOOLE-0R4 t &  not p is-a-proper-prefix-ofTREES-1R3 t"
                 sorry
              thus "x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                 sorry
              show "x inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3 & x inTARSKIR2 T"
                using A3 finseq_1_def_11 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have "X be Tree-likeTREES-1V1"
          proof-
            have "X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 X implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 X & n <=XXREAL-0R1 k implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X))"
            proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
              show "X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 X"
                  then have A4: "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } or x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
                    using xboole_0_def_3 sorry
                  have "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } implies x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  proof(rule impI)
                    assume "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
                    then have " ex s be ElementTREES-1M2-of T1 st x =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                       sorry
                    thus "x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                       sorry
                  qed
                  thus "x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                    using A2 A4 finseq_1_def_11 sorry
                qed "sorry"
                thus "X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                  using tarski_def_3 sorry
              qed
              show " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 X implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
              proof(rule ballI,rule impI)
                fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                assume A5: "q inTARSKIR2 X"
                have A6: "q inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                proof(rule impI)
                  assume "q inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
                  then have A7: " ex t be ElementTREES-1M2-of T st q =FINSEQ-1R1 t &  not p is-a-proper-prefix-ofTREES-1R3 t"
                     sorry
                  then have A8: "ProperPrefixesTREES-1K1 q c=TARSKIR1 T"
                    using trees_1_def_3 sorry
                  show "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 q implies x inHIDDENR3 X"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A9: "x inHIDDENR3 ProperPrefixesTREES-1K1 q"
                      then obtain p1 where
                        [ty]:"p1 be FinSequenceFINSEQ-1M1" and 
                        A10: "x =HIDDENR1 p1"and A11: "p1 is-a-proper-prefix-ofTREES-1R3 q"
                        using trees_1_def_2 sorry
                      have 
                        [ty]:"p1 be ElementTREES-1M2-of T"
                        using A8 A9 A10 sorry
                      have " not p is-a-proper-prefix-ofTREES-1R3 p1"
                        using A7 A11 xboole_1_th_56 sorry
                      then have "x inHIDDENR3 {s1 where s1 be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 s1 }"
                        using A10 sorry
                      thus "x inHIDDENR3 X"
                        using xboole_0_def_3 sorry
                    qed "sorry"
                    thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                      using tarski_def_3 sorry
                  qed
                qed
                have "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } implies ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                proof(rule impI)
                  assume "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
                  then obtain s where
                    [ty]:"s be ElementTREES-1M2-of T1" and 
                    A12: "q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                     sorry
                  show "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 q implies x inHIDDENR3 X"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A13: "x inHIDDENR3 ProperPrefixesTREES-1K1 q"
                      then obtain r where 
                        [ty]:"r be FinSequenceFINSEQ-1M1" and rDef:"r = x"
                        using trees_1_th_11 sorry
                      have "r is-a-proper-prefix-ofTREES-1R3 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                        using A12 A13 trees_1_th_12 sorry
                      then have "r is-a-prefix-ofTREES-1R2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                         sorry
                      then obtain r1 where
                        [ty]:"r1 be FinSequenceFINSEQ-1M1" and 
                        A14: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s =FINSEQ-1R1 r ^FINSEQ-1K8 r1"
                        using trees_1_th_1 sorry
                      have A15: "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r implies r inTARSKIR2 X"
                      proof(rule impI)
                        assume "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 r"
                        then obtain r2 where
                          [ty]:"r2 be FinSequenceFINSEQ-1M1" and 
                          A16: "p ^FINSEQ-1K8 r2 =FINSEQ-1R1 r"
                          using A14 finseq_1_th_47 sorry
                        have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s =FINSEQ-1R1 p ^FINSEQ-1K8 (r2 ^FINSEQ-1K8 r1)"
                          using A14 A16 finseq_1_th_32 sorry
                        then have "s =FINSEQ-1R1 r2 ^FINSEQ-1K8 r1"
                          using finseq_1_th_33 sorry
                        then have A17: "domFINSEQ-1K5 r2 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 r2) & s  |RELAT-1K8 domFINSEQ-1K5 r2 =FUNCT-1R1 r2"
                          using finseq_1_th_21 finseq_1_def_3 sorry
                        then have 
                          [ty]:"r2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                          using finseq_1_th_18 sorry
                        have "r2 is-a-prefix-ofTREES-1R2 s"
                          using A17 sorry
                        then have 
                          [ty]:"r2 be ElementTREES-1M2-of T1"
                          using trees_1_th_20 sorry
                        have "r =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r2"
                          using A16 sorry
                        then have "r inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v where v be ElementTREES-1M2-of T1 :  True  }"
                           sorry
                        thus "r inTARSKIR2 X"
                          using xboole_0_def_3 sorry
                      qed
                      have "lenFINSEQ-1K4 r <=XXREAL-0R1 lenFINSEQ-1K4 p implies r inTARSKIR2 X"
                      proof(rule impI)
                        assume "lenFINSEQ-1K4 r <=XXREAL-0R1 lenFINSEQ-1K4 p"
                        then have " ex r2 be FinSequenceFINSEQ-1M1 st r ^FINSEQ-1K8 r2 =FINSEQ-1R1 p"
                          using A14 finseq_1_th_47 sorry
                        then have A18: "p  |RELAT-1K8 domFINSEQ-1K5 r =FUNCT-1R1 r"
                          using finseq_1_th_21 sorry
                        have A19: "domFINSEQ-1K5 r =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 r)"
                          using finseq_1_def_3 sorry
                        then obtain r3 where 
                          [ty]:"r3 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and r3Def:"r3 = r"
                          using A18 finseq_1_th_18 sorry
                        have A20: "r3 is-a-prefix-ofTREES-1R2 p"
                          using A18 A19 sorry
                        then have A21: " not p is-a-proper-prefix-ofTREES-1R3 r3"
                          using xboole_0_def_8 sorry
                        have 
                          [ty]:"r3 be ElementTREES-1M2-of T"
                          using A1 A20 trees_1_th_20 sorry
                        have "r3 inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
                          using A21 sorry
                        thus "r inTARSKIR2 X"
                          using xboole_0_def_3 sorry
                      qed
                      thus "x inHIDDENR3 X"
                        using A15 sorry
                    qed "sorry"
                    thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                      using tarski_def_3 sorry
                  qed
                qed
                thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 X"
                  using A5 A6 xboole_0_def_3 sorry
              qed "sorry"
              fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              fix k assume [ty]: "k be NatNAT-1M1"
              fix n assume [ty]: "n be NatNAT-1M1"
              assume A22: "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 X"
                and A23: "n <=XXREAL-0R1 k"
              have A24: "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
              proof(rule impI)
                assume "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
                then have A25: " ex s be ElementTREES-1M2-of T st q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 s &  not p is-a-proper-prefix-ofTREES-1R3 s"
                   sorry
                then obtain u where 
                  [ty]:"u be ElementTREES-1M2-of T" and uDef:"u = q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
                  using A23 trees_1_def_3 sorry
                have "p is-a-proper-prefix-ofTREES-1R3 u implies  False "
                proof(rule impI)
                  assume "p is-a-proper-prefix-ofTREES-1R3 u"
                  then have "p is-a-prefix-ofTREES-1R2 q"
                    using trees_1_th_9 sorry
                  thus " False "
                    using A25 trees_1_th_8 sorry
                qed
                then have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
                   sorry
                thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                  using xboole_0_def_3 sorry
              qed
              have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
              proof(rule impI)
                assume "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
                then obtain s where
                  [ty]:"s be ElementTREES-1M2-of T1" and 
                  A26: "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                   sorry
                have A27: "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                proof(rule impI)
                  assume "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
                  then obtain r where
                    [ty]:"r be FinSequenceFINSEQ-1M1" and 
                    A28: "q ^FINSEQ-1K8 r =FINSEQ-1R1 p"
                    using A26 finseq_1_th_47 sorry
                  have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 q ^FINSEQ-1K8 (r ^FINSEQ-1K8 s)"
                    using A26 A28 finseq_1_th_32 sorry
                  then have A29: "<*FINSEQ-1K10 k*> =FINSEQ-1R1 r ^FINSEQ-1K8 s"
                    using finseq_1_th_33 sorry
                  have A30: "r =FINSEQ-1R1 <*FINSEQ-1K10 k*> implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
                  proof(rule impI)
                    assume A31: "r =FINSEQ-1R1 <*FINSEQ-1K10 k*>"
                    then obtain s where 
                      [ty]:"s be ElementTREES-1M2-of T" and sDef:"s = q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
                      using A1 A23 A28 trees_1_def_3 sorry
                    have "p is-a-proper-prefix-ofTREES-1R3 s implies  False "
                    proof(rule impI)
                      assume A32: "p is-a-proper-prefix-ofTREES-1R3 s"
                      have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 k*>)"
                        using A28 A31 finseq_1_th_22 sorry
                      also have "... = lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
                        using finseq_1_th_40 sorry
                      also have "... = lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 n*>)"
                        using finseq_1_th_40 sorry
                      also have "... = lenFINSEQ-1K4 s"
                        using finseq_1_th_22 sorry
                      finally have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 s"
                         sorry
                      thus " False "
                        using A32 card_2_th_102 sorry
                    qed
                    thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
                       sorry
                  qed
                  have "s =FINSEQ-1R1 <*FINSEQ-1K10 k*> & r =FINSEQ-1R1 {}XBOOLE-0K1 implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v where v be ElementTREES-1M2-of T1 :  True  }"
                  proof(rule impMI ,rule impI)
                    assume A33: "s =FINSEQ-1R1 <*FINSEQ-1K10 k*>"
                      and A34: "r =FINSEQ-1R1 {}XBOOLE-0K1"
                    have "s =FINSEQ-1R1 {}XBOOLE-0K1 ^FINSEQ-1K8 s & {}XBOOLE-0K1 =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1"
                      using finseq_1_th_34 sorry
                    then have "{}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T1"
                      using A23 A33 trees_1_def_3 sorry
                    then obtain t where 
                      [ty]:"t be ElementTREES-1M2-of T1" and tDef:"t = <*FINSEQ-1K10 n*>"
                      using finseq_1_th_34 sorry
                    have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t"
                      using A28 A34 finseq_1_th_34 sorry
                    thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v where v be ElementTREES-1M2-of T1 :  True  }"
                       sorry
                  qed
                  thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                    using A29 A30 finseq_1_th_88 xboole_0_def_3 sorry
                qed
                have "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q implies q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                proof(rule impI)
                  assume "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
                  then obtain r where
                    [ty]:"r be FinSequenceFINSEQ-1M1" and 
                    A35: "p ^FINSEQ-1K8 r =FINSEQ-1R1 q"
                    using A26 finseq_1_th_47 sorry
                  have "p ^FINSEQ-1K8 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)) =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                    using A26 A35 finseq_1_th_32 sorry
                  then have A36: "r ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 s"
                    using finseq_1_th_33 sorry
                  then have "domFINSEQ-1K5 r =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 r) & s  |RELAT-1K8 domFINSEQ-1K5 r =FUNCT-1R1 r"
                    using finseq_1_th_21 finseq_1_def_3 sorry
                  then have 
                    [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                    using finseq_1_th_18 sorry
                  obtain t where 
                    [ty]:"t be ElementTREES-1M2-of T1" and tDef:"t = r ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
                    using A23 A36 trees_1_def_3 sorry
                  have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t"
                    using A35 finseq_1_th_32 sorry
                  then have "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v where v be ElementTREES-1M2-of T1 :  True  }"
                     sorry
                  thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                    using xboole_0_def_3 sorry
                qed
                thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                  using A27 sorry
              qed
              thus "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
                using A22 A24 xboole_0_def_3 sorry
            qed "sorry"
            thus "X be Tree-likeTREES-1V1"
              using trees_1_def_3 sorry
          qed
          then have 
            [ty]:"X be TreeTREES-1M1"
             sorry
          show " ex tVar14 be TreeTREES-1M1 st  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 tVar14 implies q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies q inTARSKIR2 tVar14)"
          proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            show "q inTARSKIR2 X implies q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            proof-
              have "q inTARSKIR2 X implies  not ( not (q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q) & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)))"
              proof(rule impI)
                assume A37: "q inTARSKIR2 X"
                have A38: "q inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } implies  not ( not (q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q) & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)))"
                proof(rule impI)
                  assume "q inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
                  then have " ex s be ElementTREES-1M2-of T st q =FINSEQ-1R1 s &  not p is-a-proper-prefix-ofTREES-1R3 s"
                     sorry
                  thus " not ( not (q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q) & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)))"
                     sorry
                qed
                have "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } implies ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
                proof(rule impI)
                  assume "q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
                  then have " ex s be ElementTREES-1M2-of T1 st q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
                     sorry
                  thus " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                     sorry
                qed
                thus " not ( not (q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q) & ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)))"
                  using A37 A38 xboole_0_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            assume A39: "q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            have A40: "q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q implies q inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
               sorry
            have "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies q inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> v where v be ElementTREES-1M2-of T1 :  True  }"
               sorry
            thus "q inTARSKIR2 X"
              using A39 A40 xboole_0_def_3 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p inTARSKIR2 T implies ( for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it1 iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it2 iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p inTARSKIR2 T"
      have A1: "p inTARSKIR2 T"
        using Assume sorry
      show " for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it1 iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 it2 iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) implies it1 =HIDDENR1 it2"
      proof-
        have " for S1 be TreeTREES-1M1 holds  for S2 be TreeTREES-1M1 holds ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 S1 iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 S2 iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) implies S1 =HIDDENR1 S2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix S1 assume [ty]: "S1 be TreeTREES-1M1"
          fix S2 assume [ty]: "S2 be TreeTREES-1M1"
          assume A41: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 S1 iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
            and A42: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 S2 iff q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
          have "S1 c=TARSKIR1 S2 & S2 c=TARSKIR1 S1"
          proof(rule conjMI)
            show "S1 c=TARSKIR1 S2"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 S1 implies x inHIDDENR3 S2"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A43: "x inHIDDENR3 S1"
                then obtain q where 
                  [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
                  using trees_1_th_19 sorry
                have "q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
                  using A41 A43 sorry
                thus "x inHIDDENR3 S2"
                  using A42 sorry
              qed "sorry"
              thus "S1 c=TARSKIR1 S2"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 S2 implies x inHIDDENR3 S1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A44: "x inHIDDENR3 S2"
              then obtain q where 
                [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
                using trees_1_th_19 sorry
              have "q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
                using A42 A44 sorry
              thus "x inHIDDENR3 S1"
                using A41 sorry
            qed "sorry"
            thus "S2 c=TARSKIR1 S1"
              using tarski_def_3 sorry
          qed
          thus "S1 =HIDDENR1 S2"
            using xboole_0_def_10 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem trees_1_th_32:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds p inTARSKIR2 T implies T with-replacementTREES-1K5(p,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
proof-
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds p inTARSKIR2 T implies T with-replacementTREES-1K5(p,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    assume A1: "p inTARSKIR2 T"
    have "T with-replacementTREES-1K5(p,T1) c=TARSKIR1 ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }) & ({t1 where t1 be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }) c=TARSKIR1 T with-replacementTREES-1K5(p,T1)"
    proof(rule conjMI)
      show "T with-replacementTREES-1K5(p,T1) c=TARSKIR1 ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
      proof-
        have "T with-replacementTREES-1K5(p,T1) c=TARSKIR1 ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 T with-replacementTREES-1K5(p,T1) implies x inHIDDENR3 ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A2: "x inHIDDENR3 T with-replacementTREES-1K5(p,T1)"
            then obtain q where 
              [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
              using trees_1_th_19 sorry
            have A3: "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
               sorry
            have "q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 q implies x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
               sorry
            thus "x inHIDDENR3 ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
              using A1 A2 A3 trees_1_def_9 xboole_0_def_3 sorry
          qed "sorry"
          thus "T with-replacementTREES-1K5(p,T1) c=TARSKIR1 ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }) implies x inHIDDENR3 T with-replacementTREES-1K5(p,T1)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 ({t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
        have A5: "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } implies x inHIDDENR3 T with-replacementTREES-1K5(p,T1)"
        proof(rule impI)
          assume "x inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
          then have " ex s be ElementTREES-1M2-of T1 st x =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
             sorry
          thus "x inHIDDENR3 T with-replacementTREES-1K5(p,T1)"
            using A1 trees_1_def_9 sorry
        qed
        have "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } implies x inHIDDENR3 T with-replacementTREES-1K5(p,T1)"
        proof(rule impI)
          assume "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
          then have " ex t be ElementTREES-1M2-of T st x =HIDDENR1 t &  not p is-a-proper-prefix-ofTREES-1R3 t"
             sorry
          thus "x inHIDDENR3 T with-replacementTREES-1K5(p,T1)"
            using A1 trees_1_def_9 sorry
        qed
        thus "x inHIDDENR3 T with-replacementTREES-1K5(p,T1)"
          using A4 A5 xboole_0_def_3 sorry
      qed "sorry"
      thus "({t1 where t1 be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }) c=TARSKIR1 T with-replacementTREES-1K5(p,T1)"
        using tarski_def_3 sorry
    qed
    thus "T with-replacementTREES-1K5(p,T1) =XBOOLE-0R4 ({t1 where t1 be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t1 })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_33:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds p inTARSKIR2 T implies T1 =XBOOLE-0R4 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p"
proof-
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds p inTARSKIR2 T implies T1 =XBOOLE-0R4 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    assume A1: "p inTARSKIR2 T"
    then have A2: "p inTARSKIR2 T with-replacementTREES-1K5(p,T1)"
      using trees_1_def_9 sorry
    have "T1 c=TARSKIR1 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p & (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p c=TARSKIR1 T1"
    proof(rule conjMI)
      show "T1 c=TARSKIR1 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 T1 implies x inHIDDENR3 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 T1"
          then obtain q where 
            [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
            using trees_1_th_19 sorry
          have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T with-replacementTREES-1K5(p,T1)"
            using A1 A3 trees_1_def_9 sorry
          thus "x inHIDDENR3 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p"
            using A2 trees_1_def_6 sorry
        qed "sorry"
        thus "T1 c=TARSKIR1 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p implies x inHIDDENR3 T1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p"
        then obtain q where 
          [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
          using trees_1_th_19 sorry
        have A5: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T with-replacementTREES-1K5(p,T1)"
          using A2 A4 trees_1_def_6 sorry
        have A6: "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T &  not p is-a-proper-prefix-ofTREES-1R3 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q implies q inTARSKIR2 T1"
        proof(rule impMI ,rule impI)
          assume "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T"
            and A7: " not p is-a-proper-prefix-ofTREES-1R3 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
          have "p is-a-prefix-ofTREES-1R2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
            using trees_1_th_1 sorry
          then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =HIDDENR1 p"
            using A7 sorry
          also have "... = p ^FINSEQ-1K8 {}XBOOLE-0K1"
            using finseq_1_th_34 sorry
          finally have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =HIDDENR1 p ^FINSEQ-1K8 {}XBOOLE-0K1"
             sorry
          then have "q =FINSEQ-1R1 {}XBOOLE-0K1"
            using finseq_1_th_33 sorry
          thus "q inTARSKIR2 T1"
            using trees_1_th_22 sorry
        qed
        have "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies q inTARSKIR2 T1"
          using finseq_1_th_33 sorry
        thus "x inHIDDENR3 T1"
          using A1 A5 A6 trees_1_def_9 sorry
      qed "sorry"
      thus "(T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p c=TARSKIR1 T1"
        using tarski_def_3 sorry
    qed
    thus "T1 =XBOOLE-0R4 (T with-replacementTREES-1K5(p,T1)) |TREES-1K4 p"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_cl_8:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1", "t be ElementTREES-1M2-of T", "T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster T with-replacementTREES-1K5(t,T1) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "T with-replacementTREES-1K5(t,T1) be finiteFINSET-1V1"
  proof-
    have A1: "{s where s be ElementTREES-1M2-of T :  not t is-a-proper-prefix-ofTREES-1R3 s } c=TARSKIR1 T"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {s where s be ElementTREES-1M2-of T :  not t is-a-proper-prefix-ofTREES-1R3 s } implies x inHIDDENR3 T"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {s where s be ElementTREES-1M2-of T :  not t is-a-proper-prefix-ofTREES-1R3 s }"
        then have " ex s be ElementTREES-1M2-of T st x =HIDDENR1 s &  not t is-a-proper-prefix-ofTREES-1R3 s"
           sorry
        thus "x inHIDDENR3 T"
           sorry
      qed "sorry"
      thus "{s where s be ElementTREES-1M2-of T :  not t is-a-proper-prefix-ofTREES-1R3 s } c=TARSKIR1 T"
        using tarski_def_3 sorry
    qed
    have "(T1,{t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })are-equipotentTARSKIR3"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st Lamb1 =HIDDENR1 q & Lamb2 =HIDDENR1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 T1 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 T1 implies  not ( for y be objectHIDDENM1 holds  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st x =HIDDENR1 q & y =HIDDENR1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 T1"
          then obtain q where 
            [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and qDef:"q = x"
            using trees_1_th_19 sorry
          have "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =FINSEQ-1R1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
             sorry
          thus " not ( for y be objectHIDDENM1 holds  not ( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st x =HIDDENR1 q & y =HIDDENR1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 T1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 T1 implies ?P(x,f .FUNCT-1K1 x))"
        using classes1_sch_1 A2 sorry
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 T1 & rngRELAT-1K2 f =HIDDENR1 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A4: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
              and A5: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
            have "( ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st x =HIDDENR1 q & f .FUNCT-1K1 x =XBOOLE-0R4 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) & ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st y =HIDDENR1 r & f .FUNCT-1K1 y =XBOOLE-0R4 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
              using A3 A4 sorry
            thus "x =HIDDENR1 y"
              using A5 finseq_1_th_33 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 T1"
          using A3 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } & {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } c=TARSKIR1 rngRELAT-1K2 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A6: "y inHIDDENR3 domRELAT-1K1 f"and A7: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              obtain q where
                [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                A8: "y =HIDDENR1 q"and A9: "f .FUNCT-1K1 y =XBOOLE-0R4 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
                using A3 A6 sorry
              have 
                [ty]:"q be ElementTREES-1M2-of T1"
                using A3 A6 A8 sorry
              have "x =HIDDENR1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
                using A7 A9 sorry
              thus "x inHIDDENR3 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
                 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } implies x inHIDDENR3 rngRELAT-1K2 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
            then obtain s where
              [ty]:"s be ElementTREES-1M2-of T1" and 
              A10: "x =HIDDENR1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s"
               sorry
            have "?P(s,f .FUNCT-1K1 s)"
              using A3 sorry
            thus "x inHIDDENR3 rngRELAT-1K2 f"
              using A3 A10 funct_1_def_3 sorry
          qed "sorry"
          thus "{t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } c=TARSKIR1 rngRELAT-1K2 f"
            using tarski_def_3 sorry
        qed
        thus "rngRELAT-1K2 f =HIDDENR1 {t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }"
          using xboole_0_def_10 sorry
      qed
      thus "(T1,{t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  })are-equipotentTARSKIR3"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    then have "{t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  } be finiteFINSET-1V1"
      using card_1_th_38 sorry
    then have "({v where v be ElementTREES-1M2-of T :  not t is-a-proper-prefix-ofTREES-1R3 v })\\/XBOOLE-0K2 ({t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s where s be ElementTREES-1M2-of T1 :  True  }) be finiteFINSET-1V1"
      using A1 sorry
    thus "T with-replacementTREES-1K5(t,T1) be finiteFINSET-1V1"
      using trees_1_th_32 sorry
  qed
qed "sorry"

reserve w for "FinSequenceFINSEQ-1M1"
mtheorem trees_1_th_34:
" for p be FinSequenceFINSEQ-1M1 holds (ProperPrefixesTREES-1K1 p,domFINSEQ-1K5 p)are-equipotentTARSKIR3"
proof(rule ballI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex w be FinSequenceFINSEQ-1M1 st Lamb1 =HIDDENR1 w & Lamb2 =HIDDENR1 lenFINSEQ-1K4 w +NAT-1K1 \<one>\<^sub>M"
  have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 p implies ( ex y be objectHIDDENM1 st ?P(x,y))"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 p implies ( ex tVar16 be objectHIDDENM1 st  ex tVar17 be FinSequenceFINSEQ-1M1 st x =HIDDENR1 tVar17 & tVar16 =HIDDENR1 lenFINSEQ-1K4 tVar17 +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 ProperPrefixesTREES-1K1 p"
      then obtain q where
        [ty]:"q be FinSequenceFINSEQ-1M1" and 
        A2: "x =HIDDENR1 q"and "q is-a-proper-prefix-ofTREES-1R3 p"
        using trees_1_def_2 sorry
      obtain y where 
        [ty]:"y be setHIDDENM2" and yDef:"y = lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
         sorry
      show " ex tVar16 be objectHIDDENM1 st  ex tVar17 be FinSequenceFINSEQ-1M1 st x =HIDDENR1 tVar17 & tVar16 =HIDDENR1 lenFINSEQ-1K4 tVar17 +NAT-1K1 \<one>\<^sub>M"
      proof(rule bexI[of _ "y"])
        show " ex tVar17 be FinSequenceFINSEQ-1M1 st x =HIDDENR1 tVar17 & y =HIDDENR1 lenFINSEQ-1K4 tVar17 +NAT-1K1 \<one>\<^sub>M"
        proof(rule bexI[of _ "q"])
          show "x =HIDDENR1 q & y =HIDDENR1 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
            using A2 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  obtain f where
    [ty]:"f be FunctionFUNCT-1M1" and 
    A3: "domRELAT-1K1 f =XBOOLE-0R4 ProperPrefixesTREES-1K1 p"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 p implies ?P(x,f .FUNCT-1K1 x)"
    using classes1_sch_1 A1 sorry
  have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 ProperPrefixesTREES-1K1 p & rngRELAT-1K2 f =HIDDENR1 domFINSEQ-1K5 p)"
  proof(rule conjMI,rule conjMI)
    show "f be one-to-oneFUNCT-1V2"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A5: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
          and A6: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
        have "( ex q be FinSequenceFINSEQ-1M1 st x =HIDDENR1 q & f .FUNCT-1K1 x =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M) & ( ex r be FinSequenceFINSEQ-1M1 st y =HIDDENR1 r & f .FUNCT-1K1 x =XBOOLE-0R4 lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M)"
          using A3 A4 A5 A6 sorry
        thus "x =HIDDENR1 y"
          using A3 A5 trees_1_th_4 trees_1_th_18 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    show "domRELAT-1K1 f =XBOOLE-0R4 ProperPrefixesTREES-1K1 p"
      using A3 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 domFINSEQ-1K5 p & domFINSEQ-1K5 p c=TARSKIR1 rngRELAT-1K2 f"
    proof(rule conjMI)
      show "rngFUNCT-1K2 f c=TARSKIR1 domFINSEQ-1K5 p"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 domFINSEQ-1K5 p"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 f"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A7: "y inHIDDENR3 domRELAT-1K1 f"and A8: "x =HIDDENR1 f .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          obtain q where
            [ty]:"q be FinSequenceFINSEQ-1M1" and 
            A9: "y =HIDDENR1 q"and A10: "x =HIDDENR1 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
            using A3 A4 A7 A8 sorry
          have "lenFINSEQ-1K4 q <XXREAL-0R3 lenFINSEQ-1K4 p"
            using A3 A7 A9 trees_1_th_13 sorry
          then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
            using nat_1_th_13 sorry
          then have "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
            using A10 finseq_1_th_1 sorry
          thus "x inHIDDENR3 domFINSEQ-1K5 p"
            using finseq_1_def_3 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 f c=TARSKIR1 domFINSEQ-1K5 p"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 p implies x inHIDDENR3 rngRELAT-1K2 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A11: "x inHIDDENR3 domFINSEQ-1K5 p"
        then have A12: "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
          using finseq_1_def_3 sorry
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = x"
          using A11 sorry
        have A13: "\<one>\<^sub>M <=XXREAL-0R1 n"
          using A12 finseq_1_th_1 sorry
        have A14: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A12 finseq_1_th_1 sorry
        obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A15: "n =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 m"
          using A13 nat_1_th_10 sorry
        have 
          [ty]:"m be NatNAT-1M1"
           sorry
        obtain q where 
          [ty]:"q be FinSequenceFINSEQ-1M1" and qDef:"q = p  |RELAT-1K8 SegFINSEQ-1K2 m"
          using finseq_1_th_15 sorry
        have A16: "m <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A14 A15 nat_1_th_13 sorry
        have A17: "m <>HIDDENR2 lenFINSEQ-1K4 p"
          using A14 A15 nat_1_th_13 sorry
        have A18: "lenFINSEQ-1K4 q =XBOOLE-0R4 m"
          using A16 finseq_1_th_17 sorry
        have A19: "q is-a-prefix-ofTREES-1R2 p"
           sorry
        have "lenFINSEQ-1K4 q =XBOOLE-0R4 m"
          using A16 finseq_1_th_17 sorry
        then have "q is-a-proper-prefix-ofTREES-1R3 p"
          using A17 A19 sorry
        then have A20: "q inTARSKIR2 ProperPrefixesTREES-1K1 p"
          using trees_1_th_12 sorry
        then have " ex r be FinSequenceFINSEQ-1M1 st q =FINSEQ-1R1 r & f .FUNCT-1K1 q =XBOOLE-0R4 lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
          using A4 sorry
        thus "x inHIDDENR3 rngRELAT-1K2 f"
          using A3 A15 A18 A20 funct_1_def_3 sorry
      qed "sorry"
      thus "domFINSEQ-1K5 p c=TARSKIR1 rngRELAT-1K2 f"
        using tarski_def_3 sorry
    qed
    thus "rngRELAT-1K2 f =HIDDENR1 domFINSEQ-1K5 p"
      using xboole_0_def_10 sorry
  qed
  thus "(ProperPrefixesTREES-1K1 p,domFINSEQ-1K5 p)are-equipotentTARSKIR3"
    using bexI[of _ "f"] wellord2_def_4 sorry
qed "sorry"

mtheorem trees_1_cl_9:
  mlet "p be FinSequenceFINSEQ-1M1"
"cluster ProperPrefixesTREES-1K1 p as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "ProperPrefixesTREES-1K1 p be finiteFINSET-1V1"
  proof-
    have "(ProperPrefixesTREES-1K1 p,domFINSEQ-1K5 p)are-equipotentTARSKIR3"
      using trees_1_th_34 sorry
    thus "ProperPrefixesTREES-1K1 p be finiteFINSET-1V1"
      using card_1_th_38 sorry
  qed
qed "sorry"

mtheorem trees_1_th_35:
" for p be FinSequenceFINSEQ-1M1 holds cardCARD-1K4 (ProperPrefixesTREES-1K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
proof(rule ballI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  have A1: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
    using finseq_1_def_3 sorry
  have A2: "(ProperPrefixesTREES-1K1 p,domFINSEQ-1K5 p)are-equipotentTARSKIR3"
    using trees_1_th_34 sorry
  have "cardCARD-1K4 (domFINSEQ-1K5 p) =XBOOLE-0R4 cardCARD-1K4 (lenFINSEQ-1K4 p)"
    using A1 finseq_1_th_55 sorry
  thus "cardCARD-1K4 (ProperPrefixesTREES-1K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
    using A2 card_1_th_5 sorry
qed "sorry"

mdef trees_1_def_10 ("AntiChain-of-Prefixes-likeTREES-1V2" 70 ) where
"attr AntiChain-of-Prefixes-likeTREES-1V2 for setHIDDENM2 means
  (\<lambda>IT. ( for x be setHIDDENM2 holds x inTARSKIR2 IT implies x be FinSequenceFINSEQ-1M1) & ( for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds (p1 inTARSKIR2 IT & p2 inTARSKIR2 IT) & p1 <>HIDDENR2 p2 implies  not (p1,p2)are-c=-comparableXBOOLE-0R3))"..

mtheorem trees_1_cl_10:
"cluster AntiChain-of-Prefixes-likeTREES-1V2 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be AntiChain-of-Prefixes-likeTREES-1V2"
  proof-
    have " ex tVar19 be setHIDDENM2 st tVar19 be AntiChain-of-Prefixes-likeTREES-1V2"
    proof-
      show " ex tVar19 be setHIDDENM2 st tVar19 be AntiChain-of-Prefixes-likeTREES-1V2"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        have "( for x be setHIDDENM2 holds x inTARSKIR2 {}XBOOLE-0K1 implies x be FinSequenceFINSEQ-1M1) & ( for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  not (((p1 inTARSKIR2 {}XBOOLE-0K1 & p2 inTARSKIR2 {}XBOOLE-0K1) &  not p1 <>HIDDENR2 p2) & (p1,p2)are-c=-comparableXBOOLE-0R3))"
        proof(rule conjMI,rule ballI,rule ballI)
          show " for x be setHIDDENM2 holds x inTARSKIR2 {}XBOOLE-0K1 implies x be FinSequenceFINSEQ-1M1"
             sorry
          fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
          fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
          show " not (((p1 inTARSKIR2 {}XBOOLE-0K1 & p2 inTARSKIR2 {}XBOOLE-0K1) &  not p1 <>HIDDENR2 p2) & (p1,p2)are-c=-comparableXBOOLE-0R3)"
             sorry
        qed "sorry"
        thus "{}XBOOLE-0K1 be AntiChain-of-Prefixes-likeTREES-1V2"
          using trees_1_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax TREES_1M5 :: "Ty" ("AntiChain-of-PrefixesTREES-1M5" 70)
translations "AntiChain-of-PrefixesTREES-1M5" \<rightharpoonup> "AntiChain-of-Prefixes-likeTREES-1V2\<bar>setHIDDENM2"

mtheorem trees_1_th_36:
" for w be FinSequenceFINSEQ-1M1 holds {TARSKIK1 w} be AntiChain-of-Prefixes-likeTREES-1V2"
proof-
  have " for w be FinSequenceFINSEQ-1M1 holds {TARSKIK1 w} be AntiChain-of-Prefixes-likeTREES-1V2"
  proof(rule ballI)
    fix w assume [ty]: "w be FinSequenceFINSEQ-1M1"
    have "( for x be setHIDDENM2 holds x inTARSKIR2 {TARSKIK1 w} implies x be FinSequenceFINSEQ-1M1) & ( for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 inTARSKIR2 {TARSKIK1 w} & p2 inTARSKIR2 {TARSKIK1 w} implies  not ( not p1 <>HIDDENR2 p2 & (p1,p2)are-c=-comparableXBOOLE-0R3))"
    proof(rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
      show " for x be setHIDDENM2 holds x inTARSKIR2 {TARSKIK1 w} implies x be FinSequenceFINSEQ-1M1"
        using tarski_def_1 sorry
      fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
      fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
      assume A1: "p1 inTARSKIR2 {TARSKIK1 w}"
        and A2: "p2 inTARSKIR2 {TARSKIK1 w}"
      have "p1 =FINSEQ-1R1 w"
        using A1 tarski_def_1 sorry
      thus " not ( not p1 <>HIDDENR2 p2 & (p1,p2)are-c=-comparableXBOOLE-0R3)"
        using A2 tarski_def_1 sorry
    qed "sorry"
    thus "{TARSKIK1 w} be AntiChain-of-Prefixes-likeTREES-1V2"
      using trees_1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_37:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  not (p1,p2)are-c=-comparableXBOOLE-0R3 implies {TARSKIK2 p1,p2 } be AntiChain-of-Prefixes-likeTREES-1V2"
proof-
  have " for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  not (p1,p2)are-c=-comparableXBOOLE-0R3 implies {TARSKIK2 p1,p2 } be AntiChain-of-Prefixes-likeTREES-1V2"
  proof(rule ballI,rule ballI,rule impI)
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    assume A1: " not (p1,p2)are-c=-comparableXBOOLE-0R3"
    have "( for x be setHIDDENM2 holds x inTARSKIR2 {TARSKIK2 p1,p2 } implies x be FinSequenceFINSEQ-1M1) & ( for q1 be FinSequenceFINSEQ-1M1 holds  for q2 be FinSequenceFINSEQ-1M1 holds q1 inTARSKIR2 {TARSKIK2 p1,p2 } & q2 inTARSKIR2 {TARSKIK2 p1,p2 } implies  not ( not q1 <>HIDDENR2 q2 & (q1,q2)are-c=-comparableXBOOLE-0R3))"
    proof(rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
      show " for x be setHIDDENM2 holds x inTARSKIR2 {TARSKIK2 p1,p2 } implies x be FinSequenceFINSEQ-1M1"
        using tarski_def_2 sorry
      fix q1 assume [ty]: "q1 be FinSequenceFINSEQ-1M1"
      fix q2 assume [ty]: "q2 be FinSequenceFINSEQ-1M1"
      assume A2: "q1 inTARSKIR2 {TARSKIK2 p1,p2 }"
        and A3: "q2 inTARSKIR2 {TARSKIK2 p1,p2 }"
      have A4: "q1 =FINSEQ-1R1 p1 or q1 =FINSEQ-1R1 p2"
        using A2 tarski_def_2 sorry
      have "q2 =FINSEQ-1R1 p1 or q2 =FINSEQ-1R1 p2"
        using A3 tarski_def_2 sorry
      thus " not ( not q1 <>HIDDENR2 q2 & (q1,q2)are-c=-comparableXBOOLE-0R3)"
        using A1 A4 sorry
    qed "sorry"
    thus "{TARSKIK2 p1,p2 } be AntiChain-of-Prefixes-likeTREES-1V2"
      using trees_1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_1_def_11 ("AntiChain-of-PrefixesTREES-1M6-of  _ " [70]70 ) where
  mlet "T be TreeTREES-1M1"
"mode AntiChain-of-PrefixesTREES-1M6-of T \<rightarrow> AntiChain-of-PrefixesTREES-1M5 means
  (\<lambda>it. it c=TARSKIR1 T)"
proof-
  (*existence*)
    show " ex it be AntiChain-of-PrefixesTREES-1M5 st it c=TARSKIR1 T"
    proof-
      have " ex tVar20 be AntiChain-of-PrefixesTREES-1M5 st tVar20 c=TARSKIR1 T"
      proof-
        let ?t = "the ElementTREES-1M2-of T"
        obtain S where 
          [ty]:"S be AntiChain-of-PrefixesTREES-1M5" and SDef:"S = {TARSKIK1 ?t}"
          using trees_1_th_36 sorry
        show " ex tVar20 be AntiChain-of-PrefixesTREES-1M5 st tVar20 c=TARSKIR1 T"
        proof(rule bexI[of _ "S"])
          have " for x be objectHIDDENM1 holds x inHIDDENR3 S implies x inHIDDENR3 T"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 S"
            then have "x =HIDDENR1 ?t"
              using tarski_def_1 sorry
            thus "x inHIDDENR3 T"
               sorry
          qed "sorry"
          thus "S c=TARSKIR1 T"
            using tarski_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

reserve t1, t2 for "ElementTREES-1M2-of T"
mtheorem trees_1_th_38:
" for T be TreeTREES-1M1 holds {}XBOOLE-0K1 be AntiChain-of-PrefixesTREES-1M6-of T & {TARSKIK1 {}XBOOLE-0K1 } be AntiChain-of-PrefixesTREES-1M6-of T"
proof-
  have " for T be TreeTREES-1M1 holds {}XBOOLE-0K1 be AntiChain-of-PrefixesTREES-1M6-of T & {TARSKIK1 {}XBOOLE-0K1 } be AntiChain-of-PrefixesTREES-1M6-of T"
  proof(rule ballI,rule conjMI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    have "{}XBOOLE-0K1 be AntiChain-of-Prefixes-likeTREES-1V2"
       sorry
    then obtain S where 
      [ty]:"S be AntiChain-of-PrefixesTREES-1M5" and SDef:"S = {}XBOOLE-0K1"
       sorry
    have "S c=TARSKIR1 T"
       sorry
    thus "{}XBOOLE-0K1 be AntiChain-of-PrefixesTREES-1M6-of T"
      using trees_1_def_11 sorry
    obtain S where 
      [ty]:"S be AntiChain-of-PrefixesTREES-1M5" and SDef:"S = {TARSKIK1 {}XBOOLE-0K1 }"
      using trees_1_th_36 sorry
    have "S be AntiChain-of-PrefixesTREES-1M6-of T"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 S implies x inHIDDENR3 T"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 S"
        then have "x =HIDDENR1 {}XBOOLE-0K1"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 T"
          using trees_1_th_22 sorry
      qed "sorry"
      thus "S be AntiChain-of-PrefixesTREES-1M6-of T"
        using tarski_def_3 trees_1_def_11 sorry
    qed
    thus "{TARSKIK1 {}XBOOLE-0K1 } be AntiChain-of-PrefixesTREES-1M6-of T"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_39:
" for T be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds {TARSKIK1 t} be AntiChain-of-PrefixesTREES-1M6-of T"
proof-
  have " for T be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds {TARSKIK1 t} be AntiChain-of-PrefixesTREES-1M6-of T"
  proof(rule ballI,rule ballI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix t assume [ty]: "t be ElementTREES-1M2-of T"
    obtain S where 
      [ty]:"S be AntiChain-of-PrefixesTREES-1M5" and SDef:"S = {TARSKIK1 t}"
      using trees_1_th_36 sorry
    have "S be AntiChain-of-PrefixesTREES-1M6-of T"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 S implies x inHIDDENR3 T"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 S"
        then have "x =HIDDENR1 t"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 T"
           sorry
      qed "sorry"
      thus "S be AntiChain-of-PrefixesTREES-1M6-of T"
        using tarski_def_3 trees_1_def_11 sorry
    qed
    thus "{TARSKIK1 t} be AntiChain-of-PrefixesTREES-1M6-of T"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_40:
" for T be TreeTREES-1M1 holds  for t1 be ElementTREES-1M2-of T holds  for t2 be ElementTREES-1M2-of T holds  not (t1,t2)are-c=-comparableXBOOLE-0R3 implies {TARSKIK2 t1,t2 } be AntiChain-of-PrefixesTREES-1M6-of T"
proof-
  have " for T be TreeTREES-1M1 holds  for t1 be ElementTREES-1M2-of T holds  for t2 be ElementTREES-1M2-of T holds  not (t1,t2)are-c=-comparableXBOOLE-0R3 implies {TARSKIK2 t1,t2 } be AntiChain-of-PrefixesTREES-1M6-of T"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix t1 assume [ty]: "t1 be ElementTREES-1M2-of T"
    fix t2 assume [ty]: "t2 be ElementTREES-1M2-of T"
    assume " not (t1,t2)are-c=-comparableXBOOLE-0R3"
    then obtain A where 
      [ty]:"A be AntiChain-of-PrefixesTREES-1M5" and ADef:"A = {TARSKIK2 t1,t2 }"
      using trees_1_th_37 sorry
    have "A be AntiChain-of-PrefixesTREES-1M6-of T"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 T"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 A"
        then have "x =HIDDENR1 t1 or x =HIDDENR1 t2"
          using tarski_def_2 sorry
        thus "x inHIDDENR3 T"
           sorry
      qed "sorry"
      thus "A be AntiChain-of-PrefixesTREES-1M6-of T"
        using tarski_def_3 trees_1_def_11 sorry
    qed
    thus "{TARSKIK2 t1,t2 } be AntiChain-of-PrefixesTREES-1M6-of T"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_cl_11:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster note-that finiteFINSET-1V1 for AntiChain-of-PrefixesTREES-1M6-of T"
proof
(*coherence*)
  show " for it be AntiChain-of-PrefixesTREES-1M6-of T holds it be finiteFINSET-1V1"
  proof-
    have " for X be AntiChain-of-PrefixesTREES-1M6-of T holds X be finiteFINSET-1V1"
    proof(rule ballI)
      fix X assume [ty]: "X be AntiChain-of-PrefixesTREES-1M6-of T"
      have "X c=TARSKIR1 T"
        using trees_1_def_11 sorry
      thus "X be finiteFINSET-1V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef trees_1_def_12 ("heightTREES-1K6  _ " [228]228 ) where
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"func heightTREES-1K6 T \<rightarrow> NatNAT-1M1 means
  \<lambda>it. ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T & lenFINSEQ-1K4 p =XBOOLE-0R4 it) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 it)"
proof-
  (*existence*)
    show " ex it be NatNAT-1M1 st ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T & lenFINSEQ-1K4 p =XBOOLE-0R4 it) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 it)"
    proof-
      have " ex tVar22 be NatNAT-1M1 st ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T & lenFINSEQ-1K4 p =XBOOLE-0R4 tVar22) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 tVar22)"
      proof-
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A1: "(T,SegFINSEQ-1K2 n)are-equipotentTARSKIR3"
          using finseq_1_th_56 sorry
        let ?X = "\<lambda>Lamb1.  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 Lamb1"
        have A2: " ex n be NatNAT-1M1 st ?X(n)"
        proof-
          have " ex tVar21 be NatNAT-1M1 st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 tVar21"
          proof-
            have "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T &  not lenFINSEQ-1K4 p <=XXREAL-0R1 n) implies  False "
            proof(rule impI)
              assume Given: " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T &  not lenFINSEQ-1K4 p <=XXREAL-0R1 n"
              then obtain p where
                [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                A3: "p inTARSKIR2 T"and A4: " not lenFINSEQ-1K4 p <=XXREAL-0R1 n"
                 sorry
              have A5: "ProperPrefixesTREES-1K1 p c=TARSKIR1 T"
                using A3 trees_1_def_3 sorry
              have A6: "(ProperPrefixesTREES-1K1 p,domFINSEQ-1K5 p)are-equipotentTARSKIR3"
                using trees_1_th_34 sorry
              have A7: "cardCARD-1K4 (ProperPrefixesTREES-1K1 p) c=ORDINAL1R1 cardCARD-1K4 T"
                using A5 card_1_th_11 sorry
              have A8: "cardCARD-1K4 (ProperPrefixesTREES-1K1 p) =XBOOLE-0R4 cardCARD-1K4 (domFINSEQ-1K5 p)"
                using A6 card_1_th_5 sorry
              have A9: "cardCARD-1K4 T =XBOOLE-0R4 cardCARD-1K4 (SegFINSEQ-1K2 n) & domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
                using A1 card_1_th_5 finseq_1_def_3 sorry
              have "SegFINSEQ-1K2 n c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
                using A4 finseq_1_th_5 sorry
              then have A10: "cardCARD-1K4 (SegFINSEQ-1K2 n) c=ORDINAL1R1 cardCARD-1K4 (SegFINSEQ-1K2 (lenFINSEQ-1K4 p))"
                using card_1_th_11 sorry
              have "cardCARD-1K4 (SegFINSEQ-1K2 n) =XBOOLE-0R4 cardCARD-1K4 n & cardCARD-1K4 (SegFINSEQ-1K2 (lenFINSEQ-1K4 p)) =XBOOLE-0R4 cardCARD-1K4 (lenFINSEQ-1K4 p)"
                using finseq_1_th_55 sorry
              then have "cardCARD-1K4 n =XBOOLE-0R4 cardCARD-1K4 (lenFINSEQ-1K4 p)"
                using A7 A8 A9 A10 sorry
              thus " False "
                using A4 sorry
            qed
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A11: "?X(n)"
               sorry
            have 
              [ty]:"n be NatNAT-1M1"
               sorry
            show " ex tVar21 be NatNAT-1M1 st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 tVar21"
            proof(rule bexI[of _ "n"])
              show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 n"
                using A11 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A12: "?X(n)"and A13: " for m be NatNAT-1M1 holds ?X(m) implies n <=XXREAL-0R1 m"
          using nat_1_sch_5 A2 sorry
        let ?x = "the ElementTREES-1M2-of T"
        have 
          [ty]:"n be NatNAT-1M1"
           sorry
        show " ex tVar22 be NatNAT-1M1 st ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T & lenFINSEQ-1K4 p =XBOOLE-0R4 tVar22) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 tVar22)"
        proof(rule bexI[of _ "n"],rule conjMI,rule ballI,rule impI)
          show " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T & lenFINSEQ-1K4 p =XBOOLE-0R4 n"
          proof-
            have "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <>HIDDENR2 n) implies  False "
            proof(rule impI)
              assume A14: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <>HIDDENR2 n"
              obtain x where 
                [ty]:"x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and xDef:"x = ?x"
                 sorry
              have "lenFINSEQ-1K4 x <=XXREAL-0R1 n"
                using A12 sorry
              then have "lenFINSEQ-1K4 x <XXREAL-0R3 n"
                using A14 xxreal_0_th_1 sorry
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A15: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_6 sorry
              have 
                [ty]:"k be NatNAT-1M1"
                 sorry
              have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 k"
              proof(rule ballI,rule impI)
                fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                assume A16: "p inTARSKIR2 T"
                then have "lenFINSEQ-1K4 p <=XXREAL-0R1 n"
                  using A12 sorry
                then have "lenFINSEQ-1K4 p <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
                  using A14 A15 A16 xxreal_0_th_1 sorry
                thus "lenFINSEQ-1K4 p <=XXREAL-0R1 k"
                  using nat_1_th_13 sorry
              qed "sorry"
              then have "n <=XXREAL-0R1 k"
                using A13 sorry
              thus " False "
                using A15 nat_1_th_13 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume "p inTARSKIR2 T"
          thus "lenFINSEQ-1K4 p <=XXREAL-0R1 n"
            using A12 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds (( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T & lenFINSEQ-1K4 p =XBOOLE-0R4 it1) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 it1)) & (( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 T & lenFINSEQ-1K4 p =XBOOLE-0R4 it2) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 it2)) implies it1 =HIDDENR1 it2"
    proof-
      have " for l1 be NatNAT-1M1 holds  for l2 be NatNAT-1M1 holds ( ex p1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p1 inTARSKIR2 T & lenFINSEQ-1K4 p1 =XBOOLE-0R4 l1) implies (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 l1) implies (( ex p2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p2 inTARSKIR2 T & lenFINSEQ-1K4 p2 =XBOOLE-0R4 l2) implies (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 l2) implies l1 =HIDDENR1 l2)))"
      proof(rule ballI,rule ballI,rule impI,rule impI,rule impI,rule impI)
        fix l1 assume [ty]: "l1 be NatNAT-1M1"
        fix l2 assume [ty]: "l2 be NatNAT-1M1"
        assume Given: " ex p1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p1 inTARSKIR2 T & lenFINSEQ-1K4 p1 =XBOOLE-0R4 l1"
        then obtain p1 where
          [ty]:"p1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A17: "p1 inTARSKIR2 T & lenFINSEQ-1K4 p1 =XBOOLE-0R4 l1"
           sorry
        assume A18: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 l1"
        assume Given: " ex p2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p2 inTARSKIR2 T & lenFINSEQ-1K4 p2 =XBOOLE-0R4 l2"
        then obtain p2 where
          [ty]:"p2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A19: "p2 inTARSKIR2 T & lenFINSEQ-1K4 p2 =XBOOLE-0R4 l2"
           sorry
        assume " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies lenFINSEQ-1K4 p <=XXREAL-0R1 l2"
        then have A20: "l1 <=XXREAL-0R1 l2"
          using A17 sorry
        have "l2 <=XXREAL-0R1 l1"
          using A18 A19 sorry
        thus "l1 =HIDDENR1 l2"
          using A20 xxreal_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef trees_1_def_13 ("widthTREES-1K7  _ " [228]228 ) where
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"func widthTREES-1K7 T \<rightarrow> NatNAT-1M1 means
  \<lambda>it.  ex X be AntiChain-of-PrefixesTREES-1M6-of T st it =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)"
proof-
  (*existence*)
    show " ex it be NatNAT-1M1 st  ex X be AntiChain-of-PrefixesTREES-1M6-of T st it =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)"
    proof-
      have " ex tVar23 be NatNAT-1M1 st  ex tVar24 be AntiChain-of-PrefixesTREES-1M6-of T st tVar23 =XBOOLE-0R4 cardCARD-1K4 tVar24 & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 tVar24)"
      proof-
        let ?X = "\<lambda>Lamb1.  ex X be finiteFINSET-1V1\<bar>setHIDDENM2 st (Lamb1 =XBOOLE-0R4 cardCARD-1K4 X & X c=TARSKIR1 T) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 X & q inTARSKIR2 X) & p <>HIDDENR2 q implies  not (p,q)are-c=-comparableXBOOLE-0R3)"
        have "0NUMBERSK6 =XBOOLE-0R4 cardCARD-1K4 ({}XBOOLE-0K1) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 {}XBOOLE-0K1 & q inTARSKIR2 {}XBOOLE-0K1) & p <>HIDDENR2 q implies  not (p,q)are-c=-comparableXBOOLE-0R3)"
           sorry
        then have A21: " ex n be NatNAT-1M1 st ?X(n)"
          using xboole_1_th_2 sorry
        have A22: " for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 cardCARD-1K4 T"
        proof-
          have " for n be NatNAT-1M1 holds ( ex X be finiteFINSET-1V1\<bar>setHIDDENM2 st (n =XBOOLE-0R4 cardCARD-1K4 X & X c=TARSKIR1 T) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 X & q inTARSKIR2 X) & p <>HIDDENR2 q implies  not (p,q)are-c=-comparableXBOOLE-0R3)) implies n <=XXREAL-0R1 cardCARD-1K4 T"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume Given: " ex X be finiteFINSET-1V1\<bar>setHIDDENM2 st (n =XBOOLE-0R4 cardCARD-1K4 X & X c=TARSKIR1 T) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 X & q inTARSKIR2 X) & p <>HIDDENR2 q implies  not (p,q)are-c=-comparableXBOOLE-0R3)"
            then obtain X where
              [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and 
              A23: "n =XBOOLE-0R4 cardCARD-1K4 X & X c=TARSKIR1 T"and " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 X & q inTARSKIR2 X) & p <>HIDDENR2 q implies  not (p,q)are-c=-comparableXBOOLE-0R3"
               sorry
            have A24: "SegmORDINAL1K6 cardCARD-1K4 X c=ORDINAL1R1 SegmORDINAL1K6 cardCARD-1K4 T & cardCARD-1K4 X =XBOOLE-0R4 cardCARD-1K4 n"
              using A23 card_1_th_11 sorry
            have "cardCARD-1K4 T =XBOOLE-0R4 cardCARD-1K4 (SegmORDINAL1K6 cardCARD-1K4 T)"
               sorry
            thus "n <=XXREAL-0R1 cardCARD-1K4 T"
              using A24 nat_1_th_40 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A25: "?X(n)"and A26: " for m be NatNAT-1M1 holds ?X(m) implies m <=XXREAL-0R1 n"
          using nat_1_sch_6 A22 A21 sorry
        obtain X where
          [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and 
          A27: "n =XBOOLE-0R4 cardCARD-1K4 X"and A28: "X c=TARSKIR1 T"and A29: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 X & q inTARSKIR2 X) & p <>HIDDENR2 q implies  not (p,q)are-c=-comparableXBOOLE-0R3"
          using A25 sorry
        have "X be AntiChain-of-Prefixes-likeTREES-1V2"
        proof-
          have "( for x be setHIDDENM2 holds x inTARSKIR2 X implies x be FinSequenceFINSEQ-1M1) & ( for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 inTARSKIR2 X & p2 inTARSKIR2 X implies  not ( not p1 <>HIDDENR2 p2 & (p1,p2)are-c=-comparableXBOOLE-0R3))"
          proof(rule conjMI,rule ballI,rule ballI,rule impI)
            show " for x be setHIDDENM2 holds x inTARSKIR2 X implies x be FinSequenceFINSEQ-1M1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be setHIDDENM2"
              assume A30: "x inTARSKIR2 X"
              have "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                using trees_1_def_3 sorry
              thus "x be FinSequenceFINSEQ-1M1"
                using A30 A28 sorry
            qed "sorry"
            fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
            fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
            assume A31: "p1 inTARSKIR2 X & p2 inTARSKIR2 X"
            then obtain q1 q2 where 
              [ty]:"q1 be ElementTREES-1M2-of T" and q1Def:"q1 = p1" and
              [ty]:"q2 be ElementTREES-1M2-of T" and q2Def:"q2 = p2"
              using A28 sorry
            have "p1 =FINSEQ-1R1 q1 & p2 =FINSEQ-1R1 q2"
               sorry
            thus " not ( not p1 <>HIDDENR2 p2 & (p1,p2)are-c=-comparableXBOOLE-0R3)"
              using A29 A31 sorry
          qed "sorry"
          thus "X be AntiChain-of-Prefixes-likeTREES-1V2"
            using trees_1_def_10 sorry
        qed
        then have 
          [ty]:"X be AntiChain-of-PrefixesTREES-1M5"
           sorry
        have 
          [ty]:"X be AntiChain-of-PrefixesTREES-1M6-of T"
          using A28 trees_1_def_11 sorry
        have 
          [ty]:"n be NatNAT-1M1"
           sorry
        show " ex tVar23 be NatNAT-1M1 st  ex tVar24 be AntiChain-of-PrefixesTREES-1M6-of T st tVar23 =XBOOLE-0R4 cardCARD-1K4 tVar24 & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 tVar24)"
        proof(rule bexI[of _ "n"])
          show " ex tVar24 be AntiChain-of-PrefixesTREES-1M6-of T st n =XBOOLE-0R4 cardCARD-1K4 tVar24 & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 tVar24)"
          proof(rule bexI[of _ "X"],rule conjMI,rule ballI)
            show "n =XBOOLE-0R4 cardCARD-1K4 X"
              using A27 sorry
            fix Y assume [ty]: "Y be AntiChain-of-PrefixesTREES-1M6-of T"
            have "Y c=TARSKIR1 T & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 Y & q inTARSKIR2 Y) & p <>HIDDENR2 q implies  not (p,q)are-c=-comparableXBOOLE-0R3)"
              using trees_1_def_10 trees_1_def_11 sorry
            thus "cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X"
              using A26 A27 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds ( ex X be AntiChain-of-PrefixesTREES-1M6-of T st it1 =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)) & ( ex X be AntiChain-of-PrefixesTREES-1M6-of T st it2 =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)) implies it1 =HIDDENR1 it2"
    proof-
      have " for n1 be NatNAT-1M1 holds  for n2 be NatNAT-1M1 holds ( ex X1 be AntiChain-of-PrefixesTREES-1M6-of T st n1 =XBOOLE-0R4 cardCARD-1K4 X1 & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X1)) implies (( ex X2 be AntiChain-of-PrefixesTREES-1M6-of T st n2 =XBOOLE-0R4 cardCARD-1K4 X2 & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X2)) implies n1 =HIDDENR1 n2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix n1 assume [ty]: "n1 be NatNAT-1M1"
        fix n2 assume [ty]: "n2 be NatNAT-1M1"
        assume Given: " ex X1 be AntiChain-of-PrefixesTREES-1M6-of T st n1 =XBOOLE-0R4 cardCARD-1K4 X1 & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X1)"
        then obtain X1 where
          [ty]:"X1 be AntiChain-of-PrefixesTREES-1M6-of T" and 
          A32: "n1 =XBOOLE-0R4 cardCARD-1K4 X1"and A33: " for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X1"
           sorry
        assume Given: " ex X2 be AntiChain-of-PrefixesTREES-1M6-of T st n2 =XBOOLE-0R4 cardCARD-1K4 X2 & ( for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X2)"
        then obtain X2 where
          [ty]:"X2 be AntiChain-of-PrefixesTREES-1M6-of T" and 
          A34: "n2 =XBOOLE-0R4 cardCARD-1K4 X2"and A35: " for Y be AntiChain-of-PrefixesTREES-1M6-of T holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X2"
           sorry
        have A36: "cardCARD-1K4 X1 <=XXREAL-0R1 cardCARD-1K4 X2"
          using A35 sorry
        have "cardCARD-1K4 X2 <=XXREAL-0R1 cardCARD-1K4 X1"
          using A33 sorry
        thus "n1 =HIDDENR1 n2"
          using A32 A34 A36 xxreal_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_1_th_41:
" for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 widthTREES-1K7 fT"
proof-
  have " for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 widthTREES-1K7 fT"
  proof(rule ballI)
    fix fT assume [ty]: "fT be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    have "( ex X be AntiChain-of-PrefixesTREES-1M6-of fT st widthTREES-1K7 fT =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of fT holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)) & {TARSKIK1 {}XBOOLE-0K1 } be AntiChain-of-PrefixesTREES-1M6-of fT"
      using trees_1_def_13 trees_1_th_38 sorry
    then have "cardCARD-1K4 {TARSKIK1 {}XBOOLE-0K1 } <=XXREAL-0R1 widthTREES-1K7 fT"
       sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 widthTREES-1K7 fT"
      using card_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_42:
"heightTREES-1K6 (elementary-treeTREES-1K2 (0NUMBERSK6)) =XBOOLE-0R4 0NUMBERSK6"
proof-
  have "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) & lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) implies lenFINSEQ-1K4 p <=XXREAL-0R1 0NUMBERSK6)"
  proof(rule conjMI,rule ballI,rule impI)
    show " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) & lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have " ex tVar25 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st tVar25 inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) & lenFINSEQ-1K4 tVar25 =XBOOLE-0R4 0NUMBERSK6"
      proof-
        show " ex tVar25 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st tVar25 inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) & lenFINSEQ-1K4 tVar25 =XBOOLE-0R4 0NUMBERSK6"
        proof(rule bexI[of _ "<*>FINSEQ-1K7 NATNUMBERSK1"])
          show "<*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) & lenFINSEQ-1K4 <*>FINSEQ-1K7 NATNUMBERSK1 =XBOOLE-0R4 0NUMBERSK6"
            using trees_1_th_29 tarski_def_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume "p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6)"
    then have "p =FINSEQ-1R1 {}XBOOLE-0K1"
      using trees_1_th_29 tarski_def_1 sorry
    thus "lenFINSEQ-1K4 p <=XXREAL-0R1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus "heightTREES-1K6 (elementary-treeTREES-1K2 (0NUMBERSK6)) =XBOOLE-0R4 0NUMBERSK6"
    using trees_1_def_12 sorry
qed

mtheorem trees_1_th_43:
" for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 fT =XBOOLE-0R4 0NUMBERSK6 implies fT =XBOOLE-0R4 elementary-treeTREES-1K2 (0NUMBERSK6)"
proof-
  have " for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 fT =XBOOLE-0R4 0NUMBERSK6 implies fT =XBOOLE-0R4 elementary-treeTREES-1K2 (0NUMBERSK6)"
  proof(rule ballI,rule impI)
    fix fT assume [ty]: "fT be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    assume A1: "heightTREES-1K6 fT =XBOOLE-0R4 0NUMBERSK6"
    have "fT c=TARSKIR1 elementary-treeTREES-1K2 (0NUMBERSK6) & elementary-treeTREES-1K2 (0NUMBERSK6) c=TARSKIR1 fT"
    proof(rule conjMI)
      show "fT c=TARSKIR1 elementary-treeTREES-1K2 (0NUMBERSK6)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 fT implies x inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 fT"
          then obtain t where 
            [ty]:"t be ElementTREES-1M2-of fT" and tDef:"t = x"
             sorry
          have "lenFINSEQ-1K4 t =XBOOLE-0R4 0NUMBERSK6"
            using A1 trees_1_def_12 sorry
          then have "x =HIDDENR1 {}XBOOLE-0K1"
             sorry
          thus "x inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6)"
            using trees_1_th_22 sorry
        qed "sorry"
        thus "fT c=TARSKIR1 elementary-treeTREES-1K2 (0NUMBERSK6)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6) implies x inHIDDENR3 fT"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6)"
        then have "x =HIDDENR1 {}XBOOLE-0K1"
          using trees_1_th_29 tarski_def_1 sorry
        thus "x inHIDDENR3 fT"
          using trees_1_th_22 sorry
      qed "sorry"
      thus "elementary-treeTREES-1K2 (0NUMBERSK6) c=TARSKIR1 fT"
        using tarski_def_3 sorry
    qed
    thus "fT =XBOOLE-0R4 elementary-treeTREES-1K2 (0NUMBERSK6)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_44:
" for n be NatNAT-1M1 holds heightTREES-1K6 (elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds heightTREES-1K6 (elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?T = "elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    have "( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) & lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies lenFINSEQ-1K4 p <=XXREAL-0R1 \<one>\<^sub>M)"
    proof(rule conjMI,rule ballI,rule impI)
      show " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) & lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
      proof-
        have " ex p be FinSequenceFINSEQ-1M3-of omegaORDINAL1K4 st p inTARSKIR2 elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) & lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
        proof-
          obtain p where 
            [ty]:"p be FinSequenceFINSEQ-1M3-of omegaORDINAL1K4" and pDef:"p = <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>"
             sorry
          show " ex p be FinSequenceFINSEQ-1M3-of omegaORDINAL1K4 st p inTARSKIR2 elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) & lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
          proof(rule bexI[of _ "p"],rule conjMI)
            show "p inTARSKIR2 elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
              using trees_1_th_28 sorry
            show "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
              using finseq_1_th_40 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      assume A1: "p inTARSKIR2 ?T"
      have A2: "p inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 } implies p =FINSEQ-1R1 {}XBOOLE-0K1"
        using tarski_def_1 sorry
      have "p inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } implies lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
      proof(rule impI)
        assume "p inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M }"
        then have " ex k be NatNAT-1M1 st p =FINSEQ-1R1 <*FINSEQ-1K10 k*> & k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
           sorry
        thus "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
      qed
      thus "lenFINSEQ-1K4 p <=XXREAL-0R1 \<one>\<^sub>M"
        using A1 A2 xboole_0_def_3 sorry
    qed "sorry"
    thus "heightTREES-1K6 (elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 \<one>\<^sub>M"
      using trees_1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_45:
"widthTREES-1K7 (elementary-treeTREES-1K2 (0NUMBERSK6)) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  let ?T = "elementary-treeTREES-1K2 (0NUMBERSK6)"
  have " ex X be AntiChain-of-PrefixesTREES-1M6-of elementary-treeTREES-1K2 (0NUMBERSK6) st \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of elementary-treeTREES-1K2 (0NUMBERSK6) holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)"
  proof-
    obtain X where 
      [ty]:"X be AntiChain-of-PrefixesTREES-1M6-of ?T" and XDef:"X = {TARSKIK1 {}XBOOLE-0K1 }"
      using trees_1_th_38 sorry
    show " ex X be AntiChain-of-PrefixesTREES-1M6-of elementary-treeTREES-1K2 (0NUMBERSK6) st \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of elementary-treeTREES-1K2 (0NUMBERSK6) holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)"
    proof(rule bexI[of _ "X"],rule conjMI,rule ballI)
      show "\<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 X"
        using card_1_th_30 sorry
      fix Y assume [ty]: "Y be AntiChain-of-PrefixesTREES-1M6-of ?T"
      have "Y c=TARSKIR1 X"
        using trees_1_def_11 trees_1_th_29 sorry
      thus "cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X"
        using nat_1_th_43 sorry
    qed "sorry"
  qed
  thus "widthTREES-1K7 (elementary-treeTREES-1K2 (0NUMBERSK6)) =XBOOLE-0R4 \<one>\<^sub>M"
    using trees_1_def_13 sorry
qed

mtheorem trees_1_th_46:
" for n be NatNAT-1M1 holds widthTREES-1K7 (elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds widthTREES-1K7 (elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?T = "elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    have " ex X be AntiChain-of-PrefixesTREES-1M6-of elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)"
    proof-
      have "{<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } be AntiChain-of-Prefixes-likeTREES-1V2"
      proof-
        have "{<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } be AntiChain-of-Prefixes-likeTREES-1V2"
        proof-
          have "( for x be setHIDDENM2 holds x inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } implies x be FinSequenceFINSEQ-1M1) & ( for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } & p2 inTARSKIR2 {<*FINSEQ-1K10 m*> where m be NatNAT-1M1 : m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } implies  not ( not p1 <>HIDDENR2 p2 & (p1,p2)are-c=-comparableXBOOLE-0R3))"
          proof(rule conjMI,rule ballI,rule ballI,rule impI)
            show " for x be setHIDDENM2 holds x inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } implies x be FinSequenceFINSEQ-1M1"
            proof-
              have " for x be setHIDDENM2 holds x inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } implies x be FinSequenceFINSEQ-1M1"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be setHIDDENM2"
                assume "x inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M }"
                then have " ex k be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 k*> & k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                   sorry
                thus "x be FinSequenceFINSEQ-1M1"
                   sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
            fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
            assume "p1 inTARSKIR2 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } & p2 inTARSKIR2 {<*FINSEQ-1K10 m*> where m be NatNAT-1M1 : m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M }"
            then have "( ex k be NatNAT-1M1 st p1 =FINSEQ-1R1 <*FINSEQ-1K10 k*> & k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M) & ( ex m be NatNAT-1M1 st p2 =FINSEQ-1R1 <*FINSEQ-1K10 m*> & m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M)"
               sorry
            thus " not ( not p1 <>HIDDENR2 p2 & (p1,p2)are-c=-comparableXBOOLE-0R3)"
              using trees_1_th_5 sorry
          qed "sorry"
          thus "{<*FINSEQ-1K10 k*> where k be NatNAT-1M1 :  not k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } be AntiChain-of-Prefixes-likeTREES-1V2"
            using trees_1_def_10 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain X where 
        [ty]:"X be AntiChain-of-PrefixesTREES-1M5" and XDef:"X = {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M }"
         sorry
      have "X c=TARSKIR1 ?T"
        using xboole_1_th_7 sorry
      then have 
        [ty]:"X be AntiChain-of-PrefixesTREES-1M6-of ?T"
        using trees_1_def_11 sorry
      show " ex X be AntiChain-of-PrefixesTREES-1M6-of elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) st n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 X & ( for Y be AntiChain-of-PrefixesTREES-1M6-of elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M) holds cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X)"
      proof(rule bexI[of _ "X"],rule conjMI,rule ballI)
        have "(X,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))are-equipotentTARSKIR3"
        proof-
          let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be NatNAT-1M1 st Lamb1 =HIDDENR1 <*FINSEQ-1K10 n*> & Lamb2 =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
          have A1: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds (x inTARSKIR2 X & ?P(x,y)) & ?P(x,z) implies y =XBOOLE-0R4 z"
          proof-
            have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x inTARSKIR2 X implies (( ex n1 be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n1*> & y =XBOOLE-0R4 n1 +NAT-1K1 \<one>\<^sub>M) implies (( ex n2 be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n2*> & z =XBOOLE-0R4 n2 +NAT-1K1 \<one>\<^sub>M) implies y =XBOOLE-0R4 z))"
            proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
              fix x assume [ty]: "x be setHIDDENM2"
              fix y assume [ty]: "y be setHIDDENM2"
              fix z assume [ty]: "z be setHIDDENM2"
              assume "x inTARSKIR2 X"
              assume Given: " ex n1 be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n1*> & y =XBOOLE-0R4 n1 +NAT-1K1 \<one>\<^sub>M"
              then obtain n1 where
                [ty]:"n1 be NatNAT-1M1" and 
                A2: "x =XBOOLE-0R4 <*FINSEQ-1K10 n1*> & y =XBOOLE-0R4 n1 +NAT-1K1 \<one>\<^sub>M"
                 sorry
              assume Given: " ex n2 be NatNAT-1M1 st x =XBOOLE-0R4 <*FINSEQ-1K10 n2*> & z =XBOOLE-0R4 n2 +NAT-1K1 \<one>\<^sub>M"
              then obtain n2 where
                [ty]:"n2 be NatNAT-1M1" and 
                A3: "x =XBOOLE-0R4 <*FINSEQ-1K10 n2*> & z =XBOOLE-0R4 n2 +NAT-1K1 \<one>\<^sub>M"
                 sorry
              have "(<*FINSEQ-1K10 n1*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n1"
                using finseq_1_def_8 sorry
              thus "y =XBOOLE-0R4 z"
                using A2 A3 finseq_1_def_8 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st ?P(x,y))"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex tVar29 be objectHIDDENM1 st  ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & tVar29 =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M)"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 X"
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A5: "x =HIDDENR1 <*FINSEQ-1K10 k*>"and "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                 sorry
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = k +NAT-1K1 \<one>\<^sub>M"
                 sorry
              show " ex tVar29 be objectHIDDENM1 st  ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & tVar29 =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
              proof(rule bexI[of _ "y"])
                show " ex n be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 n*> & y =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
                  using A5 sorry
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A6: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ?P(x,f .FUNCT-1K1 x))"
            using classes1_sch_1 A4 sorry
          have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngRELAT-1K2 f =HIDDENR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))"
          proof(rule conjMI,rule conjMI)
            show "f be one-to-oneFUNCT-1V2"
            proof-
              have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
              proof(rule ballI,rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A7: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
                  and A8: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
                have "( ex k1 be NatNAT-1M1 st x =HIDDENR1 <*FINSEQ-1K10 k1*> & f .FUNCT-1K1 x =XBOOLE-0R4 k1 +NAT-1K1 \<one>\<^sub>M) & ( ex k2 be NatNAT-1M1 st y =HIDDENR1 <*FINSEQ-1K10 k2*> & f .FUNCT-1K1 y =XBOOLE-0R4 k2 +NAT-1K1 \<one>\<^sub>M)"
                  using A6 A7 sorry
                thus "x =HIDDENR1 y"
                  using A8 sorry
              qed "sorry"
              thus "f be one-to-oneFUNCT-1V2"
                using funct_1_def_4 sorry
            qed
            show "domRELAT-1K1 f =XBOOLE-0R4 X"
              using A6 sorry
            have "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) & SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 rngRELAT-1K2 f"
            proof(rule conjMI)
              show "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 rngFUNCT-1K2 f"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A9: "y inHIDDENR3 domRELAT-1K1 f"and A10: "x =HIDDENR1 f .FUNCT-1K1 y"
                    using funct_1_def_3 sorry
                  obtain k where
                    [ty]:"k be NatNAT-1M1" and 
                    A11: "y =HIDDENR1 <*FINSEQ-1K10 k*>"and A12: "x =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
                    using A6 A9 A10 sorry
                  obtain m where
                    [ty]:"m be NatNAT-1M1" and 
                    A13: "y =HIDDENR1 <*FINSEQ-1K10 m*> & m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                    using A6 A9 sorry
                  have "(<*FINSEQ-1K10 k*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k & (<*FINSEQ-1K10 m*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m"
                    using finseq_1_def_8 sorry
                  then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                    using A11 A13 nat_1_th_13 sorry
                  thus "x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                    using A12 finseq_1_th_1 sorry
                qed "sorry"
                thus "rngFUNCT-1K2 f c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                  using tarski_def_3 sorry
              qed
              have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies x inHIDDENR3 rngRELAT-1K2 f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A14: "x inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                then obtain k where 
                  [ty]:"k be NatNAT-1M1" and kDef:"k = x"
                   sorry
                have A15: "\<one>\<^sub>M <=XXREAL-0R1 k"
                  using A14 finseq_1_th_1 sorry
                have A16: "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using A14 finseq_1_th_1 sorry
                obtain m where
                  [ty]:"m be NatNAT-1M1" and 
                  A17: "k =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 m"
                  using A15 nat_1_th_10 sorry
                have 
                  [ty]:"m be NatNAT-1M1"
                   sorry
                have "m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                  using A16 A17 nat_1_th_13 sorry
                then have A18: "<*FINSEQ-1K10 m*> inTARSKIR2 X"
                   sorry
                then have "?P(<*FINSEQ-1K10 m*>,f .FUNCT-1K1 (<*FINSEQ-1K10 m*>))"
                  using A6 sorry
                then have "x =HIDDENR1 f .FUNCT-1K1 (<*FINSEQ-1K10 m*>)"
                  using A1 A17 A18 sorry
                thus "x inHIDDENR3 rngRELAT-1K2 f"
                  using A6 A18 funct_1_def_3 sorry
              qed "sorry"
              thus "SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 rngRELAT-1K2 f"
                using tarski_def_3 sorry
            qed
            thus "rngRELAT-1K2 f =HIDDENR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
              using xboole_0_def_10 sorry
          qed
          thus "(X,SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M))are-equipotentTARSKIR3"
            using bexI[of _ "f"] wellord2_def_4 sorry
        qed
        then have A19: "cardCARD-1K4 (SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 cardCARD-1K4 X"
          using card_1_th_5 sorry
        thus "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 X"
          using finseq_1_th_57 sorry
        fix Y assume [ty]: "Y be AntiChain-of-PrefixesTREES-1M6-of ?T"
        have A20: "Y c=TARSKIR1 ?T"
          using trees_1_def_11 sorry
        have A21: "{}XBOOLE-0K1 inTARSKIR2 Y implies Y =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
        proof-
          have "{}XBOOLE-0K1 inTARSKIR2 Y & Y <>HIDDENR2 {TARSKIK1 {}XBOOLE-0K1 } implies  False "
          proof(rule impMI ,rule impI)
            assume A22: "{}XBOOLE-0K1 inTARSKIR2 Y"
              and A23: "Y <>HIDDENR2 {TARSKIK1 {}XBOOLE-0K1 }"
            obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A24: " not (x inHIDDENR3 Y iff x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 })"
              using A23 tarski_th_2 sorry
            have A25: "{}XBOOLE-0K1 <>HIDDENR2 x"
              using A22 A24 tarski_def_1 sorry
            have 
              [ty]:"x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              using A20 A24 trees_1_th_19 sorry
            have "{}XBOOLE-0K1 is-a-prefix-ofTREES-1R2 x"
               sorry
            then have "({}XBOOLE-0K1,x)are-c=-comparableXBOOLE-0R3"
               sorry
            thus " False "
              using A22 A24 A25 trees_1_def_10 tarski_def_1 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A26: "cardCARD-1K4 {TARSKIK1 {}XBOOLE-0K1 } =XBOOLE-0R4 \<one>\<^sub>M & \<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 n"
          using card_1_th_30 nat_1_th_11 sorry
        have " not {}XBOOLE-0K1 inTARSKIR2 Y implies cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X"
        proof(rule impI)
          assume A27: " not {}XBOOLE-0K1 inTARSKIR2 Y"
          have "Y c=TARSKIR1 X"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 X"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A28: "x inHIDDENR3 Y"
              then have "x inHIDDENR3 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
                using A20 xboole_0_def_3 sorry
              thus "x inHIDDENR3 X"
                using A27 A28 tarski_def_1 sorry
            qed "sorry"
            thus "Y c=TARSKIR1 X"
              using tarski_def_3 sorry
          qed
          thus "cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X"
            using nat_1_th_43 sorry
        qed
        thus "cardCARD-1K4 Y <=XXREAL-0R1 cardCARD-1K4 X"
          using A19 A21 A26 finseq_1_th_57 sorry
      qed "sorry"
    qed
    thus "widthTREES-1K7 (elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using trees_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_47:
" for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for t be ElementTREES-1M2-of fT holds heightTREES-1K6 (fT  |TREES-1K4 t) <=XXREAL-0R1 heightTREES-1K6 fT"
proof-
  have " for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for t be ElementTREES-1M2-of fT holds heightTREES-1K6 (fT  |TREES-1K4 t) <=XXREAL-0R1 heightTREES-1K6 fT"
  proof(rule ballI,rule ballI)
    fix fT assume [ty]: "fT be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix t assume [ty]: "t be ElementTREES-1M2-of fT"
    obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
      A1: "p inTARSKIR2 fT  |TREES-1K4 t"and A2: "lenFINSEQ-1K4 p =XBOOLE-0R4 heightTREES-1K6 (fT  |TREES-1K4 t)"
      using trees_1_def_12 sorry
    have "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p inTARSKIR2 fT"
      using A1 trees_1_def_6 sorry
    then have A3: "lenFINSEQ-1K4 (t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p) <=XXREAL-0R1 heightTREES-1K6 fT"
      using trees_1_def_12 sorry
    have "lenFINSEQ-1K4 (t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p) =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 t"
      using finseq_1_th_22 nat_1_th_11 sorry
    thus "heightTREES-1K6 (fT  |TREES-1K4 t) <=XXREAL-0R1 heightTREES-1K6 fT"
      using A2 A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_48:
" for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for t be ElementTREES-1M2-of fT holds t <>HIDDENR2 {}XBOOLE-0K1 implies heightTREES-1K6 (fT  |TREES-1K4 t) <XXREAL-0R3 heightTREES-1K6 fT"
proof-
  have " for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for t be ElementTREES-1M2-of fT holds t <>HIDDENR2 {}XBOOLE-0K1 implies  not heightTREES-1K6 (fT  |TREES-1K4 t) <XXREAL-0R3 heightTREES-1K6 fT"
  proof(rule ballI,rule ballI,rule impI)
    fix fT assume [ty]: "fT be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix t assume [ty]: "t be ElementTREES-1M2-of fT"
    assume "t <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 t"
      using nat_1_th_13 sorry
    obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
      A2: "p inTARSKIR2 fT  |TREES-1K4 t"and A3: "lenFINSEQ-1K4 p =XBOOLE-0R4 heightTREES-1K6 (fT  |TREES-1K4 t)"
      using trees_1_def_12 sorry
    have "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p inTARSKIR2 fT"
      using A2 trees_1_def_6 sorry
    then have A4: "lenFINSEQ-1K4 (t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p) <=XXREAL-0R1 heightTREES-1K6 fT"
      using trees_1_def_12 sorry
    have "lenFINSEQ-1K4 (t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p) =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 t +NAT-1K1 lenFINSEQ-1K4 p"
      using A1 finseq_1_th_22 xreal_1_th_7 sorry
    then have "heightTREES-1K6 (fT  |TREES-1K4 t) +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 heightTREES-1K6 fT"
      using A3 A4 xxreal_0_th_2 sorry
    thus " not heightTREES-1K6 (fT  |TREES-1K4 t) <XXREAL-0R3 heightTREES-1K6 fT"
      using nat_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem trees_1_sch_1:
  fixes Pp1 
  assumes
    A1: " for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*> inTARSKIR2 fT implies Pp1(fT  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>))) implies Pp1(fT)"
  shows " for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds Pp1(fT)"
  proof(rule ballI)
    let ?X = "\<lambda>Lamb1.  for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 fT =XBOOLE-0R4 Lamb1 implies Pp1(fT)"
    have A2: " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?X(k)) implies ?X(n)"
    proof-
      have " for n be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 fT =XBOOLE-0R4 k implies Pp1(fT))) implies ( for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 fT =XBOOLE-0R4 n implies Pp1(fT))"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: " for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( for fT be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 fT =XBOOLE-0R4 k implies Pp1(fT))"
        fix fT assume [ty]: "fT be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        assume A4: "heightTREES-1K6 fT =XBOOLE-0R4 n"
        have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> inTARSKIR2 fT implies Pp1(fT  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>))"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
          assume "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> inTARSKIR2 fT"
          then obtain k9 where 
            [ty]:"k9 be ElementTREES-1M2-of fT" and k9Def:"k9 = <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>"
             sorry
          have "heightTREES-1K6 (fT  |TREES-1K4 k9) <XXREAL-0R3 heightTREES-1K6 fT"
            using trees_1_th_48 sorry
          thus "Pp1(fT  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>))"
            using A3 A4 sorry
        qed "sorry"
        thus "Pp1(fT)"
          using A1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_4 A2 sorry
    fix fT assume [ty]: "fT be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    have "heightTREES-1K6 fT =XBOOLE-0R4 heightTREES-1K6 fT"
       sorry
    thus "Pp1(fT)"
      using A5 sorry
  qed "sorry"

(*begin*)
reserve s, t for "FinSequenceFINSEQ-1M1"
mtheorem trees_1_th_49:
" for w be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds  for t be FinSequenceFINSEQ-1M1 holds w ^FINSEQ-1K8 t is-a-proper-prefix-ofTREES-1R3 w ^FINSEQ-1K8 s implies t is-a-proper-prefix-ofTREES-1R3 s"
proof-
  have " for w be FinSequenceFINSEQ-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds  for t be FinSequenceFINSEQ-1M1 holds w ^FINSEQ-1K8 t is-a-proper-prefix-ofTREES-1R3 w ^FINSEQ-1K8 s implies t is-a-proper-prefix-ofTREES-1R3 s"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix w assume [ty]: "w be FinSequenceFINSEQ-1M1"
    fix s assume [ty]: "s be FinSequenceFINSEQ-1M1"
    fix t assume [ty]: "t be FinSequenceFINSEQ-1M1"
    assume A1: "w ^FINSEQ-1K8 t is-a-proper-prefix-ofTREES-1R3 w ^FINSEQ-1K8 s"
    then have "w ^FINSEQ-1K8 t is-a-prefix-ofTREES-1R2 w ^FINSEQ-1K8 s"
       sorry
    then obtain a where
      [ty]:"a be FinSequenceFINSEQ-1M1" and 
      A2: "w ^FINSEQ-1K8 s =FINSEQ-1R1 (w ^FINSEQ-1K8 t)^FINSEQ-1K8 a"
      using trees_1_th_1 sorry
    have "(w ^FINSEQ-1K8 t)^FINSEQ-1K8 a =FINSEQ-1R1 w ^FINSEQ-1K8 (t ^FINSEQ-1K8 a)"
      using finseq_1_th_32 sorry
    then have "s =FINSEQ-1R1 t ^FINSEQ-1K8 a"
      using A2 finseq_1_th_33 sorry
    then have "t is-a-prefix-ofTREES-1R2 s"
      using trees_1_th_1 sorry
    thus "t is-a-proper-prefix-ofTREES-1R3 s"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_50:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds n <>HIDDENR2 m implies  not <*FINSEQ-1K10 n*> is-a-prefix-ofTREES-1R2 (<*FINSEQ-1K10 m*>)^FINSEQ-1K8 s"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for s be FinSequenceFINSEQ-1M1 holds n <>HIDDENR2 m implies (<*FINSEQ-1K10 n*> is-a-prefix-ofTREES-1R2 (<*FINSEQ-1K10 m*>)^FINSEQ-1K8 s implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix s assume [ty]: "s be FinSequenceFINSEQ-1M1"
    assume A1: "n <>HIDDENR2 m"
    assume "<*FINSEQ-1K10 n*> is-a-prefix-ofTREES-1R2 (<*FINSEQ-1K10 m*>)^FINSEQ-1K8 s"
    then have A2: " ex a be FinSequenceFINSEQ-1M1 st (<*FINSEQ-1K10 m*>)^FINSEQ-1K8 s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 a"
      using trees_1_th_1 sorry
    have "m =HIDDENR1 ((<*FINSEQ-1K10 m*>)^FINSEQ-1K8 s).FUNCT-1K1 \<one>\<^sub>M"
      using finseq_1_th_41 sorry
    also have "... = n"
      using A2 finseq_1_th_41 sorry
    finally have "m =HIDDENR1 n"
       sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_51:
"elementary-treeTREES-1K2 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
proof-
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> } implies x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<one>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }) & (x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<one>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> })"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> } implies x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<one>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
    proof-
      have "x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> } implies  not ( not x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 \<one>\<^sub>M } &  not x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 })"
      proof(rule impI)
        assume "x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
        then have "x =HIDDENR1 {}XBOOLE-0K1 or x =HIDDENR1 <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>"
          using tarski_def_2 sorry
        thus " not ( not x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 \<one>\<^sub>M } &  not x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 })"
          using tarski_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A1: "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<one>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
    have "x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
    proof-
      show "x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
      proof-
        have cases: "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<one>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
          using A1 sorry
        have case1: "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<one>\<^sub>M } implies x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
        proof(rule impI)
          assume "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<one>\<^sub>M }"
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A2: "x =HIDDENR1 <*FINSEQ-1K10 n*>"and A3: "n <XXREAL-0R3 \<one>\<^sub>M"
             sorry
          have "n =XBOOLE-0R4 0NUMBERSK6"
            using A3 nat_1_th_25 sorry
          thus "x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
            using A2 tarski_def_2 sorry
        qed
        have case2: "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
        proof(rule impI)
          assume "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
          then have "x =HIDDENR1 {}XBOOLE-0K1"
            using tarski_def_1 sorry
          thus "x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
            using tarski_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "x inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
       sorry
  qed "sorry"
  thus "elementary-treeTREES-1K2 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *> }"
    using xboole_0_def_3 sorry
qed

mtheorem trees_1_th_52:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not <*FINSEQ-1K10 n*> is-a-proper-prefix-ofTREES-1R3 <*FINSEQ-1K10 m*>"
  using trees_1_th_3 sorry

mtheorem trees_1_th_53:
"elementary-treeTREES-1K2 \<two>\<^sub>M =XBOOLE-0R4 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
proof-
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> } implies x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<two>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }) & (x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<two>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> })"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> } implies x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<two>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
    proof-
      have "x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> } implies  not ( not x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 \<two>\<^sub>M } &  not x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 })"
      proof(rule impI)
        assume "x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
        then have "(x =HIDDENR1 {}XBOOLE-0K1 or x =HIDDENR1 <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) or x =HIDDENR1 <*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*>"
          using enumset1_def_1 sorry
        thus " not ( not x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 \<two>\<^sub>M } &  not x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 })"
          using tarski_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A1: "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<two>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
    have "x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
    proof-
      show "x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
      proof-
        have cases: "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<two>\<^sub>M } or x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
          using A1 sorry
        have case1: "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<two>\<^sub>M } implies x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
        proof(rule impI)
          assume "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 \<two>\<^sub>M }"
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A2: "x =HIDDENR1 <*FINSEQ-1K10 n*>"and A3: "n <XXREAL-0R3 \<two>\<^sub>M"
             sorry
          have " ex VarFor1 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M) & n =XBOOLE-0R4 VarFor1"
            using A3 sorry
          thus "x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
            using A2 A3 enumset1_def_1 sorry
        qed
        have case2: "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
        proof(rule impI)
          assume "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
          then have "x =HIDDENR1 {}XBOOLE-0K1"
            using tarski_def_1 sorry
          thus "x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
            using enumset1_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "x inHIDDENR3 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
       sorry
  qed "sorry"
  thus "elementary-treeTREES-1K2 \<two>\<^sub>M =XBOOLE-0R4 {ENUMSET1K1 {}XBOOLE-0K1,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>,<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> \<one>\<^sub>M*> }"
    using xboole_0_def_3 sorry
qed

mtheorem trees_1_th_54:
" for T be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds t inTARSKIR2 LeavesTREES-1K3 T iff  not t ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) inTARSKIR2 T"
proof-
  have " for T be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds (t inTARSKIR2 LeavesTREES-1K3 T implies  not t ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) inTARSKIR2 T) & ( not t ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) inTARSKIR2 T &  not t inTARSKIR2 LeavesTREES-1K3 T implies  False )"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix t assume [ty]: "t be ElementTREES-1M2-of T"
    show "t inTARSKIR2 LeavesTREES-1K3 T implies  not t ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) inTARSKIR2 T"
    proof(rule impI)
      assume A1: "t inTARSKIR2 LeavesTREES-1K3 T"
      have "t is-a-proper-prefix-ofTREES-1R3 t ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>)"
        using trees_1_th_7 sorry
      thus " not t ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) inTARSKIR2 T"
        using A1 trees_1_def_5 sorry
    qed
    assume A2: " not t ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> (<*FINSEQ-1K13\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 *>) inTARSKIR2 T"
      and A3: " not t inTARSKIR2 LeavesTREES-1K3 T"
    obtain q where
      [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
      A4: "q inTARSKIR2 T"and A5: "t is-a-proper-prefix-ofTREES-1R3 q"
      using A3 trees_1_def_5 sorry
    have "t is-a-prefix-ofTREES-1R2 q"
      using A5 sorry
    then obtain r where
      [ty]:"r be FinSequenceFINSEQ-1M1" and 
      A6: "q =FINSEQ-1R1 t ^FINSEQ-1K8 r"
      using trees_1_th_1 sorry
    have 
      [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      using A6 finseq_1_th_36 sorry
    have "lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 lenFINSEQ-1K4 r"
      using A6 finseq_1_th_22 sorry
    then have "lenFINSEQ-1K4 r <>HIDDENR2 0NUMBERSK6"
      using A5 trees_1_th_6 sorry
    then have "r <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then obtain p x where
      [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "x be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A7: "r =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p"
      using finseq_2_th_130 sorry
    have "q =FINSEQ-1R1 (t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x*>))^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p"
      using A6 A7 finseq_1_th_32 sorry
    then have "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x*>) inTARSKIR2 T"
      using A4 trees_1_th_21 sorry
    thus " False "
      using A2 trees_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_1_th_55:
" for T be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds t inTARSKIR2 LeavesTREES-1K3 T iff  not ( ex n be NatNAT-1M1 st t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T)"
proof-
  have " for T be TreeTREES-1M1 holds  for t be ElementTREES-1M2-of T holds (t inTARSKIR2 LeavesTREES-1K3 T implies (( ex n be NatNAT-1M1 st t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T) implies  False )) & ( not ( ex n be NatNAT-1M1 st t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T) &  not t inTARSKIR2 LeavesTREES-1K3 T implies  False )"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix t assume [ty]: "t be ElementTREES-1M2-of T"
    show "t inTARSKIR2 LeavesTREES-1K3 T implies (( ex n be NatNAT-1M1 st t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T) implies  False )"
    proof(rule impI,rule impI)
      assume A1: "t inTARSKIR2 LeavesTREES-1K3 T"
      assume Given: " ex n be NatNAT-1M1 st t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A2: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
         sorry
      obtain nn where 
        [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
        using ordinal1_def_12 sorry
      have A3: " not t is-a-proper-prefix-ofTREES-1R3 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> nn*>)"
        using A1 A2 trees_1_def_5 sorry
      have "t is-a-prefix-ofTREES-1R2 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
        using trees_1_th_1 sorry
      then have A4: "t =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
        using A3 sorry
      have "t =FINSEQ-1R1 t ^FINSEQ-1K8 {}XBOOLE-0K1"
        using finseq_1_th_34 sorry
      thus " False "
        using A4 finseq_1_th_33 sorry
    qed
    assume A5: " not ( ex n be NatNAT-1M1 st t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T)"
      and A6: " not t inTARSKIR2 LeavesTREES-1K3 T"
    obtain q where
      [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
      A7: "q inTARSKIR2 T"and A8: "t is-a-proper-prefix-ofTREES-1R3 q"
      using A6 trees_1_def_5 sorry
    have "t is-a-prefix-ofTREES-1R2 q"
      using A8 sorry
    then obtain r where
      [ty]:"r be FinSequenceFINSEQ-1M1" and 
      A9: "q =FINSEQ-1R1 t ^FINSEQ-1K8 r"
      using trees_1_th_1 sorry
    have 
      [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      using A9 finseq_1_th_36 sorry
    have "lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 lenFINSEQ-1K4 r"
      using A9 finseq_1_th_22 sorry
    then have "lenFINSEQ-1K4 r <>HIDDENR2 0NUMBERSK6"
      using A8 trees_1_th_6 sorry
    then have "r <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then obtain p x where
      [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "x be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A10: "r =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p"
      using finseq_2_th_130 sorry
    have "q =FINSEQ-1R1 (t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> x*>))^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p"
      using A9 A10 finseq_1_th_32 sorry
    thus " False "
      using A5 A7 trees_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_1_def_14 ("TrivialInfiniteTreeTREES-1K8" 164 ) where
"func TrivialInfiniteTreeTREES-1K8 \<rightarrow> setHIDDENM2 equals
  {k  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) where k be NatNAT-1M1 :  True  }"
proof-
  (*coherence*)
    show "{k  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) where k be NatNAT-1M1 :  True  } be setHIDDENM2"
       sorry
qed "sorry"

mtheorem trees_1_cl_12:
"cluster TrivialInfiniteTreeTREES-1K8 as-term-is  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
proof
(*coherence*)
  show "TrivialInfiniteTreeTREES-1K8 be  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
  proof-
    have "TrivialInfiniteTreeTREES-1K8 be  non emptyXBOOLE-0V1 & TrivialInfiniteTreeTREES-1K8 be Tree-likeTREES-1V1"
    proof(rule conjMI)
      let ?X = "TrivialInfiniteTreeTREES-1K8"
      have "(0NUMBERSK6) |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) inTARSKIR2 ?X"
         sorry
      thus "TrivialInfiniteTreeTREES-1K8 be  non emptyXBOOLE-0V1"
         sorry
      have "TrivialInfiniteTreeTREES-1K8 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 TrivialInfiniteTreeTREES-1K8 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 TrivialInfiniteTreeTREES-1K8) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 TrivialInfiniteTreeTREES-1K8 implies (n <=XXREAL-0R1 m implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 TrivialInfiniteTreeTREES-1K8)))"
      proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
        show "TrivialInfiniteTreeTREES-1K8 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 TrivialInfiniteTreeTREES-1K8 implies x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?X"
            then have " ex k be NatNAT-1M1 st x =HIDDENR1 k  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
               sorry
            thus "x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
              using finseq_1_def_11 sorry
          qed "sorry"
          thus "TrivialInfiniteTreeTREES-1K8 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
            using tarski_def_3 sorry
        qed
        show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 TrivialInfiniteTreeTREES-1K8 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 TrivialInfiniteTreeTREES-1K8"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume "p inTARSKIR2 ?X"
          then obtain m where
            [ty]:"m be NatNAT-1M1" and 
            A1: "p =FINSEQ-1R1 m  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
             sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 p implies x inHIDDENR3 TrivialInfiniteTreeTREES-1K8"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A2: "x inHIDDENR3 ProperPrefixesTREES-1K1 p"
            then have 
              [ty]:"x be FinSequenceFINSEQ-1M1"
              using trees_1_th_11 sorry
            have A3: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 x implies x .FUNCT-1K1 k =XBOOLE-0R4 (lenFINSEQ-1K4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 k"
            proof-
              have " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 x implies (lenFINSEQ-1K4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 k =HIDDENR1 x .FUNCT-1K1 k"
              proof(rule ballI,rule impI)
                have "x is-a-proper-prefix-ofTREES-1R3 p"
                  using A2 trees_1_th_12 sorry
                then have A4: "x c=RELAT-1R2 p"
                   sorry
                fix k assume [ty]: "k be NatNAT-1M1"
                assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 x"
                then have A5: "k inTARSKIR2 domFINSEQ-1K5 x"
                  using finseq_3_th_25 sorry
                have "(lenFINSEQ-1K4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 k =HIDDENR1 0NUMBERSK6"
                   sorry
                also have "... = p .FUNCT-1K1 k"
                  using A1 sorry
                also have "... = x .FUNCT-1K1 k"
                  using A5 A4 grfunc_1_th_2 sorry
                finally show "(lenFINSEQ-1K4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 k =HIDDENR1 x .FUNCT-1K1 k"
                   sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 (lenFINSEQ-1K4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6))"
              using card_1_def_7 sorry
            then have "x =FINSEQ-1R1 lenFINSEQ-1K4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
              using A3 finseq_1_th_14 sorry
            thus "x inHIDDENR3 TrivialInfiniteTreeTREES-1K8"
               sorry
          qed "sorry"
          thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 TrivialInfiniteTreeTREES-1K8"
            using tarski_def_3 sorry
        qed "sorry"
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        fix m assume [ty]: "m be NatNAT-1M1"
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 ?X"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A6: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) =FINSEQ-1R1 k  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
           sorry
        assume A7: "n <=XXREAL-0R1 m"
        have "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
          using finseq_2_th_16 sorry
        then have "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)).FUNCT-1K1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)) =XBOOLE-0R4 m"
          using finseq_1_th_42 sorry
        then have A8: "m =XBOOLE-0R4 0NUMBERSK6"
          using A6 sorry
        have A9: " for z be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 z & z <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) implies (lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 z =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)).FUNCT-1K1 z"
        proof-
          have " for z be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 z & z <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) implies (lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 z =HIDDENR1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)).FUNCT-1K1 z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be NatNAT-1M1"
            assume "\<one>\<^sub>M <=XXREAL-0R1 z & z <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))"
            have "(lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 z =HIDDENR1 0NUMBERSK6"
               sorry
            also have "... = (p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)).FUNCT-1K1 z"
              using A6 sorry
            also have "... = (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)).FUNCT-1K1 z"
              using A7 A8 sorry
            finally show "(lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)).FUNCT-1K1 z =HIDDENR1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)).FUNCT-1K1 z"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 lenFINSEQ-1K4 (lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6))"
          using card_1_def_7 sorry
        then have "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) =FINSEQ-1R1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
          using A9 finseq_1_th_14 sorry
        thus "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 TrivialInfiniteTreeTREES-1K8"
           sorry
      qed "sorry"
      thus "TrivialInfiniteTreeTREES-1K8 be Tree-likeTREES-1V1"
        using trees_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_1_th_56:
"(NATNUMBERSK1,TrivialInfiniteTreeTREES-1K8)are-equipotentTARSKIR3"
proof-
  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =XBOOLE-0R4 Lamb1  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
  have A1: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 st ?P(x,y)"
  proof-
    have " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar31 be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 st tVar31 =XBOOLE-0R4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) inTARSKIR2 TrivialInfiniteTreeTREES-1K8"
         sorry
      then obtain y where 
        [ty]:"y be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8" and yDef:"y = x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
         sorry
      show " ex tVar31 be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 st tVar31 =XBOOLE-0R4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
      proof(rule bexI[of _ "y"])
        show "y =XBOOLE-0R4 x  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
           sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  obtain f where
    [ty]:"f be sequenceNAT-1M2-of TrivialInfiniteTreeTREES-1K8" and 
    A2: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(x,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,TrivialInfiniteTreeTREES-1K8)\<^esub> x)"
    using funct_2_sch_3 A1 sorry
  have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & rngRELAT-1K2 f =HIDDENR1 TrivialInfiniteTreeTREES-1K8)"
  proof(rule conjMI,rule conjMI)
    show "f be one-to-oneFUNCT-1V2"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
        assume A4: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
        have 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A3 funct_2_def_1 sorry
        have "?P(x,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,TrivialInfiniteTreeTREES-1K8)\<^esub> x) & ?P(y,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,TrivialInfiniteTreeTREES-1K8)\<^esub> y)"
          using A2 sorry
        thus "x =HIDDENR1 y"
          using A4 finseq_2_th_143 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    show A5: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 TrivialInfiniteTreeTREES-1K8 & TrivialInfiniteTreeTREES-1K8 c=TARSKIR1 rngRELAT-1K2 f"
    proof(rule conjMI)
      show "rngFUNCT-1K2 f c=TARSKIR1 TrivialInfiniteTreeTREES-1K8"
        using relat_1_def_19 sorry
      have " for a be objectHIDDENM1 holds a inHIDDENR3 TrivialInfiniteTreeTREES-1K8 implies a inHIDDENR3 rngRELAT-1K2 f"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 TrivialInfiniteTreeTREES-1K8"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A6: "a =HIDDENR1 k  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
           sorry
        have A7: "k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "f .FUNCT-1K1 k =HIDDENR1 a"
          using A2 A6 sorry
        thus "a inHIDDENR3 rngRELAT-1K2 f"
          using A5 funct_1_def_3 A7 sorry
      qed "sorry"
      thus "TrivialInfiniteTreeTREES-1K8 c=TARSKIR1 rngRELAT-1K2 f"
        using tarski_def_3 sorry
    qed
    thus "rngRELAT-1K2 f =HIDDENR1 TrivialInfiniteTreeTREES-1K8"
      using xboole_0_def_10 sorry
  qed
  thus "(NATNUMBERSK1,TrivialInfiniteTreeTREES-1K8)are-equipotentTARSKIR3"
    using bexI[of _ "f"] wellord2_def_4 sorry
qed

mtheorem trees_1_cl_13:
"cluster TrivialInfiniteTreeTREES-1K8 as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "TrivialInfiniteTreeTREES-1K8 be infiniteFINSET-1V2"
    using trees_1_th_56 card_1_th_38 sorry
qed "sorry"

end
