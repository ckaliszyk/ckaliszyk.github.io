theory absvalue
  imports int_1 complex1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z, r, s, t for "RealXREAL-0M1"
abbreviation(input) ABSVALUEK1(" |.ABSVALUEK1  _ .|" [0]164) where
  " |.ABSVALUEK1 x.| \<equiv>  |.COMPLEX1K10 x.|"

mtheorem absvalue_def_1:
  mlet "x be RealXREAL-0M1"
"redefine func  |.ABSVALUEK1 x.| \<rightarrow> objectHIDDENM1 equals
  x if 0NUMBERSK6 <=XXREAL-0R1 x otherwise -XCMPLX-0K4 x"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds (0NUMBERSK6 <=XXREAL-0R1 x implies (it =HIDDENR1  |.ABSVALUEK1 x.| iff it =HIDDENR1 x)) & ( not 0NUMBERSK6 <=XXREAL-0R1 x implies (it =HIDDENR1  |.ABSVALUEK1 x.| iff it =HIDDENR1 -XCMPLX-0K4 x))"
    using complex1_th_43 complex1_th_70 sorry
(*consistency*)
  show " for it be objectHIDDENM1 holds  True "
    using complex1_th_43 complex1_th_70 sorry
qed "sorry"

mtheorem absvalue_reduce_1:
  mlet "x be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1"
"reduce  |.ABSVALUEK1 x.| to x"
proof
(*reducibility*)
  show " |.ABSVALUEK1 x.| =HIDDENR1 x"
    using absvalue_def_1 sorry
qed "sorry"

mtheorem absvalue_th_1:
" for x be RealXREAL-0M1 holds  |.ABSVALUEK1 x.| =COMPLEX1R1 x or  |.ABSVALUEK1 x.| =COMPLEX1R1 -XCMPLX-0K4 x"
  using absvalue_def_1 sorry

mtheorem absvalue_th_2:
" for x be RealXREAL-0M1 holds x =COMPLEX1R1 0NUMBERSK6 iff  |.ABSVALUEK1 x.| =COMPLEX1R1 0NUMBERSK6"
  using complex1_th_47 sorry

mtheorem absvalue_th_3:
" for x be RealXREAL-0M1 holds  |.ABSVALUEK1 x.| =COMPLEX1R1 -XCMPLX-0K4 x & x <>HIDDENR2 0NUMBERSK6 implies x <XXREAL-0R3 0NUMBERSK6"
  using absvalue_def_1 sorry

mtheorem absvalue_th_4:
" for x be RealXREAL-0M1 holds -XCMPLX-0K4  |.ABSVALUEK1 x.| <=XXREAL-0R1 x & x <=XXREAL-0R1  |.ABSVALUEK1 x.|"
proof-
  have " for x be RealXREAL-0M1 holds -XCMPLX-0K4  |.ABSVALUEK1 x.| <=XXREAL-0R1 x & x <=XXREAL-0R1  |.ABSVALUEK1 x.|"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    show "-XCMPLX-0K4  |.ABSVALUEK1 x.| <=XXREAL-0R1 x & x <=XXREAL-0R1  |.ABSVALUEK1 x.|"
    proof-
      have cases: "x <XXREAL-0R3 0NUMBERSK6 or 0NUMBERSK6 <=XXREAL-0R1 x"
         sorry
      have case1: "x <XXREAL-0R3 0NUMBERSK6 implies -XCMPLX-0K4  |.ABSVALUEK1 x.| <=XXREAL-0R1 x & x <=XXREAL-0R1  |.ABSVALUEK1 x.|"
      proof(rule impI)
        assume A1: "x <XXREAL-0R3 0NUMBERSK6"
        then have " |.ABSVALUEK1 x.| =COMPLEX1R1 -XCMPLX-0K4 x"
          using absvalue_def_1 sorry
        thus "-XCMPLX-0K4  |.ABSVALUEK1 x.| <=XXREAL-0R1 x & x <=XXREAL-0R1  |.ABSVALUEK1 x.|"
          using A1 sorry
      qed
      have case2: "0NUMBERSK6 <=XXREAL-0R1 x implies -XCMPLX-0K4  |.ABSVALUEK1 x.| <=XXREAL-0R1 x & x <=XXREAL-0R1  |.ABSVALUEK1 x.|"
      proof(rule impI)
        assume A2: "0NUMBERSK6 <=XXREAL-0R1 x"
        then have "-XCMPLX-0K4 x <=XXREAL-0R1 -XCMPLX-0K4 0NUMBERSK6"
           sorry
        thus "-XCMPLX-0K4  |.ABSVALUEK1 x.| <=XXREAL-0R1 x & x <=XXREAL-0R1  |.ABSVALUEK1 x.|"
          using A2 absvalue_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_5:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds -XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y iff  |.ABSVALUEK1 x.| <=XXREAL-0R1 y"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (-XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y implies  |.ABSVALUEK1 x.| <=XXREAL-0R1 y) & ( |.ABSVALUEK1 x.| <=XXREAL-0R1 y implies -XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    show "-XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y implies  |.ABSVALUEK1 x.| <=XXREAL-0R1 y"
    proof(rule impMI ,rule impI)
      assume A1: "-XCMPLX-0K4 y <=XXREAL-0R1 x"
        and A2: "x <=XXREAL-0R1 y"
      have "-XCMPLX-0K4 x <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 y)"
        using A1 xreal_1_th_24 sorry
      thus " |.ABSVALUEK1 x.| <=XXREAL-0R1 y"
        using A2 absvalue_def_1 sorry
    qed
    assume A3: " |.ABSVALUEK1 x.| <=XXREAL-0R1 y"
    then have A4: "0NUMBERSK6 <=XXREAL-0R1 y"
      using complex1_th_46 sorry
    show "-XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y"
    proof-
      have cases: "(0NUMBERSK6 <XXREAL-0R3 x or x <XXREAL-0R3 0NUMBERSK6) or x =COMPLEX1R1 -XCMPLX-0K4 0NUMBERSK6"
         sorry
      have case1: "0NUMBERSK6 <XXREAL-0R3 x implies -XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y"
      proof(rule impI)
        assume "0NUMBERSK6 <XXREAL-0R3 x"
        thus "-XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y"
          using A3 A4 absvalue_def_1 sorry
      qed
      have case2: "x <XXREAL-0R3 0NUMBERSK6 implies -XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y"
      proof(rule impI)
        assume A5: "x <XXREAL-0R3 0NUMBERSK6"
        then have "-XCMPLX-0K4 x <=XXREAL-0R1 y"
          using A3 absvalue_def_1 sorry
        then have "-XCMPLX-0K4 y <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 x)"
          using xreal_1_th_24 sorry
        thus "-XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y"
          using A5 sorry
      qed
      have case3: "x =COMPLEX1R1 -XCMPLX-0K4 0NUMBERSK6 implies -XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y"
      proof(rule impI)
        assume "x =COMPLEX1R1 -XCMPLX-0K4 0NUMBERSK6"
        thus "-XCMPLX-0K4 y <=XXREAL-0R1 x & x <=XXREAL-0R1 y"
          using A3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_6:
" for x be RealXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 ( |.ABSVALUEK1 \<one>\<^sub>M /XCMPLX-0K7 x .|) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 ( |.ABSVALUEK1 \<one>\<^sub>M /XCMPLX-0K7 x .|) =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x <>HIDDENR2 0NUMBERSK6"
    then have "( |.ABSVALUEK1 x.|)*XCMPLX-0K3 ( |.ABSVALUEK1 \<one>\<^sub>M /XCMPLX-0K7 x .|) =COMPLEX1R1  |.ABSVALUEK1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) .| &  |.ABSVALUEK1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) .| =COMPLEX1R1  |.ABSVALUEK1 \<one>\<^sub>M.|"
      using complex1_th_65 xcmplx_1_th_106 sorry
    thus "( |.ABSVALUEK1 x.|)*XCMPLX-0K3 ( |.ABSVALUEK1 \<one>\<^sub>M /XCMPLX-0K7 x .|) =COMPLEX1R1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_7:
" for x be RealXREAL-0M1 holds  |.ABSVALUEK1 \<one>\<^sub>M /XCMPLX-0K7 x .| =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ( |.ABSVALUEK1 x.|)"
  using complex1_th_80 sorry

mtheorem absvalue_th_8:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x *XCMPLX-0K3 y implies sqrtSQUARE-1K3 (x *XCMPLX-0K3 y) =COMPLEX1R1 sqrtSQUARE-1K3 ( |.ABSVALUEK1 x.|) *XCMPLX-0K3 sqrtSQUARE-1K3 ( |.ABSVALUEK1 y.|)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x *XCMPLX-0K3 y implies sqrtSQUARE-1K3 (x *XCMPLX-0K3 y) =COMPLEX1R1 sqrtSQUARE-1K3 ( |.ABSVALUEK1 x.|) *XCMPLX-0K3 sqrtSQUARE-1K3 ( |.ABSVALUEK1 y.|)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume "0NUMBERSK6 <=XXREAL-0R1 x *XCMPLX-0K3 y"
    then have " |.ABSVALUEK1 x *XCMPLX-0K3 y .| =COMPLEX1R1 x *XCMPLX-0K3 y"
      using absvalue_def_1 sorry
    then have A1: "( |.ABSVALUEK1 x.|)*XCMPLX-0K3 ( |.ABSVALUEK1 y.|) =COMPLEX1R1 x *XCMPLX-0K3 y"
      using complex1_th_65 sorry
    have "0NUMBERSK6 <=XXREAL-0R1  |.ABSVALUEK1 x.| & 0NUMBERSK6 <=XXREAL-0R1  |.ABSVALUEK1 y.|"
      using complex1_th_46 sorry
    thus "sqrtSQUARE-1K3 (x *XCMPLX-0K3 y) =COMPLEX1R1 sqrtSQUARE-1K3 ( |.ABSVALUEK1 x.|) *XCMPLX-0K3 sqrtSQUARE-1K3 ( |.ABSVALUEK1 y.|)"
      using A1 square_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_9:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds  |.ABSVALUEK1 x.| <=XXREAL-0R1 z &  |.ABSVALUEK1 y.| <=XXREAL-0R1 t implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <=XXREAL-0R1 z +XCMPLX-0K2 t"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds  |.ABSVALUEK1 x.| <=XXREAL-0R1 z &  |.ABSVALUEK1 y.| <=XXREAL-0R1 t implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <=XXREAL-0R1 z +XCMPLX-0K2 t"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix z assume [ty]: "z be RealXREAL-0M1"
    fix t assume [ty]: "t be RealXREAL-0M1"
    assume " |.ABSVALUEK1 x.| <=XXREAL-0R1 z &  |.ABSVALUEK1 y.| <=XXREAL-0R1 t"
    then have " |.ABSVALUEK1 x +XCMPLX-0K2 y .| <=XXREAL-0R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.| &  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.| <=XXREAL-0R1 z +XCMPLX-0K2 t"
      using complex1_th_56 xreal_1_th_7 sorry
    thus " |.ABSVALUEK1 x +XCMPLX-0K2 y .| <=XXREAL-0R1 z +XCMPLX-0K2 t"
      using xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_10:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x /XCMPLX-0K7 y implies sqrtSQUARE-1K3 (x /XCMPLX-0K7 y) =COMPLEX1R1 sqrtSQUARE-1K3 ( |.ABSVALUEK1 x.|) /XCMPLX-0K7 sqrtSQUARE-1K3 ( |.ABSVALUEK1 y.|)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x /XCMPLX-0K7 y implies sqrtSQUARE-1K3 (x /XCMPLX-0K7 y) =COMPLEX1R1 sqrtSQUARE-1K3 ( |.ABSVALUEK1 x.|) /XCMPLX-0K7 sqrtSQUARE-1K3 ( |.ABSVALUEK1 y.|)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 x /XCMPLX-0K7 y"
    then have "x /XCMPLX-0K7 y =COMPLEX1R1  |.ABSVALUEK1 x /XCMPLX-0K7 y .|"
      using absvalue_def_1 sorry
    then have A1: "x /XCMPLX-0K7 y =COMPLEX1R1 ( |.ABSVALUEK1 x.|)/XCMPLX-0K7 ( |.ABSVALUEK1 y.|)"
      using complex1_th_67 sorry
    have "0NUMBERSK6 <=XXREAL-0R1  |.ABSVALUEK1 x.| & 0NUMBERSK6 <=XXREAL-0R1  |.ABSVALUEK1 y.|"
      using complex1_th_46 sorry
    thus "sqrtSQUARE-1K3 (x /XCMPLX-0K7 y) =COMPLEX1R1 sqrtSQUARE-1K3 ( |.ABSVALUEK1 x.|) /XCMPLX-0K7 sqrtSQUARE-1K3 ( |.ABSVALUEK1 y.|)"
      using A1 square_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_11:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x *XCMPLX-0K3 y implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x *XCMPLX-0K3 y implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x *XCMPLX-0K3 y"
    show " |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
    proof-
      have cases: "x *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 x *XCMPLX-0K3 y"
        using A1 sorry
      have case1: "x *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6 implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
      proof(rule impI)
        assume "x *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6"
        then have "x =COMPLEX1R1 0NUMBERSK6 or y =COMPLEX1R1 0NUMBERSK6"
          using xcmplx_1_th_6 sorry
        thus " |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
           sorry
      qed
      have case2: "0NUMBERSK6 <XXREAL-0R3 x *XCMPLX-0K3 y implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
      proof(rule impI)
        assume A5: "0NUMBERSK6 <XXREAL-0R3 x *XCMPLX-0K3 y"
        then have A6: "x <>HIDDENR2 0NUMBERSK6 & y <>HIDDENR2 0NUMBERSK6"
           sorry
        show " |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
        proof-
          have cases: "0NUMBERSK6 <XXREAL-0R3 x & 0NUMBERSK6 <XXREAL-0R3 y or x <XXREAL-0R3 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6"
            using A5 A6 sorry
          have case1: "0NUMBERSK6 <XXREAL-0R3 x & 0NUMBERSK6 <XXREAL-0R3 y implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
          proof(rule impI)
            assume A7: "0NUMBERSK6 <XXREAL-0R3 x & 0NUMBERSK6 <XXREAL-0R3 y"
            have " |.ABSVALUEK1 x.| =COMPLEX1R1 x &  |.ABSVALUEK1 y.| =COMPLEX1R1 y"
              using A7 absvalue_def_1 sorry
            thus " |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
              using A7 absvalue_def_1 sorry
          qed
          have case2: "x <XXREAL-0R3 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6 implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
          proof(rule impMI ,rule impI)
            assume A8: "x <XXREAL-0R3 0NUMBERSK6"
              and A9: "y <XXREAL-0R3 0NUMBERSK6"
            have " |.ABSVALUEK1 x.| =COMPLEX1R1 -XCMPLX-0K4 x"
              using A8 absvalue_def_1 sorry
            then have " |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.| =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 y)"
              using A9 absvalue_def_1 sorry
            also have "... = -XCMPLX-0K4 (x +XCMPLX-0K2 y)"
               sorry
            finally have " |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.| =HIDDENR1 -XCMPLX-0K4 (x +XCMPLX-0K2 y)"
               sorry
            thus " |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
              using A8 A9 absvalue_def_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_12:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.| implies 0NUMBERSK6 <=XXREAL-0R1 x *XCMPLX-0K3 y"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.| & 0NUMBERSK6 >XXREAL-0R4 x *XCMPLX-0K3 y implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have A1: "x *XCMPLX-0K3 y <XXREAL-0R3 0NUMBERSK6 implies x <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 y or 0NUMBERSK6 <XXREAL-0R3 x & y <XXREAL-0R3 0NUMBERSK6"
    proof-
      have "x *XCMPLX-0K3 y <XXREAL-0R3 0NUMBERSK6 implies  not ( not ( not x <XXREAL-0R3 0NUMBERSK6 &  not 0NUMBERSK6 <XXREAL-0R3 y) &  not ( not 0NUMBERSK6 <XXREAL-0R3 x &  not y <XXREAL-0R3 0NUMBERSK6))"
      proof(rule impI)
        assume A2: "x *XCMPLX-0K3 y <XXREAL-0R3 0NUMBERSK6"
        then have "x <>HIDDENR2 0NUMBERSK6 & y <>HIDDENR2 0NUMBERSK6"
           sorry
        thus " not ( not ( not x <XXREAL-0R3 0NUMBERSK6 &  not 0NUMBERSK6 <XXREAL-0R3 y) &  not ( not 0NUMBERSK6 <XXREAL-0R3 x &  not y <XXREAL-0R3 0NUMBERSK6))"
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A3: "(x <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 y) & x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6 implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
    proof-
      have "x <XXREAL-0R3 0NUMBERSK6 & (0NUMBERSK6 <XXREAL-0R3 y & x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6) implies  not  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A4: "x <XXREAL-0R3 0NUMBERSK6"
          and A5: "0NUMBERSK6 <XXREAL-0R3 y"
          and A6: "x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6"
        have "(-XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 x)+XCMPLX-0K2 (-XCMPLX-0K4 y) <XXREAL-0R3 (-XCMPLX-0K4 x)+XCMPLX-0K2 y"
          using A5 xreal_1_th_6 sorry
        then have A7: "-XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 (x +XCMPLX-0K2 y) <XXREAL-0R3 (-XCMPLX-0K4 x)+XCMPLX-0K2 y"
           sorry
        have " |.ABSVALUEK1 x.| =COMPLEX1R1 -XCMPLX-0K4 x &  |.ABSVALUEK1 y.| =COMPLEX1R1 y"
          using A4 A5 absvalue_def_1 sorry
        thus " not  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
          using A6 A7 absvalue_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A8: "(0NUMBERSK6 <XXREAL-0R3 x & y <XXREAL-0R3 0NUMBERSK6) & x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6 implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
    proof-
      have "0NUMBERSK6 <XXREAL-0R3 x & (y <XXREAL-0R3 0NUMBERSK6 & x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6) implies  not  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A9: "0NUMBERSK6 <XXREAL-0R3 x"
          and A10: "y <XXREAL-0R3 0NUMBERSK6"
          and A11: "x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6"
        have "(-XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 x)+XCMPLX-0K2 (-XCMPLX-0K4 y) <XXREAL-0R3 x +XCMPLX-0K2 (-XCMPLX-0K4 y)"
          using A9 xreal_1_th_6 sorry
        then have A12: "-XCMPLX-0K4 \<one>\<^sub>M *XCMPLX-0K3 (x +XCMPLX-0K2 y) <XXREAL-0R3 x +XCMPLX-0K2 (-XCMPLX-0K4 y)"
           sorry
        have " |.ABSVALUEK1 x.| =COMPLEX1R1 x &  |.ABSVALUEK1 y.| =COMPLEX1R1 -XCMPLX-0K4 y"
          using A9 A10 absvalue_def_1 sorry
        thus " not  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
          using A11 A12 absvalue_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A13: "(0NUMBERSK6 <XXREAL-0R3 x & y <XXREAL-0R3 0NUMBERSK6) & 0NUMBERSK6 <=XXREAL-0R1 x +XCMPLX-0K2 y implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
    proof-
      have "0NUMBERSK6 <XXREAL-0R3 x & (y <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 x +XCMPLX-0K2 y) implies  not  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A14: "0NUMBERSK6 <XXREAL-0R3 x"
          and A15: "y <XXREAL-0R3 0NUMBERSK6"
          and A16: "0NUMBERSK6 <=XXREAL-0R1 x +XCMPLX-0K2 y"
        have A17: " |.ABSVALUEK1 y.| =COMPLEX1R1 -XCMPLX-0K4 y"
          using A15 absvalue_def_1 sorry
        have "x +XCMPLX-0K2 y <XXREAL-0R3 x +XCMPLX-0K2 (-XCMPLX-0K4 y) &  |.ABSVALUEK1 x.| =COMPLEX1R1 x"
          using A14 A15 absvalue_def_1 xreal_1_th_6 sorry
        thus " not  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
          using A16 A17 absvalue_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A18: "(x <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 y) & 0NUMBERSK6 <=XXREAL-0R1 x +XCMPLX-0K2 y implies  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
    proof-
      have "x <XXREAL-0R3 0NUMBERSK6 & (0NUMBERSK6 <XXREAL-0R3 y & 0NUMBERSK6 <=XXREAL-0R1 x +XCMPLX-0K2 y) implies  not  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A19: "x <XXREAL-0R3 0NUMBERSK6"
          and A20: "0NUMBERSK6 <XXREAL-0R3 y"
          and A21: "0NUMBERSK6 <=XXREAL-0R1 x +XCMPLX-0K2 y"
        have A22: " |.ABSVALUEK1 y.| =COMPLEX1R1 y"
          using A20 absvalue_def_1 sorry
        have "x +XCMPLX-0K2 y <XXREAL-0R3 (-XCMPLX-0K4 x)+XCMPLX-0K2 y &  |.ABSVALUEK1 x.| =COMPLEX1R1 -XCMPLX-0K4 x"
          using A19 absvalue_def_1 xreal_1_th_6 sorry
        thus " not  |.ABSVALUEK1 x +XCMPLX-0K2 y .| <>HIDDENR2  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.|"
          using A21 A22 absvalue_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume " |.ABSVALUEK1 x +XCMPLX-0K2 y .| =COMPLEX1R1  |.ABSVALUEK1 x.| +XCMPLX-0K2  |.ABSVALUEK1 y.| & 0NUMBERSK6 >XXREAL-0R4 x *XCMPLX-0K3 y"
    thus " False "
      using A1 A3 A18 A8 A13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_13:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ( |.ABSVALUEK1 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.ABSVALUEK1 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|) +XCMPLX-0K2 ( |.ABSVALUEK1 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 y.|)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ( |.ABSVALUEK1 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.ABSVALUEK1 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|) +XCMPLX-0K2 ( |.ABSVALUEK1 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 y.|)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have A1: " for s be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds (s <=XXREAL-0R1 t & 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 s) & 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 t implies s /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 s) <=XXREAL-0R1 t /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 t)"
    proof-
      have " for s be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds s <=XXREAL-0R1 t & (0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 s & 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 t) implies s /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 s) <=XXREAL-0R1 t /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 t)"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s assume [ty]: "s be RealXREAL-0M1"
        fix t assume [ty]: "t be RealXREAL-0M1"
        assume A2: "s <=XXREAL-0R1 t"
          and A3: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 s"
          and A4: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 t"
        have "s *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 s *XCMPLX-0K3 t <=XXREAL-0R1 t +XCMPLX-0K2 s *XCMPLX-0K3 t"
          using A2 xreal_1_th_6 sorry
        then have "(s *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (t *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s)\<inverse>XCMPLX-0K5"
          using A3 xreal_1_th_64 sorry
        then have "(s *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 t *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 s)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s)\<inverse>XCMPLX-0K5)"
           sorry
        then have "(s *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 t *XCMPLX-0K3 \<one>\<^sub>M"
          using A3 xcmplx_0_def_7 sorry
        then have "((s *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 t *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t)\<inverse>XCMPLX-0K5"
          using A4 xreal_1_th_64 sorry
        then have "(s *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 t)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t)\<inverse>XCMPLX-0K5) <=XXREAL-0R1 t *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t)\<inverse>XCMPLX-0K5"
           sorry
        then have "(s *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 s)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<one>\<^sub>M <=XXREAL-0R1 t *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t)\<inverse>XCMPLX-0K5"
          using A4 xcmplx_0_def_7 sorry
        then have "s /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 s) <=XXREAL-0R1 t *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 t)\<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        thus "s /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 s) <=XXREAL-0R1 t /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 t)"
          using xcmplx_0_def_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    let ?a = " |.ABSVALUEK1 x.|"
    let ?b = " |.ABSVALUEK1 y.|"
    let ?c = " |.ABSVALUEK1 x +XCMPLX-0K2 y .|"
    have A5: "0NUMBERSK6 <=XXREAL-0R1 ?a"
      using complex1_th_46 sorry
    have A6: "0NUMBERSK6 <=XXREAL-0R1 ?b"
      using complex1_th_46 sorry
    have A7: "0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 ?a"
      using complex1_th_46 xreal_1_th_8 sorry
    have A8: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 ?a & 0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b implies ?a /XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b) <=XXREAL-0R1 ?a /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ?a)"
    proof-
      have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.| & 0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|)+XCMPLX-0K2  |.ABSVALUEK1 y.| implies ( |.ABSVALUEK1 x.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|)+XCMPLX-0K2  |.ABSVALUEK1 y.|) <=XXREAL-0R1 ( |.ABSVALUEK1 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|)"
      proof(rule impMI ,rule impI)
        assume A9: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 ?a"
          and A10: "0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b"
        have "0NUMBERSK6 +XCMPLX-0K2 ?a <=XXREAL-0R1 ?a *XCMPLX-0K3 ?b +XCMPLX-0K2 ?a"
          using A5 A6 xreal_1_th_6 sorry
        then have "?a *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ?a *XCMPLX-0K3 ?a <=XXREAL-0R1 ?a *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b) +XCMPLX-0K2 ?a *XCMPLX-0K3 ?a"
          using xreal_1_th_6 sorry
        then have "(?a *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (?a *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5"
          using A9 xreal_1_th_64 sorry
        then have "?a *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5) <=XXREAL-0R1 (?a *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5"
           sorry
        then have "?a *XCMPLX-0K3 \<one>\<^sub>M <=XXREAL-0R1 (?a *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5"
          using A7 xcmplx_0_def_7 sorry
        then have "?a *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 ((?a *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b))*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5"
          using A10 xreal_1_th_64 sorry
        then have "?a *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (?a *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5)"
           sorry
        then have "?a *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (?a *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<one>\<^sub>M"
          using A5 A6 xcmplx_0_def_7 sorry
        then have "?a /XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b) <=XXREAL-0R1 ?a *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)\<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        thus "( |.ABSVALUEK1 x.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|)+XCMPLX-0K2  |.ABSVALUEK1 y.|) <=XXREAL-0R1 ( |.ABSVALUEK1 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|)"
          using xcmplx_0_def_9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A11: "0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 ?b"
      using complex1_th_46 xreal_1_th_8 sorry
    have A12: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 ?b & 0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b implies ?b /XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b) <=XXREAL-0R1 ?b /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ?b)"
    proof-
      have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 y.| & 0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|)+XCMPLX-0K2  |.ABSVALUEK1 y.| implies ( |.ABSVALUEK1 y.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|)+XCMPLX-0K2  |.ABSVALUEK1 y.|) <=XXREAL-0R1 ( |.ABSVALUEK1 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 y.|)"
      proof(rule impMI ,rule impI)
        assume A13: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 ?b"
          and A14: "0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b"
        have "0NUMBERSK6 +XCMPLX-0K2 ?b <=XXREAL-0R1 ?a *XCMPLX-0K3 ?b +XCMPLX-0K2 ?b"
          using A5 A6 xreal_1_th_6 sorry
        then have "?b *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ?b *XCMPLX-0K3 ?b <=XXREAL-0R1 (\<one>\<^sub>M +XCMPLX-0K2 ?a)*XCMPLX-0K3 ?b +XCMPLX-0K2 ?b *XCMPLX-0K3 ?b"
          using xreal_1_th_6 sorry
        then have "(?b *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (?b *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5"
          using A13 xreal_1_th_64 sorry
        then have "?b *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?b)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5) <=XXREAL-0R1 (?b *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5"
           sorry
        then have "?b *XCMPLX-0K3 \<one>\<^sub>M <=XXREAL-0R1 (?b *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5"
          using A11 xcmplx_0_def_7 sorry
        then have "?b *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 ((?b *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b))*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5"
          using A14 xreal_1_th_64 sorry
        then have "?b *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (?b *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5)"
           sorry
        then have "?b *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (?b *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<one>\<^sub>M"
          using A5 A6 xcmplx_0_def_7 sorry
        then have "?b /XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b) <=XXREAL-0R1 ?b *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ?b)\<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        thus "( |.ABSVALUEK1 y.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|)+XCMPLX-0K2  |.ABSVALUEK1 y.|) <=XXREAL-0R1 ( |.ABSVALUEK1 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 y.|)"
          using xcmplx_0_def_9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 ?c"
      using complex1_th_46 xreal_1_th_8 sorry
    then have A15: "?c /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ?c) <=XXREAL-0R1 (?a +XCMPLX-0K2 ?b)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (?a +XCMPLX-0K2 ?b))"
      using A5 A6 A1 complex1_th_56 sorry
    have "(?a +XCMPLX-0K2 ?b)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b) =COMPLEX1R1 ?a /XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b) +XCMPLX-0K2 ?b /XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b)"
      using xcmplx_1_th_62 sorry
    then have "(?a +XCMPLX-0K2 ?b)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 ?a)+XCMPLX-0K2 ?b) <=XXREAL-0R1 ?a /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ?a) +XCMPLX-0K2 ?b /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ?b)"
      using A6 A7 A8 A12 xreal_1_th_7 sorry
    thus "( |.ABSVALUEK1 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.ABSVALUEK1 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 x.|) +XCMPLX-0K2 ( |.ABSVALUEK1 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.ABSVALUEK1 y.|)"
      using A15 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef absvalue_def_2 ("sgnABSVALUEK2  _ " [164]164 ) where
  mlet "x be RealXREAL-0M1"
"func sgnABSVALUEK2 x \<rightarrow> RealXREAL-0M1 equals
  \<one>\<^sub>M if 0NUMBERSK6 <XXREAL-0R3 x,
  -XCMPLX-0K4 \<one>\<^sub>M if x <XXREAL-0R3 0NUMBERSK6 otherwise 0NUMBERSK6"
proof-
  (*coherence*)
    show "(0NUMBERSK6 <XXREAL-0R3 x implies \<one>\<^sub>M be RealXREAL-0M1) & ((x <XXREAL-0R3 0NUMBERSK6 implies -XCMPLX-0K4 \<one>\<^sub>M be RealXREAL-0M1) & ( not 0NUMBERSK6 <XXREAL-0R3 x &  not x <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 be RealXREAL-0M1))"
       sorry
  (*consistency*)
    show " for it be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 0NUMBERSK6 implies (it =HIDDENR1 \<one>\<^sub>M iff it =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)"
       sorry
qed "sorry"

mtheorem ABSVALUEK2_projectivity:
" for x be RealXREAL-0M1 holds sgnABSVALUEK2 (sgnABSVALUEK2 x) =HIDDENR1 sgnABSVALUEK2 x"
proof-
  have " for it be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds it =HIDDENR1 sgnABSVALUEK2 x implies it =HIDDENR1 sgnABSVALUEK2 it"
  proof-
    have " for it be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 x implies it =HIDDENR1 \<one>\<^sub>M) & ((x <XXREAL-0R3 0NUMBERSK6 implies it =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) & ( not 0NUMBERSK6 <XXREAL-0R3 x &  not x <XXREAL-0R3 0NUMBERSK6 implies it =HIDDENR1 0NUMBERSK6)) implies (0NUMBERSK6 <XXREAL-0R3 it implies it =HIDDENR1 \<one>\<^sub>M) & ((it <XXREAL-0R3 0NUMBERSK6 implies it =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) & ( not 0NUMBERSK6 <XXREAL-0R3 it &  not it <XXREAL-0R3 0NUMBERSK6 implies it =HIDDENR1 0NUMBERSK6))"
       sorry
    thus " ?thesis "
      using absvalue_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_cl_1:
  mlet "x be RealXREAL-0M1"
"cluster sgnABSVALUEK2 x as-term-is integerINT-1V1"
proof
(*coherence*)
  show "sgnABSVALUEK2 x be integerINT-1V1"
  proof-
    have "(x =COMPLEX1R1 0NUMBERSK6 or x >XXREAL-0R4 0NUMBERSK6) or x <XXREAL-0R3 0NUMBERSK6"
       sorry
    thus "sgnABSVALUEK2 x be integerINT-1V1"
      using absvalue_def_2 sorry
  qed
qed "sorry"

mtheorem absvalue_th_14:
" for x be RealXREAL-0M1 holds sgnABSVALUEK2 x =COMPLEX1R1 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 x"
proof-
  have " for x be RealXREAL-0M1 holds sgnABSVALUEK2 x =COMPLEX1R1 \<one>\<^sub>M & 0NUMBERSK6 >=XXREAL-0R2 x implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "sgnABSVALUEK2 x =COMPLEX1R1 \<one>\<^sub>M"
      and A2: "0NUMBERSK6 >=XXREAL-0R2 x"
    have "x <XXREAL-0R3 0NUMBERSK6 or x =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    thus " False "
      using A1 absvalue_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_15:
" for x be RealXREAL-0M1 holds sgnABSVALUEK2 x =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M implies x <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds sgnABSVALUEK2 x =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M & x >=XXREAL-0R2 0NUMBERSK6 implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "sgnABSVALUEK2 x =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
      and A2: "x >=XXREAL-0R2 0NUMBERSK6"
    have "0NUMBERSK6 <XXREAL-0R3 x or x =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    thus " False "
      using A1 absvalue_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_16:
" for x be RealXREAL-0M1 holds sgnABSVALUEK2 x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds sgnABSVALUEK2 x =COMPLEX1R1 0NUMBERSK6 & x <>HIDDENR2 0NUMBERSK6 implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "sgnABSVALUEK2 x =COMPLEX1R1 0NUMBERSK6"
      and A2: "x <>HIDDENR2 0NUMBERSK6"
    have "0NUMBERSK6 <XXREAL-0R3 x or x <XXREAL-0R3 0NUMBERSK6"
      using A2 sorry
    thus " False "
      using A1 absvalue_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_17:
" for x be RealXREAL-0M1 holds x =COMPLEX1R1 ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x)"
proof-
  have " for x be RealXREAL-0M1 holds x =COMPLEX1R1 ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x)"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have A1: "0NUMBERSK6 <XXREAL-0R3 x implies x =COMPLEX1R1 ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x)"
    proof(rule impI)
      assume A2: "0NUMBERSK6 <XXREAL-0R3 x"
      then have " |.ABSVALUEK1 x.| =COMPLEX1R1 x"
        using absvalue_def_1 sorry
      then have "( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x) =COMPLEX1R1 x *XCMPLX-0K3 \<one>\<^sub>M"
        using A2 absvalue_def_2 sorry
      thus "x =COMPLEX1R1 ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x)"
         sorry
    qed
    have A3: "x <XXREAL-0R3 0NUMBERSK6 implies x =COMPLEX1R1 ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x)"
    proof(rule impI)
      assume A4: "x <XXREAL-0R3 0NUMBERSK6"
      then have " |.ABSVALUEK1 x.| =COMPLEX1R1 -XCMPLX-0K4 x"
        using absvalue_def_1 sorry
      then have "( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x) =HIDDENR1 (-XCMPLX-0K4 x)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A4 absvalue_def_2 sorry
      also have "... = x"
         sorry
      finally have "( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x) =HIDDENR1 x"
         sorry
      thus "x =COMPLEX1R1 ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x)"
         sorry
    qed
    have "x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x)"
       sorry
    thus "x =COMPLEX1R1 ( |.ABSVALUEK1 x.|)*XCMPLX-0K3 (sgnABSVALUEK2 x)"
      using A1 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_18:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have A1: "0NUMBERSK6 <XXREAL-0R3 x & 0NUMBERSK6 <XXREAL-0R3 y implies sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
    proof(rule impMI ,rule impI)
      assume A2: "0NUMBERSK6 <XXREAL-0R3 x"
        and A3: "0NUMBERSK6 <XXREAL-0R3 y"
      have A4: "sgnABSVALUEK2 y =COMPLEX1R1 \<one>\<^sub>M"
        using A3 absvalue_def_2 sorry
      have "(0NUMBERSK6)*XCMPLX-0K3 y <XXREAL-0R3 x *XCMPLX-0K3 y & sgnABSVALUEK2 x =COMPLEX1R1 \<one>\<^sub>M"
        using A2 A3 absvalue_def_2 xreal_1_th_68 sorry
      thus "sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
        using A4 absvalue_def_2 sorry
    qed
    have A5: "0NUMBERSK6 <XXREAL-0R3 x & y <XXREAL-0R3 0NUMBERSK6 implies sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
    proof(rule impMI ,rule impI)
      assume A6: "0NUMBERSK6 <XXREAL-0R3 x"
        and A7: "y <XXREAL-0R3 0NUMBERSK6"
      have "sgnABSVALUEK2 y =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A7 absvalue_def_2 sorry
      then have A8: "(sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A6 absvalue_def_2 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
         sorry
      finally have "(sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
         sorry
      have "x *XCMPLX-0K3 y <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 y"
        using A6 A7 xreal_1_th_69 sorry
      thus "sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
        using A8 absvalue_def_2 sorry
    qed
    have A9: "x <XXREAL-0R3 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6 implies sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
    proof(rule impMI ,rule impI)
      assume A10: "x <XXREAL-0R3 0NUMBERSK6"
        and A11: "y <XXREAL-0R3 0NUMBERSK6"
      have "sgnABSVALUEK2 y =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A11 absvalue_def_2 sorry
      then have A12: "(sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A10 absvalue_def_2 sorry
      also have "... = \<one>\<^sub>M"
         sorry
      finally have "(sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y) =HIDDENR1 \<one>\<^sub>M"
         sorry
      have "x *XCMPLX-0K3 (0NUMBERSK6) <XXREAL-0R3 x *XCMPLX-0K3 y"
        using A10 A11 xreal_1_th_69 sorry
      thus "sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
        using A12 absvalue_def_2 sorry
    qed
    have A13: "x <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 y implies sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
    proof(rule impMI ,rule impI)
      assume A14: "x <XXREAL-0R3 0NUMBERSK6"
        and A15: "0NUMBERSK6 <XXREAL-0R3 y"
      have "sgnABSVALUEK2 y =COMPLEX1R1 \<one>\<^sub>M"
        using A15 absvalue_def_2 sorry
      then have A16: "(sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A14 absvalue_def_2 sorry
      have "x *XCMPLX-0K3 y <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 y"
        using A14 A15 xreal_1_th_68 sorry
      thus "sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
        using A16 absvalue_def_2 sorry
    qed
    have "x =COMPLEX1R1 0NUMBERSK6 or y =COMPLEX1R1 0NUMBERSK6 implies sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
    proof(rule impI)
      assume A17: "x =COMPLEX1R1 0NUMBERSK6 or y =COMPLEX1R1 0NUMBERSK6"
      then have "sgnABSVALUEK2 x =COMPLEX1R1 0NUMBERSK6 or sgnABSVALUEK2 y =COMPLEX1R1 0NUMBERSK6"
        using absvalue_def_2 sorry
      thus "sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
        using A17 sorry
    qed
    thus "sgnABSVALUEK2 (x *XCMPLX-0K3 y) =COMPLEX1R1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 y)"
      using A1 A5 A13 A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem absvalue_th_20:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have A1: "y =COMPLEX1R1 0NUMBERSK6 implies sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
    proof(rule impI)
      assume A2: "y =COMPLEX1R1 0NUMBERSK6"
      then have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 (sgnABSVALUEK2 x +XCMPLX-0K2 0NUMBERSK6)+XCMPLX-0K2 \<one>\<^sub>M"
        using absvalue_def_2 sorry
      also have "... = sgnABSVALUEK2 x +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      finally have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 sgnABSVALUEK2 x +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      thus "sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
        using A2 xreal_1_th_29 sorry
    qed
    have A3: "0NUMBERSK6 <XXREAL-0R3 x & 0NUMBERSK6 <XXREAL-0R3 y implies sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
    proof(rule impI)
      have "sgnABSVALUEK2 x <XXREAL-0R3 sgnABSVALUEK2 x +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_29 sorry
      then have A4: "sgnABSVALUEK2 x +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 (sgnABSVALUEK2 x +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 sorry
      assume A5: "0NUMBERSK6 <XXREAL-0R3 x & 0NUMBERSK6 <XXREAL-0R3 y"
      then have "sgnABSVALUEK2 x =COMPLEX1R1 \<one>\<^sub>M & sgnABSVALUEK2 y =COMPLEX1R1 \<one>\<^sub>M"
        using absvalue_def_2 sorry
      thus "sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
        using A5 A4 absvalue_def_2 sorry
    qed
    have A6: "x <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 y implies sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
    proof(rule impMI ,rule impI)
      assume A7: "x <XXREAL-0R3 0NUMBERSK6"
        and A8: "0NUMBERSK6 <XXREAL-0R3 y"
      have "sgnABSVALUEK2 x =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A7 absvalue_def_2 sorry
      then have A9: "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
        using A8 absvalue_def_2 sorry
      have "(x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6 or x +XCMPLX-0K2 y =COMPLEX1R1 0NUMBERSK6) or 0NUMBERSK6 <XXREAL-0R3 x +XCMPLX-0K2 y"
         sorry
      thus "sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
        using A9 absvalue_def_2 sorry
    qed
    have A10: "0NUMBERSK6 <XXREAL-0R3 x & y <XXREAL-0R3 0NUMBERSK6 implies sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
    proof(rule impMI ,rule impI)
      assume A11: "0NUMBERSK6 <XXREAL-0R3 x"
        and A12: "y <XXREAL-0R3 0NUMBERSK6"
      have "sgnABSVALUEK2 x =COMPLEX1R1 \<one>\<^sub>M"
        using A11 absvalue_def_2 sorry
      then have A13: "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
        using A12 absvalue_def_2 sorry
      also have "... = \<one>\<^sub>M"
         sorry
      finally have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
         sorry
      have "(x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6 or x +XCMPLX-0K2 y =COMPLEX1R1 0NUMBERSK6) or 0NUMBERSK6 <XXREAL-0R3 x +XCMPLX-0K2 y"
         sorry
      thus "sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
        using A13 absvalue_def_2 sorry
    qed
    have A14: "x <XXREAL-0R3 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6 implies sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
    proof(rule impMI ,rule impI)
      assume A15: "x <XXREAL-0R3 0NUMBERSK6"
        and A16: "y <XXREAL-0R3 0NUMBERSK6"
      have "sgnABSVALUEK2 y =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A16 absvalue_def_2 sorry
      then have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A15 absvalue_def_2 sorry
      thus "sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
        using A15 A16 absvalue_def_2 sorry
    qed
    have "x =COMPLEX1R1 0NUMBERSK6 implies sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
    proof(rule impI)
      assume A17: "x =COMPLEX1R1 0NUMBERSK6"
      then have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 (0NUMBERSK6 +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
        using absvalue_def_2 sorry
      also have "... = sgnABSVALUEK2 y +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      finally have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 sgnABSVALUEK2 y +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      thus "sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
        using A17 xreal_1_th_29 sorry
    qed
    thus "sgnABSVALUEK2 (x +XCMPLX-0K2 y) <=XXREAL-0R1 (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)+XCMPLX-0K2 \<one>\<^sub>M"
      using A3 A10 A6 A14 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_21:
" for x be RealXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds x <>HIDDENR2 0NUMBERSK6 implies (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)) =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x <>HIDDENR2 0NUMBERSK6"
    then have "sgnABSVALUEK2 (x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)) =COMPLEX1R1 sgnABSVALUEK2 \<one>\<^sub>M"
      using xcmplx_1_th_106 sorry
    then have "sgnABSVALUEK2 (x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)) =COMPLEX1R1 \<one>\<^sub>M"
      using absvalue_def_2 sorry
    thus "(sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)) =COMPLEX1R1 \<one>\<^sub>M"
      using absvalue_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_22:
" for x be RealXREAL-0M1 holds \<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x) =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
proof-
  have " for x be RealXREAL-0M1 holds \<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x) =HIDDENR1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    show "\<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x) =HIDDENR1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof-
      have cases: "x =COMPLEX1R1 0NUMBERSK6 or x <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "x =COMPLEX1R1 0NUMBERSK6 implies \<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x) =HIDDENR1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
      proof(rule impI)
        assume A1: "x =COMPLEX1R1 0NUMBERSK6"
        then have "\<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (0NUMBERSK6)"
          using absvalue_def_2 sorry
        also have "... = sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
          using A1 absvalue_def_2 sorry
        finally show "\<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x) =HIDDENR1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
           sorry
      qed
      have case2: "x <>HIDDENR2 0NUMBERSK6 implies \<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x) =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
      proof(rule impI)
        assume A2: "x <>HIDDENR2 0NUMBERSK6"
        then have "((sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x)) =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x))"
          using absvalue_th_21 sorry
        then have "(sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 ((sgnABSVALUEK2 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x))) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x)"
           sorry
        then have "(sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x))*XCMPLX-0K3 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x)"
          using A2 absvalue_th_16 xcmplx_1_th_106 sorry
        thus "\<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x) =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_23:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have A1: "x =COMPLEX1R1 0NUMBERSK6 or y =COMPLEX1R1 0NUMBERSK6 implies (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
    proof(rule impI)
      have A2: "y =COMPLEX1R1 0NUMBERSK6 implies (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
      proof(rule impI)
        have A3: "sgnABSVALUEK2 x -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (sgnABSVALUEK2 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
          using xreal_1_th_29 sorry
        assume A4: "y =COMPLEX1R1 0NUMBERSK6"
        then have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 (sgnABSVALUEK2 x +XCMPLX-0K2 0NUMBERSK6)-XCMPLX-0K6 \<one>\<^sub>M"
          using absvalue_def_2 sorry
        also have "... = sgnABSVALUEK2 x -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        finally have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 sgnABSVALUEK2 x -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        thus "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
          using A4 A3 sorry
      qed
      have A5: "x =COMPLEX1R1 0NUMBERSK6 implies (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
      proof(rule impI)
        have A6: "sgnABSVALUEK2 y -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (sgnABSVALUEK2 y +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
          using xreal_1_th_29 sorry
        assume A7: "x =COMPLEX1R1 0NUMBERSK6"
        then have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 (0NUMBERSK6 +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M"
          using absvalue_def_2 sorry
        also have "... = sgnABSVALUEK2 y -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        finally have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 sgnABSVALUEK2 y -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        thus "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
          using A7 A6 sorry
      qed
      assume "x =COMPLEX1R1 0NUMBERSK6 or y =COMPLEX1R1 0NUMBERSK6"
      thus "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
        using A5 A2 sorry
    qed
    have A8: "x <XXREAL-0R3 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6 implies (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
    proof(rule impMI ,rule impI)
      assume A9: "x <XXREAL-0R3 0NUMBERSK6"
        and A10: "y <XXREAL-0R3 0NUMBERSK6"
      have "sgnABSVALUEK2 x =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A9 absvalue_def_2 sorry
      then have A11: "sgnABSVALUEK2 x =COMPLEX1R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
        using A9 A10 absvalue_def_2 sorry
      have A12: "(sgnABSVALUEK2 (x +XCMPLX-0K2 y) +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ((sgnABSVALUEK2 (x +XCMPLX-0K2 y) +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M & sgnABSVALUEK2 (x +XCMPLX-0K2 y) +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 (sgnABSVALUEK2 (x +XCMPLX-0K2 y) +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_29 sorry
      have "sgnABSVALUEK2 y =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A10 absvalue_def_2 sorry
      thus "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
        using A11 A12 xxreal_0_th_2 sorry
    qed
    have A13: "0NUMBERSK6 <XXREAL-0R3 x & y <XXREAL-0R3 0NUMBERSK6 implies (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
    proof(rule impMI ,rule impI)
      assume A14: "0NUMBERSK6 <XXREAL-0R3 x"
        and A15: "y <XXREAL-0R3 0NUMBERSK6"
      have "sgnABSVALUEK2 x =COMPLEX1R1 \<one>\<^sub>M"
        using A14 absvalue_def_2 sorry
      then have A16: "sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A15 absvalue_def_2 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y =HIDDENR1 0NUMBERSK6"
         sorry
      have "(x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6 or x +XCMPLX-0K2 y =COMPLEX1R1 0NUMBERSK6) or 0NUMBERSK6 <XXREAL-0R3 x +XCMPLX-0K2 y"
         sorry
      thus "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
        using A16 absvalue_def_2 sorry
    qed
    have A17: "x <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 y implies (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
    proof(rule impMI ,rule impI)
      assume A18: "x <XXREAL-0R3 0NUMBERSK6"
        and A19: "0NUMBERSK6 <XXREAL-0R3 y"
      have "sgnABSVALUEK2 x =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A18 absvalue_def_2 sorry
      then have A20: "sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
        using A19 absvalue_def_2 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y =HIDDENR1 0NUMBERSK6"
         sorry
      have "(x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6 or x +XCMPLX-0K2 y =COMPLEX1R1 0NUMBERSK6) or 0NUMBERSK6 <XXREAL-0R3 x +XCMPLX-0K2 y"
         sorry
      thus "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
        using A20 absvalue_def_2 sorry
    qed
    have "0NUMBERSK6 <XXREAL-0R3 x & 0NUMBERSK6 <XXREAL-0R3 y implies (sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
    proof(rule impMI ,rule impI)
      assume A21: "0NUMBERSK6 <XXREAL-0R3 x"
        and A22: "0NUMBERSK6 <XXREAL-0R3 y"
      have "sgnABSVALUEK2 y =COMPLEX1R1 \<one>\<^sub>M"
        using A22 absvalue_def_2 sorry
      then have "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
        using A21 absvalue_def_2 sorry
      thus "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
        using A21 A22 absvalue_def_2 sorry
    qed
    thus "(sgnABSVALUEK2 x +XCMPLX-0K2 sgnABSVALUEK2 y)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 sgnABSVALUEK2 (x +XCMPLX-0K2 y)"
      using A8 A17 A13 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_24:
" for x be RealXREAL-0M1 holds sgnABSVALUEK2 x =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
proof-
  have " for x be RealXREAL-0M1 holds sgnABSVALUEK2 x =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have A1: "0NUMBERSK6 <XXREAL-0R3 x implies sgnABSVALUEK2 x =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof(rule impI)
      assume A2: "0NUMBERSK6 <XXREAL-0R3 x"
      have "sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 x)"
        using absvalue_th_22 sorry
      then have "sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"
        using A2 absvalue_def_2 sorry
      also have "... = \<one>\<^sub>M"
         sorry
      finally have "sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x) =HIDDENR1 \<one>\<^sub>M"
         sorry
      thus "sgnABSVALUEK2 x =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A2 absvalue_def_2 sorry
    qed
    have "x <XXREAL-0R3 0NUMBERSK6 implies sgnABSVALUEK2 x =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
    proof(rule impI)
      assume A3: "x <XXREAL-0R3 0NUMBERSK6"
      then have "sgnABSVALUEK2 x =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using absvalue_def_2 sorry
      then have "sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using absvalue_th_22 sorry
      thus "sgnABSVALUEK2 x =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A3 absvalue_def_2 sorry
    qed
    thus "sgnABSVALUEK2 x =COMPLEX1R1 sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 x)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_25:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds sgnABSVALUEK2 (x /XCMPLX-0K7 y) =COMPLEX1R1 (sgnABSVALUEK2 x)/XCMPLX-0K7 (sgnABSVALUEK2 y)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds sgnABSVALUEK2 (x /XCMPLX-0K7 y) =HIDDENR1 (sgnABSVALUEK2 x)/XCMPLX-0K7 (sgnABSVALUEK2 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    show "sgnABSVALUEK2 (x /XCMPLX-0K7 y) =HIDDENR1 (sgnABSVALUEK2 x)/XCMPLX-0K7 (sgnABSVALUEK2 y)"
    proof-
      have cases: "y =COMPLEX1R1 0NUMBERSK6 or y <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "y =COMPLEX1R1 0NUMBERSK6 implies sgnABSVALUEK2 (x /XCMPLX-0K7 y) =HIDDENR1 (sgnABSVALUEK2 x)/XCMPLX-0K7 (sgnABSVALUEK2 y)"
      proof(rule impI)
        assume A1: "y =COMPLEX1R1 0NUMBERSK6"
        then have "sgnABSVALUEK2 (x /XCMPLX-0K7 y) =HIDDENR1 sgnABSVALUEK2 (x *XCMPLX-0K3 (0NUMBERSK6)\<inverse>XCMPLX-0K5)"
          using xcmplx_0_def_9 sorry
        also have "... = (sgnABSVALUEK2 x)*XCMPLX-0K3 (0NUMBERSK6)\<inverse>XCMPLX-0K5"
          using absvalue_def_2 sorry
        also have "... = (sgnABSVALUEK2 x)/XCMPLX-0K7 (0NUMBERSK6)"
          using xcmplx_0_def_9 sorry
        also have "... = (sgnABSVALUEK2 x)/XCMPLX-0K7 (sgnABSVALUEK2 y)"
          using A1 absvalue_def_2 sorry
        finally show "sgnABSVALUEK2 (x /XCMPLX-0K7 y) =HIDDENR1 (sgnABSVALUEK2 x)/XCMPLX-0K7 (sgnABSVALUEK2 y)"
           sorry
      qed
      have case2: "y <>HIDDENR2 0NUMBERSK6 implies sgnABSVALUEK2 (x /XCMPLX-0K7 y) =COMPLEX1R1 (sgnABSVALUEK2 x)/XCMPLX-0K7 (sgnABSVALUEK2 y)"
      proof(rule impI)
        assume A2: "y <>HIDDENR2 0NUMBERSK6"
        have "x /XCMPLX-0K7 y =HIDDENR1 (x /XCMPLX-0K7 y)*XCMPLX-0K3 \<one>\<^sub>M"
           sorry
        also have "... = (x /XCMPLX-0K7 y)*XCMPLX-0K3 (y *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y))"
          using A2 xcmplx_1_th_106 sorry
        also have "... = ((x /XCMPLX-0K7 y)*XCMPLX-0K3 y)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y)"
           sorry
        also have "... = x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y)"
          using A2 xcmplx_1_th_87 sorry
        finally have "x /XCMPLX-0K7 y =HIDDENR1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y)"
           sorry
        then have "sgnABSVALUEK2 (x /XCMPLX-0K7 y) =HIDDENR1 (sgnABSVALUEK2 x)*XCMPLX-0K3 (sgnABSVALUEK2 (\<one>\<^sub>M /XCMPLX-0K7 y))"
          using absvalue_th_18 sorry
        also have "... = ((sgnABSVALUEK2 x)/XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (sgnABSVALUEK2 y))"
          using absvalue_th_22 sorry
        also have "... = ((sgnABSVALUEK2 x)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 (sgnABSVALUEK2 y))"
          using xcmplx_1_th_76 sorry
        also have "... = (sgnABSVALUEK2 x)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 (sgnABSVALUEK2 y))"
           sorry
        finally have "sgnABSVALUEK2 (x /XCMPLX-0K7 y) =HIDDENR1 (sgnABSVALUEK2 x)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 (sgnABSVALUEK2 y))"
           sorry
        thus "sgnABSVALUEK2 (x /XCMPLX-0K7 y) =COMPLEX1R1 (sgnABSVALUEK2 x)/XCMPLX-0K7 (sgnABSVALUEK2 y)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_26:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r +XCMPLX-0K2  |.ABSVALUEK1 r.|"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r +XCMPLX-0K2  |.ABSVALUEK1 r.|"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "0NUMBERSK6 <=XXREAL-0R1  |.ABSVALUEK1 r.|"
      using complex1_th_46 sorry
    have " |.ABSVALUEK1 r.| +XCMPLX-0K2  |.ABSVALUEK1 r.| =COMPLEX1R1 r +XCMPLX-0K2  |.ABSVALUEK1 r.| or  |.ABSVALUEK1 r.| +XCMPLX-0K2 r =COMPLEX1R1 (-XCMPLX-0K4 r)+XCMPLX-0K2 r"
      using absvalue_def_1 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 r +XCMPLX-0K2  |.ABSVALUEK1 r.|"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_27:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 (-XCMPLX-0K4 r)+XCMPLX-0K2  |.ABSVALUEK1 r.|"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 (-XCMPLX-0K4 r)+XCMPLX-0K2  |.ABSVALUEK1 r.|"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "-XCMPLX-0K4 r >=XXREAL-0R2 -XCMPLX-0K4  |.ABSVALUEK1 r.|"
      using xreal_1_th_24 complex1_th_76 sorry
    then have "(-XCMPLX-0K4 r)+XCMPLX-0K2  |.ABSVALUEK1 r.| >=XXREAL-0R2 (-XCMPLX-0K4  |.ABSVALUEK1 r.|)+XCMPLX-0K2  |.ABSVALUEK1 r.|"
      using xreal_1_th_7 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 (-XCMPLX-0K4 r)+XCMPLX-0K2  |.ABSVALUEK1 r.|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_28:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  |.ABSVALUEK1 r.| =COMPLEX1R1  |.ABSVALUEK1 s.| implies r =COMPLEX1R1 s or r =COMPLEX1R1 -XCMPLX-0K4 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  |.ABSVALUEK1 r.| =COMPLEX1R1  |.ABSVALUEK1 s.| implies (r <>HIDDENR2 s implies r =COMPLEX1R1 -XCMPLX-0K4 s)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume A1: " |.ABSVALUEK1 r.| =COMPLEX1R1  |.ABSVALUEK1 s.|"
    assume A2: "r <>HIDDENR2 s"
    show "r =COMPLEX1R1 -XCMPLX-0K4 s"
    proof-
      have cases: "(( |.ABSVALUEK1 r.| =COMPLEX1R1 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 s or  |.ABSVALUEK1 r.| =COMPLEX1R1 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 -XCMPLX-0K4 s) or  |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 s) or  |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 -XCMPLX-0K4 s"
        using absvalue_def_1 sorry
      have case1: " |.ABSVALUEK1 r.| =COMPLEX1R1 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 s implies r =COMPLEX1R1 -XCMPLX-0K4 s"
      proof(rule impI)
        assume " |.ABSVALUEK1 r.| =COMPLEX1R1 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 s"
        thus "r =COMPLEX1R1 -XCMPLX-0K4 s"
          using A1 A2 sorry
      qed
      have case2: " |.ABSVALUEK1 r.| =COMPLEX1R1 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 -XCMPLX-0K4 s implies r =COMPLEX1R1 -XCMPLX-0K4 s"
      proof(rule impI)
        assume " |.ABSVALUEK1 r.| =COMPLEX1R1 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 -XCMPLX-0K4 s"
        thus "r =COMPLEX1R1 -XCMPLX-0K4 s"
          using A1 sorry
      qed
      have case3: " |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 s implies r =COMPLEX1R1 -XCMPLX-0K4 s"
      proof(rule impI)
        assume " |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 s"
        thus "r =COMPLEX1R1 -XCMPLX-0K4 s"
          using A1 sorry
      qed
      have case4: " |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 -XCMPLX-0K4 s implies r =COMPLEX1R1 -XCMPLX-0K4 s"
      proof(rule impI)
        assume " |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r &  |.ABSVALUEK1 s.| =COMPLEX1R1 -XCMPLX-0K4 s"
        thus "r =COMPLEX1R1 -XCMPLX-0K4 s"
          using A1 A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem absvalue_th_29:
" for m be NatORDINAL1M6 holds m =COMPLEX1R1  |.ABSVALUEK1 m.|"
   sorry

mtheorem absvalue_th_30:
" for r be RealXREAL-0M1 holds r <=XXREAL-0R1 0NUMBERSK6 implies  |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r"
proof-
  have " for r be RealXREAL-0M1 holds r <=XXREAL-0R1 0NUMBERSK6 implies  |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "r <=XXREAL-0R1 0NUMBERSK6"
    then have "r <XXREAL-0R3 0NUMBERSK6 or r =COMPLEX1R1 0NUMBERSK6"
       sorry
    thus " |.ABSVALUEK1 r.| =COMPLEX1R1 -XCMPLX-0K4 r"
      using absvalue_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
