theory sysrel
  imports relat_1
begin
(*begin*)
reserve x, y, z, t for "objectHIDDENM1"
reserve X, Y, Z, W for "setHIDDENM2"
reserve R, S, T for "RelationRELAT-1M1"
mlemma sysrel_lm_1:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies domRELAT-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 X & rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 Y"
  using relat_1_th_160 sorry

mtheorem sysrel_th_1:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X & rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X & rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X & rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 Y"
    proof-
      have cases: "(X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1) or X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X & rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 Y"
      proof(rule impI)
        assume "X =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]) =HIDDENR1 R /\\XBOOLE-0K3 {}XBOOLE-0K1"
          using zfmisc_1_th_90 sorry
        also have "... = {}XBOOLE-0K1"
           sorry
        finally have "R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]) =HIDDENR1 {}XBOOLE-0K1"
           sorry
        thus "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X & rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 Y"
           sorry
      qed
      have case2: "X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X & rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 Y"
      proof(rule impI,rule conjMI)
        assume A1: "X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1"
        have "rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 rngRELAT-1K2 R /\\XBOOLE-0K3 rngRELAT-1K2 ([:ZFMISC-1K2 X,Y :])"
          using relat_1_th_13 sorry
        then have A2: "rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 rngRELAT-1K2 R /\\XBOOLE-0K3 Y"
          using A1 sysrel_lm_1 sorry
        have "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 domRELAT-1K1 R /\\XBOOLE-0K3 domRELAT-1K1 ([:ZFMISC-1K2 X,Y :])"
          using xtuple_0_th_24 sorry
        then have A3: "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 domRELAT-1K1 R /\\XBOOLE-0K3 X"
          using A1 sysrel_lm_1 sorry
        have "domRELAT-1K1 R /\\XBOOLE-0K3 X c=TARSKIR1 X"
          using xboole_1_th_17 sorry
        thus "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X"
          using A3 sorry
        have "rngRELAT-1K2 R /\\XBOOLE-0K3 Y c=TARSKIR1 Y"
          using xboole_1_th_17 sorry
        thus "rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 Y"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X missesXBOOLE-0R1 Y implies domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) missesXBOOLE-0R1 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  not (X missesXBOOLE-0R1 Y &  not domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) missesXBOOLE-0R1 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) missesXBOOLE-0R1 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]))"
    proof(rule impI)
      assume A1: "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
      have "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X"
        using sysrel_th_1 sorry
      then have A2: "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) /\\XBOOLE-0K3 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X /\\XBOOLE-0K3 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]))"
        using xboole_1_th_26 sorry
      have Cut65: "X /\\XBOOLE-0K3 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) c=TARSKIR1 X /\\XBOOLE-0K3 Y"
        using sysrel_th_1 xboole_1_th_26 sorry
      have "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) /\\XBOOLE-0K3 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) =XBOOLE-0R4 {}XBOOLE-0K1"
      proof-
        show "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) /\\XBOOLE-0K3 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) =XBOOLE-0R4 {}XBOOLE-0K1"
          using A1 A2 xboole_1_th_1 xboole_1_th_3 Cut65 sorry
      qed
      thus "domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) missesXBOOLE-0R1 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]))"
        using xboole_0_def_7 sorry
    qed
    thus " not (X missesXBOOLE-0R1 Y &  not domRELAT-1K1 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])) missesXBOOLE-0R1 rngRELAT-1K2 (R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] implies domRELAT-1K1 R c=TARSKIR1 X & rngRELAT-1K2 R c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] implies domRELAT-1K1 R c=TARSKIR1 X & rngRELAT-1K2 R c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
    then have "R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]) =RELAT-1R1 R"
      using xboole_1_th_28 sorry
    thus "domRELAT-1K1 R c=TARSKIR1 X & rngRELAT-1K2 R c=TARSKIR1 Y"
      using sysrel_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] implies R ~RELAT-1K4 c=RELAT-1R2 [:ZFMISC-1K2 Y,X :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] implies R ~RELAT-1K4 c=RELAT-1R2 [:ZFMISC-1K2 Y,X :]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
    have " for z be objectHIDDENM1 holds  for t be objectHIDDENM1 holds [TARSKIK4 z,t ] inHIDDENR3 R ~RELAT-1K4 implies [TARSKIK4 z,t ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
    proof(rule ballI,rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      fix t assume [ty]: "t be objectHIDDENM1"
      assume "[TARSKIK4 z,t ] inHIDDENR3 R ~RELAT-1K4"
      then have "[TARSKIK4 t,z ] inHIDDENR3 R"
        using relat_1_def_7 sorry
      then have "t inHIDDENR3 X & z inHIDDENR3 Y"
        using A1 zfmisc_1_th_87 sorry
      thus "[TARSKIK4 z,t ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "R ~RELAT-1K4 c=RELAT-1R2 [:ZFMISC-1K2 Y,X :]"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,Y :])~RELAT-1K4 =RELAT-1R1 [:ZFMISC-1K2 Y,X :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,Y :])~RELAT-1K4 =RELAT-1R1 [:ZFMISC-1K2 Y,X :]"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Y :])~RELAT-1K4 implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]) & ([TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :] implies [TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Y :])~RELAT-1K4)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Y :])~RELAT-1K4 implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
      proof(rule impI)
        assume "[TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Y :])~RELAT-1K4"
        then have "[TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using relat_1_def_7 sorry
        then have "y inHIDDENR3 X & x inHIDDENR3 Y"
          using zfmisc_1_th_87 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
          using zfmisc_1_th_87 sorry
      qed
      assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
      then have "y inHIDDENR3 X & x inHIDDENR3 Y"
        using zfmisc_1_th_87 sorry
      then have "[TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using zfmisc_1_th_87 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 ([:ZFMISC-1K2 X,Y :])~RELAT-1K4"
        using relat_1_def_7 sorry
    qed "sorry"
    thus "([:ZFMISC-1K2 X,Y :])~RELAT-1K4 =RELAT-1R1 [:ZFMISC-1K2 Y,X :]"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_6:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds  for T be RelationRELAT-1M1 holds (R \\/XBOOLE-0K2 S)*RELAT-1K6 T =RELAT-1R1 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds  for T be RelationRELAT-1M1 holds (R \\/XBOOLE-0K2 S)*RELAT-1K6 T =RELAT-1R1 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    fix T assume [ty]: "T be RelationRELAT-1M1"
    show "(R \\/XBOOLE-0K2 S)*RELAT-1K6 T =RELAT-1R1 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T implies [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T) & ([TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T implies [TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T)"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T implies [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,z ] inHIDDENR3 R \\/XBOOLE-0K2 S & [TARSKIK4 z,y ] inHIDDENR3 T"
            using relat_1_def_8 sorry
          have "[TARSKIK4 x,z ] inHIDDENR3 R & [TARSKIK4 z,y ] inHIDDENR3 T or [TARSKIK4 x,z ] inHIDDENR3 S & [TARSKIK4 z,y ] inHIDDENR3 T"
            using A1 xboole_0_def_3 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T or [TARSKIK4 x,y ] inHIDDENR3 S *RELAT-1K6 T"
            using relat_1_def_8 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T"
            using xboole_0_def_3 sorry
        qed
        assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T"
        show "[TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T"
        proof-
          have cases: "[TARSKIK4 x,y ] inHIDDENR3 S *RELAT-1K6 T or [TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T"
            using A2 xboole_0_def_3 sorry
          have case1: "[TARSKIK4 x,y ] inHIDDENR3 S *RELAT-1K6 T implies [TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T"
          proof(rule impI)
            assume "[TARSKIK4 x,y ] inHIDDENR3 S *RELAT-1K6 T"
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A3: "[TARSKIK4 x,z ] inHIDDENR3 S"and A4: "[TARSKIK4 z,y ] inHIDDENR3 T"
              using relat_1_def_8 sorry
            have "[TARSKIK4 x,z ] inHIDDENR3 R \\/XBOOLE-0K2 S"
              using A3 xboole_0_def_3 sorry
            thus "[TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T"
              using A4 relat_1_def_8 sorry
          qed
          have case2: "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T implies [TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T"
          proof(rule impI)
            assume "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 T"
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A5: "[TARSKIK4 x,z ] inHIDDENR3 R"and A6: "[TARSKIK4 z,y ] inHIDDENR3 T"
              using relat_1_def_8 sorry
            have "[TARSKIK4 x,z ] inHIDDENR3 R \\/XBOOLE-0K2 S"
              using A5 xboole_0_def_3 sorry
            thus "[TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 S)*RELAT-1K6 T"
              using A6 relat_1_def_8 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "(R \\/XBOOLE-0K2 S)*RELAT-1K6 T =RELAT-1R1 R *RELAT-1K6 T \\/XBOOLE-0K2 S *RELAT-1K6 T"
        using relat_1_def_2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_7:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (((((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X implies ( not x inHIDDENR3 Y &  not y inHIDDENR3 X) & y inHIDDENR3 Y) & (((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y implies ( not y inHIDDENR3 X &  not x inHIDDENR3 Y) & x inHIDDENR3 X)) & (((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 Y implies ( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & y inHIDDENR3 X)) & (((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 X implies ( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & x inHIDDENR3 Y)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X implies ( not x inHIDDENR3 Y &  not y inHIDDENR3 X) & y inHIDDENR3 Y) & ((((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y implies ( not y inHIDDENR3 X &  not x inHIDDENR3 Y) & x inHIDDENR3 X) & ((((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 Y implies ( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & y inHIDDENR3 X) & (X missesXBOOLE-0R1 Y & ((R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 X) implies ( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & x inHIDDENR3 Y)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X implies ( not x inHIDDENR3 Y &  not y inHIDDENR3 X) & y inHIDDENR3 Y"
    proof-
      have "X missesXBOOLE-0R1 Y & ((R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 X) implies ( not x inHIDDENR3 Y &  not y inHIDDENR3 X) & y inHIDDENR3 Y"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A1: "X missesXBOOLE-0R1 Y"
          and A2: "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] & [TARSKIK4 x,y ] inHIDDENR3 R"
          and A3: "x inHIDDENR3 X"
        have A4: " not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
        proof-
          have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :] implies  not  True "
          proof(rule impI)
            assume A5: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
            have " not x inHIDDENR3 Y"
              using A1 A3 xboole_0_th_3 sorry
            thus " not  True "
              using A5 zfmisc_1_th_87 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A6: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies ( not x inHIDDENR3 Y &  not y inHIDDENR3 X) & y inHIDDENR3 Y"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          then have "x inHIDDENR3 X & y inHIDDENR3 Y"
            using zfmisc_1_th_87 sorry
          thus "( not x inHIDDENR3 Y &  not y inHIDDENR3 X) & y inHIDDENR3 Y"
            using A1 xboole_0_th_3 sorry
        qed
        have "[:ZFMISC-1K2 X,Y :] missesXBOOLE-0R1 [:ZFMISC-1K2 Y,X :]"
          using A1 zfmisc_1_th_104 sorry
        thus "( not x inHIDDENR3 Y &  not y inHIDDENR3 X) & y inHIDDENR3 Y"
          using A2 A6 A4 xboole_0_th_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y implies ( not y inHIDDENR3 X &  not x inHIDDENR3 Y) & x inHIDDENR3 X"
    proof-
      have "X missesXBOOLE-0R1 Y & ((R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] & [TARSKIK4 x,y ] inHIDDENR3 R) & y inHIDDENR3 Y) implies ( not y inHIDDENR3 X &  not x inHIDDENR3 Y) & x inHIDDENR3 X"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A7: "X missesXBOOLE-0R1 Y"
          and A8: "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] & [TARSKIK4 x,y ] inHIDDENR3 R"
          and A9: "y inHIDDENR3 Y"
        have A10: " not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
        proof-
          have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :] implies  not  True "
          proof(rule impI)
            assume A11: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
            have " not y inHIDDENR3 X"
              using A7 A9 xboole_0_th_3 sorry
            thus " not  True "
              using A11 zfmisc_1_th_87 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies ( not y inHIDDENR3 X &  not x inHIDDENR3 Y) & x inHIDDENR3 X"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          then have "x inHIDDENR3 X & y inHIDDENR3 Y"
            using zfmisc_1_th_87 sorry
          thus "( not y inHIDDENR3 X &  not x inHIDDENR3 Y) & x inHIDDENR3 X"
            using A7 xboole_0_th_3 sorry
        qed
        thus "( not y inHIDDENR3 X &  not x inHIDDENR3 Y) & x inHIDDENR3 X"
          using A8 A10 xboole_0_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 Y implies ( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & y inHIDDENR3 X"
    proof-
      have "X missesXBOOLE-0R1 Y & ((R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] & [TARSKIK4 x,y ] inHIDDENR3 R) & x inHIDDENR3 Y) implies ( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & y inHIDDENR3 X"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A12: "X missesXBOOLE-0R1 Y"
          and A13: "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] & [TARSKIK4 x,y ] inHIDDENR3 R"
          and A14: "x inHIDDENR3 Y"
        have A15: " not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        proof-
          have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies  not  True "
          proof(rule impI)
            assume A16: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
            have " not x inHIDDENR3 X"
              using A12 A14 xboole_0_th_3 sorry
            thus " not  True "
              using A16 zfmisc_1_th_87 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :] &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies ( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & y inHIDDENR3 X"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :] &  not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          then have "(x inHIDDENR3 Y & y inHIDDENR3 X) &  not x inHIDDENR3 X or (x inHIDDENR3 Y & y inHIDDENR3 X) &  not y inHIDDENR3 Y"
            using zfmisc_1_th_87 sorry
          thus "( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & y inHIDDENR3 X"
            using A12 xboole_0_th_3 sorry
        qed
        thus "( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & y inHIDDENR3 X"
          using A13 A15 xboole_0_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A17: "X missesXBOOLE-0R1 Y"
      and A18: "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] & [TARSKIK4 x,y ] inHIDDENR3 R"
      and A19: "y inHIDDENR3 X"
    have A20: " not [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
    proof-
      have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies  not  True "
      proof(rule impI)
        assume A21: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        have " not y inHIDDENR3 Y"
          using A17 A19 xboole_0_th_3 sorry
        thus " not  True "
          using A21 zfmisc_1_th_87 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :] implies ( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & x inHIDDENR3 Y"
    proof(rule impI)
      assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
      then have "x inHIDDENR3 Y & y inHIDDENR3 X"
        using zfmisc_1_th_87 sorry
      thus "( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & x inHIDDENR3 Y"
        using A17 xboole_0_th_3 sorry
    qed
    thus "( not x inHIDDENR3 X &  not y inHIDDENR3 Y) & x inHIDDENR3 Y"
      using A18 A20 xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] implies R  |RELAT-1K8 Z =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :]) & Z  |`RELAT-1K9 R =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Z :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] implies R  |RELAT-1K8 Z =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :]) & Z  |`RELAT-1K9 R =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Z :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
    show "R  |RELAT-1K8 Z =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Z implies [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])) & ([TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :]) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Z)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Z implies [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
        proof(rule impI)
          assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Z"
          then have A3: "x inHIDDENR3 Z"
            using relat_1_def_11 sorry
          have A4: "[TARSKIK4 x,y ] inHIDDENR3 R"
            using A2 relat_1_def_11 sorry
          then have "y inHIDDENR3 Y"
            using A1 zfmisc_1_th_87 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
            using A3 zfmisc_1_th_87 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
            using A4 xboole_0_def_4 sorry
        qed
        show "[TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :]) implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Z"
        proof(rule impI)
          assume A5: "[TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
          then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
            using xboole_0_def_4 sorry
          then have A6: "x inHIDDENR3 Z"
            using zfmisc_1_th_87 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 R"
            using A5 xboole_0_def_4 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 Z"
            using A6 relat_1_def_11 sorry
        qed
      qed "sorry"
      thus "R  |RELAT-1K8 Z =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :])"
        using relat_1_def_2 sorry
    qed
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 Z  |`RELAT-1K9 R implies [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Z :])) & ([TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Z :]) implies [TARSKIK4 x,y ] inHIDDENR3 Z  |`RELAT-1K9 R)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 Z  |`RELAT-1K9 R implies [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Z :])"
      proof(rule impI)
        assume A7: "[TARSKIK4 x,y ] inHIDDENR3 Z  |`RELAT-1K9 R"
        then have A8: "y inHIDDENR3 Z"
          using relat_1_def_12 sorry
        have A9: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A7 relat_1_def_12 sorry
        then have "x inHIDDENR3 X"
          using A1 zfmisc_1_th_87 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
          using A8 zfmisc_1_th_87 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Z :])"
          using A9 xboole_0_def_4 sorry
      qed
      assume A10: "[TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Z :])"
      then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
        using xboole_0_def_4 sorry
      then have A11: "y inHIDDENR3 Z"
        using zfmisc_1_th_87 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A10 xboole_0_def_4 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 Z  |`RELAT-1K9 R"
        using A11 relat_1_def_12 sorry
    qed "sorry"
    thus "Z  |`RELAT-1K9 R =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Z :])"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for W be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] & X =XBOOLE-0R4 Z \\/XBOOLE-0K2 W implies R =RELAT-1R1 R  |RELAT-1K8 Z \\/XBOOLE-0K2 R  |RELAT-1K8 W"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for W be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] & X =XBOOLE-0R4 Z \\/XBOOLE-0K2 W implies R =HIDDENR1 R  |RELAT-1K8 Z \\/XBOOLE-0K2 R  |RELAT-1K8 W"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
      and A2: "X =XBOOLE-0R4 Z \\/XBOOLE-0K2 W"
    have "R =HIDDENR1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])"
      using A1 xboole_1_th_28 sorry
    also have "... = R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 W,Y :])"
      using A2 zfmisc_1_th_97 sorry
    also have "... = R /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z,Y :]) \\/XBOOLE-0K2 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 W,Y :])"
      using xboole_1_th_23 sorry
    also have "... = R  |RELAT-1K8 Z \\/XBOOLE-0K2 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 W,Y :])"
      using A1 sysrel_th_8 sorry
    also have "... = R  |RELAT-1K8 Z \\/XBOOLE-0K2 R  |RELAT-1K8 W"
      using A1 sysrel_th_8 sorry
    finally show "R =HIDDENR1 R  |RELAT-1K8 Z \\/XBOOLE-0K2 R  |RELAT-1K8 W"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] implies R  |RELAT-1K8 X c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  not ((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) &  not R  |RELAT-1K8 X c=RELAT-1R2 [:ZFMISC-1K2 X,Y :])"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :] implies R  |RELAT-1K8 X c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
    proof(rule impMI ,rule impI)
      assume A1: "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
        and A2: "R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]"
      have "R  |RELAT-1K8 X =RELAT-1R1 R /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
        using relat_1_th_67 sorry
      then have "R  |RELAT-1K8 X c=RELAT-1R2 ([:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
        using A2 xboole_1_th_26 sorry
      then have A3: "R  |RELAT-1K8 X c=RELAT-1R2 ([:ZFMISC-1K2 X,Y :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :]) \\/XBOOLE-0K2 ([:ZFMISC-1K2 Y,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :])"
        using xboole_1_th_23 sorry
      have "([:ZFMISC-1K2 Y,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :]) =HIDDENR1 [:ZFMISC-1K2 X /\\XBOOLE-0K3 Y,X /\\XBOOLE-0K3 rngRELAT-1K2 R :]"
        using zfmisc_1_th_100 sorry
      also have "... = {}XBOOLE-0K1"
        using A1 zfmisc_1_th_90 sorry
      finally have "([:ZFMISC-1K2 Y,X :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X,rngRELAT-1K2 R :]) =HIDDENR1 {}XBOOLE-0K1"
         sorry
      thus "R  |RELAT-1K8 X c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
        using A3 xboole_1_th_18 sorry
    qed
    thus " not ((X missesXBOOLE-0R1 Y & R c=RELAT-1R2 [:ZFMISC-1K2 X,Y :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,X :]) &  not R  |RELAT-1K8 X c=RELAT-1R2 [:ZFMISC-1K2 X,Y :])"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_11:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds R c=RELAT-1R2 S implies R ~RELAT-1K4 c=RELAT-1R2 S ~RELAT-1K4"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds R c=RELAT-1R2 S implies R ~RELAT-1K4 c=RELAT-1R2 S ~RELAT-1K4"
  proof(rule ballI,rule ballI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    assume "R c=RELAT-1R2 S"
    then have "R \\/XBOOLE-0K2 S =RELAT-1R1 S"
      using xboole_1_th_12 sorry
    then have "R ~RELAT-1K4 \\/XBOOLE-0K2 S ~RELAT-1K4 =RELAT-1R1 S ~RELAT-1K4"
      using relat_1_th_23 sorry
    thus "R ~RELAT-1K4 c=RELAT-1R2 S ~RELAT-1K4"
      using xboole_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sysrel_lm_2:
" for X be setHIDDENM2 holds idRELAT-1K7 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
proof-
  have " for X be setHIDDENM2 holds idRELAT-1K7 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
      then have "x inHIDDENR3 X & x =HIDDENR1 y"
        using relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "idRELAT-1K7 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_12:
" for X be setHIDDENM2 holds idRELAT-1K7 X *RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 idRELAT-1K7 X"
proof-
  have " for X be setHIDDENM2 holds idRELAT-1K7 X *RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 idRELAT-1K7 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "domRELAT-1K1 (idRELAT-1K7 X) =XBOOLE-0R4 X"
       sorry
    thus "idRELAT-1K7 X *RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 idRELAT-1K7 X"
      using relat_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_13:
" for x be objectHIDDENM1 holds idRELAT-1K7 {TARSKIK1 x} =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,x ] }"
proof(rule ballI)
  fix x assume [ty]: "x be objectHIDDENM1"
  have "x inHIDDENR3 {TARSKIK1 x}"
    using tarski_def_1 sorry
  then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 {TARSKIK1 x}"
    using relat_1_def_10 sorry
  then have A1: "{TARSKIK1 [TARSKIK4 x,x ] } c=RELAT-1R2 idRELAT-1K7 {TARSKIK1 x}"
    using zfmisc_1_th_31 sorry
  have "[:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 x} :] =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,x ] }"
    using zfmisc_1_th_29 sorry
  then have "idRELAT-1K7 {TARSKIK1 x} c=RELAT-1R2 {TARSKIK1 [TARSKIK4 x,x ] }"
    using sysrel_lm_2 sorry
  thus "idRELAT-1K7 {TARSKIK1 x} =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,x ] }"
    using A1 sorry
qed "sorry"

mtheorem sysrel_th_14:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (idRELAT-1K7 (X \\/XBOOLE-0K2 Y) =RELAT-1R1 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y & idRELAT-1K7 (X /\\XBOOLE-0K3 Y) =RELAT-1R1 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y) & idRELAT-1K7 (X \\SUBSET-1K6 Y) =RELAT-1R1 idRELAT-1K7 X \\SUBSET-1K6 idRELAT-1K7 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds idRELAT-1K7 (X \\/XBOOLE-0K2 Y) =RELAT-1R1 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y & (idRELAT-1K7 (X /\\XBOOLE-0K3 Y) =RELAT-1R1 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y & idRELAT-1K7 (X \\SUBSET-1K6 Y) =RELAT-1R1 idRELAT-1K7 X \\SUBSET-1K6 idRELAT-1K7 Y)"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "idRELAT-1K7 (X \\/XBOOLE-0K2 Y) =RELAT-1R1 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\/XBOOLE-0K2 Y) implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y) & ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\/XBOOLE-0K2 Y))"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\/XBOOLE-0K2 Y) implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y"
        proof(rule impI)
          assume A1: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\/XBOOLE-0K2 Y)"
          then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using relat_1_def_10 sorry
          then have A2: "x inHIDDENR3 X or x inHIDDENR3 Y"
            using xboole_0_def_3 sorry
          have "x =HIDDENR1 y"
            using A1 relat_1_def_10 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X or [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 Y"
            using A2 relat_1_def_10 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y"
            using xboole_0_def_3 sorry
        qed
        assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y"
        then have A3: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X or [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 Y"
          using xboole_0_def_3 sorry
        then have "x inHIDDENR3 X or x inHIDDENR3 Y"
          using relat_1_def_10 sorry
        then have A4: "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_3 sorry
        have "x =HIDDENR1 y"
          using A3 relat_1_def_10 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\/XBOOLE-0K2 Y)"
          using A4 relat_1_def_10 sorry
      qed "sorry"
      thus "idRELAT-1K7 (X \\/XBOOLE-0K2 Y) =RELAT-1R1 idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y"
        using relat_1_def_2 sorry
    qed
    show "idRELAT-1K7 (X /\\XBOOLE-0K3 Y) =RELAT-1R1 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X /\\XBOOLE-0K3 Y) implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y) & ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X /\\XBOOLE-0K3 Y))"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X /\\XBOOLE-0K3 Y) implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y"
        proof(rule impI)
          assume A5: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X /\\XBOOLE-0K3 Y)"
          then have A6: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
            using relat_1_def_10 sorry
          have A7: "x =HIDDENR1 y"
            using A5 relat_1_def_10 sorry
          have "x inHIDDENR3 Y"
            using A6 xboole_0_def_4 sorry
          then have A8: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 Y"
            using A7 relat_1_def_10 sorry
          have "x inHIDDENR3 X"
            using A6 xboole_0_def_4 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
            using A7 relat_1_def_10 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y"
            using A8 xboole_0_def_4 sorry
        qed
        assume A9: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y"
        then have A10: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
          using xboole_0_def_4 sorry
        then have A11: "x =HIDDENR1 y"
          using relat_1_def_10 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 Y"
          using A9 xboole_0_def_4 sorry
        then have A12: "x inHIDDENR3 Y"
          using relat_1_def_10 sorry
        have "x inHIDDENR3 X"
          using A10 relat_1_def_10 sorry
        then have "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using A12 xboole_0_def_4 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X /\\XBOOLE-0K3 Y)"
          using A11 relat_1_def_10 sorry
      qed "sorry"
      thus "idRELAT-1K7 (X /\\XBOOLE-0K3 Y) =RELAT-1R1 idRELAT-1K7 X /\\XBOOLE-0K3 idRELAT-1K7 Y"
        using relat_1_def_2 sorry
    qed
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\SUBSET-1K6 Y) implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\SUBSET-1K6 idRELAT-1K7 Y) & ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\SUBSET-1K6 idRELAT-1K7 Y implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\SUBSET-1K6 Y))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\SUBSET-1K6 Y) implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\SUBSET-1K6 idRELAT-1K7 Y"
      proof(rule impI)
        assume A13: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\SUBSET-1K6 Y)"
        then have A14: "x inHIDDENR3 X \\SUBSET-1K6 Y"
          using relat_1_def_10 sorry
        then have " not x inHIDDENR3 Y"
          using xboole_0_def_5 sorry
        then have A15: " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 Y"
          using relat_1_def_10 sorry
        have "x =HIDDENR1 y"
          using A13 relat_1_def_10 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
          using A14 relat_1_def_10 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\SUBSET-1K6 idRELAT-1K7 Y"
          using A15 xboole_0_def_5 sorry
      qed
      assume A16: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X \\SUBSET-1K6 idRELAT-1K7 Y"
      then have A17: "x =HIDDENR1 y"
        using relat_1_def_10 sorry
      have " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 Y"
        using A16 xboole_0_def_5 sorry
      then have A18: " not (x inHIDDENR3 Y & x =HIDDENR1 y)"
        using relat_1_def_10 sorry
      have "x inHIDDENR3 X"
        using A16 relat_1_def_10 sorry
      then have "x inHIDDENR3 X \\SUBSET-1K6 Y"
        using A16 A18 relat_1_def_10 xboole_0_def_5 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (X \\SUBSET-1K6 Y)"
        using A17 relat_1_def_10 sorry
    qed "sorry"
    thus "idRELAT-1K7 (X \\SUBSET-1K6 Y) =RELAT-1R1 idRELAT-1K7 X \\SUBSET-1K6 idRELAT-1K7 Y"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_15:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies idRELAT-1K7 X c=RELAT-1R2 idRELAT-1K7 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies idRELAT-1K7 X c=RELAT-1R2 idRELAT-1K7 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X c=TARSKIR1 Y"
    then have "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Y"
      using xboole_1_th_12 sorry
    then have "idRELAT-1K7 X \\/XBOOLE-0K2 idRELAT-1K7 Y =RELAT-1R1 idRELAT-1K7 Y"
      using sysrel_th_14 sorry
    thus "idRELAT-1K7 X c=RELAT-1R2 idRELAT-1K7 Y"
      using xboole_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds idRELAT-1K7 (X \\SUBSET-1K6 Y) \\SUBSET-1K6 idRELAT-1K7 X =RELAT-1R1 {}XBOOLE-0K1"
  using sysrel_th_15 xboole_1_th_37 sorry

mtheorem sysrel_th_17:
" for R be RelationRELAT-1M1 holds R c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R) implies R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 R)"
proof-
  have " for R be RelationRELAT-1M1 holds R c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R) implies R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 R)"
  proof(rule ballI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R)"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)) & ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R) implies [TARSKIK4 x,y ] inHIDDENR3 R)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
        using A1 sorry
      assume A2: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
      then have "x inHIDDENR3 domRELAT-1K1 R"
        using relat_1_def_10 sorry
      then have A3: " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 R"
        using xtuple_0_def_12 sorry
      have "x =HIDDENR1 y"
        using A2 relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A1 A3 relat_1_def_10 sorry
    qed "sorry"
    thus "R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 R)"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_18:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds idRELAT-1K7 X c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4 implies idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X c=RELAT-1R2 R ~RELAT-1K4"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds idRELAT-1K7 X c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4 implies idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X c=RELAT-1R2 R ~RELAT-1K4"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "idRELAT-1K7 X c=RELAT-1R2 R \\/XBOOLE-0K2 R ~RELAT-1K4"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R & [TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
    proof(rule ballI,rule impI,rule conjMI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 X"
        using relat_1_def_10 sorry
      then have A2: "[TARSKIK4 x,x ] inHIDDENR3 R or [TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
        using A1 xboole_0_def_3 sorry
      thus "[TARSKIK4 x,x ] inHIDDENR3 R"
        using relat_1_def_7 sorry
      show "[TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
        using A2 relat_1_def_7 sorry
    qed "sorry"
    then have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4)"
       sorry
    thus "idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X c=RELAT-1R2 R ~RELAT-1K4"
      using relat_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_19:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds idRELAT-1K7 X c=RELAT-1R2 R implies idRELAT-1K7 X c=RELAT-1R2 R ~RELAT-1K4"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds idRELAT-1K7 X c=RELAT-1R2 R implies idRELAT-1K7 X c=RELAT-1R2 R ~RELAT-1K4"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "idRELAT-1K7 X c=RELAT-1R2 R"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 X"
        using relat_1_def_10 sorry
      thus "[TARSKIK4 x,x ] inHIDDENR3 R ~RELAT-1K4"
        using A1 relat_1_def_7 sorry
    qed "sorry"
    thus "idRELAT-1K7 X c=RELAT-1R2 R ~RELAT-1K4"
      using relat_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_20:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,X :] implies R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) =RELAT-1R1 R \\SUBSET-1K6 idRELAT-1K7 X & R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R) =RELAT-1R1 R \\SUBSET-1K6 idRELAT-1K7 X"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 [:ZFMISC-1K2 X,X :] implies R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) =RELAT-1R1 R \\SUBSET-1K6 idRELAT-1K7 X & R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R) =RELAT-1R1 R \\SUBSET-1K6 idRELAT-1K7 X"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have A1: "R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) c=RELAT-1R2 R \\SUBSET-1K6 idRELAT-1K7 X"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) implies [TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 X"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"
        then have A3: " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using xboole_0_def_5 sorry
        have " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
        proof-
          have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X implies  False "
          proof(rule impI)
            assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
            then have A4: "x =HIDDENR1 y"
              using relat_1_def_10 sorry
            have "x inHIDDENR3 domRELAT-1K1 R"
              using A2 xtuple_0_def_12 sorry
            thus " False "
              using A3 A4 relat_1_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "[TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 X"
          using A2 xboole_0_def_5 sorry
      qed "sorry"
      thus "R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) c=RELAT-1R2 R \\SUBSET-1K6 idRELAT-1K7 X"
        using relat_1_def_3 sorry
    qed
    have A5: "R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R) c=RELAT-1R2 R \\SUBSET-1K6 idRELAT-1K7 X"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R) implies [TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 X"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A6: "[TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)"
        then have A7: " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (rngRELAT-1K2 R)"
          using xboole_0_def_5 sorry
        have " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
        proof-
          have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X implies  False "
          proof(rule impI)
            assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
            then have A8: "x =HIDDENR1 y"
              using relat_1_def_10 sorry
            have "y inHIDDENR3 rngRELAT-1K2 R"
              using A6 xtuple_0_def_13 sorry
            thus " False "
              using A7 A8 relat_1_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "[TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 X"
          using A6 xboole_0_def_5 sorry
      qed "sorry"
      thus "R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R) c=RELAT-1R2 R \\SUBSET-1K6 idRELAT-1K7 X"
        using relat_1_def_3 sorry
    qed
    assume A9: "R c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
    then have "idRELAT-1K7 (domRELAT-1K1 R) c=RELAT-1R2 idRELAT-1K7 X"
      using sysrel_th_3 sysrel_th_15 sorry
    then have "R \\SUBSET-1K6 idRELAT-1K7 X c=RELAT-1R2 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"
      using xboole_1_th_34 sorry
    thus "R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) =RELAT-1R1 R \\SUBSET-1K6 idRELAT-1K7 X"
      using A1 sorry
    have "idRELAT-1K7 (rngRELAT-1K2 R) c=RELAT-1R2 idRELAT-1K7 X"
      using A9 sysrel_th_3 sysrel_th_15 sorry
    then have "R \\SUBSET-1K6 idRELAT-1K7 X c=RELAT-1R2 R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)"
      using xboole_1_th_34 sorry
    thus "R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R) =RELAT-1R1 R \\SUBSET-1K6 idRELAT-1K7 X"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_21:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (idRELAT-1K7 X *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X) =XBOOLE-0R4 domRELAT-1K1 R \\SUBSET-1K6 X) & ((R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 {}XBOOLE-0K1 implies rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X) =XBOOLE-0R4 rngRELAT-1K2 R \\SUBSET-1K6 X)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (idRELAT-1K7 X *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X) =XBOOLE-0R4 domRELAT-1K1 R \\SUBSET-1K6 X) & ((R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 {}XBOOLE-0K1 implies rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X) =XBOOLE-0R4 rngRELAT-1K2 R \\SUBSET-1K6 X)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "idRELAT-1K7 X *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X) =XBOOLE-0R4 domRELAT-1K1 R \\SUBSET-1K6 X"
    proof(rule impI)
      assume A1: "idRELAT-1K7 X *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1"
      have A2: "domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X) c=TARSKIR1 domRELAT-1K1 R \\SUBSET-1K6 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X) implies x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have A3: "x inHIDDENR3 domRELAT-1K1 R &  not x inHIDDENR3 X implies  not (x inHIDDENR3 domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X) &  not x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 X)"
            using xboole_0_def_5 sorry
          assume "x inHIDDENR3 domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X)"
          then have A4: " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 X"
            using xtuple_0_def_12 sorry
          have " not x inHIDDENR3 X"
          proof-
            have "x inHIDDENR3 X implies  not  True "
            proof(rule impI)
              assume "x inHIDDENR3 X"
              then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 X"
                using relat_1_def_10 sorry
              thus " not  True "
                using A1 A4 relat_1_def_8 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          thus "x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 X"
            using A4 A3 xtuple_0_def_12 sorry
        qed "sorry"
        thus "domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X) c=TARSKIR1 domRELAT-1K1 R \\SUBSET-1K6 X"
          using tarski_def_3 sorry
      qed
      have "domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (idRELAT-1K7 X) c=TARSKIR1 domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X)"
        using xtuple_0_th_25 sorry
      then have "domRELAT-1K1 R \\SUBSET-1K6 X c=TARSKIR1 domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X)"
         sorry
      thus "domRELAT-1K1 (R \\SUBSET-1K6 idRELAT-1K7 X) =XBOOLE-0R4 domRELAT-1K1 R \\SUBSET-1K6 X"
        using A2 sorry
    qed
    show "(R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 {}XBOOLE-0K1 implies rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X) =XBOOLE-0R4 rngRELAT-1K2 R \\SUBSET-1K6 X"
    proof(rule impI)
      assume A5: "(R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 {}XBOOLE-0K1"
      have A6: "rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X) c=TARSKIR1 rngRELAT-1K2 R \\SUBSET-1K6 X"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X) implies y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 X"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          have A7: "y inHIDDENR3 rngRELAT-1K2 R &  not y inHIDDENR3 X implies  not (y inHIDDENR3 rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X) &  not y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 X)"
            using xboole_0_def_5 sorry
          assume "y inHIDDENR3 rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X)"
          then have A8: " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 X"
            using xtuple_0_def_13 sorry
          have " not y inHIDDENR3 X"
          proof-
            have "y inHIDDENR3 X implies  not  True "
            proof(rule impI)
              assume "y inHIDDENR3 X"
              then have "[TARSKIK4 y,y ] inHIDDENR3 idRELAT-1K7 X"
                using relat_1_def_10 sorry
              thus " not  True "
                using A5 A8 relat_1_def_8 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          thus "y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 X"
            using A8 A7 xtuple_0_def_13 sorry
        qed "sorry"
        thus "rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X) c=TARSKIR1 rngRELAT-1K2 R \\SUBSET-1K6 X"
          using tarski_def_3 sorry
      qed
      have "rngRELAT-1K2 R \\SUBSET-1K6 rngRELAT-1K2 (idRELAT-1K7 X) c=TARSKIR1 rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X)"
        using relat_1_th_14 sorry
      then have "rngRELAT-1K2 R \\SUBSET-1K6 X c=TARSKIR1 rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X)"
         sorry
      thus "rngRELAT-1K2 (R \\SUBSET-1K6 idRELAT-1K7 X) =XBOOLE-0R4 rngRELAT-1K2 R \\SUBSET-1K6 X"
        using A6 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_22:
" for R be RelationRELAT-1M1 holds (R c=RELAT-1R2 R *RELAT-1K6 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) =RELAT-1R1 {}XBOOLE-0K1 implies idRELAT-1K7 (rngRELAT-1K2 R) c=RELAT-1R2 R) & (R c=RELAT-1R2 R *RELAT-1K6 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies idRELAT-1K7 (domRELAT-1K1 R) c=RELAT-1R2 R)"
proof-
  have " for R be RelationRELAT-1M1 holds (R c=RELAT-1R2 R *RELAT-1K6 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) =RELAT-1R1 {}XBOOLE-0K1 implies idRELAT-1K7 (rngRELAT-1K2 R) c=RELAT-1R2 R) & (R c=RELAT-1R2 R *RELAT-1K6 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies idRELAT-1K7 (domRELAT-1K1 R) c=RELAT-1R2 R)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R c=RELAT-1R2 R *RELAT-1K6 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) =RELAT-1R1 {}XBOOLE-0K1 implies idRELAT-1K7 (rngRELAT-1K2 R) c=RELAT-1R2 R"
    proof(rule impMI ,rule impI)
      assume A1: "R c=RELAT-1R2 R *RELAT-1K6 R"
        and A2: "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) =RELAT-1R1 {}XBOOLE-0K1"
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R implies [TARSKIK4 y,y ] inHIDDENR3 R"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngRELAT-1K2 R"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A4: "[TARSKIK4 x,z ] inHIDDENR3 R"and A5: "[TARSKIK4 z,y ] inHIDDENR3 R"
          using A1 A3 relat_1_def_8 sorry
        have "z =HIDDENR1 y"
        proof-
          have "z <>HIDDENR2 y implies  False "
          proof(rule impI)
            assume "z <>HIDDENR2 y"
            then have " not [TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 (rngRELAT-1K2 R)"
              using relat_1_def_10 sorry
            then have "[TARSKIK4 z,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)"
              using A5 xboole_0_def_5 sorry
            thus " False "
              using A2 A4 relat_1_def_8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "[TARSKIK4 y,y ] inHIDDENR3 R"
          using A5 sorry
      qed "sorry"
      thus "idRELAT-1K7 (rngRELAT-1K2 R) c=RELAT-1R2 R"
        using relat_1_th_47 sorry
    qed
    assume A6: "R c=RELAT-1R2 R *RELAT-1K6 R"
      and A7: "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R implies [TARSKIK4 x,x ] inHIDDENR3 R"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 R"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A8: "[TARSKIK4 x,y ] inHIDDENR3 R"
        using xtuple_0_def_12 sorry
      obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A9: "[TARSKIK4 x,z ] inHIDDENR3 R"and A10: "[TARSKIK4 z,y ] inHIDDENR3 R"
        using A6 A8 relat_1_def_8 sorry
      have "z =HIDDENR1 x"
      proof-
        have "z <>HIDDENR2 x implies  False "
        proof(rule impI)
          assume "z <>HIDDENR2 x"
          then have " not [TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
            using relat_1_def_10 sorry
          then have "[TARSKIK4 x,z ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"
            using A9 xboole_0_def_5 sorry
          thus " False "
            using A7 A10 relat_1_def_8 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "[TARSKIK4 x,x ] inHIDDENR3 R"
        using A9 sorry
    qed "sorry"
    thus "idRELAT-1K7 (domRELAT-1K1 R) c=RELAT-1R2 R"
      using relat_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_23:
" for R be RelationRELAT-1M1 holds (R c=RELAT-1R2 R *RELAT-1K6 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) =RELAT-1R1 {}XBOOLE-0K1 implies R /\\XBOOLE-0K3 idRELAT-1K7 (rngRELAT-1K2 R) =RELAT-1R1 idRELAT-1K7 (rngRELAT-1K2 R)) & (R c=RELAT-1R2 R *RELAT-1K6 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 R))"
  using sysrel_th_22 xboole_1_th_28 sorry

mtheorem sysrel_th_24:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) =RELAT-1R1 {}XBOOLE-0K1) & ((R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) =RELAT-1R1 {}XBOOLE-0K1) & ((R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) =RELAT-1R1 {}XBOOLE-0K1"
    proof-
      have "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) <>HIDDENR2 {}XBOOLE-0K1 implies  False "
      proof(rule impMI ,rule impI)
        assume A1: "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1"
          and A2: "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)) <>HIDDENR2 {}XBOOLE-0K1"
        obtain x y where
          [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
          A3: "[TARSKIK4 x,y ] inHIDDENR3 R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R))"
          using A2 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A4: "[TARSKIK4 x,z ] inHIDDENR3 R"and A5: "[TARSKIK4 z,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 R)"
          using A3 relat_1_def_8 sorry
        have "z inHIDDENR3 rngRELAT-1K2 R &  not [TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 (rngRELAT-1K2 R)"
          using A4 A5 xboole_0_def_5 xtuple_0_def_13 sorry
        then have "z <>HIDDENR2 y"
          using relat_1_def_10 sorry
        then have " not [TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 X"
          using relat_1_def_10 sorry
        then have "[TARSKIK4 z,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 X"
          using A5 xboole_0_def_5 sorry
        thus " False "
          using A1 A4 relat_1_def_8 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A6: "(R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
      and A7: "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R <>HIDDENR2 {}XBOOLE-0K1"
    obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A8: "[TARSKIK4 x,y ] inHIDDENR3 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R"
      using A7 sorry
    obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A9: "[TARSKIK4 x,z ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"and A10: "[TARSKIK4 z,y ] inHIDDENR3 R"
      using A8 relat_1_def_8 sorry
    have " not [TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
      using A9 xboole_0_def_5 sorry
    then have " not z inHIDDENR3 domRELAT-1K1 R or x <>HIDDENR2 z"
      using relat_1_def_10 sorry
    then have " not [TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 X"
      using A10 relat_1_def_10 xtuple_0_def_12 sorry
    then have "[TARSKIK4 x,z ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 X"
      using A9 xboole_0_def_5 sorry
    thus " False "
      using A6 A10 relat_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef sysrel_def_1 ("CLSYSRELK1  _ " [164]164 ) where
  mlet "R be RelationRELAT-1M1"
"func CLSYSRELK1 R \<rightarrow> RelationRELAT-1M1 equals
  R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R)"
proof-
  (*coherence*)
    show "R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R) be RelationRELAT-1M1"
       sorry
qed "sorry"

mtheorem sysrel_th_25:
" for R be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R implies x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) & x =HIDDENR1 y"
proof-
  have " for R be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R implies x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) & x =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
    then have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
      using xboole_0_def_4 sorry
    thus "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) & x =HIDDENR1 y"
      using A1 relat_1_def_10 xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_26:
" for R be RelationRELAT-1M1 holds domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 (CLSYSRELK1 R)"
proof-
  have " for R be RelationRELAT-1M1 holds domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 (CLSYSRELK1 R)"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 (CLSYSRELK1 R) & rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 (CLSYSRELK1 R)"
    proof(rule conjMI)
      show "domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 (CLSYSRELK1 R)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) implies x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
            using xtuple_0_def_12 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
            using A1 xboole_0_def_4 sorry
          then have "[TARSKIK4 x,x ] inHIDDENR3 CLSYSRELK1 R"
            using A1 relat_1_def_10 sorry
          thus "x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R)"
            using xtuple_0_def_13 sorry
        qed "sorry"
        thus "domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 (CLSYSRELK1 R)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R) implies x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A2: "[TARSKIK4 y,x ] inHIDDENR3 CLSYSRELK1 R"
          using xtuple_0_def_13 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A2 xboole_0_def_4 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 CLSYSRELK1 R"
          using A2 relat_1_def_10 sorry
        thus "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
          using xtuple_0_def_12 sorry
      qed "sorry"
      thus "rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 (CLSYSRELK1 R)"
        using tarski_def_3 sorry
    qed
    thus "domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 (CLSYSRELK1 R)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_27:
" for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (((x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) iff x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R) & (x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R) iff x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R)) & (x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R) iff x inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,x ] inHIDDENR3 R)) & (x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) iff x inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,x ] inHIDDENR3 R)"
proof-
  have " for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) iff x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R) & ((x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R) iff x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R) & ((x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R) iff x inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,x ] inHIDDENR3 R) & ( not (x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) &  not (x inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,x ] inHIDDENR3 R)) &  not ((x inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,x ] inHIDDENR3 R) &  not x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)))))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have A1: "x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R implies x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
    proof(rule impMI ,rule impI)
      assume A2: "x inHIDDENR3 domRELAT-1K1 R"
        and A3: "[TARSKIK4 x,x ] inHIDDENR3 R"
      have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
        using A2 relat_1_def_10 sorry
      then have "[TARSKIK4 x,x ] inHIDDENR3 R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R)"
        using A3 xboole_0_def_4 sorry
      thus "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
        using xtuple_0_def_12 sorry
    qed
    have A4: "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) implies x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R"
    proof(rule impI)
      assume "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A5: "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
        using xtuple_0_def_12 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
        using A5 xboole_0_def_4 sorry
      thus "x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R"
        using relat_1_def_10 sorry
    qed
    thus "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) iff x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R"
      using A1 sorry
    show "x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R) iff x inHIDDENR3 domRELAT-1K1 R & [TARSKIK4 x,x ] inHIDDENR3 R"
      using A4 A1 sysrel_th_26 sorry
    show "x inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R) iff x inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,x ] inHIDDENR3 R"
      using A4 A1 sysrel_th_26 xtuple_0_def_12 xtuple_0_def_13 sorry
    show " not (x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) &  not (x inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,x ] inHIDDENR3 R)) &  not ((x inHIDDENR3 rngRELAT-1K2 R & [TARSKIK4 x,x ] inHIDDENR3 R) &  not x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R))"
      using A4 A1 xtuple_0_def_12 xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_28:
" for R be RelationRELAT-1M1 holds CLSYSRELK1 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
proof-
  have " for R be RelationRELAT-1M1 holds CLSYSRELK1 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) & ([TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) implies [TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R implies [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
      proof(rule impI)
        assume A1: "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
        then have "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using xboole_0_def_4 sorry
        then have A2: "x =HIDDENR1 y"
          using relat_1_def_10 sorry
        have "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
          using A1 xtuple_0_def_12 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
          using A2 relat_1_def_10 sorry
      qed
      assume A3: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
      then have "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
        using relat_1_def_10 sorry
      then have A4: " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 CLSYSRELK1 R"
        using xtuple_0_def_12 sorry
      have "x =HIDDENR1 y"
        using A3 relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
        using A4 sysrel_th_25 sorry
    qed "sorry"
    thus "CLSYSRELK1 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_29:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (((R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 CLSYSRELK1 R) =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) & x <>HIDDENR2 y implies x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)) & (((R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 CLSYSRELK1 R)*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) & x <>HIDDENR2 y implies y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R))"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (((R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 CLSYSRELK1 R) =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) & x <>HIDDENR2 y implies x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)) & (((R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 CLSYSRELK1 R)*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) & x <>HIDDENR2 y implies y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "((R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 CLSYSRELK1 R) =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) & x <>HIDDENR2 y implies x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
    proof-
      have "R *RELAT-1K6 R =RELAT-1R1 R & (R *RELAT-1K6 (R \\SUBSET-1K6 CLSYSRELK1 R) =RELAT-1R1 {}XBOOLE-0K1 & ([TARSKIK4 x,y ] inHIDDENR3 R & x <>HIDDENR2 y)) implies x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
      proof(rule impMI ,rule impMI ,rule impMI ,rule impI)
        assume A1: "R *RELAT-1K6 R =RELAT-1R1 R"
          and A2: "R *RELAT-1K6 (R \\SUBSET-1K6 CLSYSRELK1 R) =RELAT-1R1 {}XBOOLE-0K1"
          and A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
          and A4: "x <>HIDDENR2 y"
        have A5: "y inHIDDENR3 rngRELAT-1K2 R"
          using A3 xtuple_0_def_13 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A6: "[TARSKIK4 x,z ] inHIDDENR3 R"and A7: "[TARSKIK4 z,y ] inHIDDENR3 R"
          using A1 A3 relat_1_def_8 sorry
        have A8: "z =HIDDENR1 y"
        proof-
          have "z <>HIDDENR2 y implies  not  True "
          proof(rule impI)
            assume "z <>HIDDENR2 y"
            then have " not [TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
              using relat_1_def_10 sorry
            then have " not [TARSKIK4 z,y ] inHIDDENR3 R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R)"
              using xboole_0_def_4 sorry
            then have "[TARSKIK4 z,y ] inHIDDENR3 R \\SUBSET-1K6 CLSYSRELK1 R"
              using A7 xboole_0_def_5 sorry
            thus " not  True "
              using A2 A6 relat_1_def_8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A4 relat_1_def_10 sorry
        then have " not [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R)"
          using xboole_0_def_4 sorry
        then have A9: "[TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 CLSYSRELK1 R"
          using A3 xboole_0_def_5 sorry
        have A10: " not x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
        proof-
          have "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) implies  not  True "
          proof(rule impI)
            assume "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
            then have "[TARSKIK4 x,x ] inHIDDENR3 R"
              using sysrel_th_27 sorry
            thus " not  True "
              using A2 A9 relat_1_def_8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "x inHIDDENR3 domRELAT-1K1 R"
          using A6 xtuple_0_def_12 sorry
        thus "x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
          using A7 A8 A5 A10 sysrel_th_27 xboole_0_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "((R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 CLSYSRELK1 R)*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) & x <>HIDDENR2 y implies y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
    proof-
      have "R *RELAT-1K6 R =RELAT-1R1 R & ((R \\SUBSET-1K6 CLSYSRELK1 R)*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 & ([TARSKIK4 x,y ] inHIDDENR3 R & x <>HIDDENR2 y)) implies y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
      proof(rule impMI ,rule impMI ,rule impMI ,rule impI)
        assume A11: "R *RELAT-1K6 R =RELAT-1R1 R"
          and A12: "(R \\SUBSET-1K6 CLSYSRELK1 R)*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
          and A13: "[TARSKIK4 x,y ] inHIDDENR3 R"
          and A14: "x <>HIDDENR2 y"
        have A15: "x inHIDDENR3 domRELAT-1K1 R"
          using A13 xtuple_0_def_12 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A16: "[TARSKIK4 x,z ] inHIDDENR3 R"and A17: "[TARSKIK4 z,y ] inHIDDENR3 R"
          using A11 A13 relat_1_def_8 sorry
        have A18: "z =HIDDENR1 x"
        proof-
          have "z <>HIDDENR2 x implies  not  True "
          proof(rule impI)
            assume "z <>HIDDENR2 x"
            then have " not [TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
              using relat_1_def_10 sorry
            then have " not [TARSKIK4 x,z ] inHIDDENR3 R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R)"
              using xboole_0_def_4 sorry
            then have "[TARSKIK4 x,z ] inHIDDENR3 R \\SUBSET-1K6 CLSYSRELK1 R"
              using A16 xboole_0_def_5 sorry
            thus " not  True "
              using A12 A17 relat_1_def_8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have " not [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A14 relat_1_def_10 sorry
        then have " not [TARSKIK4 x,y ] inHIDDENR3 R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R)"
          using xboole_0_def_4 sorry
        then have A19: "[TARSKIK4 x,y ] inHIDDENR3 R \\SUBSET-1K6 CLSYSRELK1 R"
          using A13 xboole_0_def_5 sorry
        have A20: " not y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
        proof-
          have "y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) implies  not  True "
          proof(rule impI)
            assume "y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
            then have "[TARSKIK4 y,y ] inHIDDENR3 R"
              using sysrel_th_27 sorry
            thus " not  True "
              using A12 A19 relat_1_def_8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "y inHIDDENR3 rngRELAT-1K2 R"
          using A17 xtuple_0_def_13 sorry
        thus "y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
          using A16 A18 A15 A20 sysrel_th_27 xboole_0_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_30:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (((R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) & x <>HIDDENR2 y implies x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)) & (((R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) & x <>HIDDENR2 y implies y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R))"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds  not ((((R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) &  not x <>HIDDENR2 y) &  not (x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R))) &  not ((((R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) &  not x <>HIDDENR2 y) &  not (y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)))"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R \\SUBSET-1K6 CLSYSRELK1 R =RELAT-1R1 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"
      using xboole_1_th_47 sorry
    thus " not ((((R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) &  not x <>HIDDENR2 y) &  not (x inHIDDENR3 domRELAT-1K1 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R))) &  not ((((R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1) & [TARSKIK4 x,y ] inHIDDENR3 R) &  not x <>HIDDENR2 y) &  not (y inHIDDENR3 rngRELAT-1K2 R \\SUBSET-1K6 domRELAT-1K1 (CLSYSRELK1 R) & x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)))"
      using sysrel_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_31:
" for R be RelationRELAT-1M1 holds (R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R & rngRELAT-1K2 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R) & (R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R & rngRELAT-1K2 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R)"
proof-
  have " for R be RelationRELAT-1M1 holds (R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R & rngRELAT-1K2 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R) & (R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R & rngRELAT-1K2 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R)"
  proof(rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R *RELAT-1K6 R =RELAT-1R1 R & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R & rngRELAT-1K2 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R"
    proof(rule impMI ,rule impI)
      assume A1: "R *RELAT-1K6 R =RELAT-1R1 R"
        and A2: "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1"
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R implies y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngRELAT-1K2 R"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A4: "[TARSKIK4 x,z ] inHIDDENR3 R"and A5: "[TARSKIK4 z,y ] inHIDDENR3 R"
          using A1 A3 relat_1_def_8 sorry
        have A6: "z =HIDDENR1 y"
        proof-
          have "z <>HIDDENR2 y implies  not  True "
          proof(rule impI)
            assume "z <>HIDDENR2 y"
            then have " not [TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
              using relat_1_def_10 sorry
            then have "[TARSKIK4 z,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"
              using A5 xboole_0_def_5 sorry
            thus " not  True "
              using A2 A4 relat_1_def_8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "z inHIDDENR3 domRELAT-1K1 R"
          using A5 xtuple_0_def_12 sorry
        then have "[TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A6 relat_1_def_10 sorry
        then have "[TARSKIK4 z,y ] inHIDDENR3 R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A5 xboole_0_def_4 sorry
        thus "y inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
          using A6 xtuple_0_def_12 sorry
      qed "sorry"
      then have A7: "rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 (CLSYSRELK1 R)"
         sorry
      have "CLSYSRELK1 R c=RELAT-1R2 R"
        using xboole_1_th_17 sorry
      then have "rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 R"
        using relat_1_th_11 sorry
      then have "domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 R"
        using sysrel_th_26 sorry
      then have "domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R"
        using A7 sorry
      thus "domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R & rngRELAT-1K2 (CLSYSRELK1 R) =XBOOLE-0R4 rngRELAT-1K2 R"
        using sysrel_th_26 sorry
    qed
    show "R *RELAT-1K6 R =RELAT-1R1 R & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R & rngRELAT-1K2 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R"
    proof(rule impMI ,rule impI)
      assume A8: "R *RELAT-1K6 R =RELAT-1R1 R"
        and A9: "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R implies x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A10: "x inHIDDENR3 domRELAT-1K1 R"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A11: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_12 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A12: "[TARSKIK4 x,z ] inHIDDENR3 R"and A13: "[TARSKIK4 z,y ] inHIDDENR3 R"
          using A8 A11 relat_1_def_8 sorry
        have A14: "z =HIDDENR1 x"
        proof-
          have "z <>HIDDENR2 x implies  not  True "
          proof(rule impI)
            assume "z <>HIDDENR2 x"
            then have " not [TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
              using relat_1_def_10 sorry
            then have "[TARSKIK4 x,z ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"
              using A12 xboole_0_def_5 sorry
            thus " not  True "
              using A9 A13 relat_1_def_8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have "[TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A10 relat_1_def_10 sorry
        then have "[TARSKIK4 x,z ] inHIDDENR3 R /\\XBOOLE-0K3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A12 xboole_0_def_4 sorry
        then have "z inHIDDENR3 rngRELAT-1K2 (CLSYSRELK1 R)"
          using xtuple_0_def_13 sorry
        thus "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R)"
          using A14 sysrel_th_26 sorry
      qed "sorry"
      then have A15: "domRELAT-1K1 R c=TARSKIR1 domRELAT-1K1 (CLSYSRELK1 R)"
         sorry
      have "CLSYSRELK1 R c=RELAT-1R2 R"
        using xboole_1_th_17 sorry
      then have "domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 R"
        using relat_1_th_11 sorry
      then have "domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R"
        using A15 sorry
      thus "domRELAT-1K1 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R & rngRELAT-1K2 (CLSYSRELK1 R) =XBOOLE-0R4 domRELAT-1K1 R"
        using sysrel_th_26 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_32:
" for R be RelationRELAT-1M1 holds ((domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 R & rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 R) & rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 R) & domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 R"
proof-
  have " for R be RelationRELAT-1M1 holds (domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 R & rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 R) & (rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 R & domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 R)"
  proof(rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "CLSYSRELK1 R c=RELAT-1R2 R"
      using xboole_1_th_17 sorry
    thus "domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 R & rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 R"
      using relat_1_th_11 sorry
    thus "rngRELAT-1K2 (CLSYSRELK1 R) c=TARSKIR1 domRELAT-1K1 R & domRELAT-1K1 (CLSYSRELK1 R) c=TARSKIR1 rngRELAT-1K2 R"
      using sysrel_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_33:
" for R be RelationRELAT-1M1 holds idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R) & idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)) c=RELAT-1R2 idRELAT-1K7 (domRELAT-1K1 R)"
  using sysrel_th_15 sysrel_th_32 sorry

mtheorem sysrel_th_34:
" for R be RelationRELAT-1M1 holds idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) c=RELAT-1R2 R & idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)) c=RELAT-1R2 R"
proof-
  have " for R be RelationRELAT-1M1 holds idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) c=RELAT-1R2 R & idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)) c=RELAT-1R2 R"
  proof(rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) c=RELAT-1R2 R"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) implies [TARSKIK4 x,y ] inHIDDENR3 R"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
        then have "x inHIDDENR3 domRELAT-1K1 (CLSYSRELK1 R) & x =HIDDENR1 y"
          using relat_1_def_10 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R"
          using sysrel_th_27 sorry
      qed "sorry"
      thus "idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) c=RELAT-1R2 R"
        using relat_1_def_3 sorry
    qed
    thus "idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)) c=RELAT-1R2 R"
      using sysrel_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_35:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies R  |RELAT-1K8 X =RELAT-1R1 idRELAT-1K7 X) & (idRELAT-1K7 X c=RELAT-1R2 R & (R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 {}XBOOLE-0K1 implies X  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 X)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies R  |RELAT-1K8 X =RELAT-1R1 idRELAT-1K7 X) & (idRELAT-1K7 X c=RELAT-1R2 R & (R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 {}XBOOLE-0K1 implies X  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "idRELAT-1K7 X c=RELAT-1R2 R & idRELAT-1K7 X *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1 implies R  |RELAT-1K8 X =RELAT-1R1 idRELAT-1K7 X"
    proof(rule impMI ,rule impI)
      assume A1: "idRELAT-1K7 X c=RELAT-1R2 R"
        and A2: "idRELAT-1K7 X *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 X) =RELAT-1R1 {}XBOOLE-0K1"
      have "R  |RELAT-1K8 X =HIDDENR1 idRELAT-1K7 X *RELAT-1K6 R"
        using relat_1_th_65 sorry
      also have "... = idRELAT-1K7 X *RELAT-1K6 (R \\/XBOOLE-0K2 idRELAT-1K7 X)"
        using A1 xboole_1_th_12 sorry
      also have "... = idRELAT-1K7 X *RELAT-1K6 ((R \\SUBSET-1K6 idRELAT-1K7 X)\\/XBOOLE-0K2 idRELAT-1K7 X)"
        using xboole_1_th_39 sorry
      also have "... = {}XBOOLE-0K1 \\/XBOOLE-0K2 idRELAT-1K7 X *RELAT-1K6 idRELAT-1K7 X"
        using A2 relat_1_th_32 sorry
      also have "... = idRELAT-1K7 X"
        using sysrel_th_12 sorry
      finally have "R  |RELAT-1K8 X =HIDDENR1 idRELAT-1K7 X"
         sorry
      thus "R  |RELAT-1K8 X =RELAT-1R1 idRELAT-1K7 X"
         sorry
    qed
    assume A3: "idRELAT-1K7 X c=RELAT-1R2 R"
      and A4: "(R \\SUBSET-1K6 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X =RELAT-1R1 {}XBOOLE-0K1"
    have "X  |`RELAT-1K9 R =HIDDENR1 R *RELAT-1K6 idRELAT-1K7 X"
      using relat_1_th_92 sorry
    also have "... = (R \\/XBOOLE-0K2 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X"
      using A3 xboole_1_th_12 sorry
    also have "... = ((R \\SUBSET-1K6 idRELAT-1K7 X)\\/XBOOLE-0K2 idRELAT-1K7 X)*RELAT-1K6 idRELAT-1K7 X"
      using xboole_1_th_39 sorry
    also have "... = {}XBOOLE-0K1 \\/XBOOLE-0K2 idRELAT-1K7 X *RELAT-1K6 idRELAT-1K7 X"
      using A4 sysrel_th_6 sorry
    also have "... = idRELAT-1K7 X"
      using sysrel_th_12 sorry
    finally have "X  |`RELAT-1K9 R =HIDDENR1 idRELAT-1K7 X"
       sorry
    thus "X  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_36:
" for R be RelationRELAT-1M1 holds (idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) =RELAT-1R1 {}XBOOLE-0K1 implies R  |RELAT-1K8 domRELAT-1K1 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) & R  |RELAT-1K8 rngRELAT-1K2 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) & ((R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)))*RELAT-1K6 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (CLSYSRELK1 R)  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) & rngRELAT-1K2 (CLSYSRELK1 R)  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)))"
proof-
  have " for R be RelationRELAT-1M1 holds (idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) =RELAT-1R1 {}XBOOLE-0K1 implies R  |RELAT-1K8 domRELAT-1K1 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) & R  |RELAT-1K8 rngRELAT-1K2 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) & ((R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)))*RELAT-1K6 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies domRELAT-1K1 (CLSYSRELK1 R)  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) & rngRELAT-1K2 (CLSYSRELK1 R)  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)))"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) =RELAT-1R1 {}XBOOLE-0K1 implies R  |RELAT-1K8 domRELAT-1K1 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) & R  |RELAT-1K8 rngRELAT-1K2 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
    proof(rule impI)
      assume A1: "idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) =RELAT-1R1 {}XBOOLE-0K1"
      have "idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) c=RELAT-1R2 R"
        using sysrel_th_34 sorry
      then have "R  |RELAT-1K8 domRELAT-1K1 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
        using A1 sysrel_th_35 sorry
      thus "R  |RELAT-1K8 domRELAT-1K1 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) & R  |RELAT-1K8 rngRELAT-1K2 (CLSYSRELK1 R) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
        using sysrel_th_26 sorry
    qed
    assume A2: "(R \\SUBSET-1K6 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)))*RELAT-1K6 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)) =RELAT-1R1 {}XBOOLE-0K1"
    have "idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R)) c=RELAT-1R2 R"
      using sysrel_th_34 sorry
    then have "rngRELAT-1K2 (CLSYSRELK1 R)  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R))"
      using A2 sysrel_th_35 sorry
    then have "domRELAT-1K1 (CLSYSRELK1 R)  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R))"
      using sysrel_th_26 sorry
    thus "domRELAT-1K1 (CLSYSRELK1 R)  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) & rngRELAT-1K2 (CLSYSRELK1 R)  |`RELAT-1K9 R =RELAT-1R1 idRELAT-1K7 (rngRELAT-1K2 (CLSYSRELK1 R))"
      using sysrel_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_37:
" for R be RelationRELAT-1M1 holds (R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) =RELAT-1R1 {}XBOOLE-0K1) & ((R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)))*RELAT-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) =RELAT-1R1 {}XBOOLE-0K1)"
proof-
  have " for R be RelationRELAT-1M1 holds (R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) =RELAT-1R1 {}XBOOLE-0K1) & ((R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)))*RELAT-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) =RELAT-1R1 {}XBOOLE-0K1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) =RELAT-1R1 {}XBOOLE-0K1"
    proof(rule impI)
      have A1: "idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) c=RELAT-1R2 R"
        using sysrel_th_34 sorry
      assume A2: "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1"
      have "R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) =HIDDENR1 R \\SUBSET-1K6 CLSYSRELK1 R"
        using xboole_1_th_47 sorry
      also have "... = R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
        using sysrel_th_28 sorry
      finally have "R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) =HIDDENR1 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
         sorry
      thus "idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))) =RELAT-1R1 {}XBOOLE-0K1"
        using A2 A1 relat_1_th_30 xboole_1_th_3 sorry
    qed
    have A3: "idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) c=RELAT-1R2 R"
      using sysrel_th_34 sorry
    assume A4: "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
    have "R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) =HIDDENR1 R \\SUBSET-1K6 CLSYSRELK1 R"
      using xboole_1_th_47 sorry
    also have "... = R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
      using sysrel_th_28 sorry
    finally have "R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R) =HIDDENR1 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R))"
       sorry
    thus "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)))*RELAT-1K6 idRELAT-1K7 (domRELAT-1K1 (CLSYSRELK1 R)) =RELAT-1R1 {}XBOOLE-0K1"
      using A4 A3 relat_1_th_29 xboole_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_38:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds (S *RELAT-1K6 R =RELAT-1R1 S & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies S *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1) & (R *RELAT-1K6 S =RELAT-1R1 S & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 S =RELAT-1R1 {}XBOOLE-0K1)"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds (S *RELAT-1K6 R =RELAT-1R1 S & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies S *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1) & (R *RELAT-1K6 S =RELAT-1R1 S & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 S =RELAT-1R1 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    show "S *RELAT-1K6 R =RELAT-1R1 S & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies S *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1"
    proof(rule impI)
      assume "S *RELAT-1K6 R =RELAT-1R1 S & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1"
      then have "S *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =HIDDENR1 S *RELAT-1K6 {}XBOOLE-0K1"
        using relat_1_th_36 sorry
      also have "... = {}XBOOLE-0K1"
         sorry
      finally have "S *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =HIDDENR1 {}XBOOLE-0K1"
         sorry
      thus "S *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1"
         sorry
    qed
    assume "R *RELAT-1K6 S =RELAT-1R1 S & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
    then have "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 S =HIDDENR1 {}XBOOLE-0K1 *RELAT-1K6 S"
      using relat_1_th_36 sorry
    also have "... = {}XBOOLE-0K1"
       sorry
    finally have "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 S =HIDDENR1 {}XBOOLE-0K1"
       sorry
    thus "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 S =RELAT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_39:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds (S *RELAT-1K6 R =RELAT-1R1 S & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies CLSYSRELK1 S c=RELAT-1R2 CLSYSRELK1 R) & (R *RELAT-1K6 S =RELAT-1R1 S & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies CLSYSRELK1 S c=RELAT-1R2 CLSYSRELK1 R)"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds (S *RELAT-1K6 R =RELAT-1R1 S & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies CLSYSRELK1 S c=RELAT-1R2 CLSYSRELK1 R) & (R *RELAT-1K6 S =RELAT-1R1 S & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1 implies CLSYSRELK1 S c=RELAT-1R2 CLSYSRELK1 R)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    show "S *RELAT-1K6 R =RELAT-1R1 S & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1 implies CLSYSRELK1 S c=RELAT-1R2 CLSYSRELK1 R"
    proof(rule impMI ,rule impI)
      assume A1: "S *RELAT-1K6 R =RELAT-1R1 S"
        and A2: "R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1"
      have A3: "S *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1"
        using A1 A2 sysrel_th_38 sorry
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 S implies [TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A4: "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 S"
        then have A5: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 S)"
          using xboole_0_def_4 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 S"
          using A4 xboole_0_def_4 sorry
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A6: "[TARSKIK4 x,z ] inHIDDENR3 S"and A7: "[TARSKIK4 z,y ] inHIDDENR3 R"
          using A1 relat_1_def_8 sorry
        have A8: "z =HIDDENR1 y"
        proof-
          have "z <>HIDDENR2 y implies  False "
          proof(rule impI)
            assume "z <>HIDDENR2 y"
            then have " not [TARSKIK4 z,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
              using relat_1_def_10 sorry
            then have "[TARSKIK4 z,y ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"
              using A7 xboole_0_def_5 sorry
            thus " False "
              using A3 A6 relat_1_def_8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A9: "x =HIDDENR1 y"
          using A5 relat_1_def_10 sorry
        then have "x inHIDDENR3 domRELAT-1K1 R"
          using A7 A8 xtuple_0_def_12 sorry
        then have A10: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
          using A9 relat_1_def_10 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A5 A7 A8 relat_1_def_10 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
          using A10 xboole_0_def_4 sorry
      qed "sorry"
      thus "CLSYSRELK1 S c=RELAT-1R2 CLSYSRELK1 R"
         sorry
    qed
    assume A11: "R *RELAT-1K6 S =RELAT-1R1 S"
      and A12: "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1"
    have A13: "(R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 S =RELAT-1R1 {}XBOOLE-0K1"
      using A11 A12 sysrel_th_38 sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 S implies [TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A14: "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 S"
      then have A15: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 S)"
        using xboole_0_def_4 sorry
      then have A16: "x =HIDDENR1 y"
        using relat_1_def_10 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 S"
        using A14 xboole_0_def_4 sorry
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A17: "[TARSKIK4 x,z ] inHIDDENR3 R"and A18: "[TARSKIK4 z,y ] inHIDDENR3 S"
        using A11 relat_1_def_8 sorry
      have "x inHIDDENR3 domRELAT-1K1 R"
        using A17 xtuple_0_def_12 sorry
      then have A19: "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
        using A16 relat_1_def_10 sorry
      have "z =HIDDENR1 x"
      proof-
        have "z <>HIDDENR2 x implies  False "
        proof(rule impI)
          assume "z <>HIDDENR2 x"
          then have " not [TARSKIK4 x,z ] inHIDDENR3 idRELAT-1K7 (domRELAT-1K1 R)"
            using relat_1_def_10 sorry
          then have "[TARSKIK4 x,z ] inHIDDENR3 R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)"
            using A17 xboole_0_def_5 sorry
          thus " False "
            using A13 A18 relat_1_def_8 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A15 A17 relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 CLSYSRELK1 R"
        using A19 xboole_0_def_4 sorry
    qed "sorry"
    thus "CLSYSRELK1 S c=RELAT-1R2 CLSYSRELK1 R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sysrel_th_40:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds (((S *RELAT-1K6 R =RELAT-1R1 S & R *RELAT-1K6 (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R)) =RELAT-1R1 {}XBOOLE-0K1) & R *RELAT-1K6 S =RELAT-1R1 R) & S *RELAT-1K6 (S \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 S)) =RELAT-1R1 {}XBOOLE-0K1 implies CLSYSRELK1 S =RELAT-1R1 CLSYSRELK1 R) & (((R *RELAT-1K6 S =RELAT-1R1 S & (R \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 R))*RELAT-1K6 R =RELAT-1R1 {}XBOOLE-0K1) & S *RELAT-1K6 R =RELAT-1R1 R) & (S \\SUBSET-1K6 idRELAT-1K7 (domRELAT-1K1 S))*RELAT-1K6 S =RELAT-1R1 {}XBOOLE-0K1 implies CLSYSRELK1 S =RELAT-1R1 CLSYSRELK1 R)"
  using sysrel_th_39 sorry

end
