theory trees_2
  imports real_1 trees_1 orders_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z, a, b, c, X, X1, X2, Y, Z for "setHIDDENM2"
reserve W, W1, W2 for "TreeTREES-1M1"
reserve w, w9 for "ElementTREES-1M2-of W"
reserve f for "FunctionFUNCT-1M1"
reserve D, D9 for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve i, k, k1, k2, l, m, n for "NatNAT-1M1"
reserve v, v1, v2 for "FinSequenceFINSEQ-1M1"
reserve p, q, r, r1, r2 for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mtheorem trees_2_th_1:
" for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for v be FinSequenceFINSEQ-1M1 holds v1 is-a-prefix-ofTREES-1R2 v & v2 is-a-prefix-ofTREES-1R2 v implies (v1,v2)are-c=-comparableXBOOLE-0R3"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds p is-a-prefix-ofTREES-1R2 r implies (q is-a-prefix-ofTREES-1R2 r implies (p,q)are-c=-comparableXBOOLE-0R3)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
    assume "p is-a-prefix-ofTREES-1R2 r"
    then have A1: " ex p9 be FinSequenceFINSEQ-1M1 st r =FINSEQ-1R1 p ^FINSEQ-1K8 p9"
      using trees_1_th_1 sorry
    assume "q is-a-prefix-ofTREES-1R2 r"
    then have A2: " ex q9 be FinSequenceFINSEQ-1M1 st r =FINSEQ-1R1 q ^FINSEQ-1K8 q9"
      using trees_1_th_1 sorry
    have "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q or lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
       sorry
    then have Cut62: "( ex t be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 t =FINSEQ-1R1 q) or ( ex t be FinSequenceFINSEQ-1M1 st q ^FINSEQ-1K8 t =FINSEQ-1R1 p)"
      using A1 A2 finseq_1_th_47 sorry
    have "p is-a-prefix-ofTREES-1R2 q or q is-a-prefix-ofTREES-1R2 p"
    proof-
      show "p is-a-prefix-ofTREES-1R2 q or q is-a-prefix-ofTREES-1R2 p"
        using trees_1_th_1 Cut62 sorry
    qed
    thus "(p,q)are-c=-comparableXBOOLE-0R3"
      using xboole_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_2:
" for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for v be FinSequenceFINSEQ-1M1 holds v1 is-a-proper-prefix-ofTREES-1R3 v & v2 is-a-prefix-ofTREES-1R2 v implies (v1,v2)are-c=-comparableXBOOLE-0R3"
  using trees_2_th_1 sorry

mtheorem trees_2_th_3:
" for k be NatNAT-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 v1 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies ( ex v2 be FinSequenceFINSEQ-1M1 st  ex x be setHIDDENM2 st v1 =FINSEQ-1R1 v2 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) & lenFINSEQ-1K4 v2 =XBOOLE-0R4 k)"
proof-
  have " for k be NatNAT-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 v1 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies ( ex tVar1 be FinSequenceFINSEQ-1M1 st  ex tVar2 be setHIDDENM2 st v1 =FINSEQ-1R1 tVar1 ^FINSEQ-1K8 (<*FINSEQ-1K10 tVar2*>) & lenFINSEQ-1K4 tVar1 =XBOOLE-0R4 k)"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix v1 assume [ty]: "v1 be FinSequenceFINSEQ-1M1"
    assume A1: "lenFINSEQ-1K4 v1 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
    obtain v2 where 
      [ty]:"v2 be FinSequenceFINSEQ-1M1" and v2Def:"v2 = v1  |RELAT-1K8 SegFINSEQ-1K2 k"
      using finseq_1_th_15 sorry
    have "v2 is-a-prefix-ofTREES-1R2 v1"
       sorry
    then obtain v where
      [ty]:"v be FinSequenceFINSEQ-1M1" and 
      A2: "v1 =FINSEQ-1R1 v2 ^FINSEQ-1K8 v"
      using trees_1_th_1 sorry
    show " ex tVar1 be FinSequenceFINSEQ-1M1 st  ex tVar2 be setHIDDENM2 st v1 =FINSEQ-1R1 tVar1 ^FINSEQ-1K8 (<*FINSEQ-1K10 tVar2*>) & lenFINSEQ-1K4 tVar1 =XBOOLE-0R4 k"
    proof(rule bexI[of _ "v2"])
      show " ex tVar2 be setHIDDENM2 st v1 =FINSEQ-1R1 v2 ^FINSEQ-1K8 (<*FINSEQ-1K10 tVar2*>) & lenFINSEQ-1K4 v2 =XBOOLE-0R4 k"
      proof(rule bexI[of _ "v .FUNCT-1K1 \<one>\<^sub>M"])
        have A3: "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have "lenFINSEQ-1K4 v2 =XBOOLE-0R4 k"
          using A1 finseq_1_th_17 sorry
        then have "k +NAT-1K1 lenFINSEQ-1K4 v =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using A1 A2 finseq_1_th_22 sorry
        thus "v1 =FINSEQ-1R1 v2 ^FINSEQ-1K8 (<*FINSEQ-1K10 v .FUNCT-1K1 \<one>\<^sub>M*>) & lenFINSEQ-1K4 v2 =XBOOLE-0R4 k"
          using A1 A2 A3 finseq_1_th_17 finseq_1_th_40 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_4:
" for x be setHIDDENM2 holds  for v be FinSequenceFINSEQ-1M1 holds ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
proof-
  have " for x be setHIDDENM2 holds  for v be FinSequenceFINSEQ-1M1 holds ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M1"
    have "ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) c=TARSKIR1 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v} & ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v} c=TARSKIR1 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
    proof(rule conjMI)
      show "ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) c=TARSKIR1 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) implies y inHIDDENR3 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
          then obtain v1 where
            [ty]:"v1 be FinSequenceFINSEQ-1M1" and 
            A1: "y =HIDDENR1 v1"and A2: "v1 is-a-proper-prefix-ofTREES-1R3 v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
            using trees_1_def_2 sorry
          have "v1 is-a-prefix-ofTREES-1R2 v & v1 <>HIDDENR2 v or v1 =FINSEQ-1R1 v"
            using A2 trees_1_th_9 sorry
          then have "v1 is-a-proper-prefix-ofTREES-1R3 v or v1 inTARSKIR2 {TARSKIK1 v}"
            using tarski_def_1 sorry
          then have "y inHIDDENR3 ProperPrefixesTREES-1K1 v or y inHIDDENR3 {TARSKIK1 v}"
            using A1 trees_1_def_2 sorry
          thus "y inHIDDENR3 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) c=TARSKIR1 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v} implies y inHIDDENR3 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
        then have A3: "y inHIDDENR3 ProperPrefixesTREES-1K1 v or y inHIDDENR3 {TARSKIK1 v}"
          using xboole_0_def_3 sorry
        have A4: "y inHIDDENR3 ProperPrefixesTREES-1K1 v implies y inHIDDENR3 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
        proof(rule impI)
          assume "y inHIDDENR3 ProperPrefixesTREES-1K1 v"
          then obtain v1 where
            [ty]:"v1 be FinSequenceFINSEQ-1M1" and 
            A5: "y =HIDDENR1 v1"and A6: "v1 is-a-proper-prefix-ofTREES-1R3 v"
            using trees_1_def_2 sorry
          have "v is-a-prefix-ofTREES-1R2 v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
            using trees_1_th_1 sorry
          then have "v1 is-a-proper-prefix-ofTREES-1R3 v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
            using A6 xboole_1_th_58 sorry
          thus "y inHIDDENR3 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
            using A5 trees_1_def_2 sorry
        qed
        have "v ^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 v"
          using finseq_1_th_34 sorry
        then have "v is-a-prefix-ofTREES-1R2 v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) & v <>HIDDENR2 v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
          using finseq_1_th_33 trees_1_th_1 sorry
        then have "v is-a-proper-prefix-ofTREES-1R3 v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
           sorry
        then have "y inHIDDENR3 ProperPrefixesTREES-1K1 v or y =HIDDENR1 v & v inTARSKIR2 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
          using A3 tarski_def_1 trees_1_def_2 sorry
        thus "y inHIDDENR3 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
          using A4 sorry
      qed "sorry"
      thus "ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v} c=TARSKIR1 ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
        using tarski_def_3 sorry
    qed
    thus "ProperPrefixesTREES-1K1 (v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 ProperPrefixesTREES-1K1 v \\/XBOOLE-0K2 {TARSKIK1 v}"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem trees_2_sch_1:
  fixes Tf0 Pp1 
  assumes
[ty]: "Tf0 be TreeTREES-1M1" and
   A1: "Pp1({}XBOOLE-0K1)" and
   A2: " for t be ElementTREES-1M2-of Tf0 holds  for n be NatNAT-1M1 holds Pp1(t) & t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Tf0 implies Pp1(t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))"
  shows " for t be ElementTREES-1M2-of Tf0 holds Pp1(t)"
  proof(rule ballI)
    let ?X = "\<lambda>Lamb1.  for t be ElementTREES-1M2-of Tf0 holds lenFINSEQ-1K4 t =XBOOLE-0R4 Lamb1 implies Pp1(t)"
    have " for x be setHIDDENM2 holds cardCARD-1K1 x =XBOOLE-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    then have A3: "?X(0NUMBERSK6)"
      using A1 sorry
    have A4: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( for t be ElementTREES-1M2-of Tf0 holds lenFINSEQ-1K4 t =XBOOLE-0R4 k implies Pp1(t)) implies ( for t be ElementTREES-1M2-of Tf0 holds lenFINSEQ-1K4 t =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies Pp1(t))"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A5: " for t be ElementTREES-1M2-of Tf0 holds lenFINSEQ-1K4 t =XBOOLE-0R4 k implies Pp1(t)"
        fix t assume [ty]: "t be ElementTREES-1M2-of Tf0"
        assume "lenFINSEQ-1K4 t =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
        then obtain v x where
          [ty]:"v be FinSequenceFINSEQ-1M1" "x be setHIDDENM2" and 
          A6: "t =FINSEQ-1R1 v ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"and A7: "lenFINSEQ-1K4 v =XBOOLE-0R4 k"
          using trees_2_th_3 sorry
        have 
          [ty]:"v be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          using A6 finseq_1_th_36 sorry
        have 
          [ty]:"v be ElementTREES-1M2-of Tf0"
          using A6 trees_1_th_21 sorry
        have "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) c=TARSKIR1 rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> t"
          using A6 finseq_1_th_30 sorry
        then have "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 x} & rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) c=TARSKIR1 NATNUMBERSK1"
          using finseq_1_th_39 xboole_1_th_1 sorry
        then have 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
          using zfmisc_1_th_31 sorry
        have A8: "Pp1(v)"
          using A5 A7 sorry
        have "x =XBOOLE-0R4 x"
           sorry
        thus "Pp1(t)"
          using A2 A6 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: " for k be NatNAT-1M1 holds ?X(k)"
      using nat_1_sch_2 A3 A4 sorry
    fix t assume [ty]: "t be ElementTREES-1M2-of Tf0"
    have "lenFINSEQ-1K4 t =XBOOLE-0R4 lenFINSEQ-1K4 t"
       sorry
    thus "Pp1(t)"
      using A9 sorry
  qed "sorry"

mtheorem trees_2_th_5:
" for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W1 iff p inTARSKIR2 W2) implies W1 =XBOOLE-0R4 W2"
proof-
  have " for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W1 iff p inTARSKIR2 W2) implies W1 =XBOOLE-0R4 W2"
  proof(rule ballI,rule ballI,rule impI)
    fix W1 assume [ty]: "W1 be TreeTREES-1M1"
    fix W2 assume [ty]: "W2 be TreeTREES-1M1"
    assume A1: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W1 iff p inTARSKIR2 W2"
    have "W1 c=TARSKIR1 W2 & W2 c=TARSKIR1 W1"
    proof(rule conjMI)
      show "W1 c=TARSKIR1 W2"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 W1 implies x inHIDDENR3 W2"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 W1"
          then obtain p where 
            [ty]:"p be ElementTREES-1M2-of W1" and pDef:"p = x"
             sorry
          have "p inTARSKIR2 W2"
            using A1 sorry
          thus "x inHIDDENR3 W2"
             sorry
        qed "sorry"
        thus "W1 c=TARSKIR1 W2"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 W2 implies x inHIDDENR3 W1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 W2"
        then obtain p where 
          [ty]:"p be ElementTREES-1M2-of W2" and pDef:"p = x"
           sorry
        have "p inTARSKIR2 W1"
          using A1 sorry
        thus "x inHIDDENR3 W1"
           sorry
      qed "sorry"
      thus "W2 c=TARSKIR1 W1"
        using tarski_def_3 sorry
    qed
    thus "W1 =XBOOLE-0R4 W2"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) TREES_2R1(" _ =TREES-2R1  _ " [50,50]50) where
  "W1 =TREES-2R1 W2 \<equiv> W1 =HIDDENR1 W2"

mtheorem trees_2_def_1:
  mlet "W1 be TreeTREES-1M1", "W2 be TreeTREES-1M1"
"redefine pred W1 =TREES-2R1 W2 means
   for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W1 iff p inTARSKIR2 W2"
proof
(*compatibility*)
  show "W1 =TREES-2R1 W2 iff ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W1 iff p inTARSKIR2 W2)"
    using trees_2_th_5 sorry
qed "sorry"

mtheorem trees_2_th_6:
" for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W implies W =TREES-2R1 W with-replacementTREES-1K5(p,W  |TREES-1K4 p)"
proof-
  have " for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W implies W =TREES-2R1 W with-replacementTREES-1K5(p,W  |TREES-1K4 p)"
  proof(rule ballI,rule ballI,rule impI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A1: "p inTARSKIR2 W"
    have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 W implies q inTARSKIR2 W with-replacementTREES-1K5(p,W  |TREES-1K4 p)) & (q inTARSKIR2 W with-replacementTREES-1K5(p,W  |TREES-1K4 p) &  not q inTARSKIR2 W implies  False )"
    proof(rule ballI,rule conjMI,rule impMI ,rule impI)
      fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      show "q inTARSKIR2 W implies q inTARSKIR2 W with-replacementTREES-1K5(p,W  |TREES-1K4 p)"
      proof(rule impI)
        assume A2: "q inTARSKIR2 W"
        have "p is-a-proper-prefix-ofTREES-1R3 q implies ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 W  |TREES-1K4 p & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
        proof(rule impI)
          assume "p is-a-proper-prefix-ofTREES-1R3 q"
          then have "p is-a-prefix-ofTREES-1R2 q"
             sorry
          then obtain r where
            [ty]:"r be FinSequenceFINSEQ-1M1" and 
            A3: "q =FINSEQ-1R1 p ^FINSEQ-1K8 r"
            using trees_1_th_1 sorry
          have "rngFUNCT-1K2 r c=TARSKIR1 rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> q"
            using A3 finseq_1_th_30 sorry
          then have "rngFUNCT-1K2 r c=TARSKIR1 NATNUMBERSK1"
            using xboole_1_th_1 sorry
          then have 
            [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            using finseq_1_def_4 sorry
          show " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 W  |TREES-1K4 p & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
          proof(rule bexI[of _ "r"])
            show "r inTARSKIR2 W  |TREES-1K4 p & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
              using A1 A2 A3 trees_1_def_6 sorry
          qed "sorry"
        qed
        thus "q inTARSKIR2 W with-replacementTREES-1K5(p,W  |TREES-1K4 p)"
          using A1 A2 trees_1_def_9 sorry
      qed
      assume A4: "q inTARSKIR2 W with-replacementTREES-1K5(p,W  |TREES-1K4 p)"
        and A5: " not q inTARSKIR2 W"
      have " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 W  |TREES-1K4 p & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
        using A1 A4 A5 trees_1_def_9 sorry
      thus " False "
        using A1 A5 trees_1_def_6 sorry
    qed "sorry"
    thus "W =TREES-2R1 W with-replacementTREES-1K5(p,W  |TREES-1K4 p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_7:
" for W be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 W & q inTARSKIR2 W) &  not p is-a-prefix-ofTREES-1R2 q implies q inTARSKIR2 W with-replacementTREES-1K5(p,W1)"
proof-
  have " for W be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (((p inTARSKIR2 W & q inTARSKIR2 W) &  not p is-a-prefix-ofTREES-1R2 q) &  not q inTARSKIR2 W with-replacementTREES-1K5(p,W1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix W1 assume [ty]: "W1 be TreeTREES-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    have " not p is-a-prefix-ofTREES-1R2 q implies  not p is-a-proper-prefix-ofTREES-1R3 q"
       sorry
    thus " not (((p inTARSKIR2 W & q inTARSKIR2 W) &  not p is-a-prefix-ofTREES-1R2 q) &  not q inTARSKIR2 W with-replacementTREES-1K5(p,W1))"
      using trees_1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_8:
" for W be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 W & q inTARSKIR2 W) &  not (p,q)are-c=-comparableXBOOLE-0R3 implies (W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2) =TREES-2R1 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1)"
proof-
  have " for W be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 W & (q inTARSKIR2 W &  not (p,q)are-c=-comparableXBOOLE-0R3) implies (W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2) =TREES-2R1 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix W1 assume [ty]: "W1 be TreeTREES-1M1"
    fix W2 assume [ty]: "W2 be TreeTREES-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A1: "p inTARSKIR2 W"
      and A2: "q inTARSKIR2 W"
      and A3: " not (p,q)are-c=-comparableXBOOLE-0R3"
    have A4: " not p is-a-prefix-ofTREES-1R2 q"
      using A3 sorry
    have " not q is-a-prefix-ofTREES-1R2 p"
      using A3 sorry
    then have A5: "p inTARSKIR2 W with-replacementTREES-1K5(q,W2)"
      using A1 A2 trees_2_th_7 sorry
    have A6: "q inTARSKIR2 W with-replacementTREES-1K5(p,W1)"
      using A1 A2 A4 trees_2_th_7 sorry
    have " for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (r inTARSKIR2 (W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2) implies r inTARSKIR2 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1)) & (r inTARSKIR2 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1) implies r inTARSKIR2 (W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2))"
    proof(rule ballI,rule conjMI,rule impI)
      fix r assume [ty]: "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      show "r inTARSKIR2 (W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2) implies r inTARSKIR2 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1)"
      proof(rule impI)
        assume "r inTARSKIR2 (W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2)"
        then have "r inTARSKIR2 W with-replacementTREES-1K5(p,W1) &  not q is-a-proper-prefix-ofTREES-1R3 r or ( ex r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r1 inTARSKIR2 W2 & r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1)"
          using A6 trees_1_def_9 sorry
        then have "((r inTARSKIR2 W &  not p is-a-proper-prefix-ofTREES-1R3 r) &  not q is-a-proper-prefix-ofTREES-1R3 r or ( ex r2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r2 inTARSKIR2 W1 & r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r2) &  not q is-a-proper-prefix-ofTREES-1R3 r) or q is-a-prefix-ofTREES-1R2 r & ( ex r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r1 inTARSKIR2 W2 & r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1)"
          using A1 trees_1_th_1 trees_1_def_9 sorry
        then have "r inTARSKIR2 W with-replacementTREES-1K5(q,W2) &  not p is-a-proper-prefix-ofTREES-1R3 r or ( ex r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r1 inTARSKIR2 W1 & r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1)"
          using A2 A3 trees_2_th_2 trees_1_def_9 sorry
        thus "r inTARSKIR2 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1)"
          using A5 trees_1_def_9 sorry
      qed
      assume "r inTARSKIR2 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1)"
      then have "r inTARSKIR2 W with-replacementTREES-1K5(q,W2) &  not p is-a-proper-prefix-ofTREES-1R3 r or ( ex r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r1 inTARSKIR2 W1 & r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1)"
        using A5 trees_1_def_9 sorry
      then have "((r inTARSKIR2 W &  not q is-a-proper-prefix-ofTREES-1R3 r) &  not p is-a-proper-prefix-ofTREES-1R3 r or ( ex r2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r2 inTARSKIR2 W2 & r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r2) &  not p is-a-proper-prefix-ofTREES-1R3 r) or p is-a-prefix-ofTREES-1R2 r & ( ex r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r1 inTARSKIR2 W1 & r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1)"
        using A2 trees_1_th_1 trees_1_def_9 sorry
      then have "r inTARSKIR2 W with-replacementTREES-1K5(p,W1) &  not q is-a-proper-prefix-ofTREES-1R3 r or ( ex r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r1 inTARSKIR2 W2 & r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1)"
        using A1 A3 trees_2_th_2 trees_1_def_9 sorry
      thus "r inTARSKIR2 (W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2)"
        using A6 trees_1_def_9 sorry
    qed "sorry"
    thus "(W with-replacementTREES-1K5(p,W1))with-replacementTREES-1K5(q,W2) =TREES-2R1 (W with-replacementTREES-1K5(q,W2))with-replacementTREES-1K5(p,W1)"
      using trees_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_2_def_2 ("finite-orderTREES-2V1" 70 ) where
"attr finite-orderTREES-2V1 for TreeTREES-1M1 means
  (\<lambda>IT.  ex n be NatNAT-1M1 st  for t be ElementTREES-1M2-of IT holds  not t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 IT)"..

mtheorem trees_2_cl_1:
"cluster finite-orderTREES-2V1 for TreeTREES-1M1"
proof
(*existence*)
  show " ex it be TreeTREES-1M1 st it be finite-orderTREES-2V1"
  proof-
    have " ex tVar4 be TreeTREES-1M1 st tVar4 be finite-orderTREES-2V1"
    proof-
      obtain T where 
        [ty]:"T be TreeTREES-1M1" and TDef:"T = {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      show " ex tVar4 be TreeTREES-1M1 st tVar4 be finite-orderTREES-2V1"
      proof(rule bexI[of _ "T"])
        have " for t be ElementTREES-1M2-of T holds  not t ^FINSEQ-1K8 (<*FINSEQ-1K10 0NUMBERSK6 *>) inTARSKIR2 T"
        proof(rule ballI)
          fix t assume [ty]: "t be ElementTREES-1M2-of T"
          show " not t ^FINSEQ-1K8 (<*FINSEQ-1K10 0NUMBERSK6 *>) inTARSKIR2 T"
            using tarski_def_1 sorry
        qed "sorry"
        thus "T be finite-orderTREES-2V1"
          using bexI[of _ "0NUMBERSK6"] trees_2_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef trees_2_def_3 ("ChainTREES-2M1-of  _ " [70]70 ) where
  mlet "W be TreeTREES-1M1"
"mode ChainTREES-2M1-of W \<rightarrow> SubsetSUBSET-1M2-of W means
  (\<lambda>it.  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 it & q inTARSKIR2 it implies (p,q)are-c=-comparableXBOOLE-0R3)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of W st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 it & q inTARSKIR2 it implies (p,q)are-c=-comparableXBOOLE-0R3"
    proof-
      have " ex tVar6 be SubsetSUBSET-1M2-of W st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((p inTARSKIR2 tVar6 & q inTARSKIR2 tVar6) &  not (p,q)are-c=-comparableXBOOLE-0R3)"
      proof-
        obtain S where 
          [ty]:"S be SubsetSUBSET-1M2-of W" and SDef:"S = {}XBOOLE-0K1"
          using xboole_1_th_2 sorry
        show " ex tVar6 be SubsetSUBSET-1M2-of W st  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((p inTARSKIR2 tVar6 & q inTARSKIR2 tVar6) &  not (p,q)are-c=-comparableXBOOLE-0R3)"
        proof(rule bexI[of _ "S"],rule ballI,rule ballI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          show " not ((p inTARSKIR2 S & q inTARSKIR2 S) &  not (p,q)are-c=-comparableXBOOLE-0R3)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef trees_2_def_4 ("LevelTREES-2M2-of  _ " [70]70 ) where
  mlet "W be TreeTREES-1M1"
"mode LevelTREES-2M2-of W \<rightarrow> SubsetSUBSET-1M2-of W means
  (\<lambda>it.  ex n be NatNAT-1M1 st it =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n })"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of W st  ex n be NatNAT-1M1 st it =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
    proof-
      have " ex tVar7 be SubsetSUBSET-1M2-of W st  ex tVar8 be NatNAT-1M1 st tVar7 =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 tVar8 }"
      proof-
        have "{}XBOOLE-0K1 inTARSKIR2 W"
          using trees_1_th_22 sorry
        then obtain L where 
          [ty]:"L be SubsetSUBSET-1M2-of W" and LDef:"L = {TARSKIK1 {}XBOOLE-0K1 }"
          using zfmisc_1_th_31 sorry
        show " ex tVar7 be SubsetSUBSET-1M2-of W st  ex tVar8 be NatNAT-1M1 st tVar7 =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 tVar8 }"
        proof(rule bexI[of _ "L"])
          show " ex tVar8 be NatNAT-1M1 st L =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 tVar8 }"
          proof(rule bexI[of _ "0NUMBERSK6"])
            have "L c=TARSKIR1 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 } & {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 } c=TARSKIR1 L"
            proof(rule conjMI)
              show "L c=TARSKIR1 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 }"
              proof-
                have "L c=TARSKIR1 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 }"
                proof-
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 L implies x inHIDDENR3 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 }"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume A1: "x inHIDDENR3 L"
                    then have A2: "x =HIDDENR1 {}XBOOLE-0K1"
                      using tarski_def_1 sorry
                    have "lenFINSEQ-1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 0NUMBERSK6"
                       sorry
                    thus "x inHIDDENR3 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 }"
                      using A1 A2 sorry
                  qed "sorry"
                  thus "L c=TARSKIR1 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 }"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have " for x be objectHIDDENM1 holds x inHIDDENR3 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 } implies x inHIDDENR3 L"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 }"
                then have " ex w be ElementTREES-1M2-of W st x =HIDDENR1 w & lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6"
                   sorry
                then have "x =HIDDENR1 {}XBOOLE-0K1"
                   sorry
                thus "x inHIDDENR3 L"
                  using tarski_def_1 sorry
              qed "sorry"
              thus "{w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 } c=TARSKIR1 L"
                using tarski_def_3 sorry
            qed
            thus "L =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 0NUMBERSK6 }"
              using xboole_0_def_10 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef trees_2_def_5 ("succTREES-2K1\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "W be TreeTREES-1M1", "w be ElementTREES-1M2-of W"
"func succTREES-2K1\<^bsub>(W)\<^esub> w \<rightarrow> SubsetSUBSET-1M2-of W equals
  {w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W }"
proof-
  (*coherence*)
    show "{w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W } be SubsetSUBSET-1M2-of W"
    proof-
      have "{w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W } be SubsetSUBSET-1M2-of W"
      proof-
        have "{w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W } c=TARSKIR1 W"
        proof-
          have "{w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W } c=TARSKIR1 W"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W } implies x inHIDDENR3 W"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 {w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W }"
              then have " ex n be NatNAT-1M1 st x =HIDDENR1 w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W"
                 sorry
              thus "x inHIDDENR3 W"
                 sorry
            qed "sorry"
            thus "{w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W } c=TARSKIR1 W"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "{w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1 : w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W } be SubsetSUBSET-1M2-of W"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_2_th_9:
" for W be TreeTREES-1M1 holds  for L be LevelTREES-2M2-of W holds L be AntiChain-of-PrefixesTREES-1M6-of W"
proof-
  have " for W be TreeTREES-1M1 holds  for L be LevelTREES-2M2-of W holds L be AntiChain-of-PrefixesTREES-1M6-of W"
  proof(rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix L assume [ty]: "L be LevelTREES-2M2-of W"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "L =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
      using trees_2_def_4 sorry
    have "L be AntiChain-of-Prefixes-likeTREES-1V2"
    proof-
      have "( for x be setHIDDENM2 holds x inTARSKIR2 L implies x be FinSequenceFINSEQ-1M1) & ( for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds v1 inTARSKIR2 L implies (v2 inTARSKIR2 L implies  not ( not v1 =HIDDENR1 v2 & (v1,v2)are-c=-comparableXBOOLE-0R3)))"
      proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
        show " for x be setHIDDENM2 holds x inTARSKIR2 L implies x be FinSequenceFINSEQ-1M1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          assume "x inTARSKIR2 L"
          then have "x be ElementTREES-1M2-of W"
             sorry
          thus "x be FinSequenceFINSEQ-1M1"
             sorry
        qed "sorry"
        fix v1 assume [ty]: "v1 be FinSequenceFINSEQ-1M1"
        fix v2 assume [ty]: "v2 be FinSequenceFINSEQ-1M1"
        assume "v1 inTARSKIR2 L"
        then have A2: " ex w1 be ElementTREES-1M2-of W st v1 =FINSEQ-1R1 w1 & lenFINSEQ-1K4 w1 =XBOOLE-0R4 n"
          using A1 sorry
        assume "v2 inTARSKIR2 L"
        then have " ex w2 be ElementTREES-1M2-of W st v2 =FINSEQ-1R1 w2 & lenFINSEQ-1K4 w2 =XBOOLE-0R4 n"
          using A1 sorry
        thus " not ( not v1 =HIDDENR1 v2 & (v1,v2)are-c=-comparableXBOOLE-0R3)"
          using A2 trees_1_th_4 sorry
      qed "sorry"
      thus "L be AntiChain-of-Prefixes-likeTREES-1V2"
        using trees_1_def_10 sorry
    qed
    thus "L be AntiChain-of-PrefixesTREES-1M6-of W"
      using trees_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_10:
" for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds succTREES-2K1\<^bsub>(W)\<^esub> w be AntiChain-of-PrefixesTREES-1M6-of W"
proof-
  have " for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds succTREES-2K1\<^bsub>(W)\<^esub> w be AntiChain-of-PrefixesTREES-1M6-of W"
  proof(rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix w assume [ty]: "w be ElementTREES-1M2-of W"
    have "succTREES-2K1\<^bsub>(W)\<^esub> w be AntiChain-of-Prefixes-likeTREES-1V2"
    proof-
      have "( for x be setHIDDENM2 holds x inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w implies x be FinSequenceFINSEQ-1M1) & ( for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds v1 inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w implies (v2 inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w implies  not ( not v1 =HIDDENR1 v2 & (v1,v2)are-c=-comparableXBOOLE-0R3)))"
      proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
        show " for x be setHIDDENM2 holds x inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w implies x be FinSequenceFINSEQ-1M1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          assume "x inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w"
          then have " ex i be NatNAT-1M1 st x =XBOOLE-0R4 w ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) & w ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) inTARSKIR2 W"
             sorry
          thus "x be FinSequenceFINSEQ-1M1"
             sorry
        qed "sorry"
        fix v1 assume [ty]: "v1 be FinSequenceFINSEQ-1M1"
        fix v2 assume [ty]: "v2 be FinSequenceFINSEQ-1M1"
        assume "v1 inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w"
        then have A1: " ex k1 be NatNAT-1M1 st v1 =FINSEQ-1R1 w ^FINSEQ-1K8 (<*FINSEQ-1K10 k1*>) & w ^FINSEQ-1K8 (<*FINSEQ-1K10 k1*>) inTARSKIR2 W"
           sorry
        assume "v2 inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w"
        then have A2: " ex k2 be NatNAT-1M1 st v2 =FINSEQ-1R1 w ^FINSEQ-1K8 (<*FINSEQ-1K10 k2*>) & w ^FINSEQ-1K8 (<*FINSEQ-1K10 k2*>) inTARSKIR2 W"
           sorry
        have A3: "lenFINSEQ-1K4 v1 =XBOOLE-0R4 lenFINSEQ-1K4 w +NAT-1K1 \<one>\<^sub>M"
          using A1 finseq_2_th_16 sorry
        have "lenFINSEQ-1K4 v2 =XBOOLE-0R4 lenFINSEQ-1K4 w +NAT-1K1 \<one>\<^sub>M"
          using A2 finseq_2_th_16 sorry
        thus " not ( not v1 =HIDDENR1 v2 & (v1,v2)are-c=-comparableXBOOLE-0R3)"
          using A3 trees_1_th_4 sorry
      qed "sorry"
      thus "succTREES-2K1\<^bsub>(W)\<^esub> w be AntiChain-of-Prefixes-likeTREES-1V2"
        using trees_1_def_10 sorry
    qed
    thus "succTREES-2K1\<^bsub>(W)\<^esub> w be AntiChain-of-PrefixesTREES-1M6-of W"
      using trees_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_11:
" for W be TreeTREES-1M1 holds  for A be AntiChain-of-PrefixesTREES-1M6-of W holds  for C be ChainTREES-2M1-of W holds  ex w be ElementTREES-1M2-of W st A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 w}"
proof-
  have " for W be TreeTREES-1M1 holds  for A be AntiChain-of-PrefixesTREES-1M6-of W holds  for C be ChainTREES-2M1-of W holds  not ( for w be ElementTREES-1M2-of W holds  not A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 w})"
  proof(rule ballI,rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix A assume [ty]: "A be AntiChain-of-PrefixesTREES-1M6-of W"
    fix C assume [ty]: "C be ChainTREES-2M1-of W"
    have A1: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C & q inTARSKIR2 A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C implies p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q"
    proof(rule ballI,rule ballI,rule impI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      assume A2: "p inTARSKIR2 A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C & q inTARSKIR2 A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C"
      then have A3: "p inTARSKIR2 A & q inTARSKIR2 A"
        using xboole_0_def_4 sorry
      have "p inTARSKIR2 C & q inTARSKIR2 C"
        using A2 xboole_0_def_4 sorry
      then have "(p,q)are-c=-comparableXBOOLE-0R3"
        using trees_2_def_3 sorry
      thus "p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q"
        using A3 trees_1_def_10 sorry
    qed "sorry"
    let ?w = "the ElementTREES-1M2-of W"
    have " not ( for w be ElementTREES-1M2-of W holds  not A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 w})"
    proof-
      show " not ( for w be ElementTREES-1M2-of W holds  not A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 w})"
      proof-
        have cases: "A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C =XBOOLE-0R4 {}XBOOLE-0K1 or A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( for w be ElementTREES-1M2-of W holds  not A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 w})"
        proof(rule impI)
          assume "A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C =XBOOLE-0R4 {}XBOOLE-0K1"
          then have "A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 ?w}"
             sorry
          thus " not ( for w be ElementTREES-1M2-of W holds  not A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 w})"
             sorry
        qed
        have case2: "A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be ElementTREES-1M2-of W st A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 x})"
        proof(rule impI)
          assume A4: "A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C <>HIDDENR2 {}XBOOLE-0K1"
          let ?x = "the ElementSUBSET-1M1-of A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C"
          have "?x inTARSKIR2 C"
            using A4 xboole_0_def_4 sorry
          then obtain x where 
            [ty]:"x be ElementTREES-1M2-of W" and xDef:"x = ?x"
             sorry
          show " ex x be ElementTREES-1M2-of W st A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 x}"
          proof(rule bexI[of _ "x"])
            show "A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 x}"
            proof-
              have " for y be objectHIDDENM1 holds y inHIDDENR3 A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C implies y inHIDDENR3 {TARSKIK1 x}"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A5: "y inHIDDENR3 A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C"
                then have "y be ElementTREES-1M2-of W"
                   sorry
                then obtain y9 where 
                  [ty]:"y9 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and y9Def:"y9 = y"
                   sorry
                have "x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> y9"
                  using A1 A5 sorry
                thus "y inHIDDENR3 {TARSKIK1 x}"
                  using tarski_def_1 sorry
              qed "sorry"
              thus "A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 x}"
                using tarski_def_3 sorry
            qed
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( for w be ElementTREES-1M2-of W holds  not A /\\SUBSET-1K9\<^bsub>(W)\<^esub> C c=TARSKIR1 {TARSKIK1 w})"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_2_def_6 (" _ -levelTREES-2K2  _ " [164,164]164 ) where
  mlet "W be TreeTREES-1M1", "n be NatNAT-1M1"
"func W -levelTREES-2K2 n \<rightarrow> LevelTREES-2M2-of W equals
  {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
proof-
  (*coherence*)
    show "{w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n } be LevelTREES-2M2-of W"
    proof-
      have "{w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n } be LevelTREES-2M2-of W"
      proof-
        let ?X = "\<lambda>Lamb1. lenFINSEQ-1K4 Lamb1 =XBOOLE-0R4 n"
        have "{w where w be ElementTREES-1M2-of W : ?X(w) } be SubsetSUBSET-1M2-of W"
          using domain_1_sch_7 sorry
        thus "{w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n } be LevelTREES-2M2-of W"
          using trees_2_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_2_th_12:
" for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds  for n be NatNAT-1M1 holds w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 succTREES-2K1\<^bsub>(W)\<^esub> w iff w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W"
   sorry

mtheorem trees_2_th_13:
" for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds w =FINSEQ-1R1 {}XBOOLE-0K1 implies W -levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w"
proof-
  have " for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds w =FINSEQ-1R1 {}XBOOLE-0K1 implies W -levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w"
  proof(rule ballI,rule ballI,rule impI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix w assume [ty]: "w be ElementTREES-1M2-of W"
    assume A1: "w =FINSEQ-1R1 {}XBOOLE-0K1"
    have "W -levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 succTREES-2K1\<^bsub>(W)\<^esub> w & succTREES-2K1\<^bsub>(W)\<^esub> w c=TARSKIR1 W -levelTREES-2K2 \<one>\<^sub>M"
    proof(rule conjMI)
      show "W -levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 succTREES-2K1\<^bsub>(W)\<^esub> w"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 W -levelTREES-2K2 \<one>\<^sub>M implies x inHIDDENR3 succTREES-2K1\<^bsub>(W)\<^esub> w"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 W -levelTREES-2K2 \<one>\<^sub>M"
          then obtain w9 where
            [ty]:"w9 be ElementTREES-1M2-of W" and 
            A2: "x =HIDDENR1 w9"and A3: "lenFINSEQ-1K4 w9 =XBOOLE-0R4 \<one>\<^sub>M"
             sorry
          have A4: "w9 =FINSEQ-1R1 <*FINSEQ-1K10 w9 .FUNCT-1K1 \<one>\<^sub>M*>"
            using A3 finseq_1_th_40 sorry
          then have "rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> w9 =XBOOLE-0R4 {TARSKIK1 w9 .FUNCT-1K1 \<one>\<^sub>M }"
            using finseq_1_th_39 sorry
          then obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = w9 .FUNCT-1K1 \<one>\<^sub>M"
            using zfmisc_1_th_31 sorry
          have "w9 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> w ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
            using A1 A4 finseq_1_th_34 sorry
          thus "x inHIDDENR3 succTREES-2K1\<^bsub>(W)\<^esub> w"
            using A2 sorry
        qed "sorry"
        thus "W -levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 succTREES-2K1\<^bsub>(W)\<^esub> w"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(W)\<^esub> w implies x inHIDDENR3 W -levelTREES-2K2 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 succTREES-2K1\<^bsub>(W)\<^esub> w"
        then obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A5: "x =HIDDENR1 w ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>)"and A6: "w ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) inTARSKIR2 W"
           sorry
        obtain w9 where 
          [ty]:"w9 be ElementTREES-1M2-of W" and w9Def:"w9 = w ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>)"
          using A6 sorry
        have "lenFINSEQ-1K4 (<*FINSEQ-1K10 i*>) =XBOOLE-0R4 \<one>\<^sub>M & w9 =FINSEQ-1R1 <*FINSEQ-1K10 i*>"
          using A1 finseq_1_th_34 finseq_1_th_39 sorry
        thus "x inHIDDENR3 W -levelTREES-2K2 \<one>\<^sub>M"
          using A5 sorry
      qed "sorry"
      thus "succTREES-2K1\<^bsub>(W)\<^esub> w c=TARSKIR1 W -levelTREES-2K2 \<one>\<^sub>M"
        using tarski_def_3 sorry
    qed
    thus "W -levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_14:
" for W be TreeTREES-1M1 holds W =XBOOLE-0R4 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
proof-
  have " for W be TreeTREES-1M1 holds W =XBOOLE-0R4 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
  proof(rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    have "W c=TARSKIR1 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  }) & unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  }) c=TARSKIR1 W"
    proof(rule conjMI)
      show "W c=TARSKIR1 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
      proof-
        have "W c=TARSKIR1 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 W implies x inHIDDENR3 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 W"
            then obtain w where 
              [ty]:"w be ElementTREES-1M2-of W" and wDef:"w = x"
               sorry
            have A1: "x inHIDDENR3 W -levelTREES-2K2 lenFINSEQ-1K4 w"
               sorry
            have "W -levelTREES-2K2 lenFINSEQ-1K4 w inTARSKIR2 {W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  }"
               sorry
            thus "x inHIDDENR3 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
              using A1 tarski_def_4 sorry
          qed "sorry"
          thus "W c=TARSKIR1 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  }) implies x inHIDDENR3 W"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A2: "x inHIDDENR3 X & X inTARSKIR2 {W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  }"
          using tarski_def_4 sorry
        have " ex n be NatNAT-1M1 st X =XBOOLE-0R4 W -levelTREES-2K2 n"
          using A2 sorry
        thus "x inHIDDENR3 W"
          using A2 sorry
      qed "sorry"
      thus "unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  }) c=TARSKIR1 W"
        using tarski_def_3 sorry
    qed
    thus "W =XBOOLE-0R4 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_15:
" for W be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds W =XBOOLE-0R4 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
proof-
  have " for W be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds W =XBOOLE-0R4 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
  proof(rule ballI)
    fix W assume [ty]: "W be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    have "W c=TARSKIR1 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W }) & unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W }) c=TARSKIR1 W"
    proof(rule conjMI)
      show "W c=TARSKIR1 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
      proof-
        have "W c=TARSKIR1 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 W implies x inHIDDENR3 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 W"
            then obtain w where 
              [ty]:"w be ElementTREES-1M2-of W" and wDef:"w = x"
               sorry
            have A1: "lenFINSEQ-1K4 w <=XXREAL-0R1 heightTREES-1K6 W"
              using trees_1_def_12 sorry
            have A2: "w inTARSKIR2 W -levelTREES-2K2 lenFINSEQ-1K4 w"
               sorry
            have "W -levelTREES-2K2 lenFINSEQ-1K4 w inTARSKIR2 {W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W }"
              using A1 sorry
            thus "x inHIDDENR3 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
              using A2 tarski_def_4 sorry
          qed "sorry"
          thus "W c=TARSKIR1 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W }) implies x inHIDDENR3 W"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A3: "x inHIDDENR3 X & X inTARSKIR2 {W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W }"
          using tarski_def_4 sorry
        have " ex n be NatNAT-1M1 st X =XBOOLE-0R4 W -levelTREES-2K2 n & n <=XXREAL-0R1 heightTREES-1K6 W"
          using A3 sorry
        thus "x inHIDDENR3 W"
          using A3 sorry
      qed "sorry"
      thus "unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W }) c=TARSKIR1 W"
        using tarski_def_3 sorry
    qed
    thus "W =XBOOLE-0R4 unionTARSKIK3 ({W -levelTREES-2K2 n where n be NatNAT-1M1 : n <=XXREAL-0R1 heightTREES-1K6 W })"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_16:
" for W be TreeTREES-1M1 holds  for L be LevelTREES-2M2-of W holds  ex n be NatNAT-1M1 st L =XBOOLE-0R4 W -levelTREES-2K2 n"
proof-
  have " for W be TreeTREES-1M1 holds  for L be LevelTREES-2M2-of W holds  ex tVar10 be NatNAT-1M1 st L =XBOOLE-0R4 W -levelTREES-2K2 tVar10"
  proof(rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix L assume [ty]: "L be LevelTREES-2M2-of W"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "L =XBOOLE-0R4 {w where w be ElementTREES-1M2-of W : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
      using trees_2_def_4 sorry
    have 
      [ty]:"n be NatNAT-1M1"
       sorry
    show " ex tVar10 be NatNAT-1M1 st L =XBOOLE-0R4 W -levelTREES-2K2 tVar10"
    proof(rule bexI[of _ "n"])
      show "L =XBOOLE-0R4 W -levelTREES-2K2 n"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem trees_2_sch_2:
  fixes Af0 Xf0 Ff1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows "cardCARD-1K1 ({Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }) c=ORDINAL1R1 cardCARD-1K1 Xf0"
  proof-
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x))"
      using funct_1_sch_3 sorry
    have "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } implies x inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }"
        then obtain w where
          [ty]:"w be ElementSUBSET-1M1-of Af0" and 
          A2: "x =HIDDENR1 Ff1(w)"and A3: "w inTARSKIR2 Xf0"
           sorry
        have "f .FUNCT-1K1 w =HIDDENR1 x"
          using A1 A2 A3 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 f"
          using A1 A3 funct_1_def_3 sorry
      qed "sorry"
      thus "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    thus "cardCARD-1K1 ({Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }) c=ORDINAL1R1 cardCARD-1K1 Xf0"
      using A1 card_1_th_12 sorry
  qed

theorem trees_2_sch_3:
  fixes Af0 Xf0 Yf0 Ff1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Xf0 be finiteFINSET-1V1\<bar>setHIDDENM2" and
  [ty]: "Yf0 be finiteFINSET-1V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
   A1: "Yf0 =XBOOLE-0R4 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }"
  shows "cardCARD-1K4 Yf0 <=XXREAL-0R1 cardCARD-1K4 Xf0"
  proof-
    have "cardCARD-1K1 ({Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }) c=ORDINAL1R1 cardCARD-1K4 Xf0"
      using trees_2_sch_2 sorry
    then have "SegmCARD-1K5 cardCARD-1K4 Yf0 c=ORDINAL1R1 SegmCARD-1K5 cardCARD-1K4 Xf0"
      using A1 sorry
    thus "cardCARD-1K4 Yf0 <=XXREAL-0R1 cardCARD-1K4 Xf0"
      using nat_1_th_39 sorry
  qed

mtheorem trees_2_th_17:
" for W be TreeTREES-1M1 holds W be finite-orderTREES-2V1 implies ( ex n be NatNAT-1M1 st  for w be ElementTREES-1M2-of W holds  ex B be finiteFINSET-1V1\<bar>setHIDDENM2 st B =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 B <=XXREAL-0R1 n)"
proof-
  have " for W be TreeTREES-1M1 holds  not (W be finite-orderTREES-2V1 & ( for n be NatNAT-1M1 holds  not ( for w be ElementTREES-1M2-of W holds  not ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds  not (B =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 B <=XXREAL-0R1 n)))))"
  proof(rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    have "( ex n be NatNAT-1M1 st  for w be ElementTREES-1M2-of W holds  not w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W) implies ( ex tVar11 be NatNAT-1M1 st  for w be ElementTREES-1M2-of W holds  ex tVar12 be finiteFINSET-1V1\<bar>setHIDDENM2 st tVar12 =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 tVar12 <=XXREAL-0R1 tVar11)"
    proof(rule impI)
      assume Given: " ex n be NatNAT-1M1 st  for w be ElementTREES-1M2-of W holds  not w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A1: " for w be ElementTREES-1M2-of W holds  not w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W"
         sorry
      have A2: "SegFINSEQ-1K2 n be finiteFINSET-1V1"
         sorry
      show " ex tVar11 be NatNAT-1M1 st  for w be ElementTREES-1M2-of W holds  ex tVar12 be finiteFINSET-1V1\<bar>setHIDDENM2 st tVar12 =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 tVar12 <=XXREAL-0R1 tVar11"
      proof(rule bexI[of _ "n"],rule ballI)
        fix w assume [ty]: "w be ElementTREES-1M2-of W"
        let ?U = "\<lambda>Lamb1. w ^FINSEQ-1K8 (<*FINSEQ-1K10 Lamb1 -XCMPLX-0K6 \<one>\<^sub>M *>)"
        have A3: "{?U(r) where r be ElementSUBSET-1M1-of REALNUMBERSK2 : r inTARSKIR2 SegFINSEQ-1K2 n } be finiteFINSET-1V1"
          using fraenkel_sch_21 A2 sorry
        have A4: "succTREES-2K1\<^bsub>(W)\<^esub> w c=TARSKIR1 {w ^FINSEQ-1K8 (<*FINSEQ-1K10 r -XCMPLX-0K6 \<one>\<^sub>M *>) where r be ElementSUBSET-1M1-of REALNUMBERSK2 : r inTARSKIR2 SegFINSEQ-1K2 n }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(W)\<^esub> w implies x inHIDDENR3 {w ^FINSEQ-1K8 (<*FINSEQ-1K10 r -XCMPLX-0K6 \<one>\<^sub>M *>) where r be ElementSUBSET-1M1-of REALNUMBERSK2 : r inTARSKIR2 SegFINSEQ-1K2 n }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 succTREES-2K1\<^bsub>(W)\<^esub> w"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A5: "x =HIDDENR1 w ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)"and A6: "w ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 W"
               sorry
            have " not w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 W"
              using A1 sorry
            then have "k <XXREAL-0R3 n"
              using A6 trees_1_def_3 sorry
            then have A7: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
              using nat_1_th_13 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_11 sorry
            then have A8: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
              using A7 finseq_1_th_1 sorry
            have A9: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            have "(k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 k"
               sorry
            thus "x inHIDDENR3 {w ^FINSEQ-1K8 (<*FINSEQ-1K10 r -XCMPLX-0K6 \<one>\<^sub>M *>) where r be ElementSUBSET-1M1-of REALNUMBERSK2 : r inTARSKIR2 SegFINSEQ-1K2 n }"
              using A5 A8 A9 sorry
          qed "sorry"
          thus "succTREES-2K1\<^bsub>(W)\<^esub> w c=TARSKIR1 {w ^FINSEQ-1K8 (<*FINSEQ-1K10 r -XCMPLX-0K6 \<one>\<^sub>M *>) where r be ElementSUBSET-1M1-of REALNUMBERSK2 : r inTARSKIR2 SegFINSEQ-1K2 n }"
            using tarski_def_3 sorry
        qed
        then obtain B where 
          [ty]:"B be finiteFINSET-1V1\<bar>setHIDDENM2" and BDef:"B = succTREES-2K1\<^bsub>(W)\<^esub> w"
          using A3 sorry
        show " ex tVar12 be finiteFINSET-1V1\<bar>setHIDDENM2 st tVar12 =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 tVar12 <=XXREAL-0R1 n"
        proof(rule bexI[of _ "B"],rule conjMI)
          show "B =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w"
             sorry
          let ?C = "{?U(r) where r be ElementSUBSET-1M1-of REALNUMBERSK2 : r inTARSKIR2 SegFINSEQ-1K2 n }"
          have "?C be finiteFINSET-1V1"
            using fraenkel_sch_21 A2 sorry
          then obtain C where 
            [ty]:"C be finiteFINSET-1V1\<bar>setHIDDENM2" and CDef:"C = ?C"
             sorry
          have A10: "C =XBOOLE-0R4 {?U(r) where r be ElementSUBSET-1M1-of REALNUMBERSK2 : r inTARSKIR2 SegFINSEQ-1K2 n }"
             sorry
          have "cardCARD-1K4 C <=XXREAL-0R1 cardCARD-1K4 (SegFINSEQ-1K2 n)"
            using trees_2_sch_3 A10 sorry
          then have A11: "cardCARD-1K4 C <=XXREAL-0R1 n"
            using finseq_1_th_57 sorry
          have "cardCARD-1K4 B <=XXREAL-0R1 cardCARD-1K4 C"
            using A4 nat_1_th_43 sorry
          thus "cardCARD-1K4 B <=XXREAL-0R1 n"
            using A11 xxreal_0_th_2 sorry
        qed "sorry"
      qed "sorry"
    qed
    thus " not (W be finite-orderTREES-2V1 & ( for n be NatNAT-1M1 holds  not ( for w be ElementTREES-1M2-of W holds  not ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds  not (B =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 B <=XXREAL-0R1 n)))))"
      using trees_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_18:
" for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds W be finite-orderTREES-2V1 implies succTREES-2K1\<^bsub>(W)\<^esub> w be finiteFINSET-1V1"
proof-
  have " for W be TreeTREES-1M1 holds  for w be ElementTREES-1M2-of W holds W be finite-orderTREES-2V1 implies succTREES-2K1\<^bsub>(W)\<^esub> w be finiteFINSET-1V1"
  proof(rule ballI,rule ballI,rule impI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix w assume [ty]: "w be ElementTREES-1M2-of W"
    assume "W be finite-orderTREES-2V1"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: " for w be ElementTREES-1M2-of W holds  ex B be finiteFINSET-1V1\<bar>setHIDDENM2 st B =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 B <=XXREAL-0R1 n"
      using trees_2_th_17 sorry
    have " ex B be finiteFINSET-1V1\<bar>setHIDDENM2 st B =XBOOLE-0R4 succTREES-2K1\<^bsub>(W)\<^esub> w & cardCARD-1K4 B <=XXREAL-0R1 n"
      using A1 sorry
    thus "succTREES-2K1\<^bsub>(W)\<^esub> w be finiteFINSET-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_cl_2:
  mlet "W be finite-orderTREES-2V1\<bar>TreeTREES-1M1", "w be ElementTREES-1M2-of W"
"cluster succTREES-2K1\<^bsub>(W)\<^esub> w as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "succTREES-2K1\<^bsub>(W)\<^esub> w be finiteFINSET-1V1"
    using trees_2_th_18 sorry
qed "sorry"

mtheorem trees_2_th_19:
" for W be TreeTREES-1M1 holds {}XBOOLE-0K1 be ChainTREES-2M1-of W"
proof-
  have " for W be TreeTREES-1M1 holds {}XBOOLE-0K1 be ChainTREES-2M1-of W"
  proof(rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    obtain S where 
      [ty]:"S be SubsetSUBSET-1M2-of W" and SDef:"S = {}XBOOLE-0K1"
      using xboole_1_th_2 sorry
    have "S be ChainTREES-2M1-of W"
    proof-
      have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((p inTARSKIR2 S & q inTARSKIR2 S) &  not (p,q)are-c=-comparableXBOOLE-0R3)"
      proof(rule ballI,rule ballI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        show " not ((p inTARSKIR2 S & q inTARSKIR2 S) &  not (p,q)are-c=-comparableXBOOLE-0R3)"
           sorry
      qed "sorry"
      thus "S be ChainTREES-2M1-of W"
        using trees_2_def_3 sorry
    qed
    thus "{}XBOOLE-0K1 be ChainTREES-2M1-of W"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_20:
" for W be TreeTREES-1M1 holds {TARSKIK1 {}XBOOLE-0K1 } be ChainTREES-2M1-of W"
proof-
  have " for W be TreeTREES-1M1 holds {TARSKIK1 {}XBOOLE-0K1 } be ChainTREES-2M1-of W"
  proof(rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    have "{}XBOOLE-0K1 inTARSKIR2 W"
      using trees_1_th_22 sorry
    then obtain S where 
      [ty]:"S be SubsetSUBSET-1M2-of W" and SDef:"S = {TARSKIK1 {}XBOOLE-0K1 }"
      using zfmisc_1_th_31 sorry
    have "S be ChainTREES-2M1-of W"
    proof-
      have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 S & q inTARSKIR2 S implies (p,q)are-c=-comparableXBOOLE-0R3"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume A1: "p inTARSKIR2 S"
          and A2: "q inTARSKIR2 S"
        have "p =FINSEQ-1R1 {}XBOOLE-0K1"
          using A1 tarski_def_1 sorry
        thus "(p,q)are-c=-comparableXBOOLE-0R3"
          using A2 tarski_def_1 sorry
      qed "sorry"
      thus "S be ChainTREES-2M1-of W"
        using trees_2_def_3 sorry
    qed
    thus "{TARSKIK1 {}XBOOLE-0K1 } be ChainTREES-2M1-of W"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_cl_3:
  mlet "W be TreeTREES-1M1"
"cluster  non emptyXBOOLE-0V1 for ChainTREES-2M1-of W"
proof
(*existence*)
  show " ex it be ChainTREES-2M1-of W st it be  non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be ChainTREES-2M1-of W holds VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "{TARSKIK1 {}XBOOLE-0K1 } be ChainTREES-2M1-of W"
        using trees_2_th_20 sorry
      thus " not ( for VarFor1 be ChainTREES-2M1-of W holds VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef trees_2_def_7 ("Branch-likeTREES-2V2\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "W be TreeTREES-1M1"
"attr Branch-likeTREES-2V2\<^bsub>(W)\<^esub> for ChainTREES-2M1-of W means
  (\<lambda>IT. ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 IT implies ProperPrefixesTREES-1K1 p c=TARSKIR1 IT) &  not ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 W & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 IT implies q is-a-proper-prefix-ofTREES-1R3 p)))"..

mtheorem trees_2_cl_4:
  mlet "W be TreeTREES-1M1"
"cluster Branch-likeTREES-2V2\<^bsub>(W)\<^esub> for ChainTREES-2M1-of W"
proof
(*existence*)
  show " ex it be ChainTREES-2M1-of W st it be Branch-likeTREES-2V2\<^bsub>(W)\<^esub>"
  proof-
    have " ex tVar13 be ChainTREES-2M1-of W st tVar13 be Branch-likeTREES-2V2\<^bsub>(W)\<^esub>"
    proof-
      let ?X = "\<lambda>Lamb1. Lamb1 be ChainTREES-2M1-of W & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Lamb1 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 Lamb1)"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 X iff Y inTARSKIR2 boolZFMISC-1K1 W & ?X(Y)"
        using xfamily_sch_1 sorry
      have "{}XBOOLE-0K1 be ChainTREES-2M1-of W & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {}XBOOLE-0K1 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 {}XBOOLE-0K1)"
        using trees_2_th_19 sorry
      then have A2: "X <>HIDDENR2 {}XBOOLE-0K1"
        using A1 sorry
      have " for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 & (Z c=TARSKIR1 X & Z be c=-linearORDINAL1V6) implies unionTARSKIK3 Z inTARSKIR2 X"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume "Z <>HIDDENR2 {}XBOOLE-0K1"
          and A3: "Z c=TARSKIR1 X"
          and A4: "Z be c=-linearORDINAL1V6"
        have "unionTARSKIK3 Z c=TARSKIR1 W"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 Z implies x inHIDDENR3 W"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 unionTARSKIK3 Z"
            then obtain Y where
              [ty]:"Y be setHIDDENM2" and 
              A5: "x inHIDDENR3 Y"and A6: "Y inTARSKIR2 Z"
              using tarski_def_4 sorry
            have "Y inTARSKIR2 boolZFMISC-1K1 W"
              using A1 A3 A6 sorry
            thus "x inHIDDENR3 W"
              using A5 sorry
          qed "sorry"
          thus "unionTARSKIK3 Z c=TARSKIR1 W"
            using tarski_def_3 sorry
        qed
        then obtain Z9 where 
          [ty]:"Z9 be SubsetSUBSET-1M2-of W" and Z9Def:"Z9 = unionTARSKIK3 Z"
           sorry
        have A7: "Z9 be ChainTREES-2M1-of W"
        proof-
          have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Z9 implies (q inTARSKIR2 Z9 implies (p,q)are-c=-comparableXBOOLE-0R3)"
          proof(rule ballI,rule ballI,rule impI,rule impI)
            fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume "p inTARSKIR2 Z9"
            then obtain X1 where
              [ty]:"X1 be setHIDDENM2" and 
              A8: "p inTARSKIR2 X1"and A9: "X1 inTARSKIR2 Z"
              using tarski_def_4 sorry
            assume "q inTARSKIR2 Z9"
            then obtain X2 where
              [ty]:"X2 be setHIDDENM2" and 
              A10: "q inTARSKIR2 X2"and A11: "X2 inTARSKIR2 Z"
              using tarski_def_4 sorry
            have "(X1,X2)are-c=-comparableXBOOLE-0R3"
              using A4 A9 A11 sorry
            then have A12: "X1 c=TARSKIR1 X2 or X2 c=TARSKIR1 X1"
               sorry
            have A13: "X1 be ChainTREES-2M1-of W"
              using A1 A3 A9 sorry
            have "X2 be ChainTREES-2M1-of W"
              using A1 A3 A11 sorry
            thus "(p,q)are-c=-comparableXBOOLE-0R3"
              using A8 A10 A12 A13 trees_2_def_3 sorry
          qed "sorry"
          thus "Z9 be ChainTREES-2M1-of W"
            using trees_2_def_3 sorry
        qed
        have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 unionTARSKIK3 Z implies ProperPrefixesTREES-1K1 p c=TARSKIR1 unionTARSKIK3 Z"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume "p inTARSKIR2 unionTARSKIK3 Z"
          then obtain X1 where
            [ty]:"X1 be setHIDDENM2" and 
            A14: "p inTARSKIR2 X1 & X1 inTARSKIR2 Z"
            using tarski_def_4 sorry
          have "ProperPrefixesTREES-1K1 p c=TARSKIR1 X1 & X1 c=TARSKIR1 unionTARSKIK3 Z"
            using A1 A3 A14 zfmisc_1_th_74 sorry
          thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 unionTARSKIK3 Z"
             sorry
        qed "sorry"
        thus "unionTARSKIK3 Z inTARSKIR2 X"
          using A1 A7 sorry
      qed "sorry"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A15: "Y inTARSKIR2 X"and A16: " for Z be setHIDDENM2 holds Z inTARSKIR2 X & Z <>HIDDENR2 Y implies  not Y c=TARSKIR1 Z"
        using A2 orders_1_th_67 sorry
      have 
        [ty]:"Y be ChainTREES-2M1-of W"
        using A1 A15 sorry
      show " ex tVar13 be ChainTREES-2M1-of W st tVar13 be Branch-likeTREES-2V2\<^bsub>(W)\<^esub>"
      proof(rule bexI[of _ "Y"])
        have "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Y implies ProperPrefixesTREES-1K1 p c=TARSKIR1 Y) & (( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 W & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 Y implies q is-a-proper-prefix-ofTREES-1R3 p)) implies  not  True )"
        proof(rule conjMI,rule impI)
          show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Y implies ProperPrefixesTREES-1K1 p c=TARSKIR1 Y"
            using A1 A15 sorry
          assume Given: " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 W & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 Y implies q is-a-proper-prefix-ofTREES-1R3 p)"
          then obtain p where
            [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
            A17: "p inTARSKIR2 W"and A18: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 Y implies q is-a-proper-prefix-ofTREES-1R3 p"
             sorry
          let ?Z = "ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
          have "ProperPrefixesTREES-1K1 p c=TARSKIR1 W & {TARSKIK1 p} c=TARSKIR1 W"
            using A17 trees_1_def_3 zfmisc_1_th_31 sorry
          then obtain Z9 where 
            [ty]:"Z9 be SubsetSUBSET-1M2-of W" and Z9Def:"Z9 = ?Z"
            using xboole_1_th_8 sorry
          have A19: "Z9 be ChainTREES-2M1-of W"
          proof-
            have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 Z9 & r inTARSKIR2 Z9 implies (q,r)are-c=-comparableXBOOLE-0R3"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              fix r assume [ty]: "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              assume A20: "q inTARSKIR2 Z9"
                and A21: "r inTARSKIR2 Z9"
              have A22: "q inTARSKIR2 ProperPrefixesTREES-1K1 p or q inTARSKIR2 {TARSKIK1 p}"
                using A20 xboole_0_def_3 sorry
              have A23: "r inTARSKIR2 ProperPrefixesTREES-1K1 p or r inTARSKIR2 {TARSKIK1 p}"
                using A21 xboole_0_def_3 sorry
              have A24: "q is-a-proper-prefix-ofTREES-1R3 p or q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p"
                using A22 tarski_def_1 trees_1_th_12 sorry
              have A25: "r is-a-proper-prefix-ofTREES-1R3 p or r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p"
                using A23 tarski_def_1 trees_1_th_12 sorry
              have A26: "q is-a-prefix-ofTREES-1R2 p"
                using A24 sorry
              have "r is-a-prefix-ofTREES-1R2 p"
                using A25 sorry
              thus "(q,r)are-c=-comparableXBOOLE-0R3"
                using A26 trees_2_th_1 sorry
            qed "sorry"
            thus "Z9 be ChainTREES-2M1-of W"
              using trees_2_def_3 sorry
          qed
          have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p} implies ProperPrefixesTREES-1K1 q c=TARSKIR1 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
          proof(rule ballI,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume "q inTARSKIR2 ?Z"
            then have "q inTARSKIR2 ProperPrefixesTREES-1K1 p or q inTARSKIR2 {TARSKIK1 p}"
              using xboole_0_def_3 sorry
            then have "q is-a-proper-prefix-ofTREES-1R3 p or q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p"
              using tarski_def_1 trees_1_th_12 sorry
            then have "q is-a-prefix-ofTREES-1R2 p"
               sorry
            then have A27: "ProperPrefixesTREES-1K1 q c=TARSKIR1 ProperPrefixesTREES-1K1 p"
              using trees_1_th_17 sorry
            have "ProperPrefixesTREES-1K1 p c=TARSKIR1 ?Z"
              using xboole_1_th_7 sorry
            thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
              using A27 sorry
          qed "sorry"
          then have A28: "?Z inTARSKIR2 X"
            using A1 A19 sorry
          have A29: "p inTARSKIR2 {TARSKIK1 p}"
            using tarski_def_1 sorry
          have A30: " not p inTARSKIR2 Y"
            using A18 sorry
          have A31: "p inTARSKIR2 ?Z"
            using A29 xboole_0_def_3 sorry
          have "Y c=TARSKIR1 ?Z"
          proof-
            have "Y c=TARSKIR1 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A32: "x inHIDDENR3 Y"
                then obtain t where 
                  [ty]:"t be ElementTREES-1M2-of W" and tDef:"t = x"
                   sorry
                have "t is-a-proper-prefix-ofTREES-1R3 p"
                  using A18 A32 sorry
                then have "t inTARSKIR2 ProperPrefixesTREES-1K1 p"
                  using trees_1_th_12 sorry
                thus "x inHIDDENR3 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
                  using xboole_0_def_3 sorry
              qed "sorry"
              thus "Y c=TARSKIR1 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          thus " not  True "
            using A16 A28 A30 A31 sorry
        qed
        thus "Y be Branch-likeTREES-2V2\<^bsub>(W)\<^esub>"
          using trees_2_def_7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax TREES_2M3 :: " Set \<Rightarrow> Ty" ("BranchTREES-2M3-of  _ " [70]70)
translations "BranchTREES-2M3-of W" \<rightharpoonup> "Branch-likeTREES-2V2\<^bsub>(W)\<^esub>\<bar>ChainTREES-2M1-of W"

mtheorem trees_2_cl_5:
  mlet "W be TreeTREES-1M1"
"cluster Branch-likeTREES-2V2\<^bsub>(W)\<^esub> also-is  non emptyXBOOLE-0V1 for ChainTREES-2M1-of W"
proof
(*coherence*)
  show " for it be ChainTREES-2M1-of W holds it be Branch-likeTREES-2V2\<^bsub>(W)\<^esub> implies it be  non emptyXBOOLE-0V1"
  proof-
    have " for B be ChainTREES-2M1-of W holds B be Branch-likeTREES-2V2\<^bsub>(W)\<^esub>\<bar>emptyXBOOLE-0V1 implies  False "
    proof(rule ballI,rule impI)
      fix B assume [ty]: "B be ChainTREES-2M1-of W"
      assume A1: "B be Branch-likeTREES-2V2\<^bsub>(W)\<^esub>\<bar>emptyXBOOLE-0V1"
      let ?t = "the ElementTREES-1M2-of W"
      have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 B implies q is-a-proper-prefix-ofTREES-1R3 ?t"
        using A1 sorry
      thus " False "
        using A1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve C for "ChainTREES-2M1-of W"
reserve B for "BranchTREES-2M3-of W"
mtheorem trees_2_th_21:
" for W be TreeTREES-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for C be ChainTREES-2M1-of W holds v1 inTARSKIR2 C & v2 inTARSKIR2 C implies v1 inTARSKIR2 ProperPrefixesTREES-1K1 v2 or v2 is-a-prefix-ofTREES-1R2 v1"
proof-
  have " for W be TreeTREES-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for C be ChainTREES-2M1-of W holds v1 inTARSKIR2 C & v2 inTARSKIR2 C implies ( not v1 inTARSKIR2 ProperPrefixesTREES-1K1 v2 implies v2 is-a-prefix-ofTREES-1R2 v1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix v1 assume [ty]: "v1 be FinSequenceFINSEQ-1M1"
    fix v2 assume [ty]: "v2 be FinSequenceFINSEQ-1M1"
    fix C assume [ty]: "C be ChainTREES-2M1-of W"
    assume A1: "v1 inTARSKIR2 C & v2 inTARSKIR2 C"
    then obtain p q where 
      [ty]:"p be ElementTREES-1M2-of W" and pDef:"p = v1" and
      [ty]:"q be ElementTREES-1M2-of W" and qDef:"q = v2"
       sorry
    assume A2: " not v1 inTARSKIR2 ProperPrefixesTREES-1K1 v2"
    have A3: "(p,q)are-c=-comparableXBOOLE-0R3"
      using A1 trees_2_def_3 sorry
    have A4: " not v1 is-a-proper-prefix-ofTREES-1R3 v2"
      using A2 trees_1_th_12 sorry
    have "v1 is-a-prefix-ofTREES-1R2 v2 or v2 is-a-prefix-ofTREES-1R2 v1"
      using A3 sorry
    thus "v2 is-a-prefix-ofTREES-1R2 v1"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_22:
" for W be TreeTREES-1M1 holds  for v be FinSequenceFINSEQ-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for C be ChainTREES-2M1-of W holds (v1 inTARSKIR2 C & v2 inTARSKIR2 C) & v is-a-prefix-ofTREES-1R2 v2 implies v1 inTARSKIR2 ProperPrefixesTREES-1K1 v or v is-a-prefix-ofTREES-1R2 v1"
proof-
  have " for W be TreeTREES-1M1 holds  for v be FinSequenceFINSEQ-1M1 holds  for v1 be FinSequenceFINSEQ-1M1 holds  for v2 be FinSequenceFINSEQ-1M1 holds  for C be ChainTREES-2M1-of W holds (v1 inTARSKIR2 C & v2 inTARSKIR2 C) & v is-a-prefix-ofTREES-1R2 v2 implies  not ( not v1 inTARSKIR2 ProperPrefixesTREES-1K1 v &  not v is-a-prefix-ofTREES-1R2 v1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M1"
    fix v1 assume [ty]: "v1 be FinSequenceFINSEQ-1M1"
    fix v2 assume [ty]: "v2 be FinSequenceFINSEQ-1M1"
    fix C assume [ty]: "C be ChainTREES-2M1-of W"
    assume A1: "v1 inTARSKIR2 C & v2 inTARSKIR2 C"
      and A2: "v is-a-prefix-ofTREES-1R2 v2"
    have "v1 inTARSKIR2 ProperPrefixesTREES-1K1 v2 or v2 is-a-prefix-ofTREES-1R2 v1"
      using A1 trees_2_th_21 sorry
    then have "v1 is-a-proper-prefix-ofTREES-1R3 v2 or v is-a-prefix-ofTREES-1R2 v1"
      using A2 trees_1_th_12 sorry
    then have "(v,v1)are-c=-comparableXBOOLE-0R3"
      using A2 trees_2_th_2 sorry
    then have "(v is-a-proper-prefix-ofTREES-1R3 v1 or v =FINSEQ-1R1 v1) or v1 is-a-proper-prefix-ofTREES-1R3 v"
       sorry
    thus " not ( not v1 inTARSKIR2 ProperPrefixesTREES-1K1 v &  not v is-a-prefix-ofTREES-1R2 v1)"
      using trees_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_cl_6:
  mlet "W be TreeTREES-1M1"
"cluster finiteFINSET-1V1 for ChainTREES-2M1-of W"
proof
(*existence*)
  show " ex it be ChainTREES-2M1-of W st it be finiteFINSET-1V1"
  proof-
    have " ex tVar14 be ChainTREES-2M1-of W st tVar14 be finiteFINSET-1V1"
    proof-
      obtain C where 
        [ty]:"C be ChainTREES-2M1-of W" and CDef:"C = {}XBOOLE-0K1"
        using trees_2_th_19 sorry
      show " ex tVar14 be ChainTREES-2M1-of W st tVar14 be finiteFINSET-1V1"
      proof(rule bexI[of _ "C"])
        show "C be finiteFINSET-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_2_th_23:
" for W be TreeTREES-1M1 holds  for n be NatNAT-1M1 holds  for C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of W holds cardCARD-1K4 C >XXREAL-0R4 n implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 n)"
proof-
  have " for W be TreeTREES-1M1 holds  for n be NatNAT-1M1 holds  for C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of W holds  not ( not cardCARD-1K4 C >XXREAL-0R4 n & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 n)))"
  proof(rule ballI,rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix C assume [ty]: "C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of W"
    let ?X = "\<lambda>Lamb1. Lamb1 <XXREAL-0R3 cardCARD-1K4 C implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 Lamb1)"
    have A1: "?X(0NUMBERSK6)"
    proof-
      have "0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 C implies ( ex tVar15 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st tVar15 inTARSKIR2 C & lenFINSEQ-1K4 tVar15 >=XXREAL-0R2 0NUMBERSK6)"
      proof(rule impI)
        assume A2: "0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 C"
        then have A3: "C <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        let ?x = "the ElementSUBSET-1M1-of C"
        obtain x where 
          [ty]:"x be ElementTREES-1M2-of W" and xDef:"x = ?x"
          using A2 card_1_th_27 tarski_def_3 sorry
        have 
          [ty]:"x be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
           sorry
        show " ex tVar15 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st tVar15 inTARSKIR2 C & lenFINSEQ-1K4 tVar15 >=XXREAL-0R2 0NUMBERSK6"
        proof(rule bexI[of _ "x"])
          show "x inTARSKIR2 C & lenFINSEQ-1K4 x >=XXREAL-0R2 0NUMBERSK6"
            using A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    have A4: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (k <XXREAL-0R3 cardCARD-1K4 C implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 k)) & k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 cardCARD-1K4 C implies  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 k +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A5: "k <XXREAL-0R3 cardCARD-1K4 C implies ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 k)"
          and A6: "k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 cardCARD-1K4 C"
        have A7: "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have A8: "k <XXREAL-0R3 cardCARD-1K4 C"
          using A6 xxreal_0_th_2 sorry
        obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A9: "p inTARSKIR2 C"and A10: "lenFINSEQ-1K4 p >=XXREAL-0R2 k"
          using A5 A6 A7 xxreal_0_th_2 sorry
        obtain q where 
          [ty]:"q be FinSequenceFINSEQ-1M1" and qDef:"q = p  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 k"
          using finseq_1_th_15 sorry
        have A11: "lenFINSEQ-1K4 q =XBOOLE-0R4 k"
          using A10 finseq_1_th_17 sorry
        then have A12: "cardCARD-1K4 (ProperPrefixesTREES-1K1 q) =XBOOLE-0R4 k"
          using trees_1_th_35 sorry
        then have "cardCARD-1K4 (ProperPrefixesTREES-1K1 q) inTARSKIR2 SegmCARD-1K5 cardCARD-1K4 C"
          using A8 nat_1_th_44 sorry
        then have A13: "C \\SUBSET-1K7\<^bsub>(W)\<^esub> ProperPrefixesTREES-1K1 q <>HIDDENR2 {}XBOOLE-0K1"
          using card_1_th_68 sorry
        let ?x = "the ElementSUBSET-1M1-of C \\SUBSET-1K7\<^bsub>(W)\<^esub> ProperPrefixesTREES-1K1 q"
        have A14: "?x inTARSKIR2 C"
          using A13 xboole_0_def_5 sorry
        have A15: " not ?x inTARSKIR2 ProperPrefixesTREES-1K1 q"
          using A13 xboole_0_def_5 sorry
        obtain x where 
          [ty]:"x be ElementTREES-1M2-of W" and xDef:"x = ?x"
          using A14 sorry
        have "cardCARD-1K4 (ProperPrefixesTREES-1K1 q \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using A12 A15 card_2_th_41 sorry
        then have "cardCARD-1K4 (ProperPrefixesTREES-1K1 q \\/XBOOLE-0K2 {TARSKIK1 x}) inTARSKIR2 SegmCARD-1K5 cardCARD-1K4 C"
          using A6 nat_1_th_44 sorry
        then have A16: "C \\SUBSET-1K7\<^bsub>(W)\<^esub> (ProperPrefixesTREES-1K1 q \\/XBOOLE-0K2 {TARSKIK1 x}) <>HIDDENR2 {}XBOOLE-0K1"
          using card_1_th_68 sorry
        let ?y = "the ElementSUBSET-1M1-of C \\SUBSET-1K7\<^bsub>(W)\<^esub> (ProperPrefixesTREES-1K1 q \\/XBOOLE-0K2 {TARSKIK1 x})"
        have A17: "?y inTARSKIR2 C"
          using A16 xboole_0_def_5 sorry
        have A18: " not ?y inTARSKIR2 ProperPrefixesTREES-1K1 q \\/XBOOLE-0K2 {TARSKIK1 x}"
          using A16 xboole_0_def_5 sorry
        obtain y where 
          [ty]:"y be ElementTREES-1M2-of W" and yDef:"y = ?y"
          using A17 sorry
        have A19: " not y inTARSKIR2 ProperPrefixesTREES-1K1 q"
          using A18 xboole_0_def_3 sorry
        have A20: " not y inTARSKIR2 {TARSKIK1 x}"
          using A18 xboole_0_def_3 sorry
        have A21: "q is-a-prefix-ofTREES-1R2 p"
           sorry
        then have A22: "q is-a-prefix-ofTREES-1R2 x"
          using A9 A14 A15 trees_2_th_22 sorry
        have A23: "q is-a-prefix-ofTREES-1R2 y"
          using A9 A17 A19 A21 trees_2_th_22 sorry
        have A24: "x <>HIDDENR2 y"
          using A20 tarski_def_1 sorry
        have "q is-a-proper-prefix-ofTREES-1R3 y or q is-a-proper-prefix-ofTREES-1R3 x"
          using A22 A23 A24 sorry
        then have "k <XXREAL-0R3 lenFINSEQ-1K4 x or k <XXREAL-0R3 lenFINSEQ-1K4 y"
          using A11 trees_1_th_6 sorry
        then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 x or k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 y"
          using nat_1_th_13 sorry
        thus " not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 k +NAT-1K1 \<one>\<^sub>M))"
          using A14 A17 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds ?X(k)"
      using nat_1_sch_2 A1 A4 sorry
    thus " not ( not cardCARD-1K4 C >XXREAL-0R4 n & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 n)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_24:
" for W be TreeTREES-1M1 holds  for C be ChainTREES-2M1-of W holds {w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p } be ChainTREES-2M1-of W"
proof-
  have " for W be TreeTREES-1M1 holds  for C be ChainTREES-2M1-of W holds {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) } be ChainTREES-2M1-of W"
  proof(rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix C assume [ty]: "C be ChainTREES-2M1-of W"
    have "{w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p } c=TARSKIR1 W"
    proof-
      have "{w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) } c=TARSKIR1 W"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p } implies x inHIDDENR3 W"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p }"
          then have " ex w be ElementTREES-1M2-of W st x =HIDDENR1 w & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)"
             sorry
          thus "x inHIDDENR3 W"
             sorry
        qed "sorry"
        thus "{w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) } c=TARSKIR1 W"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain Z where 
      [ty]:"Z be SubsetSUBSET-1M2-of W" and ZDef:"Z = {w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p }"
       sorry
    have "Z be ChainTREES-2M1-of W"
    proof-
      have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Z implies (q inTARSKIR2 Z implies (p,q)are-c=-comparableXBOOLE-0R3)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume "p inTARSKIR2 Z"
        then have " ex w be ElementTREES-1M2-of W st p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> w & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)"
           sorry
        then obtain r1 where
          [ty]:"r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A1: "r1 inTARSKIR2 C"and A2: "p is-a-prefix-ofTREES-1R2 r1"
           sorry
        assume "q inTARSKIR2 Z"
        then have " ex w9 be ElementTREES-1M2-of W st q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> w9 & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w9 is-a-prefix-ofTREES-1R2 p)"
           sorry
        then obtain r2 where
          [ty]:"r2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A3: "r2 inTARSKIR2 C"and A4: "q is-a-prefix-ofTREES-1R2 r2"
           sorry
        have "(r1,r2)are-c=-comparableXBOOLE-0R3"
          using A1 A3 trees_2_def_3 sorry
        then have "r1 is-a-prefix-ofTREES-1R2 r2 or r2 is-a-prefix-ofTREES-1R2 r1"
           sorry
        then have "p is-a-prefix-ofTREES-1R2 r2 or q is-a-prefix-ofTREES-1R2 r1"
          using A2 A4 sorry
        thus "(p,q)are-c=-comparableXBOOLE-0R3"
          using A2 A4 trees_2_th_1 sorry
      qed "sorry"
      thus "Z be ChainTREES-2M1-of W"
        using trees_2_def_3 sorry
    qed
    thus "{w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) } be ChainTREES-2M1-of W"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_25:
" for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for B be BranchTREES-2M3-of W holds p is-a-prefix-ofTREES-1R2 q & q inTARSKIR2 B implies p inTARSKIR2 B"
proof-
  have " for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for B be BranchTREES-2M3-of W holds p is-a-prefix-ofTREES-1R2 q implies (q inTARSKIR2 B implies p inTARSKIR2 B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix B assume [ty]: "B be BranchTREES-2M3-of W"
    assume "p is-a-prefix-ofTREES-1R2 q"
    then have "p is-a-proper-prefix-ofTREES-1R3 q or p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q"
       sorry
    then have A1: "p inTARSKIR2 ProperPrefixesTREES-1K1 q or p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q"
      using trees_1_def_2 sorry
    assume A2: "q inTARSKIR2 B"
    then have "ProperPrefixesTREES-1K1 q c=TARSKIR1 B"
      using trees_2_def_7 sorry
    thus "p inTARSKIR2 B"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_26:
" for W be TreeTREES-1M1 holds  for B be BranchTREES-2M3-of W holds {}XBOOLE-0K1 inTARSKIR2 B"
proof-
  have " for W be TreeTREES-1M1 holds  for B be BranchTREES-2M3-of W holds {}XBOOLE-0K1 inTARSKIR2 B"
  proof(rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix B assume [ty]: "B be BranchTREES-2M3-of W"
    let ?x = "the ElementSUBSET-1M3\<^bsub>(W)\<^esub>-of B"
    obtain x where 
      [ty]:"x be ElementTREES-1M2-of W" and xDef:"x = ?x"
       sorry
    have "<*>FINSEQ-1K7 NATNUMBERSK1 is-a-prefix-ofTREES-1R2 x"
       sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 B"
      using trees_2_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_27:
" for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for C be ChainTREES-2M1-of W holds (p inTARSKIR2 C & q inTARSKIR2 C) & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q implies p is-a-prefix-ofTREES-1R2 q"
proof-
  have " for W be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for C be ChainTREES-2M1-of W holds ((p inTARSKIR2 C & q inTARSKIR2 C) & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q) &  not p is-a-prefix-ofTREES-1R2 q implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix C assume [ty]: "C be ChainTREES-2M1-of W"
    assume "((p inTARSKIR2 C & q inTARSKIR2 C) & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q) &  not p is-a-prefix-ofTREES-1R2 q"
    then have "q inTARSKIR2 ProperPrefixesTREES-1K1 p &  not q is-a-proper-prefix-ofTREES-1R3 p"
      using trees_2_th_21 trees_1_th_6 sorry
    thus " False "
      using trees_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_28:
" for W be TreeTREES-1M1 holds  for C be ChainTREES-2M1-of W holds  ex B be BranchTREES-2M3-of W st C c=TARSKIR1 B"
proof-
  have " for W be TreeTREES-1M1 holds  for C be ChainTREES-2M1-of W holds  ex tVar16 be BranchTREES-2M3-of W st C c=TARSKIR1 tVar16"
  proof(rule ballI,rule ballI)
    fix W assume [ty]: "W be TreeTREES-1M1"
    fix C assume [ty]: "C be ChainTREES-2M1-of W"
    let ?X = "\<lambda>Lamb1. (Lamb1 be ChainTREES-2M1-of W & C c=TARSKIR1 Lamb1) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Lamb1 implies ProperPrefixesTREES-1K1 p c=TARSKIR1 Lamb1)"
    obtain X where
      [ty]:"X be setHIDDENM2" and 
      A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 X iff Y inTARSKIR2 boolZFMISC-1K1 W & ?X(Y)"
      using xfamily_sch_1 sorry
    let ?Z = "{w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p }"
    have A2: "?Z be ChainTREES-2M1-of W"
      using trees_2_th_24 sorry
    have A3: "C c=TARSKIR1 ?Z"
    proof-
      have "C c=TARSKIR1 {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 C implies x inHIDDENR3 {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A4: "x inHIDDENR3 C"
          then obtain w where 
            [ty]:"w be ElementTREES-1M2-of W" and wDef:"w = x"
             sorry
          have "w is-a-prefix-ofTREES-1R2 w"
             sorry
          thus "x inHIDDENR3 {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) }"
            using A4 sorry
        qed "sorry"
        thus "C c=TARSKIR1 {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 {w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 {w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p }"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      assume "p inTARSKIR2 ?Z"
      then have A5: " ex w be ElementTREES-1M2-of W st p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> w & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)"
         sorry
      then obtain q where
        [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
        A6: "q inTARSKIR2 C"and A7: "p is-a-prefix-ofTREES-1R2 q"
         sorry
      show "ProperPrefixesTREES-1K1 p c=TARSKIR1 {w where w be ElementTREES-1M2-of W :  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p }"
      proof-
        have "ProperPrefixesTREES-1K1 p c=TARSKIR1 {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 p implies x inHIDDENR3 {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ProperPrefixesTREES-1K1 p"
            then obtain r where
              [ty]:"r be FinSequenceFINSEQ-1M1" and 
              A8: "x =HIDDENR1 r"and A9: "r is-a-proper-prefix-ofTREES-1R3 p"
              using trees_1_def_2 sorry
            have "r is-a-prefix-ofTREES-1R2 p"
              using A9 sorry
            then have "r is-a-prefix-ofTREES-1R2 q & r inTARSKIR2 W"
              using A5 A7 trees_1_th_20 sorry
            thus "x inHIDDENR3 {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) }"
              using A6 A8 sorry
          qed "sorry"
          thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 {w where w be ElementTREES-1M2-of W :  not ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 C & w is-a-prefix-ofTREES-1R2 p)) }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed "sorry"
    then have A10: "X <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A2 A3 sorry
    have " for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 & (Z c=TARSKIR1 X & Z be c=-linearORDINAL1V6) implies unionTARSKIK3 Z inTARSKIR2 X"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix Z assume [ty]: "Z be setHIDDENM2"
      assume A11: "Z <>HIDDENR2 {}XBOOLE-0K1"
        and A12: "Z c=TARSKIR1 X"
        and A13: "Z be c=-linearORDINAL1V6"
      have "unionTARSKIK3 Z c=TARSKIR1 W"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 Z implies x inHIDDENR3 W"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 unionTARSKIK3 Z"
          then obtain Y where
            [ty]:"Y be setHIDDENM2" and 
            A14: "x inHIDDENR3 Y"and A15: "Y inTARSKIR2 Z"
            using tarski_def_4 sorry
          have "Y inTARSKIR2 boolZFMISC-1K1 W"
            using A1 A12 A15 sorry
          thus "x inHIDDENR3 W"
            using A14 sorry
        qed "sorry"
        thus "unionTARSKIK3 Z c=TARSKIR1 W"
          using tarski_def_3 sorry
      qed
      then obtain Z9 where 
        [ty]:"Z9 be SubsetSUBSET-1M2-of W" and Z9Def:"Z9 = unionTARSKIK3 Z"
         sorry
      have A16: "Z9 be ChainTREES-2M1-of W"
      proof-
        have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Z9 implies (q inTARSKIR2 Z9 implies (p,q)are-c=-comparableXBOOLE-0R3)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume "p inTARSKIR2 Z9"
          then obtain X1 where
            [ty]:"X1 be setHIDDENM2" and 
            A17: "p inTARSKIR2 X1"and A18: "X1 inTARSKIR2 Z"
            using tarski_def_4 sorry
          assume "q inTARSKIR2 Z9"
          then obtain X2 where
            [ty]:"X2 be setHIDDENM2" and 
            A19: "q inTARSKIR2 X2"and A20: "X2 inTARSKIR2 Z"
            using tarski_def_4 sorry
          have "(X1,X2)are-c=-comparableXBOOLE-0R3"
            using A13 A18 A20 sorry
          then have A21: "X1 c=TARSKIR1 X2 or X2 c=TARSKIR1 X1"
             sorry
          have A22: "X1 be ChainTREES-2M1-of W"
            using A1 A12 A18 sorry
          have "X2 be ChainTREES-2M1-of W"
            using A1 A12 A20 sorry
          thus "(p,q)are-c=-comparableXBOOLE-0R3"
            using A17 A19 A21 A22 trees_2_def_3 sorry
        qed "sorry"
        thus "Z9 be ChainTREES-2M1-of W"
          using trees_2_def_3 sorry
      qed
      have A23: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 unionTARSKIK3 Z implies ProperPrefixesTREES-1K1 p c=TARSKIR1 unionTARSKIK3 Z"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume "p inTARSKIR2 unionTARSKIK3 Z"
        then obtain X1 where
          [ty]:"X1 be setHIDDENM2" and 
          A24: "p inTARSKIR2 X1 & X1 inTARSKIR2 Z"
          using tarski_def_4 sorry
        have "ProperPrefixesTREES-1K1 p c=TARSKIR1 X1 & X1 c=TARSKIR1 unionTARSKIK3 Z"
          using A1 A12 A24 zfmisc_1_th_74 sorry
        thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 unionTARSKIK3 Z"
           sorry
      qed "sorry"
      let ?x = "the ElementSUBSET-1M1-of Z"
      have "?x inTARSKIR2 X"
        using A11 A12 sorry
      then have A25: "C c=TARSKIR1 ?x"
        using A1 sorry
      have "?x c=TARSKIR1 unionTARSKIK3 Z"
        using A11 zfmisc_1_th_74 sorry
      then have "C c=TARSKIR1 unionTARSKIK3 Z"
        using A25 sorry
      thus "unionTARSKIK3 Z inTARSKIR2 X"
        using A1 A16 A23 sorry
    qed "sorry"
    then obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A26: "Y inTARSKIR2 X"and A27: " for Z be setHIDDENM2 holds Z inTARSKIR2 X & Z <>HIDDENR2 Y implies  not Y c=TARSKIR1 Z"
      using A10 orders_1_th_67 sorry
    have 
      [ty]:"Y be ChainTREES-2M1-of W"
      using A1 A26 sorry
    have "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Y implies ProperPrefixesTREES-1K1 p c=TARSKIR1 Y) & (( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 W & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 Y implies q is-a-proper-prefix-ofTREES-1R3 p)) implies  False )"
    proof(rule conjMI,rule impI)
      show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Y implies ProperPrefixesTREES-1K1 p c=TARSKIR1 Y"
        using A1 A26 sorry
      assume Given: " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 W & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 Y implies q is-a-proper-prefix-ofTREES-1R3 p)"
      then obtain p where
        [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
        A28: "p inTARSKIR2 W"and A29: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 Y implies q is-a-proper-prefix-ofTREES-1R3 p"
         sorry
      let ?Z = "ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
      have "ProperPrefixesTREES-1K1 p c=TARSKIR1 W & {TARSKIK1 p} c=TARSKIR1 W"
        using A28 trees_1_def_3 zfmisc_1_th_31 sorry
      then obtain Z9 where 
        [ty]:"Z9 be SubsetSUBSET-1M2-of W" and Z9Def:"Z9 = ?Z"
        using xboole_1_th_8 sorry
      have A30: "Z9 be ChainTREES-2M1-of W"
      proof-
        have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 Z9 & r inTARSKIR2 Z9 implies (q,r)are-c=-comparableXBOOLE-0R3"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          fix r assume [ty]: "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume A31: "q inTARSKIR2 Z9"
            and A32: "r inTARSKIR2 Z9"
          have A33: "q inTARSKIR2 ProperPrefixesTREES-1K1 p or q inTARSKIR2 {TARSKIK1 p}"
            using A31 xboole_0_def_3 sorry
          have A34: "r inTARSKIR2 ProperPrefixesTREES-1K1 p or r inTARSKIR2 {TARSKIK1 p}"
            using A32 xboole_0_def_3 sorry
          have A35: "q is-a-proper-prefix-ofTREES-1R3 p or q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p"
            using A33 tarski_def_1 trees_1_th_12 sorry
          have A36: "r is-a-proper-prefix-ofTREES-1R3 p or r =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p"
            using A34 tarski_def_1 trees_1_th_12 sorry
          have A37: "q is-a-prefix-ofTREES-1R2 p"
            using A35 sorry
          have "r is-a-prefix-ofTREES-1R2 p"
            using A36 sorry
          thus "(q,r)are-c=-comparableXBOOLE-0R3"
            using A37 trees_2_th_1 sorry
        qed "sorry"
        thus "Z9 be ChainTREES-2M1-of W"
          using trees_2_def_3 sorry
      qed
      have A38: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p} implies ProperPrefixesTREES-1K1 q c=TARSKIR1 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
      proof(rule ballI,rule impI)
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume "q inTARSKIR2 ?Z"
        then have "q inTARSKIR2 ProperPrefixesTREES-1K1 p or q inTARSKIR2 {TARSKIK1 p}"
          using xboole_0_def_3 sorry
        then have "q is-a-proper-prefix-ofTREES-1R3 p or q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p"
          using tarski_def_1 trees_1_th_12 sorry
        then have "q is-a-prefix-ofTREES-1R2 p"
           sorry
        then have A39: "ProperPrefixesTREES-1K1 q c=TARSKIR1 ProperPrefixesTREES-1K1 p"
          using trees_1_th_17 sorry
        have "ProperPrefixesTREES-1K1 p c=TARSKIR1 ?Z"
          using xboole_1_th_7 sorry
        thus "ProperPrefixesTREES-1K1 q c=TARSKIR1 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
          using A39 sorry
      qed "sorry"
      have A40: "Y c=TARSKIR1 ?Z"
      proof-
        have "Y c=TARSKIR1 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A41: "x inHIDDENR3 Y"
            then obtain t where 
              [ty]:"t be ElementTREES-1M2-of W" and tDef:"t = x"
               sorry
            have "t is-a-proper-prefix-ofTREES-1R3 p"
              using A29 A41 sorry
            then have "t inTARSKIR2 ProperPrefixesTREES-1K1 p"
              using trees_1_th_12 sorry
            thus "x inHIDDENR3 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
              using xboole_0_def_3 sorry
          qed "sorry"
          thus "Y c=TARSKIR1 ProperPrefixesTREES-1K1 p \\/XBOOLE-0K2 {TARSKIK1 p}"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "C c=TARSKIR1 Y"
        using A1 A26 sorry
      then have "C c=TARSKIR1 ?Z"
        using A40 sorry
      then have A42: "?Z inTARSKIR2 X"
        using A1 A30 A38 sorry
      have A43: "p inTARSKIR2 {TARSKIK1 p}"
        using tarski_def_1 sorry
      have A44: " not p inTARSKIR2 Y"
        using A29 sorry
      have "p inTARSKIR2 ?Z"
        using A43 xboole_0_def_3 sorry
      thus " False "
        using A27 A40 A42 A44 sorry
    qed
    then have 
      [ty]:"Y be BranchTREES-2M3-of W"
      using trees_2_def_7 sorry
    show " ex tVar16 be BranchTREES-2M3-of W st C c=TARSKIR1 tVar16"
    proof(rule bexI[of _ "Y"])
      show "C c=TARSKIR1 Y"
        using A1 A26 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem trees_2_sch_4:
  fixes Xf0 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex n be NatNAT-1M1 st Pp2(x,n))"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex n be NatNAT-1M1 st (f .FUNCT-1K1 x =XBOOLE-0R4 n & Pp2(x,n)) & ( for m be NatNAT-1M1 holds Pp2(x,m) implies n <=XXREAL-0R1 m)))"
  proof-
    have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex n be NatNAT-1M1 st (f .FUNCT-1K1 x =HIDDENR1 n & Pp2(x,n)) & ( for m be NatNAT-1M1 holds Pp2(x,m) implies n <=XXREAL-0R1 m)))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be NatNAT-1M1 st (Lamb2 =HIDDENR1 n & Pp2(Lamb1,n)) & ( for m be NatNAT-1M1 holds Pp2(Lamb1,m) implies n <=XXREAL-0R1 m)"
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex y be objectHIDDENM1 st ?Q(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex tVar17 be objectHIDDENM1 st  ex nc be NatNAT-1M1 st (tVar17 =HIDDENR1 nc & Pp2(x,nc)) & ( for m be NatNAT-1M1 holds Pp2(x,m) implies nc <=XXREAL-0R1 m))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          let ?X = "\<lambda>Lamb1. Pp2(x,Lamb1)"
          assume "x inHIDDENR3 Xf0"
          then have " ex n be NatNAT-1M1 st ?X(n)"
            using A1 sorry
          then have A3: " ex n be NatNAT-1M1 st ?X(n)"
             sorry
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A4: "?X(n) & ( for m be NatNAT-1M1 holds ?X(m) implies n <=XXREAL-0R1 m)"
            using nat_1_sch_5 A3 sorry
          show " ex tVar17 be objectHIDDENM1 st  ex nc be NatNAT-1M1 st (tVar17 =HIDDENR1 nc & Pp2(x,nc)) & ( for m be NatNAT-1M1 holds Pp2(x,m) implies nc <=XXREAL-0R1 m)"
          proof(rule bexI[of _ "n"])
            show " ex nc be NatNAT-1M1 st (n =HIDDENR1 nc & Pp2(x,nc)) & ( for m be NatNAT-1M1 holds Pp2(x,m) implies nc <=XXREAL-0R1 m)"
              using A4 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex n be NatNAT-1M1 st (f .FUNCT-1K1 x =HIDDENR1 n & Pp2(x,n)) & ( for m be NatNAT-1M1 holds Pp2(x,m) implies n <=XXREAL-0R1 m)))"
        using classes1_sch_1 A2 sorry
    qed
    thus " ?thesis "
       sorry
  qed

mlemma trees_2_lm_1:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds k inTARSKIR2 X implies k <=XXREAL-0R1 n)"
proof-
  have " for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies  not ( for n be NatNAT-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 X &  not k <=XXREAL-0R1 n)))"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X be finiteFINSET-1V1"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex k1 be NatNAT-1M1 st  ex k2 be NatNAT-1M1 st (Lamb1 =HIDDENR1 k1 & Lamb2 =HIDDENR1 k2) & k1 >=XXREAL-0R2 k2"
    have " not ( for n be NatNAT-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 X &  not k <=XXREAL-0R1 n)))"
    proof-
      show " not ( for n be NatNAT-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 X &  not k <=XXREAL-0R1 n)))"
      proof-
        have cases: "X /\\XBOOLE-0K3 NATNUMBERSK1 =XBOOLE-0R4 {}XBOOLE-0K1 or X /\\XBOOLE-0K3 NATNUMBERSK1 <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "X /\\XBOOLE-0K3 NATNUMBERSK1 =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( for n be NatNAT-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 X &  not k <=XXREAL-0R1 n)))"
        proof(rule impI)
          assume A2: "X /\\XBOOLE-0K3 NATNUMBERSK1 =XBOOLE-0R4 {}XBOOLE-0K1"
          show " not ( for n be NatNAT-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 X &  not k <=XXREAL-0R1 n)))"
          proof-
            have " ex tVar18 be NatNAT-1M1 st  for k be NatNAT-1M1 holds k inTARSKIR2 X implies k <=XXREAL-0R1 tVar18"
            proof-
              show " ex tVar18 be NatNAT-1M1 st  for k be NatNAT-1M1 holds k inTARSKIR2 X implies k <=XXREAL-0R1 tVar18"
              proof(rule bexI[of _ "0NUMBERSK6"],rule ballI,rule impI)
                fix k assume [ty]: "k be NatNAT-1M1"
                have A3: "k inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                assume "k inTARSKIR2 X"
                thus "k <=XXREAL-0R1 0NUMBERSK6"
                  using A2 xboole_0_def_4 A3 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
        qed
        have case2: "X /\\XBOOLE-0K3 NATNUMBERSK1 <>HIDDENR2 {}XBOOLE-0K1 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds k inTARSKIR2 X implies k <=XXREAL-0R1 n)"
        proof(rule impI)
          assume A4: "X /\\XBOOLE-0K3 NATNUMBERSK1 <>HIDDENR2 {}XBOOLE-0K1"
          obtain XN where 
            [ty]:"XN be finiteFINSET-1V1\<bar>setHIDDENM2" and XNDef:"XN = X /\\XBOOLE-0K3 NATNUMBERSK1"
            using A1 sorry
          have A5: "XN <>HIDDENR2 {}XBOOLE-0K1"
            using A4 sorry
          have A6: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?P(x,y) & ?P(y,x) implies x =HIDDENR1 y"
            using xxreal_0_th_1 sorry
          have A7: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?P(x,y) & ?P(y,z) implies ?P(x,z)"
            using xxreal_0_th_2 sorry
          obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A8: "x inHIDDENR3 XN & ( for y be objectHIDDENM1 holds y inHIDDENR3 XN & y <>HIDDENR2 x implies  not ?P(y,x))"
            using card_2_sch_1 A5 A6 A7 sorry
          have "x inHIDDENR3 NATNUMBERSK1"
            using A8 xboole_0_def_4 sorry
          then obtain n where 
            [ty]:"n be NatNAT-1M1" and nDef:"n = x"
             sorry
          show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds k inTARSKIR2 X implies k <=XXREAL-0R1 n"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            have A9: "k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            assume "k inTARSKIR2 X"
            then have "k inTARSKIR2 X /\\XBOOLE-0K3 NATNUMBERSK1"
              using xboole_0_def_4 A9 sorry
            thus "k <=XXREAL-0R1 n"
              using A8 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( for n be NatNAT-1M1 holds  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 X &  not k <=XXREAL-0R1 n)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem trees_2_sch_5:
  fixes Xf0 af0 Qp1 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "af0 be objectHIDDENM1" and
   A1: "af0 inHIDDENR3 Xf0 & Qp1(af0)" and
   A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Qp1(x) implies ( ex y be objectHIDDENM1 st (y inHIDDENR3 Xf0 & Pp2(x,y)) & Qp1(y))"
  shows " ex f be FunctionFUNCT-1M1 st ((domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & rngFUNCT-1K2 f c=TARSKIR1 Xf0) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 af0) & ( for k be NatNAT-1M1 holds Pp2(f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & Qp1(f .FUNCT-1K1 k))"
  proof-
    have " ex tVar21 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar21 =XBOOLE-0R4 NATNUMBERSK1 & (rngFUNCT-1K2 tVar21 c=TARSKIR1 Xf0 & (tVar21 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 af0 & ( for k be NatNAT-1M1 holds Pp2(tVar21 .FUNCT-1K1 k,tVar21 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & Qp1(tVar21 .FUNCT-1K1 k))))"
    proof-
      obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 Xf0 & Qp1(x)"
        using xboole_0_sch_1 sorry
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 Y & Pp2(Lamb1,Lamb2)"
      have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ( ex y be objectHIDDENM1 st ?Q(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ( ex tVar20 be objectHIDDENM1 st tVar20 inHIDDENR3 Y & Pp2(x,tVar20))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 Y"
          then have "x inHIDDENR3 Xf0 & Qp1(x)"
            using A3 sorry
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A5: "(y inHIDDENR3 Xf0 & Pp2(x,y)) & Qp1(y)"
            using A2 sorry
          show " ex tVar20 be objectHIDDENM1 st tVar20 inHIDDENR3 Y & Pp2(x,tVar20)"
          proof(rule bexI[of _ "y"])
            show "y inHIDDENR3 Y & Pp2(x,y)"
              using A3 A5 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A6: "domRELAT-1K1 g =XBOOLE-0R4 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ?Q(x,g .FUNCT-1K1 x))"
        using classes1_sch_1 A4 sorry
      let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. g .FUNCT-1K1 Lamb2"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A7: "(domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 af0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?U(n,f .FUNCT-1K1 n))"
        using nat_1_sch_11 sorry
      show " ex tVar21 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar21 =XBOOLE-0R4 NATNUMBERSK1 & (rngFUNCT-1K2 tVar21 c=TARSKIR1 Xf0 & (tVar21 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 af0 & ( for k be NatNAT-1M1 holds Pp2(tVar21 .FUNCT-1K1 k,tVar21 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & Qp1(tVar21 .FUNCT-1K1 k))))"
      proof(rule bexI[of _ "f"],rule conjMI,rule conjMI,rule conjMI,rule ballI)
        show "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
          using A7 sorry
        let ?X = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1 inTARSKIR2 Y"
        have A8: "?X(0NUMBERSK6)"
          using A1 A3 A7 sorry
        have A9: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for k be NatNAT-1M1 holds f .FUNCT-1K1 k inTARSKIR2 Y implies f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 Y"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume "f .FUNCT-1K1 k inTARSKIR2 Y"
            then have "g .FUNCT-1K1 (f .FUNCT-1K1 k) inTARSKIR2 Y"
              using A6 sorry
            thus "f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 Y"
              using A7 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A10: " for k be NatNAT-1M1 holds ?X(k)"
          using nat_1_sch_2 A8 A9 sorry
        show "rngFUNCT-1K2 f c=TARSKIR1 Xf0"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 Xf0"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A11: "y inHIDDENR3 domRELAT-1K1 f"and A12: "x =HIDDENR1 f .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be NatNAT-1M1"
              using A7 A11 sorry
            have "f .FUNCT-1K1 y inTARSKIR2 Y"
              using A10 sorry
            thus "x inHIDDENR3 Xf0"
              using A3 A12 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 Xf0"
            using tarski_def_3 sorry
        qed
        show "f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 af0"
          using A7 sorry
        fix k assume [ty]: "k be NatNAT-1M1"
        have A13: "f .FUNCT-1K1 k inTARSKIR2 Y"
          using A10 sorry
        then have "Pp2(f .FUNCT-1K1 k,g .FUNCT-1K1 (f .FUNCT-1K1 k))"
          using A6 sorry
        thus "Pp2(f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & Qp1(f .FUNCT-1K1 k)"
          using A3 A7 A13 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem trees_2_th_29:
" for T be TreeTREES-1M1 holds ( for n be NatNAT-1M1 holds  ex C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T st cardCARD-1K4 C =XBOOLE-0R4 n) & ( for t be ElementTREES-1M2-of T holds succTREES-2K1\<^bsub>(T)\<^esub> t be finiteFINSET-1V1) implies ( ex B be ChainTREES-2M1-of T st  not B be finiteFINSET-1V1)"
proof-
  have " for T be TreeTREES-1M1 holds ( for n be NatNAT-1M1 holds  ex X be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T st cardCARD-1K4 X =XBOOLE-0R4 n) & ( for t be ElementTREES-1M2-of T holds succTREES-2K1\<^bsub>(T)\<^esub> t be finiteFINSET-1V1) implies ( ex tVar25 be ChainTREES-2M1-of T st  not tVar25 be finiteFINSET-1V1)"
  proof(rule ballI,rule impMI ,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    assume A1: " for n be NatNAT-1M1 holds  ex X be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T st cardCARD-1K4 X =XBOOLE-0R4 n"
      and A2: " for t be ElementTREES-1M2-of T holds succTREES-2K1\<^bsub>(T)\<^esub> t be finiteFINSET-1V1"
    let ?P = "\<lambda>Lamb1.  for n be NatNAT-1M1 holds  ex B be BranchTREES-2M3-of T st Lamb1 inTARSKIR2 B & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 Lamb1 +XCMPLX-0K2 n)"
    have A3: " for x be ElementTREES-1M2-of T holds ?P(x) implies ( ex n be NatNAT-1M1 st x ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T & ?P(x ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)))"
    proof-
      have " for x be ElementTREES-1M2-of T holds ( for n be NatNAT-1M1 holds  ex B be BranchTREES-2M3-of T st x inTARSKIR2 B & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 x +XCMPLX-0K2 n)) & ( for n be NatNAT-1M1 holds x ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T implies  not ( for nc be NatNAT-1M1 holds  ex B be BranchTREES-2M3-of T st x ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 B & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 (x ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) +XCMPLX-0K2 nc))) implies  False "
      proof(rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be ElementTREES-1M2-of T"
        assume A4: "?P(x)"
          and A5: " for n be NatNAT-1M1 holds x ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T implies  not ?P(x ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))"
        have A6: "succTREES-2K1\<^bsub>(T)\<^esub> x be finiteFINSET-1V1"
          using A2 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  for B be BranchTREES-2M3-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p =HIDDENR1 Lamb1 & Lamb1 inHIDDENR3 B) & q inTARSKIR2 B implies lenFINSEQ-1K4 p +XCMPLX-0K2 Lamb2 >XXREAL-0R4 lenFINSEQ-1K4 q"
        have A7: " for y be objectHIDDENM1 holds y inHIDDENR3 succTREES-2K1\<^bsub>(T)\<^esub> x implies ( ex n be NatNAT-1M1 st ?X(y,n))"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 succTREES-2K1\<^bsub>(T)\<^esub> x implies ( ex tVar22 be NatNAT-1M1 st  for B be BranchTREES-2M3-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p =HIDDENR1 y & y inHIDDENR3 B) & q inTARSKIR2 B implies lenFINSEQ-1K4 p +XCMPLX-0K2 tVar22 >XXREAL-0R4 lenFINSEQ-1K4 q)"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 succTREES-2K1\<^bsub>(T)\<^esub> x"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A8: "y =HIDDENR1 x ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)"and A9: "x ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T"
               sorry
            obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A10: " for B be BranchTREES-2M3-of T holds x ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 B implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 B implies lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 (x ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)) +XCMPLX-0K2 n)"
              using A5 A9 sorry
            show " ex tVar22 be NatNAT-1M1 st  for B be BranchTREES-2M3-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p =HIDDENR1 y & y inHIDDENR3 B) & q inTARSKIR2 B implies lenFINSEQ-1K4 p +XCMPLX-0K2 tVar22 >XXREAL-0R4 lenFINSEQ-1K4 q"
            proof(rule bexI[of _ "n"])
              show " for B be BranchTREES-2M3-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p =HIDDENR1 y & y inHIDDENR3 B) & q inTARSKIR2 B implies lenFINSEQ-1K4 p +XCMPLX-0K2 n >XXREAL-0R4 lenFINSEQ-1K4 q"
                using A8 A10 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A11: "domRELAT-1K1 f =XBOOLE-0R4 succTREES-2K1\<^bsub>(T)\<^esub> x"and A12: " for y be objectHIDDENM1 holds y inHIDDENR3 succTREES-2K1\<^bsub>(T)\<^esub> x implies ( ex n be NatNAT-1M1 st (f .FUNCT-1K1 y =XBOOLE-0R4 n & ?X(y,n)) & ( for m be NatNAT-1M1 holds ?X(y,m) implies n <=XXREAL-0R1 m))"
          using trees_2_sch_4 A7 sorry
        obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A13: " for m be NatNAT-1M1 holds m inTARSKIR2 rngFUNCT-1K2 f implies m <=XXREAL-0R1 k"
          using A6 A11 trees_2_lm_1 finset_1_th_8 sorry
        obtain B where
          [ty]:"B be BranchTREES-2M3-of T" and 
          A14: "x inTARSKIR2 B"and A15: " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 x +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using A4 sorry
        obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A16: "p inTARSKIR2 B"and A17: "lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 x +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using A15 sorry
        obtain r where 
          [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and rDef:"r = p  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_18 sorry
        have "lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k"
          using nat_1_th_11 sorry
        then have A18: "lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M"
          using A17 xxreal_0_th_2 sorry
        have A19: "r is-a-prefix-ofTREES-1R2 p"
           sorry
        have A20: "lenFINSEQ-1K4 r =XBOOLE-0R4 lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M"
          using A18 finseq_1_th_17 sorry
        have A21: "r inTARSKIR2 B"
          using A16 A19 trees_2_th_25 sorry
        then have "x is-a-prefix-ofTREES-1R2 r"
          using A14 A20 trees_2_th_27 nat_1_th_11 sorry
        then obtain j where
          [ty]:"j be FinSequenceFINSEQ-1M1" and 
          A22: "r =FINSEQ-1R1 x ^FINSEQ-1K8 j"
          using trees_1_th_1 sorry
        have "lenFINSEQ-1K4 x +NAT-1K1 lenFINSEQ-1K4 j =XBOOLE-0R4 lenFINSEQ-1K4 r"
          using A22 finseq_1_th_22 sorry
        then have A23: "j =FINSEQ-1R1 <*FINSEQ-1K10 j .FUNCT-1K1 \<one>\<^sub>M*>"
          using A20 finseq_1_th_40 sorry
        have A24: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> r =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 r) & \<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 x"
          using finseq_1_def_3 nat_1_th_11 sorry
        have "lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 r"
          using A18 finseq_1_th_17 sorry
        then have "(x ^FINSEQ-1K8 (<*FINSEQ-1K10 j .FUNCT-1K1 \<one>\<^sub>M*>)).FUNCT-1K1 (lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 j .FUNCT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> r"
          using A24 finseq_1_th_1 finseq_1_th_42 sorry
        then have "j .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> r"
          using A22 A23 funct_1_def_3 sorry
        then obtain l where 
          [ty]:"l be NatNAT-1M1" and lDef:"l = j .FUNCT-1K1 \<one>\<^sub>M"
           sorry
        have A25: "x ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) inTARSKIR2 succTREES-2K1\<^bsub>(T)\<^esub> x"
          using A21 A22 A23 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A26: "f .FUNCT-1K1 (x ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)) =XBOOLE-0R4 n"and A27: " for B be BranchTREES-2M3-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p =FINSEQ-1R1 x ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) & x ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) inTARSKIR2 B) & q inTARSKIR2 B implies lenFINSEQ-1K4 p +XCMPLX-0K2 n >XXREAL-0R4 lenFINSEQ-1K4 q"and " for m be NatNAT-1M1 holds ( for B be BranchTREES-2M3-of T holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p =FINSEQ-1R1 x ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) & x ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) inTARSKIR2 B) & q inTARSKIR2 B implies lenFINSEQ-1K4 p +XCMPLX-0K2 m >XXREAL-0R4 lenFINSEQ-1K4 q) implies n <=XXREAL-0R1 m"
          using A12 sorry
        have "n inTARSKIR2 rngFUNCT-1K2 f"
          using A11 A25 A26 funct_1_def_3 sorry
        then have "n <=XXREAL-0R1 k"
          using A13 sorry
        then have "lenFINSEQ-1K4 r +XCMPLX-0K2 n <=XXREAL-0R1 (lenFINSEQ-1K4 x +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k"
          using A20 xreal_1_th_7 sorry
        thus " False "
          using A16 A17 A21 A22 A23 A27 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain e where 
      [ty]:"e be ElementTREES-1M2-of T" and eDef:"e = {}XBOOLE-0K1"
      using trees_1_th_22 sorry
    have A28: "?P(e)"
    proof-
      have "( ex n be NatNAT-1M1 st  for B be BranchTREES-2M3-of T holds e inTARSKIR2 B implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 B implies lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 e +XCMPLX-0K2 n)) implies  False "
      proof(rule impI)
        assume Given: " ex n be NatNAT-1M1 st  for B be BranchTREES-2M3-of T holds e inTARSKIR2 B implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 B implies lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 e +XCMPLX-0K2 n)"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A29: " for B be BranchTREES-2M3-of T holds e inTARSKIR2 B implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 B implies lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 e +XCMPLX-0K2 n)"
           sorry
        obtain C where
          [ty]:"C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T" and 
          A30: "cardCARD-1K4 C =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
          using A1 sorry
        obtain B where
          [ty]:"B be BranchTREES-2M3-of T" and 
          A31: "C c=TARSKIR1 B"
          using trees_2_th_28 sorry
        have "n +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A32: " ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 C & lenFINSEQ-1K4 p >=XXREAL-0R2 n"
          using A30 trees_2_th_23 sorry
        have "e inTARSKIR2 B & lenFINSEQ-1K4 e =XBOOLE-0R4 0NUMBERSK6"
          using trees_2_th_26 sorry
        thus " False "
          using A29 A31 A32 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    let ?QQ = "\<lambda>Lamb1.  ex t be ElementTREES-1M2-of T st t =HIDDENR1 Lamb1 & ?P(t)"
    let ?PP = "\<lambda>Lamb1. \<lambda>Lamb2.  ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex n be NatNAT-1M1 st (Lamb1 =HIDDENR1 p & p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T) & Lamb2 =HIDDENR1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
    have A33: "e inTARSKIR2 T & ?QQ(e)"
      using A28 sorry
    have A34: " for x be objectHIDDENM1 holds x inHIDDENR3 T & ?QQ(x) implies ( ex y be objectHIDDENM1 st (y inHIDDENR3 T & ?PP(x,y)) & ?QQ(y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 T implies (( ex t be ElementTREES-1M2-of T st t =HIDDENR1 x & ( for n be NatNAT-1M1 holds  ex B be BranchTREES-2M3-of T st t inTARSKIR2 B & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 t +XCMPLX-0K2 n))) implies ( ex tVar23 be objectHIDDENM1 st (tVar23 inTARSKIR2 T & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex n be NatNAT-1M1 st (x =HIDDENR1 p & p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T) & tVar23 =HIDDENR1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))) & ( ex tVar24 be ElementTREES-1M2-of T st tVar24 =HIDDENR1 tVar23 & ( for n be NatNAT-1M1 holds  ex B be BranchTREES-2M3-of T st tVar24 inTARSKIR2 B & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 tVar24 +XCMPLX-0K2 n)))))"
      proof(rule ballI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 T"
        assume Given: " ex t be ElementTREES-1M2-of T st t =HIDDENR1 x & ?P(t)"
        then obtain t where
          [ty]:"t be ElementTREES-1M2-of T" and 
          A35: "t =HIDDENR1 x"and A36: "?P(t)"
           sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A37: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"and A38: "?P(t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))"
          using A3 A36 sorry
        obtain y where 
          [ty]:"y be setHIDDENM2" and yDef:"y = t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
           sorry
        show " ex tVar23 be objectHIDDENM1 st (tVar23 inTARSKIR2 T & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex n be NatNAT-1M1 st (x =HIDDENR1 p & p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T) & tVar23 =HIDDENR1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))) & ( ex tVar24 be ElementTREES-1M2-of T st tVar24 =HIDDENR1 tVar23 & ( for n be NatNAT-1M1 holds  ex B be BranchTREES-2M3-of T st tVar24 inTARSKIR2 B & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 tVar24 +XCMPLX-0K2 n)))"
        proof(rule bexI[of _ "y"],rule conjMI)
          show "y inTARSKIR2 T & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex n be NatNAT-1M1 st (x =HIDDENR1 p & p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T) & y =HIDDENR1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))"
            using A35 A37 sorry
          obtain t1 where 
            [ty]:"t1 be ElementTREES-1M2-of T" and t1Def:"t1 = t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
            using A37 sorry
          show " ex tVar24 be ElementTREES-1M2-of T st tVar24 =HIDDENR1 y & ( for n be NatNAT-1M1 holds  ex B be BranchTREES-2M3-of T st tVar24 inTARSKIR2 B & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 tVar24 +XCMPLX-0K2 n))"
          proof(rule bexI[of _ "t1"])
            show "t1 =HIDDENR1 y & ( for n be NatNAT-1M1 holds  ex B be BranchTREES-2M3-of T st t1 inTARSKIR2 B & ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p inTARSKIR2 B & lenFINSEQ-1K4 p >=XXREAL-0R2 lenFINSEQ-1K4 t1 +XCMPLX-0K2 n))"
              using A38 sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " ex f be FunctionFUNCT-1M1 st ((domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & rngFUNCT-1K2 f c=TARSKIR1 T) & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 e) & ( for k be NatNAT-1M1 holds ?PP(f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & ?QQ(f .FUNCT-1K1 k))"
      using trees_2_sch_5 A33 A34 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A39: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A40: "rngFUNCT-1K2 f c=TARSKIR1 T"and A41: "f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 e"and A42: " for k be NatNAT-1M1 holds ( ex p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex n be NatNAT-1M1 st (f .FUNCT-1K1 k =XBOOLE-0R4 p & p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T) & f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) & ( ex t be ElementTREES-1M2-of T st t =XBOOLE-0R4 f .FUNCT-1K1 k & ?P(t))"
       sorry
    obtain C where 
      [ty]:"C be SubsetSUBSET-1M2-of T" and CDef:"C = rngFUNCT-1K2 f"
      using A40 sorry
    have A43: " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k & q =XBOOLE-0R4 f .FUNCT-1K1 (k +XCMPLX-0K2 n) implies p is-a-prefix-ofTREES-1R2 q"
    proof(rule ballI)
      fix k assume [ty]: "k be NatNAT-1M1"
      let ?X = "\<lambda>Lamb1.  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k & q =XBOOLE-0R4 f .FUNCT-1K1 (k +XCMPLX-0K2 Lamb1) implies p is-a-prefix-ofTREES-1R2 q"
      have A44: "?X(0NUMBERSK6)"
         sorry
      have A45: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k & q =XBOOLE-0R4 f .FUNCT-1K1 (k +XCMPLX-0K2 n) implies p is-a-prefix-ofTREES-1R2 q) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k & q =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) implies p is-a-prefix-ofTREES-1R2 q)"
        proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A46: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k & q =XBOOLE-0R4 f .FUNCT-1K1 (k +XCMPLX-0K2 n) implies p is-a-prefix-ofTREES-1R2 q"
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume A47: "p =XBOOLE-0R4 f .FUNCT-1K1 k"
            and A48: "q =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
          have 
            [ty]:"k be NatNAT-1M1" and
            [ty]:"n be NatNAT-1M1"
             sorry
          obtain r l where
            [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "l be NatNAT-1M1" and 
            A49: "f .FUNCT-1K1 (k +XCMPLX-0K2 n) =XBOOLE-0R4 r"and "r ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) inTARSKIR2 T"and A50: "f .FUNCT-1K1 ((k +XCMPLX-0K2 n)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 r ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"
            using A42 sorry
          have A51: "p is-a-prefix-ofTREES-1R2 r"
            using A46 A47 A49 sorry
          have "r is-a-prefix-ofTREES-1R2 r ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"
            using trees_1_th_1 sorry
          thus "p is-a-prefix-ofTREES-1R2 q"
            using A48 A50 A51 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k & q =XBOOLE-0R4 f .FUNCT-1K1 (k +XCMPLX-0K2 n) implies p is-a-prefix-ofTREES-1R2 q"
        using nat_1_sch_2 A44 A45 sorry
    qed "sorry"
    have A52: " for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds k <=XXREAL-0R1 l implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k & q =XBOOLE-0R4 f .FUNCT-1K1 l implies p is-a-prefix-ofTREES-1R2 q)"
    proof(rule ballI,rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      fix l assume [ty]: "l be NatNAT-1M1"
      assume "k <=XXREAL-0R1 l"
      then have " ex n be NatNAT-1M1 st l =XBOOLE-0R4 k +XCMPLX-0K2 n"
        using nat_1_th_10 sorry
      thus " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k & q =XBOOLE-0R4 f .FUNCT-1K1 l implies p is-a-prefix-ofTREES-1R2 q"
        using A43 sorry
    qed "sorry"
    have "C be ChainTREES-2M1-of T"
    proof-
      have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 C & q inTARSKIR2 C implies (p,q)are-c=-comparableXBOOLE-0R3"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume A53: "p inTARSKIR2 C"
          and A54: "q inTARSKIR2 C"
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A55: "x inHIDDENR3 NATNUMBERSK1"and A56: "p =XBOOLE-0R4 f .FUNCT-1K1 x"
          using A39 A53 funct_1_def_3 sorry
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A57: "y inHIDDENR3 NATNUMBERSK1"and A58: "q =XBOOLE-0R4 f .FUNCT-1K1 y"
          using A39 A54 funct_1_def_3 sorry
        have 
          [ty]:"x be NatNAT-1M1" and
          [ty]:"y be NatNAT-1M1"
          using A55 A57 sorry
        have Cut1378: "x <=XXREAL-0R1 y or y <=XXREAL-0R1 x"
           sorry
        have "p is-a-prefix-ofTREES-1R2 q or q is-a-prefix-ofTREES-1R2 p"
        proof-
          show "p is-a-prefix-ofTREES-1R2 q or q is-a-prefix-ofTREES-1R2 p"
            using A52 A56 A58 Cut1378 sorry
        qed
        thus "(p,q)are-c=-comparableXBOOLE-0R3"
          using xboole_0_def_9 sorry
      qed "sorry"
      thus "C be ChainTREES-2M1-of T"
        using trees_2_def_3 sorry
    qed
    then have 
      [ty]:"C be ChainTREES-2M1-of T"
       sorry
    show " ex tVar25 be ChainTREES-2M1-of T st  not tVar25 be finiteFINSET-1V1"
    proof(rule bexI[of _ "C"])
      let ?X = "\<lambda>Lamb1.  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 Lamb1 implies lenFINSEQ-1K4 p =XBOOLE-0R4 Lamb1"
      have A59: "?X(0NUMBERSK6)"
        using A41 sorry
      have A60: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k implies lenFINSEQ-1K4 p =XBOOLE-0R4 k) implies ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies lenFINSEQ-1K4 p =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI,rule impI,rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A61: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p =XBOOLE-0R4 f .FUNCT-1K1 k implies lenFINSEQ-1K4 p =XBOOLE-0R4 k"
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume A62: "p =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          obtain q n where
            [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "n be NatNAT-1M1" and 
            A63: "f .FUNCT-1K1 k =XBOOLE-0R4 q"and "q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"and A64: "f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
            using A42 sorry
          have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 n*>)"
            using A62 A64 finseq_1_th_22 sorry
          also have "... = lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
            using finseq_1_th_39 sorry
          also have "... = k +NAT-1K1 \<one>\<^sub>M"
            using A61 A63 sorry
          finally show "lenFINSEQ-1K4 p =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A65: " for k be NatNAT-1M1 holds ?X(k)"
        using nat_1_sch_2 A59 A60 sorry
      have "f be one-to-oneFUNCT-1V2"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies  not (f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y &  not x =HIDDENR1 y)"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
          then obtain x9 y9 where 
            [ty]:"x9 be NatNAT-1M1" and x9Def:"x9 = x" and
            [ty]:"y9 be NatNAT-1M1" and y9Def:"y9 = y"
            using A39 sorry
          obtain p n where
            [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "n be NatNAT-1M1" and 
            A66: "f .FUNCT-1K1 x9 =XBOOLE-0R4 p"and "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"and "f .FUNCT-1K1 (x9 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
            using A42 sorry
          have A67: " ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st  ex k be NatNAT-1M1 st (f .FUNCT-1K1 y9 =XBOOLE-0R4 q & q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T) & f .FUNCT-1K1 (y9 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)"
            using A42 sorry
          have "lenFINSEQ-1K4 p =XBOOLE-0R4 x9"
            using A65 A66 sorry
          thus " not (f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y &  not x =HIDDENR1 y)"
            using A65 A66 A67 sorry
        qed "sorry"
        thus "f be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      then have "(NATNUMBERSK1,C)are-equipotentTARSKIR3"
        using A39 wellord2_def_4 sorry
      thus " not C be finiteFINSET-1V1"
        using card_1_th_38 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Koenig Lemma*)
mtheorem trees_2_th_30:
" for T be finite-orderTREES-2V1\<bar>TreeTREES-1M1 holds ( for n be NatNAT-1M1 holds  ex C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T st cardCARD-1K4 C =XBOOLE-0R4 n) implies ( ex B be ChainTREES-2M1-of T st  not B be finiteFINSET-1V1)"
proof-
  have " for T be finite-orderTREES-2V1\<bar>TreeTREES-1M1 holds  not (( for n be NatNAT-1M1 holds  not ( for C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T holds  not cardCARD-1K4 C =XBOOLE-0R4 n)) & ( for B be ChainTREES-2M1-of T holds B be finiteFINSET-1V1))"
  proof(rule ballI)
    fix T assume [ty]: "T be finite-orderTREES-2V1\<bar>TreeTREES-1M1"
    have " for t be ElementTREES-1M2-of T holds succTREES-2K1\<^bsub>(T)\<^esub> t be finiteFINSET-1V1"
       sorry
    thus " not (( for n be NatNAT-1M1 holds  not ( for C be finiteFINSET-1V1\<bar>ChainTREES-2M1-of T holds  not cardCARD-1K4 C =XBOOLE-0R4 n)) & ( for B be ChainTREES-2M1-of T holds B be finiteFINSET-1V1))"
      using trees_2_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_2_def_8 ("DecoratedTree-likeTREES-2V3" 70 ) where
"attr DecoratedTree-likeTREES-2V3 for RelationRELAT-1M1 means
  (\<lambda>IT. domRELAT-1K1 IT be TreeTREES-1M1)"..

mtheorem trees_2_cl_7:
"cluster DecoratedTree-likeTREES-2V3 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be DecoratedTree-likeTREES-2V3"
  proof-
    have " ex f be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 the TreeTREES-1M1,omegaORDINAL1K4 :]) st f be DecoratedTree-likeTREES-2V3"
    proof-
      let ?W = "the TreeTREES-1M1"
      obtain f where 
        [ty]:"f be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 the TreeTREES-1M1,omegaORDINAL1K4 :])" and fDef:"f = ?W -->FUNCOP-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6"
         sorry
      show " ex f be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 the TreeTREES-1M1,omegaORDINAL1K4 :]) st f be DecoratedTree-likeTREES-2V3"
      proof(rule bexI[of _ "f"])
        have "domRELSET-1K1\<^bsub>(the TreeTREES-1M1)\<^esub> f be TreeTREES-1M1"
        proof-
          show "domRELSET-1K1\<^bsub>(the TreeTREES-1M1)\<^esub> f be TreeTREES-1M1"
            using funcop_1_th_13 sorry
        qed
        thus "f be DecoratedTree-likeTREES-2V3"
          using trees_2_def_8 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax TREES_2M4 :: "Ty" ("DecoratedTreeTREES-2M4" 70)
translations "DecoratedTreeTREES-2M4" \<rightharpoonup> "DecoratedTree-likeTREES-2V3\<bar>FunctionFUNCT-1M1"

reserve T, T1, T2 for "DecoratedTreeTREES-2M4"
mtheorem trees_2_cl_8:
  mlet "T be DecoratedTreeTREES-2M4"
"cluster domRELAT-1K1 T as-term-is  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
proof
(*coherence*)
  show "domRELAT-1K1 T be  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
    using trees_2_def_8 sorry
qed "sorry"

mtheorem trees_2_cl_9:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster DecoratedTree-likeTREES-2V3\<bar>D -valuedRELAT-1V5 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be DecoratedTree-likeTREES-2V3\<bar>D -valuedRELAT-1V5"
  proof-
    have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (VarFor1 be DecoratedTree-likeTREES-2V3 & VarFor1 be D -valuedRELAT-1V5))"
    proof-
      let ?W = "the TreeTREES-1M1"
      let ?d = "the ElementSUBSET-1M1-of D"
      let ?f = "?W -->FUNCOP-1K8\<^bsub>(D)\<^esub> ?d"
      have "domRELSET-1K1\<^bsub>(the TreeTREES-1M1)\<^esub> ?f =XBOOLE-0R4 ?W"
        using funcop_1_th_13 sorry
      then obtain f where 
        [ty]:"f be DecoratedTreeTREES-2M4" and fDef:"f = ?f"
        using trees_2_def_8 sorry
      have "f be D -valuedRELAT-1V5"
         sorry
      thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (VarFor1 be DecoratedTree-likeTREES-2V3 & VarFor1 be D -valuedRELAT-1V5))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax TREES_2M5 :: " Set \<Rightarrow> Ty" ("DecoratedTreeTREES-2M5-of  _ " [70]70)
translations "DecoratedTreeTREES-2M5-of D" \<rightharpoonup> "D -valuedRELAT-1V5\<bar>DecoratedTreeTREES-2M4"

syntax TREES_2K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .TREES-2K3\<^bsub>'( _ ')\<^esub>  _ " [200,0,200]200)
translations "T .TREES-2K3\<^bsub>(D)\<^esub> t" \<rightharpoonup> "T .FUNCT-1K1 t"

mtheorem trees_2_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "t be ElementTREES-1M2-of domRELAT-1K1 T"
"cluster T .FUNCT-1K1 t as-term-is ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show "T .FUNCT-1K1 t be ElementSUBSET-1M1-of D"
  proof-
    have "T .FUNCT-1K1 t inTARSKIR2 rngRELSET-1K2\<^bsub>(D)\<^esub> T & rngRELSET-1K2\<^bsub>(D)\<^esub> T c=TARSKIR1 D"
      using funct_1_def_3 sorry
    thus "T .FUNCT-1K1 t be ElementSUBSET-1M1-of D"
       sorry
  qed
qed "sorry"

mtheorem trees_2_th_31:
" for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 domRELAT-1K1 T1 implies T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p) implies T1 =FUNCT-1R1 T2"
proof-
  have " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 domRELAT-1K1 T1 implies T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p) implies T1 =FUNCT-1R1 T2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
    fix T2 assume [ty]: "T2 be DecoratedTreeTREES-2M4"
    assume A1: "domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T2"
      and A2: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 domRELAT-1K1 T1 implies T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 T1 implies T1 .FUNCT-1K1 x =XBOOLE-0R4 T2 .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 T1"
      then obtain p where 
        [ty]:"p be ElementTREES-1M2-of domRELAT-1K1 T1" and pDef:"p = x"
         sorry
      have "T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p"
        using A2 sorry
      thus "T1 .FUNCT-1K1 x =XBOOLE-0R4 T2 .FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "T1 =FUNCT-1R1 T2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem trees_2_sch_6:
  fixes Tf0 Pp2 
  assumes
[ty]: "Tf0 be TreeTREES-1M1" and
   A1: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Tf0 implies ( ex x be setHIDDENM2 st Pp2(p,x))"
  shows " ex T be DecoratedTreeTREES-2M4 st domRELAT-1K1 T =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Tf0 implies Pp2(p,T .FUNCT-1K1 p))"
  proof-
    have " ex tVar27 be DecoratedTreeTREES-2M4 st domRELAT-1K1 tVar27 =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 Tf0 &  not Pp2(p,tVar27 .FUNCT-1K1 p)))"
    proof-
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Tf0 implies ( ex y be objectHIDDENM1 st Pp2(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Tf0 implies  not ( for y be objectHIDDENM1 holds  not Pp2(x,y))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 Tf0"
          then obtain p where 
            [ty]:"p be ElementTREES-1M2-of Tf0" and pDef:"p = x"
             sorry
          have " ex y be setHIDDENM2 st Pp2(p,y)"
            using A1 sorry
          thus " not ( for y be objectHIDDENM1 holds  not Pp2(x,y))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 Tf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Tf0 implies Pp2(x,f .FUNCT-1K1 x))"
        using classes1_sch_1 A2 sorry
      obtain T where 
        [ty]:"T be DecoratedTreeTREES-2M4" and TDef:"T = f"
        using A3 trees_2_def_8 sorry
      show " ex tVar27 be DecoratedTreeTREES-2M4 st domRELAT-1K1 tVar27 =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 Tf0 &  not Pp2(p,tVar27 .FUNCT-1K1 p)))"
      proof(rule bexI[of _ "T"])
        show "domRELAT-1K1 T =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 Tf0 &  not Pp2(p,T .FUNCT-1K1 p)))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem trees_2_sch_7:
  fixes Tf0 ff1 
  assumes
[ty]: "Tf0 be TreeTREES-1M1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> ff1(x1) be setHIDDENM2"
  shows " ex T be DecoratedTreeTREES-2M4 st domRELAT-1K1 T =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Tf0 implies T .FUNCT-1K1 p =XBOOLE-0R4 ff1(p))"
  proof-
    have " ex tVar28 be DecoratedTreeTREES-2M4 st domRELAT-1K1 tVar28 =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 Tf0 &  not tVar28 .FUNCT-1K1 p =XBOOLE-0R4 ff1(p)))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Tf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Tf0 implies f .FUNCT-1K1 x =XBOOLE-0R4 ff1(x))"
        using funct_1_sch_3 sorry
      obtain T where 
        [ty]:"T be DecoratedTreeTREES-2M4" and TDef:"T = f"
        using A1 trees_2_def_8 sorry
      show " ex tVar28 be DecoratedTreeTREES-2M4 st domRELAT-1K1 tVar28 =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 Tf0 &  not tVar28 .FUNCT-1K1 p =XBOOLE-0R4 ff1(p)))"
      proof(rule bexI[of _ "T"])
        show "domRELAT-1K1 T =TREES-2R1 Tf0 & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 Tf0 &  not T .FUNCT-1K1 p =XBOOLE-0R4 ff1(p)))"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef trees_2_def_9 ("LeavesTREES-2K4  _ " [164]164 ) where
  mlet "T be DecoratedTreeTREES-2M4"
"func LeavesTREES-2K4 T \<rightarrow> setHIDDENM2 equals
  T .:FUNCT-1K5 (LeavesTREES-1K3 domRELAT-1K1 T)"
proof-
  (*coherence*)
    show "T .:FUNCT-1K5 (LeavesTREES-1K3 domRELAT-1K1 T) be setHIDDENM2"
       sorry
qed "sorry"

mdef trees_2_def_10 (" _  |TREES-2K5  _ " [200,200]200 ) where
  mlet "T be DecoratedTreeTREES-2M4", "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
"func T  |TREES-2K5 p \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))"
proof-
  (*existence*)
    show " ex it be DecoratedTreeTREES-2M4 st domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))"
    proof-
      have " ex t be DecoratedTreeTREES-2M4 st domRELAT-1K1 t =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies t .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K8 q))"
      proof-
        let ?U = "\<lambda>Lamb1. T .FUNCT-1K1 (p ^FINSEQ-1K8 Lamb1)"
        show " ex t be DecoratedTreeTREES-2M4 st domRELAT-1K1 t =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies t .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K8 q))"
          using trees_2_sch_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds (domRELAT-1K1 it1 =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies it1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))) & (domRELAT-1K1 it2 =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies it2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q))) implies it1 =HIDDENR1 it2"
    proof-
      have " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & (( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies T1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)) & (domRELAT-1K1 T2 =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies T2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)))) implies T1 =HIDDENR1 T2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
        fix T2 assume [ty]: "T2 be DecoratedTreeTREES-2M4"
        assume A1: "domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p"
          and A2: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies T1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)"
          and A3: "domRELAT-1K1 T2 =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p"
          and A4: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies T2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)"
        have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p implies T1 .FUNCT-1K1 q =XBOOLE-0R4 T2 .FUNCT-1K1 q"
        proof(rule ballI,rule impI)
          fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume A5: "q inTARSKIR2 domRELAT-1K1 T  |TREES-1K4 p"
          then have "T1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q)"
            using A2 sorry
          thus "T1 .FUNCT-1K1 q =XBOOLE-0R4 T2 .FUNCT-1K1 q"
            using A4 A5 sorry
        qed "sorry"
        thus "T1 =HIDDENR1 T2"
          using A1 A3 trees_2_th_31 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_2_th_32:
" for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies rngFUNCT-1K2 (T  |TREES-2K5 p) c=TARSKIR1 rngFUNCT-1K2 T"
proof-
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for T be DecoratedTreeTREES-2M4 holds p inTARSKIR2 domRELAT-1K1 T implies rngFUNCT-1K2 (T  |TREES-2K5 p) c=TARSKIR1 rngFUNCT-1K2 T"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
    assume A1: "p inTARSKIR2 domRELAT-1K1 T"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (T  |TREES-2K5 p) implies x inHIDDENR3 rngFUNCT-1K2 T"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (T  |TREES-2K5 p)"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "y inHIDDENR3 domRELAT-1K1 (T  |TREES-2K5 p)"and A3: "x =HIDDENR1 (T  |TREES-2K5 p).FUNCT-1K1 y"
        using funct_1_def_3 sorry
      have 
        [ty]:"y be ElementTREES-1M2-of domRELAT-1K1 (T  |TREES-2K5 p)"
        using A2 sorry
      have A4: "domRELAT-1K1 (T  |TREES-2K5 p) =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p"
        using trees_2_def_10 sorry
      then have A5: "p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> y inTARSKIR2 domRELAT-1K1 T"
        using A1 trees_1_def_6 sorry
      have "x =HIDDENR1 T .FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> y)"
        using A3 A4 trees_2_def_10 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 T"
        using A5 funct_1_def_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (T  |TREES-2K5 p) c=TARSKIR1 rngFUNCT-1K2 T"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax TREES_2K6 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("LeavesTREES-2K6\<^bsub>'( _ ')\<^esub>  _ " [0,164]164)
translations "LeavesTREES-2K6\<^bsub>(D)\<^esub> T" \<rightharpoonup> "LeavesTREES-2K4 T"

mtheorem trees_2_add_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D"
"cluster LeavesTREES-2K4 T as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "LeavesTREES-2K4 T be SubsetSUBSET-1M2-of D"
  proof-
    have "T .:FUNCT-1K5 (LeavesTREES-1K3 domRELAT-1K1 T) c=TARSKIR1 rngRELSET-1K2\<^bsub>(D)\<^esub> T & rngRELSET-1K2\<^bsub>(D)\<^esub> T c=TARSKIR1 D"
      using relat_1_th_111 sorry
    thus "LeavesTREES-2K4 T be SubsetSUBSET-1M2-of D"
      using xboole_1_th_1 sorry
  qed
qed "sorry"

mtheorem trees_2_cl_10:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "p be ElementTREES-1M2-of domRELAT-1K1 T"
"cluster T  |TREES-2K5 p as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "T  |TREES-2K5 p be D -valuedRELAT-1V5"
  proof-
    have "rngFUNCT-1K2 (T  |TREES-2K5 p) c=TARSKIR1 rngRELSET-1K2\<^bsub>(D)\<^esub> T & rngRELSET-1K2\<^bsub>(D)\<^esub> T c=TARSKIR1 D"
      using trees_2_th_32 sorry
    then have "rngFUNCT-1K2 (T  |TREES-2K5 p) c=TARSKIR1 D"
       sorry
    thus "T  |TREES-2K5 p be D -valuedRELAT-1V5"
       sorry
  qed
qed "sorry"

mdef trees_2_def_11 (" _ with-replacementTREES-2K7'( _ , _ ')" [164,0,0]164 ) where
  mlet "T be DecoratedTreeTREES-2M4", "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1", "T1 be DecoratedTreeTREES-2M4"
"assume p inTARSKIR2 domRELAT-1K1 T func T with-replacementTREES-2K7(p,T1) \<rightarrow> DecoratedTreeTREES-2M4 means
  \<lambda>it. domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
proof-
  (*existence*)
    show "p inTARSKIR2 domRELAT-1K1 T implies ( ex it be DecoratedTreeTREES-2M4 st domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
    proof(rule impI)
      assume Assume: "p inTARSKIR2 domRELAT-1K1 T"
      have A1: "p inTARSKIR2 domRELAT-1K1 T"
        using Assume sorry
      show " ex it be DecoratedTreeTREES-2M4 st domRELAT-1K1 it =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
      proof-
        have " ex TT be DecoratedTreeTREES-2M4 st domRELAT-1K1 TT =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & TT .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & TT .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
        proof-
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  not p is-a-prefix-ofTREES-1R2 Lamb1 & Lamb2 =XBOOLE-0R4 T .FUNCT-1K1 Lamb1 or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & Lamb1 =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & Lamb2 =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
          have A2: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies ( ex x be setHIDDENM2 st ?X(q,x))"
          proof-
            have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
            proof(rule ballI,rule impI)
              fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              assume A3: "q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1)"
              have " not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
              proof-
                show " not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                proof-
                  have cases: "(p is-a-proper-prefix-ofTREES-1R3 q or p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q) or  not p is-a-prefix-ofTREES-1R2 q"
                     sorry
                  have case1: "p is-a-proper-prefix-ofTREES-1R3 q implies  not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                  proof(rule impI)
                    assume "p is-a-proper-prefix-ofTREES-1R3 q"
                    then obtain r where
                      [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                      A4: "r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                      using A1 A3 trees_1_def_9 sorry
                    show " not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                    proof-
                      have " ex tVar29 be setHIDDENM2 st  not p is-a-prefix-ofTREES-1R2 q & tVar29 =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex rc be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (rc inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> rc) & tVar29 =XBOOLE-0R4 T1 .FUNCT-1K1 rc)"
                      proof-
                        show " ex tVar29 be setHIDDENM2 st  not p is-a-prefix-ofTREES-1R2 q & tVar29 =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex rc be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (rc inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> rc) & tVar29 =XBOOLE-0R4 T1 .FUNCT-1K1 rc)"
                        proof(rule bexI[of _ "T1 .FUNCT-1K1 r"])
                          show " not p is-a-prefix-ofTREES-1R2 q & T1 .FUNCT-1K1 r =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex rc be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (rc inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> rc) & T1 .FUNCT-1K1 r =XBOOLE-0R4 T1 .FUNCT-1K1 rc)"
                            using A4 sorry
                        qed "sorry"
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                  qed
                  have case2: "p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q implies  not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                  proof(rule impI)
                    assume A5: "p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q"
                    show " not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                    proof-
                      have " ex tVar30 be setHIDDENM2 st  not p is-a-prefix-ofTREES-1R2 q & tVar30 =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & tVar30 =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
                      proof-
                        show " ex tVar30 be setHIDDENM2 st  not p is-a-prefix-ofTREES-1R2 q & tVar30 =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & tVar30 =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
                        proof(rule bexI[of _ "T1 .FUNCT-1K1 {}SUBSET-1K1 NATNUMBERSK1"])
                          have "{}SUBSET-1K1 NATNUMBERSK1 inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> <*>FINSEQ-1K7 NATNUMBERSK1"
                            using A5 finseq_1_th_34 trees_1_th_22 sorry
                          thus " not p is-a-prefix-ofTREES-1R2 q & T1 .FUNCT-1K1 {}SUBSET-1K1 NATNUMBERSK1 =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & T1 .FUNCT-1K1 {}SUBSET-1K1 NATNUMBERSK1 =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
                             sorry
                        qed "sorry"
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                  qed
                  have case3: " not p is-a-prefix-ofTREES-1R2 q implies  not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                  proof(rule impI)
                    assume " not p is-a-prefix-ofTREES-1R2 q"
                    thus " not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                       sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 case3 sorry
                qed
              qed
              thus " not ( for x be setHIDDENM2 holds  not ( not p is-a-prefix-ofTREES-1R2 q & x =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & x =XBOOLE-0R4 T1 .FUNCT-1K1 r)))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          show " ex TT be DecoratedTreeTREES-2M4 st domRELAT-1K1 TT =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & TT .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & TT .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))"
            using trees_2_sch_6 A2 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p inTARSKIR2 domRELAT-1K1 T implies ( for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds (domRELAT-1K1 it1 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) & (domRELAT-1K1 it2 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p inTARSKIR2 domRELAT-1K1 T"
      have A1: "p inTARSKIR2 domRELAT-1K1 T"
        using Assume sorry
      show " for it1 be DecoratedTreeTREES-2M4 holds  for it2 be DecoratedTreeTREES-2M4 holds (domRELAT-1K1 it1 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) & (domRELAT-1K1 it2 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & it2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & it2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r))) implies it1 =HIDDENR1 it2"
      proof-
        have " for D1 be DecoratedTreeTREES-2M4 holds  for D2 be DecoratedTreeTREES-2M4 holds domRELAT-1K1 D1 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & (( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)) & (domRELAT-1K1 D2 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & ( for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)))) implies D1 =HIDDENR1 D2"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix D1 assume [ty]: "D1 be DecoratedTreeTREES-2M4"
          fix D2 assume [ty]: "D2 be DecoratedTreeTREES-2M4"
          assume A6: "domRELAT-1K1 D1 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1)"
            and A7: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
            and A8: "domRELAT-1K1 D2 =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1)"
            and A9: " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) implies  not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
          have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds q inTARSKIR2 domRELAT-1K1 D1 & D1 .FUNCT-1K1 q <>HIDDENR2 D2 .FUNCT-1K1 q implies  False "
          proof(rule ballI,rule impMI ,rule impI)
            fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            assume A10: "q inTARSKIR2 domRELAT-1K1 D1"
              and A11: "D1 .FUNCT-1K1 q <>HIDDENR2 D2 .FUNCT-1K1 q"
            have A12: " not p is-a-prefix-ofTREES-1R2 q & D1 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D1 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
              using A6 A7 A10 sorry
            have " not p is-a-prefix-ofTREES-1R2 q & D2 .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T1 & q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & D2 .FUNCT-1K1 q =XBOOLE-0R4 T1 .FUNCT-1K1 r)"
              using A6 A9 A10 sorry
            thus " False "
              using A11 A12 finseq_1_th_33 trees_1_th_1 sorry
          qed "sorry"
          thus "D1 =HIDDENR1 D2"
            using A6 A8 trees_2_th_31 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem trees_2_cl_11:
  mlet "W be TreeTREES-1M1", "x be setHIDDENM2"
"cluster W -->FUNCOP-1K7 x as-term-is DecoratedTree-likeTREES-2V3"
proof
(*coherence*)
  show "W -->FUNCOP-1K7 x be DecoratedTree-likeTREES-2V3"
    using funcop_1_th_13 sorry
qed "sorry"

mtheorem trees_2_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D implies x be TreeTREES-1M1) implies unionTARSKIK3 D be TreeTREES-1M1"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D implies x be TreeTREES-1M1) implies unionTARSKIK3 D be TreeTREES-1M1"
  proof(rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume A1: " for x be setHIDDENM2 holds x inTARSKIR2 D implies x be TreeTREES-1M1"
    then obtain x where 
      [ty]:"x be TreeTREES-1M1" and xDef:"x = the ElementSUBSET-1M1-of D"
       sorry
    have "x c=TARSKIR1 unionTARSKIK3 D"
      using zfmisc_1_th_74 sorry
    then obtain T where 
      [ty]:"T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and TDef:"T = unionTARSKIK3 D"
       sorry
    have "T be Tree-likeTREES-1V1"
    proof-
      have Cut1700: " for X be setHIDDENM2 holds X inTARSKIR2 D implies X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        assume "X inTARSKIR2 D"
        then have "X be TreeTREES-1M1"
          using A1 sorry
        thus "X c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
          using trees_1_def_3 sorry
      qed "sorry"
      have "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies ProperPrefixesTREES-1K1 p c=TARSKIR1 T) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T & n <=XXREAL-0R1 k implies p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T))"
      proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        show "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
          using zfmisc_1_th_76 Cut1700 sorry
        show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies ProperPrefixesTREES-1K1 p c=TARSKIR1 T"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume "p inTARSKIR2 T"
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A2: "p inTARSKIR2 X"and A3: "X inTARSKIR2 D"
            using tarski_def_4 sorry
          have 
            [ty]:"X be TreeTREES-1M1"
            using A1 A3 sorry
          have "ProperPrefixesTREES-1K1 p c=TARSKIR1 X & X c=TARSKIR1 T"
            using A2 A3 trees_1_def_3 zfmisc_1_th_74 sorry
          thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 T"
             sorry
        qed "sorry"
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        fix k assume [ty]: "k be NatNAT-1M1"
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T"
          and A5: "n <=XXREAL-0R1 k"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A6: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 X"and A7: "X inTARSKIR2 D"
          using A4 tarski_def_4 sorry
        have 
          [ty]:"X be TreeTREES-1M1"
          using A1 A7 sorry
        have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 X"
          using A5 A6 trees_1_def_3 sorry
        thus "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
          using A7 tarski_def_4 sorry
      qed "sorry"
      thus "T be Tree-likeTREES-1V1"
        using trees_1_def_3 sorry
    qed
    thus "unionTARSKIK3 D be TreeTREES-1M1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_34:
" for X be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies x be FunctionFUNCT-1M1) & X be c=-linearORDINAL1V6 implies unionTARSKIK3 X be Relation-likeRELAT-1V1\<bar>Function-likeFUNCT-1V1"
proof-
  have " for X be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies x be FunctionFUNCT-1M1) & X be c=-linearORDINAL1V6 implies unionTARSKIK3 X be Relation-likeRELAT-1V1 & unionTARSKIK3 X be Function-likeFUNCT-1V1"
  proof(rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for x be setHIDDENM2 holds x inTARSKIR2 X implies x be FunctionFUNCT-1M1"
      and A2: "X be c=-linearORDINAL1V6"
    have "( for a be objectHIDDENM1 holds a inHIDDENR3 unionTARSKIK3 X implies ( ex b be objectHIDDENM1 st  ex c be objectHIDDENM1 st [TARSKIK4 b,c ] =HIDDENR1 a)) & unionTARSKIK3 X be Function-likeFUNCT-1V1"
    proof(rule conjMI)
      show " for a be objectHIDDENM1 holds a inHIDDENR3 unionTARSKIK3 X implies ( ex b be objectHIDDENM1 st  ex c be objectHIDDENM1 st [TARSKIK4 b,c ] =HIDDENR1 a)"
      proof-
        have " for a be objectHIDDENM1 holds a inHIDDENR3 unionTARSKIK3 X implies  not ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not [TARSKIK4 b,c ] =HIDDENR1 a)"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 unionTARSKIK3 X"
          then obtain x where
            [ty]:"x be setHIDDENM2" and 
            A3: "a inHIDDENR3 x"and A4: "x inTARSKIR2 X"
            using tarski_def_4 sorry
          have 
            [ty]:"x be FunctionFUNCT-1M1"
            using A1 A4 sorry
          have "x =FUNCT-1R1 x"
             sorry
          thus " not ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not [TARSKIK4 b,c ] =HIDDENR1 a)"
            using A3 relat_1_def_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 unionTARSKIK3 X & [TARSKIK4 a,c ] inHIDDENR3 unionTARSKIK3 X implies b =HIDDENR1 c"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A5: "[TARSKIK4 a,b ] inHIDDENR3 unionTARSKIK3 X"
          and A6: "[TARSKIK4 a,c ] inHIDDENR3 unionTARSKIK3 X"
        obtain x where
          [ty]:"x be setHIDDENM2" and 
          A7: "[TARSKIK4 a,b ] inHIDDENR3 x"and A8: "x inTARSKIR2 X"
          using A5 tarski_def_4 sorry
        obtain y where
          [ty]:"y be setHIDDENM2" and 
          A9: "[TARSKIK4 a,c ] inHIDDENR3 y"and A10: "y inTARSKIR2 X"
          using A6 tarski_def_4 sorry
        have 
          [ty]:"x be FunctionFUNCT-1M1"
          using A1 A8 sorry
        have 
          [ty]:"y be FunctionFUNCT-1M1"
          using A1 A10 sorry
        have "(x,y)are-c=-comparableXBOOLE-0R3"
          using A2 A8 A10 sorry
        then have "x c=RELAT-1R2 y or y c=RELAT-1R2 x"
           sorry
        thus "b =HIDDENR1 c"
          using A7 A9 funct_1_def_1 sorry
      qed "sorry"
      thus "unionTARSKIK3 X be Function-likeFUNCT-1V1"
        using funct_1_def_1 sorry
    qed
    thus "unionTARSKIK3 X be Relation-likeRELAT-1V1 & unionTARSKIK3 X be Function-likeFUNCT-1V1"
      using relat_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D implies x be DecoratedTreeTREES-2M4) & D be c=-linearORDINAL1V6 implies unionTARSKIK3 D be DecoratedTreeTREES-2M4"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D implies x be DecoratedTreeTREES-2M4) & D be c=-linearORDINAL1V6 implies unionTARSKIK3 D be DecoratedTreeTREES-2M4"
  proof(rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume A1: " for x be setHIDDENM2 holds x inTARSKIR2 D implies x be DecoratedTreeTREES-2M4"
      and A2: "D be c=-linearORDINAL1V6"
    have " for x be setHIDDENM2 holds x inTARSKIR2 D implies x be FunctionFUNCT-1M1"
      using A1 sorry
    then obtain T where 
      [ty]:"T be FunctionFUNCT-1M1" and TDef:"T = unionTARSKIK3 D"
      using A2 trees_2_th_34 sorry
    let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  ex T1 be DecoratedTreeTREES-2M4 st Lamb1 =HIDDENR1 T1 & domRELAT-1K1 T1 =HIDDENR1 Lamb2"
    have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 D implies ( ex y be objectHIDDENM1 st ?X(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 D implies  not ( for y be objectHIDDENM1 holds  not ( ex T1 be DecoratedTreeTREES-2M4 st x =HIDDENR1 T1 & domRELAT-1K1 T1 =HIDDENR1 y))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 D"
        then obtain T1 where 
          [ty]:"T1 be DecoratedTreeTREES-2M4" and T1Def:"T1 = x"
          using A1 sorry
        have "domRELAT-1K1 T1 =TREES-2R1 domRELAT-1K1 T1"
           sorry
        thus " not ( for y be objectHIDDENM1 holds  not ( ex T1 be DecoratedTreeTREES-2M4 st x =HIDDENR1 T1 & domRELAT-1K1 T1 =HIDDENR1 y))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A4: "domRELAT-1K1 f =XBOOLE-0R4 D & ( for x be objectHIDDENM1 holds x inHIDDENR3 D implies ?X(x,f .FUNCT-1K1 x))"
      using classes1_sch_1 A3 sorry
    obtain E where 
      [ty]:"E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and EDef:"E = rngFUNCT-1K2 f"
      using A4 relat_1_th_42 sorry
    have " for x be setHIDDENM2 holds x inTARSKIR2 E implies x be TreeTREES-1M1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      assume "x inTARSKIR2 E"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A5: "y inHIDDENR3 domRELAT-1K1 f & x =XBOOLE-0R4 f .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      have " ex T1 be DecoratedTreeTREES-2M4 st y =HIDDENR1 T1 & domRELAT-1K1 T1 =XBOOLE-0R4 x"
        using A4 A5 sorry
      thus "x be TreeTREES-1M1"
         sorry
    qed "sorry"
    then have A6: "unionTARSKIK3 E be TreeTREES-1M1"
      using trees_2_th_33 sorry
    have "domRELAT-1K1 T =XBOOLE-0R4 unionTARSKIK3 E"
    proof-
      have "domRELAT-1K1 T c=TARSKIR1 unionTARSKIK3 E & unionTARSKIK3 E c=TARSKIR1 domRELAT-1K1 T"
      proof(rule conjMI)
        show "domRELAT-1K1 T c=TARSKIR1 unionTARSKIK3 E"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 T implies x inHIDDENR3 unionTARSKIK3 E"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 domRELAT-1K1 T"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A7: "[TARSKIK4 x,y ] inHIDDENR3 T"
              using xtuple_0_def_12 sorry
            obtain X where
              [ty]:"X be setHIDDENM2" and 
              A8: "[TARSKIK4 x,y ] inHIDDENR3 X"and A9: "X inTARSKIR2 D"
              using A7 tarski_def_4 sorry
            obtain T1 where
              [ty]:"T1 be DecoratedTreeTREES-2M4" and 
              A10: "X =XBOOLE-0R4 T1"and A11: "domRELAT-1K1 T1 =XBOOLE-0R4 f .FUNCT-1K1 X"
              using A4 A9 sorry
            have A12: "domRELAT-1K1 T1 inTARSKIR2 rngFUNCT-1K2 f"
              using A4 A9 A11 funct_1_def_3 sorry
            have A13: "x inHIDDENR3 domRELAT-1K1 T1"
              using A8 A10 xtuple_0_def_12 sorry
            have "domRELAT-1K1 T1 c=TARSKIR1 unionTARSKIK3 E"
              using A12 zfmisc_1_th_74 sorry
            thus "x inHIDDENR3 unionTARSKIK3 E"
              using A13 sorry
          qed "sorry"
          thus "domRELAT-1K1 T c=TARSKIR1 unionTARSKIK3 E"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 E implies x inHIDDENR3 domRELAT-1K1 T"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 unionTARSKIK3 E"
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A14: "x inHIDDENR3 X"and A15: "X inTARSKIR2 E"
            using tarski_def_4 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A16: "y inHIDDENR3 domRELAT-1K1 f"and A17: "X =XBOOLE-0R4 f .FUNCT-1K1 y"
            using A15 funct_1_def_3 sorry
          obtain T1 where
            [ty]:"T1 be DecoratedTreeTREES-2M4" and 
            A18: "y =HIDDENR1 T1"and A19: "domRELAT-1K1 T1 =XBOOLE-0R4 X"
            using A4 A16 A17 sorry
          have "[TARSKIK4 x,T1 .FUNCT-1K1 x ] inHIDDENR3 T1"
            using A14 A19 funct_1_th_1 sorry
          then have "[TARSKIK4 x,T1 .FUNCT-1K1 x ] inHIDDENR3 unionTARSKIK3 D"
            using A4 A16 A18 tarski_def_4 sorry
          thus "x inHIDDENR3 domRELAT-1K1 T"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "unionTARSKIK3 E c=TARSKIR1 domRELAT-1K1 T"
          using tarski_def_3 sorry
      qed
      thus "domRELAT-1K1 T =XBOOLE-0R4 unionTARSKIK3 E"
        using xboole_0_def_10 sorry
    qed
    thus "unionTARSKIK3 D be DecoratedTreeTREES-2M4"
      using A6 trees_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_2_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D9 implies x be DecoratedTreeTREES-2M5-of D) & D9 be c=-linearORDINAL1V6 implies unionTARSKIK3 D9 be DecoratedTreeTREES-2M5-of D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 D9 implies x be DecoratedTreeTREES-2M5-of D) & D9 be c=-linearORDINAL1V6 implies unionTARSKIK3 D9 be DecoratedTreeTREES-2M5-of D"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D9 assume [ty]: "D9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume A1: " for x be setHIDDENM2 holds x inTARSKIR2 D9 implies x be DecoratedTreeTREES-2M5-of D"
      and A2: "D9 be c=-linearORDINAL1V6"
    have " for x be setHIDDENM2 holds x inTARSKIR2 D9 implies x be DecoratedTreeTREES-2M4"
      using A1 sorry
    then obtain T where 
      [ty]:"T be DecoratedTreeTREES-2M4" and TDef:"T = unionTARSKIK3 D9"
      using A2 trees_2_th_35 sorry
    have "rngFUNCT-1K2 T c=TARSKIR1 D"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 T implies x inHIDDENR3 D"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 T"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "y inHIDDENR3 domRELAT-1K1 T & x =HIDDENR1 T .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 T"
          using A3 funct_1_th_1 sorry
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A4: "[TARSKIK4 y,x ] inHIDDENR3 X"and A5: "X inTARSKIR2 D9"
          using tarski_def_4 sorry
        have 
          [ty]:"X be DecoratedTreeTREES-2M5-of D"
          using A1 A5 sorry
        have "y inHIDDENR3 domRELAT-1K1 X & x =HIDDENR1 X .FUNCT-1K1 y"
          using A4 funct_1_th_1 sorry
        then have A6: "x inHIDDENR3 rngRELSET-1K2\<^bsub>(D)\<^esub> X"
          using funct_1_def_3 sorry
        show "x inHIDDENR3 D"
          using A6 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 T c=TARSKIR1 D"
        using tarski_def_3 sorry
    qed
    thus "unionTARSKIK3 D9 be DecoratedTreeTREES-2M5-of D"
      using relat_1_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem trees_2_sch_8:
  fixes Df0 df0 Ff1 Sf0 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "df0 be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty]: "Sf0 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Df0,NATNUMBERSK1 :],Df0)" and
   A1: " for d be ElementSUBSET-1M1-of Df0 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <=XXREAL-0R1 k2 & k2 inTARSKIR2 Ff1(d) implies k1 inTARSKIR2 Ff1(d)"
  shows " ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
  proof-
    have " ex tVar37 be DecoratedTreeTREES-2M5-of Df0 st tVar37 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar37 holds succTREES-2K1\<^bsub>(domRELAT-1K1 tVar37)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(tVar37 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 Ff1(tVar37 .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not tVar37 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(tVar37 .TREES-2K3\<^bsub>(Df0)\<^esub> t,n))))"
    proof-
      let ?P = "\<lambda>Lamb1.  ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 Lamb1 & (lenFINSEQ-1K4 t <XXREAL-0R3 Lamb1 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
      obtain W where 
        [ty]:"W be TreeTREES-1M1" and WDef:"W = {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      have A2: "?P(0NUMBERSK6)"
      proof-
        have " ex T1 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 W,Df0 :]) st T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELSET-1K1\<^bsub>(W)\<^esub> T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6 & (lenFINSEQ-1K4 t <XXREAL-0R3 0NUMBERSK6 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))))"
        proof-
          obtain T1 where 
            [ty]:"T1 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 W,Df0 :])" and T1Def:"T1 = W -->FUNCOP-1K8\<^bsub>(Df0)\<^esub> df0"
             sorry
          show " ex T1 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 W,Df0 :]) st T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELSET-1K1\<^bsub>(W)\<^esub> T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6 & (lenFINSEQ-1K4 t <XXREAL-0R3 0NUMBERSK6 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))))"
          proof(rule bexI[of _ "T1"],rule conjMI,rule ballI,rule conjMI,rule impI)
            have "{}XBOOLE-0K1 inTARSKIR2 W"
              using trees_1_th_22 sorry
            thus "T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0"
              using funcop_1_th_7 sorry
            fix t assume [ty]: "t be ElementTREES-1M2-of domRELSET-1K1\<^bsub>(W)\<^esub> T1"
            have "domRELSET-1K1\<^bsub>(W)\<^esub> T1 =TREES-2R1 W"
              using funcop_1_th_13 sorry
            then have "t =FINSEQ-1R1 {}XBOOLE-0K1"
              using tarski_def_1 sorry
            thus "lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6"
               sorry
            assume "lenFINSEQ-1K4 t <XXREAL-0R3 0NUMBERSK6"
            thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))"
               sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds ( ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : m inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))) implies ( ex tVar33 be DecoratedTreeTREES-2M5-of Df0 st tVar33 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar33 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & (lenFINSEQ-1K4 t <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies succTREES-2K1\<^bsub>(domRELAT-1K1 tVar33)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(tVar33 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar33 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not tVar33 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume Given: " ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : m inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
          then obtain T where
            [ty]:"T be DecoratedTreeTREES-2M5-of Df0" and 
            A4: "T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : m inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
             sorry
          obtain M where 
            [ty]:"M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and MDef:"M = ({t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) })\\/XBOOLE-0K2 domRELAT-1K1 T"
             sorry
          have "M be Tree-likeTREES-1V1"
          proof-
            have "M c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies ProperPrefixesTREES-1K1 p c=TARSKIR1 M) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 M implies (n <=XXREAL-0R1 m &  not p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 M implies  not  True )))"
            proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
              show "M c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 M implies ( not x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3 implies  not  True )"
                proof(rule ballI,rule impI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 M"
                  then have A5: "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } or x inHIDDENR3 domRELAT-1K1 T & domRELAT-1K1 T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                    using trees_1_def_3 xboole_0_def_3 sorry
                  assume A6: " not x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                  then obtain n t where
                    [ty]:"n be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                    A7: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                    using A5 sorry
                  have 
                    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    using ordinal1_def_12 sorry
                  have "x =HIDDENR1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
                    using A7 sorry
                  thus " not  True "
                    using A6 finseq_1_def_11 sorry
                qed "sorry"
                thus "M c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                  using tarski_def_3 sorry
              qed
              show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies ProperPrefixesTREES-1K1 p c=TARSKIR1 M"
              proof(rule ballI,rule impI)
                fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                assume "p inTARSKIR2 M"
                then have A8: "p inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } or p inTARSKIR2 domRELAT-1K1 T"
                  using xboole_0_def_3 sorry
                have "p inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 M"
                proof(rule impI)
                  assume "p inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  then obtain n t where
                    [ty]:"n be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                    A9: "p =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and "n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                     sorry
                  have A10: "ProperPrefixesTREES-1K1 t c=TARSKIR1 domRELAT-1K1 T"
                    using trees_1_def_3 sorry
                  have A11: "domRELAT-1K1 T c=TARSKIR1 M"
                    using xboole_1_th_7 sorry
                  have A12: "ProperPrefixesTREES-1K1 t c=TARSKIR1 M"
                    using A10 A11 sorry
                  have A13: "{TARSKIK1 t} c=TARSKIR1 M"
                    using A11 zfmisc_1_th_31 sorry
                  have "ProperPrefixesTREES-1K1 p =XBOOLE-0R4 ProperPrefixesTREES-1K1 t \\/XBOOLE-0K2 {TARSKIK1 t}"
                    using A9 trees_2_th_4 sorry
                  thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 M"
                    using A12 A13 xboole_1_th_8 sorry
                qed
                then have "ProperPrefixesTREES-1K1 p c=TARSKIR1 M or ProperPrefixesTREES-1K1 p c=TARSKIR1 domRELAT-1K1 T & domRELAT-1K1 T c=TARSKIR1 M"
                  using A8 trees_1_def_3 xboole_1_th_7 sorry
                thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 M"
                   sorry
              qed "sorry"
              fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              fix m assume [ty]: "m be NatNAT-1M1"
              fix n assume [ty]: "n be NatNAT-1M1"
              assume "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 M"
              then have A14: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } or p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 domRELAT-1K1 T"
                using xboole_0_def_3 sorry
              assume A15: "n <=XXREAL-0R1 m"
                and A16: " not p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 M"
              have " not p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T"
                using A16 xboole_0_def_3 sorry
              then obtain l t where
                [ty]:"l be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                A17: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A18: "l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                using A14 A15 trees_1_def_3 sorry
              have A19: "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 m*>) & lenFINSEQ-1K4 (<*FINSEQ-1K10 m*>) =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_22 finseq_1_th_40 sorry
              have A20: "lenFINSEQ-1K4 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)) =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) & lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_22 finseq_1_th_40 sorry
              have A21: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 m & (t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)).FUNCT-1K1 (lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 l"
                using finseq_1_th_42 sorry
              then have A22: "p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> t"
                using A17 A19 A20 finseq_1_th_33 sorry
              have "n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                using A1 A15 A17 A18 A19 A20 A21 sorry
              then have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                using A22 sorry
              thus " not  True "
                using A16 xboole_0_def_3 sorry
            qed "sorry"
            thus "M be Tree-likeTREES-1V1"
              using trees_1_def_3 sorry
          qed
          then have 
            [ty]:"M be TreeTREES-1M1"
             sorry
          let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 domRELAT-1K1 T & Lamb2 =XBOOLE-0R4 T .FUNCT-1K1 Lamb1 or  not Lamb1 inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st Lamb1 =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & Lamb2 =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))"
          have A23: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies ( ex x be setHIDDENM2 st ?P(p,x))"
          proof-
            have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies  not ( for x be setHIDDENM2 holds  not (p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))))"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              assume "p inTARSKIR2 M"
              then have A24: "p inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } or p inTARSKIR2 domRELAT-1K1 T"
                using xboole_0_def_3 sorry
              have " not p inTARSKIR2 domRELAT-1K1 T implies ( ex x be setHIDDENM2 st p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n)))"
              proof(rule impI)
                assume A25: " not p inTARSKIR2 domRELAT-1K1 T"
                then obtain l t where
                  [ty]:"l be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                  A26: "p =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and "l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                  using A24 sorry
                obtain x where 
                  [ty]:"x be setHIDDENM2" and xDef:"x = Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,l)"
                   sorry
                show " ex x be setHIDDENM2 st p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))"
                proof(rule bexI[of _ "x"])
                  show "p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))"
                    using A25 A26 sorry
                qed "sorry"
              qed
              thus " not ( for x be setHIDDENM2 holds  not (p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain T9 where
            [ty]:"T9 be DecoratedTreeTREES-2M4" and 
            A27: "domRELAT-1K1 T9 =TREES-2R1 M & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies ?P(p,T9 .FUNCT-1K1 p))"
            using trees_2_sch_6 A23 sorry
          have "rngFUNCT-1K2 T9 c=TARSKIR1 Df0"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 T9 implies x inHIDDENR3 Df0"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 T9"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A28: "y inHIDDENR3 domRELAT-1K1 T9"and A29: "x =HIDDENR1 T9 .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have 
                [ty]:"y be ElementTREES-1M2-of domRELAT-1K1 T9"
                using A28 sorry
              have A30: "y inTARSKIR2 domRELAT-1K1 T implies x inHIDDENR3 Df0"
              proof(rule impI)
                assume "y inTARSKIR2 domRELAT-1K1 T"
                then obtain t where 
                  [ty]:"t be ElementTREES-1M2-of domRELAT-1K1 T" and tDef:"t = y"
                   sorry
                have "T .TREES-2K3\<^bsub>(Df0)\<^esub> t inTARSKIR2 Df0"
                   sorry
                thus "x inHIDDENR3 Df0"
                  using A27 A29 sorry
              qed
              have " not y inTARSKIR2 domRELAT-1K1 T implies x inHIDDENR3 Df0"
              proof(rule impI)
                assume A31: " not y inTARSKIR2 domRELAT-1K1 T"
                then obtain n q where
                  [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                  A32: "y =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and A33: "T9 .FUNCT-1K1 y =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n)"
                  using A27 sorry
                have "y inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  using A27 A31 xboole_0_def_3 sorry
                then obtain l t where
                  [ty]:"l be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                  A34: "y =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and "l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                   sorry
                have A35: "lenFINSEQ-1K4 (<*FINSEQ-1K10 n*>) =XBOOLE-0R4 \<one>\<^sub>M"
                  using finseq_1_th_39 sorry
                have A36: "lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) =XBOOLE-0R4 \<one>\<^sub>M"
                  using finseq_1_th_39 sorry
                have A37: "lenFINSEQ-1K4 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
                  using A35 finseq_1_th_22 sorry
                have A38: "lenFINSEQ-1K4 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)) =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M"
                  using A36 finseq_1_th_22 sorry
                have "(q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)).FUNCT-1K1 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n & (t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)).FUNCT-1K1 (lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 l"
                  using finseq_1_th_42 sorry
                then have A39: "q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> t"
                  using A32 A34 A37 A38 finseq_1_th_33 sorry
                have A40: "n inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have "T .TREES-2K3\<^bsub>(Df0)\<^esub> t inTARSKIR2 Df0"
                   sorry
                then have "[TARSKIK4 T .FUNCT-1K1 q,n ] inHIDDENR3 [:ZFMISC-1K2 Df0,NATNUMBERSK1 :]"
                  using A39 zfmisc_1_th_87 A40 sorry
                thus "x inHIDDENR3 Df0"
                  using A29 A33 funct_2_th_5 sorry
              qed
              thus "x inHIDDENR3 Df0"
                using A30 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 T9 c=TARSKIR1 Df0"
              using tarski_def_3 sorry
          qed
          then have 
            [ty]:"T9 be DecoratedTreeTREES-2M5-of Df0"
            using relat_1_def_19 sorry
          show " ex tVar33 be DecoratedTreeTREES-2M5-of Df0 st tVar33 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar33 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & (lenFINSEQ-1K4 t <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies succTREES-2K1\<^bsub>(domRELAT-1K1 tVar33)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(tVar33 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar33 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not tVar33 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))))"
          proof(rule bexI[of _ "T9"],rule conjMI,rule ballI,rule conjMI,rule impI)
            have "<*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 M & <*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 domRELAT-1K1 T"
              using trees_1_th_22 sorry
            thus "T9 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0"
              using A4 A27 sorry
            fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T9"
            have A41: "t inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s) } implies lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            proof(rule impI)
              assume "t inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
              then obtain l s where
                [ty]:"l be NatNAT-1M1" "s be ElementTREES-1M2-of domRELAT-1K1 T" and 
                A42: "t =FINSEQ-1R1 s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and "l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s)"
                 sorry
              have "lenFINSEQ-1K4 s <=XXREAL-0R1 k"
                using A4 sorry
              then have "lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) =XBOOLE-0R4 \<one>\<^sub>M & lenFINSEQ-1K4 s +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using finseq_1_th_39 xreal_1_th_7 sorry
              thus "lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using A42 finseq_1_th_22 sorry
            qed
            have "t inTARSKIR2 domRELAT-1K1 T implies lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            proof(rule impI)
              assume "t inTARSKIR2 domRELAT-1K1 T"
              then obtain s where 
                [ty]:"s be ElementTREES-1M2-of domRELAT-1K1 T" and sDef:"s = t"
                 sorry
              have "lenFINSEQ-1K4 s <=XXREAL-0R1 k & k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using A4 nat_1_th_11 sorry
              thus "lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using xxreal_0_th_2 sorry
            qed
            thus "lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              using A27 A41 xboole_0_def_3 sorry
            assume A43: "lenFINSEQ-1K4 t <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
            have A44: " not t inTARSKIR2 domRELAT-1K1 T implies  False "
            proof(rule impI)
              assume A45: " not t inTARSKIR2 domRELAT-1K1 T"
              then have "t inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                using A27 xboole_0_def_3 sorry
              then obtain l s where
                [ty]:"l be NatNAT-1M1" "s be ElementTREES-1M2-of domRELAT-1K1 T" and 
                A46: "t =FINSEQ-1R1 s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A47: "l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s)"
                 sorry
              have A48: "lenFINSEQ-1K4 t =XBOOLE-0R4 lenFINSEQ-1K4 s +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>)"
                using A46 finseq_1_th_22 sorry
              have "lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) =XBOOLE-0R4 \<one>\<^sub>M & lenFINSEQ-1K4 t <=XXREAL-0R1 k"
                using A43 finseq_1_th_39 nat_1_th_13 sorry
              then have "lenFINSEQ-1K4 s <XXREAL-0R3 k"
                using A48 nat_1_th_13 sorry
              then have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> s =XBOOLE-0R4 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : m inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                using A4 sorry
              then have "t inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> s"
                using A46 A47 sorry
              thus " False "
                using A45 sorry
            qed
            then have A49: "T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t =XBOOLE-0R4 T .FUNCT-1K1 t"
              using A27 sorry
            obtain t9 where 
              [ty]:"t9 be ElementTREES-1M2-of domRELAT-1K1 T" and t9Def:"t9 = t"
              using A44 sorry
            have "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ({t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))"
            proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
              show "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
              proof-
                have "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                proof-
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                    then obtain n where
                      [ty]:"n be NatNAT-1M1" and 
                      A50: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and A51: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T9"
                       sorry
                    have "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                    proof-
                      show "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                      proof-
                        have cases: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T or  not t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T"
                           sorry
                        have case1: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                        proof(rule impI)
                          assume A52: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T"
                          then obtain s t9 where 
                            [ty]:"s be ElementTREES-1M2-of domRELAT-1K1 T" and sDef:"s = t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)" and
                            [ty]:"t9 be ElementTREES-1M2-of domRELAT-1K1 T" and t9Def:"t9 = t"
                            using trees_1_th_21 sorry
                          have "lenFINSEQ-1K4 s <=XXREAL-0R1 k & lenFINSEQ-1K4 s =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M"
                            using A4 finseq_2_th_16 sorry
                          then have "lenFINSEQ-1K4 t <XXREAL-0R3 k"
                            using nat_1_th_13 sorry
                          then have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t9 =XBOOLE-0R4 {t9 ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : m inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t9) }"
                            using A4 sorry
                          thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                            using A49 A50 A52 sorry
                        qed
                        have case2: " not t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                        proof(rule impI)
                          assume " not t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T"
                          then have "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                            using A27 A51 xboole_0_def_3 sorry
                          then obtain l s where
                            [ty]:"l be NatNAT-1M1" "s be ElementTREES-1M2-of domRELAT-1K1 T" and 
                            A53: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) =FINSEQ-1R1 s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A54: "l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s)"
                             sorry
                          have "t =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> s"
                            using A53 finseq_2_th_17 sorry
                          thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                            using A49 A50 A53 A54 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                       sorry
                  qed "sorry"
                  thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              show A55: "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
              proof-
                have "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                proof-
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } implies x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                    then obtain n where
                      [ty]:"n be NatNAT-1M1" and 
                      A56: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and A57: "n inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                       sorry
                    have "x =HIDDENR1 t9 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
                      using A56 sorry
                    then have "x inHIDDENR3 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                      using A49 A57 sorry
                    then have "x inHIDDENR3 domRELAT-1K1 T9"
                      using A27 xboole_0_def_3 sorry
                    thus "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                      using A56 sorry
                  qed "sorry"
                  thus "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              fix n assume [ty]: "n be NatNAT-1M1"
              fix x assume [ty]: "x be setHIDDENM2"
              assume A58: "x =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t"
                and A59: "n inTARSKIR2 Ff1(x)"
              have "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                using A58 A59 sorry
              then have A60: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                using A55 sorry
              have 
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
              proof-
                show "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                proof-
                  have cases: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T or  not t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T"
                     sorry
                  have case1: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T implies T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                  proof(rule impI)
                    assume A61: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T"
                    then obtain s where 
                      [ty]:"s be ElementTREES-1M2-of domRELAT-1K1 T" and sDef:"s = t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
                       sorry
                    have "lenFINSEQ-1K4 s <=XXREAL-0R1 k & lenFINSEQ-1K4 s =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M"
                      using A4 finseq_2_th_16 sorry
                    then have "lenFINSEQ-1K4 t9 <XXREAL-0R3 k"
                      using nat_1_th_13 sorry
                    then have "T .FUNCT-1K1 (t9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                      using A4 A49 A58 A59 sorry
                    thus "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                      using A27 A60 A61 sorry
                  qed
                  have case2: " not t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T implies T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                  proof(rule impI)
                    assume " not t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T"
                    then obtain l q where
                      [ty]:"l be NatNAT-1M1" "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                      A62: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A63: "T9 .FUNCT-1K1 (t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,l)"
                      using A27 A60 sorry
                    have "t =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q & n =XBOOLE-0R4 l"
                      using A62 finseq_2_th_17 sorry
                    thus "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                      using A27 A44 A58 A63 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                 sorry
            qed "sorry"
            thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))"
              using xboole_0_def_10 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A64: " for k be NatNAT-1M1 holds ?P(k)"
        using nat_1_sch_2 A2 A3 sorry
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex T be DecoratedTreeTREES-2M5-of Df0 st  ex k be NatNAT-1M1 st ((Lamb1 =HIDDENR1 k & Lamb2 =HIDDENR1 T) & T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
      have A65: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex tVar34 be objectHIDDENM1 st  ex tVar35 be DecoratedTreeTREES-2M5-of Df0 st  ex tVar36 be NatNAT-1M1 st ((x =HIDDENR1 tVar36 & tVar34 =HIDDENR1 tVar35) & tVar35 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar35 holds lenFINSEQ-1K4 t <=XXREAL-0R1 tVar36 &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 tVar36 &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 tVar35)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(tVar35 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar35 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not tVar35 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))))))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 NATNUMBERSK1"
          then obtain N where 
            [ty]:"N be NatNAT-1M1" and NDef:"N = x"
             sorry
          obtain T where
            [ty]:"T be DecoratedTreeTREES-2M5-of Df0" and 
            A66: "T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 N & (lenFINSEQ-1K4 t <XXREAL-0R3 N implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A64 sorry
          obtain y where 
            [ty]:"y be setHIDDENM2" and yDef:"y = T"
             sorry
          show " ex tVar34 be objectHIDDENM1 st  ex tVar35 be DecoratedTreeTREES-2M5-of Df0 st  ex tVar36 be NatNAT-1M1 st ((x =HIDDENR1 tVar36 & tVar34 =HIDDENR1 tVar35) & tVar35 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar35 holds lenFINSEQ-1K4 t <=XXREAL-0R1 tVar36 &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 tVar36 &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 tVar35)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(tVar35 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar35 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not tVar35 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
          proof(rule bexI[of _ "y"])
            show " ex tVar35 be DecoratedTreeTREES-2M5-of Df0 st  ex tVar36 be NatNAT-1M1 st ((x =HIDDENR1 tVar36 & y =HIDDENR1 tVar35) & tVar35 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar35 holds lenFINSEQ-1K4 t <=XXREAL-0R1 tVar36 &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 tVar36 &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 tVar35)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(tVar35 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar35 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not tVar35 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
            proof(rule bexI[of _ "T"])
              show " ex tVar36 be NatNAT-1M1 st ((x =HIDDENR1 tVar36 & y =HIDDENR1 T) & T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 tVar36 &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 tVar36 &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
              proof(rule bexI[of _ "N"])
                show "((x =HIDDENR1 N & y =HIDDENR1 T) & T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 N &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 N &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x)) &  not T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
                  using A66 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A67: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,f .FUNCT-1K1 x))"
        using classes1_sch_1 A65 sorry
      have A68: " for x be NatNAT-1M1 holds ?P(x,f .FUNCT-1K1 x)"
        using ordinal1_def_12 A67 sorry
      obtain E where 
        [ty]:"E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and EDef:"E = rngFUNCT-1K2 f"
        using A67 relat_1_th_42 sorry
      have A69: " for x be setHIDDENM2 holds x inTARSKIR2 E implies x be DecoratedTreeTREES-2M5-of Df0"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 E"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A70: "y inHIDDENR3 domRELAT-1K1 f"and A71: "x =XBOOLE-0R4 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have " ex T be DecoratedTreeTREES-2M5-of Df0 st  ex k be NatNAT-1M1 st ((y =HIDDENR1 k & f .FUNCT-1K1 y =XBOOLE-0R4 T) & T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
          using A67 A70 sorry
        thus "x be DecoratedTreeTREES-2M5-of Df0"
          using A71 sorry
      qed "sorry"
      have A72: " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (T1 =XBOOLE-0R4 f .FUNCT-1K1 k1 & T2 =XBOOLE-0R4 f .FUNCT-1K1 k2) & k1 <=XXREAL-0R1 k2 implies T1 c=RELAT-1R2 T2"
      proof-
        have " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds  for x be NatNAT-1M1 holds  for y be NatNAT-1M1 holds T1 =XBOOLE-0R4 f .FUNCT-1K1 x & (T2 =XBOOLE-0R4 f .FUNCT-1K1 y & x <=XXREAL-0R1 y) implies T1 c=RELAT-1R2 T2"
        proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
          fix T2 assume [ty]: "T2 be DecoratedTreeTREES-2M4"
          fix x assume [ty]: "x be NatNAT-1M1"
          fix y assume [ty]: "y be NatNAT-1M1"
          assume A73: "T1 =XBOOLE-0R4 f .FUNCT-1K1 x"
            and A74: "T2 =XBOOLE-0R4 f .FUNCT-1K1 y"
            and A75: "x <=XXREAL-0R1 y"
          obtain T19 k1 where
            [ty]:"T19 be DecoratedTreeTREES-2M5-of Df0" "k1 be NatNAT-1M1" and 
            A76: "((x =XBOOLE-0R4 k1 & f .FUNCT-1K1 x =XBOOLE-0R4 T19) & T19 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T19 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k1 & (lenFINSEQ-1K4 t <XXREAL-0R3 k1 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T19)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T19 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T19 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T19 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A68 sorry
          obtain T29 k2 where
            [ty]:"T29 be DecoratedTreeTREES-2M5-of Df0" "k2 be NatNAT-1M1" and 
            A77: "((y =XBOOLE-0R4 k2 & f .FUNCT-1K1 y =XBOOLE-0R4 T29) & T29 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T29 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k2 & (lenFINSEQ-1K4 t <XXREAL-0R3 k2 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T29)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T29 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T29 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T29 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A68 sorry
          let ?I = "\<lambda>Lamb1.  for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 Lamb1 implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
          have A78: "?I(0NUMBERSK6)"
          proof-
            have " for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6 implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
            proof(rule ballI,rule impI)
              fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T1"
              assume A79: "lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6"
              have "t =FINSEQ-1R1 {}XBOOLE-0K1"
                using A79 sorry
              thus "t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
                using A73 A74 A76 A77 trees_1_th_22 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A80: " for k be NatNAT-1M1 holds ?I(k) implies ?I(k +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for k be NatNAT-1M1 holds ( for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t) implies ( for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t)"
            proof(rule ballI,rule impI,rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A81: " for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
              fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T1"
              assume "lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              then have A82: "lenFINSEQ-1K4 t <=XXREAL-0R1 k or lenFINSEQ-1K4 t =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_8 sorry
              have "lenFINSEQ-1K4 t =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
              proof(rule impI)
                assume A83: "lenFINSEQ-1K4 t =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                obtain p where 
                  [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and pDef:"p = t  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 k"
                  using finseq_1_th_18 sorry
                have "p is-a-prefix-ofTREES-1R2 t"
                   sorry
                then have 
                  [ty]:"p be ElementTREES-1M2-of domRELAT-1K1 T1"
                  using trees_1_th_20 sorry
                have A84: "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                have A85: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k1"
                  using A73 A76 A83 sorry
                have A86: "lenFINSEQ-1K4 p =XBOOLE-0R4 k"
                  using A83 A84 finseq_1_th_17 sorry
                have A87: "k <XXREAL-0R3 k1"
                  using A85 nat_1_th_13 sorry
                have A88: "T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p"
                  using A81 A86 sorry
                obtain p9 where 
                  [ty]:"p9 be ElementTREES-1M2-of domRELAT-1K1 T2" and p9Def:"p9 = p"
                  using A81 A86 sorry
                have "t <>HIDDENR2 {}XBOOLE-0K1"
                  using A83 sorry
                then obtain q x where
                  [ty]:"q be FinSequenceFINSEQ-1M1" "x be objectHIDDENM1" and 
                  A89: "t =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
                  using finseq_1_th_46 sorry
                have A90: "p is-a-prefix-ofTREES-1R2 t & q is-a-prefix-ofTREES-1R2 t"
                  using A89 trees_1_th_1 sorry
                have "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
                  using A83 A89 finseq_2_th_16 sorry
                then have A91: "p =FINSEQ-1R1 q"
                  using A86 A90 trees_2_th_1 trees_1_th_4 sorry
                have "<*FINSEQ-1K10 x*> be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  using A89 finseq_1_th_36 sorry
                then have A92: "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) c=TARSKIR1 NATNUMBERSK1"
                  using finseq_1_def_4 sorry
                have "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 x} & x inHIDDENR3 {TARSKIK1 x}"
                  using finseq_1_th_38 tarski_def_1 sorry
                then have 
                  [ty]:"x be NatNAT-1M1"
                  using A92 sorry
                have A93: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> p"
                  using A89 A91 sorry
                have "succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> p =XBOOLE-0R4 {p ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T1 .FUNCT-1K1 p) }"
                  using A73 A76 A86 A87 sorry
                then obtain i where
                  [ty]:"i be NatNAT-1M1" and 
                  A94: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>)"and A95: "i inTARSKIR2 Ff1(T1 .FUNCT-1K1 p)"
                  using A93 sorry
                have A96: "k <XXREAL-0R3 k2"
                  using A75 A76 A77 A87 xxreal_0_th_2 sorry
                then have A97: "succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> p9 =XBOOLE-0R4 {p9 ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1 : l inTARSKIR2 Ff1(T2 .FUNCT-1K1 p9) }"
                  using A74 A77 A86 sorry
                have A98: "x =XBOOLE-0R4 i"
                  using A94 finseq_2_th_17 sorry
                have A99: "t inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> p9"
                  using A88 A89 A91 A94 A95 A97 sorry
                have "T19 .FUNCT-1K1 t =XBOOLE-0R4 Sf0 .BINOP-1K1(T19 .FUNCT-1K1 p,x)"
                  using A73 A76 A86 A87 A89 A91 A95 A98 sorry
                thus "t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
                  using A73 A74 A76 A77 A86 A88 A89 A91 A95 A96 A98 A99 sorry
              qed
              thus "t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
                using A81 A82 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A100: " for k be NatNAT-1M1 holds ?I(k)"
            using nat_1_sch_2 A78 A80 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 T1 implies x inHIDDENR3 T2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A101: "x inHIDDENR3 T1"
            then obtain y z where
              [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
              A102: "[TARSKIK4 y,z ] =HIDDENR1 x"
              using relat_1_def_1 sorry
            have A103: "T1 .FUNCT-1K1 y =HIDDENR1 z"
              using A101 A102 funct_1_th_1 sorry
            have 
              [ty]:"y be ElementTREES-1M2-of domRELAT-1K1 T1"
              using A101 A102 funct_1_th_1 sorry
            have "lenFINSEQ-1K4 y <=XXREAL-0R1 lenFINSEQ-1K4 y"
               sorry
            then have "y inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
              using A100 sorry
            thus "x inHIDDENR3 T2"
              using A102 A103 funct_1_th_1 sorry
          qed "sorry"
          thus "T1 c=RELAT-1R2 T2"
            using tarski_def_3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "E be c=-linearORDINAL1V6"
      proof-
        have " for T1 be setHIDDENM2 holds  for T2 be setHIDDENM2 holds T1 inTARSKIR2 E implies (T2 inTARSKIR2 E implies (T1,T2)are-c=-comparableXBOOLE-0R3)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix T1 assume [ty]: "T1 be setHIDDENM2"
          fix T2 assume [ty]: "T2 be setHIDDENM2"
          assume A104: "T1 inTARSKIR2 E"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A105: "x inHIDDENR3 domRELAT-1K1 f"and A106: "T1 =XBOOLE-0R4 f .FUNCT-1K1 x"
            using funct_1_def_3 sorry
          assume A107: "T2 inTARSKIR2 E"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A108: "y inHIDDENR3 domRELAT-1K1 f"and A109: "T2 =XBOOLE-0R4 f .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have A110: "T1 be DecoratedTreeTREES-2M4"
            using A69 A104 sorry
          have A111: "T2 be DecoratedTreeTREES-2M4"
            using A69 A107 sorry
          have 
            [ty]:"x be NatNAT-1M1" and
            [ty]:"y be NatNAT-1M1"
            using A67 A105 A108 sorry
          have Cut2269: "x <=XXREAL-0R1 y or y <=XXREAL-0R1 x"
             sorry
          have "T1 c=TARSKIR1 T2 or T2 c=TARSKIR1 T1"
          proof-
            show "T1 c=TARSKIR1 T2 or T2 c=TARSKIR1 T1"
              using A72 A106 A109 A110 A111 Cut2269 sorry
          qed
          thus "(T1,T2)are-c=-comparableXBOOLE-0R3"
            using xboole_0_def_9 sorry
        qed "sorry"
        thus "E be c=-linearORDINAL1V6"
          using ordinal1_def_8 sorry
      qed
      then obtain T where 
        [ty]:"T be DecoratedTreeTREES-2M5-of Df0" and TDef:"T = unionTARSKIK3 (rngFUNCT-1K2 f)"
        using A69 trees_2_th_36 sorry
      show " ex tVar37 be DecoratedTreeTREES-2M5-of Df0 st tVar37 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar37 holds succTREES-2K1\<^bsub>(domRELAT-1K1 tVar37)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(tVar37 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 Ff1(tVar37 .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not tVar37 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(tVar37 .TREES-2K3\<^bsub>(Df0)\<^esub> t,n))))"
      proof(rule bexI[of _ "T"],rule conjMI,rule ballI)
        obtain T9 k where
          [ty]:"T9 be DecoratedTreeTREES-2M5-of Df0" "k be NatNAT-1M1" and 
          A112: "((0NUMBERSK6 =XBOOLE-0R4 k & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 T9) & T9 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T9 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
          using A67 sorry
        have "{}XBOOLE-0K1 inTARSKIR2 domRELAT-1K1 T9"
          using trees_1_th_22 sorry
        then have A113: "[TARSKIK4 {}XBOOLE-0K1,df0 ] inHIDDENR3 T9"
          using A112 funct_1_th_1 sorry
        have "T9 inTARSKIR2 rngFUNCT-1K2 f"
          using A67 A112 funct_1_def_3 sorry
        then have "[TARSKIK4 {}XBOOLE-0K1,df0 ] inHIDDENR3 T"
          using A113 tarski_def_4 sorry
        thus "T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0"
          using funct_1_th_1 sorry
        have A114: " for T1 be DecoratedTreeTREES-2M4 holds  for x be setHIDDENM2 holds T1 inTARSKIR2 E & x inTARSKIR2 domRELAT-1K1 T1 implies x inTARSKIR2 domRELAT-1K1 T & T1 .FUNCT-1K1 x =XBOOLE-0R4 T .FUNCT-1K1 x"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
          fix x assume [ty]: "x be setHIDDENM2"
          assume A115: "T1 inTARSKIR2 E"
            and A116: "x inTARSKIR2 domRELAT-1K1 T1"
          have "[TARSKIK4 x,T1 .FUNCT-1K1 x ] inHIDDENR3 T1"
            using A116 funct_1_th_1 sorry
          then have "[TARSKIK4 x,T1 .FUNCT-1K1 x ] inHIDDENR3 T"
            using A115 tarski_def_4 sorry
          thus "x inTARSKIR2 domRELAT-1K1 T & T1 .FUNCT-1K1 x =XBOOLE-0R4 T .FUNCT-1K1 x"
            using funct_1_th_1 sorry
        qed "sorry"
        fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T"
        have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ({t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t & ( for n be NatNAT-1M1 holds n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
        proof(rule conjMI,rule conjMI,rule ballI,rule impI)
          show "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
          proof-
            have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                then obtain l where
                  [ty]:"l be NatNAT-1M1" and 
                  A117: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A118: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) inTARSKIR2 domRELAT-1K1 T"
                   sorry
                have "[TARSKIK4 x,T .FUNCT-1K1 x ] inHIDDENR3 T"
                  using A117 A118 funct_1_th_1 sorry
                then obtain X where
                  [ty]:"X be setHIDDENM2" and 
                  A119: "[TARSKIK4 x,T .FUNCT-1K1 x ] inHIDDENR3 X"and A120: "X inTARSKIR2 rngFUNCT-1K2 f"
                  using tarski_def_4 sorry
                obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A121: "y inHIDDENR3 NATNUMBERSK1"and A122: "X =XBOOLE-0R4 f .FUNCT-1K1 y"
                  using A67 A120 funct_1_def_3 sorry
                obtain T1 k1 where
                  [ty]:"T1 be DecoratedTreeTREES-2M5-of Df0" "k1 be NatNAT-1M1" and 
                  A123: "((y =HIDDENR1 k1 & f .FUNCT-1K1 y =XBOOLE-0R4 T1) & T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k1 & (lenFINSEQ-1K4 t <XXREAL-0R3 k1 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
                  using A67 A121 sorry
                have A124: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) inTARSKIR2 domRELAT-1K1 T1"
                  using A117 A119 A122 A123 funct_1_th_1 sorry
                then obtain t9 p where 
                  [ty]:"t9 be ElementTREES-1M2-of domRELAT-1K1 T1" and t9Def:"t9 = t" and
                  [ty]:"p be ElementTREES-1M2-of domRELAT-1K1 T1" and pDef:"p = t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"
                  using trees_1_th_21 sorry
                have "lenFINSEQ-1K4 p <=XXREAL-0R1 k1"
                  using A123 sorry
                then have "lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k1"
                  using finseq_2_th_16 sorry
                then have A125: "lenFINSEQ-1K4 t9 <XXREAL-0R3 k1"
                  using nat_1_th_13 sorry
                then have A126: "succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t9 =XBOOLE-0R4 {t9 ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t9) }"
                  using A123 sorry
                have "T1 .FUNCT-1K1 t =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t"
                  using A114 A120 A122 A123 A125 sorry
                thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  using A117 A124 A126 sorry
              qed "sorry"
              thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have "[TARSKIK4 t,T .TREES-2K3\<^bsub>(Df0)\<^esub> t ] inHIDDENR3 T"
            using funct_1_th_1 sorry
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A127: "[TARSKIK4 t,T .TREES-2K3\<^bsub>(Df0)\<^esub> t ] inHIDDENR3 X"and A128: "X inTARSKIR2 E"
            using tarski_def_4 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A129: "y inHIDDENR3 NATNUMBERSK1"and A130: "X =XBOOLE-0R4 f .FUNCT-1K1 y"
            using A67 A128 funct_1_def_3 sorry
          have 
            [ty]:"y be NatNAT-1M1"
            using A129 sorry
          obtain T1 k1 where
            [ty]:"T1 be DecoratedTreeTREES-2M5-of Df0" "k1 be NatNAT-1M1" and 
            A131: "((y =XBOOLE-0R4 k1 & f .FUNCT-1K1 y =XBOOLE-0R4 T1) & T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k1 & (lenFINSEQ-1K4 t <XXREAL-0R3 k1 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A68 sorry
          obtain T2 k2 where
            [ty]:"T2 be DecoratedTreeTREES-2M5-of Df0" "k2 be NatNAT-1M1" and 
            A132: "((y +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k2 & f .FUNCT-1K1 (y +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T2) & T2 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T2 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k2 & (lenFINSEQ-1K4 t <XXREAL-0R3 k2 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T2 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T2 .TREES-2K3\<^bsub>(Df0)\<^esub> t & n inTARSKIR2 Ff1(x) implies T2 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A67 sorry
          have "y <=XXREAL-0R1 y +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          then have A133: "T1 c=RELAT-1R2 T2"
            using A72 A131 A132 sorry
          obtain t1 where 
            [ty]:"t1 be ElementTREES-1M2-of domRELAT-1K1 T1" and t1Def:"t1 = t"
            using A127 A130 A131 funct_1_th_1 sorry
          have A134: "lenFINSEQ-1K4 t1 <=XXREAL-0R1 y"
            using A131 sorry
          have A135: "T2 .FUNCT-1K1 t =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t"
            using A127 A130 A131 A133 funct_1_th_1 sorry
          obtain t2 where 
            [ty]:"t2 be ElementTREES-1M2-of domRELAT-1K1 T2" and t2Def:"t2 = t"
            using A127 A130 A131 A133 funct_1_th_1 sorry
          have A136: "lenFINSEQ-1K4 t2 <XXREAL-0R3 y +NAT-1K1 \<one>\<^sub>M"
            using A134 nat_1_th_13 sorry
          then have A137: "succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> t2 =XBOOLE-0R4 {t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T2 .TREES-2K3\<^bsub>(Df0)\<^esub> t2) }"
            using A132 sorry
          show "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
          proof-
            have "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } implies x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A138: "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                then have A139: " ex l be NatNAT-1M1 st x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) & l inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                   sorry
                have A140: "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> t2"
                  using A132 A135 A136 A138 sorry
                have "T2 inTARSKIR2 E"
                  using A67 A132 funct_1_def_3 sorry
                then have "x inHIDDENR3 domRELAT-1K1 T"
                  using A114 A140 sorry
                thus "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                  using A139 sorry
              qed "sorry"
              thus "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A141: "n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
          then have A142: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> t2"
            using A135 A137 sorry
          have "T2 inTARSKIR2 E"
            using A67 A132 funct_1_def_3 sorry
          then have "T2 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))"
            using A114 A142 sorry
          thus "T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)"
            using A132 A135 A136 A141 sorry
        qed "sorry"
        thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
          using xboole_0_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem trees_2_sch_9:
  fixes Df0 df0 Ff1 Sf0 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "df0 be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be NatNAT-1M1" and
  [ty]: "Sf0 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Df0,NATNUMBERSK1 :],Df0)"
  shows " ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
  proof-
    have " ex tVar38 be DecoratedTreeTREES-2M5-of Df0 st tVar38 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar38 holds succTREES-2K1\<^bsub>(domRELAT-1K1 tVar38)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 :  not k <XXREAL-0R3 Ff1(tVar38 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 Ff1(tVar38 .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not tVar38 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(tVar38 .TREES-2K3\<^bsub>(Df0)\<^esub> t,n))))"
    proof-
      let ?FF = "\<lambda>Lamb1. {i where i be NatNAT-1M1 : i <XXREAL-0R3 Lamb1 }"
      let ?U = "\<lambda>Lamb1. ?FF(Ff1(Lamb1))"
      have A1: " for d be ElementSUBSET-1M1-of Df0 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <=XXREAL-0R1 k2 & k2 inTARSKIR2 ?U(d) implies k1 inTARSKIR2 ?U(d)"
      proof-
        have " for d be ElementSUBSET-1M1-of Df0 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <=XXREAL-0R1 k2 & k2 inTARSKIR2 {i where i be NatNAT-1M1 : i <XXREAL-0R3 Ff1(d) } implies k1 inTARSKIR2 {icc where icc be NatNAT-1M1 : icc <XXREAL-0R3 Ff1(d) }"
        proof(rule ballI,rule ballI,rule ballI,rule impI)
          fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
          fix k1 assume [ty]: "k1 be NatNAT-1M1"
          fix k2 assume [ty]: "k2 be NatNAT-1M1"
          assume A2: "k1 <=XXREAL-0R1 k2 & k2 inTARSKIR2 {i where i be NatNAT-1M1 : i <XXREAL-0R3 Ff1(d) }"
          then have " ex i be NatNAT-1M1 st k2 =XBOOLE-0R4 i & i <XXREAL-0R3 Ff1(d)"
             sorry
          then have "k1 <XXREAL-0R3 Ff1(d)"
            using A2 xxreal_0_th_2 sorry
          thus "k1 inTARSKIR2 {icc where icc be NatNAT-1M1 : icc <XXREAL-0R3 Ff1(d) }"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain T where
        [ty]:"T be DecoratedTreeTREES-2M5-of Df0" and 
        A3: "T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 ?U(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds n inTARSKIR2 ?U(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
        using trees_2_sch_8 A1 sorry
      show " ex tVar38 be DecoratedTreeTREES-2M5-of Df0 st tVar38 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar38 holds succTREES-2K1\<^bsub>(domRELAT-1K1 tVar38)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 :  not k <XXREAL-0R3 Ff1(tVar38 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 Ff1(tVar38 .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not tVar38 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(tVar38 .TREES-2K3\<^bsub>(Df0)\<^esub> t,n))))"
      proof(rule bexI[of _ "T"],rule conjMI,rule ballI)
        show "T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0"
          using A3 sorry
        fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T"
        have A4: "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : k inTARSKIR2 ?FF(Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)) }"
          using A3 sorry
        have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ({t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
        proof(rule conjMI,rule conjMI,rule ballI,rule impI)
          show "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
          proof-
            have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 :  not i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 :  not i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                then obtain l where
                  [ty]:"l be NatNAT-1M1" and 
                  A5: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A6: "l inTARSKIR2 ?FF(Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t))"
                  using A4 sorry
                have " ex i be NatNAT-1M1 st l =XBOOLE-0R4 i & i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                  using A6 sorry
                thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 :  not i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  using A5 sorry
              qed "sorry"
              thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 :  not i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          show "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
          proof-
            have "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 :  not i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } implies x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                then obtain l where
                  [ty]:"l be NatNAT-1M1" and 
                  A7: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A8: "l <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                   sorry
                have "l inTARSKIR2 ?FF(Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t))"
                  using A8 sorry
                thus "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                  using A4 A7 sorry
              qed "sorry"
              thus "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 :  not i <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
          then have "n inTARSKIR2 ?FF(Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t))"
             sorry
          thus "T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)"
            using A3 sorry
        qed "sorry"
        thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 :  not k <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 Ff1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
          using xboole_0_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

(*begin*)
mtheorem trees_2_cl_12:
  mlet "Tr be finiteFINSET-1V1\<bar>TreeTREES-1M1", "v be ElementTREES-1M2-of Tr"
"cluster succTREES-2K1\<^bsub>(Tr)\<^esub> v as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "succTREES-2K1\<^bsub>(Tr)\<^esub> v be finiteFINSET-1V1"
     sorry
qed "sorry"

mdef trees_2_def_12 ("branchdegTREES-2K8\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "Tr be finiteFINSET-1V1\<bar>TreeTREES-1M1", "v be ElementTREES-1M2-of Tr"
"func branchdegTREES-2K8\<^bsub>(Tr)\<^esub> v \<rightarrow> setHIDDENM2 equals
  cardCARD-1K4 (succTREES-2K1\<^bsub>(Tr)\<^esub> v)"
proof-
  (*coherence*)
    show "cardCARD-1K4 (succTREES-2K1\<^bsub>(Tr)\<^esub> v) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem trees_2_cl_13:
"cluster finiteFINSET-1V1 for DecoratedTreeTREES-2M4"
proof
(*existence*)
  show " ex it be DecoratedTreeTREES-2M4 st it be finiteFINSET-1V1"
  proof-
    have " ex tVar39 be DecoratedTreeTREES-2M4 st tVar39 be finiteFINSET-1V1"
    proof-
      obtain T where 
        [ty]:"T be TreeTREES-1M1" and TDef:"T = {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      show " ex tVar39 be DecoratedTreeTREES-2M4 st tVar39 be finiteFINSET-1V1"
      proof(rule bexI[of _ "T -->FUNCOP-1K7 {}XBOOLE-0K1"])
        show "T -->FUNCOP-1K7 {}XBOOLE-0K1 be finiteFINSET-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_2_cl_14:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster finiteFINSET-1V1 for DecoratedTreeTREES-2M5-of D"
proof
(*existence*)
  show " ex it be DecoratedTreeTREES-2M5-of D st it be finiteFINSET-1V1"
  proof-
    have " ex tVar40 be DecoratedTreeTREES-2M5-of D st tVar40 be finiteFINSET-1V1"
    proof-
      let ?d = "the ElementSUBSET-1M1-of D"
      obtain T where 
        [ty]:"T be TreeTREES-1M1" and TDef:"T = {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      show " ex tVar40 be DecoratedTreeTREES-2M5-of D st tVar40 be finiteFINSET-1V1"
      proof(rule bexI[of _ "T -->FUNCOP-1K8\<^bsub>(D)\<^esub> ?d"])
        show "T -->FUNCOP-1K8\<^bsub>(D)\<^esub> (the ElementSUBSET-1M1-of D) be finiteFINSET-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_2_cl_15:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for RelationRELSET-1M1-of(a,b)"
proof
(*existence*)
  show " ex it be RelationRELSET-1M1-of(a,b) st it be  non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be RelationRELSET-1M1-of(a,b) holds VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "[:ZFMISC-1K2 a,b :] c=RELAT-1R2 [:ZFMISC-1K2 a,b :]"
         sorry
      thus " not ( for VarFor1 be RelationRELSET-1M1-of(a,b) holds VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve w for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mtheorem trees_2_th_37:
" for Z1 be TreeTREES-1M1 holds  for Z2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Z1 implies ( for v be ElementTREES-1M2-of Z1 with-replacementTREES-1K5(p,Z2) holds  for w be ElementTREES-1M2-of Z2 holds v =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> w implies (succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> v,succTREES-2K1\<^bsub>(Z2)\<^esub> w)are-equipotentTARSKIR3)"
proof-
  have " for Z1 be TreeTREES-1M1 holds  for Z2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 Z1 implies ( for t be ElementTREES-1M2-of Z1 with-replacementTREES-1K5(p,Z2) holds  for t2 be ElementTREES-1M2-of Z2 holds t =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> t2 implies (succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> t,succTREES-2K1\<^bsub>(Z2)\<^esub> t2)are-equipotentTARSKIR3)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impI)
    fix Z1 assume [ty]: "Z1 be TreeTREES-1M1"
    fix Z2 assume [ty]: "Z2 be TreeTREES-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A1: "p inTARSKIR2 Z1"
    let ?T = "Z1 with-replacementTREES-1K5(p,Z2)"
    fix t assume [ty]: "t be ElementTREES-1M2-of Z1 with-replacementTREES-1K5(p,Z2)"
    fix t2 assume [ty]: "t2 be ElementTREES-1M2-of Z2"
    assume A2: "t =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> p ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> t2"
    then have A3: "p is-a-prefix-ofTREES-1R2 t"
      using trees_1_th_1 sorry
    have A4: " for n be NatNAT-1M1 holds t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 ?T iff t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z2"
    proof-
      have " for n be NatNAT-1M1 holds (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z1 with-replacementTREES-1K5(p,Z2) implies t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z2) & (t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z2 implies t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z1 with-replacementTREES-1K5(p,Z2))"
      proof(rule ballI,rule conjMI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A5: "p is-a-proper-prefix-ofTREES-1R3 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
          using A3 trees_1_th_8 sorry
        obtain nn where 
          [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
          using ordinal1_def_12 sorry
        have A6: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> nn*>) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (t2 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> nn*>))"
          using A2 finseq_1_th_32 sorry
        show "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z1 with-replacementTREES-1K5(p,Z2) implies t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z2"
        proof(rule impI)
          assume A7: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 ?T"
          have 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have " ex w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st w inTARSKIR2 Z2 & t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> w"
            using A1 A5 trees_1_def_9 A7 sorry
          thus "t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z2"
            using A6 finseq_1_th_33 sorry
        qed
        assume "t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z2"
        thus "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z1 with-replacementTREES-1K5(p,Z2)"
          using A1 A6 trees_1_def_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be NatNAT-1M1 holds Lamb1 =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) implies Lamb2 =HIDDENR1 t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
    have A8: " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> t implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> t implies ( ex tVar41 be objectHIDDENM1 st  for m be NatNAT-1M1 holds x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) implies tVar41 =HIDDENR1 t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> t"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A9: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 ?T"
           sorry
        show " ex tVar41 be objectHIDDENM1 st  for m be NatNAT-1M1 holds x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) implies tVar41 =HIDDENR1 t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)"
        proof(rule bexI[of _ "t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)"
          thus "t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) =HIDDENR1 t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)"
            using A9 finseq_1_th_33 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A10: "domRELAT-1K1 f =XBOOLE-0R4 succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> t & ( for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> t implies ?P(x,f .FUNCT-1K1 x))"
      using classes1_sch_1 A8 sorry
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 succTREES-2K1\<^bsub>(Z2)\<^esub> t2) & (x inHIDDENR3 succTREES-2K1\<^bsub>(Z2)\<^esub> t2 implies x inHIDDENR3 rngFUNCT-1K2 f)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 succTREES-2K1\<^bsub>(Z2)\<^esub> t2"
      proof(rule impI)
        assume "x inHIDDENR3 rngFUNCT-1K2 f"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A11: "y inHIDDENR3 domRELAT-1K1 f"and A12: "x =HIDDENR1 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A13: "y =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and A14: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 ?T"
          using A10 A11 sorry
        have A15: "x =HIDDENR1 t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
          using A10 A11 A12 A13 sorry
        have "t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z2"
          using A4 A14 sorry
        thus "x inHIDDENR3 succTREES-2K1\<^bsub>(Z2)\<^esub> t2"
          using A15 sorry
      qed
      assume "x inHIDDENR3 succTREES-2K1\<^bsub>(Z2)\<^esub> t2"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A16: "x =HIDDENR1 t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and A17: "t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 Z2"
         sorry
      have "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 ?T"
        using A4 A17 sorry
      then have A18: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 f"
        using A10 sorry
      then have "f .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =HIDDENR1 x"
        using A10 A16 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 f"
        using A18 funct_1_def_3 sorry
    qed "sorry"
    then have A19: "rngFUNCT-1K2 f =XBOOLE-0R4 succTREES-2K1\<^bsub>(Z2)\<^esub> t2"
      using tarski_th_2 sorry
    have "f be one-to-oneFUNCT-1V2"
    proof-
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A20: "x1 inHIDDENR3 domRELAT-1K1 f"
          and A21: "x2 inHIDDENR3 domRELAT-1K1 f"
          and A22: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
        obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A23: "x1 =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)"and "t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 ?T"
          using A10 A20 sorry
        obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A24: "x2 =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)"and "t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 ?T"
          using A10 A21 sorry
        have "t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) =HIDDENR1 f .FUNCT-1K1 x1"
          using A10 A20 A23 sorry
        also have "... = t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)"
          using A10 A21 A22 A24 sorry
        finally have "t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) =HIDDENR1 t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)"
           sorry
        thus "x1 =HIDDENR1 x2"
          using A23 A24 finseq_1_th_33 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    thus "(succTREES-2K1\<^bsub>(Z1 with-replacementTREES-1K5(p,Z2))\<^esub> t,succTREES-2K1\<^bsub>(Z2)\<^esub> t2)are-equipotentTARSKIR3"
      using A10 A19 wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem trees_2_sch_10:
  fixes Df0 df0 Sf0 Qp2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "df0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "Sf0 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Df0,NATNUMBERSK1 :],Df0)" and
   A1: " for d be ElementSUBSET-1M1-of Df0 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds k1 <=XXREAL-0R1 k2 & Qp2(k2,d) implies Qp2(k1,d)"
  shows " ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
  proof-
    have " ex tVar48 be DecoratedTreeTREES-2M5-of Df0 st tVar48 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar48 holds succTREES-2K1\<^bsub>(domRELAT-1K1 tVar48)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,tVar48 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not (Qp2(n,tVar48 .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not tVar48 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(tVar48 .TREES-2K3\<^bsub>(Df0)\<^esub> t,n))))"
    proof-
      let ?P = "\<lambda>Lamb1.  ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 Lamb1 & (lenFINSEQ-1K4 t <XXREAL-0R3 Lamb1 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
      obtain W where 
        [ty]:"W be TreeTREES-1M1" and WDef:"W = {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      have A2: "?P(0NUMBERSK6)"
      proof-
        have " ex T1 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 W,Df0 :]) st T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELSET-1K1\<^bsub>(W)\<^esub> T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6 & (lenFINSEQ-1K4 t <XXREAL-0R3 0NUMBERSK6 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))))"
        proof-
          obtain T1 where 
            [ty]:"T1 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 W,Df0 :])" and T1Def:"T1 = W -->FUNCOP-1K8\<^bsub>(Df0)\<^esub> df0"
             sorry
          show " ex T1 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 W,Df0 :]) st T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELSET-1K1\<^bsub>(W)\<^esub> T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6 & (lenFINSEQ-1K4 t <XXREAL-0R3 0NUMBERSK6 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))))"
          proof(rule bexI[of _ "T1"],rule conjMI,rule ballI,rule conjMI,rule impI)
            have "{}XBOOLE-0K1 inTARSKIR2 W"
              using trees_1_th_22 sorry
            thus "T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0"
              using funcop_1_th_7 sorry
            fix t assume [ty]: "t be ElementTREES-1M2-of domRELSET-1K1\<^bsub>(W)\<^esub> T1"
            have "domRELSET-1K1\<^bsub>(W)\<^esub> T1 =TREES-2R1 W"
              using funcop_1_th_13 sorry
            then have "t =FINSEQ-1R1 {}XBOOLE-0K1"
              using tarski_def_1 sorry
            thus "lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6"
               sorry
            assume "lenFINSEQ-1K4 t <XXREAL-0R3 0NUMBERSK6"
            thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))"
               sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds ( ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : Qp2(m,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))) implies ( ex tVar44 be DecoratedTreeTREES-2M5-of Df0 st tVar44 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar44 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & (lenFINSEQ-1K4 t <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies succTREES-2K1\<^bsub>(domRELAT-1K1 tVar44)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,tVar44 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar44 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not tVar44 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume Given: " ex T be DecoratedTreeTREES-2M5-of Df0 st T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : Qp2(m,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
          then obtain T where
            [ty]:"T be DecoratedTreeTREES-2M5-of Df0" and 
            A4: "T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : Qp2(m,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
             sorry
          obtain M where 
            [ty]:"M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and MDef:"M = ({t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) })\\/XBOOLE-0K2 domRELAT-1K1 T"
             sorry
          have "M be Tree-likeTREES-1V1"
          proof-
            have "M c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies ProperPrefixesTREES-1K1 p c=TARSKIR1 M) & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 M implies (n <=XXREAL-0R1 m &  not p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 M implies  not  True )))"
            proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
              show "M c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 M implies ( not x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3 implies  not  True )"
                proof(rule ballI,rule impI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 M"
                  then have A5: "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } or x inHIDDENR3 domRELAT-1K1 T & domRELAT-1K1 T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                    using trees_1_def_3 xboole_0_def_3 sorry
                  assume A6: " not x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                  then obtain n t where
                    [ty]:"n be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                    A7: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                    using A5 sorry
                  have 
                    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    using ordinal1_def_12 sorry
                  have "x =HIDDENR1 t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
                    using A7 sorry
                  thus " not  True "
                    using A6 finseq_1_def_11 sorry
                qed "sorry"
                thus "M c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                  using tarski_def_3 sorry
              qed
              show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies ProperPrefixesTREES-1K1 p c=TARSKIR1 M"
              proof(rule ballI,rule impI)
                fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                assume "p inTARSKIR2 M"
                then have A8: "p inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } or p inTARSKIR2 domRELAT-1K1 T"
                  using xboole_0_def_3 sorry
                have "p inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } implies ProperPrefixesTREES-1K1 p c=TARSKIR1 M"
                proof(rule impI)
                  assume "p inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) where n be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  then obtain n t where
                    [ty]:"n be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                    A9: "p =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and "Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                     sorry
                  have A10: "ProperPrefixesTREES-1K1 t c=TARSKIR1 domRELAT-1K1 T"
                    using trees_1_def_3 sorry
                  have A11: "domRELAT-1K1 T c=TARSKIR1 M"
                    using xboole_1_th_7 sorry
                  have A12: "ProperPrefixesTREES-1K1 t c=TARSKIR1 M"
                    using A10 A11 sorry
                  have A13: "{TARSKIK1 t} c=TARSKIR1 M"
                    using A11 zfmisc_1_th_31 sorry
                  have "ProperPrefixesTREES-1K1 p =XBOOLE-0R4 ProperPrefixesTREES-1K1 t \\/XBOOLE-0K2 {TARSKIK1 t}"
                    using A9 trees_2_th_4 sorry
                  thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 M"
                    using A12 A13 xboole_1_th_8 sorry
                qed
                then have "ProperPrefixesTREES-1K1 p c=TARSKIR1 M or ProperPrefixesTREES-1K1 p c=TARSKIR1 domRELAT-1K1 T & domRELAT-1K1 T c=TARSKIR1 M"
                  using A8 trees_1_def_3 xboole_1_th_7 sorry
                thus "ProperPrefixesTREES-1K1 p c=TARSKIR1 M"
                   sorry
              qed "sorry"
              fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              fix m assume [ty]: "m be NatNAT-1M1"
              fix n assume [ty]: "n be NatNAT-1M1"
              assume "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 M"
              then have A14: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } or p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) inTARSKIR2 domRELAT-1K1 T"
                using xboole_0_def_3 sorry
              assume A15: "n <=XXREAL-0R1 m"
                and A16: " not p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 M"
              have " not p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T"
                using A16 xboole_0_def_3 sorry
              then obtain l t where
                [ty]:"l be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                A17: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A18: "Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                using A14 A15 trees_1_def_3 sorry
              have A19: "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 m*>) & lenFINSEQ-1K4 (<*FINSEQ-1K10 m*>) =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_22 finseq_1_th_40 sorry
              have A20: "lenFINSEQ-1K4 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)) =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) & lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_22 finseq_1_th_40 sorry
              have A21: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 m & (t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)).FUNCT-1K1 (lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 l"
                using finseq_1_th_42 sorry
              then have A22: "p =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> t"
                using A17 A19 A20 finseq_1_th_33 sorry
              have "Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                using A1 A15 A17 A18 A19 A20 A21 sorry
              then have "p ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                using A22 sorry
              thus " not  True "
                using A16 xboole_0_def_3 sorry
            qed "sorry"
            thus "M be Tree-likeTREES-1V1"
              using trees_1_def_3 sorry
          qed
          then have 
            [ty]:"M be TreeTREES-1M1"
             sorry
          let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 domRELAT-1K1 T & Lamb2 =XBOOLE-0R4 T .FUNCT-1K1 Lamb1 or  not Lamb1 inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st Lamb1 =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & Lamb2 =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))"
          have A23: " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies ( ex x be setHIDDENM2 st ?P(p,x))"
          proof-
            have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies  not ( for x be setHIDDENM2 holds  not (p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))))"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              assume "p inTARSKIR2 M"
              then have A24: "p inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } or p inTARSKIR2 domRELAT-1K1 T"
                using xboole_0_def_3 sorry
              have " not p inTARSKIR2 domRELAT-1K1 T implies ( ex x be setHIDDENM2 st p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n)))"
              proof(rule impI)
                assume A25: " not p inTARSKIR2 domRELAT-1K1 T"
                then obtain l t where
                  [ty]:"l be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                  A26: "p =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and "Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                  using A24 sorry
                obtain x where 
                  [ty]:"x be setHIDDENM2" and xDef:"x = Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,l)"
                   sorry
                show " ex x be setHIDDENM2 st p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))"
                proof(rule bexI[of _ "x"])
                  show "p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))"
                    using A25 A26 sorry
                qed "sorry"
              qed
              thus " not ( for x be setHIDDENM2 holds  not (p inTARSKIR2 domRELAT-1K1 T & x =XBOOLE-0R4 T .FUNCT-1K1 p or  not p inTARSKIR2 domRELAT-1K1 T & ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) & x =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n))))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain T9 where
            [ty]:"T9 be DecoratedTreeTREES-2M4" and 
            A27: "domRELAT-1K1 T9 =TREES-2R1 M & ( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 M implies ?P(p,T9 .FUNCT-1K1 p))"
            using trees_2_sch_6 A23 sorry
          have "rngFUNCT-1K2 T9 c=TARSKIR1 Df0"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 T9 implies x inHIDDENR3 Df0"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 T9"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A28: "y inHIDDENR3 domRELAT-1K1 T9"and A29: "x =HIDDENR1 T9 .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have 
                [ty]:"y be ElementTREES-1M2-of domRELAT-1K1 T9"
                using A28 sorry
              have A30: "y inTARSKIR2 domRELAT-1K1 T implies x inHIDDENR3 Df0"
              proof(rule impI)
                assume "y inTARSKIR2 domRELAT-1K1 T"
                then obtain t where 
                  [ty]:"t be ElementTREES-1M2-of domRELAT-1K1 T" and tDef:"t = y"
                   sorry
                have "T .TREES-2K3\<^bsub>(Df0)\<^esub> t inTARSKIR2 Df0"
                   sorry
                thus "x inHIDDENR3 Df0"
                  using A27 A29 sorry
              qed
              have " not y inTARSKIR2 domRELAT-1K1 T implies x inHIDDENR3 Df0"
              proof(rule impI)
                assume A31: " not y inTARSKIR2 domRELAT-1K1 T"
                then obtain n q where
                  [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                  A32: "y =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and A33: "T9 .FUNCT-1K1 y =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,n)"
                  using A27 sorry
                have "y inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, t be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  using A27 A31 xboole_0_def_3 sorry
                then obtain l t where
                  [ty]:"l be NatNAT-1M1" "t be ElementTREES-1M2-of domRELAT-1K1 T" and 
                  A34: "y =FINSEQ-1R1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and "Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                   sorry
                have A35: "lenFINSEQ-1K4 (<*FINSEQ-1K10 n*>) =XBOOLE-0R4 \<one>\<^sub>M"
                  using finseq_1_th_39 sorry
                have A36: "lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) =XBOOLE-0R4 \<one>\<^sub>M"
                  using finseq_1_th_39 sorry
                have A37: "lenFINSEQ-1K4 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
                  using A35 finseq_1_th_22 sorry
                have A38: "lenFINSEQ-1K4 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)) =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M"
                  using A36 finseq_1_th_22 sorry
                have "(q ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)).FUNCT-1K1 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n & (t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)).FUNCT-1K1 (lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 l"
                  using finseq_1_th_42 sorry
                then have A39: "q =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> t"
                  using A32 A34 A37 A38 finseq_1_th_33 sorry
                have A40: "n inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have "T .TREES-2K3\<^bsub>(Df0)\<^esub> t inTARSKIR2 Df0"
                   sorry
                then have "[TARSKIK4 T .FUNCT-1K1 q,n ] inHIDDENR3 [:ZFMISC-1K2 Df0,NATNUMBERSK1 :]"
                  using A39 zfmisc_1_th_87 A40 sorry
                thus "x inHIDDENR3 Df0"
                  using A29 A33 funct_2_th_5 sorry
              qed
              thus "x inHIDDENR3 Df0"
                using A30 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 T9 c=TARSKIR1 Df0"
              using tarski_def_3 sorry
          qed
          then have 
            [ty]:"T9 be DecoratedTreeTREES-2M5-of Df0"
            using relat_1_def_19 sorry
          show " ex tVar44 be DecoratedTreeTREES-2M5-of Df0 st tVar44 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar44 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & (lenFINSEQ-1K4 t <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies succTREES-2K1\<^bsub>(domRELAT-1K1 tVar44)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,tVar44 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar44 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not tVar44 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))))"
          proof(rule bexI[of _ "T9"],rule conjMI,rule ballI,rule conjMI,rule impI)
            have "<*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 M & <*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 domRELAT-1K1 T"
              using trees_1_th_22 sorry
            thus "T9 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0"
              using A4 A27 sorry
            fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T9"
            have A41: "t inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> s) } implies lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            proof(rule impI)
              assume "t inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
              then obtain l s where
                [ty]:"l be NatNAT-1M1" "s be ElementTREES-1M2-of domRELAT-1K1 T" and 
                A42: "t =FINSEQ-1R1 s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and "Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> s)"
                 sorry
              have "lenFINSEQ-1K4 s <=XXREAL-0R1 k"
                using A4 sorry
              then have "lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) =XBOOLE-0R4 \<one>\<^sub>M & lenFINSEQ-1K4 s +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using finseq_1_th_39 xreal_1_th_7 sorry
              thus "lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using A42 finseq_1_th_22 sorry
            qed
            have "t inTARSKIR2 domRELAT-1K1 T implies lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            proof(rule impI)
              assume "t inTARSKIR2 domRELAT-1K1 T"
              then obtain s where 
                [ty]:"s be ElementTREES-1M2-of domRELAT-1K1 T" and sDef:"s = t"
                 sorry
              have "lenFINSEQ-1K4 s <=XXREAL-0R1 k & k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using A4 nat_1_th_11 sorry
              thus "lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using xxreal_0_th_2 sorry
            qed
            thus "lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              using A27 A41 xboole_0_def_3 sorry
            assume A43: "lenFINSEQ-1K4 t <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
            have A44: " not t inTARSKIR2 domRELAT-1K1 T implies  False "
            proof(rule impI)
              assume A45: " not t inTARSKIR2 domRELAT-1K1 T"
              then have "t inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                using A27 xboole_0_def_3 sorry
              then obtain l s where
                [ty]:"l be NatNAT-1M1" "s be ElementTREES-1M2-of domRELAT-1K1 T" and 
                A46: "t =FINSEQ-1R1 s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A47: "Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> s)"
                 sorry
              have A48: "lenFINSEQ-1K4 t =XBOOLE-0R4 lenFINSEQ-1K4 s +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>)"
                using A46 finseq_1_th_22 sorry
              have "lenFINSEQ-1K4 (<*FINSEQ-1K10 l*>) =XBOOLE-0R4 \<one>\<^sub>M & lenFINSEQ-1K4 t <=XXREAL-0R1 k"
                using A43 finseq_1_th_39 nat_1_th_13 sorry
              then have "lenFINSEQ-1K4 s <XXREAL-0R3 k"
                using A48 nat_1_th_13 sorry
              then have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> s =XBOOLE-0R4 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : Qp2(m,T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                using A4 sorry
              then have "t inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> s"
                using A46 A47 sorry
              thus " False "
                using A45 sorry
            qed
            then have A49: "T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t =XBOOLE-0R4 T .FUNCT-1K1 t"
              using A27 sorry
            obtain t9 where 
              [ty]:"t9 be ElementTREES-1M2-of domRELAT-1K1 T" and t9Def:"t9 = t"
              using A44 sorry
            have "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ({t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))"
            proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
              show "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
              proof-
                have "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                proof-
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                    then obtain n where
                      [ty]:"n be NatNAT-1M1" and 
                      A50: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and A51: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T9"
                       sorry
                    have "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                    proof-
                      show "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                      proof-
                        have cases: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T or  not t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T"
                           sorry
                        have case1: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                        proof(rule impI)
                          assume A52: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T"
                          then obtain s t9 where 
                            [ty]:"s be ElementTREES-1M2-of domRELAT-1K1 T" and sDef:"s = t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)" and
                            [ty]:"t9 be ElementTREES-1M2-of domRELAT-1K1 T" and t9Def:"t9 = t"
                            using trees_1_th_21 sorry
                          have "lenFINSEQ-1K4 s <=XXREAL-0R1 k & lenFINSEQ-1K4 s =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M"
                            using A4 finseq_2_th_16 sorry
                          then have "lenFINSEQ-1K4 t <XXREAL-0R3 k"
                            using nat_1_th_13 sorry
                          then have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t9 =XBOOLE-0R4 {t9 ^FINSEQ-1K8 (<*FINSEQ-1K10 m*>) where m be NatNAT-1M1 : Qp2(m,T .TREES-2K3\<^bsub>(Df0)\<^esub> t9) }"
                            using A4 sorry
                          thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                            using A49 A50 A52 sorry
                        qed
                        have case2: " not t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                        proof(rule impI)
                          assume " not t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 domRELAT-1K1 T"
                          then have "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                            using A27 A51 xboole_0_def_3 sorry
                          then obtain l s where
                            [ty]:"l be NatNAT-1M1" "s be ElementTREES-1M2-of domRELAT-1K1 T" and 
                            A53: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) =FINSEQ-1R1 s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A54: "Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> s)"
                             sorry
                          have "t =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> s"
                            using A53 finseq_2_th_17 sorry
                          thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                            using A49 A50 A53 A54 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                       sorry
                  qed "sorry"
                  thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              show A55: "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
              proof-
                have "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                proof-
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } implies x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                    then obtain n where
                      [ty]:"n be NatNAT-1M1" and 
                      A56: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"and A57: "Qp2(n,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                       sorry
                    have "x =HIDDENR1 t9 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)"
                      using A56 sorry
                    then have "x inHIDDENR3 {s ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1, s be ElementTREES-1M2-of domRELAT-1K1 T : Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> s) }"
                      using A49 A57 sorry
                    then have "x inHIDDENR3 domRELAT-1K1 T9"
                      using A27 xboole_0_def_3 sorry
                    thus "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                      using A56 sorry
                  qed "sorry"
                  thus "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              fix n assume [ty]: "n be NatNAT-1M1"
              fix x assume [ty]: "x be setHIDDENM2"
              assume A58: "x =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t"
                and A59: "Qp2(n,x)"
              have 
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                using A58 A59 sorry
              then have A60: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t"
                using A55 sorry
              have "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
              proof-
                show "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                proof-
                  have cases: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T or  not t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T"
                     sorry
                  have case1: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T implies T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                  proof(rule impI)
                    assume A61: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T"
                    then obtain s where 
                      [ty]:"s be ElementTREES-1M2-of domRELAT-1K1 T" and sDef:"s = t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
                       sorry
                    have "lenFINSEQ-1K4 s <=XXREAL-0R1 k & lenFINSEQ-1K4 s =XBOOLE-0R4 lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M"
                      using A4 finseq_2_th_16 sorry
                    then have "lenFINSEQ-1K4 t9 <XXREAL-0R3 k"
                      using nat_1_th_13 sorry
                    then have "T .FUNCT-1K1 (t9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                      using A4 A49 A58 A59 sorry
                    thus "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                      using A27 A60 A61 sorry
                  qed
                  have case2: " not t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T implies T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                  proof(rule impI)
                    assume " not t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 domRELAT-1K1 T"
                    then obtain l q where
                      [ty]:"l be NatNAT-1M1" "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
                      A62: "t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A63: "T9 .FUNCT-1K1 (t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .FUNCT-1K1 q,l)"
                      using A27 A60 sorry
                    have "t =RELSET-1R2\<^bsub>(omegaORDINAL1K4,NATNUMBERSK1)\<^esub> q & n =XBOOLE-0R4 l"
                      using A62 finseq_2_th_17 sorry
                    thus "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                      using A27 A44 A58 A63 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)"
                 sorry
            qed "sorry"
            thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))"
              using xboole_0_def_10 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A64: " for k be NatNAT-1M1 holds ?P(k)"
        using nat_1_sch_2 A2 A3 sorry
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex T be DecoratedTreeTREES-2M5-of Df0 st  ex k be NatNAT-1M1 st ((Lamb1 =HIDDENR1 k & Lamb2 =HIDDENR1 T) & T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
      have A65: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex Y be setHIDDENM2 st  ex tVar46 be DecoratedTreeTREES-2M5-of Df0 st  ex N be NatNAT-1M1 st ((x =HIDDENR1 N & Y =HIDDENR1 tVar46) & tVar46 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar46 holds lenFINSEQ-1K4 t <=XXREAL-0R1 N &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 N &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 tVar46)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,tVar46 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar46 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not tVar46 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n)))))))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 NATNUMBERSK1"
          then obtain n where 
            [ty]:"n be NatNAT-1M1" and nDef:"n = x"
             sorry
          obtain T where
            [ty]:"T be DecoratedTreeTREES-2M5-of Df0" and 
            A66: "T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 n & (lenFINSEQ-1K4 t <XXREAL-0R3 n implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A64 sorry
          obtain y where 
            [ty]:"y be setHIDDENM2" and yDef:"y = T"
             sorry
          obtain Y where 
            [ty]:"Y be setHIDDENM2" and YDef:"Y = y"
             sorry
          show " ex Y be setHIDDENM2 st  ex tVar46 be DecoratedTreeTREES-2M5-of Df0 st  ex N be NatNAT-1M1 st ((x =HIDDENR1 N & Y =HIDDENR1 tVar46) & tVar46 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar46 holds lenFINSEQ-1K4 t <=XXREAL-0R1 N &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 N &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 tVar46)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,tVar46 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar46 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not tVar46 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
          proof(rule bexI[of _ "Y"])
            show " ex tVar46 be DecoratedTreeTREES-2M5-of Df0 st  ex N be NatNAT-1M1 st ((x =HIDDENR1 N & Y =HIDDENR1 tVar46) & tVar46 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar46 holds lenFINSEQ-1K4 t <=XXREAL-0R1 N &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 N &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 tVar46)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,tVar46 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 tVar46 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not tVar46 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
            proof(rule bexI[of _ "T"])
              obtain N where 
                [ty]:"N be NatNAT-1M1" and NDef:"N = n"
                 sorry
              show " ex N be NatNAT-1M1 st ((x =HIDDENR1 N & Y =HIDDENR1 T) & T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 N &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 N &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
              proof(rule bexI[of _ "N"])
                show "((x =HIDDENR1 N & Y =HIDDENR1 T) & T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 N &  not ( not lenFINSEQ-1K4 t <XXREAL-0R3 N &  not (succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ((x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x)) &  not T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))))"
                  using A66 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A67: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,f .FUNCT-1K1 x))"
        using classes1_sch_1 A65 sorry
      have A68: " for x be NatNAT-1M1 holds ?P(x,f .FUNCT-1K1 x)"
        using ordinal1_def_12 A67 sorry
      obtain E where 
        [ty]:"E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and EDef:"E = rngFUNCT-1K2 f"
        using A67 relat_1_th_42 sorry
      have A69: " for x be setHIDDENM2 holds x inTARSKIR2 E implies x be DecoratedTreeTREES-2M5-of Df0"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 E"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A70: "y inHIDDENR3 domRELAT-1K1 f"and A71: "x =XBOOLE-0R4 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have " ex T be DecoratedTreeTREES-2M5-of Df0 st  ex k be NatNAT-1M1 st ((y =HIDDENR1 k & f .FUNCT-1K1 y =XBOOLE-0R4 T) & T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
          using A67 A70 sorry
        thus "x be DecoratedTreeTREES-2M5-of Df0"
          using A71 sorry
      qed "sorry"
      have A72: " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (T1 =XBOOLE-0R4 f .FUNCT-1K1 k1 & T2 =XBOOLE-0R4 f .FUNCT-1K1 k2) & k1 <=XXREAL-0R1 k2 implies T1 c=RELAT-1R2 T2"
      proof-
        have " for T1 be DecoratedTreeTREES-2M4 holds  for T2 be DecoratedTreeTREES-2M4 holds  for x be NatNAT-1M1 holds  for y be NatNAT-1M1 holds T1 =XBOOLE-0R4 f .FUNCT-1K1 x & (T2 =XBOOLE-0R4 f .FUNCT-1K1 y & x <=XXREAL-0R1 y) implies T1 c=RELAT-1R2 T2"
        proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
          fix T2 assume [ty]: "T2 be DecoratedTreeTREES-2M4"
          fix x assume [ty]: "x be NatNAT-1M1"
          fix y assume [ty]: "y be NatNAT-1M1"
          assume A73: "T1 =XBOOLE-0R4 f .FUNCT-1K1 x"
            and A74: "T2 =XBOOLE-0R4 f .FUNCT-1K1 y"
            and A75: "x <=XXREAL-0R1 y"
          obtain T19 k1 where
            [ty]:"T19 be DecoratedTreeTREES-2M5-of Df0" "k1 be NatNAT-1M1" and 
            A76: "((x =XBOOLE-0R4 k1 & f .FUNCT-1K1 x =XBOOLE-0R4 T19) & T19 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T19 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k1 & (lenFINSEQ-1K4 t <XXREAL-0R3 k1 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T19)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T19 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T19 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T19 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A68 sorry
          obtain T29 k2 where
            [ty]:"T29 be DecoratedTreeTREES-2M5-of Df0" "k2 be NatNAT-1M1" and 
            A77: "((y =XBOOLE-0R4 k2 & f .FUNCT-1K1 y =XBOOLE-0R4 T29) & T29 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T29 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k2 & (lenFINSEQ-1K4 t <XXREAL-0R3 k2 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T29)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T29 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T29 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T29 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A68 sorry
          let ?I = "\<lambda>Lamb1.  for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 Lamb1 implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
          have A78: "?I(0NUMBERSK6)"
          proof-
            have " for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6 implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
            proof(rule ballI,rule impI)
              fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T1"
              assume A79: "lenFINSEQ-1K4 t <=XXREAL-0R1 0NUMBERSK6"
              have "t =FINSEQ-1R1 {}XBOOLE-0K1"
                using A79 sorry
              thus "t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
                using A73 A74 A76 A77 trees_1_th_22 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A80: " for k be NatNAT-1M1 holds ?I(k) implies ?I(k +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for k be NatNAT-1M1 holds ( for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t) implies ( for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t)"
            proof(rule ballI,rule impI,rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A81: " for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
              fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T1"
              assume "lenFINSEQ-1K4 t <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              then have A82: "lenFINSEQ-1K4 t <=XXREAL-0R1 k or lenFINSEQ-1K4 t =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_8 sorry
              have "lenFINSEQ-1K4 t =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
              proof(rule impI)
                assume A83: "lenFINSEQ-1K4 t =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                obtain p where 
                  [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and pDef:"p = t  |RELSET-1K5\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> SegFINSEQ-1K2 k"
                  using finseq_1_th_18 sorry
                have "p is-a-prefix-ofTREES-1R2 t"
                   sorry
                then have 
                  [ty]:"p be ElementTREES-1M2-of domRELAT-1K1 T1"
                  using trees_1_th_20 sorry
                have A84: "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                have A85: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k1"
                  using A73 A76 A83 sorry
                have A86: "lenFINSEQ-1K4 p =XBOOLE-0R4 k"
                  using A83 A84 finseq_1_th_17 sorry
                have A87: "k <XXREAL-0R3 k1"
                  using A85 nat_1_th_13 sorry
                have A88: "T1 .FUNCT-1K1 p =XBOOLE-0R4 T2 .FUNCT-1K1 p"
                  using A81 A86 sorry
                obtain p9 where 
                  [ty]:"p9 be ElementTREES-1M2-of domRELAT-1K1 T2" and p9Def:"p9 = p"
                  using A81 A86 sorry
                have "t <>HIDDENR2 {}XBOOLE-0K1"
                  using A83 sorry
                then obtain q x where
                  [ty]:"q be FinSequenceFINSEQ-1M1" "x be objectHIDDENM1" and 
                  A89: "t =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
                  using finseq_1_th_46 sorry
                have A90: "p is-a-prefix-ofTREES-1R2 t & q is-a-prefix-ofTREES-1R2 t"
                  using A89 trees_1_th_1 sorry
                have "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
                  using A83 A89 finseq_2_th_16 sorry
                then have A91: "p =FINSEQ-1R1 q"
                  using A86 A90 trees_2_th_1 trees_1_th_4 sorry
                have "<*FINSEQ-1K10 x*> be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  using A89 finseq_1_th_36 sorry
                then have A92: "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) c=TARSKIR1 NATNUMBERSK1"
                  using finseq_1_def_4 sorry
                have "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 x} & x inHIDDENR3 {TARSKIK1 x}"
                  using finseq_1_th_38 tarski_def_1 sorry
                then have 
                  [ty]:"x be NatNAT-1M1"
                  using A92 sorry
                have A93: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> p"
                  using A89 A91 sorry
                have "succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> p =XBOOLE-0R4 {p ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T1 .FUNCT-1K1 p) }"
                  using A73 A76 A86 A87 sorry
                then obtain i where
                  [ty]:"i be NatNAT-1M1" and 
                  A94: "p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 p ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>)"and A95: "Qp2(i,T1 .FUNCT-1K1 p)"
                  using A93 sorry
                have A96: "k <XXREAL-0R3 k2"
                  using A75 A76 A77 A87 xxreal_0_th_2 sorry
                then have A97: "succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> p9 =XBOOLE-0R4 {p9 ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) where l be NatNAT-1M1 : Qp2(l,T2 .FUNCT-1K1 p9) }"
                  using A74 A77 A86 sorry
                have A98: "x =XBOOLE-0R4 i"
                  using A94 finseq_2_th_17 sorry
                have A99: "t inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> p9"
                  using A88 A89 A91 A94 A95 A97 sorry
                have "T19 .FUNCT-1K1 t =XBOOLE-0R4 Sf0 .BINOP-1K1(T19 .FUNCT-1K1 p,x)"
                  using A73 A76 A86 A87 A89 A91 A95 A98 sorry
                thus "t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
                  using A73 A74 A76 A77 A86 A88 A89 A91 A95 A96 A98 A99 sorry
              qed
              thus "t inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 t =XBOOLE-0R4 T2 .FUNCT-1K1 t"
                using A81 A82 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A100: " for k be NatNAT-1M1 holds ?I(k)"
            using nat_1_sch_2 A78 A80 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 T1 implies x inHIDDENR3 T2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A101: "x inHIDDENR3 T1"
            then obtain y z where
              [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
              A102: "[TARSKIK4 y,z ] =HIDDENR1 x"
              using relat_1_def_1 sorry
            have A103: "T1 .FUNCT-1K1 y =HIDDENR1 z"
              using A101 A102 funct_1_th_1 sorry
            have 
              [ty]:"y be ElementTREES-1M2-of domRELAT-1K1 T1"
              using A101 A102 funct_1_th_1 sorry
            have "lenFINSEQ-1K4 y <=XXREAL-0R1 lenFINSEQ-1K4 y"
               sorry
            then have "y inTARSKIR2 domRELAT-1K1 T2 & T1 .FUNCT-1K1 y =XBOOLE-0R4 T2 .FUNCT-1K1 y"
              using A100 sorry
            thus "x inHIDDENR3 T2"
              using A102 A103 funct_1_th_1 sorry
          qed "sorry"
          thus "T1 c=RELAT-1R2 T2"
            using tarski_def_3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "E be c=-linearORDINAL1V6"
      proof-
        have " for T1 be setHIDDENM2 holds  for T2 be setHIDDENM2 holds T1 inTARSKIR2 E implies (T2 inTARSKIR2 E implies (T1,T2)are-c=-comparableXBOOLE-0R3)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix T1 assume [ty]: "T1 be setHIDDENM2"
          fix T2 assume [ty]: "T2 be setHIDDENM2"
          assume A104: "T1 inTARSKIR2 E"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A105: "x inHIDDENR3 domRELAT-1K1 f"and A106: "T1 =XBOOLE-0R4 f .FUNCT-1K1 x"
            using funct_1_def_3 sorry
          assume A107: "T2 inTARSKIR2 E"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A108: "y inHIDDENR3 domRELAT-1K1 f"and A109: "T2 =XBOOLE-0R4 f .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have A110: "T1 be DecoratedTreeTREES-2M4"
            using A69 A104 sorry
          have A111: "T2 be DecoratedTreeTREES-2M4"
            using A69 A107 sorry
          have 
            [ty]:"x be NatNAT-1M1" and
            [ty]:"y be NatNAT-1M1"
            using A67 A105 A108 sorry
          have Cut2968: "x <=XXREAL-0R1 y or y <=XXREAL-0R1 x"
             sorry
          have "T1 c=TARSKIR1 T2 or T2 c=TARSKIR1 T1"
          proof-
            show "T1 c=TARSKIR1 T2 or T2 c=TARSKIR1 T1"
              using A72 A106 A109 A110 A111 Cut2968 sorry
          qed
          thus "(T1,T2)are-c=-comparableXBOOLE-0R3"
            using xboole_0_def_9 sorry
        qed "sorry"
        thus "E be c=-linearORDINAL1V6"
          using ordinal1_def_8 sorry
      qed
      then obtain T where 
        [ty]:"T be DecoratedTreeTREES-2M5-of Df0" and TDef:"T = unionTARSKIK3 (rngFUNCT-1K2 f)"
        using A69 trees_2_th_36 sorry
      show " ex tVar48 be DecoratedTreeTREES-2M5-of Df0 st tVar48 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0 & ( for t be ElementTREES-1M2-of domRELAT-1K1 tVar48 holds succTREES-2K1\<^bsub>(domRELAT-1K1 tVar48)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,tVar48 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not (Qp2(n,tVar48 .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not tVar48 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(tVar48 .TREES-2K3\<^bsub>(Df0)\<^esub> t,n))))"
      proof(rule bexI[of _ "T"],rule conjMI,rule ballI)
        obtain T9 k where
          [ty]:"T9 be DecoratedTreeTREES-2M5-of Df0" "k be NatNAT-1M1" and 
          A112: "((0NUMBERSK6 =XBOOLE-0R4 k & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 T9) & T9 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T9 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k & (lenFINSEQ-1K4 t <XXREAL-0R3 k implies succTREES-2K1\<^bsub>(domRELAT-1K1 T9)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T9 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T9 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
          using A67 sorry
        have "{}XBOOLE-0K1 inTARSKIR2 domRELAT-1K1 T9"
          using trees_1_th_22 sorry
        then have A113: "[TARSKIK4 {}XBOOLE-0K1,df0 ] inHIDDENR3 T9"
          using A112 funct_1_th_1 sorry
        have "T9 inTARSKIR2 rngFUNCT-1K2 f"
          using A67 A112 funct_1_def_3 sorry
        then have "[TARSKIK4 {}XBOOLE-0K1,df0 ] inHIDDENR3 T"
          using A113 tarski_def_4 sorry
        thus "T .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0"
          using funct_1_th_1 sorry
        have A114: " for T1 be DecoratedTreeTREES-2M4 holds  for x be setHIDDENM2 holds T1 inTARSKIR2 E & x inTARSKIR2 domRELAT-1K1 T1 implies x inTARSKIR2 domRELAT-1K1 T & T1 .FUNCT-1K1 x =XBOOLE-0R4 T .FUNCT-1K1 x"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix T1 assume [ty]: "T1 be DecoratedTreeTREES-2M4"
          fix x assume [ty]: "x be setHIDDENM2"
          assume A115: "T1 inTARSKIR2 E"
            and A116: "x inTARSKIR2 domRELAT-1K1 T1"
          have "[TARSKIK4 x,T1 .FUNCT-1K1 x ] inHIDDENR3 T1"
            using A116 funct_1_th_1 sorry
          then have "[TARSKIK4 x,T1 .FUNCT-1K1 x ] inHIDDENR3 T"
            using A115 tarski_def_4 sorry
          thus "x inTARSKIR2 domRELAT-1K1 T & T1 .FUNCT-1K1 x =XBOOLE-0R4 T .FUNCT-1K1 x"
            using funct_1_th_1 sorry
        qed "sorry"
        fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T"
        have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ({t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t & ( for n be NatNAT-1M1 holds Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) implies T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
        proof(rule conjMI,rule conjMI,rule ballI,rule impI)
          show "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
          proof-
            have "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t implies x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                then obtain l where
                  [ty]:"l be NatNAT-1M1" and 
                  A117: "x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"and A118: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) inTARSKIR2 domRELAT-1K1 T"
                   sorry
                have "[TARSKIK4 x,T .FUNCT-1K1 x ] inHIDDENR3 T"
                  using A117 A118 funct_1_th_1 sorry
                then obtain X where
                  [ty]:"X be setHIDDENM2" and 
                  A119: "[TARSKIK4 x,T .FUNCT-1K1 x ] inHIDDENR3 X"and A120: "X inTARSKIR2 rngFUNCT-1K2 f"
                  using tarski_def_4 sorry
                obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A121: "y inHIDDENR3 NATNUMBERSK1"and A122: "X =XBOOLE-0R4 f .FUNCT-1K1 y"
                  using A67 A120 funct_1_def_3 sorry
                obtain T1 k1 where
                  [ty]:"T1 be DecoratedTreeTREES-2M5-of Df0" "k1 be NatNAT-1M1" and 
                  A123: "((y =HIDDENR1 k1 & f .FUNCT-1K1 y =XBOOLE-0R4 T1) & T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k1 & (lenFINSEQ-1K4 t <XXREAL-0R3 k1 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
                  using A67 A121 sorry
                have A124: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) inTARSKIR2 domRELAT-1K1 T1"
                  using A117 A119 A122 A123 funct_1_th_1 sorry
                then obtain t9 p where 
                  [ty]:"t9 be ElementTREES-1M2-of domRELAT-1K1 T1" and t9Def:"t9 = t" and
                  [ty]:"p be ElementTREES-1M2-of domRELAT-1K1 T1" and pDef:"p = t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>)"
                  using trees_1_th_21 sorry
                have "lenFINSEQ-1K4 p <=XXREAL-0R1 k1"
                  using A123 sorry
                then have "lenFINSEQ-1K4 t +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k1"
                  using finseq_2_th_16 sorry
                then have A125: "lenFINSEQ-1K4 t9 <XXREAL-0R3 k1"
                  using nat_1_th_13 sorry
                then have A126: "succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t9 =XBOOLE-0R4 {t9 ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t9) }"
                  using A123 sorry
                have "T1 .FUNCT-1K1 t =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t"
                  using A114 A120 A122 A123 A125 sorry
                thus "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                  using A117 A124 A126 sorry
              qed "sorry"
              thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t c=TARSKIR1 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have "[TARSKIK4 t,T .TREES-2K3\<^bsub>(Df0)\<^esub> t ] inHIDDENR3 T"
            using funct_1_th_1 sorry
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A127: "[TARSKIK4 t,T .TREES-2K3\<^bsub>(Df0)\<^esub> t ] inHIDDENR3 X"and A128: "X inTARSKIR2 E"
            using tarski_def_4 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A129: "y inHIDDENR3 NATNUMBERSK1"and A130: "X =XBOOLE-0R4 f .FUNCT-1K1 y"
            using A67 A128 funct_1_def_3 sorry
          have 
            [ty]:"y be NatNAT-1M1"
            using A129 sorry
          obtain T1 k1 where
            [ty]:"T1 be DecoratedTreeTREES-2M5-of Df0" "k1 be NatNAT-1M1" and 
            A131: "((y =XBOOLE-0R4 k1 & f .FUNCT-1K1 y =XBOOLE-0R4 T1) & T1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T1 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k1 & (lenFINSEQ-1K4 t <XXREAL-0R3 k1 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T1)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T1 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T1 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A68 sorry
          obtain T2 k2 where
            [ty]:"T2 be DecoratedTreeTREES-2M5-of Df0" "k2 be NatNAT-1M1" and 
            A132: "((y +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k2 & f .FUNCT-1K1 (y +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T2) & T2 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 df0) & ( for t be ElementTREES-1M2-of domRELAT-1K1 T2 holds lenFINSEQ-1K4 t <=XXREAL-0R1 k2 & (lenFINSEQ-1K4 t <XXREAL-0R3 k2 implies succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T2 .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds x =XBOOLE-0R4 T2 .TREES-2K3\<^bsub>(Df0)\<^esub> t & Qp2(n,x) implies T2 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(x,n))))"
            using A67 sorry
          have "y <=XXREAL-0R1 y +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          then have A133: "T1 c=RELAT-1R2 T2"
            using A72 A131 A132 sorry
          obtain t1 where 
            [ty]:"t1 be ElementTREES-1M2-of domRELAT-1K1 T1" and t1Def:"t1 = t"
            using A127 A130 A131 funct_1_th_1 sorry
          have A134: "lenFINSEQ-1K4 t1 <=XXREAL-0R1 y"
            using A131 sorry
          have A135: "T2 .FUNCT-1K1 t =XBOOLE-0R4 T .TREES-2K3\<^bsub>(Df0)\<^esub> t"
            using A127 A130 A131 A133 funct_1_th_1 sorry
          obtain t2 where 
            [ty]:"t2 be ElementTREES-1M2-of domRELAT-1K1 T2" and t2Def:"t2 = t"
            using A127 A130 A131 A133 funct_1_th_1 sorry
          have A136: "lenFINSEQ-1K4 t2 <XXREAL-0R3 y +NAT-1K1 \<one>\<^sub>M"
            using A134 nat_1_th_13 sorry
          then have A137: "succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> t2 =XBOOLE-0R4 {t2 ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T2 .TREES-2K3\<^bsub>(Df0)\<^esub> t2) }"
            using A132 sorry
          show "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
          proof-
            have "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } implies x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A138: "x inHIDDENR3 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) }"
                then have A139: " ex l be NatNAT-1M1 st x =HIDDENR1 t ^FINSEQ-1K8 (<*FINSEQ-1K10 l*>) & Qp2(l,T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
                   sorry
                have A140: "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> t2"
                  using A132 A135 A136 A138 sorry
                have "T2 inTARSKIR2 E"
                  using A67 A132 funct_1_def_3 sorry
                then have "x inHIDDENR3 domRELAT-1K1 T"
                  using A114 A140 sorry
                thus "x inHIDDENR3 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                  using A139 sorry
              qed "sorry"
              thus "{t ^FINSEQ-1K8 (<*FINSEQ-1K10 i*>) where i be NatNAT-1M1 : Qp2(i,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } c=TARSKIR1 succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A141: "Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t)"
          then have A142: "t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 succTREES-2K1\<^bsub>(domRELAT-1K1 T2)\<^esub> t2"
            using A135 A137 sorry
          have "T2 inTARSKIR2 E"
            using A67 A132 funct_1_def_3 sorry
          then have "T2 .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>))"
            using A114 A142 sorry
          thus "T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)"
            using A132 A135 A136 A141 sorry
        qed "sorry"
        thus "succTREES-2K1\<^bsub>(domRELAT-1K1 T)\<^esub> t =XBOOLE-0R4 {t ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) where k be NatNAT-1M1 : Qp2(k,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) } & ( for n be NatNAT-1M1 holds  not (Qp2(n,T .TREES-2K3\<^bsub>(Df0)\<^esub> t) &  not T .FUNCT-1K1 (t ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>)) =XBOOLE-0R4 Sf0 .BINOP-1K1(T .TREES-2K3\<^bsub>(Df0)\<^esub> t,n)))"
          using xboole_0_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem trees_2_th_38:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds ( for n be NatNAT-1M1 holds T1 -levelTREES-2K2 n =XBOOLE-0R4 T2 -levelTREES-2K2 n) implies T1 =TREES-2R1 T2"
proof(rule ballI,rule ballI,rule impI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  assume A1: " for n be NatNAT-1M1 holds T1 -levelTREES-2K2 n =XBOOLE-0R4 T2 -levelTREES-2K2 n"
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T1 iff p inTARSKIR2 T2"
  proof-
    have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 T1 implies p inTARSKIR2 T2) & (p inTARSKIR2 T2 implies p inTARSKIR2 T1)"
    proof(rule ballI,rule conjMI,rule impI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      have A2: "T1 =XBOOLE-0R4 unionTARSKIK3 ({T1 -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
        using trees_2_th_14 sorry
      show "p inTARSKIR2 T1 implies p inTARSKIR2 T2"
      proof(rule impI)
        assume "p inTARSKIR2 T1"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A3: "p inTARSKIR2 Y"and A4: "Y inTARSKIR2 {T1 -levelTREES-2K2 n where n be NatNAT-1M1 :  True  }"
          using A2 tarski_def_4 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A5: "Y =XBOOLE-0R4 T1 -levelTREES-2K2 n"
          using A4 sorry
        have "Y =XBOOLE-0R4 T2 -levelTREES-2K2 n"
          using A1 A5 sorry
        thus "p inTARSKIR2 T2"
          using A3 sorry
      qed
      assume A6: "p inTARSKIR2 T2"
      have "T2 =XBOOLE-0R4 unionTARSKIK3 ({T2 -levelTREES-2K2 n where n be NatNAT-1M1 :  True  })"
        using trees_2_th_14 sorry
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A7: "p inTARSKIR2 Y"and A8: "Y inTARSKIR2 {T2 -levelTREES-2K2 n where n be NatNAT-1M1 :  True  }"
        using A6 tarski_def_4 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A9: "Y =XBOOLE-0R4 T2 -levelTREES-2K2 n"
        using A8 sorry
      have "Y =XBOOLE-0R4 T1 -levelTREES-2K2 n"
        using A1 A9 sorry
      thus "p inTARSKIR2 T1"
        using A7 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "T1 =TREES-2R1 T2"
     sorry
qed "sorry"

mtheorem trees_2_th_39:
" for n be NatNAT-1M1 holds (TrivialInfiniteTreeTREES-1K8)-levelTREES-2K2 n =XBOOLE-0R4 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) }"
proof(rule ballI)
  let ?T = "TrivialInfiniteTreeTREES-1K8"
  fix n assume [ty]: "n be NatNAT-1M1"
  let ?L = "{w where w be ElementTREES-1M2-of ?T : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
  let ?f = "n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
  have "{TARSKIK1 ?f} =XBOOLE-0R4 ?L"
  proof-
    have "{TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) } =XBOOLE-0R4 {w where w be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
    proof-
      have "( for a be objectHIDDENM1 holds a inHIDDENR3 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) } implies a inHIDDENR3 {w where w be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 : lenFINSEQ-1K4 w =XBOOLE-0R4 n }) & {w where w be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 : lenFINSEQ-1K4 w =XBOOLE-0R4 n } c=TARSKIR1 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) }"
      proof(rule conjMI)
        show " for a be objectHIDDENM1 holds a inHIDDENR3 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) } implies a inHIDDENR3 {w where w be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 {TARSKIK1 ?f}"
          then have A1: "a =HIDDENR1 ?f"
            using tarski_def_1 sorry
          have "?f inTARSKIR2 ?T & lenFINSEQ-1K4 ?f =XBOOLE-0R4 n"
            using card_1_def_7 sorry
          thus "a inHIDDENR3 {w where w be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
            using A1 sorry
        qed "sorry"
        have " for a be objectHIDDENM1 holds a inHIDDENR3 {w where w be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 : lenFINSEQ-1K4 w =XBOOLE-0R4 n } implies a inHIDDENR3 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) }"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 ?L"
          then obtain w where
            [ty]:"w be ElementTREES-1M2-of ?T" and 
            A2: "a =HIDDENR1 w & lenFINSEQ-1K4 w =XBOOLE-0R4 n"
             sorry
          have "w inTARSKIR2 ?T"
             sorry
          then have " ex k be NatNAT-1M1 st w =RELSET-1R2\<^bsub>(omegaORDINAL1K4,omegaORDINAL1K4)\<^esub> k  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6)"
             sorry
          then have "a =HIDDENR1 ?f"
            using A2 card_1_def_7 sorry
          thus "a inHIDDENR3 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) }"
            using tarski_def_1 sorry
        qed "sorry"
        thus "{w where w be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 : lenFINSEQ-1K4 w =XBOOLE-0R4 n } c=TARSKIR1 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) }"
          using tarski_def_3 sorry
      qed
      thus "{TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) } =XBOOLE-0R4 {w where w be ElementTREES-1M2-of TrivialInfiniteTreeTREES-1K8 : lenFINSEQ-1K4 w =XBOOLE-0R4 n }"
        using tarski_def_3 xboole_0_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  thus "(TrivialInfiniteTreeTREES-1K8)-levelTREES-2K2 n =XBOOLE-0R4 {TARSKIK1 n  |->FINSEQ-2K5\<^bsub>(omegaORDINAL1K4)\<^esub> (0NUMBERSK6) }"
     sorry
qed "sorry"

mtheorem trees_2_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for B be c=-linearORDINAL1V6\<bar>SubsetSUBSET-1M2-of PFuncsPARTFUN1K4(X,Y) holds unionTARSKIK3 B inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
proof(rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix B assume [ty]: "B be c=-linearORDINAL1V6\<bar>SubsetSUBSET-1M2-of PFuncsPARTFUN1K4(X,Y)"
  have " for x be setHIDDENM2 holds x inTARSKIR2 B implies x be FunctionFUNCT-1M1"
     sorry
  then obtain f where 
    [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = unionTARSKIK3 B"
    using trees_2_th_34 sorry
  show "unionTARSKIK3 B inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
  proof-
    have cases: "B <>HIDDENR2 {}XBOOLE-0K1 or B =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    have case1: "B <>HIDDENR2 {}XBOOLE-0K1 implies unionTARSKIK3 B inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
    proof(rule impI)
      assume "B <>HIDDENR2 {}XBOOLE-0K1"
      then obtain D where 
        [ty]:"D be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2" and DDef:"D = B"
         sorry
      have A1: " for x be setHIDDENM2 holds x inTARSKIR2 {domRELAT-1K1 g where g be ElementSUBSET-1M1-of D :  True  } implies x c=TARSKIR1 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 {domRELAT-1K1 g where g be ElementSUBSET-1M1-of D :  True  }"
        then obtain g where
          [ty]:"g be ElementSUBSET-1M1-of D" and 
          A2: "x =XBOOLE-0R4 domRELAT-1K1 g"
           sorry
        have "g inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
          using tarski_def_3 sorry
        then have " ex f be FunctionFUNCT-1M1 st (g =FUNCT-1R1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y"
          using partfun1_def_3 sorry
        thus "x c=TARSKIR1 X"
          using A2 sorry
      qed "sorry"
      have A3: " for x be setHIDDENM2 holds x inTARSKIR2 {rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of D :  True  } implies x c=TARSKIR1 Y"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 {rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of D :  True  }"
        then obtain g where
          [ty]:"g be ElementSUBSET-1M1-of D" and 
          A4: "x =XBOOLE-0R4 rngFUNCT-1K2 g"
           sorry
        have "g inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
          using tarski_def_3 sorry
        then have " ex f be FunctionFUNCT-1M1 st (g =FUNCT-1R1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y"
          using partfun1_def_3 sorry
        thus "x c=TARSKIR1 Y"
          using A4 sorry
      qed "sorry"
      have "rngFUNCT-1K2 f =XBOOLE-0R4 unionTARSKIK3 ({rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of D :  True  })"
        using funct_1_th_110 sorry
      then have A5: "rngFUNCT-1K2 f c=TARSKIR1 Y"
        using A3 zfmisc_1_th_76 sorry
      have "domRELAT-1K1 f =XBOOLE-0R4 unionTARSKIK3 ({domRELAT-1K1 g where g be ElementSUBSET-1M1-of D :  True  })"
        using funct_1_th_110 sorry
      then have "domRELAT-1K1 f c=TARSKIR1 X"
        using A1 zfmisc_1_th_76 sorry
      thus "unionTARSKIK3 B inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
        using A5 partfun1_def_3 sorry
    qed
    have case2: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies unionTARSKIK3 B inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
    proof(rule impI)
      assume A6: "B =XBOOLE-0R4 {}XBOOLE-0K1"
      have "{}XBOOLE-0K1 be PartFuncPARTFUN1M1-of(X,Y)"
        using relset_1_th_12 sorry
      thus "unionTARSKIK3 B inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
        using A6 partfun1_th_45 zfmisc_1_th_2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

end
