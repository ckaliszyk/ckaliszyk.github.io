theory rfunct_4
  imports rfunct_3 measure5 fcont_1 card_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, p, r, r1, r2, s, s1, s2, x0, x for "RealXREAL-0M1"
reserve f, g for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
reserve X, Y for "setHIDDENM2"
mtheorem rfunct_4_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds maxXXREAL-0K5(a,b) >=XXREAL-0R2 minXXREAL-0K4(a,b)"
proof(rule ballI,rule ballI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  show "maxXXREAL-0K5(a,b) >=XXREAL-0R2 minXXREAL-0K4(a,b)"
  proof-
    have cases: "minXXREAL-0K4(a,b) =COMPLEX1R1 a or minXXREAL-0K4(a,b) =COMPLEX1R1 b"
      using xxreal_0_th_15 sorry
    have case1: "minXXREAL-0K4(a,b) =COMPLEX1R1 a implies maxXXREAL-0K5(a,b) >=XXREAL-0R2 minXXREAL-0K4(a,b)"
    proof(rule impI)
      assume "minXXREAL-0K4(a,b) =COMPLEX1R1 a"
      thus "maxXXREAL-0K5(a,b) >=XXREAL-0R2 minXXREAL-0K4(a,b)"
        using xxreal_0_th_25 sorry
    qed
    have case2: "minXXREAL-0K4(a,b) =COMPLEX1R1 b implies maxXXREAL-0K5(a,b) >=XXREAL-0R2 minXXREAL-0K4(a,b)"
    proof(rule impI)
      assume "minXXREAL-0K4(a,b) =COMPLEX1R1 b"
      thus "maxXXREAL-0K5(a,b) >=XXREAL-0R2 minXXREAL-0K4(a,b)"
        using xxreal_0_th_25 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem rfunct_4_th_2:
" for n be NatNAT-1M1 holds  for R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds mltRVSUM-1K18(R1 ^FINSEQ-1K8 (<*FINSEQ-1K10 r1*>),R2 ^FINSEQ-1K8 (<*FINSEQ-1K10 r2*>)) =FINSEQ-1R1 mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K8 (<*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix R1 assume [ty]: "R1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
  fix R2 assume [ty]: "R2 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
  fix r1 assume [ty]: "r1 be RealXREAL-0M1"
  fix r2 assume [ty]: "r2 be RealXREAL-0M1"
  have 
    [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and
    [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
    using xreal_0_def_1 sorry
  have "lenFINSEQ-1K4 (R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>)) =HIDDENR1 lenFINSEQ-1K4 R1 +NAT-1K1 \<one>\<^sub>M"
    using finseq_2_th_16 sorry
  also have "... = n +NAT-1K1 \<one>\<^sub>M"
    using card_1_def_7 sorry
  also have "... = lenFINSEQ-1K4 R2 +NAT-1K1 \<one>\<^sub>M"
    using card_1_def_7 sorry
  also have "... = lenFINSEQ-1K4 (R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>))"
    using finseq_2_th_16 sorry
  finally have "lenFINSEQ-1K4 (R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>)) =HIDDENR1 lenFINSEQ-1K4 (R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>))"
     sorry
  then have A1: "lenFINSEQ-1K4 (mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>))) =HIDDENR1 lenFINSEQ-1K4 (R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>))"
    using finseq_2_th_72 sorry
  also have "... = lenFINSEQ-1K4 R1 +NAT-1K1 \<one>\<^sub>M"
    using finseq_2_th_16 sorry
  also have "... = n +NAT-1K1 \<one>\<^sub>M"
    using card_1_def_7 sorry
  finally have "lenFINSEQ-1K4 (mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>))) =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
     sorry
  have A2: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k"
  proof(rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A3: "k inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
    have A4: "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using A3 finseq_1_th_1 sorry
    have "mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k"
    proof-
      show "mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k"
      proof-
        have cases: "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M or k =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          using A4 xxreal_0_th_1 sorry
        have case1: "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k"
        proof(rule impI)
          assume "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          then have A5: "k <=XXREAL-0R1 n"
            using nat_1_th_13 sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 k"
            using A3 finseq_1_th_1 sorry
          then have A6: "k inTARSKIR2 SegFINSEQ-1K2 n"
            using A5 finseq_1_th_1 sorry
          then have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 R1)"
            using card_1_def_7 sorry
          then have "k inTARSKIR2 domFINSEQ-1K5 R1"
            using finseq_1_def_3 sorry
          then have A7: "(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>)).FUNCT-1K1 k =COMPLEX1R1 R1 .FUNCT-1K1 k"
            using finseq_1_def_7 sorry
          have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 R2)"
            using A6 card_1_def_7 sorry
          then have "k inTARSKIR2 domFINSEQ-1K5 R2"
            using finseq_1_def_3 sorry
          then have "(R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)).FUNCT-1K1 k =COMPLEX1R1 R2 .FUNCT-1K1 k"
            using finseq_1_def_7 sorry
          then have A8: "mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 R1 .FUNCT-1K1 k *XCMPLX-0K3 R2 .FUNCT-1K1 k"
            using A7 rvsum_1_th_59 sorry
          have "lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2)) =COMPLEX1R1 n"
            using card_1_def_7 sorry
          then have "k inTARSKIR2 domFINSEQ-1K5 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2))"
            using A6 finseq_1_def_3 sorry
          then have "(mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k =COMPLEX1R1 mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) .FUNCT-1K1 k"
            using finseq_1_def_7 sorry
          thus "mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k"
            using A8 rvsum_1_th_59 sorry
        qed
        have case2: "k =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k"
        proof(rule impI)
          assume A9: "k =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          then have "k =COMPLEX1R1 lenFINSEQ-1K4 R1 +NAT-1K1 \<one>\<^sub>M"
            using card_1_def_7 sorry
          then have A10: "(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>)).FUNCT-1K1 k =COMPLEX1R1 r1"
            using finseq_1_th_42 sorry
          have A11: "n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2)) +NAT-1K1 \<one>\<^sub>M"
            using card_1_def_7 sorry
          have "k =COMPLEX1R1 lenFINSEQ-1K4 R2 +NAT-1K1 \<one>\<^sub>M"
            using A9 card_1_def_7 sorry
          then have "(R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)).FUNCT-1K1 k =COMPLEX1R1 r2"
            using finseq_1_th_42 sorry
          then have "mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 r1 *REAL-1K4 r2"
            using A10 rvsum_1_th_59 sorry
          thus "mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k"
            using A9 A11 finseq_1_th_42 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) .FUNCT-1K1 k =COMPLEX1R1 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1 *REAL-1K4 r2 *>)).FUNCT-1K1 k"
       sorry
  qed "sorry"
  obtain rr where 
    [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr = r1 *REAL-1K4 r2"
     sorry
  have "mltRVSUM-1K18(R1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r1*>),R2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> r2*>)) be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (n +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using A1 finseq_2_th_92 sorry
  thus "mltRVSUM-1K18(R1 ^FINSEQ-1K8 (<*FINSEQ-1K10 r1*>),R2 ^FINSEQ-1K8 (<*FINSEQ-1K10 r2*>)) =FINSEQ-1R1 mltRVSUM-1K19\<^bsub>(n)\<^esub>(R1,R2) ^FINSEQ-1K8 (<*FINSEQ-1K10 r1 *XCMPLX-0K3 r2 *>)"
    using A2 finseq_2_th_119 sorry
qed "sorry"

mtheorem rfunct_4_th_3:
" for n be NatNAT-1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 R =COMPLEX1R1 0NUMBERSK6 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies 0NUMBERSK6 <=XXREAL-0R1 R .FUNCT-1K1 i) implies ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies R .FUNCT-1K1 i =COMPLEX1R1 0NUMBERSK6)"
proof-
  have " for n be NatNAT-1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 R =COMPLEX1R1 0NUMBERSK6 & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies 0NUMBERSK6 <=XXREAL-0R1 R .FUNCT-1K1 i) implies (( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k inTARSKIR2 domFINSEQ-1K5 R & R .FUNCT-1K1 k <>HIDDENR2 0NUMBERSK6) implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    assume A1: "SumRVSUM-1K22 R =COMPLEX1R1 0NUMBERSK6"
      and A2: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies 0NUMBERSK6 <=XXREAL-0R1 R .FUNCT-1K1 i"
    have A3: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 R implies 0NUMBERSK6 <=XXREAL-0R1 R .FUNCT-1K1 i"
      using A2 sorry
    assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k inTARSKIR2 domFINSEQ-1K5 R & R .FUNCT-1K1 k <>HIDDENR2 0NUMBERSK6"
    then obtain k where
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A4: "k inTARSKIR2 domFINSEQ-1K5 R"and A5: "R .FUNCT-1K1 k <>HIDDENR2 0NUMBERSK6"
       sorry
    have "0NUMBERSK6 <=XXREAL-0R1 R .FUNCT-1K1 k"
      using A2 A4 sorry
    thus " False "
      using A1 A3 A4 A5 rvsum_1_th_85 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_4:
" for n be NatNAT-1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies 0NUMBERSK6 =COMPLEX1R1 R .FUNCT-1K1 i) implies R =FINSEQ-1R1 n  |->FINSEQ-2K2 (0NUMBERSK6)"
proof(rule ballI,rule ballI,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
  assume A1: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 R implies 0NUMBERSK6 =COMPLEX1R1 R .FUNCT-1K1 i"
  have A2: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 R implies R .FUNCT-1K1 k =COMPLEX1R1 (n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)).FUNCT-1K1 k"
  proof(rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 R"
    then have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 R)"
      using finseq_1_th_1 sorry
    then have "k inTARSKIR2 domFINSEQ-1K5 R"
      using finseq_1_def_3 sorry
    then have A3: "R .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6"
      using A1 sorry
    show "R .FUNCT-1K1 k =COMPLEX1R1 (n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)).FUNCT-1K1 k"
      using A3 sorry
  qed "sorry"
  have "lenFINSEQ-1K4 R =HIDDENR1 n"
    using card_1_def_7 sorry
  also have "... = lenFINSEQ-1K4 (n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6))"
    using card_1_def_7 sorry
  finally have "lenFINSEQ-1K4 R =HIDDENR1 lenFINSEQ-1K4 (n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6))"
     sorry
  thus "R =FINSEQ-1R1 n  |->FINSEQ-2K2 (0NUMBERSK6)"
    using A2 finseq_1_th_14 sorry
qed "sorry"

mtheorem rfunct_4_th_5:
" for n be NatNAT-1M1 holds  for R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R) =FINSEQ-1R1 n  |->FINSEQ-2K2 (0NUMBERSK6)"
proof(rule ballI,rule ballI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix R assume [ty]: "R be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
  have A1: "lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)),R)) =COMPLEX1R1 n"
    using card_1_def_7 sorry
  have A2: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R)) implies mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R) .FUNCT-1K1 k =COMPLEX1R1 (n  |->FINSEQ-2K2 (0NUMBERSK6)).FUNCT-1K1 k"
  proof(rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R))"
    have "mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R) .FUNCT-1K1 k =HIDDENR1 (n  |->FINSEQ-2K2 (0NUMBERSK6)).FUNCT-1K1 k *XCMPLX-0K3 R .FUNCT-1K1 k"
      using rvsum_1_th_60 sorry
    also have "... = (0NUMBERSK6)*XCMPLX-0K3 R .FUNCT-1K1 k"
       sorry
    finally have "mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R) .FUNCT-1K1 k =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 R .FUNCT-1K1 k"
       sorry
    thus "mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R) .FUNCT-1K1 k =COMPLEX1R1 (n  |->FINSEQ-2K2 (0NUMBERSK6)).FUNCT-1K1 k"
       sorry
  qed "sorry"
  have "lenFINSEQ-1K4 (n  |->FINSEQ-2K2 (0NUMBERSK6)) =COMPLEX1R1 n"
    using card_1_def_7 sorry
  thus "mltRVSUM-1K18(n  |->FINSEQ-2K2 (0NUMBERSK6),R) =FINSEQ-1R1 n  |->FINSEQ-2K2 (0NUMBERSK6)"
    using A1 A2 finseq_1_th_14 sorry
qed "sorry"

(*begin*)
mdef rfunct_4_def_1 (" _ is-strictly-convex-onRFUNCT-4R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-strictly-convex-onRFUNCT-4R1 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"..

mtheorem rfunct_4_th_6:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X implies f is-convex-onRFUNCT-3R2 X"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X implies f is-convex-onRFUNCT-3R2 X"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "f is-strictly-convex-onRFUNCT-4R1 X"
    have A2: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
    proof-
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A3: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
        have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
        proof(rule ballI,rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          fix s assume [ty]: "s be RealXREAL-0M1"
          assume A4: "(r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
          have "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
          proof-
            show "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
            proof-
              have cases: "(p =COMPLEX1R1 0NUMBERSK6 or p =COMPLEX1R1 \<one>\<^sub>M) or 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
                using A3 xxreal_0_th_1 sorry
              have case1: "p =COMPLEX1R1 0NUMBERSK6 implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
              proof(rule impI)
                assume "p =COMPLEX1R1 0NUMBERSK6"
                thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                   sorry
              qed
              have case2: "p =COMPLEX1R1 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
              proof(rule impI)
                assume "p =COMPLEX1R1 \<one>\<^sub>M"
                thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                   sorry
              qed
              have case3: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
              proof(rule impI)
                assume A5: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
                have "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                proof-
                  show "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                  proof-
                    have cases: "r =COMPLEX1R1 s or r <>HIDDENR2 s"
                       sorry
                    have case1: "r =COMPLEX1R1 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                    proof(rule impI)
                      assume "r =COMPLEX1R1 s"
                      thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                         sorry
                    qed
                    have case2: "r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                    proof(rule impI)
                      assume "r <>HIDDENR2 s"
                      thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                        using A1 A4 A5 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed
          thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
             sorry
        qed "sorry"
        thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "X c=TARSKIR1 domRELAT-1K1 f"
      using A1 sorry
    thus "f is-convex-onRFUNCT-3R2 X"
      using A2 rfunct_3_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strictly-convex-onRFUNCT-4R1 [.RCOMP-1K1 a,b .] iff [.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 [.RCOMP-1K1 a,b .] & s inHIDDENR3 [.RCOMP-1K1 a,b .]) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-strictly-convex-onRFUNCT-4R1 [.RCOMP-1K1 a,b .] implies [.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .]) & x <>HIDDENR2 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y))) & ([.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .]) & x <>HIDDENR2 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)) implies f is-strictly-convex-onRFUNCT-4R1 [.RCOMP-1K1 a,b .])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?ab = "{r where r be RealXREAL-0M1 : a <=XXREAL-0R1 r & r <=XXREAL-0R1 b }"
    have A1: "[.RCOMP-1K1 a,b .] =XBOOLE-0R4 ?ab"
      using rcomp_1_def_1 sorry
    show "f is-strictly-convex-onRFUNCT-4R1 [.RCOMP-1K1 a,b .] implies [.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .]) & x <>HIDDENR2 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y))"
    proof-
      have "f is-strictly-convex-onRFUNCT-4R1 [.RCOMP-1K1 a,b .] implies [.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 a,b .] & (y inHIDDENR3 [.RCOMP-1K1 a,b .] & x <>HIDDENR2 y) implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y))"
      proof(rule impI,rule conjMI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        assume A2: "f is-strictly-convex-onRFUNCT-4R1 [.RCOMP-1K1 a,b .]"
        thus "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f"
           sorry
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A3: "0NUMBERSK6 <XXREAL-0R3 p"
          and A4: "p <XXREAL-0R3 \<one>\<^sub>M"
        have A5: "0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 p"
          using A4 xreal_1_th_48 sorry
        have A6: "p *XCMPLX-0K3 b +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =COMPLEX1R1 b"
           sorry
        have A7: "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 a =COMPLEX1R1 a"
           sorry
        fix x assume [ty]: "x be RealXREAL-0M1"
        fix y assume [ty]: "y be RealXREAL-0M1"
        assume A8: "x inHIDDENR3 [.RCOMP-1K1 a,b .]"
          and A9: "y inHIDDENR3 [.RCOMP-1K1 a,b .]"
          and A10: "x <>HIDDENR2 y"
        have A11: " ex r2 be RealXREAL-0M1 st (r2 =COMPLEX1R1 y & a <=XXREAL-0R1 r2) & r2 <=XXREAL-0R1 b"
          using A1 A9 sorry
        then have A12: "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b"
          using A5 xreal_1_th_64 sorry
        have A13: " ex r1 be RealXREAL-0M1 st (r1 =COMPLEX1R1 x & a <=XXREAL-0R1 r1) & r1 <=XXREAL-0R1 b"
          using A1 A8 sorry
        then have "p *XCMPLX-0K3 x <=XXREAL-0R1 p *XCMPLX-0K3 b"
          using A3 xreal_1_th_64 sorry
        then have A14: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y <=XXREAL-0R1 b"
          using A12 A6 xreal_1_th_7 sorry
        have A15: "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y"
          using A5 A11 xreal_1_th_64 sorry
        have "p *XCMPLX-0K3 a <=XXREAL-0R1 p *XCMPLX-0K3 x"
          using A3 A13 xreal_1_th_64 sorry
        then have "a <=XXREAL-0R1 p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y"
          using A15 A7 xreal_1_th_7 sorry
        then have "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 ?ab"
          using A14 sorry
        thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
          using A1 A2 A3 A4 A8 A9 A10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A16: "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f"
      and A17: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .]) & x <>HIDDENR2 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
    have "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .]) & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 [.RCOMP-1K1 a,b .] implies  not ( not x <>HIDDENR2 y & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)))"
    proof(rule conjMI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      show "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELAT-1K1 f"
        using A16 sorry
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A18: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
      fix x assume [ty]: "x be RealXREAL-0M1"
      fix y assume [ty]: "y be RealXREAL-0M1"
      assume A19: "x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .]"
        and "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 [.RCOMP-1K1 a,b .]"
      show " not ( not x <>HIDDENR2 y & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
        using A17 A18 A19 sorry
    qed "sorry"
    thus "f is-strictly-convex-onRFUNCT-4R1 [.RCOMP-1K1 a,b .]"
      using rfunct_4_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_8:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convex-onRFUNCT-3R2 X iff X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (f is-convex-onRFUNCT-3R2 X &  not (X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) &  not f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)))) &  not ((X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) &  not f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c))) &  not f is-convex-onRFUNCT-3R2 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A1: "X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c) implies f is-convex-onRFUNCT-3R2 X"
    proof(rule impMI ,rule impI)
      assume A2: "X c=TARSKIR1 domRELAT-1K1 f"
        and A3: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c"
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
      proof-
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A4: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
          have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
          proof(rule ballI,rule ballI,rule impI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            fix s assume [ty]: "s be RealXREAL-0M1"
            assume A5: "(r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
            have "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
            proof-
              show "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
              proof-
                have cases: "(p =COMPLEX1R1 0NUMBERSK6 or p =COMPLEX1R1 \<one>\<^sub>M) or 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
                  using A4 xxreal_0_th_1 sorry
                have case1: "p =COMPLEX1R1 0NUMBERSK6 implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                proof(rule impI)
                  assume "p =COMPLEX1R1 0NUMBERSK6"
                  thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                     sorry
                qed
                have case2: "p =COMPLEX1R1 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                proof(rule impI)
                  assume "p =COMPLEX1R1 \<one>\<^sub>M"
                  thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                     sorry
                qed
                have case3: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                proof(rule impI)
                  assume A6: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
                  then have A7: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 p"
                    using xreal_1_th_50 sorry
                  show "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                  proof-
                    have cases: "(r =COMPLEX1R1 s or r >XXREAL-0R4 s) or r <XXREAL-0R3 s"
                      using xxreal_0_th_1 sorry
                    have case1: "r =COMPLEX1R1 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                    proof(rule impI)
                      assume "r =COMPLEX1R1 s"
                      thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                         sorry
                    qed
                    have case2: "r >XXREAL-0R4 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                    proof(rule impI)
                      assume A8: "r >XXREAL-0R4 s"
                      let ?t = "p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s"
                      have A9: "r -XCMPLX-0K6 s >XXREAL-0R4 0NUMBERSK6"
                        using A8 xreal_1_th_50 sorry
                      have A10: "r -XCMPLX-0K6 ?t =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r -XCMPLX-0K6 s)"
                         sorry
                      then have "r -XCMPLX-0K6 ?t >XXREAL-0R4 0NUMBERSK6"
                        using A7 A9 xreal_1_th_129 sorry
                      then have A11: "?t <XXREAL-0R3 r"
                        using xreal_1_th_47 sorry
                      have A12: "?t -XCMPLX-0K6 s =COMPLEX1R1 p *XCMPLX-0K3 (r -XCMPLX-0K6 s)"
                         sorry
                      then have A13: "(?t -XCMPLX-0K6 s)/XCMPLX-0K7 (r -XCMPLX-0K6 s) =COMPLEX1R1 p"
                        using A9 xcmplx_1_th_89 sorry
                      have "?t -XCMPLX-0K6 s >XXREAL-0R4 0NUMBERSK6"
                        using A6 A9 A12 xreal_1_th_129 sorry
                      then have A14: "s <XXREAL-0R3 ?t"
                        using xreal_1_th_47 sorry
                      have "(r -XCMPLX-0K6 ?t)/XCMPLX-0K7 (r -XCMPLX-0K6 s) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 p"
                        using A9 A10 xcmplx_1_th_89 sorry
                      thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                        using A3 A5 A14 A11 A13 sorry
                    qed
                    have case3: "r <XXREAL-0R3 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                    proof(rule impI)
                      assume A15: "r <XXREAL-0R3 s"
                      let ?t = "p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s"
                      have A16: "s -XCMPLX-0K6 r >XXREAL-0R4 0NUMBERSK6"
                        using A15 xreal_1_th_50 sorry
                      have A17: "s -XCMPLX-0K6 ?t =COMPLEX1R1 p *XCMPLX-0K3 (s -XCMPLX-0K6 r)"
                         sorry
                      then have "s -XCMPLX-0K6 ?t >XXREAL-0R4 0NUMBERSK6"
                        using A6 A16 xreal_1_th_129 sorry
                      then have A18: "?t <XXREAL-0R3 s"
                        using xreal_1_th_47 sorry
                      have A19: "?t -XCMPLX-0K6 r =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (s -XCMPLX-0K6 r)"
                         sorry
                      then have A20: "(?t -XCMPLX-0K6 r)/XCMPLX-0K7 (s -XCMPLX-0K6 r) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 p"
                        using A16 xcmplx_1_th_89 sorry
                      have "?t -XCMPLX-0K6 r >XXREAL-0R4 0NUMBERSK6"
                        using A7 A16 A19 xreal_1_th_129 sorry
                      then have A21: "r <XXREAL-0R3 ?t"
                        using xreal_1_th_47 sorry
                      have "(s -XCMPLX-0K6 ?t)/XCMPLX-0K7 (s -XCMPLX-0K6 r) =COMPLEX1R1 p"
                        using A16 A17 xcmplx_1_th_89 sorry
                      thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                        using A3 A5 A21 A18 A20 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 case3 sorry
                  qed
                qed
                show " ?thesis "
                  using cases case1 case2 case3 sorry
              qed
            qed
            thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
               sorry
          qed "sorry"
          thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-convex-onRFUNCT-3R2 X"
        using A2 rfunct_3_def_12 sorry
    qed
    have "f is-convex-onRFUNCT-3R2 X implies X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)"
    proof-
      have "f is-convex-onRFUNCT-3R2 X implies X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) &  not f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c))"
      proof(rule impI)
        assume A22: "f is-convex-onRFUNCT-3R2 X"
        have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c"
        proof-
          have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & (a <XXREAL-0R3 b & b <XXREAL-0R3 c) implies f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix a assume [ty]: "a be RealXREAL-0M1"
            fix b assume [ty]: "b be RealXREAL-0M1"
            fix c assume [ty]: "c be RealXREAL-0M1"
            assume A23: "(a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X"
              and A24: "a <XXREAL-0R3 b & b <XXREAL-0R3 c"
            let ?p = "(c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
            have A25: "c -XCMPLX-0K6 b <XXREAL-0R3 c -XCMPLX-0K6 a & 0NUMBERSK6 <XXREAL-0R3 c -XCMPLX-0K6 b"
              using A24 xreal_1_th_10 xreal_1_th_50 sorry
            then have A26: "(c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a) <XXREAL-0R3 \<one>\<^sub>M"
              using xreal_1_th_189 sorry
            have A27: "?p +XCMPLX-0K2 (b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a) =HIDDENR1 ((c -XCMPLX-0K6 b)+XCMPLX-0K2 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
              using xcmplx_1_th_62 sorry
            also have "... = \<one>\<^sub>M"
              using A25 xcmplx_1_th_60 sorry
            finally have "?p +XCMPLX-0K2 (b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a) =HIDDENR1 \<one>\<^sub>M"
               sorry
            then have "?p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?p)*XCMPLX-0K3 c =HIDDENR1 (a *XCMPLX-0K3 (c -XCMPLX-0K6 b))/XCMPLX-0K7 (c -XCMPLX-0K6 a) +XCMPLX-0K2 c *XCMPLX-0K3 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))"
              using xcmplx_1_th_74 sorry
            also have "... = (a *XCMPLX-0K3 (c -XCMPLX-0K6 b))/XCMPLX-0K7 (c -XCMPLX-0K6 a) +XCMPLX-0K2 (c *XCMPLX-0K3 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
              using xcmplx_1_th_74 sorry
            also have "... = ((c *XCMPLX-0K3 a -XCMPLX-0K6 b *XCMPLX-0K3 a)+XCMPLX-0K2 (b -XCMPLX-0K6 a)*XCMPLX-0K3 c)/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
              using xcmplx_1_th_62 sorry
            also have "... = (b *XCMPLX-0K3 (c -XCMPLX-0K6 a))/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
               sorry
            finally have "?p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?p)*XCMPLX-0K3 c =HIDDENR1 (b *XCMPLX-0K3 (c -XCMPLX-0K6 a))/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
               sorry
            then have "?p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?p)*XCMPLX-0K3 c =COMPLEX1R1 b"
              using A25 xcmplx_1_th_89 sorry
            thus "f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c"
              using A22 A23 A25 A26 A27 rfunct_3_def_12 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) &  not f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c))"
          using A22 rfunct_3_def_12 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not (f is-convex-onRFUNCT-3R2 X &  not (X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) &  not f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)))) &  not ((X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) &  not f .FUNCT-1K1 b <=XXREAL-0R1 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c))) &  not f is-convex-onRFUNCT-3R2 X)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_9:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strictly-convex-onRFUNCT-4R1 X iff X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (f is-strictly-convex-onRFUNCT-4R1 X &  not (X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) & f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)))) &  not ((X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) & f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c))) &  not f is-strictly-convex-onRFUNCT-4R1 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A1: "X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c) implies f is-strictly-convex-onRFUNCT-4R1 X"
    proof(rule impMI ,rule impI)
      assume A2: "X c=TARSKIR1 domRELAT-1K1 f"
        and A3: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c"
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
      proof-
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A4: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
          have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
          proof-
            have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix r assume [ty]: "r be RealXREAL-0M1"
              fix s assume [ty]: "s be RealXREAL-0M1"
              assume A5: "(r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
                and A6: "r <>HIDDENR2 s"
              have "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
              proof-
                have " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                proof-
                  have " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                  proof-
                    show " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                    proof-
                      have cases: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
                        using A4 sorry
                      have case1: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                      proof(rule impI)
                        assume A7: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
                        then have A8: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 p"
                          using xreal_1_th_50 sorry
                        have " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                        proof-
                          show " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                          proof-
                            have cases: "r >XXREAL-0R4 s or r <XXREAL-0R3 s"
                              using A6 xxreal_0_th_1 sorry
                            have case1: "r >XXREAL-0R4 s implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                            proof(rule impI)
                              assume A9: "r >XXREAL-0R4 s"
                              let ?t = "p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s"
                              have A10: "r -XCMPLX-0K6 s >XXREAL-0R4 0NUMBERSK6"
                                using A9 xreal_1_th_50 sorry
                              have A11: "r -XCMPLX-0K6 ?t =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r -XCMPLX-0K6 s)"
                                 sorry
                              then have "r -XCMPLX-0K6 ?t >XXREAL-0R4 0NUMBERSK6"
                                using A8 A10 xreal_1_th_129 sorry
                              then have A12: "?t <XXREAL-0R3 r"
                                using xreal_1_th_47 sorry
                              have A13: "?t -XCMPLX-0K6 s =COMPLEX1R1 p *XCMPLX-0K3 (r -XCMPLX-0K6 s)"
                                 sorry
                              then have A14: "(?t -XCMPLX-0K6 s)/XCMPLX-0K7 (r -XCMPLX-0K6 s) =COMPLEX1R1 p"
                                using A10 xcmplx_1_th_89 sorry
                              have "?t -XCMPLX-0K6 s >XXREAL-0R4 0NUMBERSK6"
                                using A7 A10 A13 xreal_1_th_129 sorry
                              then have A15: "s <XXREAL-0R3 ?t"
                                using xreal_1_th_47 sorry
                              have "(r -XCMPLX-0K6 ?t)/XCMPLX-0K7 (r -XCMPLX-0K6 s) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 p"
                                using A10 A11 xcmplx_1_th_89 sorry
                              thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                                using A3 A5 A15 A12 A14 sorry
                            qed
                            have case2: "r <XXREAL-0R3 s implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                            proof(rule impI)
                              assume A16: "r <XXREAL-0R3 s"
                              let ?t = "p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s"
                              have A17: "s -XCMPLX-0K6 r >XXREAL-0R4 0NUMBERSK6"
                                using A16 xreal_1_th_50 sorry
                              have A18: "s -XCMPLX-0K6 ?t =COMPLEX1R1 p *XCMPLX-0K3 (s -XCMPLX-0K6 r)"
                                 sorry
                              then have "s -XCMPLX-0K6 ?t >XXREAL-0R4 0NUMBERSK6"
                                using A7 A17 xreal_1_th_129 sorry
                              then have A19: "?t <XXREAL-0R3 s"
                                using xreal_1_th_47 sorry
                              have A20: "?t -XCMPLX-0K6 r =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (s -XCMPLX-0K6 r)"
                                 sorry
                              then have A21: "(?t -XCMPLX-0K6 r)/XCMPLX-0K7 (s -XCMPLX-0K6 r) =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 p"
                                using A17 xcmplx_1_th_89 sorry
                              have "?t -XCMPLX-0K6 r >XXREAL-0R4 0NUMBERSK6"
                                using A8 A17 A20 xreal_1_th_129 sorry
                              then have A22: "r <XXREAL-0R3 ?t"
                                using xreal_1_th_47 sorry
                              have "(s -XCMPLX-0K6 ?t)/XCMPLX-0K7 (s -XCMPLX-0K6 r) =COMPLEX1R1 p"
                                using A17 A18 xcmplx_1_th_89 sorry
                              thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                                using A3 A5 A22 A19 A21 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                        thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                           sorry
                      qed
                      show " ?thesis "
                        using cases case1 sorry
                    qed
                  qed
                  thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                     sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-strictly-convex-onRFUNCT-4R1 X"
        using A2 sorry
    qed
    have "f is-strictly-convex-onRFUNCT-4R1 X implies X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)"
    proof-
      have "f is-strictly-convex-onRFUNCT-4R1 X implies X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) & f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c))"
      proof(rule impI)
        assume A23: "f is-strictly-convex-onRFUNCT-4R1 X"
        have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & a <XXREAL-0R3 b) & b <XXREAL-0R3 c implies f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c"
        proof-
          have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) & (a <XXREAL-0R3 b & b <XXREAL-0R3 c) implies  not f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix a assume [ty]: "a be RealXREAL-0M1"
            fix b assume [ty]: "b be RealXREAL-0M1"
            fix c assume [ty]: "c be RealXREAL-0M1"
            assume A24: "(a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X"
              and A25: "a <XXREAL-0R3 b & b <XXREAL-0R3 c"
            let ?p = "(c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
            have A26: "c -XCMPLX-0K6 b <XXREAL-0R3 c -XCMPLX-0K6 a & 0NUMBERSK6 <XXREAL-0R3 c -XCMPLX-0K6 b"
              using A25 xreal_1_th_10 xreal_1_th_50 sorry
            then have A27: "0NUMBERSK6 <XXREAL-0R3 (c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a) & (c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a) <XXREAL-0R3 \<one>\<^sub>M"
              using xreal_1_th_139 xreal_1_th_189 sorry
            have A28: "?p +XCMPLX-0K2 (b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a) =HIDDENR1 ((c -XCMPLX-0K6 b)+XCMPLX-0K2 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
              using xcmplx_1_th_62 sorry
            also have "... = \<one>\<^sub>M"
              using A26 xcmplx_1_th_60 sorry
            finally have "?p +XCMPLX-0K2 (b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a) =HIDDENR1 \<one>\<^sub>M"
               sorry
            then have "?p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?p)*XCMPLX-0K3 c =HIDDENR1 (a *XCMPLX-0K3 (c -XCMPLX-0K6 b))/XCMPLX-0K7 (c -XCMPLX-0K6 a) +XCMPLX-0K2 c *XCMPLX-0K3 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))"
              using xcmplx_1_th_74 sorry
            also have "... = (a *XCMPLX-0K3 (c -XCMPLX-0K6 b))/XCMPLX-0K7 (c -XCMPLX-0K6 a) +XCMPLX-0K2 (c *XCMPLX-0K3 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
              using xcmplx_1_th_74 sorry
            also have "... = ((c *XCMPLX-0K3 a -XCMPLX-0K6 b *XCMPLX-0K3 a)+XCMPLX-0K2 (b -XCMPLX-0K6 a)*XCMPLX-0K3 c)/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
              using xcmplx_1_th_62 sorry
            also have "... = (b *XCMPLX-0K3 (c -XCMPLX-0K6 a))/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
               sorry
            finally have "?p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?p)*XCMPLX-0K3 c =HIDDENR1 (b *XCMPLX-0K3 (c -XCMPLX-0K6 a))/XCMPLX-0K7 (c -XCMPLX-0K6 a)"
               sorry
            then have "?p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?p)*XCMPLX-0K3 c =COMPLEX1R1 b"
              using A26 xcmplx_1_th_89 sorry
            thus " not f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c"
              using A23 A24 A25 A27 A28 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) & f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c))"
          using A23 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not (f is-strictly-convex-onRFUNCT-4R1 X &  not (X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) & f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c)))) &  not ((X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & c inHIDDENR3 X) &  not a <XXREAL-0R3 b) &  not b <XXREAL-0R3 c) & f .FUNCT-1K1 b <XXREAL-0R3 ((c -XCMPLX-0K6 b)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (c -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 c))) &  not f is-strictly-convex-onRFUNCT-4R1 X)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_10:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & Y c=TARSKIR1 X implies f is-strictly-convex-onRFUNCT-4R1 Y"
  using xboole_1_th_1 sorry

mlemma rfunct_4_lm_1:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X implies f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X implies f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "f is-strictly-convex-onRFUNCT-4R1 X"
    then have A2: "X c=TARSKIR1 domRELAT-1K1 f"
       sorry
    have A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((t inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & t <>HIDDENR2 s implies (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 s)"
    proof-
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((t inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not t <>HIDDENR2 s) & (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 s))"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A4: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
        have " for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((t inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & t <>HIDDENR2 s implies (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 s"
        proof-
          have " for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (t inHIDDENR3 X & s inHIDDENR3 X) & (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X & t <>HIDDENR2 s) implies  not (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 s"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix t assume [ty]: "t be RealXREAL-0M1"
            fix s assume [ty]: "s be RealXREAL-0M1"
            assume A5: "t inHIDDENR3 X & s inHIDDENR3 X"
              and A6: "p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
              and A7: "t <>HIDDENR2 s"
            have "f .FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
              using A1 A4 A5 A6 A7 sorry
            then have A8: "f .FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) -XCMPLX-0K6 r <XXREAL-0R3 (p *XCMPLX-0K3 f .FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)-XCMPLX-0K6 r"
              using xreal_1_th_9 sorry
            have "(f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 t =COMPLEX1R1 f .FUNCT-1K1 t -XCMPLX-0K6 r & (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 s -XCMPLX-0K6 r"
              using A2 A5 valued_1_th_3 sorry
            thus " not (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 s"
              using A2 A6 A8 valued_1_th_3 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((t inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not t <>HIDDENR2 s) & (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 s)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)"
      using valued_1_th_3 sorry
    thus "f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_11:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X iff f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  not (f is-strictly-convex-onRFUNCT-4R1 X &  not f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X) &  not (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X &  not f is-strictly-convex-onRFUNCT-4R1 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "domRELAT-1K1 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 domRELAT-1K1 f"
      using valued_1_th_3 sorry
    have A2: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELAT-1K1 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) implies ((f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)-VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 r)).FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A3: "x inTARSKIR2 domRELAT-1K1 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)"
      then have "((f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)-VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 r)).FUNCT-1K1 x =HIDDENR1 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 r)"
        using valued_1_th_3 sorry
      also have "... = (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 r"
         sorry
      also have "... = (f .FUNCT-1K1 x -XCMPLX-0K6 r)+XCMPLX-0K2 r"
        using A1 A3 valued_1_th_3 sorry
      also have "... = f .FUNCT-1K1 x -XCMPLX-0K6 (r -XCMPLX-0K6 r)"
         sorry
      finally have "((f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)-VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 r)).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x -XCMPLX-0K6 (r -XCMPLX-0K6 r)"
         sorry
      thus "((f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)-VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 r)).FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)-VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 r)) =XBOOLE-0R4 domRELAT-1K1 (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)"
      using valued_1_th_3 sorry
    then have "(f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)-VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 r) =FUNCT-1R1 f"
      using A1 A2 partfun1_th_5 sorry
    thus " not (f is-strictly-convex-onRFUNCT-4R1 X &  not f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X) &  not (f -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-strictly-convex-onRFUNCT-4R1 X &  not f is-strictly-convex-onRFUNCT-4R1 X)"
      using rfunct_4_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rfunct_4_lm_2:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds 0NUMBERSK6 <XXREAL-0R3 r implies (f is-strictly-convex-onRFUNCT-4R1 X implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X)"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds 0NUMBERSK6 <XXREAL-0R3 r implies (f is-strictly-convex-onRFUNCT-4R1 X implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 r"
    assume A2: "f is-strictly-convex-onRFUNCT-4R1 X"
    then have "X c=TARSKIR1 domRELAT-1K1 f"
       sorry
    then have A3: "X c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using valued_1_def_5 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((t inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & t <>HIDDENR2 s implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 s)"
    proof-
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((t inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not t <>HIDDENR2 s) & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 s))"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A4: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
        have " for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((t inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & t <>HIDDENR2 s implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 s"
        proof-
          have " for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (t inHIDDENR3 X & s inHIDDENR3 X) & (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X & t <>HIDDENR2 s) implies  not (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 s"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix t assume [ty]: "t be RealXREAL-0M1"
            fix s assume [ty]: "s be RealXREAL-0M1"
            assume A5: "t inHIDDENR3 X & s inHIDDENR3 X"
              and A6: "p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
              and A7: "t <>HIDDENR2 s"
            have "f .FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
              using A2 A4 A5 A6 A7 sorry
            then have A8: "r *XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 r *XCMPLX-0K3 (p *XCMPLX-0K3 f .FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
              using A1 xreal_1_th_68 sorry
            have "p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 t =COMPLEX1R1 p *XCMPLX-0K3 (r *XCMPLX-0K3 f .FUNCT-1K1 t) & (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 s =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r *XCMPLX-0K3 f .FUNCT-1K1 s)"
              using A3 A5 valued_1_def_5 sorry
            thus " not (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 s"
              using A3 A6 A8 valued_1_def_5 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " for t be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((t inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not t <>HIDDENR2 s) & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (p *XCMPLX-0K3 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 t +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 s)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_12:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds 0NUMBERSK6 <XXREAL-0R3 r implies (f is-strictly-convex-onRFUNCT-4R1 X iff r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X)"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds 0NUMBERSK6 <XXREAL-0R3 r implies  not (f is-strictly-convex-onRFUNCT-4R1 X &  not r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X) &  not (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X &  not f is-strictly-convex-onRFUNCT-4R1 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 r)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) =XBOOLE-0R4 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using valued_1_def_5 sorry
    assume A2: "0NUMBERSK6 <XXREAL-0R3 r"
    have A3: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies ((\<one>\<^sub>M /XCMPLX-0K7 r)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A4: "x inTARSKIR2 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      then have "((\<one>\<^sub>M /XCMPLX-0K7 r)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 r)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
        using A1 valued_1_def_5 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 r)*XCMPLX-0K3 (r *XCMPLX-0K3 f .FUNCT-1K1 x)"
        using A4 valued_1_def_5 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 r)*XCMPLX-0K3 r)*XCMPLX-0K3 f .FUNCT-1K1 x"
         sorry
      also have "... = \<one>\<^sub>M *XCMPLX-0K3 f .FUNCT-1K1 x"
        using A2 xcmplx_1_th_106 sorry
      finally have "((\<one>\<^sub>M /XCMPLX-0K7 r)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 f .FUNCT-1K1 x"
         sorry
      thus "((\<one>\<^sub>M /XCMPLX-0K7 r)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =XBOOLE-0R4 domRELAT-1K1 f"
      using valued_1_def_5 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 r)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =FUNCT-1R1 f"
      using A1 A3 partfun1_th_5 sorry
    thus " not (f is-strictly-convex-onRFUNCT-4R1 X &  not r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X) &  not (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X &  not f is-strictly-convex-onRFUNCT-4R1 X)"
      using A2 rfunct_4_lm_2 xreal_1_th_139 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_13:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & g is-strictly-convex-onRFUNCT-4R1 X implies f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & g is-strictly-convex-onRFUNCT-4R1 X implies f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "f is-strictly-convex-onRFUNCT-4R1 X & g is-strictly-convex-onRFUNCT-4R1 X"
    then have "X c=TARSKIR1 domRELAT-1K1 f & X c=TARSKIR1 domRELAT-1K1 g"
       sorry
    then have "X c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
      using xboole_1_th_19 sorry
    then have A2: "X c=TARSKIR1 domRELAT-1K1 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g)"
      using valued_1_def_1 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s)"
    proof-
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s))"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A3: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
        have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s"
        proof-
          have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r inHIDDENR3 X & (s inHIDDENR3 X & (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X & r <>HIDDENR2 s)) implies  not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            fix s assume [ty]: "s be RealXREAL-0M1"
            assume A4: "r inHIDDENR3 X"
              and A5: "s inHIDDENR3 X"
              and A6: "p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
              and A7: "r <>HIDDENR2 s"
            have A8: "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) =COMPLEX1R1 f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) +XCMPLX-0K2 g .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r =COMPLEX1R1 f .FUNCT-1K1 r +XCMPLX-0K2 g .FUNCT-1K1 r"
              using A2 A4 A6 valued_1_def_1 sorry
            have A9: "(p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)+XCMPLX-0K2 (p *XCMPLX-0K3 g .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 g .FUNCT-1K1 s) =COMPLEX1R1 p *XCMPLX-0K3 (f .FUNCT-1K1 r +XCMPLX-0K2 g .FUNCT-1K1 r) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f .FUNCT-1K1 s +XCMPLX-0K2 g .FUNCT-1K1 s) & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 s +XCMPLX-0K2 g .FUNCT-1K1 s"
              using A2 A5 valued_1_def_1 sorry
            have "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s & g .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 g .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 g .FUNCT-1K1 s"
              using A1 A3 A4 A5 A6 A7 sorry
            thus " not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s"
              using A8 A9 xreal_1_th_8 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_14:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & g is-convex-onRFUNCT-3R2 X implies f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & g is-convex-onRFUNCT-3R2 X implies f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "f is-strictly-convex-onRFUNCT-4R1 X & g is-convex-onRFUNCT-3R2 X"
    then have "X c=TARSKIR1 domRELAT-1K1 f & X c=TARSKIR1 domRELAT-1K1 g"
      using rfunct_3_def_12 sorry
    then have "X c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
      using xboole_1_th_19 sorry
    then have A2: "X c=TARSKIR1 domRELAT-1K1 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g)"
      using valued_1_def_1 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s)"
    proof-
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s))"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A3: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
        have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s"
        proof-
          have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r inHIDDENR3 X & (s inHIDDENR3 X & (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X & r <>HIDDENR2 s)) implies  not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            fix s assume [ty]: "s be RealXREAL-0M1"
            assume A4: "r inHIDDENR3 X"
              and A5: "s inHIDDENR3 X"
              and A6: "p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
              and A7: "r <>HIDDENR2 s"
            have A8: "(f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) =COMPLEX1R1 f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) +XCMPLX-0K2 g .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r =COMPLEX1R1 f .FUNCT-1K1 r +XCMPLX-0K2 g .FUNCT-1K1 r"
              using A2 A4 A6 valued_1_def_1 sorry
            have A9: "(p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)+XCMPLX-0K2 (p *XCMPLX-0K3 g .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 g .FUNCT-1K1 s) =COMPLEX1R1 p *XCMPLX-0K3 (f .FUNCT-1K1 r +XCMPLX-0K2 g .FUNCT-1K1 r) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f .FUNCT-1K1 s +XCMPLX-0K2 g .FUNCT-1K1 s) & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 s +XCMPLX-0K2 g .FUNCT-1K1 s"
              using A2 A5 valued_1_def_1 sorry
            have "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s & g .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 g .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 g .FUNCT-1K1 s"
              using A1 A3 A4 A5 A6 A7 rfunct_3_def_12 sorry
            thus " not (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s"
              using A8 A9 xreal_1_th_8 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g).FUNCT-1K1 s)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_15:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds (f is-strictly-convex-onRFUNCT-4R1 X & g is-strictly-convex-onRFUNCT-4R1 X) & (a >XXREAL-0R4 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 or a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) implies a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X & (g is-strictly-convex-onRFUNCT-4R1 X & (a >XXREAL-0R4 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 or a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6)) implies a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "f is-strictly-convex-onRFUNCT-4R1 X"
      and A2: "g is-strictly-convex-onRFUNCT-4R1 X"
      and A3: "a >XXREAL-0R4 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 or a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6"
    have "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
    proof-
      show "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
      proof-
        have cases: "(a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 or a >XXREAL-0R4 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6) or a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6"
          using A3 sorry
        have case1: "a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
        proof(rule impI)
          assume "a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6"
          then have "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X & b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
            using A1 A2 rfunct_4_th_12 sorry
          thus "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
            using rfunct_4_th_13 sorry
        qed
        have case2: "a >XXREAL-0R4 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6 implies a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
        proof(rule impI)
          assume A4: "a >XXREAL-0R4 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6"
          have A5: "X c=TARSKIR1 domRELAT-1K1 g"
            using A2 sorry
          have "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-strictly-convex-onRFUNCT-4R1 X"
            using A1 A4 rfunct_4_th_12 sorry
          thus "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
            using A4 A5 rfunct_4_th_14 rfunct_3_th_57 sorry
        qed
        have case3: "a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
        proof(rule impI)
          assume A6: "a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6"
          have A7: "X c=TARSKIR1 domRELAT-1K1 f"
            using A1 sorry
          have "b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
            using A2 A6 rfunct_4_th_12 sorry
          thus "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
            using A6 A7 rfunct_4_th_14 rfunct_3_th_57 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g is-strictly-convex-onRFUNCT-4R1 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_16:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-convex-onRFUNCT-3R2 X iff X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  not (f is-convex-onRFUNCT-3R2 X &  not (X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ((f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)))))) &  not ((X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ((f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))))) &  not f is-convex-onRFUNCT-3R2 X)"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)) implies f is-convex-onRFUNCT-3R2 X"
    proof(rule impMI ,rule impI)
      assume A2: "X c=TARSKIR1 domRELAT-1K1 f"
        and A3: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)"
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
      proof-
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A4: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
          have " for s be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds (s inHIDDENR3 X & t inHIDDENR3 X) & p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
          proof(rule ballI,rule ballI,rule impI)
            fix s assume [ty]: "s be RealXREAL-0M1"
            fix t assume [ty]: "t be RealXREAL-0M1"
            assume A5: "(s inHIDDENR3 X & t inHIDDENR3 X) & p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t inTARSKIR2 X"
            have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
            proof-
              show "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
              proof-
                have cases: "(p =COMPLEX1R1 0NUMBERSK6 or p =COMPLEX1R1 \<one>\<^sub>M) or 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
                  using A4 xxreal_0_th_1 sorry
                have case1: "p =COMPLEX1R1 0NUMBERSK6 implies f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                proof(rule impI)
                  assume "p =COMPLEX1R1 0NUMBERSK6"
                  thus "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                     sorry
                qed
                have case2: "p =COMPLEX1R1 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                proof(rule impI)
                  assume "p =COMPLEX1R1 \<one>\<^sub>M"
                  thus "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                     sorry
                qed
                have case3: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                proof(rule impI)
                  assume A6: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
                  then have A7: "\<one>\<^sub>M -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
                    using xreal_1_th_50 sorry
                  have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                  proof-
                    show "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                    proof-
                      have cases: "(s =COMPLEX1R1 t or s <XXREAL-0R3 t) or s >XXREAL-0R4 t"
                        using xxreal_0_th_1 sorry
                      have case1: "s =COMPLEX1R1 t implies f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                      proof(rule impI)
                        assume "s =COMPLEX1R1 t"
                        thus "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                           sorry
                      qed
                      have case2: "s <XXREAL-0R3 t implies f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                      proof(rule impI)
                        assume "s <XXREAL-0R3 t"
                        then have A8: "t -XCMPLX-0K6 s >XXREAL-0R4 0NUMBERSK6"
                          using xreal_1_th_50 sorry
                        have "(p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (t -XCMPLX-0K6 s)"
                           sorry
                        then have A9: "(p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s >XXREAL-0R4 0NUMBERSK6"
                          using A7 A8 xreal_1_th_129 sorry
                        then have A10: "p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t >XXREAL-0R4 s"
                          using xreal_1_th_47 sorry
                        have A11: "((f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 s))*XCMPLX-0K3 p =COMPLEX1R1 p *XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) -XCMPLX-0K6 p *XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 s) & ((f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))*XCMPLX-0K3 (t -XCMPLX-0K6 s))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 t) -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                           sorry
                        have "t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) =COMPLEX1R1 p *XCMPLX-0K3 (t -XCMPLX-0K6 s)"
                           sorry
                        then have A12: "t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) >XXREAL-0R4 0NUMBERSK6"
                          using A6 A8 xreal_1_th_129 sorry
                        then have "p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t <XXREAL-0R3 t"
                          using xreal_1_th_47 sorry
                        then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 s)/XCMPLX-0K7 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s) <=XXREAL-0R1 (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 s)/XCMPLX-0K7 (t -XCMPLX-0K6 s) & (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 s)/XCMPLX-0K7 (t -XCMPLX-0K6 s) <=XXREAL-0R1 (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))/XCMPLX-0K7 (t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                          using A3 A5 A10 sorry
                        then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 s)/XCMPLX-0K7 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s) <=XXREAL-0R1 (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))/XCMPLX-0K7 (t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                          using xxreal_0_th_2 sorry
                        then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) <=XXREAL-0R1 (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))*XCMPLX-0K3 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s)"
                          using A12 A9 xreal_1_th_106 sorry
                        then have "p *XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 t) +XCMPLX-0K2 p *XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 s)"
                          using A11 xreal_1_th_21 sorry
                        then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 (((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (t -XCMPLX-0K6 s) +XCMPLX-0K2 (p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 s))/XCMPLX-0K7 (t -XCMPLX-0K6 s)"
                          using A8 xreal_1_th_77 sorry
                        then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 (((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (t -XCMPLX-0K6 s))/XCMPLX-0K7 (t -XCMPLX-0K6 s) +XCMPLX-0K2 ((p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 s))/XCMPLX-0K7 (t -XCMPLX-0K6 s)"
                          using xcmplx_1_th_62 sorry
                        then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t +XCMPLX-0K2 ((p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 s))/XCMPLX-0K7 (t -XCMPLX-0K6 s)"
                          using A8 xcmplx_1_th_89 sorry
                        thus "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                          using A8 xcmplx_1_th_89 sorry
                      qed
                      have case3: "s >XXREAL-0R4 t implies f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                      proof(rule impI)
                        assume "s >XXREAL-0R4 t"
                        then have A13: "s -XCMPLX-0K6 t >XXREAL-0R4 0NUMBERSK6"
                          using xreal_1_th_50 sorry
                        have "(p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t =COMPLEX1R1 p *XCMPLX-0K3 (s -XCMPLX-0K6 t)"
                           sorry
                        then have A14: "(p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t >XXREAL-0R4 0NUMBERSK6"
                          using A6 A13 xreal_1_th_129 sorry
                        then have A15: "p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t >XXREAL-0R4 t"
                          using xreal_1_th_47 sorry
                        have A16: "((f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 t))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 t) & ((f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))*XCMPLX-0K3 (s -XCMPLX-0K6 t))*XCMPLX-0K3 p =COMPLEX1R1 p *XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 s) -XCMPLX-0K6 p *XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                           sorry
                        have "s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (s -XCMPLX-0K6 t)"
                           sorry
                        then have A17: "s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) >XXREAL-0R4 0NUMBERSK6"
                          using A7 A13 xreal_1_th_129 sorry
                        then have "p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t <XXREAL-0R3 s"
                          using xreal_1_th_47 sorry
                        then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 t)/XCMPLX-0K7 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t) <=XXREAL-0R1 (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 t)/XCMPLX-0K7 (s -XCMPLX-0K6 t) & (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 t)/XCMPLX-0K7 (s -XCMPLX-0K6 t) <=XXREAL-0R1 (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))/XCMPLX-0K7 (s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                          using A3 A5 A15 sorry
                        then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 t)/XCMPLX-0K7 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t) <=XXREAL-0R1 (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))/XCMPLX-0K7 (s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                          using xxreal_0_th_2 sorry
                        then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) <=XXREAL-0R1 (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))*XCMPLX-0K3 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t)"
                          using A17 A14 xreal_1_th_106 sorry
                        then have "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) +XCMPLX-0K2 p *XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) <=XXREAL-0R1 p *XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 s) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 t)"
                          using A16 xreal_1_th_21 sorry
                        then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 ((p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (s -XCMPLX-0K6 t) +XCMPLX-0K2 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 t))/XCMPLX-0K7 (s -XCMPLX-0K6 t)"
                          using A13 xreal_1_th_77 sorry
                        then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 ((p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (s -XCMPLX-0K6 t))/XCMPLX-0K7 (s -XCMPLX-0K6 t) +XCMPLX-0K2 (((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 t))/XCMPLX-0K7 (s -XCMPLX-0K6 t)"
                          using xcmplx_1_th_62 sorry
                        then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 t))/XCMPLX-0K7 (s -XCMPLX-0K6 t)"
                          using A13 xcmplx_1_th_89 sorry
                        thus "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                          using A13 xcmplx_1_th_89 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 case3 sorry
                    qed
                  qed
                  thus "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 sorry
              qed
            qed
            thus "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
               sorry
          qed "sorry"
          thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-convex-onRFUNCT-3R2 X"
        using A2 rfunct_3_def_12 sorry
    qed
    have "f is-convex-onRFUNCT-3R2 X implies X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))"
    proof-
      have "f is-convex-onRFUNCT-3R2 X implies X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ((f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))))"
      proof(rule impI)
        assume A18: "f is-convex-onRFUNCT-3R2 X"
        have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)"
        proof-
          have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds ((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & (a <XXREAL-0R3 r & r <XXREAL-0R3 b) implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
            fix a assume [ty]: "a be RealXREAL-0M1"
            fix b assume [ty]: "b be RealXREAL-0M1"
            fix r assume [ty]: "r be RealXREAL-0M1"
            assume A19: "(a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X"
              and A20: "a <XXREAL-0R3 r"
              and A21: "r <XXREAL-0R3 b"
            obtain aa bb where 
              [ty]:"aa be RealXREAL-0M1" and aaDef:"aa = a" and
              [ty]:"bb be RealXREAL-0M1" and bbDef:"bb = b"
               sorry
            have A22: "b -XCMPLX-0K6 r <XXREAL-0R3 b -XCMPLX-0K6 a & 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 r"
              using A20 A21 xreal_1_th_10 xreal_1_th_50 sorry
            obtain p where 
              [ty]:"p be RealXREAL-0M1" and pDef:"p = (b -XCMPLX-0K6 r)/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
               sorry
            have A23: "0NUMBERSK6 <XXREAL-0R3 r -XCMPLX-0K6 a"
              using A20 xreal_1_th_50 sorry
            have A24: "p +XCMPLX-0K2 (r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) =HIDDENR1 ((b -XCMPLX-0K6 r)+XCMPLX-0K2 (r -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
              using xcmplx_1_th_62 sorry
            also have "... = \<one>\<^sub>M"
              using A22 xcmplx_1_th_60 sorry
            finally have "p +XCMPLX-0K2 (r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) =HIDDENR1 \<one>\<^sub>M"
               sorry
            then have "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =HIDDENR1 (a *XCMPLX-0K3 (b -XCMPLX-0K6 r))/XCMPLX-0K7 (b -XCMPLX-0K6 a) +XCMPLX-0K2 b *XCMPLX-0K3 ((r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a))"
              using xcmplx_1_th_74 sorry
            also have "... = (a *XCMPLX-0K3 (b -XCMPLX-0K6 r))/XCMPLX-0K7 (b -XCMPLX-0K6 a) +XCMPLX-0K2 (b *XCMPLX-0K3 (r -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
              using xcmplx_1_th_74 sorry
            also have "... = ((b *XCMPLX-0K3 a -XCMPLX-0K6 r *XCMPLX-0K3 a)+XCMPLX-0K2 (r -XCMPLX-0K6 a)*XCMPLX-0K3 b)/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
              using xcmplx_1_th_62 sorry
            also have "... = (r *XCMPLX-0K3 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
               sorry
            finally have "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =HIDDENR1 (r *XCMPLX-0K3 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
               sorry
            then have A25: "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =COMPLEX1R1 r"
              using A22 xcmplx_1_th_89 sorry
            have A26: "(b -XCMPLX-0K6 a)*XCMPLX-0K3 (((b -XCMPLX-0K6 r)/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 b) =HIDDENR1 ((b -XCMPLX-0K6 a)*XCMPLX-0K3 ((b -XCMPLX-0K6 r)/XCMPLX-0K7 (b -XCMPLX-0K6 a)))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (b -XCMPLX-0K6 a)*XCMPLX-0K3 (((r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 b)"
               sorry
            also have "... = (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)*XCMPLX-0K3 ((r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a)))*XCMPLX-0K3 f .FUNCT-1K1 b"
              using A22 xcmplx_1_th_87 sorry
            also have "... = (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b"
              using A22 xcmplx_1_th_87 sorry
            finally have "(b -XCMPLX-0K6 a)*XCMPLX-0K3 (((b -XCMPLX-0K6 r)/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 b) =HIDDENR1 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b"
               sorry
            have "(bb -XCMPLX-0K6 r)/XCMPLX-0K7 (bb -XCMPLX-0K6 aa) <XXREAL-0R3 \<one>\<^sub>M"
              using A22 xreal_1_th_189 sorry
            then have A27: "f .FUNCT-1K1 (p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 b"
              using A18 A19 A22 A25 rfunct_3_def_12 sorry
            then have "(b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 r <=XXREAL-0R1 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 a)"
              using A22 A24 A25 A26 xreal_1_th_64 sorry
            then have "(b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 r -XCMPLX-0K6 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 a <=XXREAL-0R1 (r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 a"
              using xreal_1_th_20 sorry
            then have "(b -XCMPLX-0K6 a)*XCMPLX-0K3 (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a) <=XXREAL-0R1 (r -XCMPLX-0K6 a)*XCMPLX-0K3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)"
               sorry
            thus "(f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
              using A22 A23 xreal_1_th_102 sorry
            have "(b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 r <=XXREAL-0R1 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 ((b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a)"
              using A22 A24 A25 A27 A26 xreal_1_th_64 sorry
            then have "((b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a)+XCMPLX-0K2 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 r <=XXREAL-0R1 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b"
              using xreal_1_th_19 sorry
            then have "(b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a <=XXREAL-0R1 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 r"
              using xreal_1_th_19 sorry
            then have "(b -XCMPLX-0K6 r)*XCMPLX-0K3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a) <=XXREAL-0R1 (b -XCMPLX-0K6 a)*XCMPLX-0K3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)"
               sorry
            thus "(f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)"
              using A22 xreal_1_th_102 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ((f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))))"
          using A18 rfunct_3_def_12 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not (f is-convex-onRFUNCT-3R2 X &  not (X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ((f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)))))) &  not ((X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ((f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))))) &  not f is-convex-onRFUNCT-3R2 X)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_17:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds f is-strictly-convex-onRFUNCT-4R1 X iff X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  not (f is-strictly-convex-onRFUNCT-4R1 X &  not (X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ( not (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) &  not (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)))))) &  not ((X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ( not (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) &  not (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))))) &  not f is-strictly-convex-onRFUNCT-4R1 X)"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)) implies f is-strictly-convex-onRFUNCT-4R1 X"
    proof(rule impMI ,rule impI)
      assume A2: "X c=TARSKIR1 domRELAT-1K1 f"
        and A3: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)"
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
      proof-
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s))"
        proof(rule ballI,rule impMI ,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A4: "0NUMBERSK6 <XXREAL-0R3 p"
            and A5: "p <XXREAL-0R3 \<one>\<^sub>M"
          have A6: "\<one>\<^sub>M -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
            using A5 xreal_1_th_50 sorry
          have " for s be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds ((s inHIDDENR3 X & t inHIDDENR3 X) & p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t inTARSKIR2 X) & s <>HIDDENR2 t implies f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
          proof-
            have " for s be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds ((s inHIDDENR3 X & t inHIDDENR3 X) & p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t inTARSKIR2 X) & s <>HIDDENR2 t implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix s assume [ty]: "s be RealXREAL-0M1"
              fix t assume [ty]: "t be RealXREAL-0M1"
              assume A7: "(s inHIDDENR3 X & t inHIDDENR3 X) & p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t inTARSKIR2 X"
                and A8: "s <>HIDDENR2 t"
              have " not f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
              proof-
                show " not f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                proof-
                  have cases: "s <XXREAL-0R3 t or s >XXREAL-0R4 t"
                    using A8 xxreal_0_th_1 sorry
                  have case1: "s <XXREAL-0R3 t implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                  proof(rule impI)
                    assume "s <XXREAL-0R3 t"
                    then have A9: "t -XCMPLX-0K6 s >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    have "(p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (t -XCMPLX-0K6 s)"
                       sorry
                    then have A10: "(p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s >XXREAL-0R4 0NUMBERSK6"
                      using A6 A9 xreal_1_th_129 sorry
                    then have A11: "p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t >XXREAL-0R4 s"
                      using xreal_1_th_47 sorry
                    have A12: "((f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 s))*XCMPLX-0K3 p =COMPLEX1R1 p *XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) -XCMPLX-0K6 p *XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 s) & ((f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))*XCMPLX-0K3 (t -XCMPLX-0K6 s))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 t) -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                       sorry
                    have "t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) =COMPLEX1R1 p *XCMPLX-0K3 (t -XCMPLX-0K6 s)"
                       sorry
                    then have A13: "t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) >XXREAL-0R4 0NUMBERSK6"
                      using A4 A9 xreal_1_th_129 sorry
                    then have "p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t <XXREAL-0R3 t"
                      using xreal_1_th_47 sorry
                    then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 s)/XCMPLX-0K7 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s) <XXREAL-0R3 (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 s)/XCMPLX-0K7 (t -XCMPLX-0K6 s) & (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 s)/XCMPLX-0K7 (t -XCMPLX-0K6 s) <XXREAL-0R3 (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))/XCMPLX-0K7 (t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                      using A3 A7 A11 sorry
                    then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 s)/XCMPLX-0K7 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s) <XXREAL-0R3 (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))/XCMPLX-0K7 (t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                      using xxreal_0_th_2 sorry
                    then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) <XXREAL-0R3 (f .FUNCT-1K1 t -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))*XCMPLX-0K3 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 s)"
                      using A13 A10 xreal_1_th_102 sorry
                    then have "p *XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 t) +XCMPLX-0K2 p *XCMPLX-0K3 ((t -XCMPLX-0K6 s)*XCMPLX-0K3 f .FUNCT-1K1 s)"
                      using A12 xreal_1_th_21 sorry
                    then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 (((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (t -XCMPLX-0K6 s) +XCMPLX-0K2 (p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 s))/XCMPLX-0K7 (t -XCMPLX-0K6 s)"
                      using A9 xreal_1_th_81 sorry
                    then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 (((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (t -XCMPLX-0K6 s))/XCMPLX-0K7 (t -XCMPLX-0K6 s) +XCMPLX-0K2 ((p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 s))/XCMPLX-0K7 (t -XCMPLX-0K6 s)"
                      using xcmplx_1_th_62 sorry
                    then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t +XCMPLX-0K2 ((p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (t -XCMPLX-0K6 s))/XCMPLX-0K7 (t -XCMPLX-0K6 s)"
                      using A9 xcmplx_1_th_89 sorry
                    thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                      using A9 xcmplx_1_th_89 sorry
                  qed
                  have case2: "s >XXREAL-0R4 t implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                  proof(rule impI)
                    assume "s >XXREAL-0R4 t"
                    then have A14: "s -XCMPLX-0K6 t >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    have "(p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t =COMPLEX1R1 p *XCMPLX-0K3 (s -XCMPLX-0K6 t)"
                       sorry
                    then have A15: "(p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t >XXREAL-0R4 0NUMBERSK6"
                      using A4 A14 xreal_1_th_129 sorry
                    then have A16: "p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t >XXREAL-0R4 t"
                      using xreal_1_th_47 sorry
                    have A17: "((f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 t))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 t) & ((f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))*XCMPLX-0K3 (s -XCMPLX-0K6 t))*XCMPLX-0K3 p =COMPLEX1R1 p *XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 s) -XCMPLX-0K6 p *XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                       sorry
                    have "s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (s -XCMPLX-0K6 t)"
                       sorry
                    then have A18: "s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) >XXREAL-0R4 0NUMBERSK6"
                      using A6 A14 xreal_1_th_129 sorry
                    then have "p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t <XXREAL-0R3 s"
                      using xreal_1_th_47 sorry
                    then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 t)/XCMPLX-0K7 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t) <XXREAL-0R3 (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 t)/XCMPLX-0K7 (s -XCMPLX-0K6 t) & (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 t)/XCMPLX-0K7 (s -XCMPLX-0K6 t) <XXREAL-0R3 (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))/XCMPLX-0K7 (s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                      using A3 A7 A16 sorry
                    then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 t)/XCMPLX-0K7 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t) <XXREAL-0R3 (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))/XCMPLX-0K7 (s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))"
                      using xxreal_0_th_2 sorry
                    then have "(f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) -XCMPLX-0K6 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) <XXREAL-0R3 (f .FUNCT-1K1 s -XCMPLX-0K6 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t))*XCMPLX-0K3 ((p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)-XCMPLX-0K6 t)"
                      using A18 A15 xreal_1_th_102 sorry
                    then have "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) +XCMPLX-0K2 p *XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t)) <XXREAL-0R3 p *XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 s) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((s -XCMPLX-0K6 t)*XCMPLX-0K3 f .FUNCT-1K1 t)"
                      using A17 xreal_1_th_21 sorry
                    then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 ((p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (s -XCMPLX-0K6 t) +XCMPLX-0K2 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 t))/XCMPLX-0K7 (s -XCMPLX-0K6 t)"
                      using A14 xreal_1_th_81 sorry
                    then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 ((p *XCMPLX-0K3 f .FUNCT-1K1 s)*XCMPLX-0K3 (s -XCMPLX-0K6 t))/XCMPLX-0K7 (s -XCMPLX-0K6 t) +XCMPLX-0K2 (((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 t))/XCMPLX-0K7 (s -XCMPLX-0K6 t)"
                      using xcmplx_1_th_62 sorry
                    then have "f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t)*XCMPLX-0K3 (s -XCMPLX-0K6 t))/XCMPLX-0K7 (s -XCMPLX-0K6 t)"
                      using A14 xcmplx_1_th_89 sorry
                    thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                      using A14 xcmplx_1_th_89 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 t) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 t"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-strictly-convex-onRFUNCT-4R1 X"
        using A2 sorry
    qed
    have "f is-strictly-convex-onRFUNCT-4R1 X implies X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))"
    proof-
      have "f is-strictly-convex-onRFUNCT-4R1 X implies X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ( not (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) &  not (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))))"
      proof(rule impI)
        assume A19: "f is-strictly-convex-onRFUNCT-4R1 X"
        have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & a <XXREAL-0R3 r) & r <XXREAL-0R3 b implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)"
        proof-
          have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds ((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) & (a <XXREAL-0R3 r & r <XXREAL-0R3 b) implies (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) &  not (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
            fix a assume [ty]: "a be RealXREAL-0M1"
            fix b assume [ty]: "b be RealXREAL-0M1"
            fix r assume [ty]: "r be RealXREAL-0M1"
            assume A20: "(a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X"
              and A21: "a <XXREAL-0R3 r"
              and A22: "r <XXREAL-0R3 b"
            obtain p where 
              [ty]:"p be RealXREAL-0M1" and pDef:"p = (b -XCMPLX-0K6 r)/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
               sorry
            obtain aa bb where 
              [ty]:"aa be RealXREAL-0M1" and aaDef:"aa = a" and
              [ty]:"bb be RealXREAL-0M1" and bbDef:"bb = b"
               sorry
            have A23: "b -XCMPLX-0K6 r <XXREAL-0R3 b -XCMPLX-0K6 a & 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 r"
              using A21 A22 xreal_1_th_10 xreal_1_th_50 sorry
            have A24: "p +XCMPLX-0K2 (r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) =HIDDENR1 ((b -XCMPLX-0K6 r)+XCMPLX-0K2 (r -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
              using xcmplx_1_th_62 sorry
            also have "... = \<one>\<^sub>M"
              using A23 xcmplx_1_th_60 sorry
            finally have "p +XCMPLX-0K2 (r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) =HIDDENR1 \<one>\<^sub>M"
               sorry
            then have "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =HIDDENR1 (a *XCMPLX-0K3 (b -XCMPLX-0K6 r))/XCMPLX-0K7 (b -XCMPLX-0K6 a) +XCMPLX-0K2 b *XCMPLX-0K3 ((r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a))"
              using xcmplx_1_th_74 sorry
            also have "... = (a *XCMPLX-0K3 (b -XCMPLX-0K6 r))/XCMPLX-0K7 (b -XCMPLX-0K6 a) +XCMPLX-0K2 (b *XCMPLX-0K3 (r -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
              using xcmplx_1_th_74 sorry
            also have "... = ((b *XCMPLX-0K3 a -XCMPLX-0K6 r *XCMPLX-0K3 a)+XCMPLX-0K2 (r -XCMPLX-0K6 a)*XCMPLX-0K3 b)/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
              using xcmplx_1_th_62 sorry
            also have "... = (r *XCMPLX-0K3 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
               sorry
            finally have "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =HIDDENR1 (r *XCMPLX-0K3 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
               sorry
            then have A25: "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =COMPLEX1R1 r"
              using A23 xcmplx_1_th_89 sorry
            have "0NUMBERSK6 <XXREAL-0R3 (b -XCMPLX-0K6 r)/XCMPLX-0K7 (b -XCMPLX-0K6 a) & (bb -XCMPLX-0K6 r)/XCMPLX-0K7 (bb -XCMPLX-0K6 aa) <XXREAL-0R3 \<one>\<^sub>M"
              using A23 xreal_1_th_139 xreal_1_th_189 sorry
            then have A26: "f .FUNCT-1K1 r <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 b"
              using A19 A20 A21 A22 A25 sorry
            have A27: "0NUMBERSK6 <XXREAL-0R3 r -XCMPLX-0K6 a"
              using A21 xreal_1_th_50 sorry
            have A28: "(p *XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 b)*XCMPLX-0K3 (b -XCMPLX-0K6 a) =HIDDENR1 ((b -XCMPLX-0K6 a)*XCMPLX-0K3 p)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (b -XCMPLX-0K6 a)*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 b)"
               sorry
            also have "... = (((b -XCMPLX-0K6 a)*XCMPLX-0K3 (b -XCMPLX-0K6 r))/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((b -XCMPLX-0K6 a)*XCMPLX-0K3 ((r -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a)))*XCMPLX-0K3 f .FUNCT-1K1 b"
              using A24 xcmplx_1_th_74 sorry
            also have "... = (((b -XCMPLX-0K6 r)*XCMPLX-0K3 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (((b -XCMPLX-0K6 a)*XCMPLX-0K3 (r -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 b"
              using xcmplx_1_th_74 sorry
            also have "... = ((b -XCMPLX-0K6 r)*XCMPLX-0K3 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a)))*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (((b -XCMPLX-0K6 a)*XCMPLX-0K3 (r -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 b"
              using xcmplx_1_th_74 sorry
            also have "... = ((b -XCMPLX-0K6 r)*XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (((r -XCMPLX-0K6 a)*XCMPLX-0K3 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (b -XCMPLX-0K6 a))*XCMPLX-0K3 f .FUNCT-1K1 b"
              using A23 xcmplx_1_th_60 sorry
            also have "... = (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((r -XCMPLX-0K6 a)*XCMPLX-0K3 ((b -XCMPLX-0K6 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a)))*XCMPLX-0K3 f .FUNCT-1K1 b"
              using xcmplx_1_th_74 sorry
            also have "... = (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((r -XCMPLX-0K6 a)*XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 f .FUNCT-1K1 b"
              using A23 xcmplx_1_th_60 sorry
            finally have "(p *XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 b)*XCMPLX-0K3 (b -XCMPLX-0K6 a) =HIDDENR1 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((r -XCMPLX-0K6 a)*XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 f .FUNCT-1K1 b"
               sorry
            then have "f .FUNCT-1K1 r *XCMPLX-0K3 (b -XCMPLX-0K6 a) <XXREAL-0R3 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 a +XCMPLX-0K2 ((r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 a)"
              using A23 A26 xreal_1_th_68 sorry
            then have "f .FUNCT-1K1 r *XCMPLX-0K3 (b -XCMPLX-0K6 a) -XCMPLX-0K6 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 a <XXREAL-0R3 (r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (r -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 a"
              using xreal_1_th_19 sorry
            then have "(b -XCMPLX-0K6 a)*XCMPLX-0K3 (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a) <XXREAL-0R3 (r -XCMPLX-0K6 a)*XCMPLX-0K3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)"
               sorry
            thus "(f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a)"
              using A23 A27 xreal_1_th_106 sorry
            have "f .FUNCT-1K1 r *XCMPLX-0K3 (b -XCMPLX-0K6 a) <XXREAL-0R3 ((r -XCMPLX-0K6 b)*XCMPLX-0K3 f .FUNCT-1K1 b +XCMPLX-0K2 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a)+XCMPLX-0K2 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b"
              using A23 A26 A28 xreal_1_th_68 sorry
            then have "f .FUNCT-1K1 r *XCMPLX-0K3 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ((r -XCMPLX-0K6 b)*XCMPLX-0K3 f .FUNCT-1K1 b +XCMPLX-0K2 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a) <XXREAL-0R3 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b"
              using xreal_1_th_19 sorry
            then have "f .FUNCT-1K1 r *XCMPLX-0K3 (b -XCMPLX-0K6 a) +XCMPLX-0K2 (-XCMPLX-0K4 ((r -XCMPLX-0K6 b)*XCMPLX-0K3 f .FUNCT-1K1 b +XCMPLX-0K2 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a)) <XXREAL-0R3 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b"
               sorry
            then have "(-XCMPLX-0K4 (r -XCMPLX-0K6 b)*XCMPLX-0K3 f .FUNCT-1K1 b)-XCMPLX-0K6 (b -XCMPLX-0K6 r)*XCMPLX-0K3 f .FUNCT-1K1 a <XXREAL-0R3 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 b -XCMPLX-0K6 (b -XCMPLX-0K6 a)*XCMPLX-0K3 f .FUNCT-1K1 r"
              using xreal_1_th_20 sorry
            then have "(b -XCMPLX-0K6 r)*XCMPLX-0K3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a) <XXREAL-0R3 (b -XCMPLX-0K6 a)*XCMPLX-0K3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)"
               sorry
            thus " not (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)"
              using A23 xreal_1_th_106 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ( not (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) &  not (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))))"
          using A19 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not (f is-strictly-convex-onRFUNCT-4R1 X &  not (X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ( not (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) &  not (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r)))))) &  not ((X c=TARSKIR1 domRELAT-1K1 f & ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  not (((((a inHIDDENR3 X & b inHIDDENR3 X) & r inHIDDENR3 X) &  not a <XXREAL-0R3 r) &  not r <XXREAL-0R3 b) &  not ( not (f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (r -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) &  not (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (b -XCMPLX-0K6 a) <XXREAL-0R3 (f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 r)/XCMPLX-0K7 (b -XCMPLX-0K6 r))))) &  not f is-strictly-convex-onRFUNCT-4R1 X)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_18:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> implies (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F))) implies f is-convex-onRFUNCT-3R2 REALNUMBERSK2)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> implies  not (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  not ((SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domFINSEQ-1K5 P &  not (P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i))))) &  not f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F)))) &  not f is-convex-onRFUNCT-3R2 REALNUMBERSK2)"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
    then have A1: "REALNUMBERSK2 c=TARSKIR1 domRELAT-1K1 f"
      using partfun1_def_2 sorry
    have "( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F))) implies f is-convex-onRFUNCT-3R2 REALNUMBERSK2"
    proof(rule impI)
      assume A2: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F))"
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 REALNUMBERSK2 & s inHIDDENR3 REALNUMBERSK2) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 REALNUMBERSK2 implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
      proof-
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r inHIDDENR3 REALNUMBERSK2 & (s inHIDDENR3 REALNUMBERSK2 & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 REALNUMBERSK2) implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s)"
        proof(rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A3: "0NUMBERSK6 <=XXREAL-0R1 p"
            and A4: "p <=XXREAL-0R1 \<one>\<^sub>M"
          fix r assume [ty]: "r be RealXREAL-0M1"
          fix s assume [ty]: "s be RealXREAL-0M1"
          assume "r inHIDDENR3 REALNUMBERSK2"
            and "s inHIDDENR3 REALNUMBERSK2"
            and "p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 REALNUMBERSK2"
          obtain rr ss pp mp where 
            [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr = r" and
            [ty]:"ss be ElementSUBSET-1M1-of REALNUMBERSK2" and ssDef:"ss = s" and
            [ty]:"pp be ElementSUBSET-1M1-of REALNUMBERSK2" and ppDef:"pp = p" and
            [ty]:"mp be ElementSUBSET-1M1-of REALNUMBERSK2" and mpDef:"mp = \<one>\<^sub>M -XCMPLX-0K6 p"
            using xreal_0_def_1 sorry
          have "f .FUNCT-1K1 rr inTARSKIR2 REALNUMBERSK2 & f .FUNCT-1K1 ss inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then obtain P E F where 
            [ty]:"P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of \<two>\<^sub>M -tuples-onFINSEQ-2K4 REALNUMBERSK2" and PDef:"P = <*FINSEQ-1K11 pp,mp *>" and
            [ty]:"E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of \<two>\<^sub>M -tuples-onFINSEQ-2K4 REALNUMBERSK2" and EDef:"E = <*FINSEQ-1K11 rr,ss *>" and
            [ty]:"F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of \<two>\<^sub>M -tuples-onFINSEQ-2K4 REALNUMBERSK2" and FDef:"F = <*FINSEQ-1K11 f .FUNCT-1K1 rr,f .FUNCT-1K1 ss *>"
            using finseq_2_th_101 sorry
          have A5: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
          proof(rule ballI,rule impI)
            have A6: "domFINSEQ-1K5 P =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 P)"
              using finseq_1_def_3 sorry
            also have "... = SegFINSEQ-1K2 \<two>\<^sub>M"
              using card_1_def_7 sorry
            finally have "domFINSEQ-1K5 P =HIDDENR1 SegFINSEQ-1K2 \<two>\<^sub>M"
               sorry
            fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
            assume A7: "i inTARSKIR2 domFINSEQ-1K5 P"
            have "P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
            proof-
              show "P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
              proof-
                have cases: "i =COMPLEX1R1 \<one>\<^sub>M or i =COMPLEX1R1 \<two>\<^sub>M"
                  using A7 A6 finseq_1_th_2 tarski_def_2 sorry
                have case1: "i =COMPLEX1R1 \<one>\<^sub>M implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
                proof(rule impI)
                  assume A8: "i =COMPLEX1R1 \<one>\<^sub>M"
                  then have "E .FUNCT-1K1 i =COMPLEX1R1 r"
                    using finseq_1_th_44 sorry
                  thus "P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
                    using A3 A8 finseq_1_th_44 sorry
                qed
                have case2: "i =COMPLEX1R1 \<two>\<^sub>M implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
                proof(rule impI)
                  assume A9: "i =COMPLEX1R1 \<two>\<^sub>M"
                  then have "E .FUNCT-1K1 i =COMPLEX1R1 s & P .FUNCT-1K1 i =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 p"
                    using finseq_1_th_44 sorry
                  thus "P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
                    using A4 A9 finseq_1_th_44 xreal_1_th_48 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
               sorry
          qed "sorry"
          have "SumRVSUM-1K22 P =HIDDENR1 p +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)"
            using rvsum_1_th_77 sorry
          also have "... = \<one>\<^sub>M"
             sorry
          finally have "SumRVSUM-1K22 P =HIDDENR1 \<one>\<^sub>M"
             sorry
          then have A10: "f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,F))"
            using A2 A5 sorry
          have A11: "P .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 p & P .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 p"
            using finseq_1_th_44 sorry
          have "lenFINSEQ-1K4 P =HIDDENR1 \<two>\<^sub>M"
            using finseq_1_th_44 sorry
          also have "... = lenFINSEQ-1K4 E"
            using finseq_1_th_44 sorry
          finally have "lenFINSEQ-1K4 P =HIDDENR1 lenFINSEQ-1K4 E"
             sorry
          then have "lenFINSEQ-1K4 ((multrealBINOP-2K11).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(P,E)) =COMPLEX1R1 lenFINSEQ-1K4 P"
            using finseq_2_th_72 sorry
          then have A12: "lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,E)) =COMPLEX1R1 \<two>\<^sub>M"
            using finseq_1_th_44 sorry
          have A13: "mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,E) .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 P .FUNCT-1K1 \<one>\<^sub>M *XCMPLX-0K3 E .FUNCT-1K1 \<one>\<^sub>M & mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,E) .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 P .FUNCT-1K1 \<two>\<^sub>M *XCMPLX-0K3 E .FUNCT-1K1 \<two>\<^sub>M"
            using rvsum_1_th_60 sorry
          have "E .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 r & E .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 s"
            using finseq_1_th_44 sorry
          then have "mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,E) =FINSEQ-1R1 <*FINSEQ-1K11 p *XCMPLX-0K3 r,(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s *>"
            using A11 A12 A13 finseq_1_th_44 sorry
          then have A14: "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,E)) =COMPLEX1R1 p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s"
            using rvsum_1_th_77 sorry
          have A15: "mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,F) .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 P .FUNCT-1K1 \<one>\<^sub>M *XCMPLX-0K3 F .FUNCT-1K1 \<one>\<^sub>M & mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,F) .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 P .FUNCT-1K1 \<two>\<^sub>M *XCMPLX-0K3 F .FUNCT-1K1 \<two>\<^sub>M"
            using rvsum_1_th_60 sorry
          have "lenFINSEQ-1K4 P =HIDDENR1 \<two>\<^sub>M"
            using finseq_1_th_44 sorry
          also have "... = lenFINSEQ-1K4 F"
            using finseq_1_th_44 sorry
          finally have "lenFINSEQ-1K4 P =HIDDENR1 lenFINSEQ-1K4 F"
             sorry
          then have "lenFINSEQ-1K4 ((multrealBINOP-2K11).:FINSEQOPK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub>(P,F)) =COMPLEX1R1 lenFINSEQ-1K4 P"
            using finseq_2_th_72 sorry
          then have A16: "lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,F)) =COMPLEX1R1 \<two>\<^sub>M"
            using finseq_1_th_44 sorry
          have "F .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 f .FUNCT-1K1 r & F .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 f .FUNCT-1K1 s"
            using finseq_1_th_44 sorry
          then have "mltRVSUM-1K19\<^bsub>(\<two>\<^sub>M)\<^esub>(P,F) =FINSEQ-1R1 <*FINSEQ-1K11 p *XCMPLX-0K3 f .FUNCT-1K1 r,(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s *>"
            using A11 A16 A15 finseq_1_th_44 sorry
          thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
            using A10 A14 rvsum_1_th_77 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-convex-onRFUNCT-3R2 REALNUMBERSK2"
        using A1 rfunct_3_def_12 sorry
    qed
    thus " not (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  not ((SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domFINSEQ-1K5 P &  not (P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i))))) &  not f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F)))) &  not f is-convex-onRFUNCT-3R2 REALNUMBERSK2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_19:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convex-onRFUNCT-3R2 REALNUMBERSK2 implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F)))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convex-onRFUNCT-3R2 REALNUMBERSK2 implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  not ((SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domFINSEQ-1K5 P &  not (P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i))))) &  not f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F))))"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convex-onRFUNCT-3R2 REALNUMBERSK2"
    let ?S = "\<lambda>Lamb1.  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of Lamb1 -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of Lamb1 -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of Lamb1 -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(Lamb1)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(Lamb1)\<^esub>(P,F))"
    have A2: " for k be NatNAT-1M1 holds ?S(k) implies ?S(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of k -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of k -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of k -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P,F))) implies ( for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2 holds SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)) implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F)))"
      proof(rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?S(k)"
        fix P assume [ty]: "P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
        fix E assume [ty]: "E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
        fix F assume [ty]: "F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (k +NAT-1K1 \<one>\<^sub>M)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
        assume A4: "SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M"
          and A5: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P implies P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i)"
        obtain E1 e1 where
          [ty]:"E1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of k -tuples-onFINSEQ-2K4 REALNUMBERSK2" "e1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A6: "E =FINSEQ-1R1 E1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> e1*>)"
          using finseq_2_th_117 sorry
        obtain F1 f1 where
          [ty]:"F1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of k -tuples-onFINSEQ-2K4 REALNUMBERSK2" "f1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A7: "F =FINSEQ-1R1 F1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> f1*>)"
          using finseq_2_th_117 sorry
        have "lenFINSEQ-1K4 F1 +NAT-1K1 \<one>\<^sub>M =HIDDENR1 k +NAT-1K1 \<one>\<^sub>M"
          using card_1_def_7 sorry
        also have "... = lenFINSEQ-1K4 P"
          using card_1_def_7 sorry
        finally have "lenFINSEQ-1K4 F1 +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenFINSEQ-1K4 P"
           sorry
        then have "lenFINSEQ-1K4 F1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 P)"
          using finseq_1_th_4 sorry
        then have A8: "lenFINSEQ-1K4 F1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 P"
          using finseq_1_def_3 sorry
        have A9: "f1 =HIDDENR1 F .FUNCT-1K1 (lenFINSEQ-1K4 F1 +NAT-1K1 \<one>\<^sub>M)"
          using A7 finseq_1_th_42 sorry
        also have "... = f .FUNCT-1K1 (E .FUNCT-1K1 (lenFINSEQ-1K4 F1 +NAT-1K1 \<one>\<^sub>M))"
          using A5 A8 sorry
        also have "... = f .FUNCT-1K1 (E .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
          using card_1_def_7 sorry
        also have "... = f .FUNCT-1K1 (E .FUNCT-1K1 (lenFINSEQ-1K4 E1 +NAT-1K1 \<one>\<^sub>M))"
          using card_1_def_7 sorry
        also have "... = f .FUNCT-1K1 e1"
          using A6 finseq_1_th_42 sorry
        finally have "f1 =HIDDENR1 f .FUNCT-1K1 e1"
           sorry
        obtain P1 p1 where
          [ty]:"P1 be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of k -tuples-onFINSEQ-2K4 REALNUMBERSK2" "p1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A10: "P =FINSEQ-1R1 P1 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> p1*>)"
          using finseq_2_th_117 sorry
        obtain SP where 
          [ty]:"SP be ElementSUBSET-1M1-of REALNUMBERSK2" and SPDef:"SP = SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5"
          using xreal_0_def_1 sorry
        have "mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F) =FINSEQ-1R1 mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> p1 *REAL-1K4 f1 *>)"
          using A10 A7 rfunct_4_th_2 sorry
        then have A11: "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F)) =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1)) +XCMPLX-0K2 p1 *REAL-1K4 f1"
          using rvsum_1_th_74 sorry
        have "mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E) =FINSEQ-1R1 mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,E1) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> p1 *REAL-1K4 e1 *>)"
          using A10 A6 rfunct_4_th_2 sorry
        then have A12: "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,E1)) +XCMPLX-0K2 p1 *REAL-1K4 e1"
          using rvsum_1_th_74 sorry
        have A13: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 P1 implies P1 .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A14: "i inTARSKIR2 domFINSEQ-1K5 P1"
          have A15: "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 P1)"
            using A14 finseq_1_def_3 sorry
          then have A16: "\<one>\<^sub>M <=XXREAL-0R1 i"
            using finseq_1_th_1 sorry
          have "i <=XXREAL-0R1 lenFINSEQ-1K4 P1"
            using A15 finseq_1_th_1 sorry
          then have A17: "i <=XXREAL-0R1 k"
            using card_1_def_7 sorry
          have "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          then have "i <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            using A17 xxreal_0_th_2 sorry
          then have "i inTARSKIR2 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M)"
            using A16 finseq_1_th_1 sorry
          then have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 P)"
            using card_1_def_7 sorry
          then have A18: "i inTARSKIR2 domFINSEQ-1K5 P"
            using finseq_1_def_3 sorry
          have "P1 .FUNCT-1K1 i =COMPLEX1R1 P .FUNCT-1K1 i"
            using A10 A14 finseq_1_def_7 sorry
          thus "P1 .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6"
            using A5 A18 sorry
        qed "sorry"
        then have A19: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P1 implies P1 .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6"
           sorry
        have "f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F))"
        proof-
          show "f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F))"
          proof-
            have cases: "SumRVSUM-1K22 P1 =COMPLEX1R1 0NUMBERSK6 or SumRVSUM-1K22 P1 <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "SumRVSUM-1K22 P1 =COMPLEX1R1 0NUMBERSK6 implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F))"
            proof(rule impI)
              assume A20: "SumRVSUM-1K22 P1 =COMPLEX1R1 0NUMBERSK6"
              then have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 P1 implies P1 .FUNCT-1K1 i =COMPLEX1R1 0NUMBERSK6"
                using A19 rfunct_4_th_3 sorry
              then have A21: "P1 =FINSEQ-1R1 k  |->FINSEQ-2K2 (0NUMBERSK6)"
                using rfunct_4_th_4 sorry
              then have "mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,E1) =FINSEQ-1R1 k  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)"
                using rfunct_4_th_5 sorry
              then have A22: "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,E1)) =COMPLEX1R1 k *XCMPLX-0K3 (0NUMBERSK6)"
                using rvsum_1_th_80 sorry
              have "mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1) =FINSEQ-1R1 k  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)"
                using A21 rfunct_4_th_5 sorry
              then have A23: "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1)) =COMPLEX1R1 k *XCMPLX-0K3 (0NUMBERSK6)"
                using rvsum_1_th_80 sorry
              have "SumRVSUM-1K22 P =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 p1"
                using A10 A20 rvsum_1_th_74 sorry
              thus "f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F))"
                using A4 A12 A11 A9 A22 A23 sorry
            qed
            have case2: "SumRVSUM-1K22 P1 <>HIDDENR2 0NUMBERSK6 implies f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F))"
            proof(rule impI)
              assume A24: "SumRVSUM-1K22 P1 <>HIDDENR2 0NUMBERSK6"
              have A25: "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 P1"
                using A13 rvsum_1_th_84 sorry
              have A26: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1) implies (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1).FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F1 .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E1 .FUNCT-1K1 i)"
              proof(rule ballI,rule impI,rule conjMI)
                fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
                assume "i inTARSKIR2 domFINSEQ-1K5 (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1)"
                then have A27: "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1))"
                  using finseq_1_def_3 sorry
                then have A28: "i inTARSKIR2 SegFINSEQ-1K2 k"
                  using card_1_def_7 sorry
                then have A29: "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 P1)"
                  using card_1_def_7 sorry
                then have "i <=XXREAL-0R1 lenFINSEQ-1K4 P1"
                  using finseq_1_th_1 sorry
                then have A30: "i <=XXREAL-0R1 k"
                  using card_1_def_7 sorry
                have A31: "\<one>\<^sub>M <=XXREAL-0R1 i"
                  using A27 finseq_1_th_1 sorry
                have "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                then have "i <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                  using A30 xxreal_0_th_2 sorry
                then have "i inTARSKIR2 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M)"
                  using A31 finseq_1_th_1 sorry
                then have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 P)"
                  using card_1_def_7 sorry
                then have A32: "i inTARSKIR2 domFINSEQ-1K5 P"
                  using finseq_1_def_3 sorry
                have "i inTARSKIR2 domFINSEQ-1K5 P1"
                  using A29 finseq_1_def_3 sorry
                then have "(SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1).FUNCT-1K1 i =COMPLEX1R1 SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *XCMPLX-0K3 P1 .FUNCT-1K1 i & P1 .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6"
                  using A13 rvsum_1_th_45 sorry
                thus "(SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1).FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6"
                  using A25 sorry
                have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 E1)"
                  using A28 card_1_def_7 sorry
                then have "i inTARSKIR2 domFINSEQ-1K5 E1"
                  using finseq_1_def_3 sorry
                then have A33: "E .FUNCT-1K1 i =COMPLEX1R1 E1 .FUNCT-1K1 i"
                  using A6 finseq_1_def_7 sorry
                have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 F1)"
                  using A28 card_1_def_7 sorry
                then have "i inTARSKIR2 domFINSEQ-1K5 F1"
                  using finseq_1_def_3 sorry
                then have "F .FUNCT-1K1 i =COMPLEX1R1 F1 .FUNCT-1K1 i"
                  using A7 finseq_1_def_7 sorry
                thus "F1 .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E1 .FUNCT-1K1 i)"
                  using A5 A32 A33 sorry
              qed "sorry"
              have A34: "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) =HIDDENR1 (SumRVSUM-1K22 P1 *XCMPLX-0K3 SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5)*XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,E1)) +XCMPLX-0K2 p1 *REAL-1K4 e1"
                using A12 A24 xcmplx_0_def_7 sorry
              also have "... = SumRVSUM-1K22 P1 *XCMPLX-0K3 (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,E1))) +XCMPLX-0K2 p1 *REAL-1K4 e1"
                 sorry
              also have "... = SumRVSUM-1K22 P1 *XCMPLX-0K3 SumRVSUM-1K22 (SP *RVSUM-1K13\<^bsub>(k)\<^esub> mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,E1)) +XCMPLX-0K2 p1 *REAL-1K4 e1"
                using rvsum_1_th_87 sorry
              also have "... = SumRVSUM-1K22 P1 *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SP *RVSUM-1K13\<^bsub>(k)\<^esub> P1,E1)) +XCMPLX-0K2 p1 *REAL-1K4 e1"
                using finseqop_th_26 sorry
              finally have "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) =HIDDENR1 SumRVSUM-1K22 P1 *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SP *RVSUM-1K13\<^bsub>(k)\<^esub> P1,E1)) +XCMPLX-0K2 p1 *REAL-1K4 e1"
                 sorry
              have A35: "SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1)) =HIDDENR1 SumRVSUM-1K22 (SP *RVSUM-1K13\<^bsub>(k)\<^esub> mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1))"
                using rvsum_1_th_87 sorry
              also have "... = SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SP *RVSUM-1K13\<^bsub>(k)\<^esub> P1,F1))"
                using finseqop_th_26 sorry
              finally have "SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1)) =HIDDENR1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SP *RVSUM-1K13\<^bsub>(k)\<^esub> P1,F1))"
                 sorry
              have "lenFINSEQ-1K4 P1 +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 lenFINSEQ-1K4 P"
                using A10 finseq_2_th_16 sorry
              then have "lenFINSEQ-1K4 P1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 P)"
                using finseq_1_th_4 sorry
              then have A36: "lenFINSEQ-1K4 P1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 P"
                using finseq_1_def_3 sorry
              have "SumRVSUM-1K22 P1 +XCMPLX-0K2 p1 =COMPLEX1R1 \<one>\<^sub>M"
                using A4 A10 rvsum_1_th_74 sorry
              then have A37: "p1 =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 SumRVSUM-1K22 P1"
                 sorry
              have "SumRVSUM-1K22 (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1) =HIDDENR1 SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *XCMPLX-0K3 SumRVSUM-1K22 P1"
                using rvsum_1_th_87 sorry
              also have "... = \<one>\<^sub>M"
                using A24 xcmplx_0_def_7 sorry
              finally have "SumRVSUM-1K22 (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1) =HIDDENR1 \<one>\<^sub>M"
                 sorry
              then have "SumRVSUM-1K22 P1 *XCMPLX-0K3 f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1,E1)) <=XXREAL-0R1 SumRVSUM-1K22 P1 *XCMPLX-0K3 (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1)))"
                using A3 A25 A35 A26 xreal_1_th_64 sorry
              then have A38: "SumRVSUM-1K22 P1 *XCMPLX-0K3 f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1,E1)) +XCMPLX-0K2 p1 *XCMPLX-0K3 f .FUNCT-1K1 e1 <=XXREAL-0R1 SumRVSUM-1K22 P1 *XCMPLX-0K3 (SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1))) +XCMPLX-0K2 p1 *XCMPLX-0K3 f .FUNCT-1K1 e1"
                using xreal_1_th_6 sorry
              have A39: "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SP *RVSUM-1K13\<^bsub>(k)\<^esub> P1,E1)) inHIDDENR3 REALNUMBERSK2"
                using xreal_0_def_1 sorry
              have A40: "SumRVSUM-1K22 P1 *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SP *RVSUM-1K13\<^bsub>(k)\<^esub> P1,E1)) +XCMPLX-0K2 p1 *REAL-1K4 e1 inTARSKIR2 REALNUMBERSK2"
                using xreal_0_def_1 sorry
              have "P .FUNCT-1K1 (lenFINSEQ-1K4 P1 +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 p1"
                using A10 finseq_1_th_42 sorry
              then have "SumRVSUM-1K22 P1 <=XXREAL-0R1 \<one>\<^sub>M"
                using A5 A37 A36 xreal_1_th_49 sorry
              then have "f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 P1 *XCMPLX-0K3 f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5 *RVSUM-1K13\<^bsub>(k)\<^esub> P1,E1)) +XCMPLX-0K2 p1 *XCMPLX-0K3 f .FUNCT-1K1 e1"
                using A1 A34 A37 A25 rfunct_3_def_12 A39 A40 sorry
              then have "f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 (SumRVSUM-1K22 P1 *XCMPLX-0K3 SumRVSUM-1K22 P1 \<inverse>XCMPLX-0K5)*XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k)\<^esub>(P1,F1)) +XCMPLX-0K2 p1 *XCMPLX-0K3 f .FUNCT-1K1 e1"
                using A38 xxreal_0_th_2 sorry
              thus "f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F))"
                using A11 A9 A24 xcmplx_0_def_7 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(k +NAT-1K1 \<one>\<^sub>M)\<^esub>(P,F))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A41: "?S(0NUMBERSK6)"
      using rvsum_1_th_79 sorry
    have " for k be NatNAT-1M1 holds ?S(k)"
      using nat_1_sch_2 A41 A2 sorry
    thus " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for P be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for E be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  for F be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2 holds  not ((SumRVSUM-1K22 P =COMPLEX1R1 \<one>\<^sub>M & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domFINSEQ-1K5 P &  not (P .FUNCT-1K1 i >=XXREAL-0R2 0NUMBERSK6 & F .FUNCT-1K1 i =COMPLEX1R1 f .FUNCT-1K1 (E .FUNCT-1K1 i))))) &  not f .FUNCT-1K1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,E)) <=XXREAL-0R1 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(P,F)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_20:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for I be IntervalMEASURE5M1 holds  for a be RealXREAL-0M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 I & x2 inHIDDENR3 I) & x1 <XXREAL-0R3 a) & a <XXREAL-0R3 x2) & f is-convex-onRFUNCT-3R2 I implies f is-continuous-inFCONT-1R1 a"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix I assume [ty]: "I be IntervalMEASURE5M1"
  fix a assume [ty]: "a be RealXREAL-0M1"
  assume A1: " ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 I & x2 inHIDDENR3 I) & x1 <XXREAL-0R3 a) & a <XXREAL-0R3 x2"
    and A2: "f is-convex-onRFUNCT-3R2 I"
  obtain x1 x2 where
    [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" and 
    A3: "x1 inHIDDENR3 I"and A4: "x2 inHIDDENR3 I"and A5: "x1 <XXREAL-0R3 a"and A6: "a <XXREAL-0R3 x2"
    using A1 sorry
  let ?M = "maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|)"
  have A7: "a inHIDDENR3 I"
    using A3 A4 A5 A6 xxreal_2_th_80 sorry
  have A8: " for x be RealXREAL-0M1 holds (x1 <=XXREAL-0R1 x & x <=XXREAL-0R1 x2) & x <>HIDDENR2 a implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
  proof-
    have " for x be RealXREAL-0M1 holds x1 <=XXREAL-0R1 x & (x <=XXREAL-0R1 x2 & x <>HIDDENR2 a) implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x1 <=XXREAL-0R1 x"
        and A10: "x <=XXREAL-0R1 x2"
        and A11: "x <>HIDDENR2 a"
      have A12: "x inHIDDENR3 I"
        using A3 A4 A9 A10 xxreal_2_th_80 sorry
      have "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
      proof-
        have "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
        proof-
          show "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
          proof-
            have cases: "x <XXREAL-0R3 a or x >XXREAL-0R4 a"
              using A11 xxreal_0_th_1 sorry
            have case1: "x <XXREAL-0R3 a implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
            proof(rule impI)
              assume A13: "x <XXREAL-0R3 a"
              have A14: "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
              proof-
                show "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                proof-
                  have cases: "x1 =COMPLEX1R1 x or x1 <XXREAL-0R3 x"
                    using A9 xxreal_0_th_1 sorry
                  have case1: "x1 =COMPLEX1R1 x implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                  proof(rule impI)
                    assume "x1 =COMPLEX1R1 x"
                    thus "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                       sorry
                  qed
                  have case2: "x1 <XXREAL-0R3 x implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                  proof(rule impI)
                    assume A15: "x1 <XXREAL-0R3 x"
                    have A16: "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (a -XCMPLX-0K6 x1) =HIDDENR1 (-XCMPLX-0K4 (f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x1))/XCMPLX-0K7 (-XCMPLX-0K4 (a -XCMPLX-0K6 x1))"
                      using xcmplx_1_th_191 sorry
                    also have "... = (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a)"
                       sorry
                    finally have "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (a -XCMPLX-0K6 x1) =HIDDENR1 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a)"
                       sorry
                    have "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x) =HIDDENR1 (-XCMPLX-0K4 (f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x))/XCMPLX-0K7 (-XCMPLX-0K4 (a -XCMPLX-0K6 x))"
                      using xcmplx_1_th_191 sorry
                    also have "... = (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                       sorry
                    finally have "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x) =HIDDENR1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                       sorry
                    thus "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                      using A2 A3 A7 A12 A13 A15 A16 rfunct_4_th_16 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              have "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x) & (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                using A2 A4 A6 A7 A12 A13 rfunct_4_th_16 sorry
              then have "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                using xxreal_0_th_2 sorry
              then have "(-XCMPLX-0K4 (f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x))/XCMPLX-0K7 (-XCMPLX-0K4 (a -XCMPLX-0K6 x)) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                using xcmplx_1_th_191 sorry
              thus "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                using A14 sorry
            qed
            have case2: "x >XXREAL-0R4 a implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
            proof(rule impI,rule conjMI)
              assume A17: "x >XXREAL-0R4 a"
              have A18: "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (a -XCMPLX-0K6 x1) =HIDDENR1 (-XCMPLX-0K4 (f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x1))/XCMPLX-0K7 (-XCMPLX-0K4 (a -XCMPLX-0K6 x1))"
                using xcmplx_1_th_191 sorry
              also have "... = (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a)"
                 sorry
              finally have "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (a -XCMPLX-0K6 x1) =HIDDENR1 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a)"
                 sorry
              have "(f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (a -XCMPLX-0K6 x1) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x -XCMPLX-0K6 x1) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x1)/XCMPLX-0K7 (x -XCMPLX-0K6 x1) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                using A2 A3 A5 A7 A12 A17 rfunct_4_th_16 sorry
              thus "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
                using A18 xxreal_0_th_2 sorry
              have "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
              proof-
                show "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                proof-
                  have cases: "x =COMPLEX1R1 x2 or x <XXREAL-0R3 x2"
                    using A10 xxreal_0_th_1 sorry
                  have case1: "x =COMPLEX1R1 x2 implies (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                  proof(rule impI)
                    assume "x =COMPLEX1R1 x2"
                    thus "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                       sorry
                  qed
                  have case2: "x <XXREAL-0R3 x2 implies (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                  proof(rule impI)
                    assume "x <XXREAL-0R3 x2"
                    thus "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                      using A2 A4 A7 A12 A17 rfunct_4_th_16 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
           sorry
      qed
      thus "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) & (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A19: " for x be RealXREAL-0M1 holds (x1 <=XXREAL-0R1 x & x <=XXREAL-0R1 x2) & x <>HIDDENR2 a implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 ?M *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
  proof-
    have " for x be RealXREAL-0M1 holds (x1 <=XXREAL-0R1 x & x <=XXREAL-0R1 x2) & x <>HIDDENR2 a implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
    proof(rule ballI,rule impMI ,rule impI)
      have A20: "-XCMPLX-0K4  |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| <=XXREAL-0R1 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a)"
        using absvalue_th_4 sorry
      have A21: "(f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|"
        using absvalue_th_4 sorry
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A22: "x1 <=XXREAL-0R1 x & x <=XXREAL-0R1 x2"
        and A23: "x <>HIDDENR2 a"
      have 
        [ty]:"x be RealXREAL-0M1"
         sorry
      have "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a)"
        using A8 A22 A23 sorry
      then have A24: "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|"
        using A21 xxreal_0_th_2 sorry
      have "x -XCMPLX-0K6 a <>HIDDENR2 0NUMBERSK6"
        using A23 sorry
      then have A25: " |.COMPLEX1K10 x -XCMPLX-0K6 a .| >XXREAL-0R4 0NUMBERSK6"
        using complex1_th_47 sorry
      have "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
        using A8 A22 A23 sorry
      then have A26: "-XCMPLX-0K4  |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
        using A20 xxreal_0_th_2 sorry
      have " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
      proof-
        show " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
        proof-
          have cases: " |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .| or  |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| >=XXREAL-0R2  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|"
             sorry
          have case1: " |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .| implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
          proof(rule impI)
            assume " |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|"
            then have "-XCMPLX-0K4  |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|"
              using xreal_1_th_24 sorry
            then have "-XCMPLX-0K4  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .| <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
              using A26 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) .| <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|"
              using A24 absvalue_th_5 sorry
            then have A27: "( |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .|)/XCMPLX-0K7 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|"
              using complex1_th_67 sorry
            have " |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .| <=XXREAL-0R1 ?M"
              using xxreal_0_th_25 sorry
            then have "( |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .|)/XCMPLX-0K7 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <=XXREAL-0R1 ?M"
              using A27 xxreal_0_th_2 sorry
            thus " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
              using A25 xreal_1_th_81 sorry
          qed
          have case2: " |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| >=XXREAL-0R2  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .| implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
          proof(rule impI)
            assume " |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| >=XXREAL-0R2  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|"
            then have "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|"
              using A24 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a) .| <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|"
              using A26 absvalue_th_5 sorry
            then have A28: "( |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .|)/XCMPLX-0K7 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <=XXREAL-0R1  |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|"
              using complex1_th_67 sorry
            have " |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| <=XXREAL-0R1 ?M"
              using xxreal_0_th_25 sorry
            then have "( |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .|)/XCMPLX-0K7 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <=XXREAL-0R1 ?M"
              using A28 xxreal_0_th_2 sorry
            thus " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
              using A25 xreal_1_th_81 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A29: "maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) >=XXREAL-0R2 minXXREAL-0K4( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|)"
    using rfunct_4_th_1 sorry
  have A30: " |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .| >=XXREAL-0R2 0NUMBERSK6 &  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .| >=XXREAL-0R2 0NUMBERSK6"
    using complex1_th_46 sorry
  then have A31: "minXXREAL-0K4( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) >=XXREAL-0R2 0NUMBERSK6"
    using xxreal_0_th_20 sorry
  then have A32: "?M >=XXREAL-0R2 0NUMBERSK6"
    using rfunct_4_th_1 sorry
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))"
  proof-
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies  not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume A33: "0NUMBERSK6 <XXREAL-0R3 r"
      have 
        [ty]:"r be RealXREAL-0M1"
         sorry
      have " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r)"
      proof-
        have " not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
        proof-
          have " not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
          proof-
            show " not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
            proof-
              have cases: "?M >XXREAL-0R4 0NUMBERSK6 or ?M =COMPLEX1R1 0NUMBERSK6"
                using A30 A29 xxreal_0_th_20 sorry
              have case1: "maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) >XXREAL-0R4 0NUMBERSK6 implies  not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
              proof(rule impI)
                assume A34: "?M >XXREAL-0R4 0NUMBERSK6"
                let ?s = "minXXREAL-0K4(r /XCMPLX-0K7 ?M,minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a))"
                have A35: " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 ?s implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                proof-
                  have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                  proof(rule ballI,rule impMI ,rule impI)
                    have A36: "?s <=XXREAL-0R1 minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)"
                      using xxreal_0_th_17 sorry
                    fix x assume [ty]: "x be RealXREAL-0M1"
                    assume "x inHIDDENR3 domRELAT-1K1 f"
                      and A37: " |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 ?s"
                    have "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) <=XXREAL-0R1 a -XCMPLX-0K6 x1"
                      using xxreal_0_th_17 sorry
                    then have "?s <=XXREAL-0R1 a -XCMPLX-0K6 x1"
                      using A36 xxreal_0_th_2 sorry
                    then have " |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 a -XCMPLX-0K6 x1"
                      using A37 xxreal_0_th_2 sorry
                    then have "-XCMPLX-0K4 (a -XCMPLX-0K6 x1) <=XXREAL-0R1 x -XCMPLX-0K6 a"
                      using absvalue_th_5 sorry
                    then have "x1 -XCMPLX-0K6 a <=XXREAL-0R1 x -XCMPLX-0K6 a"
                       sorry
                    then have A38: "x1 <=XXREAL-0R1 x"
                      using xreal_1_th_9 sorry
                    have "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) <=XXREAL-0R1 x2 -XCMPLX-0K6 a"
                      using xxreal_0_th_17 sorry
                    then have "?s <=XXREAL-0R1 x2 -XCMPLX-0K6 a"
                      using A36 xxreal_0_th_2 sorry
                    then have " |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 x2 -XCMPLX-0K6 a"
                      using A37 xxreal_0_th_2 sorry
                    then have "x -XCMPLX-0K6 a <=XXREAL-0R1 x2 -XCMPLX-0K6 a"
                      using absvalue_th_5 sorry
                    then have A39: "x <=XXREAL-0R1 x2"
                      using xreal_1_th_9 sorry
                    have " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                    proof-
                      show " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                      proof-
                        have cases: "x <>HIDDENR2 a or x =COMPLEX1R1 a"
                           sorry
                        have case1: "x <>HIDDENR2 a implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                        proof(rule impI)
                          assume "x <>HIDDENR2 a"
                          then have A40: " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 ?M *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
                            using A19 A38 A39 sorry
                          have " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                          proof-
                            show " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                            proof-
                              have cases: "?M <>HIDDENR2 0NUMBERSK6 or ?M =COMPLEX1R1 0NUMBERSK6"
                                 sorry
                              have case1: "maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) <>HIDDENR2 0NUMBERSK6 implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                              proof(rule impI)
                                assume A41: "?M <>HIDDENR2 0NUMBERSK6"
                                have A42: "?M *XCMPLX-0K3 ?s <=XXREAL-0R1 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 ?M)"
                                  using A31 A29 xreal_1_th_64 xxreal_0_th_17 sorry
                                have "?M *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <XXREAL-0R3 ?M *XCMPLX-0K3 ?s"
                                  using A32 A37 A41 xreal_1_th_68 sorry
                                then have "?M *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <XXREAL-0R3 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 ?M)"
                                  using A42 xxreal_0_th_2 sorry
                                then have "?M *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <XXREAL-0R3 (r *XCMPLX-0K3 ?M)/XCMPLX-0K7 ?M"
                                  using xcmplx_1_th_74 sorry
                                then have "?M *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <XXREAL-0R3 r *XCMPLX-0K3 (?M /XCMPLX-0K7 ?M)"
                                  using xcmplx_1_th_74 sorry
                                then have "?M *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|) <XXREAL-0R3 r *XCMPLX-0K3 \<one>\<^sub>M"
                                  using A41 xcmplx_1_th_60 sorry
                                thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                                  using A40 xxreal_0_th_2 sorry
                              qed
                              have case2: "maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) =COMPLEX1R1 0NUMBERSK6 implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                              proof(rule impI)
                                assume "?M =COMPLEX1R1 0NUMBERSK6"
                                thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                                  using A33 A40 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                             sorry
                        qed
                        have case2: "x =COMPLEX1R1 a implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                        proof(rule impI)
                          assume "x =COMPLEX1R1 a"
                          thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                            using A33 absvalue_th_2 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                       sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                have "?s >XXREAL-0R4 0NUMBERSK6"
                proof-
                  have " not minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) >XXREAL-0R4 0NUMBERSK6"
                  proof-
                    have A43: "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                    proof-
                      have " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                      proof-
                        have " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                        proof-
                          show " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                          proof-
                            have cases: "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) =COMPLEX1R1 a -XCMPLX-0K6 x1 or minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) =COMPLEX1R1 x2 -XCMPLX-0K6 a"
                              using xxreal_0_th_15 sorry
                            have case1: "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) =COMPLEX1R1 a -XCMPLX-0K6 x1 implies  not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                            proof(rule impI)
                              assume "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) =COMPLEX1R1 a -XCMPLX-0K6 x1"
                              thus " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                                using A5 xreal_1_th_50 sorry
                            qed
                            have case2: "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) =COMPLEX1R1 x2 -XCMPLX-0K6 a implies  not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                            proof(rule impI)
                              assume "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) =COMPLEX1R1 x2 -XCMPLX-0K6 a"
                              thus " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                                using A6 xreal_1_th_50 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                        thus " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                           sorry
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                    have " not minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) >XXREAL-0R4 0NUMBERSK6"
                    proof-
                      show " not minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) >XXREAL-0R4 0NUMBERSK6"
                      proof-
                        have cases: "?s =COMPLEX1R1 r /XCMPLX-0K7 ?M or ?s =COMPLEX1R1 minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)"
                          using xxreal_0_th_15 sorry
                        have case1: "minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) =COMPLEX1R1 r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) implies  not minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) >XXREAL-0R4 0NUMBERSK6"
                        proof(rule impI)
                          assume "?s =COMPLEX1R1 r /XCMPLX-0K7 ?M"
                          thus " not minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) >XXREAL-0R4 0NUMBERSK6"
                            using A33 A34 xreal_1_th_139 sorry
                        qed
                        have case2: "minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) =COMPLEX1R1 minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) implies  not minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) >XXREAL-0R4 0NUMBERSK6"
                        proof(rule impI)
                          assume "?s =COMPLEX1R1 minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)"
                          thus " not minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) >XXREAL-0R4 0NUMBERSK6"
                            using A43 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " not minXXREAL-0K4(r /XCMPLX-0K7 maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|),minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)) >XXREAL-0R4 0NUMBERSK6"
                       sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                thus " not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
                  using A35 sorry
              qed
              have case2: "maxXXREAL-0K5( |.COMPLEX1K10 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x1 -XCMPLX-0K6 a) .|, |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 a)/XCMPLX-0K7 (x2 -XCMPLX-0K6 a) .|) =COMPLEX1R1 0NUMBERSK6 implies  not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
              proof(rule impI)
                assume A44: "?M =COMPLEX1R1 0NUMBERSK6"
                let ?s = "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a)"
                have A45: " for x be RealXREAL-0M1 holds (x1 <=XXREAL-0R1 x & x <=XXREAL-0R1 x2) & x <>HIDDENR2 a implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| =COMPLEX1R1 0NUMBERSK6"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be RealXREAL-0M1"
                  assume "(x1 <=XXREAL-0R1 x & x <=XXREAL-0R1 x2) & x <>HIDDENR2 a"
                  then have " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <=XXREAL-0R1 ?M *XCMPLX-0K3 ( |.COMPLEX1K10 x -XCMPLX-0K6 a .|)"
                    using A19 sorry
                  thus " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| =COMPLEX1R1 0NUMBERSK6"
                    using A44 complex1_th_46 sorry
                qed "sorry"
                have A46: " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 ?s implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                proof-
                  have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                  proof(rule ballI,rule impMI ,rule impI)
                    fix x assume [ty]: "x be RealXREAL-0M1"
                    assume "x inHIDDENR3 domRELAT-1K1 f"
                      and A47: " |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 ?s"
                    have "?s <=XXREAL-0R1 a -XCMPLX-0K6 x1"
                      using xxreal_0_th_17 sorry
                    then have " |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 a -XCMPLX-0K6 x1"
                      using A47 xxreal_0_th_2 sorry
                    then have "-XCMPLX-0K4 (a -XCMPLX-0K6 x1) <=XXREAL-0R1 x -XCMPLX-0K6 a"
                      using absvalue_th_5 sorry
                    then have "x1 -XCMPLX-0K6 a <=XXREAL-0R1 x -XCMPLX-0K6 a"
                       sorry
                    then have A48: "x1 <=XXREAL-0R1 x"
                      using xreal_1_th_9 sorry
                    have "?s <=XXREAL-0R1 x2 -XCMPLX-0K6 a"
                      using xxreal_0_th_17 sorry
                    then have " |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 x2 -XCMPLX-0K6 a"
                      using A47 xxreal_0_th_2 sorry
                    then have "x -XCMPLX-0K6 a <=XXREAL-0R1 x2 -XCMPLX-0K6 a"
                      using absvalue_th_5 sorry
                    then have A49: "x <=XXREAL-0R1 x2"
                      using xreal_1_th_9 sorry
                    have " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                    proof-
                      show " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                      proof-
                        have cases: "x <>HIDDENR2 a or x =COMPLEX1R1 a"
                           sorry
                        have case1: "x <>HIDDENR2 a implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                        proof(rule impI)
                          assume "x <>HIDDENR2 a"
                          thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                            using A33 A45 A48 A49 sorry
                        qed
                        have case2: "x =COMPLEX1R1 a implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                        proof(rule impI)
                          assume "x =COMPLEX1R1 a"
                          thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                            using A33 absvalue_th_2 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r"
                       sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                have "?s >XXREAL-0R4 0NUMBERSK6"
                proof-
                  have " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                  proof-
                    have " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                    proof-
                      show " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                      proof-
                        have cases: "?s =COMPLEX1R1 a -XCMPLX-0K6 x1 or ?s =COMPLEX1R1 x2 -XCMPLX-0K6 a"
                          using xxreal_0_th_15 sorry
                        have case1: "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) =COMPLEX1R1 a -XCMPLX-0K6 x1 implies  not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                        proof(rule impI)
                          assume "?s =COMPLEX1R1 a -XCMPLX-0K6 x1"
                          thus " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                            using A5 xreal_1_th_50 sorry
                        qed
                        have case2: "minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) =COMPLEX1R1 x2 -XCMPLX-0K6 a implies  not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                        proof(rule impI)
                          assume "?s =COMPLEX1R1 x2 -XCMPLX-0K6 a"
                          thus " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                            using A6 xreal_1_th_50 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " not minXXREAL-0K4(a -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 a) >XXREAL-0R4 0NUMBERSK6"
                       sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                thus " not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
                  using A46 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 a .| <XXREAL-0R3 s) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 a .| <XXREAL-0R3 r))))"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "f is-continuous-inFCONT-1R1 a"
    using fcont_1_th_3 sorry
qed "sorry"

(*begin*)
mdef rfunct_4_def_2 (" _ is-quasiconvex-onRFUNCT-4R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-quasiconvex-onRFUNCT-4R2 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"..

mdef rfunct_4_def_3 (" _ is-strictly-quasiconvex-onRFUNCT-4R3  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-strictly-quasiconvex-onRFUNCT-4R3 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & f .FUNCT-1K1 r <>HIDDENR2 f .FUNCT-1K1 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"..

mdef rfunct_4_def_4 (" _ is-strongly-quasiconvex-onRFUNCT-4R4  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-strongly-quasiconvex-onRFUNCT-4R4 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"..

mdef rfunct_4_def_5 (" _ is-upper-semicontinuous-inRFUNCT-4R5  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-upper-semicontinuous-inRFUNCT-4R5 x0 means
  x0 inHIDDENR3 domRELAT-1K1 f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r)))"..

mdef rfunct_4_def_6 (" _ is-upper-semicontinuous-onRFUNCT-4R6  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-upper-semicontinuous-onRFUNCT-4R6 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-upper-semicontinuous-inRFUNCT-4R5 x0)"..

mdef rfunct_4_def_7 (" _ is-lower-semicontinuous-inRFUNCT-4R7  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-lower-semicontinuous-inRFUNCT-4R7 x0 means
  x0 inHIDDENR3 domRELAT-1K1 f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r)))"..

mdef rfunct_4_def_8 (" _ is-lower-semicontinuous-onRFUNCT-4R8  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred f is-lower-semicontinuous-onRFUNCT-4R8 X means
  X c=TARSKIR1 domRELAT-1K1 f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-lower-semicontinuous-inRFUNCT-4R7 x0)"..

mtheorem rfunct_4_th_21:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELAT-1K1 f implies (f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0 iff f is-continuous-inFCONT-1R1 x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELAT-1K1 f implies  not ((f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0) &  not f is-continuous-inFCONT-1R1 x0) &  not (f is-continuous-inFCONT-1R1 x0 &  not (f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0))"
  proof(rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "x0 inHIDDENR3 domRELAT-1K1 f"
    have A2: "f is-continuous-inFCONT-1R1 x0 implies f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0"
    proof(rule impI)
      assume A3: "f is-continuous-inFCONT-1R1 x0"
      have A4: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r))"
      proof-
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar1 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar1 & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar1) & f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r)))"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A5: "0NUMBERSK6 <XXREAL-0R3 s"and A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            using A3 fcont_1_th_3 sorry
          show " ex tVar1 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar1 & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar1) & f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r))"
          proof(rule bexI[of _ "s"])
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r"
            proof-
              have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  not f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume "x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
                then have A7: " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
                  using A6 sorry
                have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
                  using absvalue_th_4 sorry
                then have "-XCMPLX-0K4 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0) <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
                  using xreal_1_th_26 sorry
                thus " not f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r"
                  using A7 xxreal_0_th_2 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            thus " not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s) & f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r))"
              using A5 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r))"
      proof-
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar2 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar2 & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar2) & f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r)))"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A8: "0NUMBERSK6 <XXREAL-0R3 s"and A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            using A3 fcont_1_th_3 sorry
          show " ex tVar2 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar2 & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar2) & f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r))"
          proof(rule bexI[of _ "s"])
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r"
            proof-
              have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  not f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume "x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
                then have A10: " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
                  using A9 sorry
                have "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
                  using absvalue_th_4 sorry
                thus " not f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r"
                  using A10 xxreal_0_th_2 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            thus " not 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s) & f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r))"
              using A8 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0"
        using A1 A4 sorry
    qed
    have "f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0 implies f is-continuous-inFCONT-1R1 x0"
    proof(rule impMI ,rule impI)
      assume A11: "f is-upper-semicontinuous-inRFUNCT-4R5 x0"
        and A12: "f is-lower-semicontinuous-inRFUNCT-4R7 x0"
      have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
      proof-
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar3 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar3 & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar3) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume A13: "0NUMBERSK6 <XXREAL-0R3 r"
          obtain s1 where
            [ty]:"s1 be RealXREAL-0M1" and 
            A14: "0NUMBERSK6 <XXREAL-0R3 s1"and A15: " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s1 implies f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r"
            using A12 A13 sorry
          obtain s2 where
            [ty]:"s2 be RealXREAL-0M1" and 
            A16: "0NUMBERSK6 <XXREAL-0R3 s2"and A17: " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s2 implies f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r"
            using A11 A13 sorry
          let ?s = "minXXREAL-0K4(s1,s2)"
          have A18: " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 ?s implies  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELAT-1K1 f &  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 minXXREAL-0K4(s1,s2) implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            proof(rule ballI,rule impMI ,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume A19: "x inHIDDENR3 domRELAT-1K1 f"
                and A20: " |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 ?s"
              have "?s <=XXREAL-0R1 s2"
                using xxreal_0_th_17 sorry
              then have " |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s2"
                using A20 xxreal_0_th_2 sorry
              then have A21: "f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x <XXREAL-0R3 r"
                using A17 A19 sorry
              have "?s <=XXREAL-0R1 s1"
                using xxreal_0_th_17 sorry
              then have " |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 s1"
                using A20 xxreal_0_th_2 sorry
              then have A22: "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 <XXREAL-0R3 r"
                using A15 A19 sorry
              have A23: " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <>HIDDENR2 r"
              proof-
                have " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =COMPLEX1R1 r implies  not  True "
                proof(rule impI)
                  assume A24: " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =COMPLEX1R1 r"
                  have " False "
                  proof-
                    show " False "
                    proof-
                      have cases: "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 >=XXREAL-0R2 0NUMBERSK6 or  not f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 >=XXREAL-0R2 0NUMBERSK6"
                         sorry
                      have case1: "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 >=XXREAL-0R2 0NUMBERSK6 implies  False "
                      proof(rule impI)
                        assume "f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 >=XXREAL-0R2 0NUMBERSK6"
                        thus " False "
                          using A22 A24 absvalue_def_1 sorry
                      qed
                      have case2: " not f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 >=XXREAL-0R2 0NUMBERSK6 implies  False "
                      proof(rule impI)
                        assume " not f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 >=XXREAL-0R2 0NUMBERSK6"
                        then have " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =COMPLEX1R1 -XCMPLX-0K4 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                          using absvalue_def_1 sorry
                        thus " False "
                          using A21 A24 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus " not  True "
                     sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have "-XCMPLX-0K4 (f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x) >XXREAL-0R4 -XCMPLX-0K4 r"
                using A21 xreal_1_th_24 sorry
              then have " |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <=XXREAL-0R1 r"
                using A22 absvalue_th_5 sorry
              thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
                using A23 xxreal_0_th_1 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          show " ex tVar3 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar3 & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar3) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
          proof(rule bexI[of _ "?s"])
            have "?s >XXREAL-0R4 0NUMBERSK6"
            proof-
              have " not minXXREAL-0K4(s1,s2) >XXREAL-0R4 0NUMBERSK6"
              proof-
                have " not minXXREAL-0K4(s1,s2) >XXREAL-0R4 0NUMBERSK6"
                proof-
                  show " not minXXREAL-0K4(s1,s2) >XXREAL-0R4 0NUMBERSK6"
                  proof-
                    have cases: "s1 <=XXREAL-0R1 s2 or  not s1 <=XXREAL-0R1 s2"
                       sorry
                    have case1: "s1 <=XXREAL-0R1 s2 implies  not minXXREAL-0K4(s1,s2) >XXREAL-0R4 0NUMBERSK6"
                    proof(rule impI)
                      assume "s1 <=XXREAL-0R1 s2"
                      thus " not minXXREAL-0K4(s1,s2) >XXREAL-0R4 0NUMBERSK6"
                        using A14 xxreal_0_def_9 sorry
                    qed
                    have case2: " not s1 <=XXREAL-0R1 s2 implies  not minXXREAL-0K4(s1,s2) >XXREAL-0R4 0NUMBERSK6"
                    proof(rule impI)
                      assume " not s1 <=XXREAL-0R1 s2"
                      thus " not minXXREAL-0K4(s1,s2) >XXREAL-0R4 0NUMBERSK6"
                        using A16 xxreal_0_def_9 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus " not minXXREAL-0K4(s1,s2) >XXREAL-0R4 0NUMBERSK6"
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            thus " not 0NUMBERSK6 <XXREAL-0R3 minXXREAL-0K4(s1,s2) & ( for x be RealXREAL-0M1 holds  not ((x inHIDDENR3 domRELAT-1K1 f &  not  |.COMPLEX1K10 x -XCMPLX-0K6 x0 .| <XXREAL-0R3 minXXREAL-0K4(s1,s2)) &  |.COMPLEX1K10 f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
              using A18 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-continuous-inFCONT-1R1 x0"
        using fcont_1_th_3 sorry
    qed
    thus " not ((f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0) &  not f is-continuous-inFCONT-1R1 x0) &  not (f is-continuous-inFCONT-1R1 x0 &  not (f is-upper-semicontinuous-inRFUNCT-4R5 x0 & f is-lower-semicontinuous-inRFUNCT-4R7 x0))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_22:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELAT-1K1 f implies (f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X iff f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELAT-1K1 f implies  not ((f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) &  not (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 &  not (f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 f"
    have A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X"
    proof(rule impI)
      assume A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      have A4: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-lower-semicontinuous-inRFUNCT-4R7 x0"
      proof(rule ballI,rule impI)
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        assume "x0 inHIDDENR3 X"
        then have A5: "x0 inHIDDENR3 domRELAT-1K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using A1 relat_1_th_57 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          using A3 fcont_1_def_2 sorry
        thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-lower-semicontinuous-inRFUNCT-4R7 x0"
          using A5 rfunct_4_th_21 sorry
      qed "sorry"
      have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-upper-semicontinuous-inRFUNCT-4R5 x0"
      proof(rule ballI,rule impI)
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        assume "x0 inHIDDENR3 X"
        then have A6: "x0 inHIDDENR3 domRELAT-1K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using A1 relat_1_th_57 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          using A3 fcont_1_def_2 sorry
        thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-upper-semicontinuous-inRFUNCT-4R5 x0"
          using A6 rfunct_4_th_21 sorry
      qed "sorry"
      thus "f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X"
        using A1 A4 sorry
    qed
    have "f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    proof(rule impMI ,rule impI)
      assume A7: "f is-upper-semicontinuous-onRFUNCT-4R6 X"
        and A8: "f is-lower-semicontinuous-onRFUNCT-4R8 X"
      have "X c=TARSKIR1 domRELAT-1K1 f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELAT-1K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0)"
      proof(rule conjMI,rule ballI,rule impI)
        show "X c=TARSKIR1 domRELAT-1K1 f"
          using A7 sorry
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        assume A9: "x0 inHIDDENR3 domRELAT-1K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        have "x0 inHIDDENR3 X"
          using A9 relat_1_th_57 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-upper-semicontinuous-inRFUNCT-4R5 x0 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-lower-semicontinuous-inRFUNCT-4R7 x0"
          using A7 A8 sorry
        thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          using rfunct_4_th_21 sorry
      qed "sorry"
      thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        using fcont_1_def_2 sorry
    qed
    thus " not ((f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) &  not (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 &  not (f is-upper-semicontinuous-onRFUNCT-4R6 X & f is-lower-semicontinuous-onRFUNCT-4R8 X))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_4_th_23:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strictly-convex-onRFUNCT-4R1 X implies f is-strongly-quasiconvex-onRFUNCT-4R4 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume A1: "f is-strictly-convex-onRFUNCT-4R1 X"
  have A2: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s))"
  proof-
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"
    proof(rule ballI,rule impMI ,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A3: "0NUMBERSK6 <XXREAL-0R3 p"
        and A4: "p <XXREAL-0R3 \<one>\<^sub>M"
      have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
      proof-
        have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
        proof(rule ballI,rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          fix s assume [ty]: "s be RealXREAL-0M1"
          have "\<one>\<^sub>M -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
            using A4 xreal_1_th_50 sorry
          then have A5: "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
            using xreal_1_th_64 xxreal_0_th_25 sorry
          assume "((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & r <>HIDDENR2 s"
          then have A6: "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
            using A1 A3 A4 sorry
          have "p *XCMPLX-0K3 f .FUNCT-1K1 r <=XXREAL-0R1 p *XCMPLX-0K3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
            using A3 xreal_1_th_64 xxreal_0_th_25 sorry
          then have "p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s <=XXREAL-0R1 p *XCMPLX-0K3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
            using A5 xreal_1_th_7 sorry
          thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
            using A6 xxreal_0_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not r <>HIDDENR2 s) & f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s))"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "X c=TARSKIR1 domRELAT-1K1 f"
    using A1 sorry
  thus "f is-strongly-quasiconvex-onRFUNCT-4R4 X"
    using A2 sorry
qed "sorry"

mtheorem rfunct_4_th_24:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strongly-quasiconvex-onRFUNCT-4R4 X implies f is-quasiconvex-onRFUNCT-4R2 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume A1: "f is-strongly-quasiconvex-onRFUNCT-4R4 X"
  have A2: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s))"
  proof-
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A3: "0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M"
      have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
      proof(rule ballI,rule ballI,rule impI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        fix s assume [ty]: "s be RealXREAL-0M1"
        assume A4: "(r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
        have "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
        proof-
          show "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
          proof-
            have cases: "r <>HIDDENR2 s or r =COMPLEX1R1 s"
               sorry
            have case1: "r <>HIDDENR2 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
            proof(rule impI)
              assume "r <>HIDDENR2 s"
              thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
                using A1 A3 A4 sorry
            qed
            have case2: "r =COMPLEX1R1 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
            proof(rule impI)
              assume "r =COMPLEX1R1 s"
              thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
           sorry
      qed "sorry"
      thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not (((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s))"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "X c=TARSKIR1 domRELAT-1K1 f"
    using A1 sorry
  thus "f is-quasiconvex-onRFUNCT-4R2 X"
    using A2 sorry
qed "sorry"

mtheorem rfunct_4_th_25:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convex-onRFUNCT-3R2 X implies f is-strictly-quasiconvex-onRFUNCT-4R3 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume A1: "f is-convex-onRFUNCT-3R2 X"
  have A2: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & f .FUNCT-1K1 r <>HIDDENR2 f .FUNCT-1K1 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s))"
  proof-
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p & p <XXREAL-0R3 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 r <>HIDDENR2 f .FUNCT-1K1 s) & f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)))"
    proof(rule ballI,rule impMI ,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A3: "0NUMBERSK6 <XXREAL-0R3 p"
        and A4: "p <XXREAL-0R3 \<one>\<^sub>M"
      have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & f .FUNCT-1K1 r <>HIDDENR2 f .FUNCT-1K1 s implies f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
      proof-
        have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) & f .FUNCT-1K1 r <>HIDDENR2 f .FUNCT-1K1 s implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          fix s assume [ty]: "s be RealXREAL-0M1"
          assume A5: "(r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X"
            and A6: "f .FUNCT-1K1 r <>HIDDENR2 f .FUNCT-1K1 s"
          have A7: "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
            using A1 A3 A4 A5 rfunct_3_def_12 sorry
          have A8: "\<one>\<^sub>M -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
            using A4 xreal_1_th_50 sorry
          have " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
          proof-
            show " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
            proof-
              have cases: "f .FUNCT-1K1 r <XXREAL-0R3 f .FUNCT-1K1 s or f .FUNCT-1K1 r >XXREAL-0R4 f .FUNCT-1K1 s"
                using A6 xxreal_0_th_1 sorry
              have case1: "f .FUNCT-1K1 r <XXREAL-0R3 f .FUNCT-1K1 s implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
              proof(rule impI)
                assume "f .FUNCT-1K1 r <XXREAL-0R3 f .FUNCT-1K1 s"
                then have "p *XCMPLX-0K3 f .FUNCT-1K1 r <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s"
                  using A3 xreal_1_th_68 sorry
                then have "p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 s +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                  using xreal_1_th_6 sorry
                then have A9: "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 f .FUNCT-1K1 s"
                  using A7 xxreal_0_th_2 sorry
                have "f .FUNCT-1K1 s <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
                  using xxreal_0_th_25 sorry
                thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
                  using A9 xxreal_0_th_2 sorry
              qed
              have case2: "f .FUNCT-1K1 r >XXREAL-0R4 f .FUNCT-1K1 s implies  not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
              proof(rule impI)
                assume "f .FUNCT-1K1 r >XXREAL-0R4 f .FUNCT-1K1 s"
                then have "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 r >XXREAL-0R4 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s"
                  using A8 xreal_1_th_68 sorry
                then have "p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 s <XXREAL-0R3 p *XCMPLX-0K3 f .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 r"
                  using xreal_1_th_6 sorry
                then have A10: "f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 f .FUNCT-1K1 r"
                  using A7 xxreal_0_th_2 sorry
                have "f .FUNCT-1K1 r <=XXREAL-0R1 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
                  using xxreal_0_th_25 sorry
                thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
                  using A10 xxreal_0_th_2 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not ((((r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X) &  not f .FUNCT-1K1 r <>HIDDENR2 f .FUNCT-1K1 s) & f .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <XXREAL-0R3 maxXXREAL-0K5(f .FUNCT-1K1 r,f .FUNCT-1K1 s))"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "X c=TARSKIR1 domRELAT-1K1 f"
    using A1 rfunct_3_def_12 sorry
  thus "f is-strictly-quasiconvex-onRFUNCT-4R3 X"
    using A2 sorry
qed "sorry"

mtheorem rfunct_4_th_26:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strongly-quasiconvex-onRFUNCT-4R4 X implies f is-strictly-quasiconvex-onRFUNCT-4R3 X"
   sorry

mtheorem rfunct_4_th_27:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-strictly-quasiconvex-onRFUNCT-4R3 X & f be one-to-oneFUNCT-1V2 implies f is-strongly-quasiconvex-onRFUNCT-4R4 X"
  using funct_1_def_4 sorry

end
