theory fdiff_4
  imports taylor_1 sin_cos5 wsierp_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, a, b, c for "RealXREAL-0M1"
reserve n for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve Z for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem fdiff_4_th_1:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A5 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A7: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x"
        using A2 sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A5 A8 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 f .FUNCT-1K1 x"
        using A5 A8 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
        using A3 A4 A8 A9 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
        using A7 A8 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_2:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 a))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 a)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A4: "\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 a"
         sorry
      assume "x inHIDDENR3 Z"
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
        using A2 A4 sorry
    qed "sorry"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A8: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have A10: "f .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a"
        using A2 sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 A9 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 f .FUNCT-1K1 x"
        using A6 A9 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 a)"
        using A5 A3 A9 A10 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 a)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 a)"
        using A8 A9 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 a)))"
      using A1 A7 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_3:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 Z"
      then have "y inHIDDENR3 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
        using A1 sorry
      thus "y inHIDDENR3 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        using valued_1_def_5 sorry
    qed "sorry"
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using tarski_def_3 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
         sorry
    qed "sorry"
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A7: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have A10: "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      have "f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & f is-differentiable-inFDIFF-1R1 x"
        using A2 A6 A9 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 f .FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 f .FUNCT-1K1 x"
        using A6 A9 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (a -XCMPLX-0K6 x)"
        using A4 A5 A9 A10 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (a -XCMPLX-0K6 x)"
         sorry
      then have "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (a -XCMPLX-0K6 x))"
        using A1 A7 A9 fdiff_1_th_20 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))/XCMPLX-0K7 (a -XCMPLX-0K6 x)"
        using xcmplx_1_th_74 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)"
         sorry
      finally have "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)"
         sorry
      thus "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)"
         sorry
    qed "sorry"
    have "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using A1 sorry
    thus "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)))"
      using A7 A8 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_4:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a +XCMPLX-0K2 x))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a +XCMPLX-0K2 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 (a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_th_12 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 valued_1_def_5 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_4_th_1 sorry
    then have A8: "a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_20 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A4 xboole_1_th_18 sorry
    then have A11: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A13: "x inHIDDENR3 Z"
        then have "((a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
          using A5 A7 fdiff_1_th_20 sorry
        also have "... = a *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A7 A13 fdiff_1_def_7 sorry
        also have "... = a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x))"
          using A2 A3 A6 A13 fdiff_4_th_1 sorry
        also have "... = a /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
          using xcmplx_1_th_99 sorry
        finally show "((a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x) -XCMPLX-0K6 diffFDIFF-1K1(a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A11 A8 A14 fdiff_1_th_19 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A11 A14 fdiff_1_def_7 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 ((a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A14 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 ((a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A10 A9 A14 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
        using A12 A14 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 x) -XCMPLX-0K6 a)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
        using A15 xcmplx_1_th_127 sorry
      also have "... = x /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a +XCMPLX-0K2 x)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x /XCMPLX-0K7 (a +XCMPLX-0K2 x)))"
      using A1 A11 A8 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_5:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 x)/XCMPLX-0K7 (a +XCMPLX-0K2 x))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 x)/XCMPLX-0K7 (a +XCMPLX-0K2 x)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\XBOOLE-0K3 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A1 valued_1_th_12 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 valued_1_def_5 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_4_th_1 sorry
    then have A8: "(\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_20 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A4 xboole_1_th_18 sorry
    then have A11: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A13: "x inHIDDENR3 Z"
        then have "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
          using A5 A7 fdiff_1_th_20 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A7 A13 fdiff_1_def_7 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x))"
          using A2 A3 A6 A13 fdiff_4_th_1 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
          using xcmplx_1_th_99 sorry
        finally show "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 x)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      have "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A1 A11 A8 A14 fdiff_1_th_19 sorry
      also have "... = diffFDIFF-1K1((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) -XCMPLX-0K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A14 fdiff_1_def_7 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A14 fdiff_1_def_7 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
        using A10 A9 A14 fdiff_1_th_23 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a +XCMPLX-0K2 x) -XCMPLX-0K6 \<one>\<^sub>M"
        using A12 A14 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 x))/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
        using A15 xcmplx_1_th_126 sorry
      also have "... = (a -XCMPLX-0K6 x)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
         sorry
      finally have "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
         sorry
      thus "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 x)/XCMPLX-0K7 (a +XCMPLX-0K2 x)"
         sorry
    qed "sorry"
    thus "(\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 x)/XCMPLX-0K7 (a +XCMPLX-0K2 x)))"
      using A1 A11 A8 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_6:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_th_12 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 valued_1_def_5 sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 fdiff_4_th_1 sorry
    then have A9: "(\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_20 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A11: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A5 xboole_1_th_18 sorry
    then have A12: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A10 fdiff_1_th_23 sorry
    have A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A14: "x inHIDDENR3 Z"
        then have "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
          using A6 A8 fdiff_1_th_20 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A8 A14 fdiff_1_def_7 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (x +XCMPLX-0K2 a))"
          using A2 A7 A4 A14 fdiff_4_th_1 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
          using xcmplx_1_th_99 sorry
        finally show "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A15: "x inHIDDENR3 Z"
      then have A16: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x) -XCMPLX-0K6 diffFDIFF-1K1((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A12 A9 A15 fdiff_1_th_19 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A12 A15 fdiff_1_def_7 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A15 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A10 A15 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
        using A13 A15 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (x +XCMPLX-0K2 a) -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
        using A16 xcmplx_1_th_127 sorry
      also have "... = (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)))"
      using A1 A12 A9 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_7:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 valued_1_def_5 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_4_th_2 sorry
    then have A8: "(\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_20 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A4 xboole_1_th_18 sorry
    then have A11: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A13: "x inHIDDENR3 Z"
        then have "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
          using A5 A7 fdiff_1_th_20 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A7 A13 fdiff_1_def_7 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 a))"
          using A2 A3 A6 A13 fdiff_4_th_2 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
          using xcmplx_1_th_99 sorry
        finally show "(((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x) +XCMPLX-0K2 diffFDIFF-1K1((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A11 A8 A14 fdiff_1_th_18 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A11 A14 fdiff_1_def_7 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A14 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A10 A9 A14 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
        using A12 A14 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (x -XCMPLX-0K6 a) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
        using A15 xcmplx_1_th_113 sorry
      also have "... = (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *XCMPLX-0K3 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a)))"
      using A1 A11 A8 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 b +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 valued_1_def_5 sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 fdiff_4_th_1 sorry
    then have A9: "(a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_20 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A11: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A5 xboole_1_th_18 sorry
    then have A12: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A10 fdiff_1_th_23 sorry
    have A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A14: "x inHIDDENR3 Z"
        then have "(((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
          using A6 A8 fdiff_1_th_20 sorry
        also have "... = (a -XCMPLX-0K6 b)*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A8 A14 fdiff_1_def_7 sorry
        also have "... = (a -XCMPLX-0K6 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (x +XCMPLX-0K2 b))"
          using A2 A7 A4 A14 fdiff_4_th_1 sorry
        also have "... = (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
          using xcmplx_1_th_99 sorry
        finally show "(((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A15: "x inHIDDENR3 Z"
      then have A16: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x) +XCMPLX-0K2 diffFDIFF-1K1((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A12 A9 A15 fdiff_1_th_18 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A12 A15 fdiff_1_def_7 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A15 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (((a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A10 A15 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
        using A13 A15 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (x +XCMPLX-0K2 b) +XCMPLX-0K2 (a -XCMPLX-0K6 b))/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
        using A16 xcmplx_1_th_113 sorry
      also have "... = (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a -XCMPLX-0K6 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)))"
      using A1 A12 A9 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_9:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 valued_1_def_5 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_4_th_2 sorry
    then have A8: "(a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_20 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A4 xboole_1_th_18 sorry
    then have A11: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A13: "x inHIDDENR3 Z"
        then have "(((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
          using A5 A7 fdiff_1_th_20 sorry
        also have "... = (a +XCMPLX-0K2 b)*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A7 A13 fdiff_1_def_7 sorry
        also have "... = (a +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 b))"
          using A2 A3 A6 A13 fdiff_4_th_2 sorry
        also have "... = (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
          using xcmplx_1_th_99 sorry
        finally show "(((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x) +XCMPLX-0K2 diffFDIFF-1K1((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A11 A8 A14 fdiff_1_th_18 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A11 A14 fdiff_1_def_7 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A14 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A10 A9 A14 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
        using A12 A14 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (x -XCMPLX-0K6 b) +XCMPLX-0K2 (a +XCMPLX-0K2 b))/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
        using A15 xcmplx_1_th_113 sorry
      also have "... = (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x +XCMPLX-0K2 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)))"
      using A1 A11 A8 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 b +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_th_12 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 valued_1_def_5 sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 fdiff_4_th_1 sorry
    then have A9: "(a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_20 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A11: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A5 xboole_1_th_18 sorry
    then have A12: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A10 fdiff_1_th_23 sorry
    have A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A14: "x inHIDDENR3 Z"
        then have "(((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
          using A6 A8 fdiff_1_th_20 sorry
        also have "... = (a +XCMPLX-0K2 b)*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A8 A14 fdiff_1_def_7 sorry
        also have "... = (a +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (x +XCMPLX-0K2 b))"
          using A2 A7 A4 A14 fdiff_4_th_1 sorry
        also have "... = (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
          using xcmplx_1_th_99 sorry
        finally show "(((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A15: "x inHIDDENR3 Z"
      then have A16: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x) -XCMPLX-0K6 diffFDIFF-1K1((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A12 A9 A15 fdiff_1_th_19 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A12 A15 fdiff_1_def_7 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A15 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 (((a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A10 A15 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
        using A13 A15 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (x +XCMPLX-0K2 b) -XCMPLX-0K6 (a +XCMPLX-0K2 b))/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
        using A16 xcmplx_1_th_127 sorry
      also have "... = (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +XCMPLX-0K2 b)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 b)))"
      using A1 A12 A9 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 ((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 ((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A2 valued_1_def_5 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_4_th_2 sorry
    then have A8: "(b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_20 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A4 xboole_1_th_18 sorry
    then have A11: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (b -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (b -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A13: "x inHIDDENR3 Z"
        then have "(((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (b -XCMPLX-0K6 a)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
          using A5 A7 fdiff_1_th_20 sorry
        also have "... = (b -XCMPLX-0K6 a)*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A7 A13 fdiff_1_def_7 sorry
        also have "... = (b -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (x -XCMPLX-0K6 b))"
          using A2 A3 A6 A13 fdiff_4_th_2 sorry
        also have "... = (b -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
          using xcmplx_1_th_99 sorry
        finally show "(((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (b -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x) +XCMPLX-0K2 diffFDIFF-1K1((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A11 A8 A14 fdiff_1_th_18 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A11 A14 fdiff_1_def_7 sorry
      also have "... = (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A8 A14 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (((b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A10 A9 A14 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M +XCMPLX-0K2 (b -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
        using A12 A14 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (x -XCMPLX-0K6 b) +XCMPLX-0K2 (b -XCMPLX-0K6 a))/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
        using A15 xcmplx_1_th_113 sorry
      also have "... = (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b -XCMPLX-0K6 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)))"
      using A1 A11 A8 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_12:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 is-differentiable-inFDIFF-1R1 x"
      using A3 taylor_1_th_2 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 valued_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 b *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A8: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_23 sorry
    have A9: "Z c=TARSKIR1 domRELAT-1K1 (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A5 xboole_1_th_18 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 f2"
      using valued_1_def_5 sorry
    then have A10: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    then have A11: "c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_20 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "\<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using prepower_th_35 sorry
      then have A13: "diffFDIFF-1K1(f2,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A3 taylor_1_th_2 sorry
      assume "x inHIDDENR3 Z"
      thus "(f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A10 A13 fdiff_1_def_7 sorry
    qed "sorry"
    have A14: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A15: "x inHIDDENR3 Z"
        then have "((c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 c *XCMPLX-0K3 (diffFDIFF-1K1(f2,x))"
          using A9 A10 fdiff_1_th_20 sorry
        also have "... = c *XCMPLX-0K3 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A10 A15 fdiff_1_def_7 sorry
        also have "... = c *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x)"
          using A12 A15 sorry
        also have "... = (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x"
           sorry
        finally show "((c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A16: "x inHIDDENR3 Z"
      then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x)"
        using A1 A8 A11 fdiff_1_th_18 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x)"
        using A8 A16 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A16 fdiff_1_def_7 sorry
      also have "... = b +XCMPLX-0K2 ((c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A7 A16 fdiff_1_th_23 sorry
      also have "... = b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x"
        using A14 A16 sorry
      finally have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x"
         sorry
      thus "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x))"
      using A1 A8 A11 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_13:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x"
      using A3 sorry
    then have A7: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 fdiff_4_th_12 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A7 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A9: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 funct_1_th_11 sorry
      then have A11: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 x +XCMPLX-0K2 c *XCMPLX-0K3 f2 .FUNCT-1K1 x"
        using A5 A10 valued_1_def_5 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 f2 .FUNCT-1K1 x"
        using A3 A10 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A2 taylor_1_def_1 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A7 A10 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))/XCMPLX-0K7 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)"
        using A2 A4 A6 A10 A11 fdiff_4_th_12 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)))"
      using A1 A8 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_14:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 f"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A4: "f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_23 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A6: "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_2_th_22 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & f is-differentiable-inFDIFF-1R1 x"
        using A2 A4 fdiff_1_th_9 sorry
      have "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A6 A7 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 (f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 fdiff_2_th_15 sorry
      also have "... = -XCMPLX-0K4 (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A7 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A1 A3 A7 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1"
        using A2 A7 sorry
      finally have "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1"
         sorry
      thus "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1))"
      using A4 A5 fdiff_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_15:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A3: "domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELAT-1K1 f"
      using rfunct_1_th_1 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A1 valued_1_def_5 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using A3 xboole_1_th_1 sorry
    then have A5: "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_4_th_14 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
        using A1 A5 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A6 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1)"
        using A2 A4 A6 fdiff_4_th_14 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1"
         sorry
      finally show "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 x)^2SQUARE-1K1))"
      using A1 A5 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_16:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 f & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 f"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
         sorry
    qed "sorry"
    then have A4: "f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_23 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A6: "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_2_th_22 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & f is-differentiable-inFDIFF-1R1 x"
        using A2 A4 fdiff_1_th_9 sorry
      have "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A6 A7 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 (f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 fdiff_2_th_15 sorry
      also have "... = -XCMPLX-0K4 (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A7 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (f .FUNCT-1K1 x)^2SQUARE-1K1"
        using A1 A3 A7 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
        using xcmplx_1_th_187 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
        using A2 A7 sorry
      finally have "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
         sorry
      thus "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1))"
      using A4 A5 fdiff_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_17:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1)"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x)"
      using A1 rfunct_1_th_21 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using rfunct_1_th_21 sorry
      also have "... = 0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 x"
        using A2 A3 A5 fdiff_4_th_12 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
      finally have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
      thus "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
         sorry
    qed "sorry"
    have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_4_th_12 sorry
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x))"
      using A4 rfunct_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_18:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have "f2 =FUNCT-1R1 \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      using rfunct_1_th_21 sorry
    then have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A3 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      using A1 rfunct_1_th_21 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      have "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using rfunct_1_th_21 sorry
      also have "... = (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 x)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x)+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)"
        using A2 A5 A4 A7 fdiff_4_th_13 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)"
         sorry
      finally have "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    have "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A2 A5 A4 fdiff_4_th_13 sorry
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)))"
      using A6 rfunct_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_19:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)"
      using A1 A3 valued_1_th_8 sorry
    then have A5: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_4_th_13 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x))"
        using A1 A5 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A6 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 x)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M))"
        using A2 A4 A6 fdiff_4_th_13 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 x))/XCMPLX-0K7 (a ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)"
        using xcmplx_1_th_74 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)"
         sorry
      finally have "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)"
         sorry
      thus "((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)))"
      using A1 A5 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_20:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<three>\<^sub>M implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<three>\<^sub>M) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<three>\<^sub>M"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 is-differentiable-inFDIFF-1R1 x"
      using A3 taylor_1_th_2 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using A1 valued_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A8: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_23 sorry
    have "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A5 xboole_1_th_18 sorry
    then have A9: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<three>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<three>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      have "diffFDIFF-1K1(f2,x) =HIDDENR1 \<three>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<three>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A3 taylor_1_th_2 sorry
      thus "(f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<three>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<three>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A9 A11 fdiff_1_def_7 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A12: "x inHIDDENR3 Z"
        then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 diffFDIFF-1K1(f1,x) +XCMPLX-0K2 diffFDIFF-1K1(f2,x)"
          using A1 A8 A9 fdiff_1_th_18 sorry
        then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(f2,x)"
          using A8 A12 fdiff_1_def_7 sorry
        also have "... = (f1 `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A9 A12 fdiff_1_def_7 sorry
        also have "... = 0NUMBERSK6 +XCMPLX-0K2 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A6 A7 A12 fdiff_1_th_23 sorry
        also have "... = \<three>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<three>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
          using A10 A12 sorry
        also have "... = \<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M"
          using prepower_th_36 sorry
        finally show "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M))"
      using A1 A8 A9 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_21:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<three>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 x  |^NEWTONK1 \<three>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<three>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 x  |^NEWTONK1 \<three>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<three>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using tarski_def_3 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a"
      using A3 sorry
    then have A6: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A4 fdiff_4_th_20 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A6 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A8: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 x  |^NEWTONK1 \<three>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have A10: "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 funct_1_th_11 sorry
      have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A3 A6 A9 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))/XCMPLX-0K7 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A6 A9 fdiff_1_def_7 sorry
      also have "... = (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A2 A4 A5 A9 fdiff_4_th_20 sorry
      also have "... = (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x)"
        using A10 valued_1_def_1 sorry
      also have "... = (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 f2 .FUNCT-1K1 x)"
        using A3 A9 sorry
      also have "... = (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 x #ZPREPOWERK3 \<three>\<^sub>M)"
        using A2 taylor_1_def_1 sorry
      also have "... = (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 x  |^NEWTONK1 \<three>\<^sub>M)"
        using prepower_th_36 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 x  |^NEWTONK1 \<three>\<^sub>M)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 x  |^NEWTONK1 \<three>\<^sub>M)"
        using A8 A9 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (a +XCMPLX-0K2 x  |^NEWTONK1 \<three>\<^sub>M)))"
      using A1 A7 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_22:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 funct_1_th_11 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using tarski_def_3 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A6: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      thus "f2 .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
         sorry
    qed "sorry"
    have A8: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A3 xboole_1_th_1 sorry
    then have A9: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A7 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A10: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A6 A9 fdiff_2_th_21 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have A13: "f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A14: "f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 A12 sorry
      have "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A6 A9 A12 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 ((diffFDIFF-1K1(f1,x))*XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A13 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A12 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A9 A12 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A5 A12 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 A7 A12 fdiff_1_th_23 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
        using A14 sorry
      finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
         sorry
      thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1"
        using A10 A12 fdiff_1_def_7 sorry
    qed "sorry"
    have A15: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A16: "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A1 funct_1_th_11 sorry
        then have A17: "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        also have "... = f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x"
          using xcmplx_0_def_9 sorry
        finally have "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x"
           sorry
        have "f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A2 A16 sorry
        thus " not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A17 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A18: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A10 A15 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A19: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A20: "x inHIDDENR3 Z"
      then have A21: "f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      have A22: "f1 .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 A20 sorry
      have A23: "x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 A20 funct_1_th_11 sorry
      have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A10 A15 A20 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A10 A20 fdiff_1_def_7 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1)/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A11 A20 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x)^2SQUARE-1K1)/XCMPLX-0K7 (f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using A23 rfunct_1_def_1 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 ((a -XCMPLX-0K6 x)*XCMPLX-0K3 (a -XCMPLX-0K6 x)))/XCMPLX-0K7 ((a +XCMPLX-0K2 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x))"
        using A22 xcmplx_0_def_9 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x))/XCMPLX-0K7 (a -XCMPLX-0K6 x))/XCMPLX-0K7 ((a +XCMPLX-0K2 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x))"
        using xcmplx_1_th_78 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a -XCMPLX-0K6 x))/XCMPLX-0K7 ((a +XCMPLX-0K2 x)/XCMPLX-0K7 (a -XCMPLX-0K6 x)))/XCMPLX-0K7 (a -XCMPLX-0K6 x)"
        using xcmplx_1_th_48 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a +XCMPLX-0K2 x))/XCMPLX-0K7 (a -XCMPLX-0K6 x)"
        using A21 xcmplx_1_th_55 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 ((a +XCMPLX-0K2 x)*XCMPLX-0K3 (a -XCMPLX-0K6 x))"
        using xcmplx_1_th_78 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using A19 A20 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A18 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_23:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x ^2SQUARE-1K1 -XCMPLX-0K6 a ^2SQUARE-1K1))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x ^2SQUARE-1K1 -XCMPLX-0K6 a ^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 funct_1_th_11 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using tarski_def_3 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A6: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A4 xboole_1_th_1 sorry
    then have A7: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A9: "\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 a"
         sorry
      assume "x inHIDDENR3 Z"
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
        using A2 A9 sorry
    qed "sorry"
    then have A10: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A11: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A10 A7 fdiff_2_th_21 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A13: "x inHIDDENR3 Z"
      then have A14: "f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A15: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a"
        using A2 A13 sorry
      have "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A10 A7 A13 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 ((diffFDIFF-1K1(f1,x))*XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A14 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A10 A13 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 A13 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A5 A8 A13 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A3 A13 fdiff_1_th_23 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1"
        using A15 sorry
      finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1"
         sorry
      thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1"
        using A11 A13 fdiff_1_def_7 sorry
    qed "sorry"
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A17: "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A1 funct_1_th_11 sorry
        then have A18: "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        also have "... = f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x"
          using xcmplx_0_def_9 sorry
        finally have "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x"
           sorry
        have "f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A2 A17 sorry
        thus " not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A18 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A19: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A11 A16 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A20: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x ^2SQUARE-1K1 -XCMPLX-0K6 a ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A21: "x inHIDDENR3 Z"
      then have A22: "f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      have A23: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x +XCMPLX-0K2 a"
        using A2 A21 sorry
      have A24: "x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 A21 funct_1_th_11 sorry
      have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A11 A16 A21 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A11 A21 fdiff_1_def_7 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1)/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A12 A21 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)^2SQUARE-1K1)/XCMPLX-0K7 (f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using A24 rfunct_1_def_1 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 ((x +XCMPLX-0K2 a)*XCMPLX-0K3 (x +XCMPLX-0K2 a)))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a))"
        using A23 xcmplx_0_def_9 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a))/XCMPLX-0K7 (x +XCMPLX-0K2 a))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a))"
        using xcmplx_1_th_78 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 (x +XCMPLX-0K2 a)))/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
        using xcmplx_1_th_48 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x -XCMPLX-0K6 a))/XCMPLX-0K7 (x +XCMPLX-0K2 a)"
        using A22 xcmplx_1_th_55 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x +XCMPLX-0K2 a))"
        using xcmplx_1_th_78 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x ^2SQUARE-1K1 -XCMPLX-0K6 a ^2SQUARE-1K1)"
         sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x ^2SQUARE-1K1 -XCMPLX-0K6 a ^2SQUARE-1K1)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x ^2SQUARE-1K1 -XCMPLX-0K6 a ^2SQUARE-1K1)"
        using A20 A21 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (x ^2SQUARE-1K1 -XCMPLX-0K6 a ^2SQUARE-1K1)))"
      using A1 A19 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b)))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 b)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A4: "\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 a & \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 b) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 b"
         sorry
      assume "x inHIDDENR3 Z"
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) & f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 b)"
        using A2 A4 sorry
    qed "sorry"
    then have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
       sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 funct_1_th_11 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using tarski_def_3 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    then have A8: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_23 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 b)"
      using A3 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A6 xboole_1_th_1 sorry
    then have A11: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A12: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A8 A11 fdiff_2_th_21 sorry
    have A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A14: "x inHIDDENR3 Z"
      then have A15: "f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A16: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b"
        using A2 A14 sorry
      have "f1 is-differentiable-inFDIFF-1R1 x & f2 is-differentiable-inFDIFF-1R1 x"
        using A8 A11 A14 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 ((diffFDIFF-1K1(f1,x))*XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A15 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 A14 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A11 A14 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 A5 A14 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A10 A9 A14 fdiff_1_th_23 sorry
      also have "... = (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1"
        using A16 sorry
      finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1"
         sorry
      thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1"
        using A12 A14 fdiff_1_def_7 sorry
    qed "sorry"
    have A17: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A18: "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A1 funct_1_th_11 sorry
        then have A19: "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        also have "... = f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x"
          using xcmplx_0_def_9 sorry
        finally have "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x"
           sorry
        have "f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A2 A18 sorry
        thus " not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A19 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A20: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A12 A17 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A21: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A22: "x inHIDDENR3 Z"
      then have A23: "f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      have A24: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b"
        using A2 A22 sorry
      have A25: "x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 A22 funct_1_th_11 sorry
      have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A12 A17 A22 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A12 A22 fdiff_1_def_7 sorry
      also have "... = ((a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1)/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A13 A22 sorry
      also have "... = ((a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1)/XCMPLX-0K7 (f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using A25 rfunct_1_def_1 sorry
      also have "... = ((a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 b)*XCMPLX-0K3 (x -XCMPLX-0K6 b)))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b))"
        using A24 xcmplx_0_def_9 sorry
      also have "... = (((a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b))/XCMPLX-0K7 (x -XCMPLX-0K6 b))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b))"
        using xcmplx_1_th_78 sorry
      also have "... = (((a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 (x -XCMPLX-0K6 b)))/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
        using xcmplx_1_th_48 sorry
      also have "... = ((a -XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 a))/XCMPLX-0K7 (x -XCMPLX-0K6 b)"
        using A23 xcmplx_1_th_55 sorry
      also have "... = (a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
        using xcmplx_1_th_78 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
        using A21 A22 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))))"
      using A1 A20 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_25:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b)))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6)) implies (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & a -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
    have A4: "( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & Z c=TARSKIR1 domRELAT-1K1 f"
      using A1 A3 valued_1_def_5 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_4_th_24 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have A7: "a -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
        using A3 sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A1 A5 A6 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A6 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))*XCMPLX-0K3 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b)))"
        using A2 A4 A6 fdiff_4_th_24 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))*XCMPLX-0K3 (a -XCMPLX-0K6 b))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
        using xcmplx_1_th_74 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
        using A7 xcmplx_1_th_106 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((x -XCMPLX-0K6 a)*XCMPLX-0K3 (x -XCMPLX-0K6 b))))"
      using A1 A5 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_26:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x *XCMPLX-0K3 (x -XCMPLX-0K6 a)))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x *XCMPLX-0K3 (x -XCMPLX-0K6 a))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a & f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 is-differentiable-inFDIFF-1R1 x"
      using A2 taylor_1_th_2 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 funct_1_th_11 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using tarski_def_3 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELAT-1K1 f1"
      using xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A8: "\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 a"
         sorry
      assume "x inHIDDENR3 Z"
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 a)"
        using A3 A8 sorry
    qed "sorry"
    then have A9: "f1 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_23 sorry
    have A10: "Z c=TARSKIR1 domRELAT-1K1 f2"
      using A5 xboole_1_th_1 sorry
    then have A11: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A3 sorry
    then have A12: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A9 A11 fdiff_2_th_21 sorry
    have A13: "f2 is-differentiable-onFDIFF-1R2 Z"
      using A10 A4 fdiff_1_th_9 sorry
    have A14: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "\<two>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using prepower_th_35 sorry
      then have A15: "diffFDIFF-1K1(f2,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A2 taylor_1_th_2 sorry
      assume "x inHIDDENR3 Z"
      thus "(f2 `|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 x"
        using A13 A15 fdiff_1_def_7 sorry
    qed "sorry"
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 \<three>\<^sub>M"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A17: "f2 is-differentiable-inFDIFF-1R1 x"
        using A2 taylor_1_th_2 sorry
      have A18: "f2 .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A2 taylor_1_def_1 sorry
      also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      finally have "f2 .FUNCT-1K1 x =HIDDENR1 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      assume A19: "x inHIDDENR3 Z"
      then have A20: "x <>HIDDENR2 0NUMBERSK6"
        using A3 sorry
      have "f1 is-differentiable-inFDIFF-1R1 x & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A3 A9 A19 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 ((diffFDIFF-1K1(f1,x))*XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A17 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(f2,x))*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A9 A19 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A11 A19 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (f2 `|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A7 A19 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 f2 .FUNCT-1K1 x -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 f1 .FUNCT-1K1 x)/XCMPLX-0K7 (f2 .FUNCT-1K1 x)^2SQUARE-1K1"
        using A14 A19 sorry
      also have "... = (x  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (x -XCMPLX-0K6 a))/XCMPLX-0K7 (x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
        using A3 A19 A18 sorry
      also have "... = (x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (x -XCMPLX-0K6 a))/XCMPLX-0K7 (x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
        using newton_th_6 sorry
      also have "... = (x *XCMPLX-0K3 x -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 (x -XCMPLX-0K6 a))/XCMPLX-0K7 (x  |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
         sorry
      also have "... = (x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x))/XCMPLX-0K7 x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M)"
        using newton_th_8 sorry
      also have "... = (x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x))/XCMPLX-0K7 x  |^NEWTONK1 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
         sorry
      also have "... = (x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x))/XCMPLX-0K7 (x  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 x)"
        using newton_th_6 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 \<three>\<^sub>M"
        using A20 xcmplx_1_th_91 sorry
      finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 \<three>\<^sub>M"
         sorry
      thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 \<three>\<^sub>M"
        using A12 A19 fdiff_1_def_7 sorry
    qed "sorry"
    have A21: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A22: "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A1 funct_1_th_11 sorry
        then have A23: "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        also have "... = f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x"
          using xcmplx_0_def_9 sorry
        finally have "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x"
           sorry
        have "f1 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & f2 .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A3 A22 sorry
        thus " not (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A23 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A24: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A12 A21 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A25: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x *XCMPLX-0K3 (x -XCMPLX-0K6 a))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A26: "x inHIDDENR3 Z"
      then have A27: "x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 funct_1_th_11 sorry
      have A28: "f2 .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A2 taylor_1_def_1 sorry
      also have "... = x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      finally have "f2 .FUNCT-1K1 x =HIDDENR1 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      then have A29: "x  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
        using A3 A26 sorry
      have A30: "f1 .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 a"
        using A3 A26 sorry
      have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A12 A21 A26 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A12 A26 fdiff_1_def_7 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 \<three>\<^sub>M)/XCMPLX-0K7 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A16 A26 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 \<three>\<^sub>M)/XCMPLX-0K7 (f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5)"
        using A27 rfunct_1_def_1 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 x  |^NEWTONK1 \<two>\<^sub>M)"
        using A28 A30 xcmplx_0_def_9 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 x))/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 x  |^NEWTONK1 \<two>\<^sub>M)"
        using newton_th_6 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 x)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 x  |^NEWTONK1 \<two>\<^sub>M)"
        using xcmplx_1_th_78 sorry
      also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 ((x -XCMPLX-0K6 a)/XCMPLX-0K7 x  |^NEWTONK1 \<two>\<^sub>M))/XCMPLX-0K7 x"
        using xcmplx_1_th_48 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x -XCMPLX-0K6 a))/XCMPLX-0K7 x"
        using A29 xcmplx_1_th_55 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x *XCMPLX-0K3 (x -XCMPLX-0K6 a))"
        using xcmplx_1_th_78 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x *XCMPLX-0K3 (x -XCMPLX-0K6 a))"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x *XCMPLX-0K3 (x -XCMPLX-0K6 a))"
        using A25 A26 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 x)/XCMPLX-0K7 (x *XCMPLX-0K3 (x -XCMPLX-0K6 a))))"
      using A1 A24 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_27:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies #RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies #RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A5 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A7: "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x"
        using A2 sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A5 A8 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using taylor_1_th_22 sorry
      also have "... = ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A8 fdiff_1_def_7 sorry
      also have "... = ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M"
        using A3 A4 A8 A9 fdiff_1_th_23 sorry
      also have "... = (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A7 A8 fdiff_1_def_7 sorry
    qed "sorry"
    thus "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_28:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have A4: "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_4_th_27 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A4 fdiff_1_th_20 sorry
      also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 ((#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A5 fdiff_1_def_7 sorry
      also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A2 A3 A5 fdiff_4_th_27 sorry
      also have "... = (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally show "(((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_29:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
         sorry
    qed "sorry"
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A7: "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      have A10: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 A8 fdiff_1_th_9 sorry
      have "(((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A7 A8 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
        using A10 taylor_1_th_22 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))"
        using A4 A5 A8 A9 fdiff_1_th_23 sorry
      also have "... = (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "(((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A7 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_30:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A7: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 x"
        using A2 sorry
      have A10: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 A8 fdiff_1_th_9 sorry
      have "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A7 A8 fdiff_1_th_20 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
        using A10 taylor_1_th_22 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M)"
        using A4 A5 A8 A9 fdiff_1_th_23 sorry
      also have "... = (a +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A7 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_31:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 a"
         sorry
    qed "sorry"
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A7: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 x"
        using A2 sorry
      have A10: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 A8 fdiff_1_th_9 sorry
      have "(((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A7 A8 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
        using A10 taylor_1_th_22 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a -XCMPLX-0K6 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))"
        using A4 A5 A8 A9 fdiff_1_th_23 sorry
      also have "... = (a -XCMPLX-0K6 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "(((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A7 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_32:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x & b <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x & b <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x & b <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 b *XCMPLX-0K3 x +XCMPLX-0K2 a"
      using A2 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A7: "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "\<three>\<^sub>M *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A10: "f .FUNCT-1K1 x =XBOOLE-0R4 a +XCMPLX-0K2 b *XCMPLX-0K3 x"
        using A2 A8 sorry
      have A11: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 A8 fdiff_1_th_9 sorry
      have "(((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A7 A8 fdiff_1_th_20 sorry
      also have "... = (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
        using A11 taylor_1_th_22 sorry
      also have "... = (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = (\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 b)"
        using A4 A5 A8 A10 fdiff_1_th_23 sorry
      also have "... = ((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 b)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      also have "... = \<one>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A9 xcmplx_1_th_112 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "(((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A7 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_33:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 b *XCMPLX-0K3 x & b <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 b *XCMPLX-0K3 x & b <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 b *XCMPLX-0K3 x & b <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 b)*XCMPLX-0K3 x +XCMPLX-0K2 a"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 b *XCMPLX-0K3 x"
        using A2 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 b)*XCMPLX-0K3 x +XCMPLX-0K2 a"
         sorry
    qed "sorry"
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A7: "#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "\<three>\<^sub>M *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A10: "f .FUNCT-1K1 x =XBOOLE-0R4 a -XCMPLX-0K6 b *XCMPLX-0K3 x"
        using A2 A8 sorry
      have A11: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A6 A8 fdiff_1_th_9 sorry
      have "(((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A7 A8 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
        using A11 taylor_1_th_22 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 b))"
        using A4 A5 A8 A10 fdiff_1_th_23 sorry
      also have "... = ((\<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 b)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      also have "... = \<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
        using A9 xcmplx_1_th_112 sorry
      also have "... = (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "(((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 b))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a -XCMPLX-0K6 b *XCMPLX-0K3 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A7 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_34:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6))) implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A2 tarski_def_3 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1"
      using A4 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 A5 fdiff_4_th_17 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A4 A7 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A9: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 A2 funct_1_th_11 sorry
      then have A11: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
        using valued_1_def_1 sorry
      also have "... = a ^2SQUARE-1K1 +XCMPLX-0K2 f2 .FUNCT-1K1 x"
        using A4 A10 sorry
      also have "... = a ^2SQUARE-1K1 +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A3 taylor_1_def_1 sorry
      also have "... = a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A4 A7 A10 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using taylor_1_th_22 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 x)"
        using A2 A3 A5 A6 A10 A11 fdiff_4_th_17 sorry
      also have "... = x *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 x *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A8 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_35:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6))) implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 a ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x"
      using A4 sorry
    have A6: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_th_8 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A2 tarski_def_3 sorry
    then have A8: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 A5 fdiff_4_th_12 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A4 A8 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A9: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A4 A8 fdiff_1_th_9 sorry
      have "x inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A2 A6 A10 funct_1_th_11 sorry
      then have A12: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using valued_1_th_13 sorry
      also have "... = a ^2SQUARE-1K1 -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A4 A10 sorry
      also have "... = a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A3 taylor_1_def_1 sorry
      also have "... = a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      have "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A9 A10 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
        using A11 taylor_1_th_22 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A8 A10 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 x))"
        using A2 A3 A7 A5 A10 fdiff_4_th_12 sorry
      also have "... = x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A2 A12 sorry
      finally have "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x  |^NEWTONK1 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A9 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_36:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & (f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6))) implies \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: "f =FUNCT-1R1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =XBOOLE-0R4 0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 x"
      using A4 sorry
    have A6: "f2 =FUNCT-1R1 \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      using rfunct_1_th_21 sorry
    have A7: "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_11 sorry
    then have A8: "Z c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A2 A6 tarski_def_3 sorry
    then have A9: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A3 A6 A5 fdiff_4_th_12 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A4 A9 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A10: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A7 fdiff_1_th_9 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 x"
      using A3 A6 A8 A5 fdiff_4_th_12 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have A13: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A4 A9 fdiff_1_th_9 sorry
      have "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A2 A7 A12 funct_1_th_11 sorry
      then have A14: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
        using valued_1_def_1 sorry
      also have "... = x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
        using A4 A12 sorry
      also have "... = x +XCMPLX-0K2 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A3 taylor_1_def_1 sorry
      also have "... = x +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 x +XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M"
         sorry
      have "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A10 A12 fdiff_1_th_20 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x)))"
        using A13 taylor_1_th_22 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A2 A9 A12 fdiff_1_def_7 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
         sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A2 A11 A12 A14 sorry
      finally have "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A10 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_37:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    then have A4: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_23 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A6: "f is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_1_th_9 sorry
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A6 fdiff_2_th_13 sorry
    qed "sorry"
    then have A7: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A8: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      assume A9: "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(sinSIN-COSK17,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A8 fdiff_2_th_13 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A2 A9 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b) *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A9 fdiff_1_def_7 sorry
      also have "... = a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
        using A2 A3 A9 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
         sorry
      thus "(((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
        using A7 A9 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)))"
      using A1 A5 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_38:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 f"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
    then have A4: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_23 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A6: "f is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_1_th_9 sorry
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A6 fdiff_2_th_13 sorry
    qed "sorry"
    then have A7: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A8: "diffFDIFF-1K1(cosSIN-COSK19,f .FUNCT-1K1 x) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      have A9: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      assume A10: "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(cosSIN-COSK19,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A9 fdiff_2_th_13 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A8 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b) *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A2 A10 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b) *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A10 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
        using A2 A3 A10 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
         sorry
      thus "(((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
        using A7 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)))"
      using A1 A5 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_39:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A2: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    then have A3: "(cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_2_th_22 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A4: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_63 sorry
      assume A5: "x inHIDDENR3 Z"
      then have A6: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A1 sorry
      have "(((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A3 A5 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(cosSIN-COSK19,x))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 A4 fdiff_2_th_15 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_63 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using xcmplx_1_th_187 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      finally have "(((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A1 A2 fdiff_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_40:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    assume A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    then have A3: "(sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_2_th_22 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using A2 A1 fdiff_1_th_9 sorry
      have "(((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A3 A4 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(sinSIN-COSK17,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using A5 fdiff_2_th_15 sorry
      also have "... = -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_64 sorry
      finally have "(((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A2 A1 fdiff_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_41:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z & cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sin_cos_th_68 sorry
    assume A2: "Z c=TARSKIR1 domRELAT-1K1 ((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x)) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A2 A1 fdiff_1_th_21 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      also have "... = (cosSIN-COSK20 x)^2SQUARE-1K1 -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_def_19 sorry
      also have "... = (cosSIN-COSK20 x)^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK18 x)^2SQUARE-1K1"
        using sin_cos_def_17 sorry
      also have "... = cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x)"
        using sin_cos5_th_7 sorry
      finally show "(((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x)"
         sorry
    qed "sorry"
    thus "(sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 x)))"
      using A2 A1 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_42:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 x))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A5: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 (diffFDIFF-1K1(cosSIN-COSK19,x))/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using xcmplx_1_th_187 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK18 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_def_17 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK18 x)/XCMPLX-0K7 (cosSIN-COSK20 x)"
        using sin_cos_def_19 sorry
      also have "... = -XCMPLX-0K4 tanSIN-COS4K1 x"
        using sin_cos4_def_1 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 x"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 x"
        using A5 A6 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 x))"
      using A1 A4 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_43:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 cotSIN-COS4K2 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 cotSIN-COS4K2 x))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A5: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 cotSIN-COS4K2 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 (diffFDIFF-1K1(sinSIN-COSK17,x))/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK20 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
        using sin_cos_def_19 sorry
      also have "... = (cosSIN-COSK20 x)/XCMPLX-0K7 (sinSIN-COSK18 x)"
        using sin_cos_def_17 sorry
      also have "... = cotSIN-COS4K2 x"
        using sin_cos4_def_2 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 cotSIN-COS4K2 x"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 cotSIN-COS4K2 x"
        using A5 A6 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 cotSIN-COS4K2 x))"
      using A1 A4 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_44:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A2: "x inHIDDENR3 Z"
      have "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x"
        using valued_1_th_8 sorry
      also have "... = -XCMPLX-0K4 x"
        using A2 funct_1_th_18 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      finally have "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
      thus "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
    qed "sorry"
    assume A3: "Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
    then have "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 (cosSIN-COSK19)"
      using valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using xboole_1_th_18 sorry
    then have A5: "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_23 sorry
    have A6: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have "(((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)) +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A3 A5 A6 fdiff_1_th_21 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A5 A7 fdiff_1_def_7 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A4 A1 A7 fdiff_1_th_23 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A1 A7 sorry
      also have "... = (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally show "(((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A3 A5 A6 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_45:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    assume A2: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
    then have "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\XBOOLE-0K3 domRELAT-1K1 (sinSIN-COSK17)"
      using valued_1_def_4 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using xboole_1_th_18 sorry
    then have A4: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_23 sorry
    have A5: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)) +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A2 A4 A5 fdiff_1_th_21 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A4 A6 fdiff_1_def_7 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A3 A1 A6 fdiff_1_th_23 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A6 funct_1_th_18 sorry
      finally show "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
      using A2 A4 A5 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_46:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17) implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17) implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17)"
    then have "Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) /\\XBOOLE-0K3 domRELAT-1K1 (sinSIN-COSK17)"
      using valued_1_def_1 sorry
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using xboole_1_th_18 sorry
    then have A3: "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_44 sorry
    have A4: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) +XCMPLX-0K2 diffFDIFF-1K1(sinSIN-COSK17,x)"
        using A1 A3 A4 fdiff_1_th_18 sorry
      also have "... = (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(sinSIN-COSK17,x)"
        using A3 A5 fdiff_1_def_7 sorry
      also have "... = ((-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)+XCMPLX-0K2 diffFDIFF-1K1(sinSIN-COSK17,x)"
        using A2 A5 fdiff_4_th_44 sorry
      also have "... = ((-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)+XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      also have "... = x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally show "(((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sinSIN-COSK17)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A1 A3 A4 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_47:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
    then have "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) /\\XBOOLE-0K3 domRELAT-1K1 (cosSIN-COSK19)"
      using valued_1_def_1 sorry
    then have A2: "Z c=TARSKIR1 domRELAT-1K1 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using xboole_1_th_18 sorry
    then have A3: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_45 sorry
    have A4: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) +XCMPLX-0K2 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A1 A3 A4 fdiff_1_th_18 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A3 A5 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A2 A5 fdiff_4_th_45 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)+XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      finally show "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
      using A1 A3 A4 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_48:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 sin_cos_th_64 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    have "Z c=TARSKIR1 domRELAT-1K1 (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A1 valued_1_def_5 sorry
    then have A4: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have A6: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 sin_cos_th_64 sorry
      have "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A1 A4 A5 fdiff_1_th_20 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x)))"
        using A6 taylor_1_th_22 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      finally have "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_49:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    assume A2: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
    then have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using valued_1_def_5 sorry
    then have A3: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A4: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      assume "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A2 A3 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x)))"
        using A4 taylor_1_th_3 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos_th_64 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using prepower_th_35 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
      using A2 A3 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_50:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) /\\XBOOLE-0K3 domRELAT-1K1 (sinSIN-COSK17)"
      using A1 valued_1_def_1 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      using xboole_1_th_18 sorry
    then have A4: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_49 sorry
    have A5: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 sorry
      then have A7: "\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using xreal_1_th_50 sorry
      have "((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(sinSIN-COSK17,x) +XCMPLX-0K2 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using A1 A4 A5 A6 fdiff_1_th_18 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A6 fdiff_1_def_7 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A3 A6 fdiff_4_th_49 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A7 xcmplx_1_th_89 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 x)^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_def_17 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK20 x)*XCMPLX-0K3 (cosSIN-COSK20 x)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos4_th_5 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK20 x) |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using wsierp_1_th_1 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_def_19 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using newton_th_6 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      finally have "((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      thus "((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)))"
      using A1 A4 A5 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_51:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) /\\XBOOLE-0K3 domRELAT-1K1 (cosSIN-COSK19)"
      using A1 valued_1_th_12 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      using xboole_1_th_18 sorry
    then have A4: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_49 sorry
    have A5: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have A7: "\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 xreal_1_th_50 sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x) -XCMPLX-0K6 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A1 A4 A5 A6 fdiff_1_th_19 sorry
      also have "... = diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x) -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A4 A6 fdiff_1_def_7 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A3 A6 fdiff_4_th_49 sorry
      also have "... = (((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
        using A7 xcmplx_1_th_89 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 x)^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos_def_19 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK18 x)*XCMPLX-0K3 (sinSIN-COSK18 x)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos4_th_4 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK18 x) |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
        using wsierp_1_th_1 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos_def_17 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
        using newton_th_6 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)))"
      using A1 A4 A5 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_52:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    have "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) /\\XBOOLE-0K3 domRELAT-1K1 (sinSIN-COSK17)"
      using A1 valued_1_th_12 sorry
    then have A3: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      using xboole_1_th_18 sorry
    then have A4: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_49 sorry
    have A5: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A2 sorry
      then have A7: "(sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
        using xreal_1_th_50 sorry
      have "((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(sinSIN-COSK17,x) -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using A1 A4 A5 A6 fdiff_1_th_19 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A6 fdiff_1_def_7 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A3 A6 fdiff_4_th_49 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A7 xcmplx_1_th_89 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 x)^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_def_17 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK20 x)*XCMPLX-0K3 (cosSIN-COSK20 x)))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos4_th_5 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK20 x) |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using wsierp_1_th_1 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_def_19 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using newton_th_6 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      finally have "((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      thus "((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)))"
      using A1 A4 A5 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_53:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6 & (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) /\\XBOOLE-0K3 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using A1 valued_1_th_12 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using xboole_1_th_18 sorry
    have A5: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      using A3 xboole_1_th_18 sorry
    then have A6: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_49 sorry
    have A7: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sorry
    have A8: "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using A4 A7 fdiff_1_th_20 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have A10: "(cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
        using A2 xreal_1_th_50 sorry
      have "(((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x) -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using A1 A6 A8 A9 fdiff_1_th_19 sorry
      also have "... = ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using A8 A9 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x)) -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using A4 A7 A9 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x) -XCMPLX-0K6 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using sin_cos_th_63 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A9 fdiff_1_def_7 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A5 A9 fdiff_4_th_49 sorry
      also have "... = (((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
        using A10 xcmplx_1_th_89 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 x)^2SQUARE-1K1))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos_def_19 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK18 x)*XCMPLX-0K3 (sinSIN-COSK18 x)))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos4_th_4 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK18 x) |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
        using wsierp_1_th_1 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos_def_17 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
        using newton_th_6 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      finally have "(((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      thus "(((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 x  |^NEWTONK1 \<three>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)))"
      using A1 A6 A8 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_54:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & n >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & n >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      and A2: "n >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    have "Z c=TARSKIR1 domRELAT-1K1 (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A1 valued_1_def_5 sorry
    then have A4: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A5: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_64 sorry
      assume "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A1 A4 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x)))"
        using A5 taylor_1_th_3 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using sin_cos_th_64 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 n)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      also have "... = ((n \<inverse>XCMPLX-0K5 *XCMPLX-0K3 n)*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using xcmplx_1_th_215 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A2 xcmplx_0_def_7 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_55:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 x -XCMPLX-0K6 \<one>\<^sub>M"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A4: "\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      assume "x inHIDDENR3 Z"
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A2 A4 sorry
    qed "sorry"
    have "Z c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 (exp-RSIN-COSK23)"
      using A1 valued_1_def_4 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A7: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A1 A6 A7 fdiff_1_th_21 sorry
      also have "... = (x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A2 A8 sorry
      also have "... = (x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using taylor_1_th_16 sorry
      also have "... = (x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = (x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M"
        using A5 A3 A8 fdiff_1_th_23 sorry
      also have "... = x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      finally show "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))"
      using A1 A6 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_56:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using A1 funct_1_th_11 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))\<^esub> (domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_1 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A7: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A8: "exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 A6 fdiff_1_th_18 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A10: "x inHIDDENR3 Z"
        then have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x"
          using A4 valued_1_def_1 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
          using A2 A10 sorry
        finally have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        thus " not (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 xreal_1_th_34 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
       sorry
    then have A11: "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A7 A8 fdiff_2_th_21 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A13: "x inHIDDENR3 Z"
        then have "((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,x) +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
          using A4 A6 A7 fdiff_1_th_18 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(f,x)"
          using sin_cos_th_65 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A6 A13 fdiff_1_def_7 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 0NUMBERSK6"
          using A5 A3 A13 fdiff_1_th_23 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        finally show "((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A14: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A15: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
        using sin_cos_th_65 sorry
      assume A16: "x inHIDDENR3 Z"
      then have A17: "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x"
        using A4 valued_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
        using A2 A16 sorry
      finally have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      have "exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A8 A9 A16 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 ((diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)^2SQUARE-1K1"
        using A15 fdiff_2_th_14 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_65 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M) -XCMPLX-0K6 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1"
        using A8 A16 A17 fdiff_1_def_7 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1"
        using A12 A16 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1"
         sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1"
         sorry
      thus "(((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1"
        using A11 A16 fdiff_1_def_7 sorry
    qed "sorry"
    have A18: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A19: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 sorry
        assume A20: "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
          using A1 funct_1_th_11 sorry
        then have A21: "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)"
          using xcmplx_1_th_215 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
          using xcmplx_1_th_99 sorry
        finally have "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
           sorry
        have "(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A9 A20 sorry
        thus " not ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A21 A19 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A22: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A11 A18 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A23: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A24: "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
        using A1 funct_1_th_11 sorry
      then have A25: "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using rfunct_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
        using xcmplx_1_th_99 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x)"
        using A4 A24 valued_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
        using A2 A24 sorry
      finally have "((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      then have A26: "(exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
        using A18 A24 sorry
      have "(exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A11 A18 A24 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)),x) =HIDDENR1 (diffFDIFF-1K1((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x))/XCMPLX-0K7 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x"
        using A11 A24 fdiff_1_def_7 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))"
        using A14 A24 A25 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))"
        using xcmplx_1_th_78 sorry
      also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
        using xcmplx_1_th_48 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
        using A26 xcmplx_1_th_60 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)"
        using A23 A24 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 \<one>\<^sub>M)))"
      using A1 A22 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_4_th_57:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELAT-1K1 ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M & (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 x +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using A1 funct_1_th_11 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
      using tarski_def_3 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (exp-RSIN-COSK23))\<^esub> (domRELAT-1K1 (exp-RSIN-COSK23) \\SUBSET-1K6 (exp-RSIN-COSK23)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A4: "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    then have "Z c=TARSKIR1 domRELAT-1K1 (exp-RSIN-COSK23) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_th_12 sorry
    then have A5: "Z c=TARSKIR1 domRELAT-1K1 f"
      using xboole_1_th_18 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A7: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    then have A8: "exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A4 A6 fdiff_1_th_19 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using sin_cos_th_54 sorry
    then have A9: "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A7 A8 fdiff_2_th_21 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A11: "x inHIDDENR3 Z"
        then have "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,x) -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
          using A4 A6 A7 fdiff_1_th_19 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(f,x)"
          using sin_cos_th_65 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
          using A6 A11 fdiff_1_def_7 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 0NUMBERSK6"
          using A5 A3 A11 fdiff_1_th_23 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        finally show "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A13: "(exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using sin_cos_th_54 sorry
      assume A14: "x inHIDDENR3 Z"
      then have A15: "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x"
        using A4 valued_1_th_13 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
        using A2 A14 sorry
      finally have "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 A14 fdiff_1_th_9 sin_cos_th_65 sorry
      then have "diffFDIFF-1K1((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 ((diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A13 fdiff_2_th_14 sorry
      also have "... = (((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A8 A14 fdiff_1_def_7 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A10 A14 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A15 sin_cos_th_65 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using xcmplx_1_th_78 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A13 xcmplx_1_th_60 sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      thus "(((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A9 A14 fdiff_1_def_7 sorry
    qed "sorry"
    have A16: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A17: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 sorry
        assume A18: "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
          using A1 funct_1_th_11 sorry
        then have A19: "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        also have "... = (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
          using xcmplx_1_th_215 sorry
        also have "... = (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
          using xcmplx_1_th_99 sorry
        finally have "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
           sorry
        have "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A2 A18 sorry
        thus " not ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A19 A17 xreal_1_th_139 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A20: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A16 fdiff_1_th_9 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A21: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A22: "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_54 sorry
      assume A23: "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELAT-1K1 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
        using A1 funct_1_th_11 sorry
      then have A24: "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using rfunct_1_def_1 sorry
      also have "... = (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using xcmplx_1_th_99 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A4 A23 valued_1_th_13 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A2 A23 sorry
      finally have "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      have "(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x & ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A9 A16 A23 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)),x) =HIDDENR1 (diffFDIFF-1K1((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x))/XCMPLX-0K7 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)).FUNCT-1K1 x"
        using A9 A23 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A12 A23 A24 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
        using A22 xcmplx_1_th_55 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)"
        using A21 A23 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)))`|FDIFF-1K2 Z).FUNCT-1K1 x =XBOOLE-0R4 \<one>\<^sub>M /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 \<one>\<^sub>M)))"
      using A1 A20 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
