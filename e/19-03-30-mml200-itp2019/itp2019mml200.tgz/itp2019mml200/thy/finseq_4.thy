theory finseq_4
  imports finseq_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve f for "FunctionFUNCT-1M1"
reserve p, q for "FinSequenceFINSEQ-1M1"
reserve A, B, C for "setHIDDENM2"
reserve x, x1, x2, y, z for "objectHIDDENM1"
reserve k, l, m, n for "NatNAT-1M1"
reserve a for "NatNAT-1M1"
mdef finseq_4_def_1 (" _ is-one-to-one-atFINSEQ-4R1  _ " [50,50]50 ) where
  mlet "f be FunctionFUNCT-1M1", "x be objectHIDDENM1"
"pred f is-one-to-one-atFINSEQ-4R1 x means
  f \<inverse>FUNCT-1K6 (ImRELAT-1K12(f,x)) =XBOOLE-0R4 {TARSKIK1 x}"..

mtheorem finseq_4_th_1:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "f is-one-to-one-atFINSEQ-4R1 x"
    then have "f \<inverse>FUNCT-1K6 (ImRELAT-1K12(f,x)) =XBOOLE-0R4 {TARSKIK1 x}"
       sorry
    then have "x inHIDDENR3 f \<inverse>FUNCT-1K6 (ImRELAT-1K12(f,x))"
      using tarski_def_1 sorry
    thus "x inHIDDENR3 domRELAT-1K1 f"
      using funct_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_2:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f is-one-to-one-atFINSEQ-4R1 x iff x inHIDDENR3 domRELAT-1K1 f & f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds (f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f & f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}) & (x inHIDDENR3 domRELAT-1K1 f & f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x} implies f is-one-to-one-atFINSEQ-4R1 x)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f & f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}"
    proof(rule impI,rule conjMI)
      assume A1: "f is-one-to-one-atFINSEQ-4R1 x"
      thus A2: "x inHIDDENR3 domRELAT-1K1 f"
        using finseq_4_th_1 sorry
      have "f \<inverse>FUNCT-1K6 (ImRELAT-1K12(f,x)) =XBOOLE-0R4 {TARSKIK1 x}"
        using A1 sorry
      thus "f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}"
        using A2 funct_1_th_59 sorry
    qed
    assume Cut74: "x inHIDDENR3 domRELAT-1K1 f & f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}"
    have "f \<inverse>FUNCT-1K6 (ImRELAT-1K12(f,x)) =XBOOLE-0R4 {TARSKIK1 x}"
    proof-
      show "f \<inverse>FUNCT-1K6 (ImRELAT-1K12(f,x)) =XBOOLE-0R4 {TARSKIK1 x}"
        using funct_1_th_59 Cut74 sorry
    qed
    thus "f is-one-to-one-atFINSEQ-4R1 x"
      using finseq_4_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_3:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f is-one-to-one-atFINSEQ-4R1 x iff x inHIDDENR3 domRELAT-1K1 f & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 z implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 z)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds (f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 z implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 z)) & (x inHIDDENR3 domRELAT-1K1 f & (( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 z implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 z) &  not f is-one-to-one-atFINSEQ-4R1 x) implies  not  True )"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 z implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 z)"
    proof-
      have "f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & (x <>HIDDENR2 z & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 z) implies  not  True )"
      proof(rule impI,rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
        assume A1: "f is-one-to-one-atFINSEQ-4R1 x"
        thus "x inHIDDENR3 domRELAT-1K1 f"
          using finseq_4_th_1 sorry
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A2: "z inHIDDENR3 domRELAT-1K1 f"
          and A3: "x <>HIDDENR2 z"
          and A4: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 z"
        have "f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 f .FUNCT-1K1 x }"
          using tarski_def_1 sorry
        then have "z inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
          using A2 A4 funct_1_def_7 sorry
        then have "z inHIDDENR3 {TARSKIK1 x}"
          using A1 finseq_4_th_2 sorry
        thus " not  True "
          using A3 tarski_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A5: "x inHIDDENR3 domRELAT-1K1 f"
      and A6: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 z implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 z"
      and A7: " not f is-one-to-one-atFINSEQ-4R1 x"
    have "f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } <>HIDDENR2 {TARSKIK1 x}"
      using A5 A7 finseq_4_th_2 sorry
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A8: "y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } &  not y inHIDDENR3 {TARSKIK1 x} or y inHIDDENR3 {TARSKIK1 x} &  not y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
      using tarski_th_2 sorry
    have "f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 f .FUNCT-1K1 x }"
      using tarski_def_1 sorry
    then have A9: "x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
      using A5 funct_1_def_7 sorry
    have " not  True "
    proof-
      show " not  True "
      proof-
        have cases: "y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } &  not y inHIDDENR3 {TARSKIK1 x} or  not y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } & y inHIDDENR3 {TARSKIK1 x}"
          using A8 sorry
        have case1: "y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } &  not y inHIDDENR3 {TARSKIK1 x} implies  not  True "
        proof(rule impI)
          assume A10: "y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } &  not y inHIDDENR3 {TARSKIK1 x}"
          then have "f .FUNCT-1K1 y inTARSKIR2 {TARSKIK1 f .FUNCT-1K1 x }"
            using funct_1_def_7 sorry
          then have A11: "f .FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 x"
            using tarski_def_1 sorry
          have "y inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 y"
            using A10 funct_1_def_7 tarski_def_1 sorry
          thus " not  True "
            using A6 A11 sorry
        qed
        have case2: " not y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } & y inHIDDENR3 {TARSKIK1 x} implies  not  True "
        proof(rule impI)
          assume " not y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } & y inHIDDENR3 {TARSKIK1 x}"
          thus " not  True "
            using A9 tarski_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not  True "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_4:
" for f be FunctionFUNCT-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x) iff f be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x) implies f be one-to-oneFUNCT-1V2) & (f be one-to-oneFUNCT-1V2 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x))"
  proof(rule ballI,rule conjMI,rule impI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x) implies f be one-to-oneFUNCT-1V2"
    proof(rule impI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x"
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A2: "x1 inHIDDENR3 domRELAT-1K1 f"
          and A3: "x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
        have "f is-one-to-one-atFINSEQ-4R1 x1"
          using A1 A2 sorry
        thus "x1 =HIDDENR1 x2"
          using A3 finseq_4_th_3 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    assume A4: "f be one-to-oneFUNCT-1V2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A5: "x inHIDDENR3 domRELAT-1K1 f"
    then have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 z implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 z"
      using A4 sorry
    thus "f is-one-to-one-atFINSEQ-4R1 x"
      using A5 finseq_4_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_4_def_2 (" _ just-once-valuesFINSEQ-4R2  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "y be objectHIDDENM1"
"pred R just-once-valuesFINSEQ-4R2 y means
  cardCARD-1K1 (CoimRELAT-1K13(R,y)) =XBOOLE-0R4 \<one>\<^sub>M"..

mtheorem finseq_4_th_5:
" for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y implies y inHIDDENR3 rngFUNCT-1K2 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y implies y inHIDDENR3 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "f just-once-valuesFINSEQ-4R2 y"
    then have "cardCARD-1K1 (CoimRELAT-1K13(f,y)) =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
    then have "rngFUNCT-1K2 f meetsXBOOLE-0R5 {TARSKIK1 y}"
      using card_1_th_27 relat_1_th_138 sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 rngFUNCT-1K2 f /\\XBOOLE-0K3 {TARSKIK1 y}"
      using xboole_0_th_4 sorry
    have "x inHIDDENR3 {TARSKIK1 y}"
      using A1 xboole_0_def_4 sorry
    then have "y =HIDDENR1 x"
      using tarski_def_1 sorry
    thus "y inHIDDENR3 rngFUNCT-1K2 f"
      using A1 xboole_0_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_6:
" for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y iff ( ex x be objectHIDDENM1 st {TARSKIK1 x} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y})"
  using card_2_th_42 sorry

mtheorem finseq_4_th_7:
" for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y iff ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y))"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds (f just-once-valuesFINSEQ-4R2 y implies ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y))) & (( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y)) implies f just-once-valuesFINSEQ-4R2 y)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix y assume [ty]: "y be objectHIDDENM1"
    show "f just-once-valuesFINSEQ-4R2 y implies ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y))"
    proof-
      have "f just-once-valuesFINSEQ-4R2 y implies ( ex tVar1 be objectHIDDENM1 st (tVar1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 tVar1) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & (z <>HIDDENR2 tVar1 & f .FUNCT-1K1 z =HIDDENR1 y) implies  not  True ))"
      proof(rule impI)
        assume A1: "f just-once-valuesFINSEQ-4R2 y"
        then have A2: "cardCARD-1K1 (CoimRELAT-1K13(f,y)) =XBOOLE-0R4 \<one>\<^sub>M"
           sorry
        have "y inHIDDENR3 rngFUNCT-1K2 f"
          using A1 finseq_4_th_5 sorry
        then obtain x1 where
          [ty]:"x1 be objectHIDDENM1" and 
          A3: "x1 inHIDDENR3 domRELAT-1K1 f"and A4: "f .FUNCT-1K1 x1 =HIDDENR1 y"
          using funct_1_def_3 sorry
        have "f .FUNCT-1K1 x1 inTARSKIR2 {TARSKIK1 y}"
          using A4 tarski_def_1 sorry
        then have A5: "x1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
          using A3 funct_1_def_7 sorry
        show " ex tVar1 be objectHIDDENM1 st (tVar1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 tVar1) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & (z <>HIDDENR2 tVar1 & f .FUNCT-1K1 z =HIDDENR1 y) implies  not  True )"
        proof(rule bexI[of _ "x1"],rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
          show "x1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x1"
            using A3 A4 sorry
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A6: "z inHIDDENR3 domRELAT-1K1 f"
            and A7: "z <>HIDDENR2 x1"
            and A8: "f .FUNCT-1K1 z =HIDDENR1 y"
          have A9: "f \<inverse>FUNCT-1K6 {TARSKIK1 y} be finiteFINSET-1V1"
            using A2 sorry
          have "f .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 y}"
            using A8 tarski_def_1 sorry
          then have "z inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
            using A6 funct_1_def_7 sorry
          then have "{TARSKIK2 z,x1 } c=TARSKIR1 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
            using A5 zfmisc_1_th_32 sorry
          then have "cardCARD-1K4 {TARSKIK2 z,x1 } <=XXREAL-0R1 \<one>\<^sub>M"
            using A9 A2 nat_1_th_43 sorry
          then have "\<two>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M"
            using A7 card_2_th_57 sorry
          thus " not  True "
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y)"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A10: "x inHIDDENR3 domRELAT-1K1 f"and A11: "y =HIDDENR1 f .FUNCT-1K1 x"and A12: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y"
       sorry
    have A13: "{TARSKIK1 x} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
    proof-
      have "{TARSKIK1 x} c=TARSKIR1 f \<inverse>FUNCT-1K6 {TARSKIK1 y} & f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
      proof(rule conjMI)
        show "{TARSKIK1 x} c=TARSKIR1 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
        proof-
          have " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 {TARSKIK1 x} implies x1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
          proof(rule ballI,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            assume "x1 inHIDDENR3 {TARSKIK1 x}"
            then have A14: "x1 =HIDDENR1 x"
              using tarski_def_1 sorry
            have "f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 y}"
              using A11 tarski_def_1 sorry
            thus "x1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
              using A10 A14 funct_1_def_7 sorry
          qed "sorry"
          thus "{TARSKIK1 x} c=TARSKIR1 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
            using tarski_def_3 sorry
        qed
        have " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y} implies x1 inHIDDENR3 {TARSKIK1 x}"
        proof(rule ballI,rule impI)
          fix x1 assume [ty]: "x1 be objectHIDDENM1"
          assume A15: "x1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
          then have "f .FUNCT-1K1 x1 inTARSKIR2 {TARSKIK1 y}"
            using funct_1_def_7 sorry
          then have A16: "f .FUNCT-1K1 x1 =HIDDENR1 y"
            using tarski_def_1 sorry
          have "x1 inHIDDENR3 domRELAT-1K1 f"
            using A15 funct_1_def_7 sorry
          then have "x1 =HIDDENR1 x"
            using A12 A16 sorry
          thus "x1 inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
        qed "sorry"
        thus "f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
          using tarski_def_3 sorry
      qed
      thus "{TARSKIK1 x} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
        using xboole_0_def_10 sorry
    qed
    have "cardCARD-1K1 (CoimRELAT-1K13(f,y)) =XBOOLE-0R4 \<one>\<^sub>M"
      using A13 card_1_th_30 sorry
    thus "f just-once-valuesFINSEQ-4R2 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_8:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 iff ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies f just-once-valuesFINSEQ-4R2 y)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be one-to-oneFUNCT-1V2 implies ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies f just-once-valuesFINSEQ-4R2 y)) & (( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies f just-once-valuesFINSEQ-4R2 y) implies f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be one-to-oneFUNCT-1V2 implies ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies f just-once-valuesFINSEQ-4R2 y)"
    proof(rule impI,rule ballI,rule impI)
      assume A1: "f be one-to-oneFUNCT-1V2"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 f"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A2: "x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y"
        using A1 A2 sorry
      thus "f just-once-valuesFINSEQ-4R2 y"
        using A2 finseq_4_th_7 sorry
    qed "sorry"
    assume A3: " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies f just-once-valuesFINSEQ-4R2 y"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & (y inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y) implies x =HIDDENR1 y"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A4: "x inHIDDENR3 domRELAT-1K1 f"
        and A5: "y inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
      have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
        using A4 funct_1_def_3 sorry
      then have "f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 x"
        using A3 sorry
      then obtain x1 where
        [ty]:"x1 be objectHIDDENM1" and 
        A6: "{TARSKIK1 x1} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
        using finseq_4_th_6 sorry
      have A7: "f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 f .FUNCT-1K1 x }"
        using tarski_def_1 sorry
      then have A8: "y inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
        using A5 funct_1_def_7 sorry
      have "x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
        using A4 A7 funct_1_def_7 sorry
      then have "x =HIDDENR1 x1"
        using A6 tarski_def_1 sorry
      thus "x =HIDDENR1 y"
        using A6 A8 tarski_def_1 sorry
    qed "sorry"
    thus "f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_9:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f is-one-to-one-atFINSEQ-4R1 x iff x inHIDDENR3 domRELAT-1K1 f & f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 x"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds (f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f & f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELAT-1K1 f & f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 x implies f is-one-to-one-atFINSEQ-4R1 x)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "f is-one-to-one-atFINSEQ-4R1 x implies x inHIDDENR3 domRELAT-1K1 f & f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 x"
    proof(rule impI,rule conjMI)
      assume A1: "f is-one-to-one-atFINSEQ-4R1 x"
      thus "x inHIDDENR3 domRELAT-1K1 f"
        using finseq_4_th_1 sorry
      have "{TARSKIK1 x} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
        using A1 finseq_4_th_2 sorry
      thus "f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 x"
        using finseq_4_th_6 sorry
    qed
    assume A2: "x inHIDDENR3 domRELAT-1K1 f"
      and A3: "f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 x"
    obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A4: "f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 z}"
      using A3 finseq_4_th_6 sorry
    have "f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 f .FUNCT-1K1 x }"
      using tarski_def_1 sorry
    then have "x inHIDDENR3 {TARSKIK1 z}"
      using A2 A4 funct_1_def_7 sorry
    then have "x =HIDDENR1 z"
      using tarski_def_1 sorry
    thus "f is-one-to-one-atFINSEQ-4R1 x"
      using A2 A4 finseq_4_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_4_def_3 (" _ <-FINSEQ-4K1  _ " [200,200]200 ) where
  mlet "f be FunctionFUNCT-1M1", "y be objectHIDDENM1"
"assume f just-once-valuesFINSEQ-4R2 y func f <-FINSEQ-4K1 y \<rightarrow> setHIDDENM2 means
  \<lambda>it. it inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 it =HIDDENR1 y"
proof-
  (*existence*)
    show "f just-once-valuesFINSEQ-4R2 y implies ( ex it be setHIDDENM2 st it inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 it =HIDDENR1 y)"
    proof(rule impI)
      assume Assume: "f just-once-valuesFINSEQ-4R2 y"
      have A1: "f just-once-valuesFINSEQ-4R2 y"
        using Assume sorry
      show " ex it be setHIDDENM2 st it inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 it =HIDDENR1 y"
      proof-
        have " ex tVar2 be setHIDDENM2 st (tVar2 be setHIDDENM2 & tVar2 inTARSKIR2 domRELAT-1K1 f) & f .FUNCT-1K1 tVar2 =HIDDENR1 y"
        proof-
          have "y inHIDDENR3 rngFUNCT-1K2 f"
            using A1 finseq_4_th_5 sorry
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =HIDDENR1 y"
            using funct_1_def_3 sorry
          show " ex tVar2 be setHIDDENM2 st (tVar2 be setHIDDENM2 & tVar2 inTARSKIR2 domRELAT-1K1 f) & f .FUNCT-1K1 tVar2 =HIDDENR1 y"
          proof(rule bexI[of _ "x"])
            show "(x be setHIDDENM2 & x inTARSKIR2 domRELAT-1K1 f) & f .FUNCT-1K1 x =HIDDENR1 y"
              using A2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "f just-once-valuesFINSEQ-4R2 y implies ( for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds (it1 inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 it1 =HIDDENR1 y) & (it2 inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 it2 =HIDDENR1 y) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f just-once-valuesFINSEQ-4R2 y"
      have A1: "f just-once-valuesFINSEQ-4R2 y"
        using Assume sorry
      show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds (it1 inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 it1 =HIDDENR1 y) & (it2 inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 it2 =HIDDENR1 y) implies it1 =HIDDENR1 it2"
      proof-
        have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds (x1 inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 x1 =HIDDENR1 y) & (x2 inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 x2 =HIDDENR1 y) implies x1 =HIDDENR1 x2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x1 assume [ty]: "x1 be setHIDDENM2"
          fix x2 assume [ty]: "x2 be setHIDDENM2"
          assume A3: "x1 inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 x1 =HIDDENR1 y"
            and A4: "x2 inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 x2 =HIDDENR1 y"
          obtain x where
            [ty]:"x be objectHIDDENM1" and 
            "x inHIDDENR3 domRELAT-1K1 f"and "f .FUNCT-1K1 x =HIDDENR1 y"and A5: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f & z <>HIDDENR2 x implies f .FUNCT-1K1 z <>HIDDENR2 y"
            using A1 finseq_4_th_7 sorry
          have "x =HIDDENR1 x1"
            using A3 A5 sorry
          thus "x1 =HIDDENR1 x2"
            using A4 A5 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem finseq_4_th_10:
" for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y implies ImRELAT-1K12(f,f <-FINSEQ-4K1 y) =XBOOLE-0R4 {TARSKIK1 y}"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y implies ImRELAT-1K12(f,f <-FINSEQ-4K1 y) =HIDDENR1 {TARSKIK1 y}"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "f just-once-valuesFINSEQ-4R2 y"
    then have "f <-FINSEQ-4K1 y inTARSKIR2 domRELAT-1K1 f"
      using finseq_4_def_3 sorry
    then have "ImRELAT-1K12(f,f <-FINSEQ-4K1 y) =HIDDENR1 {TARSKIK1 f .FUNCT-1K1 (f <-FINSEQ-4K1 y) }"
      using funct_1_th_59 sorry
    also have "... = {TARSKIK1 y}"
      using A1 finseq_4_def_3 sorry
    finally show "ImRELAT-1K12(f,f <-FINSEQ-4K1 y) =HIDDENR1 {TARSKIK1 y}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_11:
" for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y implies f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 f <-FINSEQ-4K1 y }"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y implies f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 f <-FINSEQ-4K1 y }"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "f just-once-valuesFINSEQ-4R2 y"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "{TARSKIK1 x} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
      using finseq_4_th_6 sorry
    have A3: "x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
      using A2 zfmisc_1_th_31 sorry
    then have "f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 y}"
      using funct_1_def_7 sorry
    then have A4: "f .FUNCT-1K1 x =HIDDENR1 y"
      using tarski_def_1 sorry
    have "x inHIDDENR3 domRELAT-1K1 f"
      using A3 funct_1_def_7 sorry
    thus "f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 f <-FINSEQ-4K1 y }"
      using A1 A2 A4 finseq_4_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_12:
" for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f be one-to-oneFUNCT-1V2 & y inHIDDENR3 rngFUNCT-1K2 f implies f \<inverse>FUNCT-1K4 .FUNCT-1K1 y =XBOOLE-0R4 f <-FINSEQ-4K1 y"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f be one-to-oneFUNCT-1V2 & y inHIDDENR3 rngFUNCT-1K2 f implies f \<inverse>FUNCT-1K4 .FUNCT-1K1 y =XBOOLE-0R4 f <-FINSEQ-4K1 y"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "y inHIDDENR3 rngFUNCT-1K2 f"
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A3: "x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =HIDDENR1 y"
      using A2 funct_1_def_3 sorry
    have "f just-once-valuesFINSEQ-4R2 y"
      using A1 A2 finseq_4_th_8 sorry
    then have "x =HIDDENR1 f <-FINSEQ-4K1 y"
      using A3 finseq_4_def_3 sorry
    thus "f \<inverse>FUNCT-1K4 .FUNCT-1K1 y =XBOOLE-0R4 f <-FINSEQ-4K1 y"
      using A1 A3 funct_1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_13:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f is-one-to-one-atFINSEQ-4R1 x implies f <-FINSEQ-4K1 (f .FUNCT-1K1 x) =HIDDENR1 x"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f is-one-to-one-atFINSEQ-4R1 x implies f <-FINSEQ-4K1 (f .FUNCT-1K1 x) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "f is-one-to-one-atFINSEQ-4R1 x"
    then have "x inHIDDENR3 domRELAT-1K1 f & f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 x"
      using finseq_4_th_9 sorry
    thus "f <-FINSEQ-4K1 (f .FUNCT-1K1 x) =HIDDENR1 x"
      using finseq_4_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_14:
" for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y implies f is-one-to-one-atFINSEQ-4R1 f <-FINSEQ-4K1 y"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for y be objectHIDDENM1 holds f just-once-valuesFINSEQ-4R2 y implies f is-one-to-one-atFINSEQ-4R1 f <-FINSEQ-4K1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "f just-once-valuesFINSEQ-4R2 y"
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 f <-FINSEQ-4K1 y implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 (f <-FINSEQ-4K1 y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 f <-FINSEQ-4K1 y"
      then have "f .FUNCT-1K1 x <>HIDDENR2 y"
        using A1 finseq_4_def_3 sorry
      thus "f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 (f <-FINSEQ-4K1 y)"
        using A1 finseq_4_def_3 sorry
    qed "sorry"
    have "f <-FINSEQ-4K1 y inTARSKIR2 domRELAT-1K1 f"
      using A1 finseq_4_def_3 sorry
    thus "f is-one-to-one-atFINSEQ-4R1 f <-FINSEQ-4K1 y"
      using A2 finseq_4_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve d, d1, d2, d3 for "ElementSUBSET-1M1-of D"
syntax FINSEQ_4K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<*FINSEQ-4K2\<^bsub>'( _ ')\<^esub> _ , _ *>" [0,0,0]164)
translations "<*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *>" \<rightharpoonup> "<*FINSEQ-1K11 d1,d2 *>"

mtheorem finseq_4_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d1 be ElementSUBSET-1M1-of D", "d2 be ElementSUBSET-1M1-of D"
"cluster <*FINSEQ-1K11 d1,d2 *> as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "<*FINSEQ-1K11 d1,d2 *> be FinSequenceFINSEQ-1M3-of D"
    using finseq_2_th_13 sorry
qed "sorry"

syntax FINSEQ_4K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<*FINSEQ-4K3\<^bsub>'( _ ')\<^esub> _ , _ , _ *>" [0,0,0,0]164)
translations "<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>" \<rightharpoonup> "<*FINSEQ-1K12 d1,d2,d3 *>"

mtheorem finseq_4_add_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d1 be ElementSUBSET-1M1-of D", "d2 be ElementSUBSET-1M1-of D", "d3 be ElementSUBSET-1M1-of D"
"cluster <*FINSEQ-1K12 d1,d2,d3 *> as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "<*FINSEQ-1K12 d1,d2,d3 *> be FinSequenceFINSEQ-1M3-of D"
    using finseq_2_th_14 sorry
qed "sorry"

mtheorem finseq_4_th_15:
" for i be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for P be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 P implies P /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 P .FUNCT-1K1 i"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  fix D assume [ty]: "D be setHIDDENM2"
  fix P assume [ty]: "P be FinSequenceFINSEQ-1M3-of D"
  assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 P"
  then have "i inTARSKIR2 domFINSEQ-1K5 P"
    using finseq_3_th_25 sorry
  thus "P /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 P .FUNCT-1K1 i"
    using partfun1_def_6 sorry
qed "sorry"

mtheorem finseq_4_th_16:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    have A1: "\<one>\<^sub>M inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
      using finseq_1_th_2 sorry
    have "domFINSEQ-1K5 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>) =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M} & (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 d"
      using finseq_1_th_2 finseq_1_def_8 sorry
    thus "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d"
      using A1 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_17:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds (<*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d1 & (<*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 d2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds (<*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d1 & (<*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 d2"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    let ?s = "<*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *>"
    have A1: "?s .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 d2 & \<one>\<^sub>M inTARSKIR2 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
      using finseq_1_th_2 finseq_1_th_44 sorry
    have A2: "\<two>\<^sub>M inTARSKIR2 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M }"
      using finseq_1_th_2 sorry
    have "domFINSEQ-1K5 ?s =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,\<two>\<^sub>M } & ?s .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 d1"
      using finseq_1_th_2 finseq_1_th_44 finseq_1_th_89 sorry
    thus "(<*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d1 & (<*FINSEQ-4K2\<^bsub>(D)\<^esub> d1,d2 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 d2"
      using A1 A2 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_18:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds ((<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d1 & (<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 d2) & (<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 d3"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds ((<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d1 & (<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 d2) & (<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 d3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix d3 assume [ty]: "d3 be ElementSUBSET-1M1-of D"
    let ?s = "<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>"
    have A1: "?s .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 d2 & ?s .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 d3"
      using finseq_1_th_45 sorry
    have A2: "\<one>\<^sub>M inTARSKIR2 {ENUMSET1K1 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M } & \<two>\<^sub>M inTARSKIR2 {ENUMSET1K1 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
      using finseq_3_th_1 sorry
    have A3: "\<three>\<^sub>M inTARSKIR2 {ENUMSET1K1 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
      using finseq_3_th_1 sorry
    have "domFINSEQ-1K5 ?s =XBOOLE-0R4 {ENUMSET1K1 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M } & ?s .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 d1"
      using finseq_1_th_45 finseq_1_th_89 finseq_3_th_1 sorry
    thus "((<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 d1 & (<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 d2) & (<*FINSEQ-4K3\<^bsub>(D)\<^esub> d1,d2,d3 *>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 d3"
      using A1 A2 A3 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_4_def_4 (" _ ..FINSEQ-4K4  _ " [200,200]200 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "x be objectHIDDENM1"
"func x ..FINSEQ-4K4 p \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}) .FUNCT-1K1 \<one>\<^sub>M"
proof-
  (*coherence*)
    show "SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}) .FUNCT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
    proof-
      let ?q = "SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})"
      show "SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}) .FUNCT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
      proof-
        have cases: " not \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?q or \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?q"
           sorry
        have case1: " not \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})) implies SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}) .FUNCT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
        proof(rule impI)
          assume " not \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?q"
          then have "?q .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
            using funct_1_def_2 sorry
          thus "SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}) .FUNCT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
             sorry
        qed
        have case2: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})) implies SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}) .FUNCT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
        proof(rule impI)
          assume A1: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?q"
          have A2: "rngFUNCT-1K2 ?q c=TARSKIR1 NATNUMBERSK1"
            using finseq_1_def_4 sorry
          have "?q .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 ?q"
            using A1 funct_1_def_3 sorry
          thus "SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}) .FUNCT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
qed "sorry"

mtheorem finseq_4_th_19:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?q = "SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})"
    have A1: "p \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 domFINSEQ-1K5 p & domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 relat_1_th_132 sorry
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "p \<inverse>FUNCT-1K6 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
      using funct_1_th_72 sorry
    then have "rngFUNCT-1K2 ?q <>HIDDENR2 {}XBOOLE-0K1"
      using A1 finseq_1_def_13 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?q"
      using finseq_3_th_32 sorry
    then have A2: "?q .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 ?q"
      using funct_1_def_3 sorry
    have "rngFUNCT-1K2 ?q =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      using A1 finseq_1_def_13 sorry
    then have "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) inTARSKIR2 {TARSKIK1 x}"
      using A2 funct_1_def_7 sorry
    thus "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_20:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "p \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 domFINSEQ-1K5 p & domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 relat_1_th_132 sorry
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "p \<inverse>FUNCT-1K6 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
      using funct_1_th_72 sorry
    then have "rngFUNCT-1K2 (SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})) <>HIDDENR2 {}XBOOLE-0K1"
      using A1 finseq_1_def_13 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}))"
      using finseq_3_th_32 sorry
    then have "x ..FINSEQ-4K4 p inTARSKIR2 rngFUNCT-1K2 (SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}))"
      using funct_1_def_3 sorry
    then have "x ..FINSEQ-4K4 p inTARSKIR2 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      using A1 finseq_1_def_13 sorry
    thus "x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
      using funct_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_21:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies \<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies \<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
      using finseq_4_th_20 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using finseq_3_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_22:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1 & lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p be ElementSUBSET-1M1-of NATNUMBERSK1"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1 & lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "\<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using finseq_4_th_21 sorry
    thus "x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1 & lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p be ElementSUBSET-1M1-of NATNUMBERSK1"
      using int_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_23:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x ..FINSEQ-4K4 p inTARSKIR2 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x ..FINSEQ-4K4 p inTARSKIR2 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x"
      using finseq_4_th_19 sorry
    then have A2: "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) inTARSKIR2 {TARSKIK1 x}"
      using tarski_def_1 sorry
    have "x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
      using A1 finseq_4_th_20 sorry
    thus "x ..FINSEQ-4K4 p inTARSKIR2 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      using A2 funct_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_24:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p & k <XXREAL-0R3 x ..FINSEQ-4K4 p implies p .FUNCT-1K1 k <>HIDDENR2 x"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p & (k <XXREAL-0R3 x ..FINSEQ-4K4 p & p .FUNCT-1K1 k =HIDDENR1 x) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix k assume [ty]: "k be NatNAT-1M1"
    let ?q = "SgmFINSEQ-1K15 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 p"
      and A2: "k <XXREAL-0R3 x ..FINSEQ-4K4 p"
      and A3: "p .FUNCT-1K1 k =HIDDENR1 x"
    have A4: "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    have A5: "p \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 domFINSEQ-1K5 p & domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 relat_1_th_132 sorry
    then have "rngFUNCT-1K2 ?q =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      using finseq_1_def_13 sorry
    then have "k inTARSKIR2 rngFUNCT-1K2 ?q"
      using A1 A3 A4 funct_1_def_7 sorry
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A6: "y inHIDDENR3 domFINSEQ-1K5 ?q"and A7: "?q .FUNCT-1K1 y =XBOOLE-0R4 k"
      using funct_1_def_3 sorry
    have 
      [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A6 sorry
    have A8: " not \<one>\<^sub>M <XXREAL-0R3 y implies  False "
    proof(rule impI)
      assume " not \<one>\<^sub>M <XXREAL-0R3 y"
      then have "\<one>\<^sub>M =XBOOLE-0R4 y or y <XXREAL-0R3 \<one>\<^sub>M"
        using xxreal_0_th_1 sorry
      thus " False "
        using A2 A6 A7 finseq_3_th_24 nat_1_th_14 sorry
    qed
    have "domFINSEQ-1K5 ?q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
      using finseq_1_def_3 sorry
    then have "y <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
      using A6 finseq_1_th_1 sorry
    thus " False "
      using A2 A5 A7 A8 finseq_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_25:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x implies p <-FINSEQ-4K1 x =XBOOLE-0R4 x ..FINSEQ-4K4 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x implies p <-FINSEQ-4K1 x =XBOOLE-0R4 x ..FINSEQ-4K4 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "p just-once-valuesFINSEQ-4R2 x"
    then have "x inHIDDENR3 rngFUNCT-1K2 p"
      using finseq_4_th_5 sorry
    then have "x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x"
      using finseq_4_th_19 finseq_4_th_20 sorry
    thus "p <-FINSEQ-4K1 x =XBOOLE-0R4 x ..FINSEQ-4K4 p"
      using A1 finseq_4_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_26:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x implies ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p & k <>HIDDENR2 x ..FINSEQ-4K4 p implies p .FUNCT-1K1 k <>HIDDENR2 x)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x implies ( for k be NatNAT-1M1 holds (k inTARSKIR2 domFINSEQ-1K5 p & k <>HIDDENR2 x ..FINSEQ-4K4 p) & p .FUNCT-1K1 k =HIDDENR1 x implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "p just-once-valuesFINSEQ-4R2 x"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A2: "(k inTARSKIR2 domFINSEQ-1K5 p & k <>HIDDENR2 x ..FINSEQ-4K4 p) & p .FUNCT-1K1 k =HIDDENR1 x"
    have "p <-FINSEQ-4K1 x =XBOOLE-0R4 x ..FINSEQ-4K4 p"
      using A1 finseq_4_th_25 sorry
    thus " not  True "
      using A1 A2 finseq_4_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_27:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p & k <>HIDDENR2 x ..FINSEQ-4K4 p implies p .FUNCT-1K1 k <>HIDDENR2 x) implies p just-once-valuesFINSEQ-4R2 x"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p & k <>HIDDENR2 x ..FINSEQ-4K4 p implies p .FUNCT-1K1 k <>HIDDENR2 x) implies p just-once-valuesFINSEQ-4R2 x"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A2: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p & k <>HIDDENR2 x ..FINSEQ-4K4 p implies p .FUNCT-1K1 k <>HIDDENR2 x"
    have A3: " for z be objectHIDDENM1 holds z inHIDDENR3 domFINSEQ-1K5 p & z <>HIDDENR2 x ..FINSEQ-4K4 p implies p .FUNCT-1K1 z <>HIDDENR2 x"
      using A2 sorry
    have "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x & x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
      using A1 finseq_4_th_19 finseq_4_th_20 sorry
    thus "p just-once-valuesFINSEQ-4R2 x"
      using A3 finseq_4_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_28:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x iff x inHIDDENR3 rngFUNCT-1K2 p & {TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p & {TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}) & (x inHIDDENR3 rngFUNCT-1K2 p & {TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x} implies p just-once-valuesFINSEQ-4R2 x)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p & {TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
    proof(rule impI)
      assume A1: "p just-once-valuesFINSEQ-4R2 x"
      then have "x ..FINSEQ-4K4 p =XBOOLE-0R4 p <-FINSEQ-4K1 x"
        using finseq_4_th_25 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 p & {TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
        using A1 finseq_4_th_5 finseq_4_th_11 sorry
    qed
    assume A2: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A3: "{TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
    have A4: " for z be objectHIDDENM1 holds z inHIDDENR3 domFINSEQ-1K5 p & (z <>HIDDENR2 x ..FINSEQ-4K4 p & p .FUNCT-1K1 z =HIDDENR1 x) implies  False "
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A5: "z inHIDDENR3 domFINSEQ-1K5 p"
        and A6: "z <>HIDDENR2 x ..FINSEQ-4K4 p"
        and A7: "p .FUNCT-1K1 z =HIDDENR1 x"
      have "p .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x}"
        using A7 tarski_def_1 sorry
      then have "z inHIDDENR3 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
        using A5 funct_1_def_7 sorry
      thus " False "
        using A3 A6 tarski_def_1 sorry
    qed "sorry"
    have "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x & x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
      using A2 finseq_4_th_19 finseq_4_th_20 sorry
    thus "p just-once-valuesFINSEQ-4R2 x"
      using A4 finseq_4_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_29:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p be one-to-oneFUNCT-1V2 & x inHIDDENR3 rngFUNCT-1K2 p implies {TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p be one-to-oneFUNCT-1V2 & x inHIDDENR3 rngFUNCT-1K2 p implies {TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "p be one-to-oneFUNCT-1V2"
      and A2: "x inHIDDENR3 rngFUNCT-1K2 p"
    have "{TARSKIK1 x ..FINSEQ-4K4 p } c=TARSKIR1 p \<inverse>FUNCT-1K6 {TARSKIK1 x} & p \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 {TARSKIK1 x ..FINSEQ-4K4 p }"
    proof(rule conjMI)
      show "{TARSKIK1 x ..FINSEQ-4K4 p } c=TARSKIR1 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x ..FINSEQ-4K4 p } implies y inHIDDENR3 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 {TARSKIK1 x ..FINSEQ-4K4 p }"
          then have "y =HIDDENR1 x ..FINSEQ-4K4 p"
            using tarski_def_1 sorry
          thus "y inHIDDENR3 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
            using A2 finseq_4_th_23 sorry
        qed "sorry"
        thus "{TARSKIK1 x ..FINSEQ-4K4 p } c=TARSKIR1 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 p \<inverse>FUNCT-1K6 {TARSKIK1 x} implies y inHIDDENR3 {TARSKIK1 x ..FINSEQ-4K4 p }"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "y inHIDDENR3 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
        then have A4: "y inHIDDENR3 domFINSEQ-1K5 p"
          using funct_1_def_7 sorry
        have "p .FUNCT-1K1 y inTARSKIR2 {TARSKIK1 x}"
          using A3 funct_1_def_7 sorry
        then have A5: "p .FUNCT-1K1 y =HIDDENR1 x"
          using tarski_def_1 sorry
        have "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x & x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
          using A2 finseq_4_th_19 finseq_4_th_20 sorry
        then have "x ..FINSEQ-4K4 p =HIDDENR1 y"
          using A1 A4 A5 sorry
        thus "y inHIDDENR3 {TARSKIK1 x ..FINSEQ-4K4 p }"
          using tarski_def_1 sorry
      qed "sorry"
      thus "p \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 {TARSKIK1 x ..FINSEQ-4K4 p }"
        using tarski_def_3 sorry
    qed
    thus "{TARSKIK1 x ..FINSEQ-4K4 p } =XBOOLE-0R4 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_30:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x iff lenFINSEQ-1K4 (p -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p just-once-valuesFINSEQ-4R2 x implies lenFINSEQ-1K4 (p -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M) & (lenFINSEQ-1K4 (p -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M implies p just-once-valuesFINSEQ-4R2 x)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "p just-once-valuesFINSEQ-4R2 x implies lenFINSEQ-1K4 (p -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using finseq_3_th_59 sorry
    assume "lenFINSEQ-1K4 (p -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
    then have "lenFINSEQ-1K4 p +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 p -XCMPLX-0K6 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})"
      using finseq_3_th_59 sorry
    also have "... = lenFINSEQ-1K4 p +XCMPLX-0K2 (-XCMPLX-0K4 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}))"
       sorry
    finally have "lenFINSEQ-1K4 p +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 p +XCMPLX-0K2 (-XCMPLX-0K4 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}))"
       sorry
    thus "p just-once-valuesFINSEQ-4R2 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve L, M for "ElementSUBSET-1M1-of NATNUMBERSK1"
mtheorem finseq_4_th_31:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x implies ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x}) implies (k <XXREAL-0R3 x ..FINSEQ-4K4 p implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k) & (x ..FINSEQ-4K4 p <=XXREAL-0R1 k implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x implies ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x}) implies (k <XXREAL-0R3 x ..FINSEQ-4K4 p implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k) & (x ..FINSEQ-4K4 p <=XXREAL-0R1 k implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "p just-once-valuesFINSEQ-4R2 x"
    let ?q = "p -FINSEQ-3K1 {TARSKIK1 x}"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A2: "k inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x})"
    let ?A = "{L where L be ElementSUBSET-1M1-of NATNUMBERSK1 : (L inTARSKIR2 domFINSEQ-1K5 p & L <=XXREAL-0R1 k) & p .FUNCT-1K1 L inTARSKIR2 {TARSKIK1 x} }"
    have A3: "domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x}) c=TARSKIR1 domFINSEQ-1K5 p"
      using finseq_3_th_63 sorry
    show "k <XXREAL-0R3 x ..FINSEQ-4K4 p implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
    proof(rule impI)
      assume A4: "k <XXREAL-0R3 x ..FINSEQ-4K4 p"
      have "?A c=TARSKIR1 {}XBOOLE-0K1"
      proof-
        have "{L where L be ElementSUBSET-1M1-of NATNUMBERSK1 : (L inTARSKIR2 domFINSEQ-1K5 p & L <=XXREAL-0R1 k) & p .FUNCT-1K1 L inTARSKIR2 {TARSKIK1 x} } c=TARSKIR1 {}XBOOLE-0K1"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {L where L be ElementSUBSET-1M1-of NATNUMBERSK1 : (L inTARSKIR2 domFINSEQ-1K5 p & L <=XXREAL-0R1 k) & p .FUNCT-1K1 L inTARSKIR2 {TARSKIK1 x} } implies y inHIDDENR3 {}XBOOLE-0K1"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 ?A"
            then obtain L where
              [ty]:"L be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              "y =HIDDENR1 L"and A5: "L inTARSKIR2 domFINSEQ-1K5 p & L <=XXREAL-0R1 k"and A6: "p .FUNCT-1K1 L inTARSKIR2 {TARSKIK1 x}"
               sorry
            have "p .FUNCT-1K1 L <>HIDDENR2 x"
              using A1 A4 A5 finseq_4_th_26 sorry
            thus "y inHIDDENR3 {}XBOOLE-0K1"
              using A6 tarski_def_1 sorry
          qed "sorry"
          thus "{L where L be ElementSUBSET-1M1-of NATNUMBERSK1 : (L inTARSKIR2 domFINSEQ-1K5 p & L <=XXREAL-0R1 k) & p .FUNCT-1K1 L inTARSKIR2 {TARSKIK1 x} } c=TARSKIR1 {}XBOOLE-0K1"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then have A7: "?A =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      have "p .FUNCT-1K1 k <>HIDDENR2 x"
        using A1 A2 A3 A4 finseq_4_th_26 sorry
      then have " not p .FUNCT-1K1 k inTARSKIR2 {TARSKIK1 x}"
        using tarski_def_1 sorry
      then have "?q .FUNCT-1K1 (k -XCMPLX-0K6 0NUMBERSK6) =XBOOLE-0R4 p .FUNCT-1K1 k"
        using A2 A3 A7 card_1_th_27 finseq_3_th_85 sorry
      thus "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
         sorry
    qed
    let ?B = "{M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} }"
    assume A8: "x ..FINSEQ-4K4 p <=XXREAL-0R1 k"
    have A9: "x inHIDDENR3 rngFUNCT-1K2 p"
      using A1 finseq_4_th_5 sorry
    have A10: "?B =XBOOLE-0R4 {TARSKIK1 x ..FINSEQ-4K4 p }"
    proof-
      have "{M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} } =XBOOLE-0R4 {TARSKIK1 x ..FINSEQ-4K4 p }"
      proof-
        have "{M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} } c=TARSKIR1 {TARSKIK1 x ..FINSEQ-4K4 p } & {TARSKIK1 x ..FINSEQ-4K4 p } c=TARSKIR1 {M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} }"
        proof(rule conjMI)
          show "{M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} } c=TARSKIR1 {TARSKIK1 x ..FINSEQ-4K4 p }"
          proof-
            have "{M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} } c=TARSKIR1 {TARSKIK1 x ..FINSEQ-4K4 p }"
            proof-
              have " for y be objectHIDDENM1 holds y inHIDDENR3 {M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} } implies y inHIDDENR3 {TARSKIK1 x ..FINSEQ-4K4 p }"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume "y inHIDDENR3 ?B"
                then obtain M where
                  [ty]:"M be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A11: "M =HIDDENR1 y"and A12: "M inTARSKIR2 domFINSEQ-1K5 p"and "M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"and A13: "p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x}"
                   sorry
                have "p .FUNCT-1K1 M =HIDDENR1 x"
                  using A13 tarski_def_1 sorry
                then have "M =XBOOLE-0R4 x ..FINSEQ-4K4 p"
                  using A1 A12 finseq_4_th_26 sorry
                thus "y inHIDDENR3 {TARSKIK1 x ..FINSEQ-4K4 p }"
                  using A11 tarski_def_1 sorry
              qed "sorry"
              thus "{M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} } c=TARSKIR1 {TARSKIK1 x ..FINSEQ-4K4 p }"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x ..FINSEQ-4K4 p } implies y inHIDDENR3 {M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} }"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 {TARSKIK1 x ..FINSEQ-4K4 p }"
            then have A14: "y =HIDDENR1 x ..FINSEQ-4K4 p"
              using tarski_def_1 sorry
            have "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x"
              using A9 finseq_4_th_19 sorry
            then have A15: "p .FUNCT-1K1 (x ..FINSEQ-4K4 p) inTARSKIR2 {TARSKIK1 x}"
              using tarski_def_1 sorry
            have "x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p & x ..FINSEQ-4K4 p <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              using A9 A8 finseq_4_th_20 nat_1_th_12 sorry
            thus "y inHIDDENR3 {M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} }"
              using A14 A15 sorry
          qed "sorry"
          thus "{TARSKIK1 x ..FINSEQ-4K4 p } c=TARSKIR1 {M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} }"
            using tarski_def_3 sorry
        qed
        thus "{M where M be ElementSUBSET-1M1-of NATNUMBERSK1 : (M inTARSKIR2 domFINSEQ-1K5 p & M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M) & p .FUNCT-1K1 M inTARSKIR2 {TARSKIK1 x} } =XBOOLE-0R4 {TARSKIK1 x ..FINSEQ-4K4 p }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain B where 
      [ty]:"B be finiteFINSET-1V1\<bar>setHIDDENM2" and BDef:"B = ?B"
       sorry
    have "domFINSEQ-1K5 ?q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q) & lenFINSEQ-1K4 (p -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 finseq_4_th_30 finseq_1_def_3 sorry
    then have "k <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 finseq_1_th_1 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using nat_1_th_12 xreal_1_th_19 sorry
    then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
       sorry
    then have A16: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    have "p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {TARSKIK1 x} implies  False "
    proof(rule impI)
      have "x ..FINSEQ-4K4 p <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M"
        using A8 xreal_1_th_29 sorry
      then have A17: "p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 x"
        using A1 A16 finseq_4_th_26 sorry
      assume "p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {TARSKIK1 x}"
      thus " False "
        using A17 tarski_def_1 sorry
    qed
    then have "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 cardCARD-1K4 B) =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
      using A16 finseq_3_th_85 sorry
    then have "?q .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
      using A10 card_1_th_30 sorry
    thus "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_32:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p be one-to-oneFUNCT-1V2 & x inHIDDENR3 rngFUNCT-1K2 p implies ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x}) implies ((p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k iff k <XXREAL-0R3 x ..FINSEQ-4K4 p) & ((p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) iff x ..FINSEQ-4K4 p <=XXREAL-0R1 k))"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p be one-to-oneFUNCT-1V2 & x inHIDDENR3 rngFUNCT-1K2 p implies ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x}) implies ((p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k implies k <XXREAL-0R3 x ..FINSEQ-4K4 p) & ((k <XXREAL-0R3 x ..FINSEQ-4K4 p implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k) & (((p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies x ..FINSEQ-4K4 p <=XXREAL-0R1 k) &  not (x ..FINSEQ-4K4 p <=XXREAL-0R1 k &  not (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "p be one-to-oneFUNCT-1V2"
      and A2: "x inHIDDENR3 rngFUNCT-1K2 p"
    let ?q = "p -FINSEQ-3K1 {TARSKIK1 x}"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A3: "k inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x})"
    have A4: "p just-once-valuesFINSEQ-4R2 x"
      using A1 A2 finseq_4_th_8 sorry
    then have "domFINSEQ-1K5 ?q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q) & lenFINSEQ-1K4 (p -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using finseq_4_th_30 finseq_1_def_3 sorry
    then have "k <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using A3 finseq_1_th_1 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using nat_1_th_12 xreal_1_th_19 sorry
    then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
       sorry
    then have A5: "domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x}) c=TARSKIR1 domFINSEQ-1K5 p & k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
      using finseq_1_def_3 finseq_3_th_63 sorry
    show "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k implies k <XXREAL-0R3 x ..FINSEQ-4K4 p"
    proof-
      have "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k &  not k <XXREAL-0R3 x ..FINSEQ-4K4 p implies  not  True "
      proof(rule impMI ,rule impI)
        assume A6: "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
          and A7: " not k <XXREAL-0R3 x ..FINSEQ-4K4 p"
        have "?q .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using A4 A3 A7 finseq_4_th_31 sorry
        then have "k +NAT-1K1 0NUMBERSK6 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using A1 A3 A5 A6 sorry
        thus " not  True "
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "k <XXREAL-0R3 x ..FINSEQ-4K4 p implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
      using A4 A3 finseq_4_th_31 sorry
    show "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies x ..FINSEQ-4K4 p <=XXREAL-0R1 k"
    proof-
      have "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies ( not x ..FINSEQ-4K4 p <=XXREAL-0R1 k implies  not  True )"
      proof(rule impI,rule impI)
        assume A8: "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        assume " not x ..FINSEQ-4K4 p <=XXREAL-0R1 k"
        then have "p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 k"
          using A4 A3 A8 finseq_4_th_31 sorry
        then have "k +NAT-1K1 0NUMBERSK6 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using A1 A3 A5 sorry
        thus " not  True "
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " not (x ..FINSEQ-4K4 p <=XXREAL-0R1 k &  not (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
      using A4 A3 finseq_4_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_4_def_5 (" _ -|FINSEQ-4K5  _ " [132,132]132 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "x be objectHIDDENM1"
"assume x inHIDDENR3 rngFUNCT-1K2 p func p -|FINSEQ-4K5 x \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it.  ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & it =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n"
proof-
  (*existence*)
    show "x inHIDDENR3 rngFUNCT-1K2 p implies ( ex it be FinSequenceFINSEQ-1M1 st  ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & it =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n)"
    proof(rule impI)
      assume Assume: "x inHIDDENR3 rngFUNCT-1K2 p"
      have A1: "x inHIDDENR3 rngFUNCT-1K2 p"
        using Assume sorry
      show " ex it be FinSequenceFINSEQ-1M1 st  ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & it =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n"
      proof-
        have " ex tVar3 be FinSequenceFINSEQ-1M1 st  not ( for n be NatNAT-1M1 holds  not (n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & tVar3 =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n))"
        proof-
          obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
            using A1 finseq_4_th_22 sorry
          obtain q where 
            [ty]:"q be FinSequenceFINSEQ-1M1" and qDef:"q = p  |RELAT-1K8 SegFINSEQ-1K2 n"
            using finseq_1_th_15 sorry
          show " ex tVar3 be FinSequenceFINSEQ-1M1 st  not ( for n be NatNAT-1M1 holds  not (n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & tVar3 =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n))"
          proof(rule bexI[of _ "q"])
            show " not ( for n be NatNAT-1M1 holds  not (n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & q =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n))"
               sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "x inHIDDENR3 rngFUNCT-1K2 p implies ( for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds ( ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & it1 =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n) & ( ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & it2 =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "x inHIDDENR3 rngFUNCT-1K2 p"
      have A1: "x inHIDDENR3 rngFUNCT-1K2 p"
        using Assume sorry
      show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds ( ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & it1 =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n) & ( ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & it2 =FUNCT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 n) implies it1 =HIDDENR1 it2"
         sorry
    qed
qed "sorry"

mtheorem finseq_4_th_33:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for n be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p & n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M implies p  |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 p -|FINSEQ-4K5 x"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for n be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p implies  not (n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M &  not p  |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 p -|FINSEQ-4K5 x)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have " ex m be NatNAT-1M1 st m =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & p  |RELAT-1K8 SegFINSEQ-1K2 m =FUNCT-1R1 p -|FINSEQ-4K5 x"
      using finseq_4_def_5 sorry
    thus " not (n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M &  not p  |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 p -|FINSEQ-4K5 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_34:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A2: "n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"and A3: "p  |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 p -|FINSEQ-4K5 x"
      using finseq_4_def_5 sorry
    have A4: "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_12 sorry
    have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A1 A2 finseq_4_th_21 sorry
    then have "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A4 xxreal_0_th_2 sorry
    thus "lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 A3 finseq_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_35:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for n be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p & n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M implies domFINSEQ-1K5 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 SegFINSEQ-1K2 n"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for n be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p implies  not (n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M &  not domFINSEQ-1K5 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 SegFINSEQ-1K2 n)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using finseq_4_th_34 sorry
    thus " not (n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M &  not domFINSEQ-1K5 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 SegFINSEQ-1K2 n)"
      using finseq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_36:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for k be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p & k inTARSKIR2 domFINSEQ-1K5 (p -|FINSEQ-4K5 x) implies p .FUNCT-1K1 k =XBOOLE-0R4 (p -|FINSEQ-4K5 x).FUNCT-1K1 k"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for k be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p & k inTARSKIR2 domFINSEQ-1K5 (p -|FINSEQ-4K5 x) implies p .FUNCT-1K1 k =XBOOLE-0R4 (p -|FINSEQ-4K5 x).FUNCT-1K1 k"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A2: "k inTARSKIR2 domFINSEQ-1K5 (p -|FINSEQ-4K5 x)"
    have " ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & p  |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 p -|FINSEQ-4K5 x"
      using A1 finseq_4_def_5 sorry
    thus "p .FUNCT-1K1 k =XBOOLE-0R4 (p -|FINSEQ-4K5 x).FUNCT-1K1 k"
      using A2 funct_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_37:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies  not x inHIDDENR3 rngFUNCT-1K2 (p -|FINSEQ-4K5 x)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & x inHIDDENR3 rngFUNCT-1K2 (p -|FINSEQ-4K5 x) implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A2: "x inHIDDENR3 rngFUNCT-1K2 (p -|FINSEQ-4K5 x)"
    obtain n where 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 finseq_4_th_22 sorry
    let ?r = "p  |RELAT-1K8 SegFINSEQ-1K2 n"
    have A3: "?r =FUNCT-1R1 p -|FINSEQ-4K5 x"
      using A1 finseq_4_th_33 sorry
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A4: "y inHIDDENR3 domRELAT-1K1 ?r"and A5: "?r .FUNCT-1K1 y =HIDDENR1 x"
      using A2 funct_1_def_3 sorry
    have A6: "domRELAT-1K1 ?r =XBOOLE-0R4 SegFINSEQ-1K2 n"
      using A1 A3 finseq_4_th_35 sorry
    then have 
      [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A4 sorry
    have "y <=XXREAL-0R1 n"
      using A4 A6 finseq_1_th_1 sorry
    then have A7: "y +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p"
      using xreal_1_th_19 sorry
    have "y <XXREAL-0R3 y +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_29 sorry
    then have "domRELAT-1K1 ?r c=TARSKIR1 domFINSEQ-1K5 p & y <XXREAL-0R3 x ..FINSEQ-4K4 p"
      using A7 relat_1_th_60 xxreal_0_th_2 sorry
    then have "p .FUNCT-1K1 y <>HIDDENR2 x"
      using A4 finseq_4_th_24 sorry
    thus " not  True "
      using A4 A5 funct_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_38:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies rngFUNCT-1K2 (p -|FINSEQ-4K5 x) missesXBOOLE-0R1 {TARSKIK1 x}"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies rngFUNCT-1K2 (p -|FINSEQ-4K5 x) missesXBOOLE-0R1 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have " not x inHIDDENR3 rngFUNCT-1K2 (p -|FINSEQ-4K5 x)"
      using finseq_4_th_37 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (p -|FINSEQ-4K5 x) implies  not y inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "rngFUNCT-1K2 (p -|FINSEQ-4K5 x) missesXBOOLE-0R1 {TARSKIK1 x}"
      using xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_39:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies rngFUNCT-1K2 (p -|FINSEQ-4K5 x) c=TARSKIR1 rngFUNCT-1K2 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies rngFUNCT-1K2 (p -|FINSEQ-4K5 x) c=TARSKIR1 rngFUNCT-1K2 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have " ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & p  |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 p -|FINSEQ-4K5 x"
      using finseq_4_def_5 sorry
    thus "rngFUNCT-1K2 (p -|FINSEQ-4K5 x) c=TARSKIR1 rngFUNCT-1K2 p"
      using relat_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_40:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies (x ..FINSEQ-4K4 p =XBOOLE-0R4 \<one>\<^sub>M iff p -|FINSEQ-4K5 x =FINSEQ-1R1 {}XBOOLE-0K1)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies (x ..FINSEQ-4K4 p =XBOOLE-0R4 \<one>\<^sub>M implies p -|FINSEQ-4K5 x =FINSEQ-1R1 {}XBOOLE-0K1) & (p -|FINSEQ-4K5 x =FINSEQ-1R1 {}XBOOLE-0K1 implies x ..FINSEQ-4K4 p =XBOOLE-0R4 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
    show "x ..FINSEQ-4K4 p =XBOOLE-0R4 \<one>\<^sub>M implies p -|FINSEQ-4K5 x =FINSEQ-1R1 {}XBOOLE-0K1"
    proof(rule impI)
      assume A2: "x ..FINSEQ-4K4 p =XBOOLE-0R4 \<one>\<^sub>M"
      have "lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) =HIDDENR1 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
        using A1 finseq_4_th_34 sorry
      also have "... = 0NUMBERSK6"
        using A2 sorry
      finally have "lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) =HIDDENR1 0NUMBERSK6"
         sorry
      thus "p -|FINSEQ-4K5 x =FINSEQ-1R1 {}XBOOLE-0K1"
         sorry
    qed
    assume "p -|FINSEQ-4K5 x =FINSEQ-1R1 {}XBOOLE-0K1"
    then have A3: "lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 0NUMBERSK6"
       sorry
    have "lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 finseq_4_th_34 sorry
    thus "x ..FINSEQ-4K4 p =XBOOLE-0R4 \<one>\<^sub>M"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_41:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds x inHIDDENR3 rngFUNCT-1K2 p & p be FinSequenceFINSEQ-1M3-of D implies p -|FINSEQ-4K5 x be FinSequenceFINSEQ-1M3-of D"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds x inHIDDENR3 rngFUNCT-1K2 p implies  not (p be FinSequenceFINSEQ-1M3-of D &  not p -|FINSEQ-4K5 x be FinSequenceFINSEQ-1M3-of D)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have " ex n be NatNAT-1M1 st n =XBOOLE-0R4 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M & p  |RELAT-1K8 SegFINSEQ-1K2 n =FUNCT-1R1 p -|FINSEQ-4K5 x"
      using finseq_4_def_5 sorry
    thus " not (p be FinSequenceFINSEQ-1M3-of D &  not p -|FINSEQ-4K5 x be FinSequenceFINSEQ-1M3-of D)"
      using finseq_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_4_def_6 (" _  |--FINSEQ-4K6  _ " [132,132]132 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "x be objectHIDDENM1"
"assume x inHIDDENR3 rngFUNCT-1K2 p func p  |--FINSEQ-4K6 x \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p))"
proof-
  (*existence*)
    show "x inHIDDENR3 rngFUNCT-1K2 p implies ( ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)))"
    proof(rule impI)
      assume Assume: "x inHIDDENR3 rngFUNCT-1K2 p"
      have A1: "x inHIDDENR3 rngFUNCT-1K2 p"
        using Assume sorry
      show " ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p))"
      proof-
        have " ex tVar4 be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 tVar4 =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 tVar4 &  not tVar4 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)))"
        proof-
          let ?F = "\<lambda>Lamb1. p .FUNCT-1K1 (Lamb1 +NAT-1K1 x ..FINSEQ-4K4 p)"
          obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
            using A1 finseq_4_th_22 sorry
          obtain q where
            [ty]:"q be FinSequenceFINSEQ-1M1" and 
            A2: "lenFINSEQ-1K4 q =XBOOLE-0R4 n & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 k =XBOOLE-0R4 ?F(k))"
            using finseq_1_sch_2 sorry
          show " ex tVar4 be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 tVar4 =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 tVar4 &  not tVar4 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)))"
          proof(rule bexI[of _ "q"])
            show "lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 q &  not q .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)))"
              using A2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "x inHIDDENR3 rngFUNCT-1K2 p implies ( for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p))) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "x inHIDDENR3 rngFUNCT-1K2 p"
      have A1: "x inHIDDENR3 rngFUNCT-1K2 p"
        using Assume sorry
      show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p))) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p))) implies it1 =HIDDENR1 it2"
      proof-
        have " for q be FinSequenceFINSEQ-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)) implies (lenFINSEQ-1K4 r =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 r implies r .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)) implies q =HIDDENR1 r)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
          fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
          fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
          assume A3: "lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
            and A4: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)"
          assume A5: "lenFINSEQ-1K4 r =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
            and A6: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 r implies r .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)"
          have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 k =XBOOLE-0R4 r .FUNCT-1K1 k"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            have A7: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 q) & domFINSEQ-1K5 r =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 r)"
              using finseq_1_def_3 sorry
            assume A8: "k inTARSKIR2 domFINSEQ-1K5 q"
            then have "q .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)"
              using A4 sorry
            thus "q .FUNCT-1K1 k =XBOOLE-0R4 r .FUNCT-1K1 k"
              using A3 A5 A6 A8 A7 sorry
          qed "sorry"
          thus "q =HIDDENR1 r"
            using A3 A5 finseq_2_th_9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem finseq_4_th_42:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for n be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p & n =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p implies domFINSEQ-1K5 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 SegFINSEQ-1K2 n"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for n be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p implies  not (n =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p &  not domFINSEQ-1K5 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 SegFINSEQ-1K2 n)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
      using finseq_4_def_6 sorry
    thus " not (n =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p &  not domFINSEQ-1K5 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 SegFINSEQ-1K2 n)"
      using finseq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_43:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for n be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p & n inTARSKIR2 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x) implies n +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for n be NatNAT-1M1 holds x inHIDDENR3 rngFUNCT-1K2 p & n inTARSKIR2 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x) implies n +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A2: "n inTARSKIR2 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x)"
    obtain m where 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
      using A1 finseq_4_th_22 sorry
    have "n inTARSKIR2 SegFINSEQ-1K2 m"
      using A1 A2 finseq_4_th_42 sorry
    then have "n <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
      using finseq_1_th_1 sorry
    then have A3: "n +NAT-1K1 x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using xreal_1_th_19 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 n"
      using A2 finseq_3_th_25 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 x ..FINSEQ-4K4 p"
      using nat_1_th_12 sorry
    thus "n +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
      using A3 finseq_3_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_44:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) c=TARSKIR1 rngFUNCT-1K2 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) c=TARSKIR1 rngFUNCT-1K2 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) implies y inHIDDENR3 rngFUNCT-1K2 p"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A2: "z inHIDDENR3 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x)"and A3: "(p  |--FINSEQ-4K6 x).FUNCT-1K1 z =HIDDENR1 y"
        using funct_1_def_3 sorry
      have 
        [ty]:"z be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A2 sorry
      have "y =HIDDENR1 p .FUNCT-1K1 (z +NAT-1K1 x ..FINSEQ-4K4 p) & z +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
        using A1 A2 A3 finseq_4_def_6 finseq_4_th_43 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 p"
        using funct_1_def_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) c=TARSKIR1 rngFUNCT-1K2 p"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_45:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x iff x inHIDDENR3 rngFUNCT-1K2 p &  not x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p &  not x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)) & (x inHIDDENR3 rngFUNCT-1K2 p &  not x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) implies p just-once-valuesFINSEQ-4R2 x)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p &  not x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
    proof-
      have "p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p & (x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) implies  not  True )"
      proof(rule impI,rule conjMI,rule impI)
        assume A1: "p just-once-valuesFINSEQ-4R2 x"
        thus A2: "x inHIDDENR3 rngFUNCT-1K2 p"
          using finseq_4_th_5 sorry
        assume "x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A3: "z inHIDDENR3 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x)"and A4: "(p  |--FINSEQ-4K6 x).FUNCT-1K1 z =HIDDENR1 x"
          using funct_1_def_3 sorry
        have 
          [ty]:"z be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A3 sorry
        have "(p  |--FINSEQ-4K6 x).FUNCT-1K1 z =XBOOLE-0R4 p .FUNCT-1K1 (z +NAT-1K1 x ..FINSEQ-4K4 p) & z +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
          using A2 A3 finseq_4_def_6 finseq_4_th_43 sorry
        then have "z +NAT-1K1 x ..FINSEQ-4K4 p =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 x ..FINSEQ-4K4 p"
          using A1 A4 finseq_4_th_26 sorry
        thus " not  True "
          using A3 finseq_3_th_24 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A6: " not x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p & (k <>HIDDENR2 x ..FINSEQ-4K4 p & p .FUNCT-1K1 k =HIDDENR1 x) implies  False "
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A7: "k inTARSKIR2 domFINSEQ-1K5 p"
        and A8: "k <>HIDDENR2 x ..FINSEQ-4K4 p"
        and A9: "p .FUNCT-1K1 k =HIDDENR1 x"
      have " False "
      proof-
        show " False "
        proof-
          have cases: "k <XXREAL-0R3 x ..FINSEQ-4K4 p or x ..FINSEQ-4K4 p <XXREAL-0R3 k"
            using A8 xxreal_0_th_1 sorry
          have case1: "k <XXREAL-0R3 x ..FINSEQ-4K4 p implies  False "
          proof(rule impI)
            assume "k <XXREAL-0R3 x ..FINSEQ-4K4 p"
            then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p"
              using nat_1_th_13 sorry
            then have "k <=XXREAL-0R1 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_19 sorry
            then have A10: "k <=XXREAL-0R1 lenFINSEQ-1K4 (p -|FINSEQ-4K5 x)"
              using A5 finseq_4_th_34 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 k"
              using A7 finseq_3_th_25 sorry
            then have A11: "k inTARSKIR2 domFINSEQ-1K5 (p -|FINSEQ-4K5 x)"
              using A10 finseq_3_th_25 sorry
            then have "x =HIDDENR1 (p -|FINSEQ-4K5 x).FUNCT-1K1 k"
              using A5 A9 finseq_4_th_36 sorry
            then have "x inHIDDENR3 rngFUNCT-1K2 (p -|FINSEQ-4K5 x)"
              using A11 funct_1_def_3 sorry
            thus " False "
              using A5 finseq_4_th_37 sorry
          qed
          have case2: "x ..FINSEQ-4K4 p <XXREAL-0R3 k implies  False "
          proof(rule impI)
            assume A12: "x ..FINSEQ-4K4 p <XXREAL-0R3 k"
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A13: "k =XBOOLE-0R4 x ..FINSEQ-4K4 p +XCMPLX-0K2 m"
              using nat_1_th_10 sorry
            have "x ..FINSEQ-4K4 p +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 x ..FINSEQ-4K4 p +XCMPLX-0K2 m"
              using A12 A13 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 m"
               sorry
            then have A14: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
              using nat_1_th_13 sorry
            have "m +NAT-1K1 x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using A7 A13 finseq_3_th_25 sorry
            then have "m <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
              using xreal_1_th_19 sorry
            then have "m <=XXREAL-0R1 lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x)"
              using A5 finseq_4_def_6 sorry
            then have A15: "m inTARSKIR2 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x)"
              using A14 finseq_3_th_25 sorry
            then have "(p  |--FINSEQ-4K6 x).FUNCT-1K1 m =XBOOLE-0R4 p .FUNCT-1K1 k"
              using A5 A13 finseq_4_def_6 sorry
            thus " False "
              using A6 A9 A15 funct_1_def_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " False "
         sorry
    qed "sorry"
    thus "p just-once-valuesFINSEQ-4R2 x"
      using A5 finseq_4_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_46:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies  not x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & (p be one-to-oneFUNCT-1V2 & x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)) implies  not  True "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A2: "p be one-to-oneFUNCT-1V2"
      and A3: "x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
    have A4: "lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
      using A1 finseq_4_def_6 sorry
    obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A5: "y inHIDDENR3 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x)"and A6: "(p  |--FINSEQ-4K6 x).FUNCT-1K1 y =HIDDENR1 x"
      using A3 funct_1_def_3 sorry
    have 
      [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A5 sorry
    have A7: "\<one>\<^sub>M <=XXREAL-0R1 y +NAT-1K1 x ..FINSEQ-4K4 p"
      using A1 finseq_4_th_21 nat_1_th_12 sorry
    have A8: "y inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x))"
      using A5 finseq_1_def_3 sorry
    then have "y <=XXREAL-0R1 lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x)"
      using finseq_1_th_1 sorry
    then have "y +NAT-1K1 x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A4 xreal_1_th_19 sorry
    then have "y +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using A7 sorry
    then have A9: "y +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    have A10: "x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x"
      using A1 finseq_4_th_19 finseq_4_th_20 sorry
    have "(p  |--FINSEQ-4K6 x).FUNCT-1K1 y =XBOOLE-0R4 p .FUNCT-1K1 (y +NAT-1K1 x ..FINSEQ-4K4 p)"
      using A1 A5 finseq_4_def_6 sorry
    then have "0NUMBERSK6 +NAT-1K1 x ..FINSEQ-4K4 p =XBOOLE-0R4 y +NAT-1K1 x ..FINSEQ-4K4 p"
      using A2 A6 A10 A9 sorry
    thus " not  True "
      using A8 finseq_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_47:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x iff x inHIDDENR3 rngFUNCT-1K2 p & rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x}"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p & rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x}) & (x inHIDDENR3 rngFUNCT-1K2 p & rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x} implies p just-once-valuesFINSEQ-4R2 x)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p & rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x}"
    proof-
      have "p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p & ( not rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x} implies  not  True )"
      proof(rule impI,rule conjMI,rule impI)
        assume A1: "p just-once-valuesFINSEQ-4R2 x"
        thus "x inHIDDENR3 rngFUNCT-1K2 p"
          using finseq_4_th_45 sorry
        assume " not rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x}"
        then have A2: " ex y be objectHIDDENM1 st y inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) & y inHIDDENR3 {TARSKIK1 x}"
          using xboole_0_th_3 sorry
        have " not x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
          using A1 finseq_4_th_45 sorry
        thus " not  True "
          using A2 tarski_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A3: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A4: "rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x}"
    have "x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) implies  False "
    proof(rule impI)
      have A5: "x inHIDDENR3 {TARSKIK1 x}"
        using tarski_def_1 sorry
      assume "x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
      thus " False "
        using A4 A5 xboole_0_th_3 sorry
    qed
    thus "p just-once-valuesFINSEQ-4R2 x"
      using A3 finseq_4_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_48:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x}"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2"
    then have " not x inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
      using finseq_4_th_46 sorry
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) implies  not y inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 {TARSKIK1 x}"
      using xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_49:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies (x ..FINSEQ-4K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p iff p  |--FINSEQ-4K6 x =FINSEQ-1R1 {}XBOOLE-0K1)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies (x ..FINSEQ-4K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p implies p  |--FINSEQ-4K6 x =FINSEQ-1R1 {}XBOOLE-0K1) & (p  |--FINSEQ-4K6 x =FINSEQ-1R1 {}XBOOLE-0K1 implies x ..FINSEQ-4K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
    show "x ..FINSEQ-4K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p implies p  |--FINSEQ-4K6 x =FINSEQ-1R1 {}XBOOLE-0K1"
    proof(rule impI)
      assume A2: "x ..FINSEQ-4K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p"
      have "lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x) =HIDDENR1 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
        using A1 finseq_4_def_6 sorry
      also have "... = 0NUMBERSK6"
        using A2 sorry
      finally have "lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x) =HIDDENR1 0NUMBERSK6"
         sorry
      thus "p  |--FINSEQ-4K6 x =FINSEQ-1R1 {}XBOOLE-0K1"
         sorry
    qed
    assume "p  |--FINSEQ-4K6 x =FINSEQ-1R1 {}XBOOLE-0K1"
    then have A3: "lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 0NUMBERSK6"
       sorry
    have "lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
      using A1 finseq_4_def_6 sorry
    thus "x ..FINSEQ-4K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_50:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds x inHIDDENR3 rngFUNCT-1K2 p & p be FinSequenceFINSEQ-1M3-of D implies p  |--FINSEQ-4K6 x be FinSequenceFINSEQ-1M3-of D"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds x inHIDDENR3 rngFUNCT-1K2 p & p be FinSequenceFINSEQ-1M3-of D implies p  |--FINSEQ-4K6 x be FinSequenceFINSEQ-1M3-of D"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A2: "p be FinSequenceFINSEQ-1M3-of D"
    have "rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) c=TARSKIR1 D"
    proof-
      have A3: "lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
        using A1 finseq_4_def_6 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) implies y inHIDDENR3 D"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A4: "z inHIDDENR3 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x)"and A5: "(p  |--FINSEQ-4K6 x).FUNCT-1K1 z =HIDDENR1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"z be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A4 sorry
        have "domFINSEQ-1K5 (p  |--FINSEQ-4K6 x) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x))"
          using finseq_1_def_3 sorry
        then have "z <=XXREAL-0R1 lenFINSEQ-1K4 (p  |--FINSEQ-4K6 x)"
          using A4 finseq_1_th_1 sorry
        then have A6: "z +NAT-1K1 x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A3 xreal_1_th_19 sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 z +NAT-1K1 x ..FINSEQ-4K4 p"
          using A1 finseq_4_th_21 nat_1_th_12 sorry
        then have "z +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
          using A6 sorry
        then have A7: "z +NAT-1K1 x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
          using finseq_1_def_3 sorry
        have "y =HIDDENR1 p .FUNCT-1K1 (z +NAT-1K1 x ..FINSEQ-4K4 p)"
          using A1 A4 A5 finseq_4_def_6 sorry
        then have A8: "y inHIDDENR3 rngFUNCT-1K2 p"
          using A7 funct_1_def_3 sorry
        have "rngFUNCT-1K2 p c=TARSKIR1 D"
          using A2 finseq_1_def_4 sorry
        thus "y inHIDDENR3 D"
          using A8 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) c=TARSKIR1 D"
        using tarski_def_3 sorry
    qed
    thus "p  |--FINSEQ-4K6 x be FinSequenceFINSEQ-1M3-of D"
      using finseq_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_51:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies p =FINSEQ-1R1 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies p =FINSEQ-1R1 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?q1 = "p -|FINSEQ-4K5 x"
    let ?q2 = "p  |--FINSEQ-4K6 x"
    let ?r = "?q1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
    have A2: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x) implies p .FUNCT-1K1 (lenFINSEQ-1K4 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +XCMPLX-0K2 k) =XBOOLE-0R4 (p  |--FINSEQ-4K6 x).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domFINSEQ-1K5 ?q2"
      then have "?q2 .FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 (((x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 k)"
        using A1 finseq_4_def_6 sorry
      also have "... = p .FUNCT-1K1 ((lenFINSEQ-1K4 ?q1 +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
        using A1 finseq_4_th_34 sorry
      also have "... = p .FUNCT-1K1 ((lenFINSEQ-1K4 ?q1 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))+XCMPLX-0K2 k)"
        using finseq_1_th_40 sorry
      also have "... = p .FUNCT-1K1 (lenFINSEQ-1K4 ?r +XCMPLX-0K2 k)"
        using finseq_1_th_22 sorry
      finally have "?q2 .FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 (lenFINSEQ-1K4 ?r +XCMPLX-0K2 k)"
         sorry
      thus "p .FUNCT-1K1 (lenFINSEQ-1K4 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) +XCMPLX-0K2 k) =XBOOLE-0R4 (p  |--FINSEQ-4K6 x).FUNCT-1K1 k"
         sorry
    qed "sorry"
    have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) implies p .FUNCT-1K1 k =XBOOLE-0R4 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "k inTARSKIR2 domFINSEQ-1K5 ?r"
      have "((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
      proof-
        show "((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
        proof-
          have cases: "k inTARSKIR2 domFINSEQ-1K5 ?q1 or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) & k =XBOOLE-0R4 lenFINSEQ-1K4 ?q1 +XCMPLX-0K2 n)"
            using A4 finseq_1_th_25 sorry
          have case1: "k inTARSKIR2 domFINSEQ-1K5 (p -|FINSEQ-4K5 x) implies ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
          proof(rule impI)
            assume A5: "k inTARSKIR2 domFINSEQ-1K5 ?q1"
            then have "((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 (p -|FINSEQ-4K5 x).FUNCT-1K1 k"
              using finseq_1_def_7 sorry
            also have "... = p .FUNCT-1K1 k"
              using A1 A5 finseq_4_th_36 sorry
            finally show "((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
               sorry
          qed
          have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) & k =XBOOLE-0R4 lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) +XCMPLX-0K2 n) implies ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
          proof(rule impI)
            assume " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) & k =XBOOLE-0R4 lenFINSEQ-1K4 ?q1 +XCMPLX-0K2 n"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A6: "n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>)"and A7: "k =XBOOLE-0R4 lenFINSEQ-1K4 ?q1 +XCMPLX-0K2 n"
               sorry
            have "n inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
              using A6 finseq_1_th_2 finseq_1_def_8 sorry
            then have A8: "n =XBOOLE-0R4 \<one>\<^sub>M"
              using tarski_def_1 sorry
            then have "((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 (<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M"
              using A6 A7 finseq_1_def_7 sorry
            also have "... = x"
              using finseq_1_def_8 sorry
            also have "... = p .FUNCT-1K1 ((x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)"
              using A1 finseq_4_th_19 sorry
            also have "... = p .FUNCT-1K1 k"
              using A1 A7 A8 finseq_4_th_34 sorry
            finally show "((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "p .FUNCT-1K1 k =XBOOLE-0R4 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 k"
         sorry
    qed "sorry"
    have "lenFINSEQ-1K4 p =HIDDENR1 (lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p)+XCMPLX-0K2 x ..FINSEQ-4K4 p"
       sorry
    also have "... = ((x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 lenFINSEQ-1K4 ?q2"
      using A1 finseq_4_def_6 sorry
    also have "... = (lenFINSEQ-1K4 ?q1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 ?q2"
      using A1 finseq_4_th_34 sorry
    also have "... = (lenFINSEQ-1K4 ?q1 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>))+NAT-1K1 lenFINSEQ-1K4 ?q2"
      using finseq_1_th_40 sorry
    also have "... = lenFINSEQ-1K4 ?r +NAT-1K1 lenFINSEQ-1K4 ?q2"
      using finseq_1_th_22 sorry
    finally have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 ?r +NAT-1K1 lenFINSEQ-1K4 ?q2"
       sorry
    thus "p =FINSEQ-1R1 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
      using A3 A2 finseq_3_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_52:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies p -|FINSEQ-4K5 x be one-to-oneFUNCT-1V2"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies  not (p be one-to-oneFUNCT-1V2 &  not p -|FINSEQ-4K5 x be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "p =HIDDENR1 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
      using finseq_4_th_51 sorry
    also have "... = (p -|FINSEQ-4K5 x)^FINSEQ-1K8 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x))"
      using finseq_1_th_32 sorry
    finally have "p =HIDDENR1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x))"
       sorry
    thus " not (p be one-to-oneFUNCT-1V2 &  not p -|FINSEQ-4K5 x be one-to-oneFUNCT-1V2)"
      using finseq_3_th_91 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_53:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies p  |--FINSEQ-4K6 x be one-to-oneFUNCT-1V2"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies  not (p be one-to-oneFUNCT-1V2 &  not p  |--FINSEQ-4K6 x be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p"
    then have "p =FINSEQ-1R1 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
      using finseq_4_th_51 sorry
    thus " not (p be one-to-oneFUNCT-1V2 &  not p  |--FINSEQ-4K6 x be one-to-oneFUNCT-1V2)"
      using finseq_3_th_91 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_54:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds p just-once-valuesFINSEQ-4R2 x iff x inHIDDENR3 rngFUNCT-1K2 p & p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p & p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)) & (x inHIDDENR3 rngFUNCT-1K2 p implies (p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x) implies p just-once-valuesFINSEQ-4R2 x))"
  proof(rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?q = "p -FINSEQ-3K1 {TARSKIK1 x}"
    let ?r = "p -|FINSEQ-4K5 x"
    let ?s = "p  |--FINSEQ-4K6 x"
    show "p just-once-valuesFINSEQ-4R2 x implies x inHIDDENR3 rngFUNCT-1K2 p & p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
    proof(rule impI,rule conjMI)
      assume A1: "p just-once-valuesFINSEQ-4R2 x"
      thus A2: "x inHIDDENR3 rngFUNCT-1K2 p"
        using finseq_4_th_5 sorry
      have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p -|FINSEQ-4K5 x) implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 (p -|FINSEQ-4K5 x).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        have "x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A2 finseq_4_th_21 sorry
        then have "x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        then have "lenFINSEQ-1K4 ?r <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
          using A2 finseq_4_th_34 sorry
        then have "lenFINSEQ-1K4 ?r <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
          using A1 finseq_4_th_30 sorry
        then have A4: "SegFINSEQ-1K2 (lenFINSEQ-1K4 ?r) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
          using finseq_1_th_5 sorry
        fix k assume [ty]: "k be NatNAT-1M1"
        have A5: "SegFINSEQ-1K2 (lenFINSEQ-1K4 ?r) =XBOOLE-0R4 domFINSEQ-1K5 ?r & SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q) =XBOOLE-0R4 domFINSEQ-1K5 ?q"
          using finseq_1_def_3 sorry
        assume A6: "k inTARSKIR2 domFINSEQ-1K5 ?r"
        then have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?r)"
          using finseq_1_def_3 sorry
        then have "k <=XXREAL-0R1 lenFINSEQ-1K4 ?r"
          using finseq_1_th_1 sorry
        then have "k <=XXREAL-0R1 x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
          using A2 finseq_4_th_34 sorry
        then have A7: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p"
          using xreal_1_th_19 sorry
        have "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_29 sorry
        then have A8: "k <XXREAL-0R3 x ..FINSEQ-4K4 p"
          using A7 xxreal_0_th_2 sorry
        have "?r .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
          using A2 A6 finseq_4_th_36 sorry
        thus "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k =XBOOLE-0R4 (p -|FINSEQ-4K5 x).FUNCT-1K1 k"
          using A1 A6 A4 A5 A8 finseq_4_th_31 sorry
      qed "sorry"
      have A9: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (p  |--FINSEQ-4K6 x) implies (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 (lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) +XCMPLX-0K2 k) =XBOOLE-0R4 (p  |--FINSEQ-4K6 x).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        obtain m where 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M"
          using A2 finseq_4_th_22 sorry
        fix k assume [ty]: "k be NatNAT-1M1"
        let ?z = "k +NAT-1K1 m"
        assume A10: "k inTARSKIR2 domFINSEQ-1K5 ?s"
        then have A11: "?s .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)"
          using A2 finseq_4_def_6 sorry
        have A12: "domFINSEQ-1K5 ?s =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?s)"
          using finseq_1_def_3 sorry
        then have A13: "\<one>\<^sub>M <=XXREAL-0R1 k"
          using A10 finseq_1_th_1 sorry
        then have "x ..FINSEQ-4K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 x ..FINSEQ-4K4 p"
          using xreal_1_th_7 sorry
        then have A14: "x ..FINSEQ-4K4 p <=XXREAL-0R1 (k +NAT-1K1 x ..FINSEQ-4K4 p)-XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_19 sorry
        have "k <=XXREAL-0R1 lenFINSEQ-1K4 ?s"
          using A10 A12 finseq_1_th_1 sorry
        then have "k <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p"
          using A2 finseq_4_def_6 sorry
        then have "k +NAT-1K1 x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using xreal_1_th_19 sorry
        then have "(k +NAT-1K1 x ..FINSEQ-4K4 p)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        then have A15: "(k +NAT-1K1 x ..FINSEQ-4K4 p)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
          using A1 finseq_4_th_30 sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p"
          using A2 finseq_4_th_21 sorry
        then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 x ..FINSEQ-4K4 p"
          using A13 xreal_1_th_7 sorry
        then have A16: "\<one>\<^sub>M <=XXREAL-0R1 (k +NAT-1K1 x ..FINSEQ-4K4 p)-XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_19 sorry
        have "domFINSEQ-1K5 ?q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
          using finseq_1_def_3 sorry
        then have "?z inTARSKIR2 domFINSEQ-1K5 ?q"
          using A16 A15 sorry
        then have "?q .FUNCT-1K1 ?z =HIDDENR1 p .FUNCT-1K1 (?z +NAT-1K1 \<one>\<^sub>M)"
          using A1 A14 finseq_4_th_31 sorry
        also have "... = p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)"
           sorry
        finally have "?q .FUNCT-1K1 ?z =HIDDENR1 p .FUNCT-1K1 (k +NAT-1K1 x ..FINSEQ-4K4 p)"
           sorry
        thus "(p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 (lenFINSEQ-1K4 (p -|FINSEQ-4K5 x) +XCMPLX-0K2 k) =XBOOLE-0R4 (p  |--FINSEQ-4K6 x).FUNCT-1K1 k"
          using A2 A11 finseq_4_th_34 sorry
      qed "sorry"
      have "lenFINSEQ-1K4 ?r +NAT-1K1 lenFINSEQ-1K4 ?s =HIDDENR1 (x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 lenFINSEQ-1K4 ?s"
        using A2 finseq_4_th_34 sorry
      also have "... = (x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p)"
        using A2 finseq_4_def_6 sorry
      also have "... = lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      also have "... = lenFINSEQ-1K4 ?q"
        using A1 finseq_4_th_30 sorry
      finally have "lenFINSEQ-1K4 ?r +NAT-1K1 lenFINSEQ-1K4 ?s =HIDDENR1 lenFINSEQ-1K4 ?q"
         sorry
      then have "domFINSEQ-1K5 ?q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?r +NAT-1K1 lenFINSEQ-1K4 ?s)"
        using finseq_1_def_3 sorry
      thus "p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
        using A3 A9 finseq_1_def_7 sorry
    qed
    assume A17: "x inHIDDENR3 rngFUNCT-1K2 p"
    assume A18: "p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p & (k <>HIDDENR2 x ..FINSEQ-4K4 p & p .FUNCT-1K1 k =HIDDENR1 x) implies  False "
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A19: "k inTARSKIR2 domFINSEQ-1K5 p"
        and A20: "k <>HIDDENR2 x ..FINSEQ-4K4 p"
        and A21: "p .FUNCT-1K1 k =HIDDENR1 x"
      have "{TARSKIK2 x ..FINSEQ-4K4 p,k } c=TARSKIR1 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK2 x ..FINSEQ-4K4 p,k } implies y inHIDDENR3 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A22: "y inHIDDENR3 {TARSKIK2 x ..FINSEQ-4K4 p,k }"
          have A23: "x inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
          have "x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 (x ..FINSEQ-4K4 p) =HIDDENR1 x"
            using A17 finseq_4_th_19 finseq_4_th_20 sorry
          then have A24: "x ..FINSEQ-4K4 p inTARSKIR2 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
            using A23 funct_1_def_7 sorry
          have "k inTARSKIR2 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
            using A19 A21 A23 funct_1_def_7 sorry
          thus "y inHIDDENR3 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
            using A22 A24 tarski_def_2 sorry
        qed "sorry"
        thus "{TARSKIK2 x ..FINSEQ-4K4 p,k } c=TARSKIR1 p \<inverse>FUNCT-1K6 {TARSKIK1 x}"
          using tarski_def_3 sorry
      qed
      then have "cardCARD-1K4 {TARSKIK2 x ..FINSEQ-4K4 p,k } <=XXREAL-0R1 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})"
        using nat_1_th_43 sorry
      then have A25: "\<two>\<^sub>M <=XXREAL-0R1 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})"
        using A20 card_2_th_57 sorry
      have A26: "lenFINSEQ-1K4 ?q =HIDDENR1 lenFINSEQ-1K4 p -XCMPLX-0K6 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 x})"
        using finseq_3_th_59 sorry
      also have "... = lenFINSEQ-1K4 p +XCMPLX-0K2 (-XCMPLX-0K4 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}))"
         sorry
      finally have "lenFINSEQ-1K4 ?q =HIDDENR1 lenFINSEQ-1K4 p +XCMPLX-0K2 (-XCMPLX-0K4 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 x}))"
         sorry
      have "lenFINSEQ-1K4 ?q =HIDDENR1 lenFINSEQ-1K4 ?r +NAT-1K1 lenFINSEQ-1K4 ?s"
        using A18 finseq_1_th_22 sorry
      also have "... = (x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 lenFINSEQ-1K4 ?s"
        using A17 finseq_4_th_34 sorry
      also have "... = (x ..FINSEQ-4K4 p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (lenFINSEQ-1K4 p -XCMPLX-0K6 x ..FINSEQ-4K4 p)"
        using A17 finseq_4_def_6 sorry
      also have "... = lenFINSEQ-1K4 p +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
         sorry
      finally have "lenFINSEQ-1K4 ?q =HIDDENR1 lenFINSEQ-1K4 p +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
         sorry
      thus " False "
        using A26 A25 sorry
    qed "sorry"
    thus "p just-once-valuesFINSEQ-4R2 x"
      using A17 finseq_4_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_55:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2"
    then have "p just-once-valuesFINSEQ-4R2 x"
      using finseq_4_th_8 sorry
    thus "p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
      using finseq_4_th_54 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_56:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds (x inHIDDENR3 rngFUNCT-1K2 p & p -FINSEQ-3K1 {TARSKIK1 x} be one-to-oneFUNCT-1V2) & p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x) implies p be one-to-oneFUNCT-1V2"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & (p -FINSEQ-3K1 {TARSKIK1 x} be one-to-oneFUNCT-1V2 & p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)) implies p be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A2: "p -FINSEQ-3K1 {TARSKIK1 x} be one-to-oneFUNCT-1V2"
      and A3: "p -FINSEQ-3K1 {TARSKIK1 x} =FINSEQ-1R1 (p -|FINSEQ-4K5 x)^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
    let ?q = "p -FINSEQ-3K1 {TARSKIK1 x}"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domFINSEQ-1K5 p & (x2 inHIDDENR3 domFINSEQ-1K5 p & p .FUNCT-1K1 x1 =XBOOLE-0R4 p .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A4: "x1 inHIDDENR3 domFINSEQ-1K5 p"
        and A5: "x2 inHIDDENR3 domFINSEQ-1K5 p"
        and A6: "p .FUNCT-1K1 x1 =XBOOLE-0R4 p .FUNCT-1K1 x2"
      obtain k1 k2 where 
        [ty]:"k1 be ElementSUBSET-1M1-of NATNUMBERSK1" and k1Def:"k1 = x1" and
        [ty]:"k2 be ElementSUBSET-1M1-of NATNUMBERSK1" and k2Def:"k2 = x2"
        using A4 A5 sorry
      have A7: "p just-once-valuesFINSEQ-4R2 x"
        using A1 A3 finseq_4_th_54 sorry
      have "x1 =HIDDENR1 x2"
      proof-
        show "x1 =HIDDENR1 x2"
        proof-
          have cases: "(((((((x1 =HIDDENR1 x ..FINSEQ-4K4 p & x2 =HIDDENR1 x ..FINSEQ-4K4 p or x1 =HIDDENR1 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <XXREAL-0R3 k2) or x1 =HIDDENR1 x ..FINSEQ-4K4 p & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p) or k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p =HIDDENR1 x2) or k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <XXREAL-0R3 k2) or k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p) or x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & x ..FINSEQ-4K4 p <XXREAL-0R3 k2) or x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & x ..FINSEQ-4K4 p =HIDDENR1 x2) or x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p"
            using xxreal_0_th_1 sorry
          have case1: "x1 =HIDDENR1 x ..FINSEQ-4K4 p & x2 =HIDDENR1 x ..FINSEQ-4K4 p implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume "x1 =HIDDENR1 x ..FINSEQ-4K4 p & x2 =HIDDENR1 x ..FINSEQ-4K4 p"
            thus "x1 =HIDDENR1 x2"
               sorry
          qed
          have case2: "x1 =HIDDENR1 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <XXREAL-0R3 k2 implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume "x1 =HIDDENR1 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <XXREAL-0R3 k2"
            thus "x1 =HIDDENR1 x2"
              using A1 A5 A6 A7 finseq_4_th_19 finseq_4_th_26 sorry
          qed
          have case3: "x1 =HIDDENR1 x ..FINSEQ-4K4 p & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume "x1 =HIDDENR1 x ..FINSEQ-4K4 p & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p"
            thus "x1 =HIDDENR1 x2"
              using A1 A5 A6 A7 finseq_4_th_19 finseq_4_th_26 sorry
          qed
          have case4: "k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p =HIDDENR1 x2 implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume "k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p =HIDDENR1 x2"
            thus "x1 =HIDDENR1 x2"
              using A1 A4 A6 A7 finseq_4_th_19 finseq_4_th_26 sorry
          qed
          have case5: "k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <XXREAL-0R3 k2 implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume A8: "k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & x ..FINSEQ-4K4 p <XXREAL-0R3 k2"
            have "x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using A1 finseq_4_th_21 sorry
            then have "k1 <XXREAL-0R3 lenFINSEQ-1K4 p"
              using A8 xxreal_0_th_2 sorry
            then have "k1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using nat_1_th_13 sorry
            then have "k1 <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_19 sorry
            then have A9: "k1 <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
              using A7 finseq_4_th_30 sorry
            have "k1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A4 finseq_1_def_3 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 k1"
              using finseq_1_th_1 sorry
            then have "k1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
              using A9 sorry
            then have A10: "k1 inTARSKIR2 domFINSEQ-1K5 ?q"
              using finseq_1_def_3 sorry
            then have A11: "?q .FUNCT-1K1 k1 =XBOOLE-0R4 p .FUNCT-1K1 k1"
              using A7 A8 finseq_4_th_31 sorry
            obtain m2 where
              [ty]:"m2 be NatNAT-1M1" and 
              A12: "k2 =XBOOLE-0R4 m2 +NAT-1K1 \<one>\<^sub>M"
              using A8 nat_1_th_6 sorry
            have 
              [ty]:"m2 be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have A13: "x ..FINSEQ-4K4 p <=XXREAL-0R1 m2"
              using A8 A12 nat_1_th_13 sorry
            have "k2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A5 finseq_1_def_3 sorry
            then have "k2 <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using finseq_1_th_1 sorry
            then have "m2 <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using A12 xreal_1_th_19 sorry
            then have A14: "m2 <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
              using A7 finseq_4_th_30 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p"
              using A1 finseq_4_th_21 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 m2"
              using A13 xxreal_0_th_2 sorry
            then have "m2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
              using A14 sorry
            then have A15: "m2 inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x})"
              using finseq_1_def_3 sorry
            then have "?q .FUNCT-1K1 m2 =XBOOLE-0R4 p .FUNCT-1K1 k2"
              using A7 A12 A13 finseq_4_th_31 sorry
            thus "x1 =HIDDENR1 x2"
              using A2 A6 A8 A10 A13 A15 A11 sorry
          qed
          have case6: "k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume A16: "k1 <XXREAL-0R3 x ..FINSEQ-4K4 p & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p"
            have A17: "x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using A1 finseq_4_th_21 sorry
            then have "k2 <XXREAL-0R3 lenFINSEQ-1K4 p"
              using A16 xxreal_0_th_2 sorry
            then have "k2 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using nat_1_th_13 sorry
            then have "k2 <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_19 sorry
            then have A18: "k2 <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
              using A7 finseq_4_th_30 sorry
            have "k2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A5 finseq_1_def_3 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 k2"
              using finseq_1_th_1 sorry
            then have "k2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
              using A18 sorry
            then have A19: "k2 inTARSKIR2 domFINSEQ-1K5 ?q"
              using finseq_1_def_3 sorry
            then have A20: "p .FUNCT-1K1 k2 =XBOOLE-0R4 (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k2"
              using A7 A16 finseq_4_th_31 sorry
            have "k1 <XXREAL-0R3 lenFINSEQ-1K4 p"
              using A16 A17 xxreal_0_th_2 sorry
            then have "k1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using nat_1_th_13 sorry
            then have "k1 <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_19 sorry
            then have A21: "k1 <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
              using A7 finseq_4_th_30 sorry
            have "k1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A4 finseq_1_def_3 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 k1"
              using finseq_1_th_1 sorry
            then have "k1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
              using A21 sorry
            then have A22: "k1 inTARSKIR2 domFINSEQ-1K5 ?q"
              using finseq_1_def_3 sorry
            then have "p .FUNCT-1K1 k1 =XBOOLE-0R4 (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 k1"
              using A7 A16 finseq_4_th_31 sorry
            thus "x1 =HIDDENR1 x2"
              using A2 A6 A22 A19 A20 sorry
          qed
          have case7: "x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & x ..FINSEQ-4K4 p <XXREAL-0R3 k2 implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume A23: "x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & x ..FINSEQ-4K4 p <XXREAL-0R3 k2"
            then obtain m2 where
              [ty]:"m2 be NatNAT-1M1" and 
              A24: "k2 =XBOOLE-0R4 m2 +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_6 sorry
            obtain m1 where
              [ty]:"m1 be NatNAT-1M1" and 
              A25: "k1 =XBOOLE-0R4 m1 +NAT-1K1 \<one>\<^sub>M"
              using A23 nat_1_th_6 sorry
            have 
              [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and
              [ty]:"m2 be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "k2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A5 finseq_1_def_3 sorry
            then have "k2 <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using finseq_1_th_1 sorry
            then have "m2 <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using A24 xreal_1_th_19 sorry
            then have A26: "m2 <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
              using A7 finseq_4_th_30 sorry
            have A27: "\<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p"
              using A1 finseq_4_th_21 sorry
            have A28: "x ..FINSEQ-4K4 p <=XXREAL-0R1 m2"
              using A23 A24 nat_1_th_13 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 m2"
              using A27 xxreal_0_th_2 sorry
            then have "m2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
              using A26 sorry
            then have A29: "m2 inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x})"
              using finseq_1_def_3 sorry
            then have A30: "p .FUNCT-1K1 k2 =XBOOLE-0R4 (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 m2"
              using A7 A24 A28 finseq_4_th_31 sorry
            have "k1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A4 finseq_1_def_3 sorry
            then have "k1 <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using finseq_1_th_1 sorry
            then have "m1 <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using A25 xreal_1_th_19 sorry
            then have A31: "m1 <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
              using A7 finseq_4_th_30 sorry
            have A32: "x ..FINSEQ-4K4 p <=XXREAL-0R1 m1"
              using A23 A25 nat_1_th_13 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 m1"
              using A27 xxreal_0_th_2 sorry
            then have "m1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
              using A31 sorry
            then have A33: "m1 inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x})"
              using finseq_1_def_3 sorry
            then have "p .FUNCT-1K1 k1 =XBOOLE-0R4 (p -FINSEQ-3K1 {TARSKIK1 x}).FUNCT-1K1 m1"
              using A7 A25 A32 finseq_4_th_31 sorry
            thus "x1 =HIDDENR1 x2"
              using A2 A6 A25 A24 A33 A29 A30 sorry
          qed
          have case8: "x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & x ..FINSEQ-4K4 p =HIDDENR1 x2 implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume "x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & x ..FINSEQ-4K4 p =HIDDENR1 x2"
            thus "x1 =HIDDENR1 x2"
              using A1 A4 A6 A7 finseq_4_th_19 finseq_4_th_26 sorry
          qed
          have case9: "x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p implies x1 =HIDDENR1 x2"
          proof(rule impI)
            assume A34: "x ..FINSEQ-4K4 p <XXREAL-0R3 k1 & k2 <XXREAL-0R3 x ..FINSEQ-4K4 p"
            have "x ..FINSEQ-4K4 p <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using A1 finseq_4_th_21 sorry
            then have "k2 <XXREAL-0R3 lenFINSEQ-1K4 p"
              using A34 xxreal_0_th_2 sorry
            then have "k2 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using nat_1_th_13 sorry
            then have "k2 <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_19 sorry
            then have A35: "k2 <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
              using A7 finseq_4_th_30 sorry
            have "k2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A5 finseq_1_def_3 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 k2"
              using finseq_1_th_1 sorry
            then have "k2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
              using A35 sorry
            then have A36: "k2 inTARSKIR2 domFINSEQ-1K5 ?q"
              using finseq_1_def_3 sorry
            then have A37: "?q .FUNCT-1K1 k2 =XBOOLE-0R4 p .FUNCT-1K1 k2"
              using A7 A34 finseq_4_th_31 sorry
            obtain m2 where
              [ty]:"m2 be NatNAT-1M1" and 
              A38: "k1 =XBOOLE-0R4 m2 +NAT-1K1 \<one>\<^sub>M"
              using A34 nat_1_th_6 sorry
            have 
              [ty]:"m2 be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have A39: "x ..FINSEQ-4K4 p <=XXREAL-0R1 m2"
              using A34 A38 nat_1_th_13 sorry
            have "k1 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A4 finseq_1_def_3 sorry
            then have "k1 <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using finseq_1_th_1 sorry
            then have "m2 <=XXREAL-0R1 lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M"
              using A38 xreal_1_th_19 sorry
            then have A40: "m2 <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
              using A7 finseq_4_th_30 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 x ..FINSEQ-4K4 p"
              using A1 finseq_4_th_21 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 m2"
              using A39 xxreal_0_th_2 sorry
            then have "m2 inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
              using A40 sorry
            then have A41: "m2 inTARSKIR2 domFINSEQ-1K5 (p -FINSEQ-3K1 {TARSKIK1 x})"
              using finseq_1_def_3 sorry
            then have "?q .FUNCT-1K1 m2 =XBOOLE-0R4 p .FUNCT-1K1 k1"
              using A7 A38 A39 finseq_4_th_31 sorry
            thus "x1 =HIDDENR1 x2"
              using A2 A6 A34 A36 A39 A41 A37 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 case5 case6 case7 case8 case9 sorry
        qed
      qed
      thus "x1 =HIDDENR1 x2"
         sorry
    qed "sorry"
    thus "p be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_57:
" for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 (p -|FINSEQ-4K5 x) missesXBOOLE-0R1 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p & p be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 (p -|FINSEQ-4K5 x) missesXBOOLE-0R1 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 rngFUNCT-1K2 p"
      and A2: "p be one-to-oneFUNCT-1V2"
    have "p =FINSEQ-1R1 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))^FINSEQ-1K8 (p  |--FINSEQ-4K6 x)"
      using A1 finseq_4_th_51 sorry
    then have "rngFUNCT-1K2 (p  |--FINSEQ-4K6 x) missesXBOOLE-0R1 rngFUNCT-1K2 ((p -|FINSEQ-4K5 x)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
      using A2 finseq_3_th_91 sorry
    thus "rngFUNCT-1K2 (p -|FINSEQ-4K5 x) missesXBOOLE-0R1 rngFUNCT-1K2 (p  |--FINSEQ-4K6 x)"
      using finseq_1_th_29 xboole_1_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_58:
" for A be setHIDDENM2 holds A be finiteFINSET-1V1 implies ( ex p be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 A & p be one-to-oneFUNCT-1V2)"
proof-
  have " for A be setHIDDENM2 holds A be finiteFINSET-1V1 implies ( ex p be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 A & p be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  ex p be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 Lamb1 & p be one-to-oneFUNCT-1V2"
    have "rngFUNCT-1K2 ({}XBOOLE-0K1) =FINSEQ-1R1 {}XBOOLE-0K1"
       sorry
    then have A1: "?P({}XBOOLE-0K1)"
       sorry
    have " for B be setHIDDENM2 holds  for C be setHIDDENM2 holds B inTARSKIR2 A & C c=TARSKIR1 A implies (( ex p be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 C & p be one-to-oneFUNCT-1V2) implies ( ex p be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 B} & p be one-to-oneFUNCT-1V2))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
      fix B assume [ty]: "B be setHIDDENM2"
      fix C assume [ty]: "C be setHIDDENM2"
      assume "B inTARSKIR2 A"
        and "C c=TARSKIR1 A"
      assume Given: " ex p be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 C & p be one-to-oneFUNCT-1V2"
      then obtain p where
        [ty]:"p be FinSequenceFINSEQ-1M1" and 
        A2: "rngFUNCT-1K2 p =XBOOLE-0R4 C"and A3: "p be one-to-oneFUNCT-1V2"
         sorry
      have A4: " not B inTARSKIR2 C implies ( ex q be setHIDDENM2 st rngFUNCT-1K2 q =HIDDENR1 C \\/XBOOLE-0K2 {TARSKIK1 B} & q be one-to-oneFUNCT-1V2)"
      proof(rule impI)
        assume A5: " not B inTARSKIR2 C"
        obtain q where 
          [ty]:"q be setHIDDENM2" and qDef:"q = p ^FINSEQ-1K8 (<*FINSEQ-1K10 B*>)"
           sorry
        show " ex q be setHIDDENM2 st rngFUNCT-1K2 q =HIDDENR1 C \\/XBOOLE-0K2 {TARSKIK1 B} & q be one-to-oneFUNCT-1V2"
        proof(rule bexI[of _ "q"],rule conjMI)
          have "rngFUNCT-1K2 q =HIDDENR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 B*>)"
            using finseq_1_th_31 sorry
          also have "... = C \\/XBOOLE-0K2 {TARSKIK1 B}"
            using A2 finseq_1_th_38 sorry
          finally show "rngFUNCT-1K2 q =HIDDENR1 C \\/XBOOLE-0K2 {TARSKIK1 B}"
             sorry
          show "q be one-to-oneFUNCT-1V2"
          proof-
            have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domFINSEQ-1K5 q & y inHIDDENR3 domFINSEQ-1K5 q) & q .FUNCT-1K1 x =XBOOLE-0R4 q .FUNCT-1K1 y implies x =HIDDENR1 y"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A6: "x inHIDDENR3 domFINSEQ-1K5 q & y inHIDDENR3 domFINSEQ-1K5 q"
                and A7: "q .FUNCT-1K1 x =XBOOLE-0R4 q .FUNCT-1K1 y"
              obtain k l where 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = x" and
                [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = y"
                using A6 sorry
              have A8: "k inTARSKIR2 domFINSEQ-1K5 p implies (( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>) & l =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n) implies x =HIDDENR1 y)"
              proof(rule impI,rule impI)
                assume A9: "k inTARSKIR2 domFINSEQ-1K5 p"
                assume Given: " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>) & l =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n"
                then obtain n where
                  [ty]:"n be NatNAT-1M1" and 
                  A10: "n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>)"and A11: "l =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n"
                   sorry
                have "n inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
                  using A10 finseq_1_th_2 finseq_1_th_38 sorry
                then have A12: "n =XBOOLE-0R4 \<one>\<^sub>M"
                  using tarski_def_1 sorry
                have "(<*FINSEQ-1K10 B*>).FUNCT-1K1 n =HIDDENR1 q .FUNCT-1K1 k"
                  using A7 A10 A11 finseq_1_def_7 sorry
                also have "... = p .FUNCT-1K1 k"
                  using A9 finseq_1_def_7 sorry
                finally have "(<*FINSEQ-1K10 B*>).FUNCT-1K1 n =HIDDENR1 p .FUNCT-1K1 k"
                   sorry
                then have "B =XBOOLE-0R4 p .FUNCT-1K1 k"
                  using A12 finseq_1_def_8 sorry
                thus "x =HIDDENR1 y"
                  using A2 A5 A9 funct_1_def_3 sorry
              qed
              have A13: "l inTARSKIR2 domFINSEQ-1K5 p implies (( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>) & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n) implies x =HIDDENR1 y)"
              proof(rule impI,rule impI)
                assume A14: "l inTARSKIR2 domFINSEQ-1K5 p"
                assume Given: " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>) & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n"
                then obtain n where
                  [ty]:"n be NatNAT-1M1" and 
                  A15: "n inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>)"and A16: "k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 n"
                   sorry
                have "n inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
                  using A15 finseq_1_th_2 finseq_1_th_38 sorry
                then have A17: "n =XBOOLE-0R4 \<one>\<^sub>M"
                  using tarski_def_1 sorry
                have "(<*FINSEQ-1K10 B*>).FUNCT-1K1 n =HIDDENR1 q .FUNCT-1K1 l"
                  using A7 A15 A16 finseq_1_def_7 sorry
                also have "... = p .FUNCT-1K1 l"
                  using A14 finseq_1_def_7 sorry
                finally have "(<*FINSEQ-1K10 B*>).FUNCT-1K1 n =HIDDENR1 p .FUNCT-1K1 l"
                   sorry
                then have "B =XBOOLE-0R4 p .FUNCT-1K1 l"
                  using A17 finseq_1_def_8 sorry
                thus "x =HIDDENR1 y"
                  using A2 A5 A14 funct_1_def_3 sorry
              qed
              have A18: "( ex m1 be NatNAT-1M1 st m1 inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>) & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 m1) implies (( ex m2 be NatNAT-1M1 st m2 inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>) & l =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 m2) implies x =HIDDENR1 y)"
              proof(rule impI,rule impI)
                assume Given: " ex m1 be NatNAT-1M1 st m1 inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>) & k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 m1"
                then obtain m1 where
                  [ty]:"m1 be NatNAT-1M1" and 
                  A19: "m1 inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>)"and A20: "k =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 m1"
                   sorry
                have "m1 inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
                  using A19 finseq_1_th_2 finseq_1_def_8 sorry
                then have A21: "m1 =XBOOLE-0R4 \<one>\<^sub>M"
                  using tarski_def_1 sorry
                assume Given: " ex m2 be NatNAT-1M1 st m2 inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>) & l =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 m2"
                then obtain m2 where
                  [ty]:"m2 be NatNAT-1M1" and 
                  A22: "m2 inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 B*>)"and A23: "l =XBOOLE-0R4 lenFINSEQ-1K4 p +XCMPLX-0K2 m2"
                   sorry
                have "m2 inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
                  using A22 finseq_1_th_2 finseq_1_def_8 sorry
                thus "x =HIDDENR1 y"
                  using A20 A23 A21 tarski_def_1 sorry
              qed
              have "k inTARSKIR2 domFINSEQ-1K5 p & l inTARSKIR2 domFINSEQ-1K5 p implies x =HIDDENR1 y"
              proof(rule impI)
                assume A24: "k inTARSKIR2 domFINSEQ-1K5 p & l inTARSKIR2 domFINSEQ-1K5 p"
                then have "q .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k & q .FUNCT-1K1 l =XBOOLE-0R4 p .FUNCT-1K1 l"
                  using finseq_1_def_7 sorry
                thus "x =HIDDENR1 y"
                  using A3 A7 A24 sorry
              qed
              thus "x =HIDDENR1 y"
                using A6 A8 A13 A18 finseq_1_th_25 sorry
            qed "sorry"
            thus "q be one-to-oneFUNCT-1V2"
              using funct_1_def_4 sorry
          qed
        qed "sorry"
      qed
      have "B inTARSKIR2 C implies ( ex q be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 q =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 B} & q be one-to-oneFUNCT-1V2)"
      proof(rule impI)
        assume A25: "B inTARSKIR2 C"
        obtain q where 
          [ty]:"q be FinSequenceFINSEQ-1M1" and qDef:"q = p"
           sorry
        show " ex q be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 q =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 B} & q be one-to-oneFUNCT-1V2"
        proof(rule bexI[of _ "q"])
          show "rngFUNCT-1K2 q =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 B} & q be one-to-oneFUNCT-1V2"
            using A2 A3 A25 zfmisc_1_th_40 sorry
        qed "sorry"
      qed
      thus " ex p be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 B} & p be one-to-oneFUNCT-1V2"
        using A4 sorry
    qed "sorry"
    then have A26: " for B be setHIDDENM2 holds  for C be setHIDDENM2 holds (B inTARSKIR2 A & C c=TARSKIR1 A) & ?P(C) implies ?P(C \\/XBOOLE-0K2 {TARSKIK1 B})"
       sorry
    assume A27: "A be finiteFINSET-1V1"
    show " ex p be FinSequenceFINSEQ-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 A & p be one-to-oneFUNCT-1V2"
      using finset_1_sch_2 A27 A1 A26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_59:
" for p be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 domFINSEQ-1K5 p & p be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  not ((rngFUNCT-1K2 p c=TARSKIR1 domFINSEQ-1K5 p & p be one-to-oneFUNCT-1V2) &  not rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p)"
  proof(rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    let ?P = "\<lambda>Lamb1.  for q be FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 q =XBOOLE-0R4 Lamb1 & rngFUNCT-1K2 q c=TARSKIR1 domFINSEQ-1K5 q) & q be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 q =XBOOLE-0R4 domFINSEQ-1K5 q"
    have A1: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p"
       sorry
    have " for k be NatNAT-1M1 holds ( for q be FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 q =XBOOLE-0R4 k & rngFUNCT-1K2 q c=TARSKIR1 domFINSEQ-1K5 q) & q be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 q =XBOOLE-0R4 domFINSEQ-1K5 q) implies ( for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 q =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M & (rngFUNCT-1K2 q c=TARSKIR1 domFINSEQ-1K5 q & q be one-to-oneFUNCT-1V2) implies rngFUNCT-1K2 q =XBOOLE-0R4 domFINSEQ-1K5 q)"
    proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A2: " for q be FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 q =XBOOLE-0R4 k & rngFUNCT-1K2 q c=TARSKIR1 domFINSEQ-1K5 q) & q be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 q =XBOOLE-0R4 domFINSEQ-1K5 q"
      fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
      assume A3: "lenFINSEQ-1K4 q =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
        and A4: "rngFUNCT-1K2 q c=TARSKIR1 domFINSEQ-1K5 q"
        and A5: "q be one-to-oneFUNCT-1V2"
      have A6: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M)"
        using A3 finseq_1_def_3 sorry
      have "domFINSEQ-1K5 q c=TARSKIR1 rngFUNCT-1K2 q"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 q implies x inHIDDENR3 rngFUNCT-1K2 q"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A7: "x inHIDDENR3 domFINSEQ-1K5 q"
          then obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x"
             sorry
          show "x inHIDDENR3 rngFUNCT-1K2 q"
          proof-
            have cases: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 q or  not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 q"
               sorry
            have case1: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 q implies x inHIDDENR3 rngFUNCT-1K2 q"
            proof(rule impI)
              assume A8: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 q"
              have "x inHIDDENR3 rngFUNCT-1K2 q"
              proof-
                show "x inHIDDENR3 rngFUNCT-1K2 q"
                proof-
                  have cases: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M or n <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  have case1: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies x inHIDDENR3 rngFUNCT-1K2 q"
                  proof(rule impI)
                    assume "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                    thus "x inHIDDENR3 rngFUNCT-1K2 q"
                      using A8 sorry
                  qed
                  have case2: "n <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies x inHIDDENR3 rngFUNCT-1K2 q"
                  proof(rule impI)
                    assume "n <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M"
                    then have " not x inHIDDENR3 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                      using tarski_def_1 sorry
                    then have "x inHIDDENR3 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                      using A6 A7 xboole_0_def_5 sorry
                    then have A9: "x inHIDDENR3 SegFINSEQ-1K2 k"
                      using finseq_1_th_10 sorry
                    let ?r = "q -FINSEQ-3K1 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                    have A10: "lenFINSEQ-1K4 ?r =XBOOLE-0R4 (k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
                      using A3 A5 A8 finseq_3_th_90 sorry
                    then have A11: "domFINSEQ-1K5 ?r =XBOOLE-0R4 SegFINSEQ-1K2 k"
                      using finseq_1_def_3 sorry
                    have A12: "rngFUNCT-1K2 ?r =XBOOLE-0R4 rngFUNCT-1K2 q \\SUBSET-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                      using finseq_3_th_65 sorry
                    then have "rngFUNCT-1K2 ?r c=TARSKIR1 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                      using A4 A6 xboole_1_th_33 sorry
                    then have "rngFUNCT-1K2 ?r c=TARSKIR1 domFINSEQ-1K5 ?r"
                      using A11 finseq_1_th_10 sorry
                    then have "rngFUNCT-1K2 ?r =XBOOLE-0R4 domFINSEQ-1K5 ?r"
                      using A2 A5 A10 finseq_3_th_87 sorry
                    thus "x inHIDDENR3 rngFUNCT-1K2 q"
                      using A12 A11 A9 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "x inHIDDENR3 rngFUNCT-1K2 q"
                 sorry
            qed
            have case2: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 q implies x inHIDDENR3 rngFUNCT-1K2 q"
            proof(rule impI)
              assume A13: " not k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 q"
              have A14: "rngFUNCT-1K2 q c=TARSKIR1 SegFINSEQ-1K2 k"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 q implies x inHIDDENR3 SegFINSEQ-1K2 k"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume A15: "x inHIDDENR3 rngFUNCT-1K2 q"
                  then have " not x inHIDDENR3 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                    using A13 tarski_def_1 sorry
                  then have "x inHIDDENR3 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
                    using A4 A6 A15 xboole_0_def_5 sorry
                  thus "x inHIDDENR3 SegFINSEQ-1K2 k"
                    using finseq_1_th_10 sorry
                qed "sorry"
                thus "rngFUNCT-1K2 q c=TARSKIR1 SegFINSEQ-1K2 k"
                  using tarski_def_3 sorry
              qed
              have A16: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M)"
                using finseq_1_th_4 sorry
              then have A17: "q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 q"
                using A6 funct_1_def_3 sorry
              obtain r where 
                [ty]:"r be FinSequenceFINSEQ-1M1" and rDef:"r = q  |RELAT-1K8 SegFINSEQ-1K2 k"
                using finseq_1_th_15 sorry
              have A18: "domFINSEQ-1K5 r c=TARSKIR1 domFINSEQ-1K5 q & k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
                using relat_1_th_60 xreal_1_th_29 sorry
              have A19: "lenFINSEQ-1K4 r =XBOOLE-0R4 k"
                using A3 finseq_3_th_53 sorry
              then have A20: "domFINSEQ-1K5 r =XBOOLE-0R4 SegFINSEQ-1K2 k"
                using finseq_1_def_3 sorry
              have "rngFUNCT-1K2 r c=TARSKIR1 rngFUNCT-1K2 q & r be one-to-oneFUNCT-1V2"
                using A5 funct_1_th_52 relat_1_th_70 sorry
              then have "rngFUNCT-1K2 r =XBOOLE-0R4 domFINSEQ-1K5 r"
                using A2 A19 A20 A14 xboole_1_th_1 sorry
              then obtain x1 where
                [ty]:"x1 be objectHIDDENM1" and 
                A21: "x1 inHIDDENR3 domFINSEQ-1K5 r"and A22: "r .FUNCT-1K1 x1 =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                using A20 A14 A17 funct_1_def_3 sorry
              obtain n where 
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x1"
                using A21 sorry
              have "r .FUNCT-1K1 x1 =XBOOLE-0R4 q .FUNCT-1K1 x1 & n <=XXREAL-0R1 k"
                using A20 A21 finseq_1_th_1 funct_1_th_49 sorry
              thus "x inHIDDENR3 rngFUNCT-1K2 q"
                using A5 A6 A16 A21 A22 A18 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "domFINSEQ-1K5 q c=TARSKIR1 rngFUNCT-1K2 q"
          using tarski_def_3 sorry
      qed
      thus "rngFUNCT-1K2 q =XBOOLE-0R4 domFINSEQ-1K5 q"
        using A4 sorry
    qed "sorry"
    then have A23: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have " for q be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 q =XBOOLE-0R4 0NUMBERSK6 implies (rngFUNCT-1K2 q c=TARSKIR1 domFINSEQ-1K5 q & q be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 q =XBOOLE-0R4 domFINSEQ-1K5 q)"
    proof(rule ballI,rule impI,rule impMI ,rule impI)
      fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
      assume A24: "lenFINSEQ-1K4 q =XBOOLE-0R4 0NUMBERSK6"
      assume "rngFUNCT-1K2 q c=TARSKIR1 domFINSEQ-1K5 q"
        and "q be one-to-oneFUNCT-1V2"
      have "q =FINSEQ-1R1 {}XBOOLE-0K1"
        using A24 sorry
      thus "rngFUNCT-1K2 q =XBOOLE-0R4 domFINSEQ-1K5 q"
         sorry
    qed "sorry"
    then have A25: "?P(0NUMBERSK6)"
       sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A25 A23 sorry
    thus " not ((rngFUNCT-1K2 p c=TARSKIR1 domFINSEQ-1K5 p & p be one-to-oneFUNCT-1V2) &  not rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_60:
" for p be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p implies p be one-to-oneFUNCT-1V2"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  not (rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p &  not p be one-to-oneFUNCT-1V2)"
  proof(rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    let ?P = "\<lambda>Lamb1.  for p be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 Lamb1 & rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p implies p be one-to-oneFUNCT-1V2"
    have A1: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p"
       sorry
    have A2: " for k be NatNAT-1M1 holds ( for p be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 k & rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p implies p be one-to-oneFUNCT-1V2) implies ( for p be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p implies p be one-to-oneFUNCT-1V2)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A3: "?P(k)"
      show " for p be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p implies p be one-to-oneFUNCT-1V2"
      proof(rule ballI,rule impMI ,rule impI)
        let ?x = "k +NAT-1K1 \<one>\<^sub>M"
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
        let ?q = "p -FINSEQ-3K1 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
        assume A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          and A5: "rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p"
        have A6: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M)"
          using A4 finseq_1_def_3 sorry
        then have A7: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 p"
          using A5 finseq_1_th_4 sorry
        have " for l be NatNAT-1M1 holds l inTARSKIR2 domFINSEQ-1K5 p & (l <>HIDDENR2 (k +NAT-1K1 \<one>\<^sub>M)..FINSEQ-4K4 p & p .FUNCT-1K1 l =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M) implies  False "
        proof(rule ballI,rule impMI ,rule impMI ,rule impI)
          have "rngFUNCT-1K2 ?q =HIDDENR1 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
            using A5 A6 finseq_3_th_65 sorry
          also have "... = SegFINSEQ-1K2 k"
            using finseq_1_th_10 sorry
          finally have "rngFUNCT-1K2 ?q =HIDDENR1 SegFINSEQ-1K2 k"
             sorry
          then have "cardCARD-1K4 (rngFUNCT-1K2 ?q) =XBOOLE-0R4 k"
            using finseq_1_th_57 sorry
          then have A8: "cardCARD-1K4 k =XBOOLE-0R4 cardCARD-1K4 (rngFUNCT-1K2 ?q)"
             sorry
          have "p .FUNCT-1K1 (?x ..FINSEQ-4K4 p) =XBOOLE-0R4 ?x"
            using A5 A6 finseq_4_th_19 finseq_1_th_4 sorry
          then have A9: "p .FUNCT-1K1 (?x ..FINSEQ-4K4 p) inTARSKIR2 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
            using tarski_def_1 sorry
          fix l assume [ty]: "l be NatNAT-1M1"
          assume A10: "l inTARSKIR2 domFINSEQ-1K5 p"
            and A11: "l <>HIDDENR2 (k +NAT-1K1 \<one>\<^sub>M)..FINSEQ-4K4 p"
            and A12: "p .FUNCT-1K1 l =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          have A13: "cardCARD-1K4 {TARSKIK2 ?x ..FINSEQ-4K4 p,l } =XBOOLE-0R4 \<two>\<^sub>M"
            using A11 card_2_th_57 sorry
          have "p .FUNCT-1K1 l inTARSKIR2 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
            using A12 tarski_def_1 sorry
          then have A14: "l inTARSKIR2 p \<inverse>FUNCT-1K6 {TARSKIK1 ?x}"
            using A10 funct_1_def_7 sorry
          have "?x ..FINSEQ-4K4 p inTARSKIR2 domFINSEQ-1K5 p"
            using A5 A6 finseq_4_th_20 finseq_1_th_4 sorry
          then have "?x ..FINSEQ-4K4 p inTARSKIR2 p \<inverse>FUNCT-1K6 {TARSKIK1 ?x}"
            using A9 funct_1_def_7 sorry
          then have "{TARSKIK2 ?x ..FINSEQ-4K4 p,l } c=TARSKIR1 p \<inverse>FUNCT-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
            using A14 zfmisc_1_th_32 sorry
          then have A15: "\<two>\<^sub>M <=XXREAL-0R1 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M })"
            using A13 nat_1_th_43 sorry
          have "lenFINSEQ-1K4 ?q =XBOOLE-0R4 (k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M })"
            using A4 finseq_3_th_59 sorry
          then have "\<two>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 ?q <=XXREAL-0R1 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 ?x}) +XCMPLX-0K2 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 cardCARD-1K4 (p \<inverse>FUNCT-1K6 {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }))"
            using A15 xreal_1_th_6 sorry
          then have "(lenFINSEQ-1K4 ?q +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
             sorry
          then have "lenFINSEQ-1K4 ?q +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
            using xreal_1_th_6 sorry
          then have A16: "lenFINSEQ-1K4 ?q <=XXREAL-0R1 k -XCMPLX-0K6 \<one>\<^sub>M"
            using xreal_1_th_19 sorry
          have "domFINSEQ-1K5 ?q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?q)"
            using finseq_1_def_3 sorry
          then have "cardCARD-1K4 (SegmCARD-1K5 k) c=ORDINAL1R1 cardCARD-1K4 (domFINSEQ-1K5 ?q) & cardCARD-1K4 (SegmCARD-1K5 lenFINSEQ-1K4 ?q) =XBOOLE-0R4 cardCARD-1K4 (domFINSEQ-1K5 ?q)"
            using card_1_th_12 finseq_1_th_57 A8 sorry
          then have "k <=XXREAL-0R1 lenFINSEQ-1K4 ?q"
            using nat_1_th_40 sorry
          then have "k <=XXREAL-0R1 k -XCMPLX-0K6 \<one>\<^sub>M"
            using A16 xxreal_0_th_2 sorry
          then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 0NUMBERSK6"
            using xreal_1_th_19 sorry
          thus " False "
            using xreal_1_th_6 sorry
        qed "sorry"
        then have A17: "p just-once-valuesFINSEQ-4R2 k +NAT-1K1 \<one>\<^sub>M"
          using A7 finseq_4_th_27 sorry
        then have A18: "lenFINSEQ-1K4 ?q =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A4 finseq_4_th_30 sorry
        also have "... = k"
           sorry
        finally have "lenFINSEQ-1K4 ?q =HIDDENR1 k"
           sorry
        have A19: "?q =FINSEQ-1R1 (p -|FINSEQ-4K5 (k +NAT-1K1 \<one>\<^sub>M))^FINSEQ-1K8 (p  |--FINSEQ-4K6 (k +NAT-1K1 \<one>\<^sub>M))"
          using A17 finseq_4_th_54 sorry
        have "rngFUNCT-1K2 ?q =HIDDENR1 SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 k +NAT-1K1 \<one>\<^sub>M }"
          using A5 A6 finseq_3_th_65 sorry
        also have "... = SegFINSEQ-1K2 k"
          using finseq_1_th_10 sorry
        finally have "rngFUNCT-1K2 ?q =HIDDENR1 SegFINSEQ-1K2 k"
           sorry
        then have "domFINSEQ-1K5 ?q =XBOOLE-0R4 rngFUNCT-1K2 ?q"
          using A18 finseq_1_def_3 sorry
        thus "p be one-to-oneFUNCT-1V2"
          using A3 A7 A18 A19 finseq_4_th_56 sorry
      qed "sorry"
    qed "sorry"
    have A20: "?P(0NUMBERSK6)"
    proof-
      have " for p be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6 implies  not (rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p &  not p be one-to-oneFUNCT-1V2)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
        assume "lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6"
        then have "p =FINSEQ-1R1 {}XBOOLE-0K1"
           sorry
        thus " not (rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p &  not p be one-to-oneFUNCT-1V2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A20 A2 sorry
    thus " not (rngFUNCT-1K2 p =XBOOLE-0R4 domFINSEQ-1K5 p &  not p be one-to-oneFUNCT-1V2)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_61:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q) & q be one-to-oneFUNCT-1V2 implies p be one-to-oneFUNCT-1V2"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 q & (lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & q be one-to-oneFUNCT-1V2) implies p be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "rngFUNCT-1K2 p =XBOOLE-0R4 rngFUNCT-1K2 q"
      and A2: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
      and A3: "q be one-to-oneFUNCT-1V2"
    have A4: "rngFUNCT-1K2 p =XBOOLE-0R4 domRELAT-1K1 (q \<inverse>FUNCT-1K4)"
      using A1 A3 funct_1_th_33 sorry
    then have A5: "domRELAT-1K1 (q \<inverse>FUNCT-1K4 *FUNCT-1K3 p) =HIDDENR1 domFINSEQ-1K5 p"
      using relat_1_th_27 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    finally have "domRELAT-1K1 (q \<inverse>FUNCT-1K4 *FUNCT-1K3 p) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
       sorry
    then obtain r where 
      [ty]:"r be FinSequenceFINSEQ-1M1" and rDef:"r = q \<inverse>FUNCT-1K4 *FUNCT-1K3 p"
      using finseq_1_def_2 sorry
    have "rngFUNCT-1K2 r =HIDDENR1 rngFUNCT-1K2 (q \<inverse>FUNCT-1K4)"
      using A4 relat_1_th_28 sorry
    also have "... = domFINSEQ-1K5 q"
      using A3 funct_1_th_33 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using finseq_1_def_3 sorry
    finally have "rngFUNCT-1K2 r =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
       sorry
    then have "r be one-to-oneFUNCT-1V2"
      using A2 A5 finseq_4_th_60 sorry
    thus "p be one-to-oneFUNCT-1V2"
      using A4 funct_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_4_lm_1:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds cardCARD-1K4 A =XBOOLE-0R4 cardCARD-1K4 B & rngFUNCT-1K2 f =XBOOLE-0R4 B implies f be one-to-oneFUNCT-1V2"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix A assume [ty]: "A be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix B assume [ty]: "B be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
  assume A1: "cardCARD-1K4 A =XBOOLE-0R4 cardCARD-1K4 B"
    and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 B"
  have A3: "(A,B)are-equipotentTARSKIR3"
    using A1 card_1_th_5 sorry
  obtain p where
    [ty]:"p be FinSequenceFINSEQ-1M1" and 
    A4: "rngFUNCT-1K2 p =XBOOLE-0R4 A"and A5: "p be one-to-oneFUNCT-1V2"
    using finseq_4_th_58 sorry
  have "(domFINSEQ-1K5 p,p .:FUNCT-1K5 domFINSEQ-1K5 p)are-equipotentTARSKIR3"
    using A5 card_1_th_33 sorry
  then have "(domFINSEQ-1K5 p,A)are-equipotentTARSKIR3"
    using A4 relat_1_th_113 sorry
  then have A6: "(domFINSEQ-1K5 p,B)are-equipotentTARSKIR3"
    using A3 wellord2_th_15 sorry
  obtain X where 
    [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and XDef:"X = domFINSEQ-1K5 p"
     sorry
  obtain q where
    [ty]:"q be FinSequenceFINSEQ-1M1" and 
    A7: "rngFUNCT-1K2 q =XBOOLE-0R4 B"and A8: "q be one-to-oneFUNCT-1V2"
    using finseq_4_th_58 sorry
  have A9: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
    using finseq_1_def_3 sorry
  have "(domFINSEQ-1K5 q,q .:FUNCT-1K5 domFINSEQ-1K5 q)are-equipotentTARSKIR3"
    using A8 card_1_th_33 sorry
  then have "(domFINSEQ-1K5 q,B)are-equipotentTARSKIR3"
    using A7 relat_1_th_113 sorry
  then have "(domFINSEQ-1K5 p,domFINSEQ-1K5 q)are-equipotentTARSKIR3"
    using A6 wellord2_th_15 sorry
  then have "cardCARD-1K4 X =HIDDENR1 cardCARD-1K4 (SegFINSEQ-1K2 (lenFINSEQ-1K4 q))"
    using A9 card_1_th_5 sorry
  also have "... = lenFINSEQ-1K4 q"
    using finseq_1_th_57 sorry
  finally have "cardCARD-1K4 X =HIDDENR1 lenFINSEQ-1K4 q"
     sorry
  then have A10: "lenFINSEQ-1K4 q =HIDDENR1 cardCARD-1K4 (SegFINSEQ-1K2 (lenFINSEQ-1K4 p))"
    using finseq_1_def_3 sorry
  also have "... = lenFINSEQ-1K4 p"
    using finseq_1_th_57 sorry
  finally have "lenFINSEQ-1K4 q =HIDDENR1 lenFINSEQ-1K4 p"
     sorry
  have "f be one-to-oneFUNCT-1V2"
  proof-
    show "f be one-to-oneFUNCT-1V2"
    proof-
      have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies f be one-to-oneFUNCT-1V2"
      proof(rule impI)
        assume "B =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "f be one-to-oneFUNCT-1V2"
           sorry
      qed
      have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies f be one-to-oneFUNCT-1V2"
      proof(rule impI)
        assume A11: "B <>HIDDENR2 {}XBOOLE-0K1"
        then have "rngFUNCT-1K2 p =XBOOLE-0R4 domRELAT-1K1 f"
          using A4 funct_2_def_1 sorry
        then have A12: "rngFUNCT-1K2 (f *FUNCT-1K3 p) =HIDDENR1 B"
          using A2 relat_1_th_28 sorry
        also have "... = domRELAT-1K1 (q \<inverse>FUNCT-1K4)"
          using A7 A8 funct_1_th_33 sorry
        finally have "rngFUNCT-1K2 (f *FUNCT-1K3 p) =HIDDENR1 domRELAT-1K1 (q \<inverse>FUNCT-1K4)"
           sorry
        have "domRELAT-1K1 (q \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 q"
          using A8 funct_1_th_33 sorry
        then have "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 (q \<inverse>FUNCT-1K4)"
          using A7 relat_1_def_19 sorry
        then have "domRELAT-1K1 (q \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
          using relat_1_th_27 sorry
        then have "rngFUNCT-1K2 p =XBOOLE-0R4 domRELAT-1K1 (q \<inverse>FUNCT-1K4 *FUNCT-1K3 f)"
          using A4 A11 funct_2_def_1 sorry
        then have A13: "domRELAT-1K1 ((q \<inverse>FUNCT-1K4 *FUNCT-1K3 f)*FUNCT-1K3 p) =HIDDENR1 domFINSEQ-1K5 p"
          using relat_1_th_27 sorry
        also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
          using finseq_1_def_3 sorry
        finally have "domRELAT-1K1 ((q \<inverse>FUNCT-1K4 *FUNCT-1K3 f)*FUNCT-1K3 p) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
           sorry
        then obtain g where 
          [ty]:"g be FinSequenceFINSEQ-1M1" and gDef:"g = (q \<inverse>FUNCT-1K4 *FUNCT-1K3 f)*FUNCT-1K3 p"
          using finseq_1_def_2 sorry
        have "g =FUNCT-1R1 q \<inverse>FUNCT-1K4 *FUNCT-1K3 (f *FUNCT-1K3 p)"
          using relat_1_th_36 sorry
        then have "rngFUNCT-1K2 g =HIDDENR1 rngFUNCT-1K2 (q \<inverse>FUNCT-1K4)"
          using A12 relat_1_th_28 sorry
        also have "... = domFINSEQ-1K5 q"
          using A8 funct_1_th_33 sorry
        also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
          using finseq_1_def_3 sorry
        finally have "rngFUNCT-1K2 g =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
           sorry
        then have A14: "g be one-to-oneFUNCT-1V2"
          using A10 A13 finseq_4_th_60 sorry
        have "q *FUNCT-1K3 g =HIDDENR1 q *FUNCT-1K3 (q \<inverse>FUNCT-1K4 *FUNCT-1K3 (f *FUNCT-1K3 p))"
          using relat_1_th_36 sorry
        also have "... = (q *FUNCT-1K3 q \<inverse>FUNCT-1K4)*FUNCT-1K3 (f *FUNCT-1K3 p)"
          using relat_1_th_36 sorry
        also have "... = idPARTFUN1K6 (rngFUNCT-1K2 q) *FUNCT-1K3 (f *FUNCT-1K3 p)"
          using A8 funct_1_th_39 sorry
        also have "... = (idPARTFUN1K6 (rngFUNCT-1K2 q) *PARTFUN1K1\<^bsub>(A,B,rngFUNCT-1K2 q,rngFUNCT-1K2 q)\<^esub> f)*FUNCT-1K3 p"
          using relat_1_th_36 sorry
        also have "... = f *FUNCT-1K3 p"
          using A2 A7 relat_1_th_54 sorry
        finally have "q *FUNCT-1K3 g =HIDDENR1 f *FUNCT-1K3 p"
           sorry
        then have "(q *FUNCT-1K3 g)*FUNCT-1K3 p \<inverse>FUNCT-1K4 =HIDDENR1 f *FUNCT-1K3 (p *FUNCT-1K3 p \<inverse>FUNCT-1K4)"
          using relat_1_th_36 sorry
        also have "... = f *PARTFUN1K1\<^bsub>(rngFUNCT-1K2 p,rngFUNCT-1K2 p,A,B)\<^esub> idPARTFUN1K6 (rngFUNCT-1K2 p)"
          using A5 funct_1_th_39 sorry
        also have "... = f *PARTFUN1K1\<^bsub>(domRELAT-1K1 f,domRELAT-1K1 f,A,B)\<^esub> idPARTFUN1K6 (domRELAT-1K1 f)"
          using A4 A11 funct_2_def_1 sorry
        also have "... = f"
          using relat_1_th_52 sorry
        finally have "(q *FUNCT-1K3 g)*FUNCT-1K3 p \<inverse>FUNCT-1K4 =HIDDENR1 f"
           sorry
        thus "f be one-to-oneFUNCT-1V2"
          using A5 A8 A14 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "f be one-to-oneFUNCT-1V2"
     sorry
qed "sorry"

mtheorem finseq_4_th_62:
" for p be FinSequenceFINSEQ-1M1 holds p be one-to-oneFUNCT-1V2 iff cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds (p be one-to-oneFUNCT-1V2 implies cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 lenFINSEQ-1K4 p) & (cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 lenFINSEQ-1K4 p implies p be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    show "p be one-to-oneFUNCT-1V2 implies cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
    proof(rule impI)
      assume "p be one-to-oneFUNCT-1V2"
      then have "(domFINSEQ-1K5 p,p .:FUNCT-1K5 domFINSEQ-1K5 p)are-equipotentTARSKIR3"
        using card_1_th_33 sorry
      then have "(domFINSEQ-1K5 p,rngFUNCT-1K2 p)are-equipotentTARSKIR3"
        using relat_1_th_113 sorry
      then have "(SegFINSEQ-1K2 (lenFINSEQ-1K4 p),rngFUNCT-1K2 p)are-equipotentTARSKIR3"
        using finseq_1_def_3 sorry
      then have "cardCARD-1K4 (SegFINSEQ-1K2 (lenFINSEQ-1K4 p)) =XBOOLE-0R4 cardCARD-1K4 (rngFUNCT-1K2 p)"
        using card_1_th_5 sorry
      thus "cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
        using finseq_1_th_57 sorry
    qed
    obtain f where 
      [ty]:"f be FunctionFUNCT-2M1-of(domFINSEQ-1K5 p,rngFUNCT-1K2 p)" and fDef:"f = p"
      using funct_2_th_1 sorry
    obtain B where 
      [ty]:"B be finiteFINSET-1V1\<bar>setHIDDENM2" and BDef:"B = domFINSEQ-1K5 p"
       sorry
    assume "cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
    then have "cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 cardCARD-1K4 (SegFINSEQ-1K2 (lenFINSEQ-1K4 p))"
      using finseq_1_th_57 sorry
    then have A1: "cardCARD-1K4 (rngFUNCT-1K2 p) =XBOOLE-0R4 cardCARD-1K4 B"
      using finseq_1_def_3 sorry
    have "domRELAT-1K1 f be finiteFINSET-1V1"
       sorry
    thus "p be one-to-oneFUNCT-1V2"
      using A1 finseq_4_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve f for "FunctionFUNCT-2M1-of(A,B)"
mtheorem finseq_4_th_63:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds cardCARD-1K4 A =XBOOLE-0R4 cardCARD-1K4 B & f be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 f =XBOOLE-0R4 B"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix A assume [ty]: "A be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix B assume [ty]: "B be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
  assume A1: "cardCARD-1K4 A =XBOOLE-0R4 cardCARD-1K4 B"
    and A2: "f be one-to-oneFUNCT-1V2"
  have A3: "(A,B)are-equipotentTARSKIR3"
    using A1 card_1_th_5 sorry
  obtain p where
    [ty]:"p be FinSequenceFINSEQ-1M1" and 
    A4: "rngFUNCT-1K2 p =XBOOLE-0R4 A"and A5: "p be one-to-oneFUNCT-1V2"
    using finseq_4_th_58 sorry
  have "(domFINSEQ-1K5 p,p .:FUNCT-1K5 domFINSEQ-1K5 p)are-equipotentTARSKIR3"
    using A5 card_1_th_33 sorry
  then have "(domFINSEQ-1K5 p,A)are-equipotentTARSKIR3"
    using A4 relat_1_th_113 sorry
  then have A6: "(domFINSEQ-1K5 p,B)are-equipotentTARSKIR3"
    using A3 wellord2_th_15 sorry
  obtain q where
    [ty]:"q be FinSequenceFINSEQ-1M1" and 
    A7: "rngFUNCT-1K2 q =XBOOLE-0R4 B"and A8: "q be one-to-oneFUNCT-1V2"
    using finseq_4_th_58 sorry
  have A9: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
    using finseq_1_def_3 sorry
  have "(domFINSEQ-1K5 q,q .:FUNCT-1K5 domFINSEQ-1K5 q)are-equipotentTARSKIR3"
    using A8 card_1_th_33 sorry
  then have "(domFINSEQ-1K5 q,B)are-equipotentTARSKIR3"
    using A7 relat_1_th_113 sorry
  then have "(domFINSEQ-1K5 p,domFINSEQ-1K5 q)are-equipotentTARSKIR3"
    using A6 wellord2_th_15 sorry
  then have "cardCARD-1K4 (domFINSEQ-1K5 p) =HIDDENR1 cardCARD-1K4 (SegFINSEQ-1K2 (lenFINSEQ-1K4 q))"
    using A9 card_1_th_5 sorry
  also have "... = lenFINSEQ-1K4 q"
    using finseq_1_th_57 sorry
  finally have "cardCARD-1K4 (domFINSEQ-1K5 p) =HIDDENR1 lenFINSEQ-1K4 q"
     sorry
  then have A10: "lenFINSEQ-1K4 q =HIDDENR1 cardCARD-1K4 (SegFINSEQ-1K2 (lenFINSEQ-1K4 p))"
    using finseq_1_def_3 sorry
  also have "... = lenFINSEQ-1K4 p"
    using finseq_1_th_57 sorry
  finally have "lenFINSEQ-1K4 q =HIDDENR1 lenFINSEQ-1K4 p"
     sorry
  show "rngFUNCT-1K2 f =XBOOLE-0R4 B"
  proof-
    have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies rngFUNCT-1K2 f =XBOOLE-0R4 B"
    proof(rule impI)
      assume "B =XBOOLE-0R4 {}XBOOLE-0K1"
      thus "rngFUNCT-1K2 f =XBOOLE-0R4 B"
         sorry
    qed
    have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 f =XBOOLE-0R4 B"
    proof(rule impI)
      assume A11: "B <>HIDDENR2 {}XBOOLE-0K1"
      have "domRELAT-1K1 (q \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 q"
        using A8 funct_1_th_33 sorry
      then have "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 (q \<inverse>FUNCT-1K4)"
        using A7 relat_1_def_19 sorry
      then have "domRELAT-1K1 (q \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
        using relat_1_th_27 sorry
      then have "rngFUNCT-1K2 p =XBOOLE-0R4 domRELAT-1K1 (q \<inverse>FUNCT-1K4 *FUNCT-1K3 f)"
        using A4 A11 funct_2_def_1 sorry
      then have A12: "domRELAT-1K1 ((q \<inverse>FUNCT-1K4 *FUNCT-1K3 f)*FUNCT-1K3 p) =HIDDENR1 domFINSEQ-1K5 p"
        using relat_1_th_27 sorry
      also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
        using finseq_1_def_3 sorry
      finally have "domRELAT-1K1 ((q \<inverse>FUNCT-1K4 *FUNCT-1K3 f)*FUNCT-1K3 p) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
         sorry
      then obtain g where 
        [ty]:"g be FinSequenceFINSEQ-1M1" and gDef:"g = (q \<inverse>FUNCT-1K4 *FUNCT-1K3 f)*FUNCT-1K3 p"
        using finseq_1_def_2 sorry
      have "g =FUNCT-1R1 q \<inverse>FUNCT-1K4 *FUNCT-1K3 (f *FUNCT-1K3 p)"
        using relat_1_th_36 sorry
      then have "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (q \<inverse>FUNCT-1K4)"
        using relat_1_th_26 sorry
      then have "rngFUNCT-1K2 g c=TARSKIR1 domFINSEQ-1K5 q"
        using A8 funct_1_th_33 sorry
      then have "rngFUNCT-1K2 g c=TARSKIR1 domFINSEQ-1K5 g"
        using A10 A12 finseq_1_def_3 sorry
      then have "rngFUNCT-1K2 g =XBOOLE-0R4 domFINSEQ-1K5 g"
        using A2 A5 A8 finseq_4_th_59 sorry
      then have "rngFUNCT-1K2 g =XBOOLE-0R4 domFINSEQ-1K5 q"
        using A10 A12 finseq_1_def_3 sorry
      then have A13: "rngFUNCT-1K2 (q *FUNCT-1K3 g) =XBOOLE-0R4 B"
        using A7 relat_1_th_28 sorry
      have A14: "rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 q"
        using A7 relat_1_def_19 sorry
      have A15: "rngFUNCT-1K2 p =XBOOLE-0R4 domRELAT-1K1 f"
        using A4 A11 funct_2_def_1 sorry
      have "q *FUNCT-1K3 g =HIDDENR1 q *FUNCT-1K3 (q \<inverse>FUNCT-1K4 *FUNCT-1K3 (f *FUNCT-1K3 p))"
        using relat_1_th_36 sorry
      also have "... = (q *FUNCT-1K3 q \<inverse>FUNCT-1K4)*FUNCT-1K3 (f *FUNCT-1K3 p)"
        using relat_1_th_36 sorry
      also have "... = idPARTFUN1K6 (rngFUNCT-1K2 q) *FUNCT-1K3 (f *FUNCT-1K3 p)"
        using A8 funct_1_th_39 sorry
      also have "... = (idPARTFUN1K6 (rngFUNCT-1K2 q) *PARTFUN1K1\<^bsub>(A,B,rngFUNCT-1K2 q,rngFUNCT-1K2 q)\<^esub> f)*FUNCT-1K3 p"
        using relat_1_th_36 sorry
      also have "... = f *FUNCT-1K3 p"
        using A14 relat_1_th_53 sorry
      finally have "q *FUNCT-1K3 g =HIDDENR1 f *FUNCT-1K3 p"
         sorry
      thus "rngFUNCT-1K2 f =XBOOLE-0R4 B"
        using A13 A15 relat_1_th_28 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem finseq_4_th_64:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds cardCARD-1K4 A =XBOOLE-0R4 cardCARD-1K4 B & rngFUNCT-1K2 f =XBOOLE-0R4 B implies f be one-to-oneFUNCT-1V2"
  using finseq_4_lm_1 sorry

(*\$N Dirichlet Principle*)
(*\$N Pigeon Hole Principle*)
mtheorem finseq_4_th_65:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds cardCARD-1K1 B inTARSKIR2 cardCARD-1K1 A & B <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st ((x inHIDDENR3 A & y inHIDDENR3 A) & x <>HIDDENR2 y) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y)"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds cardCARD-1K1 B inTARSKIR2 cardCARD-1K1 A & (B <>HIDDENR2 {}XBOOLE-0K1 & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 A & y inHIDDENR3 A) & x <>HIDDENR2 y implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 y)) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
    assume A1: "cardCARD-1K1 B inTARSKIR2 cardCARD-1K1 A"
      and A2: "B <>HIDDENR2 {}XBOOLE-0K1"
      and A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 A & y inHIDDENR3 A) & x <>HIDDENR2 y implies f .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 y"
    have A4: "domRELAT-1K1 f =XBOOLE-0R4 A"
      using A2 funct_2_def_1 sorry
    then have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
      using A3 sorry
    then have "f be one-to-oneFUNCT-1V2"
       sorry
    then have "(domRELAT-1K1 f,f .:FUNCT-1K5 domRELAT-1K1 f)are-equipotentTARSKIR3"
      using card_1_th_33 sorry
    then have "(domRELAT-1K1 f,rngFUNCT-1K2 f)are-equipotentTARSKIR3"
      using relat_1_th_113 sorry
    then have A5: "cardCARD-1K1 A =XBOOLE-0R4 cardCARD-1K1 (rngFUNCT-1K2 f)"
      using A4 card_1_th_5 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 B"
      using relat_1_def_19 sorry
    then have "cardCARD-1K1 A c=ORDINAL1R1 cardCARD-1K1 B"
      using A5 card_1_th_11 sorry
    thus " False "
      using A1 card_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_66:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds cardCARD-1K1 A inTARSKIR2 cardCARD-1K1 B implies ( ex x be objectHIDDENM1 st x inHIDDENR3 B & ( for y be objectHIDDENM1 holds y inHIDDENR3 A implies f .FUNCT-1K1 y <>HIDDENR2 x))"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds cardCARD-1K1 A inTARSKIR2 cardCARD-1K1 B & ( for x be objectHIDDENM1 holds x inHIDDENR3 B implies ( ex y be objectHIDDENM1 st y inHIDDENR3 A & f .FUNCT-1K1 y =HIDDENR1 x)) implies  not  True "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
    assume A1: "cardCARD-1K1 A inTARSKIR2 cardCARD-1K1 B"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 B implies ( ex y be objectHIDDENM1 st y inHIDDENR3 A & f .FUNCT-1K1 y =HIDDENR1 x)"
    have A3: "domRELAT-1K1 f =XBOOLE-0R4 A"
      using A1 card_1_th_27 funct_2_def_1 sorry
    have "rngFUNCT-1K2 f =XBOOLE-0R4 B"
    proof-
      have "rngFUNCT-1K2 f c=TARSKIR1 B & B c=TARSKIR1 rngFUNCT-1K2 f"
      proof(rule conjMI)
        show "rngFUNCT-1K2 f c=TARSKIR1 B"
          using relat_1_def_19 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 B implies x inHIDDENR3 rngFUNCT-1K2 f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 B"
          then have " ex y be objectHIDDENM1 st y inHIDDENR3 A & f .FUNCT-1K1 y =HIDDENR1 x"
            using A2 sorry
          thus "x inHIDDENR3 rngFUNCT-1K2 f"
            using A3 funct_1_def_3 sorry
        qed "sorry"
        thus "B c=TARSKIR1 rngFUNCT-1K2 f"
          using tarski_def_3 sorry
      qed
      thus "rngFUNCT-1K2 f =XBOOLE-0R4 B"
        using xboole_0_def_10 sorry
    qed
    then have "cardCARD-1K1 B c=ORDINAL1R1 cardCARD-1K1 A"
      using A3 card_1_th_12 sorry
    thus " not  True "
      using A1 card_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem finseq_4_th_67:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for p be ElementSUBSET-1M1-of D holds (f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for p be ElementSUBSET-1M1-of D holds (f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    have "lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)) =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_1_th_22 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))"
      using finseq_1_th_39 nat_1_th_11 sorry
    then have "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))"
      using finseq_3_th_25 sorry
    then have "(f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)).FUNCT-1K1 (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)"
      using partfun1_def_6 sorry
    also have "... = p"
      using finseq_1_th_42 sorry
    finally show "(f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_68:
" for k be NatNAT-1M1 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of E holds  for q be FinSequenceFINSEQ-1M3-of E holds k inTARSKIR2 domFINSEQ-1K5 p implies (p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)/.PARTFUN1K7\<^bsub>(E)\<^esub> k =XBOOLE-0R4 p /.PARTFUN1K7\<^bsub>(E)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of E holds  for q be FinSequenceFINSEQ-1M3-of E holds k inTARSKIR2 domFINSEQ-1K5 p implies (p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)/.PARTFUN1K7\<^bsub>(E)\<^esub> k =HIDDENR1 p /.PARTFUN1K7\<^bsub>(E)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of E"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of E"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 p"
    then have "k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)"
      using finseq_3_th_22 sorry
    then have "(p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)/.PARTFUN1K7\<^bsub>(E)\<^esub> k =HIDDENR1 (p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q).FUNCT-1K1 k"
      using partfun1_def_6 sorry
    also have "... = p .FUNCT-1K1 k"
      using A1 finseq_1_def_7 sorry
    also have "... = p /.PARTFUN1K7\<^bsub>(E)\<^esub> k"
      using A1 partfun1_def_6 sorry
    finally show "(p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)/.PARTFUN1K7\<^bsub>(E)\<^esub> k =HIDDENR1 p /.PARTFUN1K7\<^bsub>(E)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_69:
" for k be NatNAT-1M1 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of E holds  for q be FinSequenceFINSEQ-1M3-of E holds k inTARSKIR2 domFINSEQ-1K5 q implies (p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)/.PARTFUN1K7\<^bsub>(E)\<^esub> (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =XBOOLE-0R4 q /.PARTFUN1K7\<^bsub>(E)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of E holds  for q be FinSequenceFINSEQ-1M3-of E holds k inTARSKIR2 domFINSEQ-1K5 q implies (p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)/.PARTFUN1K7\<^bsub>(E)\<^esub> (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 q /.PARTFUN1K7\<^bsub>(E)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of E"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of E"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 q"
    then have "lenFINSEQ-1K4 p +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 (p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)"
      using finseq_1_th_28 sorry
    then have "(p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)/.PARTFUN1K7\<^bsub>(E)\<^esub> (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 (p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q).FUNCT-1K1 (lenFINSEQ-1K4 p +XCMPLX-0K2 k)"
      using partfun1_def_6 sorry
    also have "... = q .FUNCT-1K1 k"
      using A1 finseq_1_def_7 sorry
    also have "... = q /.PARTFUN1K7\<^bsub>(E)\<^esub> k"
      using A1 partfun1_def_6 sorry
    finally show "(p ^FINSEQ-1K9\<^bsub>(E)\<^esub> q)/.PARTFUN1K7\<^bsub>(E)\<^esub> (lenFINSEQ-1K4 p +XCMPLX-0K2 k) =HIDDENR1 q /.PARTFUN1K7\<^bsub>(E)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_70:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 domFINSEQ-1K5 (p  |FINSEQ-1K18\<^bsub>(D)\<^esub> m) implies (p  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> a =XBOOLE-0R4 p /.PARTFUN1K7\<^bsub>(D)\<^esub> a"
proof-
  have " for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 domFINSEQ-1K5 (p  |FINSEQ-1K18\<^bsub>(D)\<^esub> m) implies (p  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> a =HIDDENR1 p /.PARTFUN1K7\<^bsub>(D)\<^esub> a"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix D assume [ty]: "D be setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "a inTARSKIR2 domFINSEQ-1K5 (p  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)"
    then have "a inTARSKIR2 domFINSEQ-1K5 p /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m"
      using relat_1_th_61 sorry
    then have A2: "a inTARSKIR2 domFINSEQ-1K5 p"
      using xboole_0_def_4 sorry
    have "(p  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> a =HIDDENR1 (p  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 m).FUNCT-1K1 a"
      using A1 partfun1_def_6 sorry
    also have "... = p .FUNCT-1K1 a"
      using A1 funct_1_th_47 sorry
    also have "... = p /.PARTFUN1K7\<^bsub>(D)\<^esub> a"
      using A2 partfun1_def_6 sorry
    finally show "(p  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> a =HIDDENR1 p /.PARTFUN1K7\<^bsub>(D)\<^esub> a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_71:
" for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 SegFINSEQ-1K2 n implies m inTARSKIR2 domFINSEQ-1K5 f & (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> m =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
proof-
  have " for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 SegFINSEQ-1K2 n implies m inTARSKIR2 domFINSEQ-1K5 f & (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> m =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix D assume [ty]: "D be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "n inTARSKIR2 domFINSEQ-1K5 f"
      and A2: "m inTARSKIR2 SegFINSEQ-1K2 n"
    have "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) & n <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_1_def_3 finseq_3_th_25 sorry
    then have A3: "SegFINSEQ-1K2 n c=TARSKIR1 domFINSEQ-1K5 f"
      using finseq_1_th_5 sorry
    thus "m inTARSKIR2 domFINSEQ-1K5 f"
      using A2 sorry
    have A4: "SegFINSEQ-1K2 n =HIDDENR1 domFINSEQ-1K5 f /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 n"
      using A3 xboole_1_th_28 sorry
    also have "... = domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)"
      using relat_1_th_61 sorry
    finally have "SegFINSEQ-1K2 n =HIDDENR1 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)"
       sorry
    then have "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> m =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n).FUNCT-1K1 m"
      using A2 partfun1_def_6 sorry
    also have "... = f .FUNCT-1K1 m"
      using A2 A4 funct_1_th_47 sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
      using A2 A3 partfun1_def_6 sorry
    finally show "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> m =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_72:
" for n be NatNAT-1M1 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds n <=XXREAL-0R1 cardCARD-1K4 X implies ( ex A be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of X st cardCARD-1K4 A =XBOOLE-0R4 n)"
proof-
  have " for n be NatNAT-1M1 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds n <=XXREAL-0R1 cardCARD-1K4 X implies  not ( for A be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of X holds  not cardCARD-1K4 A =XBOOLE-0R4 n)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume A1: "n <=XXREAL-0R1 cardCARD-1K4 X"
    obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M1" and 
      A2: "rngFUNCT-1K2 p =XBOOLE-0R4 X"and A3: "p be one-to-oneFUNCT-1V2"
      using finseq_4_th_58 sorry
    obtain q where 
      [ty]:"q be FinSequenceFINSEQ-1M1" and qDef:"q = p  |RELAT-1K8 SegFINSEQ-1K2 n"
      using finseq_1_th_15 sorry
    have "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A1 A2 A3 finseq_4_th_62 sorry
    then have A4: "lenFINSEQ-1K4 q =XBOOLE-0R4 n"
      using finseq_1_th_17 sorry
    obtain A where 
      [ty]:"A be SubsetSUBSET-1M2-of X" and ADef:"A = rngFUNCT-1K2 q"
      using A2 relat_1_th_70 sorry
    have "q be one-to-oneFUNCT-1V2"
      using A3 funct_1_th_52 sorry
    then have "cardCARD-1K4 A =XBOOLE-0R4 n"
      using A4 finseq_4_th_62 sorry
    thus " not ( for A be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of X holds  not cardCARD-1K4 A =XBOOLE-0R4 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve f for "FunctionFUNCT-1M1"
mtheorem finseq_4_th_73:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & x inHIDDENR3 rngFUNCT-1K2 f implies cardCARD-1K1 (CoimRELAT-1K13(f,x)) =XBOOLE-0R4 \<one>\<^sub>M"
  using finseq_4_th_8 finseq_4_def_2 sorry

mdef finseq_4_def_7 ("<*FINSEQ-4K7 _ , _ , _ , _ *>" [0,0,0,0]164 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"func <*FINSEQ-4K7 x1,x2,x3,x4 *> \<rightarrow> setHIDDENM2 equals
  (<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)"
proof-
  (*coherence*)
    show "(<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>) be setHIDDENM2"
       sorry
qed "sorry"

mdef finseq_4_def_8 ("<*FINSEQ-4K8 _ , _ , _ , _ , _ *>" [0,0,0,0,0]164 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1"
"func <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> \<rightarrow> setHIDDENM2 equals
  (<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K11 x4,x5 *>)"
proof-
  (*coherence*)
    show "(<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K11 x4,x5 *>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem finseq_4_cl_1:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster <*FINSEQ-4K7 x1,x2,x3,x4 *> as-term-is  non emptyXBOOLE-0V1\<bar>Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<*FINSEQ-4K7 x1,x2,x3,x4 *> be  non emptyXBOOLE-0V1\<bar>Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem finseq_4_cl_2:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1"
"cluster <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> as-term-is  non emptyXBOOLE-0V1\<bar>Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> be  non emptyXBOOLE-0V1\<bar>Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem finseq_4_cl_3:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster <*FINSEQ-4K7 x1,x2,x3,x4 *> as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "<*FINSEQ-4K7 x1,x2,x3,x4 *> be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

mtheorem finseq_4_cl_4:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1"
"cluster <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

syntax FINSEQ_4K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<*FINSEQ-4K9\<^bsub>'( _ ')\<^esub> _ , _ , _ , _ *>" [0,0,0,0,0]164)
translations "<*FINSEQ-4K9\<^bsub>(D)\<^esub> x1,x2,x3,x4 *>" \<rightharpoonup> "<*FINSEQ-4K7 x1,x2,x3,x4 *>"

mtheorem finseq_4_add_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D", "x3 be ElementSUBSET-1M1-of D", "x4 be ElementSUBSET-1M1-of D"
"cluster <*FINSEQ-4K7 x1,x2,x3,x4 *> as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "<*FINSEQ-4K7 x1,x2,x3,x4 *> be FinSequenceFINSEQ-1M3-of D"
  proof-
    have "<*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> x1,x2,x3 *>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> x4*>)"
       sorry
    thus "<*FINSEQ-4K7 x1,x2,x3,x4 *> be FinSequenceFINSEQ-1M3-of D"
       sorry
  qed
qed "sorry"

syntax FINSEQ_4K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("<*FINSEQ-4K10\<^bsub>'( _ ')\<^esub> _ , _ , _ , _ , _ *>" [0,0,0,0,0,0]164)
translations "<*FINSEQ-4K10\<^bsub>(D)\<^esub> x1,x2,x3,x4,x5 *>" \<rightharpoonup> "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *>"

mtheorem finseq_4_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x1 be ElementSUBSET-1M1-of D", "x2 be ElementSUBSET-1M1-of D", "x3 be ElementSUBSET-1M1-of D", "x4 be ElementSUBSET-1M1-of D", "x5 be ElementSUBSET-1M1-of D"
"cluster <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> be FinSequenceFINSEQ-1M3-of D"
  proof-
    have "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-4K3\<^bsub>(D)\<^esub> x1,x2,x3 *>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(D)\<^esub> x4,x5 *>)"
       sorry
    thus "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> be FinSequenceFINSEQ-1M3-of D"
       sorry
  qed
qed "sorry"

reserve x1, x2, x3, x4, x5 for "objectHIDDENM1"
mtheorem finseq_4_th_74:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds ((<*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>) & <*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (<*FINSEQ-1K11 x1,x2 *>)^FINSEQ-1K8 (<*FINSEQ-1K11 x3,x4 *>)) & <*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K12 x2,x3,x4 *>)) & <*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds <*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>) & (<*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (<*FINSEQ-1K11 x1,x2 *>)^FINSEQ-1K8 (<*FINSEQ-1K11 x3,x4 *>) & (<*FINSEQ-4K7 x1,x2,x3,x4 *> =HIDDENR1 (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K12 x2,x3,x4 *>) & <*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    show "<*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)"
       sorry
    show "<*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (<*FINSEQ-1K11 x1,x2 *>)^FINSEQ-1K8 (<*FINSEQ-1K11 x3,x4 *>)"
      using finseq_1_th_32 sorry
    then have "<*FINSEQ-4K7 x1,x2,x3,x4 *> =HIDDENR1 (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 ((<*FINSEQ-1K10 x2*>)^FINSEQ-1K8 (<*FINSEQ-1K11 x3,x4 *>))"
      using finseq_1_th_32 sorry
    also have "... = (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K12 x2,x3,x4 *>)"
      using finseq_1_th_43 sorry
    finally show "<*FINSEQ-4K7 x1,x2,x3,x4 *> =HIDDENR1 (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K12 x2,x3,x4 *>)"
       sorry
    show "<*FINSEQ-4K7 x1,x2,x3,x4 *> =FINSEQ-1R1 (((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_75:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds (((<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K11 x4,x5 *>) & <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-4K7 x1,x2,x3,x4 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)) & <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 ((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)) & <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-1K11 x1,x2 *>)^FINSEQ-1K8 (<*FINSEQ-1K12 x3,x4,x5 *>)) & <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-4K7 x2,x3,x4,x5 *>)"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K11 x4,x5 *>) & (<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-4K7 x1,x2,x3,x4 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>) & (<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 ((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>) & (<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =HIDDENR1 (<*FINSEQ-1K11 x1,x2 *>)^FINSEQ-1K8 (<*FINSEQ-1K12 x3,x4,x5 *>) & <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =HIDDENR1 (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-4K7 x2,x3,x4,x5 *>))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    show "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K11 x4,x5 *>)"
       sorry
    show A1: "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 (<*FINSEQ-4K7 x1,x2,x3,x4 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)"
      using finseq_1_th_32 sorry
    show "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =FINSEQ-1R1 ((((<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x2*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x3*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)"
      using finseq_1_th_32 sorry
    have "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =HIDDENR1 ((<*FINSEQ-1K11 x1,x2 *>)^FINSEQ-1K8 ((<*FINSEQ-1K10 x3*>)^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)))^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)"
      using A1 finseq_1_th_32 sorry
    also have "... = (<*FINSEQ-1K11 x1,x2 *>)^FINSEQ-1K8 (<*FINSEQ-1K12 x3,x4,x5 *>)"
      using finseq_1_th_32 sorry
    finally show "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =HIDDENR1 (<*FINSEQ-1K11 x1,x2 *>)^FINSEQ-1K8 (<*FINSEQ-1K12 x3,x4,x5 *>)"
       sorry
    then have "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =HIDDENR1 (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 ((<*FINSEQ-1K10 x2*>)^FINSEQ-1K8 (<*FINSEQ-1K12 x3,x4,x5 *>))"
      using finseq_1_th_32 sorry
    also have "... = (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-4K7 x2,x3,x4,x5 *>)"
      using finseq_4_th_74 sorry
    finally show "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> =HIDDENR1 (<*FINSEQ-1K10 x1*>)^FINSEQ-1K8 (<*FINSEQ-4K7 x2,x3,x4,x5 *>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve p for "FinSequenceFINSEQ-1M1"
mtheorem finseq_4_th_76:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds p =FINSEQ-1R1 <*FINSEQ-4K7 x1,x2,x3,x4 *> iff (((lenFINSEQ-1K4 p =XBOOLE-0R4 \<four>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3) & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds (p =FINSEQ-1R1 <*FINSEQ-4K7 x1,x2,x3,x4 *> implies (((lenFINSEQ-1K4 p =XBOOLE-0R4 \<four>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3) & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4) & (lenFINSEQ-1K4 p =XBOOLE-0R4 \<four>\<^sub>M & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1 & (p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2 & (p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3 & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4))) implies p =FINSEQ-1R1 <*FINSEQ-4K7 x1,x2,x3,x4 *>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    show "p =FINSEQ-1R1 <*FINSEQ-4K7 x1,x2,x3,x4 *> implies (((lenFINSEQ-1K4 p =XBOOLE-0R4 \<four>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3) & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4"
    proof-
      have "p =FINSEQ-1R1 <*FINSEQ-4K7 x1,x2,x3,x4 *> implies lenFINSEQ-1K4 p =HIDDENR1 \<four>\<^sub>M & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1 & (p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2 & (p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3 & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4)))"
      proof(rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
        let ?p3 = "<*FINSEQ-1K12 x1,x2,x3 *>"
        assume A1: "p =FINSEQ-1R1 <*FINSEQ-4K7 x1,x2,x3,x4 *>"
        then have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x4*>)"
          using finseq_1_th_22 sorry
        also have "... = \<three>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x4*>)"
          using finseq_1_th_45 sorry
        also have "... = \<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        also have "... = \<four>\<^sub>M"
           sorry
        finally show "lenFINSEQ-1K4 p =HIDDENR1 \<four>\<^sub>M"
           sorry
        have A2: "domFINSEQ-1K5 ?p3 =XBOOLE-0R4 {ENUMSET1K1 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
          using finseq_1_th_89 finseq_3_th_1 sorry
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p3"
          using enumset1_def_1 sorry
        then have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 \<one>\<^sub>M"
          using A1 finseq_1_def_7 sorry
        also have "... = x1"
          using finseq_1_th_45 sorry
        finally show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1"
           sorry
        have "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p3"
          using A2 enumset1_def_1 sorry
        then have "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 \<two>\<^sub>M"
          using A1 finseq_1_def_7 sorry
        also have "... = x2"
          using finseq_1_th_45 sorry
        finally show "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2"
           sorry
        have "\<three>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p3"
          using A2 enumset1_def_1 sorry
        then have "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 \<three>\<^sub>M"
          using A1 finseq_1_def_7 sorry
        also have "... = x3"
          using finseq_1_th_45 sorry
        finally show "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3"
           sorry
        have "\<one>\<^sub>M inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using tarski_def_1 sorry
        then have A3: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x4*>)"
          using finseq_1_th_2 finseq_1_def_8 sorry
        have "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 ((<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)).FUNCT-1K1 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = ((<*FINSEQ-1K12 x1,x2,x3 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x4*>)).FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_45 sorry
        also have "... = (<*FINSEQ-1K10 x4*>).FUNCT-1K1 \<one>\<^sub>M"
          using A3 finseq_1_def_7 sorry
        also have "... = x4"
          using finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<four>\<^sub>M"
      and A5: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1"
      and A6: "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2"
      and A7: "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3"
      and A8: "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4"
    have A9: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 x1,x2,x3 *>) implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      have A10: "lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) =XBOOLE-0R4 \<three>\<^sub>M"
        using finseq_1_th_45 sorry
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K12 x1,x2,x3 *>)"
      then have A11: "k inTARSKIR2 {ENUMSET1K1 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
        using A10 finseq_1_def_3 finseq_3_th_1 sorry
      show "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 k"
      proof-
        have cases: "(k =XBOOLE-0R4 \<one>\<^sub>M or k =XBOOLE-0R4 \<two>\<^sub>M) or k =XBOOLE-0R4 \<three>\<^sub>M"
          using A11 enumset1_def_1 sorry
        have case1: "k =XBOOLE-0R4 \<one>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 k"
        proof(rule impI)
          assume "k =XBOOLE-0R4 \<one>\<^sub>M"
          thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 k"
            using A5 finseq_1_th_45 sorry
        qed
        have case2: "k =XBOOLE-0R4 \<two>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 k"
        proof(rule impI)
          assume "k =XBOOLE-0R4 \<two>\<^sub>M"
          thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 k"
            using A6 finseq_1_th_45 sorry
        qed
        have case3: "k =XBOOLE-0R4 \<three>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 k"
        proof(rule impI)
          assume "k =XBOOLE-0R4 \<three>\<^sub>M"
          thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-1K12 x1,x2,x3 *>).FUNCT-1K1 k"
            using A7 finseq_1_th_45 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed "sorry"
    have A12: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x4*>) implies p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +XCMPLX-0K2 k) =XBOOLE-0R4 (<*FINSEQ-1K10 x4*>).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x4*>) implies p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +XCMPLX-0K2 k) =HIDDENR1 (<*FINSEQ-1K10 x4*>).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x4*>)"
        then have "k inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using finseq_1_th_2 finseq_1_def_8 sorry
        then have A13: "k =XBOOLE-0R4 \<one>\<^sub>M"
          using tarski_def_1 sorry
        then have "p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +XCMPLX-0K2 k) =HIDDENR1 p .FUNCT-1K1 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_45 sorry
        also have "... = (<*FINSEQ-1K10 x4*>).FUNCT-1K1 k"
          using A8 A13 finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +XCMPLX-0K2 k) =HIDDENR1 (<*FINSEQ-1K10 x4*>).FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using A4 finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_th_45 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x4*>))"
      using finseq_1_th_39 sorry
    finally have "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K12 x1,x2,x3 *>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x4*>))"
       sorry
    thus "p =FINSEQ-1R1 <*FINSEQ-4K7 x1,x2,x3,x4 *>"
      using A9 A12 finseq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem finseq_4_th_78:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds p =FINSEQ-1R1 <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> iff ((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<five>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3) & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4) & p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for p be FinSequenceFINSEQ-1M1 holds (p =FINSEQ-1R1 <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> implies ((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<five>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3) & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4) & p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5) & (lenFINSEQ-1K4 p =XBOOLE-0R4 \<five>\<^sub>M & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1 & (p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2 & (p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3 & (p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4 & p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5)))) implies p =HIDDENR1 <*FINSEQ-4K8 x1,x2,x3,x4,x5 *>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    let ?p4 = "<*FINSEQ-4K7 x1,x2,x3,x4 *>"
    show "p =FINSEQ-1R1 <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> implies ((((lenFINSEQ-1K4 p =XBOOLE-0R4 \<five>\<^sub>M & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3) & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4) & p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5"
    proof-
      have "p =FINSEQ-1R1 <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> implies lenFINSEQ-1K4 p =HIDDENR1 \<five>\<^sub>M & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1 & (p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2 & (p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3 & (p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4 & p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5))))"
      proof(rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
        let ?p4 = "<*FINSEQ-4K7 x1,x2,x3,x4 *>"
        have "\<one>\<^sub>M inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using tarski_def_1 sorry
        then have A1: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x5*>)"
          using finseq_1_th_2 finseq_1_def_8 sorry
        assume A2: "p =FINSEQ-1R1 <*FINSEQ-4K8 x1,x2,x3,x4,x5 *>"
        then have A3: "p =FINSEQ-1R1 ?p4 ^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)"
          using finseq_4_th_75 sorry
        have "lenFINSEQ-1K4 p =HIDDENR1 lenFINSEQ-1K4 ((<*FINSEQ-4K7 x1,x2,x3,x4 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>))"
          using A2 finseq_4_th_75 sorry
        also have "... = lenFINSEQ-1K4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x5*>)"
          using finseq_1_th_22 sorry
        also have "... = \<four>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x5*>)"
          using finseq_4_th_76 sorry
        also have "... = \<four>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        also have "... = \<five>\<^sub>M"
           sorry
        finally show "lenFINSEQ-1K4 p =HIDDENR1 \<five>\<^sub>M"
           sorry
        have A4: "domFINSEQ-1K5 ?p4 =XBOOLE-0R4 {ENUMSET1K2 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
          using finseq_1_th_89 finseq_3_th_2 sorry
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p4"
          using enumset1_def_2 sorry
        then have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 \<one>\<^sub>M"
          using A3 finseq_1_def_7 sorry
        also have "... = x1"
          using finseq_4_th_76 sorry
        finally show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1"
           sorry
        have "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p4"
          using A4 enumset1_def_2 sorry
        then have "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 \<two>\<^sub>M"
          using A3 finseq_1_def_7 sorry
        also have "... = x2"
          using finseq_4_th_76 sorry
        finally show "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2"
           sorry
        have "\<three>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p4"
          using A4 enumset1_def_2 sorry
        then have "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 \<three>\<^sub>M"
          using A3 finseq_1_def_7 sorry
        also have "... = x3"
          using finseq_4_th_76 sorry
        finally show "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3"
           sorry
        have "\<four>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p4"
          using A4 enumset1_def_2 sorry
        then have "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 \<four>\<^sub>M"
          using A3 finseq_1_def_7 sorry
        also have "... = x4"
          using finseq_4_th_76 sorry
        finally show "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4"
           sorry
        have "p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 ((<*FINSEQ-4K7 x1,x2,x3,x4 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)).FUNCT-1K1 (\<four>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using A2 finseq_4_th_75 sorry
        also have "... = ((<*FINSEQ-4K7 x1,x2,x3,x4 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)).FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>) +NAT-1K1 \<one>\<^sub>M)"
          using finseq_4_th_76 sorry
        also have "... = (<*FINSEQ-1K10 x5*>).FUNCT-1K1 \<one>\<^sub>M"
          using A1 finseq_1_def_7 sorry
        also have "... = x5"
          using finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<five>\<^sub>M"
      and A6: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x1"
      and A7: "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x2"
      and A8: "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x3"
      and A9: "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x4"
      and A10: "p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x5"
    have A11: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 ?p4 implies p .FUNCT-1K1 k =XBOOLE-0R4 ?p4 .FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 ?p4 implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        have A12: "lenFINSEQ-1K4 ?p4 =XBOOLE-0R4 \<four>\<^sub>M"
          using finseq_4_th_76 sorry
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k inTARSKIR2 domFINSEQ-1K5 ?p4"
        then have A13: "k inTARSKIR2 {ENUMSET1K2 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
          using A12 finseq_1_def_3 finseq_3_th_2 sorry
        show "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
        proof-
          have cases: "((k =XBOOLE-0R4 \<one>\<^sub>M or k =XBOOLE-0R4 \<two>\<^sub>M) or k =XBOOLE-0R4 \<three>\<^sub>M) or k =XBOOLE-0R4 \<four>\<^sub>M"
            using A13 enumset1_def_2 sorry
          have case1: "k =XBOOLE-0R4 \<one>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
          proof(rule impI)
            assume "k =XBOOLE-0R4 \<one>\<^sub>M"
            thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
              using A6 finseq_4_th_76 sorry
          qed
          have case2: "k =XBOOLE-0R4 \<two>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
          proof(rule impI)
            assume "k =XBOOLE-0R4 \<two>\<^sub>M"
            thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
              using A7 finseq_4_th_76 sorry
          qed
          have case3: "k =XBOOLE-0R4 \<three>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
          proof(rule impI)
            assume "k =XBOOLE-0R4 \<three>\<^sub>M"
            thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
              using A8 finseq_4_th_76 sorry
          qed
          have case4: "k =XBOOLE-0R4 \<four>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
          proof(rule impI)
            assume "k =XBOOLE-0R4 \<four>\<^sub>M"
            thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>).FUNCT-1K1 k"
              using A9 finseq_4_th_76 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A14: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x5*>) implies p .FUNCT-1K1 (lenFINSEQ-1K4 ?p4 +XCMPLX-0K2 k) =XBOOLE-0R4 (<*FINSEQ-1K10 x5*>).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x5*>) implies p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>) +XCMPLX-0K2 k) =HIDDENR1 (<*FINSEQ-1K10 x5*>).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x5*>)"
        then have "k inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
          using finseq_1_th_2 finseq_1_def_8 sorry
        then have A15: "k =XBOOLE-0R4 \<one>\<^sub>M"
          using tarski_def_1 sorry
        then have "p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>) +XCMPLX-0K2 k) =HIDDENR1 p .FUNCT-1K1 (\<four>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
          using finseq_4_th_76 sorry
        also have "... = (<*FINSEQ-1K10 x5*>).FUNCT-1K1 k"
          using A10 A15 finseq_1_def_8 sorry
        finally show "p .FUNCT-1K1 (lenFINSEQ-1K4 (<*FINSEQ-4K7 x1,x2,x3,x4 *>) +XCMPLX-0K2 k) =HIDDENR1 (<*FINSEQ-1K10 x5*>).FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (\<four>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using A5 finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 ?p4 +NAT-1K1 \<one>\<^sub>M)"
      using finseq_4_th_76 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 ?p4 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x5*>))"
      using finseq_1_th_39 sorry
    finally have "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?p4 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x5*>))"
       sorry
    then have "p =HIDDENR1 (<*FINSEQ-4K7 x1,x2,x3,x4 *>)^FINSEQ-1K8 (<*FINSEQ-1K10 x5*>)"
      using A11 A14 finseq_1_def_7 sorry
    also have "... = <*FINSEQ-4K8 x1,x2,x3,x4,x5 *>"
      using finseq_4_th_75 sorry
    finally show "p =HIDDENR1 <*FINSEQ-4K8 x1,x2,x3,x4,x5 *>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve ND for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve y1, y2, y3, y4, y5 for "ElementSUBSET-1M1-of ND"
(*\$CT*)
mtheorem finseq_4_th_80:
" for ND be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for y1 be ElementSUBSET-1M1-of ND holds  for y2 be ElementSUBSET-1M1-of ND holds  for y3 be ElementSUBSET-1M1-of ND holds  for y4 be ElementSUBSET-1M1-of ND holds (((<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 y1 & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 y2) & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 y3) & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<four>\<^sub>M =XBOOLE-0R4 y4"
proof-
  have " for ND be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for y1 be ElementSUBSET-1M1-of ND holds  for y2 be ElementSUBSET-1M1-of ND holds  for y3 be ElementSUBSET-1M1-of ND holds  for y4 be ElementSUBSET-1M1-of ND holds (((<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 y1 & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 y2) & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 y3) & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<four>\<^sub>M =XBOOLE-0R4 y4"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix ND assume [ty]: "ND be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix y1 assume [ty]: "y1 be ElementSUBSET-1M1-of ND"
    fix y2 assume [ty]: "y2 be ElementSUBSET-1M1-of ND"
    fix y3 assume [ty]: "y3 be ElementSUBSET-1M1-of ND"
    fix y4 assume [ty]: "y4 be ElementSUBSET-1M1-of ND"
    let ?s = "<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>"
    have A1: "\<two>\<^sub>M inTARSKIR2 {ENUMSET1K2 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M } & \<three>\<^sub>M inTARSKIR2 {ENUMSET1K2 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
      using finseq_3_th_2 sorry
    have A2: "?s .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 y2 & ?s .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 y3"
      using finseq_4_th_76 sorry
    have A3: "\<four>\<^sub>M inTARSKIR2 {ENUMSET1K2 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
      using finseq_3_th_2 sorry
    have A4: "?s .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 y4 & \<one>\<^sub>M inTARSKIR2 {ENUMSET1K2 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
      using finseq_4_th_76 finseq_3_th_2 sorry
    have "domFINSEQ-1K5 ?s =XBOOLE-0R4 {ENUMSET1K2 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M } & ?s .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 y1"
      using finseq_4_th_76 finseq_1_th_89 finseq_3_th_2 sorry
    thus "(((<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 y1 & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 y2) & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 y3) & (<*FINSEQ-4K9\<^bsub>(ND)\<^esub> y1,y2,y3,y4 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<four>\<^sub>M =XBOOLE-0R4 y4"
      using A2 A4 A1 A3 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_81:
" for ND be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for y1 be ElementSUBSET-1M1-of ND holds  for y2 be ElementSUBSET-1M1-of ND holds  for y3 be ElementSUBSET-1M1-of ND holds  for y4 be ElementSUBSET-1M1-of ND holds  for y5 be ElementSUBSET-1M1-of ND holds ((((<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 y1 & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 y2) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 y3) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<four>\<^sub>M =XBOOLE-0R4 y4) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<five>\<^sub>M =XBOOLE-0R4 y5"
proof-
  have " for ND be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for y1 be ElementSUBSET-1M1-of ND holds  for y2 be ElementSUBSET-1M1-of ND holds  for y3 be ElementSUBSET-1M1-of ND holds  for y4 be ElementSUBSET-1M1-of ND holds  for y5 be ElementSUBSET-1M1-of ND holds ((((<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 y1 & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 y2) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 y3) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<four>\<^sub>M =XBOOLE-0R4 y4) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<five>\<^sub>M =XBOOLE-0R4 y5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix ND assume [ty]: "ND be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix y1 assume [ty]: "y1 be ElementSUBSET-1M1-of ND"
    fix y2 assume [ty]: "y2 be ElementSUBSET-1M1-of ND"
    fix y3 assume [ty]: "y3 be ElementSUBSET-1M1-of ND"
    fix y4 assume [ty]: "y4 be ElementSUBSET-1M1-of ND"
    fix y5 assume [ty]: "y5 be ElementSUBSET-1M1-of ND"
    let ?s = "<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>"
    let ?i5 = "{ENUMSET1K3 \<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M }"
    have A1: "\<one>\<^sub>M inTARSKIR2 ?i5 & \<two>\<^sub>M inTARSKIR2 ?i5"
      using finseq_3_th_3 sorry
    have A2: "\<three>\<^sub>M inTARSKIR2 ?i5 & \<four>\<^sub>M inTARSKIR2 ?i5"
      using finseq_3_th_3 sorry
    have A3: "?s .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 y4 & ?s .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 y5"
      using finseq_4_th_78 sorry
    have A4: "?s .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 y2 & ?s .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 y3"
      using finseq_4_th_78 sorry
    have A5: "\<five>\<^sub>M inTARSKIR2 ?i5"
      using finseq_3_th_3 sorry
    have "domFINSEQ-1K5 ?s =XBOOLE-0R4 ?i5 & ?s .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 y1"
      using finseq_4_th_78 finseq_1_th_89 finseq_3_th_3 sorry
    thus "((((<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 y1 & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 y2) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 y3) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<four>\<^sub>M =XBOOLE-0R4 y4) & (<*FINSEQ-4K10\<^bsub>(ND)\<^esub> y1,y2,y3,y4,y5 *>)/.PARTFUN1K7\<^bsub>(ND)\<^esub> \<five>\<^sub>M =XBOOLE-0R4 y5"
      using A4 A3 A1 A2 A5 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem finseq_4_sch_1:
  fixes Df0 Nf0 Pp2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Nf0 be NatNAT-1M1" and
   A1: " for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 Nf0 implies ( ex d be ElementSUBSET-1M1-of Df0 st Pp2(n,d))"
  shows " ex f be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 f =XBOOLE-0R4 Nf0 & ( for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 Nf0 implies Pp2(n,f /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n))"
  proof-
    have " ex tVar8 be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 tVar8 =XBOOLE-0R4 Nf0 & ( for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 Nf0 implies Pp2(n,tVar8 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n))"
    proof-
      let ?P1 = "\<lambda>Lamb1. \<lambda>Lamb2. Pp2(Lamb1,Lamb2) & Lamb2 inHIDDENR3 Df0"
      obtain X where 
        [ty]:"X be setHIDDENM2" and XDef:"X = Df0"
         sorry
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 Nf0 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 X & (Pp2(x,y) & y inHIDDENR3 Df0))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 SegFINSEQ-1K2 Nf0"
        then obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of NATNUMBERSK1" and x9Def:"x9 = x"
           sorry
        obtain d where
          [ty]:"d be ElementSUBSET-1M1-of Df0" and 
          A4: "Pp2(x9,d)"
          using A1 A3 sorry
        obtain y where 
          [ty]:"y be objectHIDDENM1" and yDef:"y = d"
           sorry
        show " ex y be objectHIDDENM1 st y inHIDDENR3 X & (Pp2(x,y) & y inHIDDENR3 Df0)"
        proof(rule bexI[of _ "y"])
          show "y inHIDDENR3 X & (Pp2(x,y) & y inHIDDENR3 Df0)"
            using A4 sorry
        qed "sorry"
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A5: "(domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & rngFUNCT-1K2 f c=TARSKIR1 X) & ( for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 Nf0 implies ?P1(x,f .FUNCT-1K1 x))"
        using funct_1_sch_6 A2 sorry
      have 
        [ty]:"f be FinSequenceFINSEQ-1M1"
        using A5 finseq_1_def_2 sorry
      have 
        [ty]:"f be FinSequenceFINSEQ-1M3-of Df0"
        using A5 finseq_1_def_4 sorry
      show " ex tVar8 be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 tVar8 =XBOOLE-0R4 Nf0 & ( for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 Nf0 implies Pp2(n,tVar8 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
        have "Nf0 inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        thus "lenFINSEQ-1K4 f =XBOOLE-0R4 Nf0"
          using A5 finseq_1_def_3 sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A6: "n inTARSKIR2 SegFINSEQ-1K2 Nf0"
        then have "Pp2(n,f .FUNCT-1K1 n)"
          using A5 sorry
        thus "Pp2(n,f /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n)"
          using A5 A6 partfun1_def_6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem finseq_4_th_82:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds p c=RELAT-1R2 q implies ( ex p9 be FinSequenceFINSEQ-1M3-of D st p ^FINSEQ-1K9\<^bsub>(D)\<^esub> p9 =FINSEQ-1R1 q)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds p c=RELAT-1R2 q implies ( ex tVar9 be FinSequenceFINSEQ-1M3-of D st p ^FINSEQ-1K9\<^bsub>(D)\<^esub> tVar9 =FINSEQ-1R1 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p c=RELAT-1R2 q"
    have "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) & domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using finseq_1_def_3 sorry
    then have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using A1 grfunc_1_th_2 sorry
    then have "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
      using finseq_1_th_5 sorry
    then obtain N where 
      [ty]:"N be ElementSUBSET-1M1-of NATNUMBERSK1" and NDef:"N = lenFINSEQ-1K4 q -XCMPLX-0K6 lenFINSEQ-1K4 p"
      using int_1_th_3 xreal_1_th_48 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. q /.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 p +XCMPLX-0K2 Lamb1) =XBOOLE-0R4 Lamb2"
    have A2: " for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 N implies ( ex d be ElementSUBSET-1M1-of D st ?P(n,d))"
       sorry
    obtain f where
      [ty]:"f be FinSequenceFINSEQ-1M3-of D" and 
      A3: "lenFINSEQ-1K4 f =XBOOLE-0R4 N"and A4: " for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 N implies ?P(n,f /.PARTFUN1K7\<^bsub>(D)\<^esub> n)"
      using finseq_4_sch_1 A2 sorry
    show " ex tVar9 be FinSequenceFINSEQ-1M3-of D st p ^FINSEQ-1K9\<^bsub>(D)\<^esub> tVar9 =FINSEQ-1R1 q"
    proof(rule bexI[of _ "f"])
      have A5: "lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f) =HIDDENR1 lenFINSEQ-1K4 p +NAT-1K1 N"
        using A3 finseq_1_th_22 sorry
      also have "... = lenFINSEQ-1K4 q"
         sorry
      finally have "lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f) =HIDDENR1 lenFINSEQ-1K4 q"
         sorry
      have " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f) implies (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
      proof(rule ballI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A6: "\<one>\<^sub>M <=XXREAL-0R1 k"
          and A7: "k <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f)"
        have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
          using A5 A6 A7 sorry
        then have A8: "k inTARSKIR2 domFINSEQ-1K5 q"
          using finseq_1_def_3 sorry
        show "(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
        proof-
          have cases: "k <=XXREAL-0R1 lenFINSEQ-1K4 p or lenFINSEQ-1K4 p <XXREAL-0R3 k"
             sorry
          have case1: "k <=XXREAL-0R1 lenFINSEQ-1K4 p implies (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
          proof(rule impI)
            assume "k <=XXREAL-0R1 lenFINSEQ-1K4 p"
            then have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A6 sorry
            then have A9: "k inTARSKIR2 domFINSEQ-1K5 p"
              using finseq_1_def_3 sorry
            then have "(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
              using finseq_1_def_7 sorry
            also have "... = q .FUNCT-1K1 k"
              using A1 A9 grfunc_1_th_2 sorry
            finally show "(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
               sorry
          qed
          have case2: "lenFINSEQ-1K4 p <XXREAL-0R3 k implies (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
          proof(rule impI)
            assume A10: "lenFINSEQ-1K4 p <XXREAL-0R3 k"
            then have "k -XCMPLX-0K6 lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6"
              using xreal_1_th_50 sorry
            then obtain kk where 
              [ty]:"kk be ElementSUBSET-1M1-of NATNUMBERSK1" and kkDef:"kk = k -XCMPLX-0K6 lenFINSEQ-1K4 p"
              using int_1_th_3 sorry
            have "k <=XXREAL-0R1 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 f"
              using A7 finseq_1_th_22 sorry
            then have A11: "kk <=XXREAL-0R1 (lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 lenFINSEQ-1K4 p"
              using xreal_1_th_9 sorry
            have "k -XCMPLX-0K6 lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
              using A10 int_1_th_7 xreal_1_th_50 sorry
            then have A12: "kk inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
              using A11 sorry
            then have A13: "kk inTARSKIR2 domFINSEQ-1K5 f"
              using finseq_1_def_3 sorry
            have "(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 k =HIDDENR1 f .FUNCT-1K1 kk"
              using A7 A10 finseq_1_th_24 sorry
            also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> kk"
              using A13 partfun1_def_6 sorry
            also have "... = q /.PARTFUN1K7\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 p +NAT-1K1 kk)"
              using A3 A4 A12 sorry
            also have "... = q .FUNCT-1K1 k"
              using A8 partfun1_def_6 sorry
            finally show "(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "p ^FINSEQ-1K9\<^bsub>(D)\<^esub> f =FINSEQ-1R1 q"
        using A5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_83:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds (p c=RELAT-1R2 q & \<one>\<^sub>M <=XXREAL-0R1 i) & i <=XXREAL-0R1 lenFINSEQ-1K4 p implies q .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds p c=RELAT-1R2 q implies (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 p implies q .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume "p c=RELAT-1R2 q"
    then have A1: " ex p9 be FinSequenceFINSEQ-1M3-of D st p ^FINSEQ-1K9\<^bsub>(D)\<^esub> p9 =FINSEQ-1R1 q"
      using finseq_4_th_82 sorry
    assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 p"
    thus "q .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i"
      using A1 finseq_1_th_64 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem finseq_4_sch_2:
  fixes Df0 lf0 Ff1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "lf0 be NatNAT-1M1" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0"
  shows " ex g be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 g =XBOOLE-0R4 lf0 & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 g implies g /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n =XBOOLE-0R4 Ff1(n))"
  proof-
    have " ex tVar10 be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 tVar10 =XBOOLE-0R4 lf0 & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 tVar10 implies tVar10 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n =XBOOLE-0R4 Ff1(n))"
    proof-
      obtain g where
        [ty]:"g be FinSequenceFINSEQ-1M3-of Df0" and 
        A1: "lenFINSEQ-1K4 g =XBOOLE-0R4 lf0 & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 g implies g .FUNCT-1K1 n =XBOOLE-0R4 Ff1(n))"
        using finseq_2_sch_1 sorry
      show " ex tVar10 be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 tVar10 =XBOOLE-0R4 lf0 & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 tVar10 implies tVar10 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n =XBOOLE-0R4 Ff1(n))"
      proof(rule bexI[of _ "g"],rule conjMI,rule ballI,rule impI)
        show "lenFINSEQ-1K4 g =XBOOLE-0R4 lf0"
          using A1 sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A2: "n inTARSKIR2 domFINSEQ-1K5 g"
        then have "g .FUNCT-1K1 n =XBOOLE-0R4 Ff1(n)"
          using A1 sorry
        thus "g /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n =XBOOLE-0R4 Ff1(n)"
          using A2 partfun1_def_6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem finseq_4_cl_5:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster <*FINSEQ-4K7 x1,x2,x3,x4 *> as-term-is \<four>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<*FINSEQ-4K7 x1,x2,x3,x4 *> be \<four>\<^sub>M -elementCARD-1V3"
     sorry
qed "sorry"

mtheorem finseq_4_cl_6:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1"
"cluster <*FINSEQ-4K8 x1,x2,x3,x4,x5 *> as-term-is \<five>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<*FINSEQ-4K8 x1,x2,x3,x4,x5 *> be \<five>\<^sub>M -elementCARD-1V3"
     sorry
qed "sorry"

(*begin*)
mtheorem finseq_4_th_84:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <XXREAL-0R3 n implies ( ex p be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 m +NAT-1K1 p & \<one>\<^sub>M <=XXREAL-0R1 p)"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <XXREAL-0R3 n implies ( ex tVar11 be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 m +NAT-1K1 tVar11 & (tVar11 <XXREAL-0R3 \<one>\<^sub>M implies  False ))"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "m <XXREAL-0R3 n"
    then obtain p where
      [ty]:"p be NatNAT-1M1" and 
      A2: "n =XBOOLE-0R4 m +XCMPLX-0K2 p"
      using nat_1_th_10 sorry
    have 
      [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    show " ex tVar11 be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 m +NAT-1K1 tVar11 & (tVar11 <XXREAL-0R3 \<one>\<^sub>M implies  False )"
    proof(rule bexI[of _ "p"],rule conjMI,rule impI)
      show "n =XBOOLE-0R4 m +NAT-1K1 p"
        using A2 sorry
      assume "p <XXREAL-0R3 \<one>\<^sub>M"
      then have "p <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
         sorry
      then have "p =XBOOLE-0R4 0NUMBERSK6"
        using nat_1_th_13 sorry
      thus " False "
        using A1 A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_85:
" for S be setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(S,D1) holds  for f2 be FunctionFUNCT-2M1-of(D1,D2) holds f1 be bijectiveFUNCT-2V3\<^bsub>(S,D1)\<^esub> & f2 be bijectiveFUNCT-2V3\<^bsub>(D1,D2)\<^esub> implies f2 *PARTFUN1K1\<^bsub>(S,D1,D1,D2)\<^esub> f1 be bijectiveFUNCT-2V3\<^bsub>(S,D2)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix S assume [ty]: "S be setHIDDENM2"
  fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(S,D1)"
  fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(D1,D2)"
  let ?f3 = "f2 *PARTFUN1K1\<^bsub>(S,D1,D1,D2)\<^esub> f1"
  have A1: "domRELAT-1K1 f2 =XBOOLE-0R4 D1"
    using funct_2_def_1 sorry
  assume A2: "f1 be bijectiveFUNCT-2V3\<^bsub>(S,D1)\<^esub> & f2 be bijectiveFUNCT-2V3\<^bsub>(D1,D2)\<^esub>"
  then have "rngFUNCT-1K2 f2 =XBOOLE-0R4 D2 & rngFUNCT-1K2 f1 =XBOOLE-0R4 D1"
    using funct_2_def_3 sorry
  then have "rngFUNCT-1K2 ?f3 =XBOOLE-0R4 D2"
    using A1 relat_1_th_28 sorry
  then have "?f3 be one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(D2)\<^esub>"
    using A2 funct_2_def_3 sorry
  thus "f2 *PARTFUN1K1\<^bsub>(S,D1,D1,D2)\<^esub> f1 be bijectiveFUNCT-2V3\<^bsub>(S,D2)\<^esub>"
     sorry
qed "sorry"

mtheorem finseq_4_th_86:
" for Y be setHIDDENM2 holds  for E1 be Equivalence-RelationEQREL-1M2-of Y holds  for E2 be Equivalence-RelationEQREL-1M2-of Y holds ClassEQREL-1K9\<^bsub>(Y)\<^esub> E1 =XBOOLE-0R4 ClassEQREL-1K9\<^bsub>(Y)\<^esub> E2 implies E1 =RELAT-1R1 E2"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix E1 assume [ty]: "E1 be Equivalence-RelationEQREL-1M2-of Y"
  fix E2 assume [ty]: "E2 be Equivalence-RelationEQREL-1M2-of Y"
  assume A1: "ClassEQREL-1K9\<^bsub>(Y)\<^esub> E1 =XBOOLE-0R4 ClassEQREL-1K9\<^bsub>(Y)\<^esub> E2"
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 E1 implies x inHIDDENR3 E2) & (x inHIDDENR3 E2 implies x inHIDDENR3 E1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 E1 implies x inHIDDENR3 E2"
    proof(rule impI)
      assume A2: "x inHIDDENR3 E1"
      then obtain a b where
        [ty]:"a be objectHIDDENM1" "b be objectHIDDENM1" and 
        A3: "x =HIDDENR1 [TARSKIK4 a,b ]"and A4: "a inHIDDENR3 Y"and A5: "b inHIDDENR3 Y"
        using relset_1_th_2 sorry
      have 
        [ty]:"a be ElementSUBSET-1M1-of Y" and
        [ty]:"b be ElementSUBSET-1M1-of Y"
        using A4 A5 sorry
      have "ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E1,b) inTARSKIR2 ClassEQREL-1K9\<^bsub>(Y)\<^esub> E2"
        using A1 A4 eqrel_1_def_3 sorry
      then obtain c where
        [ty]:"c be objectHIDDENM1" and 
        "c inHIDDENR3 Y"and A6: "ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E1,b) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E2,c)"
        using eqrel_1_def_3 sorry
      have "b inTARSKIR2 ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E1,b)"
        using A4 eqrel_1_th_20 sorry
      then have "[TARSKIK4 b,c ] inHIDDENR3 E2"
        using A6 eqrel_1_th_19 sorry
      then have A7: "[TARSKIK4 c,b ] inHIDDENR3 E2"
        using eqrel_1_th_6 sorry
      have "a inTARSKIR2 ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E1,b)"
        using A2 A3 eqrel_1_th_19 sorry
      then have "[TARSKIK4 a,c ] inHIDDENR3 E2"
        using A6 eqrel_1_th_19 sorry
      thus "x inHIDDENR3 E2"
        using A3 A7 eqrel_1_th_7 sorry
    qed
    assume A8: "x inHIDDENR3 E2"
    then obtain a b where
      [ty]:"a be objectHIDDENM1" "b be objectHIDDENM1" and 
      A9: "x =HIDDENR1 [TARSKIK4 a,b ]"and A10: "a inHIDDENR3 Y"and A11: "b inHIDDENR3 Y"
      using relset_1_th_2 sorry
    have 
      [ty]:"a be ElementSUBSET-1M1-of Y" and
      [ty]:"b be ElementSUBSET-1M1-of Y"
      using A10 A11 sorry
    have "ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E2,b) inTARSKIR2 ClassEQREL-1K9\<^bsub>(Y)\<^esub> E1"
      using A1 A10 eqrel_1_def_3 sorry
    then obtain c where
      [ty]:"c be objectHIDDENM1" and 
      "c inHIDDENR3 Y"and A12: "ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E2,b) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E1,c)"
      using eqrel_1_def_3 sorry
    have "b inTARSKIR2 ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E2,b)"
      using A10 eqrel_1_th_20 sorry
    then have "[TARSKIK4 b,c ] inHIDDENR3 E1"
      using A12 eqrel_1_th_19 sorry
    then have A13: "[TARSKIK4 c,b ] inHIDDENR3 E1"
      using eqrel_1_th_6 sorry
    have "a inTARSKIR2 ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(E2,b)"
      using A8 A9 eqrel_1_th_19 sorry
    then have "[TARSKIK4 a,c ] inHIDDENR3 E1"
      using A12 eqrel_1_th_19 sorry
    thus "x inHIDDENR3 E1"
      using A9 A13 eqrel_1_th_7 sorry
  qed "sorry"
  thus "E1 =RELAT-1R1 E2"
     sorry
qed "sorry"

mtheorem finseq_4_cl_7:
  mlet "Z be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for a-partitionEQREL-1M3-of Z"
proof
(*coherence*)
  show " for it be a-partitionEQREL-1M3-of Z holds it be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem finseq_4_cl_8:
  mlet "X be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1 for a-partitionEQREL-1M3-of X"
proof
(*existence*)
  show " ex it be a-partitionEQREL-1M3-of X st it be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1"
  proof-
    have " ex tVar12 be a-partitionEQREL-1M3-of X st  not tVar12 be emptyXBOOLE-0V1 & tVar12 be finiteFINSET-1V1"
    proof-
      let ?p = "the a-partitionEQREL-1M3-of X"
      show " ex tVar12 be a-partitionEQREL-1M3-of X st  not tVar12 be emptyXBOOLE-0V1 & tVar12 be finiteFINSET-1V1"
      proof(rule bexI[of _ "?p"])
        show " not the a-partitionEQREL-1M3-of X be emptyXBOOLE-0V1 & the a-partitionEQREL-1M3-of X be finiteFINSET-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve X, A for " non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
reserve PX for "a-partitionEQREL-1M3-of X"
reserve PA1, PA2 for "a-partitionEQREL-1M3-of A"
mtheorem finseq_4_th_87:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PX be a-partitionEQREL-1M3-of X holds  for Pi be setHIDDENM2 holds Pi inTARSKIR2 PX implies ( ex x be ElementSUBSET-1M1-of X st x inTARSKIR2 Pi)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PX be a-partitionEQREL-1M3-of X holds  for Pi be setHIDDENM2 holds Pi inTARSKIR2 PX implies ( ex tVar13 be ElementSUBSET-1M1-of X st tVar13 inTARSKIR2 Pi)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PX assume [ty]: "PX be a-partitionEQREL-1M3-of X"
    fix Pi assume [ty]: "Pi be setHIDDENM2"
    assume "Pi inTARSKIR2 PX"
    then have 
      [ty]:"Pi be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of PX"
       sorry
    let ?q = "the ElementSUBSET-1M3\<^bsub>(X)\<^esub>-of Pi"
    obtain q where 
      [ty]:"q be ElementSUBSET-1M1-of X" and qDef:"q = ?q"
       sorry
    show " ex tVar13 be ElementSUBSET-1M1-of X st tVar13 inTARSKIR2 Pi"
    proof(rule bexI[of _ "q"])
      show "q inTARSKIR2 Pi"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_88:
" for X be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for PX be a-partitionEQREL-1M3-of X holds cardCARD-1K4 PX <=XXREAL-0R1 cardCARD-1K4 X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for PX be a-partitionEQREL-1M3-of X holds cardCARD-1K4 PX >XXREAL-0R4 cardCARD-1K4 X implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix PX assume [ty]: "PX be a-partitionEQREL-1M3-of X"
    assume "cardCARD-1K4 PX >XXREAL-0R4 cardCARD-1K4 X"
    then have "cardCARD-1K4 (SegmCARD-1K5 cardCARD-1K4 X) inTARSKIR2 cardCARD-1K4 (SegmCARD-1K5 cardCARD-1K4 PX)"
      using nat_1_th_41 sorry
    then obtain Pi where
      [ty]:"Pi be objectHIDDENM1" and 
      A1: "Pi inHIDDENR3 PX"and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies projEQREL-1K16\<^bsub>(X)\<^esub> PX .FUNCT-1K1 x <>HIDDENR2 Pi"
      using finseq_4_th_66 sorry
    have 
      [ty]:"Pi be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of PX"
      using A1 sorry
    obtain q where
      [ty]:"q be ElementSUBSET-1M1-of X" and 
      A3: "q inTARSKIR2 Pi"
      using finseq_4_th_87 sorry
    obtain Pq where 
      [ty]:"Pq be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of PX" and PqDef:"Pq = projEQREL-1K16\<^bsub>(X)\<^esub> PX .FUNCT-2K3\<^bsub>(X,PX)\<^esub> q"
       sorry
    have A4: "Pq =XBOOLE-0R4 Pi or Pq missesSUBSET-1R1 Pi"
      using eqrel_1_def_4 sorry
    have "q inTARSKIR2 Pq"
      using eqrel_1_def_9 sorry
    thus " False "
      using A2 A3 A4 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_89:
" for A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for PA1 be a-partitionEQREL-1M3-of A holds  for PA2 be a-partitionEQREL-1M3-of A holds PA1 is-finer-thanSETFAM-1R1 PA2 implies cardCARD-1K4 PA2 <=XXREAL-0R1 cardCARD-1K4 PA1"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for PA1 be a-partitionEQREL-1M3-of A holds  for PA2 be a-partitionEQREL-1M3-of A holds PA1 is-finer-thanSETFAM-1R1 PA2 implies (cardCARD-1K4 PA1 <XXREAL-0R3 cardCARD-1K4 PA2 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix PA1 assume [ty]: "PA1 be a-partitionEQREL-1M3-of A"
    fix PA2 assume [ty]: "PA2 be a-partitionEQREL-1M3-of A"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st  ex B be setHIDDENM2 st (A =HIDDENR1 Lamb1 & B =HIDDENR1 Lamb2) & A c=TARSKIR1 B"
    assume A1: "PA1 is-finer-thanSETFAM-1R1 PA2"
    have A2: " for e be objectHIDDENM1 holds e inHIDDENR3 PA1 implies ( ex u be objectHIDDENM1 st u inHIDDENR3 PA2 & ?P(e,u))"
    proof-
      have " for e be objectHIDDENM1 holds e inHIDDENR3 PA1 implies  not ( for u be objectHIDDENM1 holds  not (u inHIDDENR3 PA2 & ( ex A be setHIDDENM2 st  ex B be setHIDDENM2 st (A =HIDDENR1 e & B =HIDDENR1 u) & A c=TARSKIR1 B)))"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        obtain ee where 
          [ty]:"ee be setHIDDENM2" and eeDef:"ee = e"
          using tarski_th_1 sorry
        assume "e inHIDDENR3 PA1"
        then have "ee inTARSKIR2 PA1"
           sorry
        then have " ex u be setHIDDENM2 st u inTARSKIR2 PA2 & ee c=TARSKIR1 u"
          using setfam_1_def_2 A1 sorry
        thus " not ( for u be objectHIDDENM1 holds  not (u inHIDDENR3 PA2 & ( ex A be setHIDDENM2 st  ex B be setHIDDENM2 st (A =HIDDENR1 e & B =HIDDENR1 u) & A c=TARSKIR1 B)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-2M1-of(PA1,PA2)" and 
      A3: " for e be objectHIDDENM1 holds e inHIDDENR3 PA1 implies ?P(e,f .FUNCT-1K1 e)"
      using funct_2_sch_1 A2 sorry
    assume "cardCARD-1K4 PA1 <XXREAL-0R3 cardCARD-1K4 PA2"
    then have "cardCARD-1K4 (SegmCARD-1K5 cardCARD-1K4 PA1) inTARSKIR2 cardCARD-1K4 (SegmCARD-1K5 cardCARD-1K4 PA2)"
      using nat_1_th_41 sorry
    then obtain p2i where
      [ty]:"p2i be objectHIDDENM1" and 
      A4: "p2i inHIDDENR3 PA2"and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 PA1 implies f .FUNCT-1K1 x <>HIDDENR2 p2i"
      using finseq_4_th_66 sorry
    have 
      [ty]:"p2i be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA2"
      using A4 sorry
    obtain q where
      [ty]:"q be ElementSUBSET-1M1-of A" and 
      A6: "q inTARSKIR2 p2i"
      using finseq_4_th_87 sorry
    obtain p2q where 
      [ty]:"p2q be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA2" and p2qDef:"p2q = f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> (projEQREL-1K16\<^bsub>(A)\<^esub> PA1 .FUNCT-2K3\<^bsub>(A,PA1)\<^esub> q)"
       sorry
    have A7: "p2q =XBOOLE-0R4 p2i or p2q missesSUBSET-1R1 p2i"
      using eqrel_1_def_4 sorry
    have "?P(projEQREL-1K16\<^bsub>(A)\<^esub> PA1 .FUNCT-2K3\<^bsub>(A,PA1)\<^esub> q,f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> (projEQREL-1K16\<^bsub>(A)\<^esub> PA1 .FUNCT-2K3\<^bsub>(A,PA1)\<^esub> q))"
      using A3 sorry
    then have "q inTARSKIR2 projEQREL-1K16\<^bsub>(A)\<^esub> PA1 .FUNCT-2K3\<^bsub>(A,PA1)\<^esub> q & projEQREL-1K16\<^bsub>(A)\<^esub> PA1 .FUNCT-2K3\<^bsub>(A,PA1)\<^esub> q c=TARSKIR1 p2q"
      using eqrel_1_def_9 sorry
    thus " False "
      using A5 A6 A7 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_90:
" for A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for PA1 be a-partitionEQREL-1M3-of A holds  for PA2 be a-partitionEQREL-1M3-of A holds PA1 is-finer-thanSETFAM-1R1 PA2 implies ( for p2 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA2 holds  ex p1 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1 st p1 c=TARSKIR1 p2)"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for PA1 be a-partitionEQREL-1M3-of A holds  for PA2 be a-partitionEQREL-1M3-of A holds PA1 is-finer-thanSETFAM-1R1 PA2 implies ( for p2 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA2 holds  ex tVar14 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1 st tVar14 c=TARSKIR1 p2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix PA1 assume [ty]: "PA1 be a-partitionEQREL-1M3-of A"
    fix PA2 assume [ty]: "PA2 be a-partitionEQREL-1M3-of A"
    assume A1: "PA1 is-finer-thanSETFAM-1R1 PA2"
    fix p2 assume [ty]: "p2 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA2"
    obtain E1 where
      [ty]:"E1 be Equivalence-RelationEQREL-1M2-of A" and 
      A2: "PA1 =XBOOLE-0R4 ClassEQREL-1K9\<^bsub>(A)\<^esub> E1"
      using eqrel_1_th_34 sorry
    obtain p29 where 
      [ty]:"p29 be SubsetSUBSET-1M2-of A" and p29Def:"p29 = p2"
       sorry
    obtain E2 where
      [ty]:"E2 be Equivalence-RelationEQREL-1M2-of A" and 
      A3: "PA2 =XBOOLE-0R4 ClassEQREL-1K9\<^bsub>(A)\<^esub> E2"
      using eqrel_1_th_34 sorry
    obtain a where
      [ty]:"a be objectHIDDENM1" and 
      A4: "a inHIDDENR3 A"and A5: "p29 =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(A,A)\<^esub>(E2,a)"
      using A3 eqrel_1_def_3 sorry
    have A6: "a inHIDDENR3 ClassEQREL-1K7\<^bsub>(A,A)\<^esub>(E1,a)"
      using A4 eqrel_1_th_20 sorry
    obtain E1a where 
      [ty]:"E1a be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1" and E1aDef:"E1a = ClassEQREL-1K7\<^bsub>(A,A)\<^esub>(E1,a)"
      using A2 A4 eqrel_1_def_3 sorry
    obtain p22 where
      [ty]:"p22 be setHIDDENM2" and 
      A7: "p22 inTARSKIR2 PA2"and A8: "E1a c=TARSKIR1 p22"
      using A1 setfam_1_def_2 sorry
    obtain p229 where 
      [ty]:"p229 be SubsetSUBSET-1M2-of A" and p229Def:"p229 = p22"
      using A7 sorry
    show " ex tVar14 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1 st tVar14 c=TARSKIR1 p2"
    proof(rule bexI[of _ "E1a"])
      have " ex b be objectHIDDENM1 st b inHIDDENR3 A & p229 =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(A,A)\<^esub>(E2,b)"
        using A3 A7 eqrel_1_def_3 sorry
      thus "E1a c=TARSKIR1 p2"
        using A5 A8 A6 eqrel_1_th_23 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_91:
" for A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for PA1 be a-partitionEQREL-1M3-of A holds  for PA2 be a-partitionEQREL-1M3-of A holds PA1 is-finer-thanSETFAM-1R1 PA2 & cardCARD-1K4 PA1 =XBOOLE-0R4 cardCARD-1K4 PA2 implies PA1 =XBOOLE-0R4 PA2"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for PA1 be a-partitionEQREL-1M3-of A holds  for PA2 be a-partitionEQREL-1M3-of A holds PA1 is-finer-thanSETFAM-1R1 PA2 & cardCARD-1K4 PA1 =XBOOLE-0R4 cardCARD-1K4 PA2 implies PA1 =XBOOLE-0R4 PA2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix PA1 assume [ty]: "PA1 be a-partitionEQREL-1M3-of A"
    fix PA2 assume [ty]: "PA2 be a-partitionEQREL-1M3-of A"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st  ex B be setHIDDENM2 st (A =HIDDENR1 Lamb1 & B =HIDDENR1 Lamb2) & A c=TARSKIR1 B"
    assume A1: "PA1 is-finer-thanSETFAM-1R1 PA2"
      and A2: "cardCARD-1K4 PA1 =XBOOLE-0R4 cardCARD-1K4 PA2"
    have A3: " for e be objectHIDDENM1 holds e inHIDDENR3 PA1 implies ( ex u be objectHIDDENM1 st u inHIDDENR3 PA2 & ?P(e,u))"
    proof-
      have " for e be objectHIDDENM1 holds e inHIDDENR3 PA1 implies  not ( for u be objectHIDDENM1 holds  not (u inHIDDENR3 PA2 & ( ex A be setHIDDENM2 st  ex B be setHIDDENM2 st (A =HIDDENR1 e & B =HIDDENR1 u) & A c=TARSKIR1 B)))"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        obtain ee where 
          [ty]:"ee be setHIDDENM2" and eeDef:"ee = e"
          using tarski_th_1 sorry
        assume "e inHIDDENR3 PA1"
        then have "ee inTARSKIR2 PA1"
           sorry
        then have " ex u be setHIDDENM2 st u inTARSKIR2 PA2 & ee c=TARSKIR1 u"
          using setfam_1_def_2 A1 sorry
        thus " not ( for u be objectHIDDENM1 holds  not (u inHIDDENR3 PA2 & ( ex A be setHIDDENM2 st  ex B be setHIDDENM2 st (A =HIDDENR1 e & B =HIDDENR1 u) & A c=TARSKIR1 B)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-2M1-of(PA1,PA2)" and 
      A4: " for e be objectHIDDENM1 holds e inHIDDENR3 PA1 implies ?P(e,f .FUNCT-1K1 e)"
      using funct_2_sch_1 A3 sorry
    have A5: "domRELAT-1K1 f =XBOOLE-0R4 PA1"
      using funct_2_def_1 sorry
    have A6: "PA2 c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for p2 be objectHIDDENM1 holds p2 inHIDDENR3 PA2 implies p2 inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix p2 assume [ty]: "p2 be objectHIDDENM1"
        assume "p2 inHIDDENR3 PA2"
        then obtain p29 where 
          [ty]:"p29 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA2" and p29Def:"p29 = p2"
           sorry
        obtain p1 where
          [ty]:"p1 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1" and 
          A7: "p1 c=TARSKIR1 p29"
          using A1 finseq_4_th_90 sorry
        obtain fp1 where 
          [ty]:"fp1 be SubsetSUBSET-1M2-of A" and fp1Def:"fp1 = f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> p1"
          using tarski_def_3 sorry
        have "?P(p1,f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> p1)"
          using A4 sorry
        then have A8: "p1 c=TARSKIR1 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> p1"
           sorry
        have "p29 meetsSUBSET-1R2 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> p1"
        proof-
          have " not p29 meetsSUBSET-1R2 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> p1"
          proof-
            have " ex x be ElementSUBSET-1M1-of A st x inTARSKIR2 p1"
              using finseq_4_th_87 sorry
            thus " not p29 meetsSUBSET-1R2 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> p1"
              using A7 A8 xboole_0_th_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have "p29 =XBOOLE-0R4 fp1"
          using eqrel_1_def_4 sorry
        thus "p2 inHIDDENR3 rngFUNCT-1K2 f"
          using A5 funct_1_def_3 sorry
      qed "sorry"
      thus "PA2 c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    have "rngFUNCT-1K2 f c=TARSKIR1 PA2"
      using relat_1_def_19 sorry
    then have "rngFUNCT-1K2 f =XBOOLE-0R4 PA2"
      using A6 sorry
    then have A9: "f be one-to-oneFUNCT-1V2"
      using A2 finseq_4_lm_1 sorry
    have A10: " for x be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1 holds x =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x"
    proof-
      have " for x be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1 holds x <>HIDDENR2 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x implies  False "
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1"
        obtain fx where 
          [ty]:"fx be SubsetSUBSET-1M2-of A" and fxDef:"fx = f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x"
          using tarski_def_3 sorry
        obtain E1 where
          [ty]:"E1 be Equivalence-RelationEQREL-1M2-of A" and 
          A11: "PA1 =XBOOLE-0R4 ClassEQREL-1K9\<^bsub>(A)\<^esub> E1"
          using eqrel_1_th_34 sorry
        assume "x <>HIDDENR2 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x"
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A12: "a inHIDDENR3 x &  not a inHIDDENR3 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x or a inHIDDENR3 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x &  not a inHIDDENR3 x"
          using tarski_th_2 sorry
        have A13: "fx c=TARSKIR1 A"
           sorry
        then have A14: "a inHIDDENR3 ClassEQREL-1K7\<^bsub>(A,A)\<^esub>(E1,a)"
          using A12 eqrel_1_th_20 sorry
        obtain CE1a where 
          [ty]:"CE1a be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1" and CE1aDef:"CE1a = ClassEQREL-1K7\<^bsub>(A,A)\<^esub>(E1,a)"
          using A13 A12 A11 eqrel_1_def_3 sorry
        obtain fCE1a where 
          [ty]:"fCE1a be SubsetSUBSET-1M2-of A" and fCE1aDef:"fCE1a = f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> CE1a"
          using tarski_def_3 sorry
        have "?P(x,f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x)"
          using A4 sorry
        then have A15: "x c=TARSKIR1 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x"
           sorry
        have "?P(CE1a,f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> CE1a)"
          using A4 sorry
        then have "CE1a c=TARSKIR1 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> CE1a"
           sorry
        then have "fx meetsXBOOLE-0R5 fCE1a"
          using A15 A12 A14 xboole_0_th_3 sorry
        then have "fx =XBOOLE-0R4 fCE1a"
          using eqrel_1_def_4 sorry
        thus " False "
          using A5 A9 A15 A12 A14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 PA1 implies x inHIDDENR3 PA2) & (x inHIDDENR3 PA2 implies x inHIDDENR3 PA1)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 PA1 implies x inHIDDENR3 PA2"
      proof(rule impI)
        assume "x inHIDDENR3 PA1"
        then obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1" and x9Def:"x9 = x"
           sorry
        let ?fx = "f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> x9"
        have "?fx inTARSKIR2 PA2"
           sorry
        thus "x inHIDDENR3 PA2"
          using A10 sorry
      qed
      assume "x inHIDDENR3 PA2"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A16: "y inHIDDENR3 domRELAT-1K1 f"and A17: "x =HIDDENR1 f .FUNCT-1K1 y"
        using A6 funct_1_def_3 sorry
      obtain y9 where 
        [ty]:"y9 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 A)\<^esub>-of PA1" and y9Def:"y9 = y"
        using A16 funct_2_def_1 sorry
      have "y9 =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(PA1,PA2)\<^esub> y9"
        using A10 sorry
      thus "x inHIDDENR3 PA1"
        using A17 sorry
    qed "sorry"
    thus "PA1 =XBOOLE-0R4 PA2"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_cl_9:
  mlet "D be setHIDDENM2", "M be FinSequenceFINSEQ-1M3-of D * FINSEQ-1K14", "k be NatNAT-1M1"
"cluster M /.PARTFUN1K7\<^bsub>(D * FINSEQ-1K14)\<^esub> k as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "M /.PARTFUN1K7\<^bsub>(D * FINSEQ-1K14)\<^esub> k be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem finseq_4_cl_10:
  mlet "D be setHIDDENM2", "M be FinSequenceFINSEQ-1M3-of D * FINSEQ-1K14", "k be NatNAT-1M1"
"cluster M /.PARTFUN1K7\<^bsub>(D * FINSEQ-1K14)\<^esub> k as-term-is FinSequence-likeFINSEQ-1V1\<bar>D -valuedRELAT-1V5 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it =HIDDENR1 M /.PARTFUN1K7\<^bsub>(D * FINSEQ-1K14)\<^esub> k implies it be FinSequence-likeFINSEQ-1V1\<bar>D -valuedRELAT-1V5"
    using finseq_1_def_11 sorry
qed "sorry"

reserve f for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_4_th_92:
" for m be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
proof-
  have " for m be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "m inTARSKIR2 domFINSEQ-1K5 f"
    have "\<one>\<^sub>M <=XXREAL-0R1 m"
      using A1 finseq_3_th_25 sorry
    then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 m"
       sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using A1 finseq_4_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_4_th_93:
" for m be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> m =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)"
proof-
  have " for m be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds m inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> m =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "m inTARSKIR2 domFINSEQ-1K5 f"
    have "m <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_3_th_25 sorry
    then have A2: "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m) =XBOOLE-0R4 m"
      using finseq_1_th_59 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 m"
      using A1 finseq_3_th_25 sorry
    then have "m inTARSKIR2 SegFINSEQ-1K2 m"
       sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> m =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> m)"
      using A1 A2 finseq_4_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
