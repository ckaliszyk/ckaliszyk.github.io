theory partit1
  imports finseq_4 classes1 membered
   "../mizar_extension/E_number"
begin
(*begin*)
reserve Y, Z for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve PA, PB for "a-partitionEQREL-1M3-of Y"
reserve A, B for "SubsetSUBSET-1M2-of Y"
reserve i, j, k for "NatNAT-1M1"
reserve x, y, z, x1, x2, y1, z0, X, V, a, b, d, t, SFX, SFY for "setHIDDENM2"
mtheorem partit1_th_1:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X be setHIDDENM2 holds  for V be setHIDDENM2 holds (X inTARSKIR2 PA & V inTARSKIR2 PA) & X c=TARSKIR1 V implies X =XBOOLE-0R4 V"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X be setHIDDENM2 holds  for V be setHIDDENM2 holds X inTARSKIR2 PA & (V inTARSKIR2 PA & X c=TARSKIR1 V) implies X =XBOOLE-0R4 V"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix X assume [ty]: "X be setHIDDENM2"
    fix V assume [ty]: "V be setHIDDENM2"
    assume A1: "X inTARSKIR2 PA"
      and A2: "V inTARSKIR2 PA"
      and A3: "X c=TARSKIR1 V"
    have A4: "X =XBOOLE-0R4 V or X missesXBOOLE-0R1 V"
      using A1 A2 eqrel_1_def_4 sorry
    let ?x = "the ElementSUBSET-1M1-of X"
    have "X <>HIDDENR2 {}XBOOLE-0K1"
      using A1 eqrel_1_def_4 sorry
    then have "?x inTARSKIR2 X"
       sorry
    thus "X =XBOOLE-0R4 V"
      using A3 A4 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) PARTIT1R1(" _ ''<''PARTIT1R1  _ " [50,50]50) where
  "SFX '<'PARTIT1R1 SFY \<equiv> SFX is-finer-thanSETFAM-1R1 SFY"

abbreviation(input) PARTIT1R2(" _ ''>''PARTIT1R2  _ " [50,50]50) where
  "SFY '>'PARTIT1R2 SFX \<equiv> SFX is-finer-thanSETFAM-1R1 SFY"

mtheorem partit1_th_2:
" for SFX be setHIDDENM2 holds unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }) =XBOOLE-0R4 unionTARSKIK3 SFX"
proof-
  have " for SFX be setHIDDENM2 holds unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }) =XBOOLE-0R4 unionTARSKIK3 SFX"
  proof(rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    have A1: "unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }) c=TARSKIR1 unionTARSKIK3 SFX"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }) implies y inHIDDENR3 unionTARSKIK3 SFX"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 })"
        then have " ex z be setHIDDENM2 st y inHIDDENR3 z & z inTARSKIR2 SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_4 sorry
        thus "y inHIDDENR3 unionTARSKIK3 SFX"
          using tarski_def_4 sorry
      qed "sorry"
      thus "unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }) c=TARSKIR1 unionTARSKIK3 SFX"
        using tarski_def_3 sorry
    qed
    have "unionTARSKIK3 SFX c=TARSKIR1 unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 })"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 unionTARSKIK3 SFX implies y inHIDDENR3 unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 })"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 unionTARSKIK3 SFX"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A2: "y inHIDDENR3 X"and A3: "X inTARSKIR2 SFX"
          using tarski_def_4 sorry
        have " not X inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          using A2 tarski_def_1 sorry
        then have "X inTARSKIR2 SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
          using A3 xboole_0_def_5 sorry
        thus "y inHIDDENR3 unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 })"
          using A2 tarski_def_4 sorry
      qed "sorry"
      thus "unionTARSKIK3 SFX c=TARSKIR1 unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 })"
        using tarski_def_3 sorry
    qed
    thus "unionTARSKIK3 (SFX \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }) =XBOOLE-0R4 unionTARSKIK3 SFX"
      using A1 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_3:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB & PB '>'PARTIT1R2 PA implies PB c=TARSKIR1 PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB & PB '>'PARTIT1R2 PA implies PB c=TARSKIR1 PA"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    assume A1: "PA '>'PARTIT1R2 PB"
      and A2: "PB '>'PARTIT1R2 PA"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 PB implies x inHIDDENR3 PA"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      assume A3: "x inHIDDENR3 PB"
      then obtain V where
        [ty]:"V be setHIDDENM2" and 
        A4: "V inTARSKIR2 PA"and A5: "xx c=TARSKIR1 V"
        using A1 setfam_1_def_2 sorry
      obtain W where
        [ty]:"W be setHIDDENM2" and 
        A6: "W inTARSKIR2 PB"and A7: "V c=TARSKIR1 W"
        using A2 A4 setfam_1_def_2 sorry
      have "x =HIDDENR1 W"
        using A3 A5 A6 A7 partit1_th_1 xboole_1_th_1 sorry
      thus "x inHIDDENR3 PA"
        using A4 A5 A7 xboole_0_def_10 sorry
    qed "sorry"
    thus "PB c=TARSKIR1 PA"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_4:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB & PB '>'PARTIT1R2 PA implies PA =XBOOLE-0R4 PB"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB & PB '>'PARTIT1R2 PA implies PA =XBOOLE-0R4 PB"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    assume "PA '>'PARTIT1R2 PB & PB '>'PARTIT1R2 PA"
    then have "PB c=TARSKIR1 PA & PA c=TARSKIR1 PB"
      using partit1_th_3 sorry
    thus "PA =XBOOLE-0R4 PB"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_5:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB implies PA is-coarser-thanSETFAM-1R2 PB"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB implies PA is-coarser-thanSETFAM-1R2 PB"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    assume A1: "PA '>'PARTIT1R2 PB"
    have " for x be setHIDDENM2 holds x inTARSKIR2 PA implies ( ex y be setHIDDENM2 st y inTARSKIR2 PB & y c=TARSKIR1 x)"
    proof-
      have " for x be setHIDDENM2 holds x inTARSKIR2 PA implies  not ( for y be setHIDDENM2 holds  not (y inTARSKIR2 PB & y c=TARSKIR1 x))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume A2: "x inTARSKIR2 PA"
        then have A3: "x <>HIDDENR2 {}XBOOLE-0K1"
          using eqrel_1_def_4 sorry
        let ?u = "the ElementSUBSET-1M1-of x"
        have A4: "?u inTARSKIR2 x"
          using A3 sorry
        have "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PB =XBOOLE-0R4 Y"
          using eqrel_1_def_4 sorry
        then obtain y where
          [ty]:"y be setHIDDENM2" and 
          A5: "?u inTARSKIR2 y"and A6: "y inTARSKIR2 PB"
          using A2 A4 tarski_def_4 sorry
        obtain z where
          [ty]:"z be setHIDDENM2" and 
          A7: "z inTARSKIR2 PA"and A8: "y c=TARSKIR1 z"
          using A1 A6 setfam_1_def_2 sorry
        have "x =XBOOLE-0R4 z or x missesXBOOLE-0R1 z"
          using A2 A7 eqrel_1_def_4 sorry
        thus " not ( for y be setHIDDENM2 holds  not (y inTARSKIR2 PB & y c=TARSKIR1 x))"
          using A3 A5 A6 A8 xboole_0_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "PA is-coarser-thanSETFAM-1R2 PB"
      using setfam_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partit1_def_1 (" _ is-a-dependent-set-ofPARTIT1R3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y", "b be setHIDDENM2"
"pred b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA means
   ex B be setHIDDENM2 st (B c=TARSKIR1 PA & B <>HIDDENR2 {}XBOOLE-0K1) & b =XBOOLE-0R4 unionTARSKIK3 B"..

mdef partit1_def_2 (" _ is-min-dependPARTIT1R4\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [50,0,0,0]50 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y", "PB be a-partitionEQREL-1M3-of Y", "b be setHIDDENM2"
"pred b is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) means
  (b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB) & ( for d be setHIDDENM2 holds (d c=TARSKIR1 b & d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB implies d =XBOOLE-0R4 b)"..

mtheorem partit1_th_6:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB implies ( for b be setHIDDENM2 holds b inTARSKIR2 PA implies b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB)"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PB implies ( for b be setHIDDENM2 holds  not (b inTARSKIR2 PA &  not b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    assume A1: "PA '>'PARTIT1R2 PB"
    have A2: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PB =XBOOLE-0R4 Y"
      using eqrel_1_def_4 sorry
    have A3: "PA is-coarser-thanSETFAM-1R2 PB"
      using A1 partit1_th_5 sorry
    have " for b be setHIDDENM2 holds b inTARSKIR2 PA implies b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
    proof(rule ballI,rule impI)
      fix b assume [ty]: "b be setHIDDENM2"
      assume A4: "b inTARSKIR2 PA"
      let ?B0 = "{x8 where x8 be SubsetSUBSET-1M2-of Y : x8 inTARSKIR2 PB & x8 c=TARSKIR1 b }"
      obtain xb where
        [ty]:"xb be setHIDDENM2" and 
        A5: "xb inTARSKIR2 PB & xb c=TARSKIR1 b"
        using A3 A4 setfam_1_def_3 sorry
      have A6: "xb inTARSKIR2 ?B0"
        using A5 sorry
      have " for z be objectHIDDENM1 holds z inHIDDENR3 ?B0 implies z inHIDDENR3 PB"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 {x8 where x8 be SubsetSUBSET-1M2-of Y : x8 inTARSKIR2 PB & x8 c=TARSKIR1 b } implies z inHIDDENR3 PB"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 ?B0"
          then have " ex x8 be SubsetSUBSET-1M2-of Y st (x8 =HIDDENR1 z & x8 inTARSKIR2 PB) & x8 c=TARSKIR1 b"
             sorry
          thus "z inHIDDENR3 PB"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have A7: "?B0 c=TARSKIR1 PB"
         sorry
      have " for z be objectHIDDENM1 holds z inHIDDENR3 b implies z inHIDDENR3 unionTARSKIK3 ?B0"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 b implies z inHIDDENR3 unionTARSKIK3 ({x8 where x8 be SubsetSUBSET-1M2-of Y : x8 inTARSKIR2 PB & x8 c=TARSKIR1 b })"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A8: "z inHIDDENR3 b"
          then obtain x1 where
            [ty]:"x1 be setHIDDENM2" and 
            A9: "z inHIDDENR3 x1"and A10: "x1 inTARSKIR2 PB"
            using A2 A4 tarski_def_4 sorry
          obtain y1 where
            [ty]:"y1 be setHIDDENM2" and 
            A11: "y1 inTARSKIR2 PA"and A12: "x1 c=TARSKIR1 y1"
            using A1 A10 setfam_1_def_2 sorry
          have "b =XBOOLE-0R4 y1 or b missesXBOOLE-0R1 y1"
            using A4 A11 eqrel_1_def_4 sorry
          then have "x1 inTARSKIR2 ?B0"
            using A8 A9 A10 A12 xboole_0_th_3 sorry
          thus "z inHIDDENR3 unionTARSKIK3 ({x8 where x8 be SubsetSUBSET-1M2-of Y : x8 inTARSKIR2 PB & x8 c=TARSKIR1 b })"
            using A9 tarski_def_4 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have A13: "b c=TARSKIR1 unionTARSKIK3 ?B0"
         sorry
      have " for z be objectHIDDENM1 holds z inHIDDENR3 unionTARSKIK3 ?B0 implies z inHIDDENR3 b"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 unionTARSKIK3 ({x8 where x8 be SubsetSUBSET-1M2-of Y : x8 inTARSKIR2 PB & x8 c=TARSKIR1 b }) implies z inHIDDENR3 b"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 unionTARSKIK3 ?B0"
          then obtain y where
            [ty]:"y be setHIDDENM2" and 
            A14: "z inHIDDENR3 y"and A15: "y inTARSKIR2 ?B0"
            using tarski_def_4 sorry
          have " ex x8 be SubsetSUBSET-1M2-of Y st (x8 =XBOOLE-0R4 y & x8 inTARSKIR2 PB) & x8 c=TARSKIR1 b"
            using A15 sorry
          thus "z inHIDDENR3 b"
            using A14 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have "unionTARSKIK3 ?B0 c=TARSKIR1 b"
         sorry
      then have "b =XBOOLE-0R4 unionTARSKIK3 ?B0"
        using A13 xboole_0_def_10 sorry
      thus "b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
        using A6 A7 sorry
    qed "sorry"
    thus " for b be setHIDDENM2 holds  not (b inTARSKIR2 PA &  not b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_7:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds Y is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds Y is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    have A1: "{TARSKIK1 Y} be Subset-FamilySETFAM-1M1-of Y"
      using zfmisc_1_th_68 sorry
    have A2: "unionTARSKIK3 {TARSKIK1 Y} =XBOOLE-0R4 Y"
      using zfmisc_1_th_25 sorry
    have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 {TARSKIK1 Y} implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 {TARSKIK1 Y} implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
    proof-
      have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 {TARSKIK1 Y} implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 {TARSKIK1 Y} implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B))"
      proof(rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
        fix A assume [ty]: "A be SubsetSUBSET-1M2-of Y"
        assume A3: "A inTARSKIR2 {TARSKIK1 Y}"
        then have A4: "A =XBOOLE-0R4 Y"
          using tarski_def_1 sorry
        show "A <>HIDDENR2 {}XBOOLE-0K1"
          using A3 tarski_def_1 sorry
        fix B assume [ty]: "B be SubsetSUBSET-1M2-of Y"
        assume "B inTARSKIR2 {TARSKIK1 Y}"
        thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
          using A4 tarski_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A5: "{TARSKIK1 Y} be a-partitionEQREL-1M3-of Y"
      using A1 A2 eqrel_1_def_4 sorry
    have " for a be setHIDDENM2 holds a inTARSKIR2 PA implies ( ex b be setHIDDENM2 st b inTARSKIR2 {TARSKIK1 Y} & a c=TARSKIR1 b)"
    proof-
      have " for a be setHIDDENM2 holds a inTARSKIR2 PA implies  not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 {TARSKIK1 Y} & a c=TARSKIR1 b))"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be setHIDDENM2"
        assume A6: "a inTARSKIR2 PA"
        then have A7: "a <>HIDDENR2 {}XBOOLE-0K1"
          using eqrel_1_def_4 sorry
        let ?x = "the ElementSUBSET-1M1-of a"
        have "?x inTARSKIR2 Y"
          using A6 A7 tarski_def_3 sorry
        then obtain b where
          [ty]:"b be setHIDDENM2" and 
          "?x inTARSKIR2 b"and A8: "b inTARSKIR2 {TARSKIK1 Y}"
          using A2 tarski_def_4 sorry
        have "b =XBOOLE-0R4 Y"
          using A8 tarski_def_1 sorry
        thus " not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 {TARSKIK1 Y} & a c=TARSKIR1 b))"
          using A6 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A9: "{TARSKIK1 Y} '>'PARTIT1R2 PA"
      using setfam_1_def_2 sorry
    have "Y inTARSKIR2 {TARSKIK1 Y}"
      using tarski_def_1 sorry
    thus "Y is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
      using A5 A9 partit1_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_8:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for F be Subset-FamilySETFAM-1M1-of Y holds IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds X inTARSKIR2 F implies X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) implies IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for F be Subset-FamilySETFAM-1M1-of Y holds  not (( not IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds  not (X inTARSKIR2 F &  not X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA))) &  not IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of Y"
    show " not (( not IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds  not (X inTARSKIR2 F &  not X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA))) &  not IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA)"
    proof-
      have cases: "F =XBOOLE-0R4 {}XBOOLE-0K1 or F <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "F =XBOOLE-0R4 {}XBOOLE-0K1 implies  not (( not IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds  not (X inTARSKIR2 F &  not X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA))) &  not IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA)"
      proof(rule impI)
        assume "F =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F =XBOOLE-0R4 Y"
          using setfam_1_def_9 sorry
        thus " not (( not IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds  not (X inTARSKIR2 F &  not X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA))) &  not IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA)"
          using partit1_th_7 sorry
      qed
      have case2: "F <>HIDDENR2 {}XBOOLE-0K1 implies (IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds X inTARSKIR2 F implies X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) implies IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA)"
      proof(rule impI,rule impMI ,rule impI)
        assume A1: "F <>HIDDENR2 {}XBOOLE-0K1"
        then obtain F9 where 
          [ty]:"F9 be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of Y" and F9Def:"F9 = F"
           sorry
        assume A2: "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1"
          and A3: " for X be setHIDDENM2 holds X inTARSKIR2 F implies X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st ((A =HIDDENR1 Lamb2 & A c=TARSKIR1 PA) & Lamb2 <>HIDDENR2 {}XBOOLE-0K1) & Lamb1 =HIDDENR1 unionTARSKIK3 A"
        have A4: " for X be objectHIDDENM1 holds X inHIDDENR3 F implies ( ex B be objectHIDDENM1 st ?P(X,B))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 F implies  not ( for B be objectHIDDENM1 holds  not ( ex A be setHIDDENM2 st ((A =HIDDENR1 B & A c=TARSKIR1 PA) & B <>HIDDENR2 {}XBOOLE-0K1) & x =HIDDENR1 unionTARSKIK3 A))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            obtain X where 
              [ty]:"X be setHIDDENM2" and XDef:"X = x"
              using tarski_th_1 sorry
            assume "x inHIDDENR3 F"
            then have "X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
              using A3 sorry
            then have " ex B be setHIDDENM2 st (B c=TARSKIR1 PA & B <>HIDDENR2 {}XBOOLE-0K1) & X =XBOOLE-0R4 unionTARSKIK3 B"
               sorry
            then have " ex B be objectHIDDENM1 st ?P(X,B)"
               sorry
            thus " not ( for B be objectHIDDENM1 holds  not ( ex A be setHIDDENM2 st ((A =HIDDENR1 B & A c=TARSKIR1 PA) & B <>HIDDENR2 {}XBOOLE-0K1) & x =HIDDENR1 unionTARSKIK3 A))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A5: "domRELAT-1K1 f =XBOOLE-0R4 F & ( for X be objectHIDDENM1 holds X inHIDDENR3 F implies ?P(X,f .FUNCT-1K1 X))"
          using classes1_sch_1 A4 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 boolSETFAM-1K9 (boolSETFAM-1K9 Y)"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 boolSETFAM-1K9 (boolSETFAM-1K9 Y)"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            obtain yy where 
              [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
              using tarski_th_1 sorry
            assume "y inHIDDENR3 rngFUNCT-1K2 f"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A6: "x inHIDDENR3 domRELAT-1K1 f"and A7: "y =HIDDENR1 f .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have "?P(x,f .FUNCT-1K1 x)"
              using A5 A6 sorry
            then have "f .FUNCT-1K1 x c=TARSKIR1 PA"
               sorry
            then have "yy c=TARSKIR1 boolSETFAM-1K9 Y"
              using A7 xboole_1_th_1 sorry
            thus "y inHIDDENR3 boolSETFAM-1K9 (boolSETFAM-1K9 Y)"
               sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 boolSETFAM-1K9 (boolSETFAM-1K9 Y)"
            using tarski_def_3 sorry
        qed
        then have 
          [ty]:"f be FunctionFUNCT-2M1-of(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))"
          using A5 funct_2_def_1 relset_1_th_4 sorry
        let ?P1 = "\<lambda>Lamb1. Lamb1 inTARSKIR2 F"
        let ?S = "\<lambda>Lamb1. f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> Lamb1"
        obtain T where 
          [ty]:"T be Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 Y" and TDef:"T = {?S(X) where X be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of F9 : ?P1(X) }"
          using domain_1_sch_8 sorry
        have 
          [ty]:"T be Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 Y"
           sorry
        obtain B where 
          [ty]:"B be ElementSUBSET-1M1-of boolZFMISC-1K1 (boolSETFAM-1K9 Y)" and BDef:"B = IntersectSETFAM-1K8\<^bsub>(boolSETFAM-1K9 Y)\<^esub> T"
           sorry
        have " ex B be ElementSUBSET-1M1-of boolZFMISC-1K1 (boolSETFAM-1K9 Y) st B c=TARSKIR1 PA & (B <>HIDDENR2 {}XBOOLE-0K1 & IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F =XBOOLE-0R4 unionSETFAM-1K5\<^bsub>(Y)\<^esub> B)"
        proof(rule bexI[of _ "B"],rule conjMI,rule conjMI)
          show "B c=TARSKIR1 PA"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 B implies x inHIDDENR3 PA"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A8: "x inHIDDENR3 B"
              obtain X where
                [ty]:"X be objectHIDDENM1" and 
                A9: "X inHIDDENR3 F"
                using A1 xboole_0_def_1 sorry
              have "f .FUNCT-1K1 X inTARSKIR2 T"
                using A9 sorry
              then have A10: "x inHIDDENR3 f .FUNCT-1K1 X"
                using A8 setfam_1_th_43 sorry
              have "?P(X,f .FUNCT-1K1 X)"
                using A5 A9 sorry
              then have "f .FUNCT-1K1 X c=TARSKIR1 PA"
                 sorry
              thus "x inHIDDENR3 PA"
                using A10 sorry
            qed "sorry"
            thus "B c=TARSKIR1 PA"
              using tarski_def_3 sorry
          qed
          show "B <>HIDDENR2 {}XBOOLE-0K1"
          proof-
            have " not B <>HIDDENR2 {}XBOOLE-0K1"
            proof-
              obtain X where
                [ty]:"X be objectHIDDENM1" and 
                A11: "X inHIDDENR3 F"
                using A1 xboole_0_def_1 sorry
              have A12: "f .FUNCT-1K1 X inTARSKIR2 T"
                using A11 sorry
              obtain A where
                [ty]:"A be objectHIDDENM1" and 
                A13: "A inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F"
                using A2 xboole_0_def_1 sorry
              have 
                [ty]:"A be ElementSUBSET-1M1-of Y"
                using A13 sorry
              let ?AA = "EqClassEQREL-1K14\<^bsub>(Y)\<^esub>(A,PA)"
              have A14: "A inTARSKIR2 meetSETFAM-1K6\<^bsub>(Y)\<^esub> F"
                using A1 A13 setfam_1_def_9 sorry
              have " for X be setHIDDENM2 holds X inTARSKIR2 T implies ?AA inTARSKIR2 X"
              proof-
                have " for X be setHIDDENM2 holds X inTARSKIR2 T implies EqClassEQREL-1K14\<^bsub>(Y)\<^esub>(A,PA) inTARSKIR2 X"
                proof(rule ballI,rule impI)
                  fix X assume [ty]: "X be setHIDDENM2"
                  assume "X inTARSKIR2 T"
                  then obtain z where
                    [ty]:"z be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of F9" and 
                    A15: "X =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z"and "z inTARSKIR2 F"
                     sorry
                  have A16: "?P(z,f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z)"
                    using A5 sorry
                  then have A17: "f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z c=TARSKIR1 PA"
                     sorry
                  have "z =XBOOLE-0R4 unionSETFAM-1K5\<^bsub>(Y)\<^esub> (f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z) & A inTARSKIR2 z"
                    using A14 setfam_1_def_1 A16 sorry
                  then have " ex A0 be setHIDDENM2 st A inTARSKIR2 A0 & A0 inTARSKIR2 f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z"
                    using tarski_def_4 sorry
                  thus "EqClassEQREL-1K14\<^bsub>(Y)\<^esub>(A,PA) inTARSKIR2 X"
                    using A15 A17 eqrel_1_def_6 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              then have "EqClassEQREL-1K14\<^bsub>(Y)\<^esub>(A,PA) inTARSKIR2 meetSETFAM-1K6\<^bsub>(boolSETFAM-1K9 Y)\<^esub> T"
                using A12 setfam_1_def_1 sorry
              thus " not B <>HIDDENR2 {}XBOOLE-0K1"
                using setfam_1_def_9 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have A18: "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F c=TARSKIR1 unionSETFAM-1K5\<^bsub>(Y)\<^esub> B"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F implies x inHIDDENR3 unionSETFAM-1K5\<^bsub>(Y)\<^esub> B"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A19: "x inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F"
              then have A20: "x inHIDDENR3 meetSETFAM-1K6\<^bsub>(Y)\<^esub> F"
                using A1 setfam_1_def_9 sorry
              have 
                [ty]:"x be ElementSUBSET-1M1-of Y"
                using A19 sorry
              have 
                [ty]:"PA be a-partitionEQREL-1M3-of Y"
                 sorry
              let ?A = "EqClassEQREL-1K14\<^bsub>(Y)\<^esub>(x,PA)"
              obtain X where
                [ty]:"X be objectHIDDENM1" and 
                A21: "X inHIDDENR3 F"
                using A1 xboole_0_def_1 sorry
              have A22: "f .FUNCT-1K1 X inTARSKIR2 T"
                using A21 sorry
              have " for X be setHIDDENM2 holds X inTARSKIR2 T implies ?A inTARSKIR2 X"
              proof-
                have " for X be setHIDDENM2 holds X inTARSKIR2 T implies EqClassEQREL-1K14\<^bsub>(Y)\<^esub>(x,PA) inTARSKIR2 X"
                proof(rule ballI,rule impI)
                  fix X assume [ty]: "X be setHIDDENM2"
                  assume "X inTARSKIR2 T"
                  then obtain z where
                    [ty]:"z be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of F9" and 
                    A23: "X =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z"and "z inTARSKIR2 F"
                     sorry
                  have A24: "?P(z,f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z)"
                    using A5 sorry
                  then have A25: "f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z c=TARSKIR1 PA"
                     sorry
                  have "z =XBOOLE-0R4 unionSETFAM-1K5\<^bsub>(Y)\<^esub> (f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z)"
                    using A24 sorry
                  then have "x inTARSKIR2 unionSETFAM-1K5\<^bsub>(Y)\<^esub> (f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z)"
                    using A20 setfam_1_def_1 sorry
                  then have " ex A0 be setHIDDENM2 st x inTARSKIR2 A0 & A0 inTARSKIR2 f .FUNCT-2K3\<^bsub>(F9,boolSETFAM-1K9 (boolSETFAM-1K9 Y))\<^esub> z"
                    using tarski_def_4 sorry
                  thus "EqClassEQREL-1K14\<^bsub>(Y)\<^esub>(x,PA) inTARSKIR2 X"
                    using A23 A25 eqrel_1_def_6 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              then have "?A inTARSKIR2 meetSETFAM-1K6\<^bsub>(boolSETFAM-1K9 Y)\<^esub> T"
                using A22 setfam_1_def_1 sorry
              then have "x inTARSKIR2 ?A & ?A inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(boolSETFAM-1K9 Y)\<^esub> T"
                using A22 eqrel_1_def_6 setfam_1_def_9 sorry
              thus "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(Y)\<^esub> B"
                using tarski_def_4 sorry
            qed "sorry"
            thus "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F c=TARSKIR1 unionSETFAM-1K5\<^bsub>(Y)\<^esub> B"
              using tarski_def_3 sorry
          qed
          have "unionSETFAM-1K5\<^bsub>(Y)\<^esub> B c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 unionSETFAM-1K5\<^bsub>(Y)\<^esub> B implies x inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A26: "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(Y)\<^esub> B"
              obtain X where
                [ty]:"X be objectHIDDENM1" and 
                A27: "X inHIDDENR3 F"
                using A1 xboole_0_def_1 sorry
              have A28: "f .FUNCT-1K1 X inTARSKIR2 T"
                using A27 sorry
              obtain y where
                [ty]:"y be setHIDDENM2" and 
                A29: "x inHIDDENR3 y"and A30: "y inTARSKIR2 B"
                using A26 tarski_def_4 sorry
              have A31: "y inTARSKIR2 meetSETFAM-1K6\<^bsub>(boolSETFAM-1K9 Y)\<^esub> T"
                using A28 A30 setfam_1_def_9 sorry
              have " for X be setHIDDENM2 holds X inTARSKIR2 F implies x inHIDDENR3 X"
              proof(rule ballI,rule impI)
                fix X assume [ty]: "X be setHIDDENM2"
                assume A32: "X inTARSKIR2 F"
                then have "f .FUNCT-1K1 X inTARSKIR2 T"
                   sorry
                then have A33: "y inTARSKIR2 f .FUNCT-1K1 X"
                  using A31 setfam_1_def_1 sorry
                have "?P(X,f .FUNCT-1K1 X)"
                  using A5 A32 sorry
                then have "X =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 X)"
                   sorry
                thus "x inHIDDENR3 X"
                  using A29 A33 tarski_def_4 sorry
              qed "sorry"
              then have "x inHIDDENR3 meetSETFAM-1K6\<^bsub>(Y)\<^esub> F"
                using A1 setfam_1_def_1 sorry
              thus "x inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F"
                using A1 setfam_1_def_9 sorry
            qed "sorry"
            thus "unionSETFAM-1K5\<^bsub>(Y)\<^esub> B c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F"
              using tarski_def_3 sorry
          qed
          thus "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F =XBOOLE-0R4 unionSETFAM-1K5\<^bsub>(Y)\<^esub> B"
            using A18 xboole_0_def_10 sorry
        qed "sorry"
        thus "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> F is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
          using partit1_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_9:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X0 be SubsetSUBSET-1M2-of Y holds  for X1 be SubsetSUBSET-1M2-of Y holds (X0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & X0 meetsXBOOLE-0R5 X1 implies X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X0 be SubsetSUBSET-1M2-of Y holds  for X1 be SubsetSUBSET-1M2-of Y holds X0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & (X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & X0 meetsXBOOLE-0R5 X1) implies X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix X0 assume [ty]: "X0 be SubsetSUBSET-1M2-of Y"
    fix X1 assume [ty]: "X1 be SubsetSUBSET-1M2-of Y"
    assume A1: "X0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
      and A2: "X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
      and A3: "X0 meetsXBOOLE-0R5 X1"
    obtain A where
      [ty]:"A be setHIDDENM2" and 
      A4: "A c=TARSKIR1 PA"and "A <>HIDDENR2 {}XBOOLE-0K1"and A5: "X0 =XBOOLE-0R4 unionTARSKIK3 A"
      using A1 sorry
    obtain B where
      [ty]:"B be setHIDDENM2" and 
      A6: "B c=TARSKIR1 PA"and "B <>HIDDENR2 {}XBOOLE-0K1"and A7: "X1 =XBOOLE-0R4 unionTARSKIK3 B"
      using A2 sorry
    have A8: "X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1 c=TARSKIR1 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1 implies x inHIDDENR3 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A9: "x inHIDDENR3 X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1"
        then have A10: "x inHIDDENR3 X0"
          using xboole_0_def_4 sorry
        have A11: "x inHIDDENR3 X1"
          using A9 xboole_0_def_4 sorry
        obtain y where
          [ty]:"y be setHIDDENM2" and 
          A12: "x inHIDDENR3 y"and A13: "y inTARSKIR2 A"
          using A5 A10 tarski_def_4 sorry
        obtain z where
          [ty]:"z be setHIDDENM2" and 
          A14: "x inHIDDENR3 z"and A15: "z inTARSKIR2 B"
          using A7 A11 tarski_def_4 sorry
        have A16: "y inTARSKIR2 PA"
          using A4 A13 sorry
        have A17: "z inTARSKIR2 PA"
          using A6 A15 sorry
        have "y meetsXBOOLE-0R5 z"
          using A12 A14 xboole_0_th_3 sorry
        then have "y =XBOOLE-0R4 z"
          using A16 A17 eqrel_1_def_4 sorry
        then have "y inTARSKIR2 A /\\XBOOLE-0K3 B"
          using A13 A15 xboole_0_def_4 sorry
        thus "x inHIDDENR3 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
          using A12 tarski_def_4 sorry
      qed "sorry"
      thus "X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1 c=TARSKIR1 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
        using tarski_def_3 sorry
    qed
    have "unionTARSKIK3 (A /\\XBOOLE-0K3 B) c=TARSKIR1 X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (A /\\XBOOLE-0K3 B) implies x inHIDDENR3 X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
        then obtain y where
          [ty]:"y be setHIDDENM2" and 
          A18: "x inHIDDENR3 y"and A19: "y inTARSKIR2 A /\\XBOOLE-0K3 B"
          using tarski_def_4 sorry
        have A20: "y inTARSKIR2 A"
          using A19 xboole_0_def_4 sorry
        have A21: "y inTARSKIR2 B"
          using A19 xboole_0_def_4 sorry
        have A22: "x inHIDDENR3 X0"
          using A5 A18 A20 tarski_def_4 sorry
        have "x inHIDDENR3 X1"
          using A7 A18 A21 tarski_def_4 sorry
        thus "x inHIDDENR3 X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1"
          using A22 xboole_0_def_4 sorry
      qed "sorry"
      thus "unionTARSKIK3 (A /\\XBOOLE-0K3 B) c=TARSKIR1 X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1"
        using tarski_def_3 sorry
    qed
    then have A23: "X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1 =XBOOLE-0R4 unionTARSKIK3 (A /\\XBOOLE-0K3 B)"
      using A8 xboole_0_def_10 sorry
    have A24: "A \\/XBOOLE-0K2 B c=TARSKIR1 PA"
      using A4 A6 xboole_1_th_8 sorry
    have "A /\\XBOOLE-0K3 B c=TARSKIR1 A & A c=TARSKIR1 A \\/XBOOLE-0K2 B"
      using xboole_1_th_7 xboole_1_th_17 sorry
    then have "A /\\XBOOLE-0K3 B c=TARSKIR1 A \\/XBOOLE-0K2 B"
       sorry
    then have A25: "A /\\XBOOLE-0K3 B c=TARSKIR1 PA"
      using A24 sorry
    have "A /\\XBOOLE-0K3 B =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume A26: "A /\\XBOOLE-0K3 B =XBOOLE-0R4 {}XBOOLE-0K1"
      have " ex y be objectHIDDENM1 st y inHIDDENR3 X0 & y inHIDDENR3 X1"
        using A3 xboole_0_th_3 sorry
      thus " False "
        using A8 A26 xboole_0_def_4 zfmisc_1_th_2 sorry
    qed
    thus "X0 /\\SUBSET-1K9\<^bsub>(Y)\<^esub> X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
      using A23 A25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_10:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X be SubsetSUBSET-1M2-of Y holds X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & X <>HIDDENR2 Y implies X `SUBSET-1K3\<^bsub>(Y)\<^esub> is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for X be SubsetSUBSET-1M2-of Y holds X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & X <>HIDDENR2 Y implies X `SUBSET-1K3\<^bsub>(Y)\<^esub> is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of Y"
    assume A1: "X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
      and A2: "X <>HIDDENR2 Y"
    obtain B where
      [ty]:"B be setHIDDENM2" and 
      A3: "B c=TARSKIR1 PA"and "B <>HIDDENR2 {}XBOOLE-0K1"and A4: "X =XBOOLE-0R4 unionTARSKIK3 B"
      using A1 sorry
    have A5: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 Y"
      using eqrel_1_def_4 sorry
    then have A6: "X `SUBSET-1K3\<^bsub>(Y)\<^esub> =XBOOLE-0R4 unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA \\SUBSET-1K7\<^bsub>(Y)\<^esub> unionTARSKIK3 B"
      using A4 subset_1_def_4 sorry
    have 
      [ty]:"B be SubsetSUBSET-1M2-of PA"
      using A3 sorry
    have Cut493: "PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume "PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "PA c=TARSKIR1 B"
        using xboole_1_th_37 sorry
      thus " False "
        using A2 A4 A5 xboole_0_def_10 sorry
    qed
    have "(PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B c=TARSKIR1 PA &  not PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B <>HIDDENR2 {}XBOOLE-0K1) & X `SUBSET-1K3\<^bsub>(Y)\<^esub> =XBOOLE-0R4 unionTARSKIK3 (PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B)"
    proof-
      show "(PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B c=TARSKIR1 PA &  not PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B <>HIDDENR2 {}XBOOLE-0K1) & X `SUBSET-1K3\<^bsub>(Y)\<^esub> =XBOOLE-0R4 unionTARSKIK3 (PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B)"
        using A6 eqrel_1_th_43 xboole_1_th_36 Cut493 sorry
    qed
    thus "X `SUBSET-1K3\<^bsub>(Y)\<^esub> is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
      using bexI[of _ "PA \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> B"] partit1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_11:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for y be ElementSUBSET-1M1-of Y holds  ex X be SubsetSUBSET-1M2-of Y st y inTARSKIR2 X & X is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for y be ElementSUBSET-1M1-of Y holds  ex tVar3 be SubsetSUBSET-1M2-of Y st y inTARSKIR2 tVar3 & tVar3 is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
    have A1: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 Y"
      using eqrel_1_def_4 sorry
    have A2: " for A be setHIDDENM2 holds A inTARSKIR2 PA implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be setHIDDENM2 holds B inTARSKIR2 PA implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
      using eqrel_1_def_4 sorry
    have A3: "Y is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & Y is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
      using partit1_th_7 sorry
    let ?P = "\<lambda>Lamb1. (y inTARSKIR2 Lamb1 & Lamb1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & Lamb1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
    obtain XX where 
      [ty]:"XX be Subset-FamilySETFAM-1M1-of Y" and XXDef:"XX = {X where X be SubsetSUBSET-1M2-of Y : ?P(X) }"
      using domain_1_sch_7 sorry
    have 
      [ty]:"XX be Subset-FamilySETFAM-1M1-of Y"
       sorry
    have "Y c=TARSKIR1 Y"
       sorry
    then have A4: "Y inTARSKIR2 XX"
      using A3 sorry
    have " for X1 be setHIDDENM2 holds X1 inTARSKIR2 XX implies y inTARSKIR2 X1"
    proof(rule ballI,rule impI)
      fix X1 assume [ty]: "X1 be setHIDDENM2"
      assume "X1 inTARSKIR2 XX"
      then have " ex X be SubsetSUBSET-1M2-of Y st ((X =XBOOLE-0R4 X1 & y inTARSKIR2 X) & X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
         sorry
      thus "y inTARSKIR2 X1"
         sorry
    qed "sorry"
    then have A5: "y inTARSKIR2 meetSETFAM-1K6\<^bsub>(Y)\<^esub> XX"
      using A4 setfam_1_def_1 sorry
    then have A6: "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX <>HIDDENR2 {}XBOOLE-0K1"
      using setfam_1_def_9 sorry
    show " ex tVar3 be SubsetSUBSET-1M2-of Y st y inTARSKIR2 tVar3 & tVar3 is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
    proof(rule bexI[of _ "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"])
      have " for X1 be setHIDDENM2 holds X1 inTARSKIR2 XX implies X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
      proof(rule ballI,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        assume "X1 inTARSKIR2 XX"
        then have " ex X be SubsetSUBSET-1M2-of Y st ((X =XBOOLE-0R4 X1 & y inTARSKIR2 X) & X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
           sorry
        thus "X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
           sorry
      qed "sorry"
      then have A7: "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
        using A6 partit1_th_8 sorry
      have " for X1 be setHIDDENM2 holds X1 inTARSKIR2 XX implies X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
      proof(rule ballI,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        assume "X1 inTARSKIR2 XX"
        then have " ex X be SubsetSUBSET-1M2-of Y st ((X =XBOOLE-0R4 X1 & y inTARSKIR2 X) & X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & X is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
           sorry
        thus "X1 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
           sorry
      qed "sorry"
      then have A8: "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
        using A6 partit1_th_8 sorry
      have " for d be setHIDDENM2 holds (d c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX & d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB implies d =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
      proof-
        have " for d be setHIDDENM2 holds d c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX & (d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB) implies d =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
        proof(rule ballI,rule impMI ,rule impMI ,rule impI)
          fix d assume [ty]: "d be setHIDDENM2"
          assume A9: "d c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
            and A10: "d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
            and A11: "d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
          obtain Ad where
            [ty]:"Ad be setHIDDENM2" and 
            A12: "Ad c=TARSKIR1 PA"and A13: "Ad <>HIDDENR2 {}XBOOLE-0K1"and A14: "d =XBOOLE-0R4 unionTARSKIK3 Ad"
            using A10 sorry
          have A15: "d c=TARSKIR1 Y"
            using A1 A12 A14 zfmisc_1_th_77 sorry
          show "d =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
          proof-
            have cases: "y inTARSKIR2 d or  not y inTARSKIR2 d"
               sorry
            have case1: "y inTARSKIR2 d implies d =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
            proof(rule impI)
              assume "y inTARSKIR2 d"
              then have A16: "d inTARSKIR2 XX"
                using A10 A11 A15 sorry
              have "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX c=TARSKIR1 d"
              proof-
                have " for X1 be objectHIDDENM1 holds X1 inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX implies X1 inHIDDENR3 d"
                proof(rule ballI,rule impI)
                  fix X1 assume [ty]: "X1 be objectHIDDENM1"
                  assume "X1 inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
                  then have "X1 inHIDDENR3 meetSETFAM-1K6\<^bsub>(Y)\<^esub> XX"
                    using A4 setfam_1_def_9 sorry
                  thus "X1 inHIDDENR3 d"
                    using A16 setfam_1_def_1 sorry
                qed "sorry"
                thus "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX c=TARSKIR1 d"
                  using tarski_def_3 sorry
              qed
              thus "d =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
                using A9 xboole_0_def_10 sorry
            qed
            have case2: " not y inTARSKIR2 d implies d =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
            proof(rule impI)
              assume A17: " not y inTARSKIR2 d"
              have 
                [ty]:"d be SubsetSUBSET-1M2-of Y"
                using A1 A12 A14 zfmisc_1_th_77 sorry
              have "d `SUBSET-1K3\<^bsub>(Y)\<^esub> =XBOOLE-0R4 Y \\SUBSET-1K6 d"
                using subset_1_def_4 sorry
              then have A18: "y inTARSKIR2 d `SUBSET-1K3\<^bsub>(Y)\<^esub>"
                using A17 xboole_0_def_5 sorry
              have "d missesXBOOLE-0R1 d `SUBSET-1K3\<^bsub>(Y)\<^esub>"
                using subset_1_th_24 sorry
              then have A19: "d /\\SUBSET-1K9\<^bsub>(Y)\<^esub> d `SUBSET-1K3\<^bsub>(Y)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
                using xboole_0_def_7 sorry
              have "d <>HIDDENR2 Y"
                using A17 sorry
              then have "d `SUBSET-1K3\<^bsub>(Y)\<^esub> is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & d `SUBSET-1K3\<^bsub>(Y)\<^esub> is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
                using A10 A11 partit1_th_10 sorry
              then have A20: "d `SUBSET-1K3\<^bsub>(Y)\<^esub> inTARSKIR2 XX"
                using A18 sorry
              have "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX c=TARSKIR1 d `SUBSET-1K3\<^bsub>(Y)\<^esub>"
              proof-
                have " for X1 be objectHIDDENM1 holds X1 inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX implies X1 inHIDDENR3 d `SUBSET-1K3\<^bsub>(Y)\<^esub>"
                proof(rule ballI,rule impI)
                  fix X1 assume [ty]: "X1 be objectHIDDENM1"
                  assume "X1 inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
                  then have "X1 inHIDDENR3 meetSETFAM-1K6\<^bsub>(Y)\<^esub> XX"
                    using A4 setfam_1_def_9 sorry
                  thus "X1 inHIDDENR3 d `SUBSET-1K3\<^bsub>(Y)\<^esub>"
                    using A20 setfam_1_def_1 sorry
                qed "sorry"
                thus "IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX c=TARSKIR1 d `SUBSET-1K3\<^bsub>(Y)\<^esub>"
                  using tarski_def_3 sorry
              qed
              then have A21: "d /\\SUBSET-1K9\<^bsub>(Y)\<^esub> (IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX) =XBOOLE-0R4 {}XBOOLE-0K1"
                using A19 xboole_1_th_3 xboole_1_th_26 sorry
              have "d /\\SUBSET-1K9\<^bsub>(Y)\<^esub> d c=TARSKIR1 d /\\SUBSET-1K9\<^bsub>(Y)\<^esub> (IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX)"
                using A9 xboole_1_th_26 sorry
              then have A22: "unionTARSKIK3 Ad =XBOOLE-0R4 {}XBOOLE-0K1"
                using A14 A21 sorry
              obtain ad where
                [ty]:"ad be objectHIDDENM1" and 
                A23: "ad inHIDDENR3 Ad"
                using A13 xboole_0_def_1 sorry
              have A24: "ad <>HIDDENR2 {}XBOOLE-0K1"
                using A2 A12 A23 sorry
              have 
                [ty]:"ad be setHIDDENM2"
                using tarski_th_1 sorry
              have "ad c=TARSKIR1 {}XBOOLE-0K1"
                using A22 A23 zfmisc_1_th_74 sorry
              thus "d =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX"
                using A24 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "y inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX & IntersectSETFAM-1K8\<^bsub>(Y)\<^esub> XX is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
        using A4 A5 A7 A8 setfam_1_def_9 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_12:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for P be a-partitionEQREL-1M3-of Y holds  for y be ElementSUBSET-1M1-of Y holds  ex A be SubsetSUBSET-1M2-of Y st y inTARSKIR2 A & A inTARSKIR2 P"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for P be a-partitionEQREL-1M3-of Y holds  for y be ElementSUBSET-1M1-of Y holds  ex tVar4 be SubsetSUBSET-1M2-of Y st y inTARSKIR2 tVar4 & tVar4 inTARSKIR2 P"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix P assume [ty]: "P be a-partitionEQREL-1M3-of Y"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
    obtain R where
      [ty]:"R be Equivalence-RelationEQREL-1M2-of Y" and 
      A1: "P =XBOOLE-0R4 ClassEQREL-1K9\<^bsub>(Y)\<^esub> R"
      using eqrel_1_th_34 sorry
    show " ex tVar4 be SubsetSUBSET-1M2-of Y st y inTARSKIR2 tVar4 & tVar4 inTARSKIR2 P"
    proof(rule bexI[of _ "ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(R,y)"],rule conjMI)
      show "y inTARSKIR2 ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(R,y)"
        using eqrel_1_th_20 sorry
      show "ClassEQREL-1K7\<^bsub>(Y,Y)\<^esub>(R,y) inTARSKIR2 P"
        using A1 eqrel_1_def_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partit1_def_3 ("PARTITIONSPARTIT1K1  _ " [164]164 ) where
  mlet "Y be setHIDDENM2"
"func PARTITIONSPARTIT1K1 Y \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be setHIDDENM2 holds x inTARSKIR2 it iff x be a-partitionEQREL-1M3-of Y"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be setHIDDENM2 holds x inTARSKIR2 it iff x be a-partitionEQREL-1M3-of Y"
    proof-
      have " ex tVar5 be setHIDDENM2 st  for x be setHIDDENM2 holds (x inTARSKIR2 tVar5 implies x be a-partitionEQREL-1M3-of Y) & (x be a-partitionEQREL-1M3-of Y implies x inTARSKIR2 tVar5)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 be a-partitionEQREL-1M3-of Y"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be setHIDDENM2 holds x inTARSKIR2 X iff x inTARSKIR2 boolSETFAM-1K9 (boolSETFAM-1K9 Y) & ?P(x)"
          using xfamily_sch_1 sorry
        show " ex tVar5 be setHIDDENM2 st  for x be setHIDDENM2 holds (x inTARSKIR2 tVar5 implies x be a-partitionEQREL-1M3-of Y) & (x be a-partitionEQREL-1M3-of Y implies x inTARSKIR2 tVar5)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          show "x inTARSKIR2 X implies x be a-partitionEQREL-1M3-of Y"
            using A1 sorry
          assume "x be a-partitionEQREL-1M3-of Y"
          thus "x inTARSKIR2 X"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 it1 iff x be a-partitionEQREL-1M3-of Y) & ( for x be setHIDDENM2 holds x inTARSKIR2 it2 iff x be a-partitionEQREL-1M3-of Y) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be setHIDDENM2 holds  for A2 be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 A1 iff x be a-partitionEQREL-1M3-of Y) & ( for x be setHIDDENM2 holds x inTARSKIR2 A2 iff x be a-partitionEQREL-1M3-of Y) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be setHIDDENM2"
        fix A2 assume [ty]: "A2 be setHIDDENM2"
        assume A2: " for x be setHIDDENM2 holds x inTARSKIR2 A1 iff x be a-partitionEQREL-1M3-of Y"
          and A3: " for x be setHIDDENM2 holds x inTARSKIR2 A2 iff x be a-partitionEQREL-1M3-of Y"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 A1 iff y inHIDDENR3 A2"
        proof(rule ballI)
          fix y assume [ty]: "y be objectHIDDENM1"
          have "y inHIDDENR3 A1 iff y be a-partitionEQREL-1M3-of Y"
            using A2 sorry
          thus "y inHIDDENR3 A1 iff y inHIDDENR3 A2"
            using A3 sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem partit1_cl_1:
  mlet "Y be setHIDDENM2"
"cluster PARTITIONSPARTIT1K1 Y as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "PARTITIONSPARTIT1K1 Y be  non emptyXBOOLE-0V1"
  proof-
    have " not PARTITIONSPARTIT1K1 Y be emptyXBOOLE-0V1"
    proof-
      show " not PARTITIONSPARTIT1K1 Y be emptyXBOOLE-0V1"
      proof-
        have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies  not PARTITIONSPARTIT1K1 Y be emptyXBOOLE-0V1"
        proof(rule impI)
          assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
          thus " not PARTITIONSPARTIT1K1 Y be emptyXBOOLE-0V1"
            using partit1_def_3 eqrel_1_th_45 sorry
        qed
        have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies  not PARTITIONSPARTIT1K1 Y be emptyXBOOLE-0V1"
        proof(rule impI)
          assume "Y <>HIDDENR2 {}XBOOLE-0K1"
          then have 
            [ty]:"Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
             sorry
          have A1: "{TARSKIK1 Y} be Subset-FamilySETFAM-1M1-of Y & unionTARSKIK3 {TARSKIK1 Y} =XBOOLE-0R4 Y"
            using zfmisc_1_th_25 zfmisc_1_th_68 sorry
          have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 {TARSKIK1 Y} implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 {TARSKIK1 Y} implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
          proof-
            have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 {TARSKIK1 Y} implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 {TARSKIK1 Y} implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B))"
            proof(rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
              fix A assume [ty]: "A be SubsetSUBSET-1M2-of Y"
              assume A2: "A inTARSKIR2 {TARSKIK1 Y}"
              then have A3: "A =XBOOLE-0R4 Y"
                using tarski_def_1 sorry
              show "A <>HIDDENR2 {}XBOOLE-0K1"
                using A2 tarski_def_1 sorry
              fix B assume [ty]: "B be SubsetSUBSET-1M2-of Y"
              assume "B inTARSKIR2 {TARSKIK1 Y}"
              thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
                using A3 tarski_def_1 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then have "{TARSKIK1 Y} be a-partitionEQREL-1M3-of Y"
            using A1 eqrel_1_def_4 sorry
          thus " not PARTITIONSPARTIT1K1 Y be emptyXBOOLE-0V1"
            using partit1_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
mdef partit1_def_4 (" _ '''/'\\''PARTIT1K2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y", "PB be a-partitionEQREL-1M3-of Y"
"func PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB \<rightarrow> a-partitionEQREL-1M3-of Y equals
  INTERSECTIONSETFAM-1K3(PA,PB) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  (*coherence*)
    show "INTERSECTIONSETFAM-1K3(PA,PB) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } be a-partitionEQREL-1M3-of Y"
    proof-
      have "{}XBOOLE-0K1 c=TARSKIR1 Y"
         sorry
      then obtain e where 
        [ty]:"e be Subset-FamilySETFAM-1M1-of Y" and eDef:"e = {TARSKIK1 {}XBOOLE-0K1 }"
        using zfmisc_1_th_31 sorry
      let ?a = "INTERSECTIONSETFAM-1K3(PA,PB)"
      have " for z be objectHIDDENM1 holds z inHIDDENR3 ?a implies z inHIDDENR3 boolSETFAM-1K9 Y"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 INTERSECTIONSETFAM-1K3(PA,PB) implies z inHIDDENR3 boolSETFAM-1K9 Y"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          obtain zz where 
            [ty]:"zz be setHIDDENM2" and zzDef:"zz = z"
            using tarski_th_1 sorry
          assume "z inHIDDENR3 ?a"
          then have " ex M be setHIDDENM2 st  ex N be setHIDDENM2 st (M inTARSKIR2 PA & N inTARSKIR2 PB) & z =HIDDENR1 M /\\XBOOLE-0K3 N"
            using setfam_1_def_5 sorry
          then have "zz c=TARSKIR1 Y"
            using xboole_1_th_108 sorry
          thus "z inHIDDENR3 boolSETFAM-1K9 Y"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then obtain a where 
        [ty]:"a be Subset-FamilySETFAM-1M1-of Y" and aDef:"a = INTERSECTIONSETFAM-1K3(PA,PB)"
        using tarski_def_3 sorry
      obtain ia where 
        [ty]:"ia be Subset-FamilySETFAM-1M1-of Y" and iaDef:"ia = a \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 Y)\<^esub> e"
         sorry
      have A1: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 Y & unionSETFAM-1K5\<^bsub>(Y)\<^esub> PB =XBOOLE-0R4 Y"
        using eqrel_1_def_4 sorry
      have A2: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> ia =HIDDENR1 unionTARSKIK3 (INTERSECTIONSETFAM-1K3(PA,PB))"
        using partit1_th_2 sorry
      also have "... = unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA /\\SUBSET-1K9\<^bsub>(Y)\<^esub> unionSETFAM-1K5\<^bsub>(Y)\<^esub> PB"
        using setfam_1_th_28 sorry
      also have "... = Y"
        using A1 sorry
      finally have "unionSETFAM-1K5\<^bsub>(Y)\<^esub> ia =HIDDENR1 Y"
         sorry
      have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 ia implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 ia implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
      proof-
        have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 ia implies  not A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds  not ((B inTARSKIR2 ia &  not A =XBOOLE-0R4 B) &  not A missesXBOOLE-0R1 B))"
        proof(rule ballI,rule impI)
          fix A assume [ty]: "A be SubsetSUBSET-1M2-of Y"
          assume A3: "A inTARSKIR2 ia"
          then have A4: " not A inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
            using xboole_0_def_5 sorry
          have A5: "A inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PB)"
            using A3 xboole_0_def_5 sorry
          have " for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 ia implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B"
          proof-
            have " for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 ia implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
            proof(rule ballI,rule impI)
              have A6: " for m be setHIDDENM2 holds  for n be setHIDDENM2 holds  for o be setHIDDENM2 holds  for p be setHIDDENM2 holds (m /\\XBOOLE-0K3 n)/\\XBOOLE-0K3 (o /\\XBOOLE-0K3 p) =XBOOLE-0R4 m /\\XBOOLE-0K3 ((n /\\XBOOLE-0K3 o)/\\XBOOLE-0K3 p)"
              proof(rule ballI,rule ballI,rule ballI,rule ballI)
                fix m assume [ty]: "m be setHIDDENM2"
                fix n assume [ty]: "n be setHIDDENM2"
                fix o assume [ty]: "o be setHIDDENM2"
                fix p assume [ty]: "p be setHIDDENM2"
                have "(m /\\XBOOLE-0K3 n)/\\XBOOLE-0K3 (o /\\XBOOLE-0K3 p) =HIDDENR1 m /\\XBOOLE-0K3 (n /\\XBOOLE-0K3 (o /\\XBOOLE-0K3 p))"
                  using xboole_1_th_16 sorry
                also have "... = m /\\XBOOLE-0K3 ((n /\\XBOOLE-0K3 o)/\\XBOOLE-0K3 p)"
                  using xboole_1_th_16 sorry
                finally have "(m /\\XBOOLE-0K3 n)/\\XBOOLE-0K3 (o /\\XBOOLE-0K3 p) =HIDDENR1 m /\\XBOOLE-0K3 ((n /\\XBOOLE-0K3 o)/\\XBOOLE-0K3 p)"
                   sorry
                thus "(m /\\XBOOLE-0K3 n)/\\XBOOLE-0K3 (o /\\XBOOLE-0K3 p) =XBOOLE-0R4 m /\\XBOOLE-0K3 ((n /\\XBOOLE-0K3 o)/\\XBOOLE-0K3 p)"
                   sorry
              qed "sorry"
              fix B assume [ty]: "B be SubsetSUBSET-1M2-of Y"
              assume "B inTARSKIR2 ia"
              then have "B inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PB)"
                using xboole_0_def_5 sorry
              then obtain M N where
                [ty]:"M be setHIDDENM2" "N be setHIDDENM2" and 
                A7: "M inTARSKIR2 PA & N inTARSKIR2 PB"and A8: "B =XBOOLE-0R4 M /\\XBOOLE-0K3 N"
                using setfam_1_def_5 sorry
              obtain S T where
                [ty]:"S be setHIDDENM2" "T be setHIDDENM2" and 
                A9: "S inTARSKIR2 PA & T inTARSKIR2 PB"and A10: "A =XBOOLE-0R4 S /\\XBOOLE-0K3 T"
                using A5 setfam_1_def_5 sorry
              have "M /\\XBOOLE-0K3 N =XBOOLE-0R4 S /\\XBOOLE-0K3 T or ( not M =XBOOLE-0R4 S or  not N =XBOOLE-0R4 T)"
                 sorry
              then have "M /\\XBOOLE-0K3 N =XBOOLE-0R4 S /\\XBOOLE-0K3 T or (M missesXBOOLE-0R1 S or N missesXBOOLE-0R1 T)"
                using A7 A9 eqrel_1_def_4 sorry
              then have A11: "M /\\XBOOLE-0K3 N =XBOOLE-0R4 S /\\XBOOLE-0K3 T or (M /\\XBOOLE-0K3 S =XBOOLE-0R4 {}XBOOLE-0K1 or N /\\XBOOLE-0K3 T =XBOOLE-0R4 {}XBOOLE-0K1)"
                using xboole_0_def_7 sorry
              have "(M /\\XBOOLE-0K3 S)/\\XBOOLE-0K3 (N /\\XBOOLE-0K3 T) =HIDDENR1 M /\\XBOOLE-0K3 ((S /\\XBOOLE-0K3 N)/\\XBOOLE-0K3 T)"
                using A6 sorry
              also have "... = (M /\\XBOOLE-0K3 N)/\\XBOOLE-0K3 (S /\\XBOOLE-0K3 T)"
                using A6 sorry
              finally have "(M /\\XBOOLE-0K3 S)/\\XBOOLE-0K3 (N /\\XBOOLE-0K3 T) =HIDDENR1 (M /\\XBOOLE-0K3 N)/\\XBOOLE-0K3 (S /\\XBOOLE-0K3 T)"
                 sorry
              thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
                using A8 A10 A11 xboole_0_def_7 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " not A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds  not ((B inTARSKIR2 ia &  not A =XBOOLE-0R4 B) &  not A missesXBOOLE-0R1 B))"
            using A4 tarski_def_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "INTERSECTIONSETFAM-1K3(PA,PB) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } be a-partitionEQREL-1M3-of Y"
        using A2 eqrel_1_def_4 sorry
    qed
qed "sorry"

mtheorem PARTIT1K2_commutativity:
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB =HIDDENR1 PB '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA"
proof-
  have " for it be a-partitionEQREL-1M3-of Y holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds it =HIDDENR1 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB implies it =HIDDENR1 PB '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA"
  proof-
    have " for it be a-partitionEQREL-1M3-of Y holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds it =HIDDENR1 INTERSECTIONSETFAM-1K3(PA,PB) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } implies it =HIDDENR1 INTERSECTIONSETFAM-1K3(PB,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
       sorry
    thus " ?thesis "
      using partit1_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_13:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    have " for u be setHIDDENM2 holds u inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } implies ( ex v be setHIDDENM2 st v inTARSKIR2 PA & u c=TARSKIR1 v)"
    proof-
      have " for u be setHIDDENM2 holds u inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } implies ( ex tVar6 be setHIDDENM2 st tVar6 inTARSKIR2 PA & u c=TARSKIR1 tVar6)"
      proof(rule ballI,rule impI)
        fix u assume [ty]: "u be setHIDDENM2"
        assume "u inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
        then obtain v u2 where
          [ty]:"v be setHIDDENM2" "u2 be setHIDDENM2" and 
          A1: "v inTARSKIR2 PA"and "u2 inTARSKIR2 PA"and A2: "u =XBOOLE-0R4 v /\\XBOOLE-0K3 u2"
          using setfam_1_def_5 sorry
        show " ex tVar6 be setHIDDENM2 st tVar6 inTARSKIR2 PA & u c=TARSKIR1 tVar6"
        proof(rule bexI[of _ "v"])
          show "v inTARSKIR2 PA & u c=TARSKIR1 v"
            using A1 A2 xboole_1_th_17 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A3: "INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } '<'PARTIT1R1 PA"
      using setfam_1_def_2 sorry
    have " for u be setHIDDENM2 holds u inTARSKIR2 PA implies ( ex v be setHIDDENM2 st v inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } & u c=TARSKIR1 v)"
    proof-
      have " for u be setHIDDENM2 holds u inTARSKIR2 PA implies  not ( for v be setHIDDENM2 holds  not (v inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } & u c=TARSKIR1 v))"
      proof(rule ballI,rule impI)
        fix u assume [ty]: "u be setHIDDENM2"
        assume A4: "u inTARSKIR2 PA"
        then have A5: "u <>HIDDENR2 {}XBOOLE-0K1"
          using eqrel_1_def_4 sorry
        let ?v = "u /\\XBOOLE-0K3 u"
        have A6: " not ?v inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          using A5 tarski_def_1 sorry
        have "?v inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PA)"
          using A4 setfam_1_def_5 sorry
        then have "?v inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
          using A6 xboole_0_def_5 sorry
        thus " not ( for v be setHIDDENM2 holds  not (v inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 } & u c=TARSKIR1 v))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "PA '<'PARTIT1R1 INTERSECTIONSETFAM-1K3(PA,PA) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
      using setfam_1_def_2 sorry
    thus "PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
      using A3 partit1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_14:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC =XBOOLE-0R4 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PB '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC)"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC =XBOOLE-0R4 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PB '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    fix PC assume [ty]: "PC be a-partitionEQREL-1M3-of Y"
    obtain PD PE where
      [ty]:"PD be a-partitionEQREL-1M3-of Y" "PE be a-partitionEQREL-1M3-of Y" and 
      A1: "PD =XBOOLE-0R4 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"and A2: "PE =XBOOLE-0R4 PB '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC"
       sorry
    have " for u be setHIDDENM2 holds u inTARSKIR2 PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC implies ( ex v be setHIDDENM2 st v inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE & u c=TARSKIR1 v)"
    proof-
      have " for u be setHIDDENM2 holds u inTARSKIR2 PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC implies ( ex tVar7 be setHIDDENM2 st tVar7 inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE & u c=TARSKIR1 tVar7)"
      proof(rule ballI,rule impI)
        fix u assume [ty]: "u be setHIDDENM2"
        assume A3: "u inTARSKIR2 PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC"
        then obtain u1 u2 where
          [ty]:"u1 be setHIDDENM2" "u2 be setHIDDENM2" and 
          A4: "u1 inTARSKIR2 PD"and A5: "u2 inTARSKIR2 PC"and A6: "u =XBOOLE-0R4 u1 /\\XBOOLE-0K3 u2"
          using setfam_1_def_5 sorry
        obtain u3 u4 where
          [ty]:"u3 be setHIDDENM2" "u4 be setHIDDENM2" and 
          A7: "u3 inTARSKIR2 PA"and A8: "u4 inTARSKIR2 PB"and A9: "u1 =XBOOLE-0R4 u3 /\\XBOOLE-0K3 u4"
          using A1 A4 setfam_1_def_5 sorry
        obtain v v1 v2 where
          [ty]:"v be setHIDDENM2" "v1 be setHIDDENM2" "v2 be setHIDDENM2" and 
          A10: "v1 =XBOOLE-0R4 u4 /\\XBOOLE-0K3 u2"and A11: "v2 =XBOOLE-0R4 u3"and A12: "v =XBOOLE-0R4 (u3 /\\XBOOLE-0K3 u4)/\\XBOOLE-0K3 u2"
           sorry
        have A13: "v =XBOOLE-0R4 v2 /\\XBOOLE-0K3 v1"
          using A10 A11 A12 xboole_1_th_16 sorry
        have A14: "v1 inTARSKIR2 INTERSECTIONSETFAM-1K3(PB,PC)"
          using A5 A8 A10 setfam_1_def_5 sorry
        have A15: " not u inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          using A3 xboole_0_def_5 sorry
        have "u =XBOOLE-0R4 u3 /\\XBOOLE-0K3 v1"
          using A6 A9 A10 xboole_1_th_16 sorry
        then have "v1 <>HIDDENR2 {}XBOOLE-0K1"
          using A15 tarski_def_1 sorry
        then have " not v1 inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_1 sorry
        then have "v1 inTARSKIR2 INTERSECTIONSETFAM-1K3(PB,PC) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
          using A14 xboole_0_def_5 sorry
        then have A16: "v inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PE)"
          using A2 A7 A11 A13 setfam_1_def_5 sorry
        show " ex tVar7 be setHIDDENM2 st tVar7 inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE & u c=TARSKIR1 tVar7"
        proof(rule bexI[of _ "v"])
          show "v inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE & u c=TARSKIR1 v"
            using A6 A9 A12 A15 A16 xboole_0_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A17: "PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC '<'PARTIT1R1 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE"
      using setfam_1_def_2 sorry
    have " for u be setHIDDENM2 holds u inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE implies ( ex v be setHIDDENM2 st v inTARSKIR2 PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC & u c=TARSKIR1 v)"
    proof-
      have " for u be setHIDDENM2 holds u inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE implies ( ex tVar8 be setHIDDENM2 st tVar8 inTARSKIR2 PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC & u c=TARSKIR1 tVar8)"
      proof(rule ballI,rule impI)
        fix u assume [ty]: "u be setHIDDENM2"
        assume A18: "u inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE"
        then obtain u1 u2 where
          [ty]:"u1 be setHIDDENM2" "u2 be setHIDDENM2" and 
          A19: "u1 inTARSKIR2 PA"and A20: "u2 inTARSKIR2 PE"and A21: "u =XBOOLE-0R4 u1 /\\XBOOLE-0K3 u2"
          using setfam_1_def_5 sorry
        obtain u3 u4 where
          [ty]:"u3 be setHIDDENM2" "u4 be setHIDDENM2" and 
          A22: "u3 inTARSKIR2 PB"and A23: "u4 inTARSKIR2 PC"and A24: "u2 =XBOOLE-0R4 u3 /\\XBOOLE-0K3 u4"
          using A2 A20 setfam_1_def_5 sorry
        have A25: "u =XBOOLE-0R4 (u1 /\\XBOOLE-0K3 u3)/\\XBOOLE-0K3 u4"
          using A21 A24 xboole_1_th_16 sorry
        obtain v v1 v2 where
          [ty]:"v be setHIDDENM2" "v1 be setHIDDENM2" "v2 be setHIDDENM2" and 
          A26: "v1 =XBOOLE-0R4 u1 /\\XBOOLE-0K3 u3"and "v2 =XBOOLE-0R4 u4"and A27: "v =XBOOLE-0R4 (u1 /\\XBOOLE-0K3 u3)/\\XBOOLE-0K3 u4"
           sorry
        have A28: "v1 inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PB)"
          using A19 A22 A26 setfam_1_def_5 sorry
        have A29: " not u inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          using A18 xboole_0_def_5 sorry
        then have "v1 <>HIDDENR2 {}XBOOLE-0K1"
          using A25 A26 tarski_def_1 sorry
        then have " not v1 inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_1 sorry
        then have "v1 inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PB) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
          using A28 xboole_0_def_5 sorry
        then have A30: "v inTARSKIR2 INTERSECTIONSETFAM-1K3(PD,PC)"
          using A1 A23 A26 A27 setfam_1_def_5 sorry
        show " ex tVar8 be setHIDDENM2 st tVar8 inTARSKIR2 PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC & u c=TARSKIR1 tVar8"
        proof(rule bexI[of _ "v"])
          show "v inTARSKIR2 PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC & u c=TARSKIR1 v"
            using A25 A27 A29 A30 xboole_0_def_5 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PE '<'PARTIT1R1 PD '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC"
      using setfam_1_def_2 sorry
    thus "(PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC =XBOOLE-0R4 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PB '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PC)"
      using A1 A2 A17 partit1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_15:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    have " for u be setHIDDENM2 holds u inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB implies ( ex v be setHIDDENM2 st v inTARSKIR2 PA & u c=TARSKIR1 v)"
    proof-
      have " for u be setHIDDENM2 holds u inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB implies ( ex tVar9 be setHIDDENM2 st tVar9 inTARSKIR2 PA & u c=TARSKIR1 tVar9)"
      proof(rule ballI,rule impI)
        fix u assume [ty]: "u be setHIDDENM2"
        assume "u inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"
        then obtain u1 u2 where
          [ty]:"u1 be setHIDDENM2" "u2 be setHIDDENM2" and 
          A1: "u1 inTARSKIR2 PA"and "u2 inTARSKIR2 PB"and A2: "u =XBOOLE-0R4 u1 /\\XBOOLE-0K3 u2"
          using setfam_1_def_5 sorry
        show " ex tVar9 be setHIDDENM2 st tVar9 inTARSKIR2 PA & u c=TARSKIR1 tVar9"
        proof(rule bexI[of _ "u1"])
          show "u1 inTARSKIR2 PA & u c=TARSKIR1 u1"
            using A1 A2 xboole_1_th_17 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "PA '>'PARTIT1R2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partit1_def_5 (" _ '''\\'/''PARTIT1K3\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y", "PB be a-partitionEQREL-1M3-of Y"
"func PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB \<rightarrow> a-partitionEQREL-1M3-of Y means
  \<lambda>it.  for d be setHIDDENM2 holds d inTARSKIR2 it iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
proof-
  (*existence*)
    show " ex it be a-partitionEQREL-1M3-of Y st  for d be setHIDDENM2 holds d inTARSKIR2 it iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
    proof-
      have " ex tVar10 be a-partitionEQREL-1M3-of Y st (tVar10 be ElementSUBSET-1M1-of boolZFMISC-1K1 (boolZFMISC-1K1 Y) & tVar10 be a-partitionEQREL-1M3-of Y) & ( for d be setHIDDENM2 holds  not (d inTARSKIR2 tVar10 &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) &  not d inTARSKIR2 tVar10))"
      proof-
        have A1: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 Y"
          using eqrel_1_def_4 sorry
        have A2: " for A be setHIDDENM2 holds A inTARSKIR2 PA implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be setHIDDENM2 holds B inTARSKIR2 PA implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
          using eqrel_1_def_4 sorry
        let ?P = "\<lambda>Lamb1. Lamb1 is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A3: " for d be setHIDDENM2 holds d inTARSKIR2 X iff d inTARSKIR2 boolSETFAM-1K9 Y & ?P(d)"
          using xfamily_sch_1 sorry
        have A4: " for d be setHIDDENM2 holds d inTARSKIR2 X iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
        proof-
          have " for d be setHIDDENM2 holds  not (d inTARSKIR2 X &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) &  not d inTARSKIR2 X)"
          proof(rule ballI)
            fix d assume [ty]: "d be setHIDDENM2"
            have " for d be setHIDDENM2 holds d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) implies d inTARSKIR2 boolSETFAM-1K9 Y"
            proof(rule ballI,rule impI)
              fix d assume [ty]: "d be setHIDDENM2"
              assume "d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
              then have "d is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
                 sorry
              then have " ex A be setHIDDENM2 st (A c=TARSKIR1 PA & A <>HIDDENR2 {}XBOOLE-0K1) & d =XBOOLE-0R4 unionTARSKIK3 A"
                 sorry
              then have "d c=TARSKIR1 unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA"
                using zfmisc_1_th_77 sorry
              thus "d inTARSKIR2 boolSETFAM-1K9 Y"
                using A1 sorry
            qed "sorry"
            then have "d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) implies d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) & d inTARSKIR2 boolSETFAM-1K9 Y"
               sorry
            thus " not (d inTARSKIR2 X &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) &  not d inTARSKIR2 X)"
              using A3 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " ex tVar10 be a-partitionEQREL-1M3-of Y st (tVar10 be ElementSUBSET-1M1-of boolZFMISC-1K1 (boolZFMISC-1K1 Y) & tVar10 be a-partitionEQREL-1M3-of Y) & ( for d be setHIDDENM2 holds  not (d inTARSKIR2 tVar10 &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) &  not d inTARSKIR2 tVar10))"
        proof(rule bexI[of _ "X"])
          have A5: "Y c=TARSKIR1 unionTARSKIK3 X"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 unionTARSKIK3 X"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 Y"
              then obtain a where
                [ty]:"a be SubsetSUBSET-1M2-of Y" and 
                A6: "y inHIDDENR3 a"and A7: "a is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
                using partit1_th_11 sorry
              have "a inTARSKIR2 X"
                using A4 A7 sorry
              thus "y inHIDDENR3 unionTARSKIK3 X"
                using A6 tarski_def_4 sorry
            qed "sorry"
            thus "Y c=TARSKIR1 unionTARSKIK3 X"
              using tarski_def_3 sorry
          qed
          have "unionTARSKIK3 X c=TARSKIR1 Y"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 unionTARSKIK3 X implies y inHIDDENR3 Y"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 unionTARSKIK3 X"
              then obtain a where
                [ty]:"a be setHIDDENM2" and 
                A8: "y inHIDDENR3 a"and A9: "a inTARSKIR2 X"
                using tarski_def_4 sorry
              have "a is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
                using A4 A9 sorry
              then have "a is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
                 sorry
              then have " ex A be setHIDDENM2 st (A c=TARSKIR1 PA & A <>HIDDENR2 {}XBOOLE-0K1) & a =XBOOLE-0R4 unionTARSKIK3 A"
                 sorry
              then have "a c=TARSKIR1 Y"
                using A1 zfmisc_1_th_77 sorry
              thus "y inHIDDENR3 Y"
                using A8 sorry
            qed "sorry"
            thus "unionTARSKIK3 X c=TARSKIR1 Y"
              using tarski_def_3 sorry
          qed
          then have A10: "unionTARSKIK3 X =XBOOLE-0R4 Y"
            using A5 xboole_0_def_10 sorry
          have A11: " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 X implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 X implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
          proof-
            have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 X implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 X implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B))"
            proof(rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
              fix A assume [ty]: "A be SubsetSUBSET-1M2-of Y"
              assume "A inTARSKIR2 X"
              then have A12: "A is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
                using A4 sorry
              then have A13: "A is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
                 sorry
              have A14: "A is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
                using A12 sorry
              obtain Aa where
                [ty]:"Aa be setHIDDENM2" and 
                A15: "Aa c=TARSKIR1 PA"and A16: "Aa <>HIDDENR2 {}XBOOLE-0K1"and A17: "A =XBOOLE-0R4 unionTARSKIK3 Aa"
                using A13 sorry
              obtain aa where
                [ty]:"aa be objectHIDDENM1" and 
                A18: "aa inHIDDENR3 Aa"
                using A16 xboole_0_def_1 sorry
              have A19: "aa <>HIDDENR2 {}XBOOLE-0K1"
                using A2 A15 A18 sorry
              have 
                [ty]:"aa be setHIDDENM2"
                using tarski_th_1 sorry
              have "aa c=TARSKIR1 unionTARSKIK3 Aa"
                using A18 zfmisc_1_th_74 sorry
              thus "A <>HIDDENR2 {}XBOOLE-0K1"
                using A17 A19 sorry
              fix B assume [ty]: "B be SubsetSUBSET-1M2-of Y"
              assume "B inTARSKIR2 X"
              then have A20: "B is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
                using A4 sorry
              then have A21: "B is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & B is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
                 sorry
              have "A meetsXBOOLE-0R5 B implies A =XBOOLE-0R4 B"
              proof(rule impI)
                assume "A meetsXBOOLE-0R5 B"
                then have A22: "A /\\SUBSET-1K9\<^bsub>(Y)\<^esub> B is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & A /\\SUBSET-1K9\<^bsub>(Y)\<^esub> B is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
                  using A13 A14 A21 partit1_th_9 sorry
                have "A /\\SUBSET-1K9\<^bsub>(Y)\<^esub> B c=TARSKIR1 A"
                  using xboole_1_th_17 sorry
                then have A23: "A /\\SUBSET-1K9\<^bsub>(Y)\<^esub> B =XBOOLE-0R4 A"
                  using A12 A22 sorry
                have A24: "A c=TARSKIR1 B"
                  using A23 xboole_0_def_4 sorry
                have "A /\\SUBSET-1K9\<^bsub>(Y)\<^esub> B c=TARSKIR1 B"
                  using xboole_1_th_17 sorry
                then have A25: "A /\\SUBSET-1K9\<^bsub>(Y)\<^esub> B =XBOOLE-0R4 B"
                  using A20 A22 sorry
                have "B c=TARSKIR1 A"
                  using A25 xboole_0_def_4 sorry
                thus "A =XBOOLE-0R4 B"
                  using A24 xboole_0_def_10 sorry
              qed
              thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have "X c=TARSKIR1 boolSETFAM-1K9 Y"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 boolSETFAM-1K9 Y"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              obtain xx where 
                [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
                using tarski_th_1 sorry
              assume "x inHIDDENR3 X"
              then have "xx is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
                using A4 sorry
              then have "xx is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
                 sorry
              then have " ex a be setHIDDENM2 st (a c=TARSKIR1 PA & a <>HIDDENR2 {}XBOOLE-0K1) & x =HIDDENR1 unionTARSKIK3 a"
                 sorry
              then have "xx c=TARSKIR1 Y"
                using A1 zfmisc_1_th_77 sorry
              thus "x inHIDDENR3 boolSETFAM-1K9 Y"
                 sorry
            qed "sorry"
            thus "X c=TARSKIR1 boolSETFAM-1K9 Y"
              using tarski_def_3 sorry
          qed
          then have 
            [ty]:"X be Subset-FamilySETFAM-1M1-of Y"
             sorry
          have "X be a-partitionEQREL-1M3-of Y"
            using A10 A11 eqrel_1_def_4 sorry
          thus "(X be ElementSUBSET-1M1-of boolZFMISC-1K1 (boolZFMISC-1K1 Y) & X be a-partitionEQREL-1M3-of Y) & ( for d be setHIDDENM2 holds  not (d inTARSKIR2 X &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) &  not d inTARSKIR2 X))"
            using A4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be a-partitionEQREL-1M3-of Y holds  for it2 be a-partitionEQREL-1M3-of Y holds ( for d be setHIDDENM2 holds d inTARSKIR2 it1 iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) & ( for d be setHIDDENM2 holds d inTARSKIR2 it2 iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be a-partitionEQREL-1M3-of Y holds  for A2 be a-partitionEQREL-1M3-of Y holds ( for x be setHIDDENM2 holds x inTARSKIR2 A1 iff x is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) & ( for x be setHIDDENM2 holds x inTARSKIR2 A2 iff x is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be a-partitionEQREL-1M3-of Y"
        fix A2 assume [ty]: "A2 be a-partitionEQREL-1M3-of Y"
        assume A26: " for x be setHIDDENM2 holds x inTARSKIR2 A1 iff x is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
          and A27: " for x be setHIDDENM2 holds x inTARSKIR2 A2 iff x is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 A1 iff y inHIDDENR3 A2"
          using A26 A27 sorry
        thus "A1 =HIDDENR1 A2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem PARTIT1K3_commutativity:
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB =HIDDENR1 PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA"
proof-
  have " for it be a-partitionEQREL-1M3-of Y holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds it =HIDDENR1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB implies it =HIDDENR1 PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA"
  proof-
    have " for it be a-partitionEQREL-1M3-of Y holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ( for d be setHIDDENM2 holds d inTARSKIR2 it iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) implies ( for d be setHIDDENM2 holds d inTARSKIR2 it iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PB,PA))"
    proof-
      have " for IT be a-partitionEQREL-1M3-of Y holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  not (( for d be setHIDDENM2 holds  not (d inTARSKIR2 IT &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) &  not d inTARSKIR2 IT)) &  not ( for d be setHIDDENM2 holds  not (d inTARSKIR2 IT &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PB,PA)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PB,PA) &  not d inTARSKIR2 IT)))"
      proof(rule ballI,rule ballI,rule ballI)
        fix IT assume [ty]: "IT be a-partitionEQREL-1M3-of Y"
        fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
        fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
        have A28: " for a be setHIDDENM2 holds a is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) implies a is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PB,PA)"
           sorry
        have A29: " for a be setHIDDENM2 holds a is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PB,PA) implies a is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
           sorry
        have " for a be setHIDDENM2 holds ( for d be setHIDDENM2 holds d inTARSKIR2 a iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) implies ( for d be setHIDDENM2 holds d inTARSKIR2 a iff d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PB,PA))"
          using A28 A29 sorry
        thus " not (( for d be setHIDDENM2 holds  not (d inTARSKIR2 IT &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB) &  not d inTARSKIR2 IT)) &  not ( for d be setHIDDENM2 holds  not (d inTARSKIR2 IT &  not d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PB,PA)) &  not (d is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PB,PA) &  not d inTARSKIR2 IT)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using partit1_def_5 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_16:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
  proof(rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    show " for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
    proof-
      have " for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
      proof(rule ballI,rule ballI)
        fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
        fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
        have " for a be setHIDDENM2 holds a inTARSKIR2 PA implies ( ex b be setHIDDENM2 st b inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB & a c=TARSKIR1 b)"
        proof-
          have " for a be setHIDDENM2 holds a inTARSKIR2 PA implies  not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB & a c=TARSKIR1 b))"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be setHIDDENM2"
            assume A1: "a inTARSKIR2 PA"
            then have A2: "a <>HIDDENR2 {}XBOOLE-0K1"
              using eqrel_1_def_4 sorry
            let ?x = "the ElementSUBSET-1M1-of a"
            have A3: "?x inTARSKIR2 Y"
              using A1 A2 tarski_def_3 sorry
            have "unionSETFAM-1K5\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 Y"
              using eqrel_1_def_4 sorry
            then obtain b where
              [ty]:"b be setHIDDENM2" and 
              A4: "?x inTARSKIR2 b"and A5: "b inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
              using A3 tarski_def_4 sorry
            have "b is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
              using A5 partit1_def_5 sorry
            then have "b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
               sorry
            then obtain B where
              [ty]:"B be setHIDDENM2" and 
              A6: "B c=TARSKIR1 PA"and "B <>HIDDENR2 {}XBOOLE-0K1"and A7: "b =XBOOLE-0R4 unionTARSKIK3 B"
               sorry
            have "a inTARSKIR2 B"
            proof-
              obtain u where
                [ty]:"u be setHIDDENM2" and 
                A8: "?x inTARSKIR2 u"and A9: "u inTARSKIR2 B"
                using A4 A7 tarski_def_4 sorry
              have "a /\\XBOOLE-0K3 u <>HIDDENR2 {}XBOOLE-0K1"
                using A2 A8 xboole_0_def_4 sorry
              then have A10: " not a missesXBOOLE-0R1 u"
                using xboole_0_def_7 sorry
              have "u inTARSKIR2 PA"
                using A6 A9 sorry
              thus "a inTARSKIR2 B"
                using A1 A9 A10 eqrel_1_def_4 sorry
            qed
            thus " not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB & a c=TARSKIR1 b))"
              using A5 A7 zfmisc_1_th_74 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "PA '<'PARTIT1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
          using setfam_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_17:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    have A1: "PA '<'PARTIT1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA"
      using partit1_th_16 sorry
    have " for a be setHIDDENM2 holds a inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA implies ( ex b be setHIDDENM2 st b inTARSKIR2 PA & a c=TARSKIR1 b)"
    proof-
      have " for a be setHIDDENM2 holds a inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA implies  not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 PA & a c=TARSKIR1 b))"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be setHIDDENM2"
        assume A2: "a inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA"
        then have A3: "a is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PA)"
          using partit1_def_5 sorry
        then have "a is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
           sorry
        then obtain B where
          [ty]:"B be setHIDDENM2" and 
          A4: "B c=TARSKIR1 PA"and "B <>HIDDENR2 {}XBOOLE-0K1"and A5: "a =XBOOLE-0R4 unionTARSKIK3 B"
           sorry
        have A6: "a <>HIDDENR2 {}XBOOLE-0K1"
          using A2 eqrel_1_def_4 sorry
        let ?x = "the ElementSUBSET-1M1-of a"
        have "?x inTARSKIR2 a"
          using A6 sorry
        then have "?x inTARSKIR2 Y"
          using A2 sorry
        then have "?x inTARSKIR2 unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA"
          using eqrel_1_def_4 sorry
        then obtain b where
          [ty]:"b be setHIDDENM2" and 
          A7: "?x inTARSKIR2 b"and A8: "b inTARSKIR2 PA"
          using tarski_def_4 sorry
        have "b inTARSKIR2 B"
        proof-
          obtain u where
            [ty]:"u be setHIDDENM2" and 
            A9: "?x inTARSKIR2 u"and A10: "u inTARSKIR2 B"
            using A5 A6 tarski_def_4 sorry
          have "b /\\XBOOLE-0K3 u <>HIDDENR2 {}XBOOLE-0K1"
            using A7 A9 xboole_0_def_4 sorry
          then have A11: " not b missesXBOOLE-0R1 u"
            using xboole_0_def_7 sorry
          have "u inTARSKIR2 PA"
            using A4 A10 sorry
          thus "b inTARSKIR2 B"
            using A8 A10 A11 eqrel_1_def_4 sorry
        qed
        then have A12: "b c=TARSKIR1 a"
          using A5 zfmisc_1_th_74 sorry
        have "b is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
          using A8 partit1_th_6 sorry
        then have "a =XBOOLE-0R4 b"
          using A3 A12 sorry
        thus " not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 PA & a c=TARSKIR1 b))"
          using A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA '<'PARTIT1R1 PA"
      using setfam_1_def_2 sorry
    thus "PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
      using A1 partit1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_18:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for z0 be setHIDDENM2 holds  for t be setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds (((PA '<'PARTIT1R1 PC & x inTARSKIR2 PC) & z0 inTARSKIR2 PA) & t inTARSKIR2 x) & t inTARSKIR2 z0 implies z0 c=TARSKIR1 x"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for z0 be setHIDDENM2 holds  for t be setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PC & (x inTARSKIR2 PC & (z0 inTARSKIR2 PA & (t inTARSKIR2 x & t inTARSKIR2 z0))) implies z0 c=TARSKIR1 x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix z0 assume [ty]: "z0 be setHIDDENM2"
    fix t assume [ty]: "t be setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PC assume [ty]: "PC be a-partitionEQREL-1M3-of Y"
    assume A1: "PA '<'PARTIT1R1 PC"
      and A2: "x inTARSKIR2 PC"
      and A3: "z0 inTARSKIR2 PA"
      and A4: "t inTARSKIR2 x & t inTARSKIR2 z0"
    obtain b where
      [ty]:"b be setHIDDENM2" and 
      A5: "b inTARSKIR2 PC"and A6: "z0 c=TARSKIR1 b"
      using A1 A3 setfam_1_def_2 sorry
    have "x =XBOOLE-0R4 b or x missesXBOOLE-0R1 b"
      using A2 A5 eqrel_1_def_4 sorry
    thus "z0 c=TARSKIR1 x"
      using A4 A6 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_19:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for z0 be setHIDDENM2 holds  for t be setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ((x inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB & z0 inTARSKIR2 PA) & t inTARSKIR2 x) & t inTARSKIR2 z0 implies z0 c=TARSKIR1 x"
  using partit1_th_16 partit1_th_18 sorry

(*begin*)
mdef partit1_def_6 ("ERlPARTIT1K4\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "PA be a-partitionEQREL-1M3-of Y"
"func ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \<rightarrow> Equivalence-RelationEQREL-1M2-of Y means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 it iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)"
proof-
  (*existence*)
    show " ex it be Equivalence-RelationEQREL-1M2-of Y st  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 it iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)"
    proof-
      have " not ( for VarFor1 be Equivalence-RelationEQREL-1M2-of Y holds  not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not ([TARSKIK4 x1,x2 ] inHIDDENR3 VarFor1 & ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A))) &  not ( not ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) &  not [TARSKIK4 x1,x2 ] inHIDDENR3 VarFor1)))"
      proof-
        have A1: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 Y"
          using eqrel_1_def_4 sorry
        have " ex RA be Equivalence-RelationEQREL-1M2-of Y st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 RA iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x inHIDDENR3 A) & y inHIDDENR3 A)"
        proof-
          have " ex tVar12 be Equivalence-RelationEQREL-1M2-of Y st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar12 & ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x inHIDDENR3 A) & y inHIDDENR3 A))) &  not ( not ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x inHIDDENR3 A) & y inHIDDENR3 A)) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar12)"
          proof-
            let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & Lamb1 inHIDDENR3 A) & Lamb2 inHIDDENR3 A"
            have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ?P(x,x)"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ( ex tVar11 be SubsetSUBSET-1M2-of Y st (tVar11 inTARSKIR2 PA & x inHIDDENR3 tVar11) & x inHIDDENR3 tVar11)"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 Y"
                then have " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 PA"
                  using A1 tarski_def_4 sorry
                then obtain Z where
                  [ty]:"Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and 
                  A3: "x inHIDDENR3 Z"and A4: "Z inTARSKIR2 PA"
                   sorry
                obtain A where 
                  [ty]:"A be SubsetSUBSET-1M2-of Y" and ADef:"A = Z"
                  using A4 sorry
                show " ex tVar11 be SubsetSUBSET-1M2-of Y st (tVar11 inTARSKIR2 PA & x inHIDDENR3 tVar11) & x inHIDDENR3 tVar11"
                proof(rule bexI[of _ "A"])
                  show "(A inTARSKIR2 PA & x inHIDDENR3 A) & x inHIDDENR3 A"
                    using A3 A4 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?P(x,y) implies ?P(y,x)"
               sorry
            have A6: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?P(x,y) & ?P(y,z) implies ?P(x,z)"
            proof-
              have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ( ex A be SubsetSUBSET-1M2-of Y st A inTARSKIR2 PA & (x inHIDDENR3 A & y inHIDDENR3 A)) implies (( ex B be SubsetSUBSET-1M2-of Y st B inTARSKIR2 PA & (y inHIDDENR3 B & z inHIDDENR3 B)) implies ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x inHIDDENR3 A) & z inHIDDENR3 A))"
              proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                fix y assume [ty]: "y be objectHIDDENM1"
                fix z assume [ty]: "z be objectHIDDENM1"
                assume Given: " ex A be SubsetSUBSET-1M2-of Y st A inTARSKIR2 PA & (x inHIDDENR3 A & y inHIDDENR3 A)"
                then obtain A where
                  [ty]:"A be SubsetSUBSET-1M2-of Y" and 
                  A7: "A inTARSKIR2 PA"and A8: "x inHIDDENR3 A & y inHIDDENR3 A"
                   sorry
                assume Given: " ex B be SubsetSUBSET-1M2-of Y st B inTARSKIR2 PA & (y inHIDDENR3 B & z inHIDDENR3 B)"
                then obtain B where
                  [ty]:"B be SubsetSUBSET-1M2-of Y" and 
                  A9: "B inTARSKIR2 PA"and A10: "y inHIDDENR3 B & z inHIDDENR3 B"
                   sorry
                have "A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B"
                  using A7 A9 eqrel_1_def_4 sorry
                thus " ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x inHIDDENR3 A) & z inHIDDENR3 A"
                  using A7 A8 A10 xboole_0_th_3 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain RA where
              [ty]:"RA be Equivalence-RelationEQREL-1M2-of Y" and 
              A11: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 RA iff (x inHIDDENR3 Y & y inHIDDENR3 Y) & ?P(x,y)"
              using eqrel_1_sch_1 A2 A5 A6 sorry
            show " ex tVar12 be Equivalence-RelationEQREL-1M2-of Y st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar12 & ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x inHIDDENR3 A) & y inHIDDENR3 A))) &  not ( not ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x inHIDDENR3 A) & y inHIDDENR3 A)) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar12)"
            proof(rule bexI[of _ "RA"])
              show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 RA & ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x inHIDDENR3 A) & y inHIDDENR3 A))) &  not ( not ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x inHIDDENR3 A) & y inHIDDENR3 A)) &  not [TARSKIK4 x,y ] inHIDDENR3 RA)"
                using A11 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        thus " not ( for VarFor1 be Equivalence-RelationEQREL-1M2-of Y holds  not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not ([TARSKIK4 x1,x2 ] inHIDDENR3 VarFor1 & ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A))) &  not ( not ( for A be SubsetSUBSET-1M2-of Y holds  not ((A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) &  not [TARSKIK4 x1,x2 ] inHIDDENR3 VarFor1)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Equivalence-RelationEQREL-1M2-of Y holds  for it2 be Equivalence-RelationEQREL-1M2-of Y holds ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 it1 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) & ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 it2 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be Equivalence-RelationEQREL-1M2-of Y holds  for f2 be Equivalence-RelationEQREL-1M2-of Y holds ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 f1 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) & ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 f2 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be Equivalence-RelationEQREL-1M2-of Y"
        fix f2 assume [ty]: "f2 be Equivalence-RelationEQREL-1M2-of Y"
        assume A12: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 f1 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)"
          and A13: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 f2 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)"
        have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not ([TARSKIK4 x1,x2 ] inHIDDENR3 f1 &  not [TARSKIK4 x1,x2 ] inHIDDENR3 f2) &  not ([TARSKIK4 x1,x2 ] inHIDDENR3 f2 &  not [TARSKIK4 x1,x2 ] inHIDDENR3 f1)"
        proof(rule ballI,rule ballI)
          fix x1 assume [ty]: "x1 be objectHIDDENM1"
          fix x2 assume [ty]: "x2 be objectHIDDENM1"
          have "[TARSKIK4 x1,x2 ] inHIDDENR3 f1 iff ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)"
            using A12 sorry
          thus " not ([TARSKIK4 x1,x2 ] inHIDDENR3 f1 &  not [TARSKIK4 x1,x2 ] inHIDDENR3 f2) &  not ([TARSKIK4 x1,x2 ] inHIDDENR3 f2 &  not [TARSKIK4 x1,x2 ] inHIDDENR3 f1)"
            using A13 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef partit1_def_7 ("RelPARTIT1K5  _ " [164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func RelPARTIT1K5 Y \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex z be objectHIDDENM1 st ?P(x,z))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex tVar13 be objectHIDDENM1 st  ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & tVar13 =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 PARTITIONSPARTIT1K1 Y"
          then have 
            [ty]:"x be a-partitionEQREL-1M3-of Y"
            using partit1_def_3 sorry
          show " ex tVar13 be objectHIDDENM1 st  ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & tVar13 =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
          proof(rule bexI[of _ "ERlPARTIT1K4\<^bsub>(Y)\<^esub> x"])
            show " ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & ERlPARTIT1K4\<^bsub>(Y)\<^esub> x =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))"
      proof-
        have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & f .FUNCT-1K1 x =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))"
        proof-
          show " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & f .FUNCT-1K1 x =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))"
            using classes1_sch_1 A1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it1 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))) & (domRELAT-1K1 it2 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it2 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))) implies it1 =HIDDENR1 it2"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex z be objectHIDDENM1 st ?P(x,z))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex tVar13 be objectHIDDENM1 st  ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & tVar13 =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 PARTITIONSPARTIT1K1 Y"
          then have 
            [ty]:"x be a-partitionEQREL-1M3-of Y"
            using partit1_def_3 sorry
          show " ex tVar13 be objectHIDDENM1 st  ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & tVar13 =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
          proof(rule bexI[of _ "ERlPARTIT1K4\<^bsub>(Y)\<^esub> x"])
            show " ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & ERlPARTIT1K4\<^bsub>(Y)\<^esub> x =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it1 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))) & (domRELAT-1K1 it2 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & it2 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA))) implies it1 =HIDDENR1 it2"
      proof-
        have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & (( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & f1 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)) & (domRELAT-1K1 f2 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)))) implies f1 =HIDDENR1 f2"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
          fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
          assume A2: "domRELAT-1K1 f1 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y"
            and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & f1 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
            and A4: "domRELAT-1K1 f2 =XBOOLE-0R4 PARTITIONSPARTIT1K1 Y"
            and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
          have " for z be objectHIDDENM1 holds z inHIDDENR3 PARTITIONSPARTIT1K1 Y implies f1 .FUNCT-1K1 z =XBOOLE-0R4 f2 .FUNCT-1K1 z"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 PARTITIONSPARTIT1K1 Y implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 PARTITIONSPARTIT1K1 Y"
              then have "( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & f1 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA) & ( ex PA be a-partitionEQREL-1M3-of Y st PA =HIDDENR1 x & f2 .FUNCT-1K1 x =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
                using A3 A5 sorry
              thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus "f1 =HIDDENR1 f2"
            using A2 A4 funct_1_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem partit1_th_20:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PB iff ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds (PA '<'PARTIT1R1 PB implies ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB) & (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB implies PA '<'PARTIT1R1 PB)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    let ?RA = "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
    let ?RB = "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
    show "PA '<'PARTIT1R1 PB implies ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
    proof(rule impI)
      assume A1: "PA '<'PARTIT1R1 PB"
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 ?RA implies [TARSKIK4 x1,x2 ] inHIDDENR3 ?RB"
      proof-
        have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
        proof(rule ballI,rule ballI,rule impI)
          fix x1 assume [ty]: "x1 be objectHIDDENM1"
          fix x2 assume [ty]: "x2 be objectHIDDENM1"
          assume "[TARSKIK4 x1,x2 ] inHIDDENR3 ?RA"
          then obtain A where
            [ty]:"A be SubsetSUBSET-1M2-of Y" and 
            A2: "A inTARSKIR2 PA"and A3: "x1 inHIDDENR3 A & x2 inHIDDENR3 A"
            using partit1_def_6 sorry
          have " ex y be setHIDDENM2 st y inTARSKIR2 PB & A c=TARSKIR1 y"
            using A1 A2 setfam_1_def_2 sorry
          thus "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
            using A3 partit1_def_6 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
         sorry
    qed
    assume A4: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
    have " for x be setHIDDENM2 holds x inTARSKIR2 PA implies ( ex y be setHIDDENM2 st y inTARSKIR2 PB & x c=TARSKIR1 y)"
    proof-
      have " for x be setHIDDENM2 holds x inTARSKIR2 PA implies  not ( for y be setHIDDENM2 holds  not (y inTARSKIR2 PB & x c=TARSKIR1 y))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume A5: "x inTARSKIR2 PA"
        then have A6: "x <>HIDDENR2 {}XBOOLE-0K1"
          using eqrel_1_def_4 sorry
        let ?x0 = "the ElementSUBSET-1M1-of x"
        let ?y = "{z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 ?x0,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
        have A7: "x c=TARSKIR1 ?y"
        proof-
          have "x c=TARSKIR1 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
          proof-
            have " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 x implies x1 inHIDDENR3 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
            proof(rule ballI,rule impI)
              fix x1 assume [ty]: "x1 be objectHIDDENM1"
              assume A8: "x1 inHIDDENR3 x"
              then have "[TARSKIK4 ?x0,x1 ] inHIDDENR3 ?RA"
                using A5 partit1_def_6 sorry
              thus "x1 inHIDDENR3 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
                using A4 A5 A8 sorry
            qed "sorry"
            thus "x c=TARSKIR1 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        let ?x1 = "the ElementSUBSET-1M1-of x"
        have "[TARSKIK4 ?x0,?x1 ] inHIDDENR3 ?RA"
          using A5 A6 partit1_def_6 sorry
        then obtain B where
          [ty]:"B be SubsetSUBSET-1M2-of Y" and 
          A9: "B inTARSKIR2 PB"and A10: "?x0 inTARSKIR2 B"and "?x1 inTARSKIR2 B"
          using A4 partit1_def_6 sorry
        have A11: "?y c=TARSKIR1 B"
        proof-
          have "{z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB } c=TARSKIR1 B"
          proof-
            have " for x2 be objectHIDDENM1 holds x2 inHIDDENR3 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB } implies x2 inHIDDENR3 B"
            proof(rule ballI,rule impI)
              fix x2 assume [ty]: "x2 be objectHIDDENM1"
              assume "x2 inHIDDENR3 ?y"
              then have " ex z be ElementSUBSET-1M1-of Y st z =HIDDENR1 x2 & [TARSKIK4 ?x0,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
                 sorry
              then obtain B2 where
                [ty]:"B2 be SubsetSUBSET-1M2-of Y" and 
                A12: "B2 inTARSKIR2 PB"and A13: "?x0 inTARSKIR2 B2"and A14: "x2 inHIDDENR3 B2"
                using partit1_def_6 sorry
              have "B2 meetsXBOOLE-0R5 B"
                using A10 A13 xboole_0_th_3 sorry
              thus "x2 inHIDDENR3 B"
                using A9 A12 A14 eqrel_1_def_4 sorry
            qed "sorry"
            thus "{z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB } c=TARSKIR1 B"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "B c=TARSKIR1 ?y"
        proof-
          have "B c=TARSKIR1 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
          proof-
            have " for x2 be objectHIDDENM1 holds x2 inHIDDENR3 B implies x2 inHIDDENR3 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
            proof(rule ballI,rule impI)
              fix x2 assume [ty]: "x2 be objectHIDDENM1"
              assume A15: "x2 inHIDDENR3 B"
              then have "[TARSKIK4 ?x0,x2 ] inHIDDENR3 ?RB"
                using A9 A10 partit1_def_6 sorry
              thus "x2 inHIDDENR3 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
                using A15 sorry
            qed "sorry"
            thus "B c=TARSKIR1 {z where z be ElementSUBSET-1M1-of Y : [TARSKIK4 the ElementSUBSET-1M1-of x,z ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB }"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have "?y =XBOOLE-0R4 B"
          using A11 xboole_0_def_10 sorry
        thus " not ( for y be setHIDDENM2 holds  not (y inTARSKIR2 PB & x c=TARSKIR1 y))"
          using A7 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "PA '<'PARTIT1R1 PB"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_21:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for p0 be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of Y holds ((((((p0 c=TARSKIR1 Y & x inTARSKIR2 p0) & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 y) & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p2 be setHIDDENM2 st  ex p3 be setHIDDENM2 st  ex u be setHIDDENM2 st ((((p2 inTARSKIR2 PA & p3 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p2) & u inTARSKIR2 p2) & u inTARSKIR2 p3) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p3))) & p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA) & p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB implies y inTARSKIR2 p0"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for p0 be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of Y holds p0 c=TARSKIR1 Y & ((x inTARSKIR2 p0 & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x) & ((f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 y & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f) & (( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p2 be setHIDDENM2 st  ex p3 be setHIDDENM2 st  ex u be setHIDDENM2 st ((((p2 inTARSKIR2 PA & p3 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p2) & u inTARSKIR2 p2) & u inTARSKIR2 p3) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p3)) & (p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA & p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB)))) implies y inTARSKIR2 p0"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    fix p0 assume [ty]: "p0 be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of Y"
    assume A1: "p0 c=TARSKIR1 Y"
      and A2: "x inTARSKIR2 p0 & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x"
      and A3: "f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 y & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
      and A4: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p2 be setHIDDENM2 st  ex p3 be setHIDDENM2 st  ex u be setHIDDENM2 st ((((p2 inTARSKIR2 PA & p3 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p2) & u inTARSKIR2 p2) & u inTARSKIR2 p3) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p3)"
      and A5: "p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
      and A6: "p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
    obtain A1 where
      [ty]:"A1 be setHIDDENM2" and 
      A7: "A1 c=TARSKIR1 PA"and "A1 <>HIDDENR2 {}XBOOLE-0K1"and A8: "p0 =XBOOLE-0R4 unionTARSKIK3 A1"
      using A5 sorry
    obtain B1 where
      [ty]:"B1 be setHIDDENM2" and 
      A9: "B1 c=TARSKIR1 PB"and "B1 <>HIDDENR2 {}XBOOLE-0K1"and A10: "p0 =XBOOLE-0R4 unionTARSKIK3 B1"
      using A6 sorry
    have A11: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 Y"
      using eqrel_1_def_4 sorry
    have A12: " for A be setHIDDENM2 holds A inTARSKIR2 PA implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be setHIDDENM2 holds B inTARSKIR2 PA implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
      using eqrel_1_def_4 sorry
    have A13: " for A be setHIDDENM2 holds A inTARSKIR2 PB implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be setHIDDENM2 holds B inTARSKIR2 PB implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
      using eqrel_1_def_4 sorry
    have " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 k inTARSKIR2 p0"
    proof-
      have " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 k inTARSKIR2 p0"
      proof-
        let ?P = "\<lambda>Lamb1. \<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 Lamb1 inTARSKIR2 p0"
        have A14: "?P(0NUMBERSK6)"
           sorry
        have A15: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for k be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 k inTARSKIR2 p0) implies (\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p0)"
          proof(rule ballI,rule impI,rule impMI ,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A16: "?P(k)"
            assume A17: "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              and A18: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
            have A19: "k <XXREAL-0R3 lenFINSEQ-1K4 f"
              using A18 nat_1_th_13 sorry
            have A20: "\<one>\<^sub>M <=XXREAL-0R1 k or \<one>\<^sub>M =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
              using A17 nat_1_th_8 sorry
            have "f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p0"
            proof-
              show "f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p0"
              proof-
                have cases: "\<one>\<^sub>M <=XXREAL-0R1 k or 0NUMBERSK6 =XBOOLE-0R4 k"
                  using A20 sorry
                have case1: "\<one>\<^sub>M <=XXREAL-0R1 k implies f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p0"
                proof(rule impI)
                  assume A21: "\<one>\<^sub>M <=XXREAL-0R1 k"
                  then obtain p2 p3 u where
                    [ty]:"p2 be setHIDDENM2" "p3 be setHIDDENM2" "u be setHIDDENM2" and 
                    A22: "p2 inTARSKIR2 PA"and A23: "p3 inTARSKIR2 PB"and A24: "f .FUNCT-1K1 k inTARSKIR2 p2"and A25: "u inTARSKIR2 p2"and A26: "u inTARSKIR2 p3"and A27: "f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p3"
                    using A4 A19 sorry
                  obtain A where
                    [ty]:"A be setHIDDENM2" and 
                    A28: "f .FUNCT-1K1 k inTARSKIR2 A"and A29: "A inTARSKIR2 PA"
                    using A1 A11 A16 A18 A21 nat_1_th_13 tarski_def_4 sorry
                  have A30: "p2 =XBOOLE-0R4 A or p2 missesXBOOLE-0R1 A"
                    using A22 A29 eqrel_1_def_4 sorry
                  obtain a where
                    [ty]:"a be setHIDDENM2" and 
                    A31: "f .FUNCT-1K1 k inTARSKIR2 a"and A32: "a inTARSKIR2 A1"
                    using A8 A16 A18 A21 nat_1_th_13 tarski_def_4 sorry
                  have "a =XBOOLE-0R4 p2 or a missesXBOOLE-0R1 p2"
                    using A7 A12 A22 A32 sorry
                  then have A33: "A c=TARSKIR1 p0"
                    using A8 A24 A28 A30 A31 A32 xboole_0_th_3 zfmisc_1_th_74 sorry
                  obtain B where
                    [ty]:"B be setHIDDENM2" and 
                    A34: "u inTARSKIR2 B"and A35: "B inTARSKIR2 PB"
                    using A23 A26 sorry
                  have A36: "p3 =XBOOLE-0R4 B or p3 missesXBOOLE-0R1 B"
                    using A23 A35 eqrel_1_def_4 sorry
                  obtain b where
                    [ty]:"b be setHIDDENM2" and 
                    A37: "u inTARSKIR2 b"and A38: "b inTARSKIR2 B1"
                    using A10 A24 A25 A28 A30 A33 tarski_def_4 xboole_0_th_3 sorry
                  have "p3 =XBOOLE-0R4 b or p3 missesXBOOLE-0R1 b"
                    using A9 A13 A23 A38 sorry
                  then have "B c=TARSKIR1 p0"
                    using A10 A26 A34 A36 A37 A38 xboole_0_th_3 zfmisc_1_th_74 sorry
                  thus "f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p0"
                    using A26 A27 A34 A36 xboole_0_th_3 sorry
                qed
                have case2: "0NUMBERSK6 =XBOOLE-0R4 k implies f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p0"
                proof(rule impI)
                  assume "0NUMBERSK6 =XBOOLE-0R4 k"
                  thus "f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p0"
                    using A2 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p0"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 k inTARSKIR2 p0"
          using nat_1_sch_2 A14 A15 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "y inTARSKIR2 p0"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_22:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R1 be Equivalence-RelationEQREL-1M2-of Y holds  for R2 be Equivalence-RelationEQREL-1M2-of Y holds  for f be FinSequenceFINSEQ-1M3-of Y holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (((x inTARSKIR2 Y & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 y) & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex u be setHIDDENM2 st (u inTARSKIR2 Y & [TARSKIK4 f .FUNCT-1K1 i,u ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2) & [TARSKIK4 u,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2)) implies [TARSKIK4 x,y ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R1 be Equivalence-RelationEQREL-1M2-of Y holds  for R2 be Equivalence-RelationEQREL-1M2-of Y holds  for f be FinSequenceFINSEQ-1M3-of Y holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Y & (f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x & ((f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 y & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex u be setHIDDENM2 st (u inTARSKIR2 Y & [TARSKIK4 f .FUNCT-1K1 i,u ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2) & [TARSKIK4 u,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2)))) implies [TARSKIK4 x,y ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix R1 assume [ty]: "R1 be Equivalence-RelationEQREL-1M2-of Y"
    fix R2 assume [ty]: "R2 be Equivalence-RelationEQREL-1M2-of Y"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of Y"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume A1: "x inTARSKIR2 Y"
      and A2: "f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x"
      and A3: "f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 y & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
      and A4: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex u be setHIDDENM2 st (u inTARSKIR2 Y & [TARSKIK4 f .FUNCT-1K1 i,u ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2) & [TARSKIK4 u,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2)"
    have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 i ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
    proof-
      have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 i ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
      proof-
        let ?P = "\<lambda>Lamb1. \<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 Lamb1 ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
        have A5: "?P(0NUMBERSK6)"
           sorry
        have A6: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for i be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 i ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2) implies (\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2)"
          proof(rule ballI,rule impI,rule impMI ,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume A7: "?P(i)"
            assume A8: "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M"
              and A9: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
            have A10: "i <XXREAL-0R3 lenFINSEQ-1K4 f"
              using A9 nat_1_th_13 sorry
            have A11: "\<one>\<^sub>M <=XXREAL-0R1 i or \<one>\<^sub>M =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
              using A8 nat_1_th_8 sorry
            have A12: "R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2 c=RELAT-1R2 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
              using eqrel_1_def_2 sorry
            have "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
            proof-
              show "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
              proof-
                have cases: "\<one>\<^sub>M <=XXREAL-0R1 i or 0NUMBERSK6 =XBOOLE-0R4 i"
                  using A11 sorry
                have case1: "\<one>\<^sub>M <=XXREAL-0R1 i implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
                proof(rule impI)
                  assume A13: "\<one>\<^sub>M <=XXREAL-0R1 i"
                  then obtain u where
                    [ty]:"u be setHIDDENM2" and 
                    A14: "u inTARSKIR2 Y"and A15: "[TARSKIK4 f .FUNCT-1K1 i,u ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2 & [TARSKIK4 u,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2"
                    using A4 A10 sorry
                  have 
                    [ty]:"u be ElementSUBSET-1M1-of Y"
                    using A14 sorry
                  have A16: "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
                    using finseq_1_def_3 sorry
                  then have "i inTARSKIR2 domFINSEQ-1K5 f"
                    using A10 A13 finseq_1_th_1 sorry
                  then obtain f1 where 
                    [ty]:"f1 be ElementSUBSET-1M1-of Y" and f1Def:"f1 = f .FUNCT-1K1 i"
                    using finseq_2_th_11 sorry
                  have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                    using A8 A9 A16 finseq_1_th_1 sorry
                  then obtain f2 where 
                    [ty]:"f2 be ElementSUBSET-1M1-of Y" and f2Def:"f2 = f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
                    using finseq_2_th_11 sorry
                  obtain p where 
                    [ty]:"p be FinSequenceFINSEQ-1M3-of Y" and pDef:"p = <*FINSEQ-4K3\<^bsub>(Y)\<^esub> f1,u,f2 *>"
                     sorry
                  have A17: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<three>\<^sub>M"
                    using finseq_1_th_45 sorry
                  have A18: "p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 i & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
                    using finseq_1_th_45 sorry
                  have " for j be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 j & j <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 j,p .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2"
                  proof(rule ballI,rule impMI ,rule impI)
                    fix j assume [ty]: "j be NatNAT-1M1"
                    assume A19: "\<one>\<^sub>M <=XXREAL-0R1 j"
                      and A20: "j <XXREAL-0R3 lenFINSEQ-1K4 p"
                    have "j <XXREAL-0R3 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
                      using A20 finseq_1_th_45 sorry
                    then have "j <=XXREAL-0R1 \<two>\<^sub>M"
                      using nat_1_th_13 sorry
                    then have " ex VarFor1 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M) & j =XBOOLE-0R4 VarFor1"
                      using nat_1_th_60 sorry
                    thus "[TARSKIK4 p .FUNCT-1K1 j,p .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2"
                      using A15 A18 A19 finseq_1_th_45 sorry
                  qed "sorry"
                  then have "[TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
                    using A17 A18 eqrel_1_th_28 sorry
                  thus "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
                    using A7 A9 A13 eqrel_1_th_7 nat_1_th_13 sorry
                qed
                have case2: "0NUMBERSK6 =XBOOLE-0R4 i implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
                proof(rule impI)
                  assume A21: "0NUMBERSK6 =XBOOLE-0R4 i"
                  have "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 \<one>\<^sub>M ] inHIDDENR3 R1"
                    using A1 A2 eqrel_1_th_5 sorry
                  then have "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 \<one>\<^sub>M ] inHIDDENR3 R1 \\/EQREL-1K3\<^bsub>(Y)\<^esub> R2"
                    using xboole_0_def_3 sorry
                  thus "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
                    using A12 A21 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 i ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
          using nat_1_sch_2 A5 A6 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "[TARSKIK4 x,y ] inHIDDENR3 R1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> R2"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_23:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    have A1: "PA is-finer-thanSETFAM-1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
      using partit1_th_16 sorry
    have A2: "PB is-finer-thanSETFAM-1R1 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"
      using partit1_th_16 sorry
    have A3: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 Y"
      using eqrel_1_def_4 sorry
    have A4: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PB =XBOOLE-0R4 Y"
      using eqrel_1_def_4 sorry
    have A5: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) c=RELAT-1R2 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) implies [TARSKIK4 x,y ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "[TARSKIK4 x,y ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
        then obtain p0 where
          [ty]:"p0 be SubsetSUBSET-1M2-of Y" and 
          A6: "p0 inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB"and A7: "x inHIDDENR3 p0"and A8: "y inHIDDENR3 p0"
          using partit1_def_6 sorry
        have A9: "p0 is-min-dependPARTIT1R4\<^bsub>(Y)\<^esub>(PA,PB)"
          using A6 partit1_def_5 sorry
        then have A10: "p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
           sorry
        have A11: "p0 is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
          using A9 sorry
        obtain A1 where
          [ty]:"A1 be setHIDDENM2" and 
          A12: "A1 c=TARSKIR1 PA"and "A1 <>HIDDENR2 {}XBOOLE-0K1"and A13: "p0 =XBOOLE-0R4 unionTARSKIK3 A1"
          using A10 sorry
        obtain a where
          [ty]:"a be setHIDDENM2" and 
          A14: "x inHIDDENR3 a"and A15: "a inTARSKIR2 A1"
          using A7 A13 tarski_def_4 sorry
        obtain Ca where 
          [ty]:"Ca be setHIDDENM2" and CaDef:"Ca = {p where p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PA :  ex f be FinSequenceFINSEQ-1M3-of Y st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f inTARSKIR2 p) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)) }"
           sorry
        obtain pb where 
          [ty]:"pb be setHIDDENM2" and pbDef:"pb = unionTARSKIK3 Ca"
           sorry
        obtain Cb where 
          [ty]:"Cb be setHIDDENM2" and CbDef:"Cb = {p where p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PB :  ex q be setHIDDENM2 st q inTARSKIR2 Ca & p /\\SUBSET-1K8\<^bsub>(Y)\<^esub> q <>HIDDENR2 {}XBOOLE-0K1 }"
           sorry
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of Y" and x9Def:"x9 = x"
          using A7 sorry
        obtain fx where 
          [ty]:"fx be FinSequenceFINSEQ-1M3-of Y" and fxDef:"fx = <*FINSEQ-1K13\<^bsub>(Y)\<^esub> x9*>"
           sorry
        have A16: "fx .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
          using finseq_1_def_8 sorry
        then have A17: "fx .FUNCT-1K1 lenFINSEQ-1K4 fx inTARSKIR2 a"
          using A14 finseq_1_th_40 sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fx & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fx implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & fx .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & fx .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
          using finseq_1_th_40 sorry
        then have A18: "a inTARSKIR2 Ca"
          using A12 A15 A16 A17 sorry
        then obtain y5 where
          [ty]:"y5 be setHIDDENM2" and 
          A19: "x inHIDDENR3 y5"and A20: "y5 inTARSKIR2 Ca"
          using A14 sorry
        obtain z5 where
          [ty]:"z5 be setHIDDENM2" and 
          A21: "x9 inTARSKIR2 z5"and A22: "z5 inTARSKIR2 PB"
          using A4 tarski_def_4 sorry
        have "y5 /\\XBOOLE-0K3 z5 <>HIDDENR2 {}XBOOLE-0K1"
          using A19 A21 xboole_0_def_4 sorry
        then have A23: "z5 inTARSKIR2 Cb"
          using A20 A22 sorry
        have "Ca c=TARSKIR1 PA"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 Ca implies z inHIDDENR3 PA"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 Ca"
            then have " ex p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PA st z =HIDDENR1 p & ( ex f be FinSequenceFINSEQ-1M3-of Y st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f inTARSKIR2 p) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
               sorry
            thus "z inHIDDENR3 PA"
               sorry
          qed "sorry"
          thus "Ca c=TARSKIR1 PA"
            using tarski_def_3 sorry
        qed
        then have A24: "pb is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PA"
          using A18 sorry
        have A25: "pb c=TARSKIR1 unionTARSKIK3 Cb"
        proof-
          have " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 pb implies x1 inHIDDENR3 unionTARSKIK3 Cb"
          proof(rule ballI,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            assume "x1 inHIDDENR3 pb"
            then obtain y where
              [ty]:"y be setHIDDENM2" and 
              A26: "x1 inHIDDENR3 y"and A27: "y inTARSKIR2 Ca"
              using tarski_def_4 sorry
            have " ex p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PA st y =XBOOLE-0R4 p & ( ex f be FinSequenceFINSEQ-1M3-of Y st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f inTARSKIR2 p) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
              using A27 sorry
            then obtain z where
              [ty]:"z be setHIDDENM2" and 
              A28: "x1 inHIDDENR3 z"and A29: "z inTARSKIR2 PB"
              using A4 A26 tarski_def_4 sorry
            have "y /\\XBOOLE-0K3 z <>HIDDENR2 {}XBOOLE-0K1"
              using A26 A28 xboole_0_def_4 sorry
            then have "z inTARSKIR2 Cb"
              using A27 A29 sorry
            thus "x1 inHIDDENR3 unionTARSKIK3 Cb"
              using A28 tarski_def_4 sorry
          qed "sorry"
          thus "pb c=TARSKIR1 unionTARSKIK3 Cb"
            using tarski_def_3 sorry
        qed
        have "unionTARSKIK3 Cb c=TARSKIR1 pb"
        proof-
          have " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 unionTARSKIK3 Cb implies x1 inHIDDENR3 pb"
          proof(rule ballI,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            assume "x1 inHIDDENR3 unionTARSKIK3 Cb"
            then obtain y1 where
              [ty]:"y1 be setHIDDENM2" and 
              A30: "x1 inHIDDENR3 y1"and A31: "y1 inTARSKIR2 Cb"
              using tarski_def_4 sorry
            have A32: " ex p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PB st y1 =XBOOLE-0R4 p & ( ex q be setHIDDENM2 st q inTARSKIR2 Ca & p /\\SUBSET-1K8\<^bsub>(Y)\<^esub> q <>HIDDENR2 {}XBOOLE-0K1)"
              using A31 sorry
            then obtain q where
              [ty]:"q be setHIDDENM2" and 
              A33: "q inTARSKIR2 Ca"and A34: "y1 /\\XBOOLE-0K3 q <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            obtain pd where
              [ty]:"pd be setHIDDENM2" and 
              A35: "x1 inHIDDENR3 pd"and A36: "pd inTARSKIR2 PA"
              using A3 A30 A32 tarski_def_4 sorry
            have A37: " ex pp be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PA st q =XBOOLE-0R4 pp & ( ex f be FinSequenceFINSEQ-1M3-of Y st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f inTARSKIR2 pp) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
              using A33 sorry
            then obtain fd where
              [ty]:"fd be FinSequenceFINSEQ-1M3-of Y" and 
              A38: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fd"and A39: "fd .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"and A40: "fd .FUNCT-1K1 lenFINSEQ-1K4 fd inTARSKIR2 q"and A41: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & fd .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & fd .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
               sorry
            have 
              [ty]:"x1 be ElementSUBSET-1M1-of Y"
              using A30 A32 sorry
            obtain f where 
              [ty]:"f be FinSequenceFINSEQ-1M3-of Y" and fDef:"f = fd ^FINSEQ-1K9\<^bsub>(Y)\<^esub> (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> x1*>)"
               sorry
            have "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fd +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> x1*>)"
              using finseq_1_th_22 sorry
            then have A42: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M"
              using finseq_1_th_40 sorry
            have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M"
              using A38 xreal_1_th_6 sorry
            then have A43: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
              using A42 xxreal_0_th_2 sorry
            have A44: "f .FUNCT-1K1 (lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 y1"
              using A30 finseq_1_th_42 sorry
            have "y1 meetsXBOOLE-0R5 q"
              using A34 xboole_0_def_7 sorry
            then obtain z0 where
              [ty]:"z0 be objectHIDDENM1" and 
              A45: "z0 inHIDDENR3 y1 & z0 inHIDDENR3 q"
              using xboole_0_th_3 sorry
            have A46: "z0 inHIDDENR3 y1 /\\XBOOLE-0K3 q"
              using A45 xboole_0_def_4 sorry
            have A47: "domFINSEQ-1K5 fd =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 fd)"
              using finseq_1_def_3 sorry
            have A48: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 fd implies f .FUNCT-1K1 k =XBOOLE-0R4 fd .FUNCT-1K1 k"
            proof(rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 fd"
              then have "k inTARSKIR2 domFINSEQ-1K5 fd"
                using A47 finseq_1_th_1 sorry
              thus "f .FUNCT-1K1 k =XBOOLE-0R4 fd .FUNCT-1K1 k"
                using finseq_1_def_7 sorry
            qed "sorry"
            then have A49: "(fd ^FINSEQ-1K9\<^bsub>(Y)\<^esub> (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> x1*>)).FUNCT-1K1 (lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 x1 & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
              using A38 A39 finseq_1_th_42 sorry
            have A50: "f .FUNCT-1K1 lenFINSEQ-1K4 fd inTARSKIR2 q"
              using A38 A40 A48 sorry
            have A51: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
            proof-
              have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
              proof(rule ballI,rule impI)
                fix i assume [ty]: "i be NatNAT-1M1"
                assume A52: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd"
                then have A53: "f .FUNCT-1K1 i =XBOOLE-0R4 fd .FUNCT-1K1 i"
                  using A48 sorry
                have "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fd"
                  using A52 nat_1_th_13 sorry
                then have "f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fd .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
                  using A48 sorry
                thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                  using A41 A52 A53 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
            proof-
              have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
              proof(rule ballI,rule impMI ,rule impI)
                fix i assume [ty]: "i be NatNAT-1M1"
                assume A54: "\<one>\<^sub>M <=XXREAL-0R1 i"
                  and A55: "i <XXREAL-0R3 lenFINSEQ-1K4 f"
                have A56: "i <=XXREAL-0R1 lenFINSEQ-1K4 fd"
                  using A42 A55 nat_1_th_13 sorry
                have "(\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd) &  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)) or (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd) & (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
                proof-
                  show "(\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd) &  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)) or (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd) & (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
                  proof-
                    have cases: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd or \<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd"
                      using A54 A56 xxreal_0_th_1 sorry
                    have case1: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                    proof(rule impI)
                      assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd"
                      thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                        using A51 sorry
                    qed
                    have case2: "\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                    proof(rule impI)
                      assume "\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd"
                      thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                        using A32 A37 A44 A46 A50 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                   sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            then have "pd inTARSKIR2 Ca"
              using A35 A36 A42 A43 A49 sorry
            thus "x1 inHIDDENR3 pb"
              using A35 tarski_def_4 sorry
          qed "sorry"
          thus "unionTARSKIK3 Cb c=TARSKIR1 pb"
            using tarski_def_3 sorry
        qed
        then have A57: "pb =XBOOLE-0R4 unionTARSKIK3 Cb"
          using A25 xboole_0_def_10 sorry
        have "Cb c=TARSKIR1 PB"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 Cb implies z inHIDDENR3 PB"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 Cb"
            then have " ex p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PB st z =HIDDENR1 p & ( ex q be setHIDDENM2 st q inTARSKIR2 Ca & p /\\SUBSET-1K8\<^bsub>(Y)\<^esub> q <>HIDDENR2 {}XBOOLE-0K1)"
               sorry
            thus "z inHIDDENR3 PB"
               sorry
          qed "sorry"
          thus "Cb c=TARSKIR1 PB"
            using tarski_def_3 sorry
        qed
        then have A58: "pb is-a-dependent-set-ofPARTIT1R3\<^bsub>(Y)\<^esub> PB"
          using A23 A57 sorry
        have " not pb c=TARSKIR1 p0 implies  False "
        proof(rule impI)
          assume " not pb c=TARSKIR1 p0"
          then have "pb \\SUBSET-1K6 p0 <>HIDDENR2 {}XBOOLE-0K1"
            using xboole_1_th_37 sorry
          then obtain x1 where
            [ty]:"x1 be objectHIDDENM1" and 
            A59: "x1 inHIDDENR3 pb \\SUBSET-1K6 p0"
            using xboole_0_def_1 sorry
          have A60: " not x1 inHIDDENR3 p0"
            using A59 xboole_0_def_5 sorry
          obtain y1 where
            [ty]:"y1 be setHIDDENM2" and 
            A61: "x1 inHIDDENR3 y1"and A62: "y1 inTARSKIR2 Cb"
            using A57 A59 tarski_def_4 sorry
          have A63: " ex p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PB st y1 =XBOOLE-0R4 p & ( ex q be setHIDDENM2 st q inTARSKIR2 Ca & p /\\SUBSET-1K8\<^bsub>(Y)\<^esub> q <>HIDDENR2 {}XBOOLE-0K1)"
            using A62 sorry
          then obtain q where
            [ty]:"q be setHIDDENM2" and 
            A64: "q inTARSKIR2 Ca"and A65: "y1 /\\XBOOLE-0K3 q <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          have A66: " ex pp be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PA st q =XBOOLE-0R4 pp & ( ex f be FinSequenceFINSEQ-1M3-of Y st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f inTARSKIR2 pp) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
            using A64 sorry
          then obtain fd where
            [ty]:"fd be FinSequenceFINSEQ-1M3-of Y" and 
            A67: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fd"and A68: "fd .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"and A69: "fd .FUNCT-1K1 lenFINSEQ-1K4 fd inTARSKIR2 q"and A70: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & fd .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & fd .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
             sorry
          have 
            [ty]:"x1 be ElementSUBSET-1M1-of Y"
            using A61 A63 sorry
          obtain f where 
            [ty]:"f be FinSequenceFINSEQ-1M3-of Y" and fDef:"f = fd ^FINSEQ-1K9\<^bsub>(Y)\<^esub> (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> x1*>)"
             sorry
          have "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fd +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> x1*>)"
            using finseq_1_th_22 sorry
          then have A71: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M"
            using finseq_1_th_40 sorry
          have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M"
            using A67 xreal_1_th_6 sorry
          then have A72: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
            using A71 xxreal_0_th_2 sorry
          have A73: "f .FUNCT-1K1 (lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 y1"
            using A61 finseq_1_th_42 sorry
          have "y1 meetsXBOOLE-0R5 q"
            using A65 xboole_0_def_7 sorry
          then obtain z0 where
            [ty]:"z0 be objectHIDDENM1" and 
            A74: "z0 inHIDDENR3 y1 & z0 inHIDDENR3 q"
            using xboole_0_th_3 sorry
          have A75: "z0 inHIDDENR3 y1 /\\XBOOLE-0K3 q"
            using A74 xboole_0_def_4 sorry
          have A76: "domFINSEQ-1K5 fd =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 fd)"
            using finseq_1_def_3 sorry
          have A77: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 fd implies f .FUNCT-1K1 k =XBOOLE-0R4 fd .FUNCT-1K1 k"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 fd"
            then have "k inTARSKIR2 domFINSEQ-1K5 fd"
              using A76 finseq_1_th_1 sorry
            thus "f .FUNCT-1K1 k =XBOOLE-0R4 fd .FUNCT-1K1 k"
              using finseq_1_def_7 sorry
          qed "sorry"
          then have A78: "(fd ^FINSEQ-1K9\<^bsub>(Y)\<^esub> (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> x1*>)).FUNCT-1K1 (lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 x1 & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
            using A67 A68 finseq_1_th_42 sorry
          have A79: "f .FUNCT-1K1 lenFINSEQ-1K4 fd inTARSKIR2 q"
            using A67 A69 A77 sorry
          have A80: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
          proof-
            have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume A81: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd"
              then have A82: "f .FUNCT-1K1 i =XBOOLE-0R4 fd .FUNCT-1K1 i"
                using A77 sorry
              have "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fd"
                using A81 nat_1_th_13 sorry
              then have "f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fd .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
                using A77 sorry
              thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                using A70 A81 A82 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A83: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
          proof-
            have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
            proof(rule ballI,rule impMI ,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume A84: "\<one>\<^sub>M <=XXREAL-0R1 i"
                and A85: "i <XXREAL-0R3 lenFINSEQ-1K4 f"
              have A86: "i <=XXREAL-0R1 lenFINSEQ-1K4 fd"
                using A71 A85 nat_1_th_13 sorry
              have "(\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd) &  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)) or (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd) & (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
              proof-
                show "(\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd) &  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)) or (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd) & (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
                proof-
                  have cases: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd or \<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd"
                    using A84 A86 xxreal_0_th_1 sorry
                  have case1: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                  proof(rule impI)
                    assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd"
                    thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                      using A80 sorry
                  qed
                  have case2: "\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                  proof(rule impI)
                    assume "\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd"
                    thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                      using A63 A66 A73 A75 A79 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1) & x0 inTARSKIR2 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
          proof-
            have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not (((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1) & x0 inTARSKIR2 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f"
              then obtain p1 p2 x0 where
                [ty]:"p1 be setHIDDENM2" "p2 be setHIDDENM2" "x0 be setHIDDENM2" and 
                A87: "(p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1"and A88: "x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2"and A89: "f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2"
                using A83 sorry
              have "x0 inTARSKIR2 p1 & x0 inTARSKIR2 p2"
                using A88 xboole_0_def_4 sorry
              thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not (((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1) & x0 inTARSKIR2 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                using A87 A89 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " False "
            using A7 A10 A11 A60 A71 A72 A78 partit1_th_21 sorry
        qed
        then have "y inHIDDENR3 pb"
          using A8 A9 A24 A58 sorry
        then obtain y1 where
          [ty]:"y1 be setHIDDENM2" and 
          A90: "y inHIDDENR3 y1"and A91: "y1 inTARSKIR2 Cb"
          using A25 tarski_def_4 sorry
        have A92: " ex p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PB st y1 =XBOOLE-0R4 p & ( ex q be setHIDDENM2 st q inTARSKIR2 Ca & p /\\SUBSET-1K8\<^bsub>(Y)\<^esub> q <>HIDDENR2 {}XBOOLE-0K1)"
          using A91 sorry
        then obtain q where
          [ty]:"q be setHIDDENM2" and 
          A93: "q inTARSKIR2 Ca"and A94: "y1 /\\XBOOLE-0K3 q <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have A95: " ex pp be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 Y)\<^esub>-of PA st q =XBOOLE-0R4 pp & ( ex f be FinSequenceFINSEQ-1M3-of Y st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x) & f .FUNCT-1K1 lenFINSEQ-1K4 f inTARSKIR2 pp) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
          using A93 sorry
        then obtain fd where
          [ty]:"fd be FinSequenceFINSEQ-1M3-of Y" and 
          A96: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fd"and A97: "fd .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"and A98: "fd .FUNCT-1K1 lenFINSEQ-1K4 fd inTARSKIR2 q"and A99: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & fd .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & fd .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
           sorry
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of Y" and y9Def:"y9 = y"
          using A8 sorry
        obtain f where 
          [ty]:"f be FinSequenceFINSEQ-1M3-of Y" and fDef:"f = fd ^FINSEQ-1K9\<^bsub>(Y)\<^esub> (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> y9*>)"
           sorry
        have "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fd +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> y9*>)"
          using finseq_1_th_22 sorry
        then have A100: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        then have A101: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using A96 xreal_1_th_6 sorry
        have A102: "f .FUNCT-1K1 (lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 y1"
          using A90 finseq_1_th_42 sorry
        have "y1 meetsXBOOLE-0R5 q"
          using A94 xboole_0_def_7 sorry
        then obtain z0 where
          [ty]:"z0 be objectHIDDENM1" and 
          A103: "z0 inHIDDENR3 y1 & z0 inHIDDENR3 q"
          using xboole_0_th_3 sorry
        have A104: "z0 inHIDDENR3 y1 /\\XBOOLE-0K3 q"
          using A103 xboole_0_def_4 sorry
        have A105: "domFINSEQ-1K5 fd =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 fd)"
          using finseq_1_def_3 sorry
        have A106: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 fd implies f .FUNCT-1K1 k =XBOOLE-0R4 fd .FUNCT-1K1 k"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 fd"
          then have "k inTARSKIR2 domFINSEQ-1K5 fd"
            using A105 finseq_1_th_1 sorry
          thus "f .FUNCT-1K1 k =XBOOLE-0R4 fd .FUNCT-1K1 k"
            using finseq_1_def_7 sorry
        qed "sorry"
        then have A107: "f .FUNCT-1K1 lenFINSEQ-1K4 fd inTARSKIR2 q"
          using A96 A98 sorry
        have A108: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
        proof-
          have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume A109: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd"
            then have A110: "f .FUNCT-1K1 i =XBOOLE-0R4 fd .FUNCT-1K1 i"
              using A106 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fd"
              using A109 nat_1_th_13 sorry
            then have "f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 fd .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
              using A106 sorry
            thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
              using A99 A109 A110 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A111: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex p1 be setHIDDENM2 st  ex p2 be setHIDDENM2 st  ex x0 be setHIDDENM2 st (((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)"
        proof-
          have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
          proof(rule ballI,rule impMI ,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume A112: "\<one>\<^sub>M <=XXREAL-0R1 i"
              and A113: "i <XXREAL-0R3 lenFINSEQ-1K4 f"
            have A114: "i <=XXREAL-0R1 lenFINSEQ-1K4 fd"
              using A100 A113 nat_1_th_13 sorry
            have "(\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd) &  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)) or (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd) & (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
            proof-
              show "(\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd) &  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)) or (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd) & (\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2)))"
              proof-
                have cases: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd or \<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd"
                  using A112 A114 xxreal_0_th_1 sorry
                have case1: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                proof(rule impI)
                  assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 fd"
                  thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                    using A108 sorry
                qed
                have case2: "\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd implies  not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                proof(rule impI)
                  assume "\<one>\<^sub>M <=XXREAL-0R1 i & i =XBOOLE-0R4 lenFINSEQ-1K4 fd"
                  thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
                    using A92 A95 A102 A104 A107 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " not ( for p1 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for x0 be setHIDDENM2 holds  not ((((p1 inTARSKIR2 PA & p2 inTARSKIR2 PB) & f .FUNCT-1K1 i inTARSKIR2 p1) & x0 inTARSKIR2 p1 /\\XBOOLE-0K3 p2) & f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A115: "(fd ^FINSEQ-1K9\<^bsub>(Y)\<^esub> (<*FINSEQ-1K13\<^bsub>(Y)\<^esub> y9*>)).FUNCT-1K1 (lenFINSEQ-1K4 fd +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 y & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using A101 finseq_1_th_42 xxreal_0_th_2 sorry
        have A116: "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
          using A96 A97 A106 sorry
        have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies ( ex u be setHIDDENM2 st (u inTARSKIR2 Y & [TARSKIK4 f .FUNCT-1K1 i,u ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB) & [TARSKIK4 u,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
        proof-
          have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies  not ( for u be setHIDDENM2 holds  not ((u inTARSKIR2 Y & [TARSKIK4 f .FUNCT-1K1 i,u ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB) & [TARSKIK4 u,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB))"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f"
            then obtain p1 p2 u where
              [ty]:"p1 be setHIDDENM2" "p2 be setHIDDENM2" "u be setHIDDENM2" and 
              A117: "p1 inTARSKIR2 PA"and A118: "p2 inTARSKIR2 PB"and A119: "f .FUNCT-1K1 i inTARSKIR2 p1"and A120: "u inTARSKIR2 p1 /\\XBOOLE-0K3 p2"and A121: "f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 p2"
              using A111 sorry
            have A122: "u inTARSKIR2 p1"
              using A120 xboole_0_def_4 sorry
            have A123: "u inTARSKIR2 p2"
              using A120 xboole_0_def_4 sorry
            obtain x2 where 
              [ty]:"x2 be setHIDDENM2" and x2Def:"x2 = f .FUNCT-1K1 i"
               sorry
            obtain y2 where 
              [ty]:"y2 be setHIDDENM2" and y2Def:"y2 = f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
               sorry
            have A124: "[TARSKIK4 x2,u ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
              using A117 A119 A122 partit1_def_6 sorry
            have A125: "[TARSKIK4 u,y2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
              using A118 A121 A123 partit1_def_6 sorry
            have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB & ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
              using xboole_1_th_7 sorry
            thus " not ( for u be setHIDDENM2 holds  not ((u inTARSKIR2 Y & [TARSKIK4 f .FUNCT-1K1 i,u ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB) & [TARSKIK4 u,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB))"
              using A117 A122 A124 A125 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have "[TARSKIK4 x9,y9 ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
          using A100 A115 A116 partit1_th_22 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
           sorry
      qed "sorry"
      thus "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) c=RELAT-1R2 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
        using relat_1_def_3 sorry
    qed
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
    proof(rule ballI,rule ballI,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
      then have "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA or [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
        using xboole_0_def_3 sorry
      then have A126: "( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A) or ( ex B be SubsetSUBSET-1M2-of Y st (B inTARSKIR2 PB & x1 inHIDDENR3 B) & x2 inHIDDENR3 B)"
        using partit1_def_6 sorry
      have "((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) & [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) or ((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex B be SubsetSUBSET-1M2-of Y st (B inTARSKIR2 PB & x1 inHIDDENR3 B) & x2 inHIDDENR3 B)) & ((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex B be SubsetSUBSET-1M2-of Y st (B inTARSKIR2 PB & x1 inHIDDENR3 B) & x2 inHIDDENR3 B) implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB))"
      proof-
        show "((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)) & [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) or ((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex B be SubsetSUBSET-1M2-of Y st (B inTARSKIR2 PB & x1 inHIDDENR3 B) & x2 inHIDDENR3 B)) & ((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex B be SubsetSUBSET-1M2-of Y st (B inTARSKIR2 PB & x1 inHIDDENR3 B) & x2 inHIDDENR3 B) implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB))"
        proof-
          have cases: "(x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A) or (x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex B be SubsetSUBSET-1M2-of Y st (B inTARSKIR2 PB & x1 inHIDDENR3 B) & x2 inHIDDENR3 B)"
            using A126 sorry
          have case1: "(x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A) implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
          proof(rule impI)
            assume "(x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex A be SubsetSUBSET-1M2-of Y st (A inTARSKIR2 PA & x1 inHIDDENR3 A) & x2 inHIDDENR3 A)"
            then obtain A where
              [ty]:"A be SubsetSUBSET-1M2-of Y" and 
              A127: "A inTARSKIR2 PA"and A128: "x1 inHIDDENR3 A & x2 inHIDDENR3 A"
               sorry
            have " ex y be setHIDDENM2 st y inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB & A c=TARSKIR1 y"
              using A1 A127 setfam_1_def_2 sorry
            thus "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
              using A128 partit1_def_6 sorry
          qed
          have case2: "(x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex B be SubsetSUBSET-1M2-of Y st (B inTARSKIR2 PB & x1 inHIDDENR3 B) & x2 inHIDDENR3 B) implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
          proof(rule impI)
            assume "(x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & ( ex B be SubsetSUBSET-1M2-of Y st (B inTARSKIR2 PB & x1 inHIDDENR3 B) & x2 inHIDDENR3 B)"
            then obtain B where
              [ty]:"B be SubsetSUBSET-1M2-of Y" and 
              A129: "B inTARSKIR2 PB"and A130: "x1 inHIDDENR3 B & x2 inHIDDENR3 B"
               sorry
            have " ex y be setHIDDENM2 st y inTARSKIR2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB & B c=TARSKIR1 y"
              using A2 A129 setfam_1_def_2 sorry
            thus "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
              using A130 partit1_def_6 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
         sorry
    qed "sorry"
    then have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
       sorry
    then have "(ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB) c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)"
      using eqrel_1_def_2 sorry
    thus "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_24:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    have A1: "PA '>'PARTIT1R2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"
      using partit1_th_15 sorry
    have A2: "PB '>'PARTIT1R2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"
      using partit1_th_15 sorry
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) iff [TARSKIK4 x1,x2 ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
    proof-
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds ([TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) implies [TARSKIK4 x1,x2 ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)) & ([TARSKIK4 x1,x2 ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB) implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB))"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        show "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) implies [TARSKIK4 x1,x2 ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
        proof(rule impI)
          assume "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)"
          then obtain C where
            [ty]:"C be SubsetSUBSET-1M2-of Y" and 
            A3: "C inTARSKIR2 PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB"and A4: "x1 inHIDDENR3 C & x2 inHIDDENR3 C"
            using partit1_def_6 sorry
          have A5: " ex A be setHIDDENM2 st A inTARSKIR2 PA & C c=TARSKIR1 A"
            using A1 A3 setfam_1_def_2 sorry
          have A6: " ex B be setHIDDENM2 st B inTARSKIR2 PB & C c=TARSKIR1 B"
            using A2 A3 setfam_1_def_2 sorry
          have A7: "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
            using A4 A5 partit1_def_6 sorry
          have "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
            using A4 A6 partit1_def_6 sorry
          thus "[TARSKIK4 x1,x2 ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
            using A7 xboole_0_def_4 sorry
        qed
        assume A8: "[TARSKIK4 x1,x2 ] inHIDDENR3 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
        then have A9: "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
          using xboole_0_def_4 sorry
        have A10: "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
          using A8 xboole_0_def_4 sorry
        obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of Y" and 
          A11: "A inTARSKIR2 PA"and A12: "x1 inHIDDENR3 A"and A13: "x2 inHIDDENR3 A"
          using A9 partit1_def_6 sorry
        obtain B where
          [ty]:"B be SubsetSUBSET-1M2-of Y" and 
          A14: "B inTARSKIR2 PB"and A15: "x1 inHIDDENR3 B"and A16: "x2 inHIDDENR3 B"
          using A10 partit1_def_6 sorry
        have A17: "A /\\SUBSET-1K9\<^bsub>(Y)\<^esub> B <>HIDDENR2 {}XBOOLE-0K1"
          using A12 A15 xboole_0_def_4 sorry
        obtain C where
          [ty]:"C be SubsetSUBSET-1M2-of Y" and 
          A18: "C =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(Y)\<^esub> B"
           sorry
        have A19: "C inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PB)"
          using A11 A14 A18 setfam_1_def_5 sorry
        have " not C inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          using A17 A18 tarski_def_1 sorry
        then have A20: "C inTARSKIR2 INTERSECTIONSETFAM-1K3(PA,PB) \\SUBSET-1K6 {TARSKIK1 {}XBOOLE-0K1 }"
          using A19 xboole_0_def_5 sorry
        have "x1 inHIDDENR3 C & x2 inHIDDENR3 C"
          using A12 A13 A15 A16 A18 xboole_0_def_4 sorry
        thus "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)"
          using A20 partit1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_25:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA =RELAT-1R1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB implies PA =XBOOLE-0R4 PB"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA =RELAT-1R1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB implies PA =XBOOLE-0R4 PB"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    assume "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA =RELAT-1R1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
    then have "PA '<'PARTIT1R1 PB & PB '<'PARTIT1R1 PA"
      using partit1_th_20 sorry
    thus "PA =XBOOLE-0R4 PB"
      using partit1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_26:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC =XBOOLE-0R4 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC)"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC =XBOOLE-0R4 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    fix PC assume [ty]: "PC be a-partitionEQREL-1M3-of Y"
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> ((PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC) =HIDDENR1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB))\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC)"
      using partit1_th_23 sorry
    also have "... = ((ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB))\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC)"
      using partit1_th_23 sorry
    also have "... = (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> ((ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC))"
      using eqrel_1_th_13 sorry
    also have "... = (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC))"
      using partit1_th_23 sorry
    also have "... = ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC))"
      using partit1_th_23 sorry
    finally have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> ((PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC) =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC))"
       sorry
    thus "(PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC =XBOOLE-0R4 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PB '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PC)"
      using partit1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_27:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 PA"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)) & (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB)) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> ((ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB))"
      using partit1_th_23 partit1_th_24 sorry
    thus "PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 PA"
      using partit1_th_25 eqrel_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_28:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 PA"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)) & (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> ((ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB))"
      using partit1_th_23 partit1_th_24 sorry
    thus "PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =XBOOLE-0R4 PA"
      using partit1_th_25 eqrel_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_29:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PC & PB '<'PARTIT1R1 PC implies PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB '<'PARTIT1R1 PC"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds PA '<'PARTIT1R1 PC & PB '<'PARTIT1R1 PC implies PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB '<'PARTIT1R1 PC"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    fix PC assume [ty]: "PC be a-partitionEQREL-1M3-of Y"
    assume "PA '<'PARTIT1R1 PC & PB '<'PARTIT1R1 PC"
    then have A1: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC & ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC"
      using partit1_th_20 sorry
    have A2: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
      using partit1_th_23 sorry
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC"
      using A1 xboole_1_th_8 sorry
    then have "(ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB) c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC"
      using eqrel_1_def_2 sorry
    thus "PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PB '<'PARTIT1R1 PC"
      using A2 partit1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_30:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PC & PB '>'PARTIT1R2 PC implies PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB '>'PARTIT1R2 PC"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds  for PB be a-partitionEQREL-1M3-of Y holds  for PC be a-partitionEQREL-1M3-of Y holds PA '>'PARTIT1R2 PC & PB '>'PARTIT1R2 PC implies PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB '>'PARTIT1R2 PC"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    fix PB assume [ty]: "PB be a-partitionEQREL-1M3-of Y"
    fix PC assume [ty]: "PC be a-partitionEQREL-1M3-of Y"
    assume "PA '>'PARTIT1R2 PC & PB '>'PARTIT1R2 PC"
    then have A1: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA & ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB"
      using partit1_th_20 sorry
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PB)"
      using partit1_th_24 sorry
    then have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PC c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB)"
      using A1 xboole_1_th_19 sorry
    thus "PA '/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PB '>'PARTIT1R2 PC"
      using partit1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) PARTIT1K6("%IPARTIT1K6  _ " [164]164) where
  "%IPARTIT1K6 Y \<equiv> SmallestPartitionEQREL-1K12 Y"

abbreviation(input) PARTIT1K7("%IPARTIT1K7  _ " [164]164) where
  "%IPARTIT1K7 Y \<equiv> SmallestPartitionEQREL-1K12 Y"

mtheorem partit1_add_1:
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster SmallestPartitionEQREL-1K12 Y as-term-is a-partitionEQREL-1M3-of Y"
proof
(*coherence*)
  show "SmallestPartitionEQREL-1K12 Y be a-partitionEQREL-1M3-of Y"
     sorry
qed "sorry"

mdef partit1_def_8 ("%OPARTIT1K8  _ " [164]164 ) where
  mlet "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func %OPARTIT1K8 Y \<rightarrow> a-partitionEQREL-1M3-of Y equals
  {TARSKIK1 Y}"
proof-
  (*coherence*)
    show "{TARSKIK1 Y} be a-partitionEQREL-1M3-of Y"
    proof-
      have A1: "{TARSKIK1 Y} be Subset-FamilySETFAM-1M1-of Y & unionTARSKIK3 {TARSKIK1 Y} =XBOOLE-0R4 Y"
        using zfmisc_1_th_25 zfmisc_1_th_68 sorry
      have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 {TARSKIK1 Y} implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 {TARSKIK1 Y} implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
      proof-
        have " for A be SubsetSUBSET-1M2-of Y holds A inTARSKIR2 {TARSKIK1 Y} implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of Y holds B inTARSKIR2 {TARSKIK1 Y} implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B))"
        proof(rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
          fix A assume [ty]: "A be SubsetSUBSET-1M2-of Y"
          assume A2: "A inTARSKIR2 {TARSKIK1 Y}"
          then have A3: "A =XBOOLE-0R4 Y"
            using tarski_def_1 sorry
          show "A <>HIDDENR2 {}XBOOLE-0K1"
            using A2 tarski_def_1 sorry
          fix B assume [ty]: "B be SubsetSUBSET-1M2-of Y"
          assume "B inTARSKIR2 {TARSKIK1 Y}"
          thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
            using A3 tarski_def_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "{TARSKIK1 Y} be a-partitionEQREL-1M3-of Y"
        using A1 eqrel_1_def_4 sorry
    qed
qed "sorry"

mtheorem partit1_th_31:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds %IPARTIT1K7 Y =XBOOLE-0R4 {B where B be SubsetSUBSET-1M2-of Y :  ex x be setHIDDENM2 st B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y }"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds %IPARTIT1K7 Y =XBOOLE-0R4 {B where B be SubsetSUBSET-1M2-of Y :  not ( for x be setHIDDENM2 holds  not (B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)) }"
  proof(rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?B0 = "{B where B be SubsetSUBSET-1M2-of Y :  ex x be setHIDDENM2 st B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y }"
    have A1: "%IPARTIT1K7 Y c=TARSKIR1 ?B0"
    proof-
      have "%IPARTIT1K7 Y c=TARSKIR1 {B where B be SubsetSUBSET-1M2-of Y :  not ( for x be setHIDDENM2 holds  not (B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)) }"
      proof-
        have " for a be objectHIDDENM1 holds a inHIDDENR3 %IPARTIT1K7 Y implies a inHIDDENR3 {B where B be SubsetSUBSET-1M2-of Y :  not ( for x be setHIDDENM2 holds  not (B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)) }"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 %IPARTIT1K7 Y"
          then have "a inHIDDENR3 {{TARSKIK1 x} where x be ElementSUBSET-1M1-of Y :  True  }"
            using eqrel_1_th_37 sorry
          then obtain x where
            [ty]:"x be ElementSUBSET-1M1-of Y" and 
            A2: "a =HIDDENR1 {TARSKIK1 x}"
             sorry
          obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of Y" and yDef:"y = x"
             sorry
          obtain B where 
            [ty]:"B be SubsetSUBSET-1M2-of Y" and BDef:"B = {TARSKIK1 y}"
            using zfmisc_1_th_31 sorry
          have "a =HIDDENR1 B"
            using A2 sorry
          thus "a inHIDDENR3 {B where B be SubsetSUBSET-1M2-of Y :  not ( for x be setHIDDENM2 holds  not (B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)) }"
             sorry
        qed "sorry"
        thus "%IPARTIT1K7 Y c=TARSKIR1 {B where B be SubsetSUBSET-1M2-of Y :  not ( for x be setHIDDENM2 holds  not (B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)) }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "?B0 c=TARSKIR1 %IPARTIT1K7 Y"
    proof-
      have "{B where B be SubsetSUBSET-1M2-of Y :  not ( for x be setHIDDENM2 holds  not (B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)) } c=TARSKIR1 %IPARTIT1K7 Y"
      proof-
        have " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 {B where B be SubsetSUBSET-1M2-of Y :  ex x be setHIDDENM2 st B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y } implies x1 inHIDDENR3 %IPARTIT1K7 Y"
        proof(rule ballI,rule impI)
          fix x1 assume [ty]: "x1 be objectHIDDENM1"
          assume "x1 inHIDDENR3 ?B0"
          then have " ex B be SubsetSUBSET-1M2-of Y st x1 =HIDDENR1 B & ( ex x be setHIDDENM2 st B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)"
             sorry
          then have "x1 inHIDDENR3 {{TARSKIK1 z} where z be ElementSUBSET-1M1-of Y :  True  }"
             sorry
          thus "x1 inHIDDENR3 %IPARTIT1K7 Y"
            using eqrel_1_th_37 sorry
        qed "sorry"
        thus "{B where B be SubsetSUBSET-1M2-of Y :  not ( for x be setHIDDENM2 holds  not (B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)) } c=TARSKIR1 %IPARTIT1K7 Y"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "%IPARTIT1K7 Y =XBOOLE-0R4 {B where B be SubsetSUBSET-1M2-of Y :  not ( for x be setHIDDENM2 holds  not (B =XBOOLE-0R4 {TARSKIK1 x} & x inTARSKIR2 Y)) }"
      using A1 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_32:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds %OPARTIT1K8 Y '>'PARTIT1R2 PA & PA '>'PARTIT1R2 %IPARTIT1K7 Y"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds %OPARTIT1K8 Y '>'PARTIT1R2 PA & PA '>'PARTIT1R2 %IPARTIT1K7 Y"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    have A1: " for a be setHIDDENM2 holds a inTARSKIR2 PA implies ( ex b be setHIDDENM2 st b inTARSKIR2 %OPARTIT1K8 Y & a c=TARSKIR1 b)"
    proof-
      have " for a be setHIDDENM2 holds a inTARSKIR2 PA implies  not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 %OPARTIT1K8 Y & a c=TARSKIR1 b))"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be setHIDDENM2"
        assume A2: "a inTARSKIR2 PA"
        then have A3: "a c=TARSKIR1 Y"
           sorry
        have A4: "a <>HIDDENR2 {}XBOOLE-0K1"
          using A2 eqrel_1_def_4 sorry
        let ?x = "the ElementSUBSET-1M1-of a"
        have A5: "?x inTARSKIR2 Y"
          using A2 A4 tarski_def_3 sorry
        have "unionSETFAM-1K5\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =XBOOLE-0R4 Y"
          using eqrel_1_def_4 sorry
        then obtain b where
          [ty]:"b be setHIDDENM2" and 
          "?x inTARSKIR2 b"and A6: "b inTARSKIR2 %OPARTIT1K8 Y"
          using A5 tarski_def_4 sorry
        have "a c=TARSKIR1 b"
          using A3 A6 tarski_def_1 sorry
        thus " not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 %OPARTIT1K8 Y & a c=TARSKIR1 b))"
          using A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for a be setHIDDENM2 holds a inTARSKIR2 %IPARTIT1K7 Y implies ( ex b be setHIDDENM2 st b inTARSKIR2 PA & a c=TARSKIR1 b)"
    proof-
      have " for a be setHIDDENM2 holds a inTARSKIR2 %IPARTIT1K7 Y implies  not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 PA & a c=TARSKIR1 b))"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be setHIDDENM2"
        assume A7: "a inTARSKIR2 %IPARTIT1K7 Y"
        then have "a inTARSKIR2 {{TARSKIK1 x} where x be ElementSUBSET-1M1-of Y :  True  }"
          using eqrel_1_th_37 sorry
        then obtain x where
          [ty]:"x be ElementSUBSET-1M1-of Y" and 
          A8: "a =XBOOLE-0R4 {TARSKIK1 x}"
           sorry
        have A9: "a <>HIDDENR2 {}XBOOLE-0K1"
          using A7 eqrel_1_def_4 sorry
        let ?u = "the ElementSUBSET-1M1-of a"
        have A10: "?u =XBOOLE-0R4 x"
          using A8 tarski_def_1 sorry
        have A11: "?u inTARSKIR2 Y"
          using A7 A9 tarski_def_3 sorry
        have "unionSETFAM-1K5\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 Y"
          using eqrel_1_def_4 sorry
        then obtain b where
          [ty]:"b be setHIDDENM2" and 
          A12: "?u inTARSKIR2 b"and A13: "b inTARSKIR2 PA"
          using A11 tarski_def_4 sorry
        have "a c=TARSKIR1 b"
          using A8 A10 A12 tarski_def_1 sorry
        thus " not ( for b be setHIDDENM2 holds  not (b inTARSKIR2 PA & a c=TARSKIR1 b))"
          using A13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "%OPARTIT1K8 Y '>'PARTIT1R2 PA & PA '>'PARTIT1R2 %IPARTIT1K7 Y"
      using A1 setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_33:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =RELAT-1R1 nablaEQREL-1K1 Y"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =RELAT-1R1 nablaEQREL-1K1 Y"
  proof(rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have "nablaEQREL-1K1 Y c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y)"
    proof-
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 nablaEQREL-1K1 Y implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y)"
      proof(rule ballI,rule ballI,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A1: "[TARSKIK4 x1,x2 ] inHIDDENR3 nablaEQREL-1K1 Y"
        have A2: "Y inTARSKIR2 %OPARTIT1K8 Y"
          using tarski_def_1 sorry
        have "x1 inHIDDENR3 Y & x2 inHIDDENR3 Y"
          using A1 zfmisc_1_th_87 sorry
        thus "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y)"
          using A2 partit1_def_6 sorry
      qed "sorry"
      thus "nablaEQREL-1K1 Y c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y)"
        using relat_1_def_3 sorry
    qed
    thus "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =RELAT-1R1 nablaEQREL-1K1 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_34:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) =RELAT-1R1 idRELAT-1K7 Y"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) =RELAT-1R1 idRELAT-1K7 Y"
  proof(rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have A1: "unionSETFAM-1K5\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) =XBOOLE-0R4 Y"
      using eqrel_1_def_4 sorry
    have A2: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) c=RELAT-1R2 idRELAT-1K7 Y"
    proof-
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) implies [TARSKIK4 x1,x2 ] inHIDDENR3 idRELAT-1K7 Y"
      proof(rule ballI,rule ballI,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y)"
        then obtain a where
          [ty]:"a be SubsetSUBSET-1M2-of Y" and 
          A3: "a inTARSKIR2 %IPARTIT1K7 Y"and A4: "x1 inHIDDENR3 a & x2 inHIDDENR3 a"
          using partit1_def_6 sorry
        have "%IPARTIT1K7 Y =XBOOLE-0R4 {{TARSKIK1 x} where x be ElementSUBSET-1M1-of Y :  True  }"
          using eqrel_1_th_37 sorry
        then obtain x where
          [ty]:"x be ElementSUBSET-1M1-of Y" and 
          A5: "a =XBOOLE-0R4 {TARSKIK1 x}"
          using A3 sorry
        have "x1 =HIDDENR1 x & x2 =HIDDENR1 x"
          using A4 A5 tarski_def_1 sorry
        thus "[TARSKIK4 x1,x2 ] inHIDDENR3 idRELAT-1K7 Y"
          using relat_1_def_10 sorry
      qed "sorry"
      thus "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) c=RELAT-1R2 idRELAT-1K7 Y"
        using relat_1_def_3 sorry
    qed
    have "idRELAT-1K7 Y c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y)"
    proof-
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 idRELAT-1K7 Y implies [TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y)"
      proof(rule ballI,rule ballI,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A6: "[TARSKIK4 x1,x2 ] inHIDDENR3 idRELAT-1K7 Y"
        then have A7: "x1 inHIDDENR3 Y"
          using relat_1_def_10 sorry
        have A8: "x1 =HIDDENR1 x2"
          using A6 relat_1_def_10 sorry
        have " ex y be setHIDDENM2 st x1 inHIDDENR3 y & y inTARSKIR2 %IPARTIT1K7 Y"
          using A1 A7 tarski_def_4 sorry
        thus "[TARSKIK4 x1,x2 ] inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y)"
          using A8 partit1_def_6 sorry
      qed "sorry"
      thus "idRELAT-1K7 Y c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y)"
        using relat_1_def_3 sorry
    qed
    thus "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) =RELAT-1R1 idRELAT-1K7 Y"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_35:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds %IPARTIT1K7 Y '<'PARTIT1R1 %OPARTIT1K8 Y"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds %IPARTIT1K7 Y '<'PARTIT1R1 %OPARTIT1K8 Y"
  proof(rule ballI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =HIDDENR1 nablaEQREL-1K1 Y"
      using partit1_th_33 sorry
    also have "... = [:ZFMISC-1K2 Y,Y :]"
       sorry
    finally have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =HIDDENR1 [:ZFMISC-1K2 Y,Y :]"
       sorry
    then have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y)"
       sorry
    thus "%IPARTIT1K7 Y '<'PARTIT1R1 %OPARTIT1K8 Y"
      using partit1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_36:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds (%OPARTIT1K8 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 %OPARTIT1K8 Y & (%OPARTIT1K8 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds (%OPARTIT1K8 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 %OPARTIT1K8 Y & (%OPARTIT1K8 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
  proof(rule ballI,rule ballI,rule conjMI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    have A1: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> ((%OPARTIT1K8 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y))\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
      using partit1_th_23 sorry
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =RELAT-1R1 nablaEQREL-1K1 Y"
      using partit1_th_33 sorry
    then have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA =RELAT-1R1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y)"
      using eqrel_1_th_1 sorry
    then have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) c=RELAT-1R2 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y))\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
      using eqrel_1_def_2 sorry
    then have A2: "%OPARTIT1K8 Y '<'PARTIT1R1 (%OPARTIT1K8 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA"
      using A1 partit1_th_20 sorry
    have "%OPARTIT1K8 Y '>'PARTIT1R2 PA '\\/'PARTIT1K3\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y)"
      using partit1_th_32 sorry
    thus "(%OPARTIT1K8 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 %OPARTIT1K8 Y"
      using A2 partit1_th_4 sorry
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> ((%OPARTIT1K8 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y))/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA) & ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%OPARTIT1K8 Y) =RELAT-1R1 nablaEQREL-1K1 Y"
      using partit1_th_24 partit1_th_33 sorry
    thus "(%OPARTIT1K8 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
      using partit1_th_25 xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partit1_th_37:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds (%IPARTIT1K7 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA & (%IPARTIT1K7 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 %IPARTIT1K7 Y"
proof-
  have " for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for PA be a-partitionEQREL-1M3-of Y holds (%IPARTIT1K7 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA & (%IPARTIT1K7 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 %IPARTIT1K7 Y"
  proof(rule ballI,rule ballI,rule conjMI)
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix PA assume [ty]: "PA be a-partitionEQREL-1M3-of Y"
    have A1: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) =RELAT-1R1 idRELAT-1K7 Y"
      using partit1_th_34 sorry
    have A2: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> ((%IPARTIT1K7 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA) =RELAT-1R1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y))\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA) & ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y))\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
      using partit1_th_23 eqrel_1_def_2 sorry
    have A3: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) \\/EQREL-1K3\<^bsub>(Y)\<^esub> ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 idRELAT-1K7 Y \\/XBOOLE-0K2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
      using partit1_th_34 sorry
    have "%IPARTIT1K7 Y '<'PARTIT1R1 PA"
      using partit1_th_32 sorry
    then have A4: "ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y) c=RELAT-1R2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
      using partit1_th_20 sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 idRELAT-1K7 Y \\/XBOOLE-0K2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA implies z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A5: "z inHIDDENR3 idRELAT-1K7 Y \\/XBOOLE-0K2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
      have "z inHIDDENR3 idRELAT-1K7 Y & z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA or z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA & (z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA implies z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
      proof-
        show "z inHIDDENR3 idRELAT-1K7 Y & z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA or z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA & (z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA implies z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
        proof-
          have cases: "z inHIDDENR3 idRELAT-1K7 Y or z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
            using A5 xboole_0_def_3 sorry
          have case1: "z inHIDDENR3 idRELAT-1K7 Y implies z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
          proof(rule impI)
            assume "z inHIDDENR3 idRELAT-1K7 Y"
            thus "z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
              using A1 A4 sorry
          qed
          have case2: "z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA implies z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
          proof(rule impI)
            assume "z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
            thus "z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "z inHIDDENR3 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
         sorry
    qed "sorry"
    then have A6: "idRELAT-1K7 Y \\/XBOOLE-0K2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=TARSKIR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
       sorry
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA c=RELAT-1R2 idRELAT-1K7 Y \\/XBOOLE-0K2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
      using xboole_1_th_7 sorry
    then have "idRELAT-1K7 Y \\/XBOOLE-0K2 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA"
      using A6 xboole_0_def_10 sorry
    then have A7: "PA '<'PARTIT1R1 (%IPARTIT1K7 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA"
      using A2 A3 partit1_th_20 sorry
    have "%IPARTIT1K7 Y '<'PARTIT1R1 PA"
      using partit1_th_32 sorry
    then have "(%IPARTIT1K7 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA '<'PARTIT1R1 PA"
      using partit1_th_29 sorry
    thus "(%IPARTIT1K7 Y)'\\/'PARTIT1K3\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 PA"
      using A7 partit1_th_4 sorry
    have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> ((%IPARTIT1K7 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA) =HIDDENR1 (ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y))/\\EQREL-1K4\<^bsub>(Y)\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
      using partit1_th_24 sorry
    also have "... = idRELAT-1K7 Y /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 Y,Y :])\<^esub> (ERlPARTIT1K4\<^bsub>(Y)\<^esub> PA)"
      using partit1_th_34 sorry
    also have "... = idRELAT-1K7 Y"
      using eqrel_1_th_10 sorry
    also have "... = ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y)"
      using partit1_th_34 sorry
    finally have "ERlPARTIT1K4\<^bsub>(Y)\<^esub> ((%IPARTIT1K7 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA) =HIDDENR1 ERlPARTIT1K4\<^bsub>(Y)\<^esub> (%IPARTIT1K7 Y)"
       sorry
    thus "(%IPARTIT1K7 Y)'/\\'PARTIT1K2\<^bsub>(Y)\<^esub> PA =XBOOLE-0R4 %IPARTIT1K7 Y"
      using partit1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
