theory classes1
  imports funct_2 card_1 xfamily
begin
(*begin*)
reserve W, X, Y, Z for "setHIDDENM2"
reserve f, g for "FunctionFUNCT-1M1"
reserve a, x, y, z for "setHIDDENM2"
mdef classes1_def_1 ("subset-closedCLASSES1V1" 70 ) where
"attr subset-closedCLASSES1V1 for setHIDDENM2 means
  (\<lambda>B.  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 B & Y c=TARSKIR1 X implies Y inTARSKIR2 B)"..

mdef classes1_def_2 ("TarskiCLASSES1V2" 70 ) where
"attr TarskiCLASSES1V2 for setHIDDENM2 means
  (\<lambda>B. (B be subset-closedCLASSES1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 B implies boolSETFAM-1K9 X inTARSKIR2 B)) & ( for X be setHIDDENM2 holds X c=TARSKIR1 B implies (X,B)are-equipotentTARSKIR3 or X inTARSKIR2 B))"..

mdef classes1_def_3 (" _ is-Tarski-Class-ofCLASSES1R1  _ " [50,50]50 ) where
  mlet "A be setHIDDENM2", "B be setHIDDENM2"
"pred B is-Tarski-Class-ofCLASSES1R1 A means
  A inTARSKIR2 B & B be TarskiCLASSES1V2"..

mdef classes1_def_4 ("Tarski-ClassCLASSES1K1  _ " [300]300 ) where
  mlet "A be setHIDDENM2"
"func Tarski-ClassCLASSES1K1 A \<rightarrow> setHIDDENM2 means
  \<lambda>it. it is-Tarski-Class-ofCLASSES1R1 A & ( for D be setHIDDENM2 holds D is-Tarski-Class-ofCLASSES1R1 A implies it c=TARSKIR1 D)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st it is-Tarski-Class-ofCLASSES1R1 A & ( for D be setHIDDENM2 holds D is-Tarski-Class-ofCLASSES1R1 A implies it c=TARSKIR1 D)"
    proof-
      have " ex tVar1 be setHIDDENM2 st tVar1 is-Tarski-Class-ofCLASSES1R1 A & ( for D be setHIDDENM2 holds  not (D is-Tarski-Class-ofCLASSES1R1 A &  not tVar1 c=TARSKIR1 D))"
      proof-
        obtain Big where
          [ty]:"Big be setHIDDENM2" and 
          A1: "A inTARSKIR2 Big"and A2: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Big & Y c=TARSKIR1 X implies Y inTARSKIR2 Big"and A3: "( for X be setHIDDENM2 holds X inTARSKIR2 Big implies boolSETFAM-1K9 X inTARSKIR2 Big) & ( for X be setHIDDENM2 holds X c=TARSKIR1 Big implies (X,Big)are-equipotentTARSKIR3 or X inTARSKIR2 Big)"
          using zfmisc_1_th_112 sorry
        have A4: "Big be TarskiCLASSES1V2"
          using A3 A2 classes1_def_1 sorry
        let ?P = "\<lambda>Lamb1. Lamb1 is-Tarski-Class-ofCLASSES1R1 A"
        obtain Classes where
          [ty]:"Classes be setHIDDENM2" and 
          A5: " for X be setHIDDENM2 holds X inTARSKIR2 Classes iff X inTARSKIR2 boolSETFAM-1K9 Big & ?P(X)"
          using xfamily_sch_1 sorry
        let ?IT = "meetSETFAM-1K1 Classes"
        have A6: "Big inTARSKIR2 boolSETFAM-1K9 Big & Big is-Tarski-Class-ofCLASSES1R1 A"
          using A1 A4 zfmisc_1_def_1 sorry
        then have A7: "Big inTARSKIR2 Classes"
          using A5 sorry
        have A8: "Classes <>HIDDENR2 {}XBOOLE-0K1"
          using A5 A6 sorry
        have A9: " for X be setHIDDENM2 holds X inTARSKIR2 Classes implies A inTARSKIR2 X"
        proof(rule ballI,rule impI)
          fix X assume [ty]: "X be setHIDDENM2"
          assume "X inTARSKIR2 Classes"
          then have "X is-Tarski-Class-ofCLASSES1R1 A"
            using A5 sorry
          thus "A inTARSKIR2 X"
             sorry
        qed "sorry"
        then have A10: "A inTARSKIR2 ?IT"
          using A8 setfam_1_def_1 sorry
        show " ex tVar1 be setHIDDENM2 st tVar1 is-Tarski-Class-ofCLASSES1R1 A & ( for D be setHIDDENM2 holds  not (D is-Tarski-Class-ofCLASSES1R1 A &  not tVar1 c=TARSKIR1 D))"
        proof(rule bexI[of _ "?IT"])
          have "A inTARSKIR2 meetSETFAM-1K1 Classes & (meetSETFAM-1K1 Classes be TarskiCLASSES1V2 & ( for D be setHIDDENM2 holds  not (D is-Tarski-Class-ofCLASSES1R1 A &  not meetSETFAM-1K1 Classes c=TARSKIR1 D)))"
          proof(rule conjMI)
            show "A inTARSKIR2 meetSETFAM-1K1 Classes"
              using A8 A9 setfam_1_def_1 sorry
            have "( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes & Y c=TARSKIR1 X implies Y inTARSKIR2 meetSETFAM-1K1 Classes) & (( for X be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes implies boolSETFAM-1K9 X inTARSKIR2 meetSETFAM-1K1 Classes) & (( for X be setHIDDENM2 holds X c=TARSKIR1 meetSETFAM-1K1 Classes implies (X,meetSETFAM-1K1 Classes)are-equipotentTARSKIR3 or X inTARSKIR2 meetSETFAM-1K1 Classes) & ( for D be setHIDDENM2 holds D is-Tarski-Class-ofCLASSES1R1 A implies meetSETFAM-1K1 Classes c=TARSKIR1 D)))"
            proof(rule conjMI,rule conjMI,rule conjMI,rule ballI,rule impI)
              show A11: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes & Y c=TARSKIR1 X implies Y inTARSKIR2 meetSETFAM-1K1 Classes"
              proof-
                have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes & Y c=TARSKIR1 X implies Y inTARSKIR2 meetSETFAM-1K1 Classes"
                proof(rule ballI,rule ballI,rule impMI ,rule impI)
                  fix X assume [ty]: "X be setHIDDENM2"
                  fix Y assume [ty]: "Y be setHIDDENM2"
                  assume A12: "X inTARSKIR2 ?IT"
                    and A13: "Y c=TARSKIR1 X"
                  have " for Z be setHIDDENM2 holds Z inTARSKIR2 Classes implies Y inTARSKIR2 Z"
                  proof(rule ballI,rule impI)
                    fix Z assume [ty]: "Z be setHIDDENM2"
                    assume A14: "Z inTARSKIR2 Classes"
                    then have "Z is-Tarski-Class-ofCLASSES1R1 A"
                      using A5 sorry
                    then have "Z be TarskiCLASSES1V2"
                       sorry
                    then have A15: "Z be subset-closedCLASSES1V1"
                       sorry
                    have "X inTARSKIR2 Z"
                      using A12 A14 setfam_1_def_1 sorry
                    thus "Y inTARSKIR2 Z"
                      using A13 A15 sorry
                  qed "sorry"
                  thus "Y inTARSKIR2 meetSETFAM-1K1 Classes"
                    using A8 setfam_1_def_1 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              show A16: " for X be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes implies boolSETFAM-1K9 X inTARSKIR2 meetSETFAM-1K1 Classes"
              proof-
                have " for X be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes implies boolSETFAM-1K9 X inTARSKIR2 meetSETFAM-1K1 Classes"
                proof(rule ballI,rule impI)
                  fix X assume [ty]: "X be setHIDDENM2"
                  assume A17: "X inTARSKIR2 ?IT"
                  have " for Z be setHIDDENM2 holds Z inTARSKIR2 Classes implies boolSETFAM-1K9 X inTARSKIR2 Z"
                  proof(rule ballI,rule impI)
                    fix Z assume [ty]: "Z be setHIDDENM2"
                    assume A18: "Z inTARSKIR2 Classes"
                    then have "Z is-Tarski-Class-ofCLASSES1R1 A"
                      using A5 sorry
                    then have A19: "Z be TarskiCLASSES1V2"
                       sorry
                    have "X inTARSKIR2 Z"
                      using A17 A18 setfam_1_def_1 sorry
                    thus "boolSETFAM-1K9 X inTARSKIR2 Z"
                      using A19 sorry
                  qed "sorry"
                  thus "boolSETFAM-1K9 X inTARSKIR2 meetSETFAM-1K1 Classes"
                    using A8 setfam_1_def_1 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              show A20: " for X be setHIDDENM2 holds X c=TARSKIR1 meetSETFAM-1K1 Classes implies (X,meetSETFAM-1K1 Classes)are-equipotentTARSKIR3 or X inTARSKIR2 meetSETFAM-1K1 Classes"
              proof-
                have " for X be setHIDDENM2 holds X c=TARSKIR1 meetSETFAM-1K1 Classes &  not (X,meetSETFAM-1K1 Classes)are-equipotentTARSKIR3 implies X inTARSKIR2 meetSETFAM-1K1 Classes"
                proof(rule ballI,rule impMI ,rule impI)
                  fix X assume [ty]: "X be setHIDDENM2"
                  assume A21: "X c=TARSKIR1 ?IT"
                    and A22: " not (X,?IT)are-equipotentTARSKIR3"
                  have " for Z be setHIDDENM2 holds Z inTARSKIR2 Classes implies X inTARSKIR2 Z"
                  proof(rule ballI,rule impI)
                    fix Z assume [ty]: "Z be setHIDDENM2"
                    assume A23: "Z inTARSKIR2 Classes"
                    then have "Z is-Tarski-Class-ofCLASSES1R1 A"
                      using A5 sorry
                    then have A24: "Z be TarskiCLASSES1V2"
                       sorry
                    have A25: "?IT c=TARSKIR1 Z"
                      using A23 setfam_1_th_3 sorry
                    then have "X c=TARSKIR1 Z"
                      using A21 sorry
                    then have "(X,Z)are-equipotentTARSKIR3 or X inTARSKIR2 Z"
                      using A24 sorry
                    thus "X inTARSKIR2 Z"
                      using A21 A22 A25 card_1_th_24 sorry
                  qed "sorry"
                  thus "X inTARSKIR2 meetSETFAM-1K1 Classes"
                    using A8 setfam_1_def_1 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              fix D assume [ty]: "D be setHIDDENM2"
              assume A26: "D is-Tarski-Class-ofCLASSES1R1 A"
              then have A27: "A inTARSKIR2 D"
                 sorry
              have A28: "D be TarskiCLASSES1V2"
                using A26 sorry
              then have A29: "D be subset-closedCLASSES1V1"
                 sorry
              have A30: "?IT /\\XBOOLE-0K3 D is-Tarski-Class-ofCLASSES1R1 A"
              proof-
                have "meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D is-Tarski-Class-ofCLASSES1R1 A"
                proof-
                  have "A inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D & meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D be TarskiCLASSES1V2"
                  proof(rule conjMI)
                    show "A inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D"
                      using A10 A27 xboole_0_def_4 sorry
                    have "( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D & Y c=TARSKIR1 X implies Y inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D) & (( for X be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D implies boolSETFAM-1K9 X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D) & ( for X be setHIDDENM2 holds X c=TARSKIR1 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D &  not (X,meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D)are-equipotentTARSKIR3 implies X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D))"
                    proof(rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
                      show " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D & Y c=TARSKIR1 X implies Y inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D"
                      proof-
                        have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D & Y c=TARSKIR1 X implies Y inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D"
                        proof(rule ballI,rule ballI,rule impMI ,rule impI)
                          fix X assume [ty]: "X be setHIDDENM2"
                          fix Y assume [ty]: "Y be setHIDDENM2"
                          assume A31: "X inTARSKIR2 ?IT /\\XBOOLE-0K3 D"
                            and A32: "Y c=TARSKIR1 X"
                          have A33: "X inTARSKIR2 ?IT"
                            using A31 xboole_0_def_4 sorry
                          have A34: "X inTARSKIR2 D"
                            using A31 xboole_0_def_4 sorry
                          have A35: "Y inTARSKIR2 ?IT"
                            using A11 A32 A33 sorry
                          have "Y inTARSKIR2 D"
                            using A29 A32 A34 sorry
                          thus "Y inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D"
                            using A35 xboole_0_def_4 sorry
                        qed "sorry"
                        thus " ?thesis "
                           sorry
                      qed
                      show " for X be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D implies boolSETFAM-1K9 X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D"
                      proof-
                        have " for X be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D implies boolSETFAM-1K9 X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D"
                        proof(rule ballI,rule impI)
                          fix X assume [ty]: "X be setHIDDENM2"
                          assume A36: "X inTARSKIR2 ?IT /\\XBOOLE-0K3 D"
                          then have A37: "X inTARSKIR2 ?IT"
                            using xboole_0_def_4 sorry
                          have A38: "X inTARSKIR2 D"
                            using A36 xboole_0_def_4 sorry
                          have A39: "boolSETFAM-1K9 X inTARSKIR2 ?IT"
                            using A16 A37 sorry
                          have "boolSETFAM-1K9 X inTARSKIR2 D"
                            using A28 A38 sorry
                          thus "boolSETFAM-1K9 X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D"
                            using A39 xboole_0_def_4 sorry
                        qed "sorry"
                        thus " ?thesis "
                           sorry
                      qed
                      fix X assume [ty]: "X be setHIDDENM2"
                      assume A40: "X c=TARSKIR1 ?IT /\\XBOOLE-0K3 D"
                        and A41: " not (X,?IT /\\XBOOLE-0K3 D)are-equipotentTARSKIR3"
                      have A42: "?IT /\\XBOOLE-0K3 D c=TARSKIR1 ?IT"
                        using xboole_1_th_17 sorry
                      have A43: "?IT /\\XBOOLE-0K3 D c=TARSKIR1 D"
                        using xboole_1_th_17 sorry
                      have A44: " not (X,?IT)are-equipotentTARSKIR3"
                        using A40 A41 A42 card_1_th_24 sorry
                      have A45: "X c=TARSKIR1 D &  not (X,D)are-equipotentTARSKIR3"
                        using A40 A41 A43 card_1_th_24 sorry
                      have A46: "X inTARSKIR2 ?IT"
                        using A20 A40 A42 A44 xboole_1_th_1 sorry
                      have "X inTARSKIR2 D"
                        using A28 A45 sorry
                      thus "X inTARSKIR2 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D"
                        using A46 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D be TarskiCLASSES1V2"
                      using classes1_def_1 classes1_def_2 sorry
                  qed
                  thus "meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D is-Tarski-Class-ofCLASSES1R1 A"
                    using classes1_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have "?IT /\\XBOOLE-0K3 D c=TARSKIR1 Big"
              proof-
                have "meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D c=TARSKIR1 Big"
                proof-
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D implies x inHIDDENR3 Big"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 ?IT /\\XBOOLE-0K3 D"
                    then have "x inHIDDENR3 ?IT"
                      using xboole_0_def_4 sorry
                    thus "x inHIDDENR3 Big"
                      using A7 setfam_1_def_1 sorry
                  qed "sorry"
                  thus "meetSETFAM-1K1 Classes /\\XBOOLE-0K3 D c=TARSKIR1 Big"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              then have A47: "?IT c=TARSKIR1 ?IT /\\XBOOLE-0K3 D"
                using setfam_1_th_3 A5 A30 sorry
              have "?IT /\\XBOOLE-0K3 D c=TARSKIR1 D"
                using xboole_1_th_17 sorry
              thus "meetSETFAM-1K1 Classes c=TARSKIR1 D"
                using A47 sorry
            qed "sorry"
            thus "meetSETFAM-1K1 Classes be TarskiCLASSES1V2 & ( for D be setHIDDENM2 holds  not (D is-Tarski-Class-ofCLASSES1R1 A &  not meetSETFAM-1K1 Classes c=TARSKIR1 D))"
              using classes1_def_1 classes1_def_2 sorry
          qed
          thus "meetSETFAM-1K1 Classes is-Tarski-Class-ofCLASSES1R1 A & ( for D be setHIDDENM2 holds  not (D is-Tarski-Class-ofCLASSES1R1 A &  not meetSETFAM-1K1 Classes c=TARSKIR1 D))"
            using classes1_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds (it1 is-Tarski-Class-ofCLASSES1R1 A & ( for D be setHIDDENM2 holds D is-Tarski-Class-ofCLASSES1R1 A implies it1 c=TARSKIR1 D)) & (it2 is-Tarski-Class-ofCLASSES1R1 A & ( for D be setHIDDENM2 holds D is-Tarski-Class-ofCLASSES1R1 A implies it2 c=TARSKIR1 D)) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem classes1_cl_1:
  mlet "A be setHIDDENM2"
"cluster Tarski-ClassCLASSES1K1 A as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "Tarski-ClassCLASSES1K1 A be  non emptyXBOOLE-0V1"
  proof-
    have " not Tarski-ClassCLASSES1K1 A be emptyXBOOLE-0V1"
    proof-
      have "Tarski-ClassCLASSES1K1 A is-Tarski-Class-ofCLASSES1R1 A"
        using classes1_def_4 sorry
      thus " not Tarski-ClassCLASSES1K1 A be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem classes1_th_1:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 iff (W be subset-closedCLASSES1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 W implies boolSETFAM-1K9 X inTARSKIR2 W)) & ( for X be setHIDDENM2 holds X c=TARSKIR1 W & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W implies X inTARSKIR2 W)"
proof-
  have " for W be setHIDDENM2 holds (W be TarskiCLASSES1V2 implies (W be subset-closedCLASSES1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 W implies boolSETFAM-1K9 X inTARSKIR2 W)) & ( for X be setHIDDENM2 holds X c=TARSKIR1 W & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W implies X inTARSKIR2 W)) &  not (((W be subset-closedCLASSES1V1 & ( for X be setHIDDENM2 holds  not (X inTARSKIR2 W &  not boolSETFAM-1K9 X inTARSKIR2 W))) & ( for X be setHIDDENM2 holds  not ((X c=TARSKIR1 W & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W) &  not X inTARSKIR2 W))) &  not W be TarskiCLASSES1V2)"
  proof(rule ballI,rule conjMI)
    fix W assume [ty]: "W be setHIDDENM2"
    show "W be TarskiCLASSES1V2 implies (W be subset-closedCLASSES1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 W implies boolSETFAM-1K9 X inTARSKIR2 W)) & ( for X be setHIDDENM2 holds X c=TARSKIR1 W & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W implies X inTARSKIR2 W)"
    proof(rule impI,rule conjMI,rule ballI,rule impMI ,rule impI)
      assume A1: "W be TarskiCLASSES1V2"
      thus "W be subset-closedCLASSES1V1 & ( for X be setHIDDENM2 holds X inTARSKIR2 W implies boolSETFAM-1K9 X inTARSKIR2 W)"
         sorry
      fix X assume [ty]: "X be setHIDDENM2"
      assume A2: "X c=TARSKIR1 W"
        and A3: "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
      have "cardCARD-1K1 X <>HIDDENR2 cardCARD-1K1 W"
        using A3 sorry
      then have " not (X,W)are-equipotentTARSKIR3"
        using card_1_th_5 sorry
      thus "X inTARSKIR2 W"
        using A1 A2 sorry
    qed "sorry"
    have "( for X be setHIDDENM2 holds X c=TARSKIR1 W & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W implies X inTARSKIR2 W) implies ( for X be setHIDDENM2 holds X c=TARSKIR1 W implies (X,W)are-equipotentTARSKIR3 or X inTARSKIR2 W)"
    proof(rule impI,rule ballI,rule impI)
      assume A4: " for X be setHIDDENM2 holds X c=TARSKIR1 W & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W implies X inTARSKIR2 W"
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X c=TARSKIR1 W"
      then have "cardCARD-1K1 X c=TARSKIR1 cardCARD-1K1 W &  not cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W or X inTARSKIR2 W"
        using A4 card_1_th_11 sorry
      thus "(X,W)are-equipotentTARSKIR3 or X inTARSKIR2 W"
        using card_1_th_3 card_1_th_5 sorry
    qed "sorry"
    thus " not (((W be subset-closedCLASSES1V1 & ( for X be setHIDDENM2 holds  not (X inTARSKIR2 W &  not boolSETFAM-1K9 X inTARSKIR2 W))) & ( for X be setHIDDENM2 holds  not ((X c=TARSKIR1 W & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W) &  not X inTARSKIR2 W))) &  not W be TarskiCLASSES1V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_2:
" for X be setHIDDENM2 holds X inTARSKIR2 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds X inTARSKIR2 Tarski-ClassCLASSES1K1 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "Tarski-ClassCLASSES1K1 X is-Tarski-Class-ofCLASSES1R1 X"
      using classes1_def_4 sorry
    thus "X inTARSKIR2 Tarski-ClassCLASSES1K1 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K1 X & Z c=TARSKIR1 Y implies Z inTARSKIR2 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not ((Y inTARSKIR2 Tarski-ClassCLASSES1K1 X & Z c=TARSKIR1 Y) &  not Z inTARSKIR2 Tarski-ClassCLASSES1K1 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "Tarski-ClassCLASSES1K1 X is-Tarski-Class-ofCLASSES1R1 X"
      using classes1_def_4 sorry
    then have "Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
       sorry
    then have "Tarski-ClassCLASSES1K1 X be subset-closedCLASSES1V1"
       sorry
    thus " not ((Y inTARSKIR2 Tarski-ClassCLASSES1K1 X & Z c=TARSKIR1 Y) &  not Z inTARSKIR2 Tarski-ClassCLASSES1K1 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (Y inTARSKIR2 Tarski-ClassCLASSES1K1 X &  not boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K1 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "Tarski-ClassCLASSES1K1 X is-Tarski-Class-ofCLASSES1R1 X"
      using classes1_def_4 sorry
    then have "Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
       sorry
    thus " not (Y inTARSKIR2 Tarski-ClassCLASSES1K1 X &  not boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K1 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X implies (Y,Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3 or Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X &  not (Y,Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3) &  not Y inTARSKIR2 Tarski-ClassCLASSES1K1 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "Tarski-ClassCLASSES1K1 X is-Tarski-Class-ofCLASSES1R1 X"
      using classes1_def_4 sorry
    then have "Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
       sorry
    thus " not ((Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X &  not (Y,Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3) &  not Y inTARSKIR2 Tarski-ClassCLASSES1K1 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X & cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X implies Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X & cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X implies Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
      and A2: "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X"
    have "cardCARD-1K1 Y <>HIDDENR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X"
      using A2 sorry
    thus "Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      using A1 classes1_th_5 card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve u, v for "ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X"
reserve A, B, C for "OrdinalORDINAL1M3"
reserve L for "SequenceORDINAL1M4"
mdef classes1_def_5 ("Tarski-ClassCLASSES1K2'( _ , _ ')" [0,0]300 ) where
  mlet "X be setHIDDENM2", "A be OrdinalORDINAL1M3"
"func Tarski-ClassCLASSES1K2(X,A) \<rightarrow> setHIDDENM2 means
  \<lambda>it.  ex L be SequenceORDINAL1M4 st (((it =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  ex L be SequenceORDINAL1M4 st (((it =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Lamb2 & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Lamb2 }))\\/XBOOLE-0K2 boolSETFAM-1K9 Lamb2 /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Lamb2)\<^esub> Tarski-ClassCLASSES1K1 X"
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 (rngFUNCT-1K2 Lamb2) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
        have "( ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) & ( ex L be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
          using ordinal2_sch_7 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((it1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)) & ( ex L be SequenceORDINAL1M4 st (((it2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)) implies it1 =HIDDENR1 it2"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Lamb2 & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Lamb2 }))\\/XBOOLE-0K2 boolSETFAM-1K9 Lamb2 /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Lamb2)\<^esub> Tarski-ClassCLASSES1K1 X"
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 (rngFUNCT-1K2 Lamb2) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
        have "( ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) & ( ex L be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
          using ordinal2_sch_7 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X holds  not (v inTARSKIR2 L .FUNCT-1K1 C & u c=TARSKIR1 v)) })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 L .FUNCT-1K1 C }))\\/XBOOLE-0K2 boolSETFAM-1K9 (L .FUNCT-1K1 C) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (L .FUNCT-1K1 C))\<^esub> Tarski-ClassCLASSES1K1 X))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma classes1_lm_1:
" for X be setHIDDENM2 holds Tarski-ClassCLASSES1K2(X,0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X} & (( for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K2(X,succORDINAL1K1 A) =XBOOLE-0R4 (({uc where uc be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex vc be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st vc inTARSKIR2 Tarski-ClassCLASSES1K2(X,A) & uc c=TARSKIR1 vc })\\/XBOOLE-0K2 ({boolSETFAM-1K9 vc where vc be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : vc inTARSKIR2 Tarski-ClassCLASSES1K2(X,A) }))\\/XBOOLE-0K2 boolSETFAM-1K9 Tarski-ClassCLASSES1K2(X,A) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Tarski-ClassCLASSES1K2(X,A))\<^esub> Tarski-ClassCLASSES1K1 X) & ( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds ((A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & domRELAT-1K1 L =XBOOLE-0R4 A) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Tarski-ClassCLASSES1K2(X,B)) implies Tarski-ClassCLASSES1K2(X,A) =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X))"
proof(rule ballI,rule conjMI,rule conjMI)
  fix X assume [ty]: "X be setHIDDENM2"
  let ?F = "\<lambda>Lamb1. Tarski-ClassCLASSES1K2(X,Lamb1)"
  let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Lamb2 & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Lamb2 }))\\/XBOOLE-0K2 boolSETFAM-1K9 Lamb2 /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Lamb2)\<^esub> Tarski-ClassCLASSES1K1 X"
  let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 (rngFUNCT-1K2 Lamb2) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
  have A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 ?F(A) iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C)))"
    using classes1_def_5 sorry
  show "Tarski-ClassCLASSES1K2(X,0ORDINAL1K5) =XBOOLE-0R4 {TARSKIK1 X}"
    using ordinal2_sch_8 A1 sorry
  show " for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K2(X,succORDINAL1K1 A) =XBOOLE-0R4 (({uc where uc be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex vc be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st vc inTARSKIR2 Tarski-ClassCLASSES1K2(X,A) & uc c=TARSKIR1 vc })\\/XBOOLE-0K2 ({boolSETFAM-1K9 vc where vc be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : vc inTARSKIR2 Tarski-ClassCLASSES1K2(X,A) }))\\/XBOOLE-0K2 boolSETFAM-1K9 Tarski-ClassCLASSES1K2(X,A) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Tarski-ClassCLASSES1K2(X,A))\<^esub> Tarski-ClassCLASSES1K1 X"
    using ordinal2_sch_9 A1 sorry
  show " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds ((A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & domRELAT-1K1 L =XBOOLE-0R4 A) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Tarski-ClassCLASSES1K2(X,B)) implies Tarski-ClassCLASSES1K2(X,A) =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
  proof-
    have " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & (domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Tarski-ClassCLASSES1K2(X,B))) implies Tarski-ClassCLASSES1K2(X,A) =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      fix L assume [ty]: "L be SequenceORDINAL1M4"
      assume A2: "A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4"
        and A3: "domRELAT-1K1 L =XBOOLE-0R4 A"
        and A4: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 ?F(B)"
      show "Tarski-ClassCLASSES1K2(X,A) =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
        using ordinal2_sch_10 A1 A2 A3 A4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) CLASSES1K3("Tarski-ClassCLASSES1K3'( _ , _ ')" [0,0]300) where
  "Tarski-ClassCLASSES1K3(X,A) \<equiv> Tarski-ClassCLASSES1K2(X,A)"

mtheorem classes1_add_1:
  mlet "X be setHIDDENM2", "A be OrdinalORDINAL1M3"
"cluster Tarski-ClassCLASSES1K2(X,A) as-term-is SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
proof
(*coherence*)
  show "Tarski-ClassCLASSES1K2(X,A) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
  proof-
    let ?P = "\<lambda>Lamb1. Tarski-ClassCLASSES1K2(X,Lamb1) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
    have "{TARSKIK1 X} c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 X} implies x inHIDDENR3 Tarski-ClassCLASSES1K1 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {TARSKIK1 X}"
        then have "x =HIDDENR1 X"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 Tarski-ClassCLASSES1K1 X"
          using classes1_th_2 sorry
      qed "sorry"
      thus "{TARSKIK1 X} c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
        using tarski_def_3 sorry
    qed
    then have A1: "?P(0ORDINAL1K5)"
      using classes1_lm_1 sorry
    have A2: " for B be OrdinalORDINAL1M3 holds ?P(B) implies ?P(succORDINAL1K1 B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K2(X,B) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X implies Tarski-ClassCLASSES1K2(X,succORDINAL1K1 B) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
      proof(rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume "Tarski-ClassCLASSES1K2(X,B) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
        then obtain S where 
          [ty]:"S be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X" and SDef:"S = Tarski-ClassCLASSES1K2(X,B)"
           sorry
        let ?Y = "Tarski-ClassCLASSES1K2(X,succORDINAL1K1 B)"
        have "?Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
        proof-
          have "Tarski-ClassCLASSES1K2(X,succORDINAL1K1 B) c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 Tarski-ClassCLASSES1K2(X,succORDINAL1K1 B) implies x inHIDDENR3 Tarski-ClassCLASSES1K1 X"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 ?Y"
              then have "x inHIDDENR3 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 S & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 S }))\\/XBOOLE-0K2 boolSETFAM-1K9 S /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 S)\<^esub> Tarski-ClassCLASSES1K1 X"
                using classes1_lm_1 sorry
              then have A3: "x inHIDDENR3 ({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 S & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 S }) or x inHIDDENR3 boolSETFAM-1K9 S /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 S)\<^esub> Tarski-ClassCLASSES1K1 X"
                using xboole_0_def_3 sorry
              have A4: "x inHIDDENR3 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 S & u c=TARSKIR1 v } implies x inHIDDENR3 Tarski-ClassCLASSES1K1 X"
              proof(rule impI)
                assume "x inHIDDENR3 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 S & u c=TARSKIR1 v }"
                then have " ex u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st x =HIDDENR1 u & ( ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 S & u c=TARSKIR1 v)"
                   sorry
                thus "x inHIDDENR3 Tarski-ClassCLASSES1K1 X"
                   sorry
              qed
              have "x inHIDDENR3 {boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 S } implies x inHIDDENR3 Tarski-ClassCLASSES1K1 X"
              proof(rule impI)
                assume "x inHIDDENR3 {boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 S }"
                then have " ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st x =HIDDENR1 boolSETFAM-1K9 v & v inTARSKIR2 S"
                   sorry
                thus "x inHIDDENR3 Tarski-ClassCLASSES1K1 X"
                  using classes1_th_4 sorry
              qed
              thus "x inHIDDENR3 Tarski-ClassCLASSES1K1 X"
                using A3 A4 xboole_0_def_3 xboole_0_def_4 sorry
            qed "sorry"
            thus "Tarski-ClassCLASSES1K2(X,succORDINAL1K1 B) c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "Tarski-ClassCLASSES1K2(X,succORDINAL1K1 B) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for B be OrdinalORDINAL1M3 holds (B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4) & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?P(C)) implies ?P(B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds (B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4) & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies Tarski-ClassCLASSES1K2(X,C) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X) implies Tarski-ClassCLASSES1K2(X,B) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
      proof(rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A6: "B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4"
          and " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies Tarski-ClassCLASSES1K2(X,C) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
        let ?f = "\<lambda>Lamb1. Tarski-ClassCLASSES1K2(X,Lamb1)"
        obtain L where
          [ty]:"L be SequenceORDINAL1M4" and 
          A7: "domRELAT-1K1 L =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies L .FUNCT-1K1 C =XBOOLE-0R4 ?f(C))"
          using ordinal2_sch_2 sorry
        have "Tarski-ClassCLASSES1K2(X,B) =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
          using A6 A7 classes1_lm_1 sorry
        thus "Tarski-ClassCLASSES1K2(X,B) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
          using xboole_1_th_17 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal2_sch_1 A1 A2 A5 sorry
    thus "Tarski-ClassCLASSES1K2(X,A) be SubsetSUBSET-1M2-of Tarski-ClassCLASSES1K1 X"
       sorry
  qed
qed "sorry"

mtheorem classes1_th_7:
" for X be setHIDDENM2 holds Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 X}"
  using classes1_lm_1 sorry

mtheorem classes1_th_8:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) }))\\/XBOOLE-0K2 boolSETFAM-1K9 Tarski-ClassCLASSES1K3(X,A) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Tarski-ClassCLASSES1K3(X,A))\<^esub> Tarski-ClassCLASSES1K1 X"
  using classes1_lm_1 sorry

mtheorem classes1_th_9:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B) }"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) }"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4"
    let ?f = "\<lambda>Lamb1. Tarski-ClassCLASSES1K3(X,Lamb1)"
    obtain L where
      [ty]:"L be SequenceORDINAL1M4" and 
      A2: "domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 ?f(B))"
      using ordinal2_sch_2 sorry
    have A3: "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
      using A1 A2 classes1_lm_1 sorry
    have "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B) } & {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) } c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
    proof(rule conjMI)
      show "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B) }"
      proof-
        have "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A) implies x inHIDDENR3 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
            then have "x inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 L)"
              using A3 xboole_0_def_4 sorry
            then obtain Y where
              [ty]:"Y be setHIDDENM2" and 
              A4: "x inHIDDENR3 Y"and A5: "Y inTARSKIR2 rngFUNCT-1K2 L"
              using tarski_def_4 sorry
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A6: "y inHIDDENR3 domRELAT-1K1 L"and A7: "Y =XBOOLE-0R4 L .FUNCT-1K1 y"
              using A5 funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A6 sorry
            have "Y =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,y)"
              using A2 A6 A7 sorry
            thus "x inHIDDENR3 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) }"
              using A2 A4 A6 sorry
          qed "sorry"
          thus "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B) } implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B) }"
        then obtain u where
          [ty]:"u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X" and 
          A8: "x =HIDDENR1 u"and A9: " ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)"
           sorry
        obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A10: "B inTARSKIR2 A"and A11: "u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)"
          using A9 sorry
        have "L .FUNCT-1K1 B =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,B)"
          using A2 A10 sorry
        then have "Tarski-ClassCLASSES1K3(X,B) inTARSKIR2 rngFUNCT-1K2 L"
          using A2 A10 funct_1_def_3 sorry
        then have "u inTARSKIR2 unionTARSKIK3 (rngFUNCT-1K2 L)"
          using A11 tarski_def_4 sorry
        thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
          using A3 A8 xboole_0_def_4 sorry
      qed "sorry"
      thus "{u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) } c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
        using tarski_def_3 sorry
    qed
    thus "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) iff Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X or ( ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds (Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) implies Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X or ( ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z))) & (Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X or ( ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z)) implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?T1 = "{u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v }"
    let ?T2 = "{boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) }"
    let ?T3 = "boolSETFAM-1K9 Tarski-ClassCLASSES1K3(X,A) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Tarski-ClassCLASSES1K3(X,A))\<^esub> Tarski-ClassCLASSES1K1 X"
    have A1: "Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) =XBOOLE-0R4 (?T1 \\/XBOOLE-0K2 ?T2)\\/XBOOLE-0K2 ?T3"
      using classes1_lm_1 sorry
    show "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) implies Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X or ( ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z))"
    proof-
      have "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) implies  not ( not (Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X) & ( for Z be setHIDDENM2 holds  not (Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) &  not ( not Y c=TARSKIR1 Z &  not Y =XBOOLE-0R4 boolSETFAM-1K9 Z))))"
      proof(rule impI)
        assume "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
        then have A2: "Y inTARSKIR2 ?T1 \\/XBOOLE-0K2 ?T2 or Y inTARSKIR2 ?T3"
          using A1 xboole_0_def_3 sorry
        have A3: "Y inTARSKIR2 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v } implies ( ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z))"
        proof(rule impI)
          assume "Y inTARSKIR2 ?T1"
          then have " ex u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st Y =XBOOLE-0R4 u & ( ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v)"
             sorry
          thus " ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z)"
             sorry
        qed
        have "Y inTARSKIR2 {boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) } implies ( ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z))"
        proof(rule impI)
          assume "Y inTARSKIR2 ?T2"
          then have " ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st Y =XBOOLE-0R4 boolSETFAM-1K9 v & v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
             sorry
          thus " ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z)"
             sorry
        qed
        thus " not ( not (Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X) & ( for Z be setHIDDENM2 holds  not (Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) &  not ( not Y c=TARSKIR1 Z &  not Y =XBOOLE-0R4 boolSETFAM-1K9 Z))))"
          using A2 A3 xboole_0_def_3 xboole_0_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A4: "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X or ( ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z))"
    have A5: "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
    proof(rule impI)
      assume "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      then have "Y inTARSKIR2 ?T3"
        using xboole_0_def_4 sorry
      thus "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
        using A1 xboole_0_def_3 sorry
    qed
    have "( ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z)) implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
    proof(rule impI)
      assume Given: " ex Z be setHIDDENM2 st Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & (Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z)"
      then obtain Z where
        [ty]:"Z be setHIDDENM2" and 
        A6: "Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"and A7: "Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z"
         sorry
      have 
        [ty]:"Z be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X"
        using A6 sorry
      obtain y where 
        [ty]:"y be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X" and yDef:"y = Y"
        using A6 A7 classes1_th_3 classes1_th_4 sorry
      have A8: "Y c=TARSKIR1 Z implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
      proof(rule impI)
        assume "Y c=TARSKIR1 Z"
        then have "y inTARSKIR2 ?T1"
          using A6 sorry
        then have "Y inTARSKIR2 ?T1 \\/XBOOLE-0K2 ?T2"
          using xboole_0_def_3 sorry
        thus "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
          using A1 xboole_0_def_3 sorry
      qed
      have "Y =XBOOLE-0R4 boolSETFAM-1K9 Z implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 boolSETFAM-1K9 Z"
        then have "y inTARSKIR2 ?T2"
          using A6 sorry
        then have "Y inTARSKIR2 ?T1 \\/XBOOLE-0K2 ?T2"
          using xboole_0_def_3 sorry
        thus "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
          using A1 xboole_0_def_3 sorry
      qed
      thus "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
        using A7 A8 sorry
    qed
    thus "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
      using A4 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds Y c=TARSKIR1 Z & Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
  using classes1_th_10 sorry

mtheorem classes1_th_12:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
  using classes1_th_10 sorry

mtheorem classes1_th_13:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies (x inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) iff ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)))"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies (x inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))) & (( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)) implies x inTARSKIR2 Tarski-ClassCLASSES1K3(X,A))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4"
    then have A2: "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B) }"
      using classes1_th_9 sorry
    show "x inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))"
    proof-
      have "x inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies  not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & x inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)))"
      proof(rule impI)
        assume "x inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
        then have " ex u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st x =XBOOLE-0R4 u & ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & u inTARSKIR2 Tarski-ClassCLASSES1K3(X,B))"
          using A2 sorry
        thus " not ( for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 A & x inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)"
    then obtain B where
      [ty]:"B be OrdinalORDINAL1M3" and 
      A3: "B inTARSKIR2 A"and A4: "x inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)"
       sorry
    obtain u where 
      [ty]:"u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X" and uDef:"u = x"
      using A4 sorry
    have "u inTARSKIR2 {v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & v inTARSKIR2 Tarski-ClassCLASSES1K3(X,B) }"
      using A3 A4 sorry
    thus "x inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
      using A1 classes1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_14:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds ((A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4) & Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)) & (Z c=TARSKIR1 Y or Z =XBOOLE-0R4 boolSETFAM-1K9 Y) implies Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & (A be limit-ordinalORDINAL1V4 & Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)) implies (Z c=TARSKIR1 Y or Z =XBOOLE-0R4 boolSETFAM-1K9 Y implies Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "A be limit-ordinalORDINAL1V4"
      and A3: "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
    obtain B where
      [ty]:"B be OrdinalORDINAL1M3" and 
      A4: "B inTARSKIR2 A"and A5: "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)"
      using A1 A2 A3 classes1_th_13 sorry
    have A6: "boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B)"
      using A5 classes1_th_10 sorry
    have A7: "Z c=TARSKIR1 Y implies Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B)"
      using A5 classes1_th_10 sorry
    have A8: "succORDINAL1K1 B inTARSKIR2 A"
      using A2 A4 ordinal1_th_28 sorry
    assume "Z c=TARSKIR1 Y or Z =XBOOLE-0R4 boolSETFAM-1K9 Y"
    thus "Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
      using A2 A6 A7 A8 classes1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_15:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A) implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
      then have "x inHIDDENR3 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v }"
         sorry
      then have A1: "x inHIDDENR3 ({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) })"
        using xboole_0_def_3 sorry
      have "Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) }))\\/XBOOLE-0K2 boolSETFAM-1K9 Tarski-ClassCLASSES1K3(X,A) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Tarski-ClassCLASSES1K3(X,A))\<^esub> Tarski-ClassCLASSES1K1 X"
        using classes1_lm_1 sorry
      thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
        using A1 xboole_0_def_3 sorry
    qed "sorry"
    thus "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_16:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B)"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not (A c=ORDINAL1R1 B &  not Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?OnP = "\<lambda>Lamb1. A c=ORDINAL1R1 Lamb1 implies Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,Lamb1)"
    have A1: " for B be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?OnP(C)) implies ?OnP(B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies (A c=ORDINAL1R1 C implies Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,C))) & A c=ORDINAL1R1 B implies Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B)"
      proof(rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A2: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?OnP(C)"
          and A3: "A c=ORDINAL1R1 B"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A) implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A4: "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
          have "A <>HIDDENR2 B implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
          proof(rule impI)
            assume A5: "A <>HIDDENR2 B"
            then have A6: "A inTARSKIR2 B"
              using ordinal1_th_11 A3 xboole_0_def_8 sorry
            have A7: "B <>HIDDENR2 {}XBOOLE-0K1"
              using A3 A5 sorry
            have A8: "( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C) implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
            proof(rule impI)
              assume Given: " ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C"
              then obtain C where
                [ty]:"C be OrdinalORDINAL1M3" and 
                A9: "B =XBOOLE-0R4 succORDINAL1K1 C"
                 sorry
              have "A c=ORDINAL1R1 C & C inTARSKIR2 B"
                using A6 A9 ordinal1_th_22 sorry
              then have A10: "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,C)"
                using A2 sorry
              have "Tarski-ClassCLASSES1K3(X,C) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B)"
                using A9 classes1_th_15 sorry
              then have "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B)"
                using A10 sorry
              thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
                using A4 sorry
            qed
            have "( for C be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 C) implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
            proof(rule impI)
              assume " for C be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 C"
              then have "Tarski-ClassCLASSES1K3(X,B) =XBOOLE-0R4 {v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex C be OrdinalORDINAL1M3 st C inTARSKIR2 B & v inTARSKIR2 Tarski-ClassCLASSES1K3(X,C) }"
                using A7 classes1_th_9 ordinal1_th_29 sorry
              thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
                using A4 A6 sorry
            qed
            thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
              using A8 sorry
          qed
          thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
            using A4 sorry
        qed "sorry"
        thus "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B)"
          using tarski_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for B be OrdinalORDINAL1M3 holds ?OnP(B)"
      using ordinal1_sch_2 A1 sorry
    thus " not (A c=ORDINAL1R1 B &  not Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_17:
" for X be setHIDDENM2 holds  ex A be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
proof-
  have " for X be setHIDDENM2 holds ( for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K3(X,A) <>HIDDENR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)) implies  False "
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K3(X,A) <>HIDDENR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
    let ?P = "\<lambda>Lamb1.  ex A be OrdinalORDINAL1M3 st Lamb1 inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
    obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Z iff x inHIDDENR3 Tarski-ClassCLASSES1K1 X & ?P(x)"
      using xboole_0_sch_1 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be OrdinalORDINAL1M3 st (Lamb2 =HIDDENR1 A & Lamb1 inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)) &  not Lamb1 inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
    have A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?P(x,y) & ?P(x,z) implies y =HIDDENR1 z"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ( ex A be OrdinalORDINAL1M3 st (y =HIDDENR1 A & x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)) &  not x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)) implies (( ex B be OrdinalORDINAL1M3 st (z =HIDDENR1 B & x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B)) &  not x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)) implies (y <>HIDDENR2 z implies  False ))"
      proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume Given: " ex A be OrdinalORDINAL1M3 st (y =HIDDENR1 A & x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)) &  not x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
        then obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A4: "y =HIDDENR1 A"and A5: "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"and A6: " not x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
           sorry
        assume Given: " ex B be OrdinalORDINAL1M3 st (z =HIDDENR1 B & x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B)) &  not x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
        then obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A7: "z =HIDDENR1 B"and A8: "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B)"and A9: " not x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
           sorry
        assume A10: "y <>HIDDENR2 z"
        have "A c=ORDINAL1R1 B or B c=ORDINAL1R1 A"
           sorry
        then have A11: "A c<XBOOLE-0R2 B or B c<XBOOLE-0R2 A"
          using A4 A7 A10 sorry
        have "A c<XBOOLE-0R2 B implies  False "
        proof(rule impI)
          assume "A c<XBOOLE-0R2 B"
          then have "succORDINAL1K1 A c=ORDINAL1R1 B"
            using ordinal1_th_11 ordinal1_th_21 sorry
          then have "Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B)"
            using classes1_th_16 sorry
          thus " False "
            using A5 A9 sorry
        qed
        then have "succORDINAL1K1 B c=ORDINAL1R1 A"
          using ordinal1_th_11 ordinal1_th_21 A11 sorry
        then have "Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
          using classes1_th_16 sorry
        thus " False "
          using A6 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A12: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff ( ex y be objectHIDDENM1 st y inHIDDENR3 Z & ?P(y,x))"
      using tarski_sch_1 A3 sorry
    have " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Y"
    proof(rule ballI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      have A13: "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
        using classes1_th_15 sorry
      obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A14: " not (x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A) iff x inHIDDENR3 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A))"
        using A1 tarski_th_2 sorry
      have "x inHIDDENR3 Z"
        using A2 A14 sorry
      thus "A inTARSKIR2 Y"
        using A12 A13 A14 sorry
    qed "sorry"
    thus " False "
      using ordinal1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_18:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) implies Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) implies Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
    have "{}XBOOLE-0K1 c=ORDINAL1R1 A"
       sorry
    then have A2: "Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
      using classes1_th_16 sorry
    have A3: "Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 X} & X inTARSKIR2 {TARSKIK1 X}"
      using classes1_lm_1 tarski_def_1 sorry
    have Cut671: "Tarski-ClassCLASSES1K3(X,A) is-Tarski-Class-ofCLASSES1R1 X"
    proof-
      have "X inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & Tarski-ClassCLASSES1K3(X,A) be TarskiCLASSES1V2"
      proof(rule conjMI)
        show "X inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
          using A2 A3 sorry
        have A4: "Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A) =XBOOLE-0R4 (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) }))\\/XBOOLE-0K2 boolSETFAM-1K9 Tarski-ClassCLASSES1K3(X,A) /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Tarski-ClassCLASSES1K3(X,A))\<^esub> Tarski-ClassCLASSES1K1 X"
          using classes1_lm_1 sorry
        have "Tarski-ClassCLASSES1K1 X is-Tarski-Class-ofCLASSES1R1 X"
          using classes1_def_4 sorry
        then have A5: "Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
           sorry
        have "( for Z be setHIDDENM2 holds  for Y be setHIDDENM2 holds Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & Y c=TARSKIR1 Z implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)) & (( for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)) & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A) &  not (Y,Tarski-ClassCLASSES1K3(X,A))are-equipotentTARSKIR3 implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)))"
        proof(rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
          show " for Z be setHIDDENM2 holds  for Y be setHIDDENM2 holds Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & Y c=TARSKIR1 Z implies Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
          proof(rule ballI,rule ballI,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            fix Y assume [ty]: "Y be setHIDDENM2"
            assume A6: "Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & Y c=TARSKIR1 Z"
            have "Tarski-ClassCLASSES1K1 X is-Tarski-Class-ofCLASSES1R1 X"
              using classes1_def_4 sorry
            then have "Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
               sorry
            then have "Tarski-ClassCLASSES1K1 X be subset-closedCLASSES1V1"
               sorry
            then obtain y where 
              [ty]:"y be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X" and yDef:"y = Y"
              using A6 sorry
            have " ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & y c=TARSKIR1 v"
              using A6 sorry
            then have "Y inTARSKIR2 {u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v }"
               sorry
            then have "Y inTARSKIR2 ({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) })"
              using xboole_0_def_3 sorry
            thus "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
              using A1 A4 xboole_0_def_3 sorry
          qed "sorry"
          show " for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
          proof-
            have " for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
            proof(rule ballI,rule impI)
              fix Y assume [ty]: "Y be setHIDDENM2"
              assume "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
              then have "boolSETFAM-1K9 Y inTARSKIR2 {boolSETFAM-1K9 u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : u inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) }"
                 sorry
              then have "boolSETFAM-1K9 Y inTARSKIR2 ({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) })"
                using xboole_0_def_3 sorry
              thus "boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
                using A1 A4 xboole_0_def_3 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume A7: "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
            and A8: " not (Y,Tarski-ClassCLASSES1K3(X,A))are-equipotentTARSKIR3"
          have "Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
            using A7 xboole_1_th_1 sorry
          then have "(Y,Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3 or Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
            using A5 sorry
          thus "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
            using A1 A7 A8 classes1_th_10 card_1_th_24 sorry
        qed "sorry"
        thus "Tarski-ClassCLASSES1K3(X,A) be TarskiCLASSES1V2"
          using classes1_def_1 classes1_def_2 sorry
      qed
      thus "Tarski-ClassCLASSES1K3(X,A) is-Tarski-Class-ofCLASSES1R1 X"
        using classes1_def_3 sorry
    qed
    have "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K1 X & Tarski-ClassCLASSES1K1 X c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
    proof-
      show "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K1 X & Tarski-ClassCLASSES1K1 X c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
        using classes1_def_4 Cut671 sorry
    qed
    thus "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_19:
" for X be setHIDDENM2 holds  ex A be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  ex tVar2 be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K3(X,tVar2) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A1: "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
      using classes1_th_17 sorry
    show " ex tVar2 be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K3(X,tVar2) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
    proof(rule bexI[of _ "A"])
      show "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
        using A1 classes1_th_18 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_20:
" for X be setHIDDENM2 holds  ex A be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies Tarski-ClassCLASSES1K3(X,B) <>HIDDENR2 Tarski-ClassCLASSES1K1 X)"
proof-
  have " for X be setHIDDENM2 holds  ex tVar3 be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K3(X,tVar3) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 tVar3 implies  not Tarski-ClassCLASSES1K3(X,B) <>HIDDENR2 Tarski-ClassCLASSES1K1 X)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?P = "\<lambda>Lamb1. Tarski-ClassCLASSES1K3(X,Lamb1) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
    have A1: " ex A be OrdinalORDINAL1M3 st ?P(A)"
      using classes1_th_19 sorry
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A2: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
      using ordinal1_sch_1 A1 sorry
    show " ex tVar3 be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K3(X,tVar3) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 tVar3 implies  not Tarski-ClassCLASSES1K3(X,B) <>HIDDENR2 Tarski-ClassCLASSES1K1 X)"
    proof(rule bexI[of _ "A"],rule conjMI,rule ballI,rule impI)
      show "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
        using A2 sorry
      fix B assume [ty]: "B be OrdinalORDINAL1M3"
      assume "B inTARSKIR2 A"
      thus " not Tarski-ClassCLASSES1K3(X,B) <>HIDDENR2 Tarski-ClassCLASSES1K1 X"
        using A2 ordinal1_th_5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_21:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y <>HIDDENR2 X & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies ( ex A be OrdinalORDINAL1M3 st  not Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) & Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y <>HIDDENR2 X & Y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies ( ex tVar4 be OrdinalORDINAL1M3 st  not Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,tVar4) & Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 tVar4))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y <>HIDDENR2 X"
      and A2: "Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
    let ?P = "\<lambda>Lamb1. Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,Lamb1)"
    have " ex A be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
      using classes1_th_19 sorry
    then have A3: " ex A be OrdinalORDINAL1M3 st ?P(A)"
      using A2 sorry
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A4: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
      using ordinal1_sch_1 A3 sorry
    have A5: " not Y inTARSKIR2 {TARSKIK1 X}"
      using A1 tarski_def_1 sorry
    have A6: "Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 X}"
      using classes1_lm_1 sorry
    have "A be limit-ordinalORDINAL1V4 implies  False "
    proof(rule impI)
      assume "A be limit-ordinalORDINAL1V4"
      then have " ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)"
        using A4 A5 A6 classes1_th_13 sorry
      thus " False "
        using A4 ordinal1_th_5 sorry
    qed
    then obtain B where
      [ty]:"B be OrdinalORDINAL1M3" and 
      A7: "A =XBOOLE-0R4 succORDINAL1K1 B"
      using ordinal1_th_29 sorry
    show " ex tVar4 be OrdinalORDINAL1M3 st  not Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,tVar4) & Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 tVar4)"
    proof(rule bexI[of _ "B"])
      have " not A c=ORDINAL1R1 B"
        using A7 ordinal1_th_5 ordinal1_th_6 sorry
      thus " not Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,B) & Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B)"
        using A4 A7 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_22:
" for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies ( for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 implies Tarski-ClassCLASSES1K3(X,A) be epsilon-transitiveORDINAL1V1)"
proof-
  have " for X be setHIDDENM2 holds  not (X be epsilon-transitiveORDINAL1V1 &  not ( for A be OrdinalORDINAL1M3 holds  not ( not A <>HIDDENR2 {}XBOOLE-0K1 &  not Tarski-ClassCLASSES1K3(X,A) be epsilon-transitiveORDINAL1V1)))"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies Y c=TARSKIR1 X) implies ( for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 implies Tarski-ClassCLASSES1K3(X,A) be epsilon-transitiveORDINAL1V1)"
    proof(rule impI)
      assume A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies Y c=TARSKIR1 X"
      let ?OnP = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 implies Tarski-ClassCLASSES1K3(X,Lamb1) be epsilon-transitiveORDINAL1V1"
      have A2: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?OnP(B)) implies ?OnP(A)"
      proof-
        have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (B <>HIDDENR2 {}XBOOLE-0K1 implies Tarski-ClassCLASSES1K3(X,B) be epsilon-transitiveORDINAL1V1)) & A <>HIDDENR2 {}XBOOLE-0K1 implies Tarski-ClassCLASSES1K3(X,A) be epsilon-transitiveORDINAL1V1"
        proof(rule ballI,rule impMI ,rule impI)
          fix A assume [ty]: "A be OrdinalORDINAL1M3"
          assume A3: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?OnP(B)"
            and A4: "A <>HIDDENR2 {}XBOOLE-0K1"
          have " for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A) implies Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
          proof(rule ballI,rule impI)
            fix Y assume [ty]: "Y be setHIDDENM2"
            assume A5: "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,A)"
            have A6: "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
            proof(rule impI)
              assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
              then obtain B where
                [ty]:"B be OrdinalORDINAL1M3" and 
                A7: "A =XBOOLE-0R4 succORDINAL1K1 B"
                 sorry
              have A8: "B c=ORDINAL1R1 A"
                using ordinal1_th_6 ordinal1_def_2 A7 sorry
              have A9: "?OnP(B)"
                using A3 A7 ordinal1_th_6 sorry
              have A10: "Tarski-ClassCLASSES1K3(X,B) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                using A8 classes1_th_16 sorry
              have " not Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B) implies Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
              proof(rule impI)
                assume " not Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B)"
                then obtain Z where
                  [ty]:"Z be setHIDDENM2" and 
                  A11: "Z inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)"and A12: "Y c=TARSKIR1 Z or Y =XBOOLE-0R4 boolSETFAM-1K9 Z"
                  using A5 A7 classes1_th_10 sorry
                have A13: "Y =XBOOLE-0R4 boolSETFAM-1K9 Z implies Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                  using A7 A11 classes1_th_10 sorry
                have "Y c=TARSKIR1 Z implies Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                proof(rule impI)
                  assume A14: "Y c=TARSKIR1 Z"
                  show "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      obtain xx where 
                        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
                        using tarski_th_1 sorry
                      assume A15: "x inHIDDENR3 Y"
                      then have A16: "x inHIDDENR3 Z"
                        using A14 sorry
                      have A17: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
                      proof(rule impI)
                        assume "B =XBOOLE-0R4 {}XBOOLE-0K1"
                        then have "Tarski-ClassCLASSES1K3(X,B) =XBOOLE-0R4 {TARSKIK1 X}"
                          using classes1_lm_1 sorry
                        then have "Z =XBOOLE-0R4 X"
                          using A11 tarski_def_1 sorry
                        thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
                          using A7 A11 classes1_th_10 A1 A14 A15 sorry
                      qed
                      have "B <>HIDDENR2 {}XBOOLE-0K1 implies x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
                      proof(rule impI)
                        assume "B <>HIDDENR2 {}XBOOLE-0K1"
                        then have "Z c=TARSKIR1 Tarski-ClassCLASSES1K3(X,B)"
                          using A9 A11 ordinal1_def_2 sorry
                        then have "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,B)"
                          using A16 sorry
                        thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
                          using A10 sorry
                      qed
                      thus "x inHIDDENR3 Tarski-ClassCLASSES1K3(X,A)"
                        using A17 sorry
                    qed "sorry"
                    thus "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                      using tarski_def_3 sorry
                  qed
                qed
                thus "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                  using A12 A13 sorry
              qed
              thus "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                using A10 sorry
            qed
            have "( for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B) implies Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
            proof(rule impI)
              assume A18: " for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B"
              then have "A be limit-ordinalORDINAL1V4"
                using ordinal1_th_29 sorry
              then obtain B where
                [ty]:"B be OrdinalORDINAL1M3" and 
                A19: "B inTARSKIR2 A"and A20: "Y inTARSKIR2 Tarski-ClassCLASSES1K3(X,B)"
                using A4 A5 classes1_th_13 sorry
              have A21: "succORDINAL1K1 B <>HIDDENR2 A"
                using A18 sorry
              have A22: "Tarski-ClassCLASSES1K3(X,B) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B)"
                using classes1_th_15 sorry
              have A23: "succORDINAL1K1 B c<XBOOLE-0R2 A"
                using A19 ordinal1_th_21 A21 sorry
              have A24: "Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                using A19 ordinal1_th_21 classes1_th_16 sorry
              have "Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B) be epsilon-transitiveORDINAL1V1"
                using A3 A23 ordinal1_th_11 sorry
              then have "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 B)"
                using A20 A22 sorry
              thus "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
                using A24 sorry
            qed
            thus "Y c=TARSKIR1 Tarski-ClassCLASSES1K3(X,A)"
              using A6 sorry
          qed "sorry"
          thus "Tarski-ClassCLASSES1K3(X,A) be epsilon-transitiveORDINAL1V1"
            using ordinal1_def_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 implies Tarski-ClassCLASSES1K3(X,A) be epsilon-transitiveORDINAL1V1"
        using ordinal1_sch_2 A2 sorry
    qed
    thus " not (X be epsilon-transitiveORDINAL1V1 &  not ( for A be OrdinalORDINAL1M3 holds  not ( not A <>HIDDENR2 {}XBOOLE-0K1 &  not Tarski-ClassCLASSES1K3(X,A) be epsilon-transitiveORDINAL1V1)))"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_23:
" for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies Tarski-ClassCLASSES1K1 X be epsilon-transitiveORDINAL1V1"
proof-
  have " for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies Tarski-ClassCLASSES1K1 X be epsilon-transitiveORDINAL1V1"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A1: "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 X"
      using classes1_th_19 sorry
    have "Tarski-ClassCLASSES1K3(X,A) c=TARSKIR1 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
      using classes1_th_15 sorry
    then have A2: "Tarski-ClassCLASSES1K3(X,A) =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,succORDINAL1K1 A)"
      using A1 sorry
    assume "X be epsilon-transitiveORDINAL1V1"
    thus "Tarski-ClassCLASSES1K1 X be epsilon-transitiveORDINAL1V1"
      using A1 A2 classes1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_24:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
    have "boolSETFAM-1K9 Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
      using A1 classes1_th_3 sorry
    then have "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 (boolSETFAM-1K9 Y) & cardCARD-1K1 (boolSETFAM-1K9 Y) c=TARSKIR1 cardCARD-1K1 Tarski-ClassCLASSES1K1 X"
      using card_1_th_11 card_1_th_14 sorry
    thus "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_25:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies  not (Y,Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies  not (Y,Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
    then have "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X"
      using classes1_th_24 sorry
    then have "cardCARD-1K1 Y <>HIDDENR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 X"
       sorry
    thus " not (Y,Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_26:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (x inTARSKIR2 Tarski-ClassCLASSES1K1 X implies {TARSKIK1 x} inTARSKIR2 Tarski-ClassCLASSES1K1 X) & (x inTARSKIR2 Tarski-ClassCLASSES1K1 X & y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies {TARSKIK2 x,y } inTARSKIR2 Tarski-ClassCLASSES1K1 X)"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (x inTARSKIR2 Tarski-ClassCLASSES1K1 X implies {TARSKIK1 x} inTARSKIR2 Tarski-ClassCLASSES1K1 X) & (x inTARSKIR2 Tarski-ClassCLASSES1K1 X & y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies {TARSKIK2 x,y } inTARSKIR2 Tarski-ClassCLASSES1K1 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    show Z1: "x inTARSKIR2 Tarski-ClassCLASSES1K1 X implies {TARSKIK1 x} inTARSKIR2 Tarski-ClassCLASSES1K1 X"
    proof(rule impI)
      assume "x inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      then have "boolSETFAM-1K9 x inTARSKIR2 Tarski-ClassCLASSES1K1 X"
        using classes1_th_4 sorry
      thus "{TARSKIK1 x} inTARSKIR2 Tarski-ClassCLASSES1K1 X"
        using classes1_th_3 zfmisc_1_th_68 sorry
    qed
    assume A1: "x inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      and A2: "y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
    have A3: "{TARSKIK1 x} inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      using Z1 A1 sorry
    have "boolSETFAM-1K9 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
      using zfmisc_1_th_24 sorry
    then have A4: " not ({TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} },Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3"
      using A3 classes1_th_4 classes1_th_25 sorry
    have "x <>HIDDENR2 y implies {TARSKIK2 x,y } inTARSKIR2 Tarski-ClassCLASSES1K1 X"
    proof(rule impI)
      assume A5: "x <>HIDDENR2 y"
      have "({TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} },{TARSKIK2 x,y })are-equipotentTARSKIR3"
      proof-
        let ?C = "\<lambda>Lamb1. Lamb1 =HIDDENR1 {}XBOOLE-0K1"
        let ?f = "\<lambda>Lamb1. x"
        let ?g = "\<lambda>Lamb1. y"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A6: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} } & ( for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} } implies (?C(z) implies f .FUNCT-1K1 z =XBOOLE-0R4 ?f(z)) & ( not ?C(z) implies f .FUNCT-1K1 z =XBOOLE-0R4 ?g(z)))"
          using partfun1_sch_1 sorry
        have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} } & rngRELAT-1K2 f =HIDDENR1 {TARSKIK2 x,y })"
        proof(rule conjMI,rule conjMI)
          show "f be one-to-oneFUNCT-1V2"
          proof-
            have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f implies  not (f .FUNCT-1K1 x1 =HIDDENR1 f .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix x1 assume [ty]: "x1 be objectHIDDENM1"
              fix x2 assume [ty]: "x2 be objectHIDDENM1"
              assume A7: "x1 inHIDDENR3 domRELAT-1K1 f"
                and A8: "x2 inHIDDENR3 domRELAT-1K1 f"
              have A9: "x2 =HIDDENR1 {}XBOOLE-0K1 or x2 =HIDDENR1 {TARSKIK1 x}"
                using A6 A8 tarski_def_2 sorry
              have A10: "x1 =HIDDENR1 {}XBOOLE-0K1 implies f .FUNCT-1K1 x1 =XBOOLE-0R4 x"
                using A6 A7 sorry
              have "x1 <>HIDDENR2 {}XBOOLE-0K1 implies f .FUNCT-1K1 x1 =XBOOLE-0R4 y"
                using A6 A7 sorry
              thus " not (f .FUNCT-1K1 x1 =HIDDENR1 f .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
                using A5 A6 A7 A8 A9 A10 tarski_def_2 sorry
            qed "sorry"
            thus "f be one-to-oneFUNCT-1V2"
              using funct_1_def_4 sorry
          qed
          show "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
            using A6 sorry
          have "rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK2 x,y } & {TARSKIK2 x,y } c=TARSKIR1 rngRELAT-1K2 f"
          proof(rule conjMI)
            show "rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK2 x,y }"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 f implies z inHIDDENR3 {TARSKIK2 x,y }"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 rngFUNCT-1K2 f"
                then have " ex u be objectHIDDENM1 st u inHIDDENR3 domRELAT-1K1 f & z =HIDDENR1 f .FUNCT-1K1 u"
                  using funct_1_def_3 sorry
                then have "z =HIDDENR1 x or z =HIDDENR1 y"
                  using A6 sorry
                thus "z inHIDDENR3 {TARSKIK2 x,y }"
                  using tarski_def_2 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK2 x,y }"
                using tarski_def_3 sorry
            qed
            have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z inHIDDENR3 rngRELAT-1K2 f"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 {TARSKIK2 x,y }"
              then have A11: "z =HIDDENR1 x or z =HIDDENR1 y"
                using tarski_def_2 sorry
              have A12: "{}XBOOLE-0K1 inTARSKIR2 domRELAT-1K1 f"
                using A6 tarski_def_2 sorry
              have A13: "{TARSKIK1 x} inTARSKIR2 domRELAT-1K1 f"
                using A6 tarski_def_2 sorry
              have A14: "f .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 x"
                using A6 A12 sorry
              have "f .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 y"
                using A6 A13 sorry
              thus "z inHIDDENR3 rngRELAT-1K2 f"
                using A11 A12 A13 A14 funct_1_def_3 sorry
            qed "sorry"
            thus "{TARSKIK2 x,y } c=TARSKIR1 rngRELAT-1K2 f"
              using tarski_def_3 sorry
          qed
          thus "rngRELAT-1K2 f =HIDDENR1 {TARSKIK2 x,y }"
            using xboole_0_def_10 sorry
        qed
        thus "({TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} },{TARSKIK2 x,y })are-equipotentTARSKIR3"
          using bexI[of _ "f"] wellord2_def_4 sorry
      qed
      then have A15: " not ({TARSKIK2 x,y },Tarski-ClassCLASSES1K1 X)are-equipotentTARSKIR3"
        using A4 wellord2_th_15 sorry
      have "{TARSKIK2 x,y } c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
        using A1 A2 zfmisc_1_th_32 sorry
      thus "{TARSKIK2 x,y } inTARSKIR2 Tarski-ClassCLASSES1K1 X"
        using A15 classes1_th_5 sorry
    qed
    thus "{TARSKIK2 x,y } inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      using A3 enumset1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_27:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Tarski-ClassCLASSES1K1 X & y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies [TARSKIK4 x,y ] inHIDDENR3 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Tarski-ClassCLASSES1K1 X & y inTARSKIR2 Tarski-ClassCLASSES1K1 X implies [TARSKIK4 x,y ] inHIDDENR3 Tarski-ClassCLASSES1K1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume "x inTARSKIR2 Tarski-ClassCLASSES1K1 X & y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
    then have "{TARSKIK2 x,y } inTARSKIR2 Tarski-ClassCLASSES1K1 X & {TARSKIK1 x} inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      using classes1_th_26 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 Tarski-ClassCLASSES1K1 X"
      using classes1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_28:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X & Z c=TARSKIR1 Tarski-ClassCLASSES1K1 X implies [:ZFMISC-1K2 Y,Z :] c=RELAT-1R2 Tarski-ClassCLASSES1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X & Z c=TARSKIR1 Tarski-ClassCLASSES1K1 X implies [:ZFMISC-1K2 Y,Z :] c=RELAT-1R2 Tarski-ClassCLASSES1K1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X & Z c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :] implies [TARSKIK4 x,y ] inHIDDENR3 Tarski-ClassCLASSES1K1 X"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
      then have "x inHIDDENR3 Y & y inHIDDENR3 Z"
        using zfmisc_1_th_87 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 Tarski-ClassCLASSES1K1 X"
        using A1 classes1_th_27 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 Y,Z :] c=RELAT-1R2 Tarski-ClassCLASSES1K1 X"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef classes1_def_6 ("RankCLASSES1K4  _ " [300]300 ) where
  mlet "A be OrdinalORDINAL1M3"
"func RankCLASSES1K4 A \<rightarrow> setHIDDENM2 means
  \<lambda>it.  ex L be SequenceORDINAL1M4 st (((it =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  ex L be SequenceORDINAL1M4 st (((it =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C))))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. boolSETFAM-1K9 Lamb2"
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 (rngFUNCT-1K2 Lamb2)"
        have "( ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) & ( ex L be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
          using ordinal2_sch_7 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C))))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((it1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))) & ( ex L be SequenceORDINAL1M4 st (((it2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))) implies it1 =HIDDENR1 it2"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C))))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. boolSETFAM-1K9 Lamb2"
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 (rngFUNCT-1K2 Lamb2)"
        have "( ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) & ( ex L be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
          using ordinal2_sch_7 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C)))))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 boolSETFAM-1K9 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 (L  |RELAT-1K8 C))))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma classes1_lm_2:
"RankCLASSES1K4 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1 & (( for A be OrdinalORDINAL1M3 holds RankCLASSES1K4 (succORDINAL1K1 A) =XBOOLE-0R4 boolSETFAM-1K9 RankCLASSES1K4 A) & ( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds ((A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & domRELAT-1K1 L =XBOOLE-0R4 A) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 RankCLASSES1K4 B) implies RankCLASSES1K4 A =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L)))"
proof(rule conjMI,rule conjMI)
  let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. boolSETFAM-1K9 Lamb2"
  let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 (rngFUNCT-1K2 Lamb2)"
  have A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 RankCLASSES1K4 A iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C)))"
    using classes1_def_6 sorry
  show "RankCLASSES1K4 (0ORDINAL1K5) =XBOOLE-0R4 {}XBOOLE-0K1"
    using ordinal2_sch_8 A1 sorry
  show " for A be OrdinalORDINAL1M3 holds RankCLASSES1K4 (succORDINAL1K1 A) =XBOOLE-0R4 boolSETFAM-1K9 RankCLASSES1K4 A"
    using ordinal2_sch_9 A1 sorry
  show " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds ((A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & domRELAT-1K1 L =XBOOLE-0R4 A) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 RankCLASSES1K4 B) implies RankCLASSES1K4 A =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L)"
  proof-
    have " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & (domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 RankCLASSES1K4 B)) implies RankCLASSES1K4 A =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L)"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      fix L assume [ty]: "L be SequenceORDINAL1M4"
      assume A2: "A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4"
        and A3: "domRELAT-1K1 L =XBOOLE-0R4 A"
        and A4: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 RankCLASSES1K4 B"
      show "RankCLASSES1K4 A =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L)"
        using ordinal2_sch_10 A1 A2 A3 A4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed

mtheorem classes1_th_29:
"RankCLASSES1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
  using classes1_lm_2 sorry

mtheorem classes1_th_30:
" for A be OrdinalORDINAL1M3 holds RankCLASSES1K4 (succORDINAL1K1 A) =XBOOLE-0R4 boolSETFAM-1K9 RankCLASSES1K4 A"
  using classes1_lm_2 sorry

mtheorem classes1_th_31:
" for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies ( for x be setHIDDENM2 holds x inTARSKIR2 RankCLASSES1K4 A iff ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 RankCLASSES1K4 B))"
proof-
  have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies ( for x be setHIDDENM2 holds (x inTARSKIR2 RankCLASSES1K4 A implies ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 RankCLASSES1K4 B)) & (( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 RankCLASSES1K4 B) implies x inTARSKIR2 RankCLASSES1K4 A))"
  proof(rule ballI,rule impI,rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4"
    obtain L where
      [ty]:"L be SequenceORDINAL1M4" and 
      A2: "domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 RankCLASSES1K4 B)"
      using ordinal2_sch_2 sorry
    have A3: "RankCLASSES1K4 A =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 L)"
      using A1 A2 classes1_lm_2 sorry
    fix x assume [ty]: "x be setHIDDENM2"
    show "x inTARSKIR2 RankCLASSES1K4 A implies ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 RankCLASSES1K4 B)"
    proof-
      have "x inTARSKIR2 RankCLASSES1K4 A implies ( ex tVar6 be OrdinalORDINAL1M3 st tVar6 inTARSKIR2 A & x inTARSKIR2 RankCLASSES1K4 tVar6)"
      proof(rule impI)
        assume "x inTARSKIR2 RankCLASSES1K4 A"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A4: "x inTARSKIR2 Y"and A5: "Y inTARSKIR2 rngFUNCT-1K2 L"
          using A3 tarski_def_4 sorry
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A6: "y inHIDDENR3 domRELAT-1K1 L"and A7: "Y =XBOOLE-0R4 L .FUNCT-1K1 y"
          using A5 funct_1_def_3 sorry
        have 
          [ty]:"y be OrdinalORDINAL1M3"
          using A6 sorry
        show " ex tVar6 be OrdinalORDINAL1M3 st tVar6 inTARSKIR2 A & x inTARSKIR2 RankCLASSES1K4 tVar6"
        proof(rule bexI[of _ "y"])
          show "y inTARSKIR2 A & x inTARSKIR2 RankCLASSES1K4 y"
            using A2 A4 A6 A7 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex B be OrdinalORDINAL1M3 st B inTARSKIR2 A & x inTARSKIR2 RankCLASSES1K4 B"
    then obtain B where
      [ty]:"B be OrdinalORDINAL1M3" and 
      A8: "B inTARSKIR2 A"and A9: "x inTARSKIR2 RankCLASSES1K4 B"
       sorry
    have "L .FUNCT-1K1 B =XBOOLE-0R4 RankCLASSES1K4 B"
      using A2 A8 sorry
    then have "RankCLASSES1K4 B inTARSKIR2 rngFUNCT-1K2 L"
      using A2 A8 funct_1_def_3 sorry
    thus "x inTARSKIR2 RankCLASSES1K4 A"
      using A3 A9 tarski_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_32:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 A iff X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds (X c=TARSKIR1 RankCLASSES1K4 A implies X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)) & (X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A) implies X c=TARSKIR1 RankCLASSES1K4 A)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "X c=TARSKIR1 RankCLASSES1K4 A implies X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
    proof(rule impI)
      assume "X c=TARSKIR1 RankCLASSES1K4 A"
      then have "X inTARSKIR2 boolSETFAM-1K9 RankCLASSES1K4 A"
         sorry
      thus "X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
        using classes1_lm_2 sorry
    qed
    assume "X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
    then have "X inTARSKIR2 boolSETFAM-1K9 RankCLASSES1K4 A"
      using classes1_lm_2 sorry
    thus "X c=TARSKIR1 RankCLASSES1K4 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_cl_2:
  mlet "A be OrdinalORDINAL1M3"
"cluster RankCLASSES1K4 A as-term-is epsilon-transitiveORDINAL1V1"
proof
(*coherence*)
  show "RankCLASSES1K4 A be epsilon-transitiveORDINAL1V1"
  proof-
    let ?P = "\<lambda>Lamb1.  for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 Lamb1 implies X c=TARSKIR1 RankCLASSES1K4 Lamb1"
    have A1: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 B implies X c=TARSKIR1 RankCLASSES1K4 B)) implies ( for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 A implies X c=TARSKIR1 RankCLASSES1K4 A)"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A2: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)"
        fix X assume [ty]: "X be setHIDDENM2"
        assume A3: "X inTARSKIR2 RankCLASSES1K4 A"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 RankCLASSES1K4 A"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A4: "x inHIDDENR3 X"
          obtain xx where 
            [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
            using tarski_th_1 sorry
          have A5: "A be limit-ordinalORDINAL1V4 implies x inHIDDENR3 RankCLASSES1K4 A"
          proof(rule impI)
            assume A6: "A be limit-ordinalORDINAL1V4"
            then obtain B where
              [ty]:"B be OrdinalORDINAL1M3" and 
              A7: "B inTARSKIR2 A"and A8: "X inTARSKIR2 RankCLASSES1K4 B"
              using A3 classes1_lm_2 classes1_th_31 sorry
            have "X c=TARSKIR1 RankCLASSES1K4 B"
              using A2 A7 A8 sorry
            thus "x inHIDDENR3 RankCLASSES1K4 A"
              using A4 A6 A7 classes1_th_31 sorry
          qed
          have " not A be limit-ordinalORDINAL1V4 implies x inHIDDENR3 RankCLASSES1K4 A"
          proof(rule impI)
            assume " not A be limit-ordinalORDINAL1V4"
            then obtain B where
              [ty]:"B be OrdinalORDINAL1M3" and 
              A9: "A =XBOOLE-0R4 succORDINAL1K1 B"
              using ordinal1_th_29 sorry
            have "X c=TARSKIR1 RankCLASSES1K4 B"
              using A3 A9 classes1_th_32 sorry
            then have "xx c=TARSKIR1 RankCLASSES1K4 B"
              using A2 A4 A9 ordinal1_th_6 sorry
            thus "x inHIDDENR3 RankCLASSES1K4 A"
              using A9 classes1_th_32 sorry
          qed
          thus "x inHIDDENR3 RankCLASSES1K4 A"
            using A5 sorry
        qed "sorry"
        thus "X c=TARSKIR1 RankCLASSES1K4 A"
          using tarski_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have Cut1094: " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal1_sch_2 A1 sorry
    have " for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 A implies X c=TARSKIR1 RankCLASSES1K4 A"
    proof-
      show " for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 A implies X c=TARSKIR1 RankCLASSES1K4 A"
        using Cut1094 sorry
    qed
    thus "RankCLASSES1K4 A be epsilon-transitiveORDINAL1V1"
      using ordinal1_def_2 sorry
  qed
qed "sorry"

mtheorem classes1_th_33:
" for A be OrdinalORDINAL1M3 holds RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)"
proof-
  have " for A be OrdinalORDINAL1M3 holds RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "RankCLASSES1K4 A inTARSKIR2 boolSETFAM-1K9 RankCLASSES1K4 A"
      using zfmisc_1_def_1 sorry
    then have "RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
      using classes1_lm_2 sorry
    thus "RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_34:
" for A be OrdinalORDINAL1M3 holds unionTARSKIK3 RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds unionTARSKIK3 RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 RankCLASSES1K4 A implies x inHIDDENR3 RankCLASSES1K4 A"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 unionTARSKIK3 RankCLASSES1K4 A"
      then obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: "x inHIDDENR3 X"and A2: "X inTARSKIR2 RankCLASSES1K4 A"
        using tarski_def_4 sorry
      have "X c=TARSKIR1 RankCLASSES1K4 A"
        using A2 ordinal1_def_2 sorry
      thus "x inHIDDENR3 RankCLASSES1K4 A"
        using A1 sorry
    qed "sorry"
    thus "unionTARSKIK3 RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 A"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_35:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X inTARSKIR2 RankCLASSES1K4 A implies unionTARSKIK3 X inTARSKIR2 RankCLASSES1K4 A"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X inTARSKIR2 RankCLASSES1K4 A implies unionTARSKIK3 X inTARSKIR2 RankCLASSES1K4 A"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "X inTARSKIR2 RankCLASSES1K4 A"
    have A2: "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies unionTARSKIK3 X inTARSKIR2 RankCLASSES1K4 A"
    proof(rule impI)
      assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
      then obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A3: "A =XBOOLE-0R4 succORDINAL1K1 B"
         sorry
      have A4: "unionTARSKIK3 X c=TARSKIR1 unionTARSKIK3 RankCLASSES1K4 B"
        using zfmisc_1_th_77 A1 A3 classes1_th_32 sorry
      have "unionTARSKIK3 RankCLASSES1K4 B c=TARSKIR1 RankCLASSES1K4 B"
        using classes1_th_34 sorry
      thus "unionTARSKIK3 X inTARSKIR2 RankCLASSES1K4 A"
        using A3 classes1_th_32 A4 xboole_1_th_1 sorry
    qed
    have "A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B) implies unionTARSKIK3 X inTARSKIR2 RankCLASSES1K4 A"
    proof(rule impMI ,rule impI)
      assume A5: "A <>HIDDENR2 {}XBOOLE-0K1"
        and A6: " for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B"
      have A7: "A be limit-ordinalORDINAL1V4"
        using A6 ordinal1_th_29 sorry
      then obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A8: "B inTARSKIR2 A"and A9: "X inTARSKIR2 RankCLASSES1K4 B"
        using A1 A5 classes1_th_31 sorry
      have A10: "unionTARSKIK3 X c=TARSKIR1 unionTARSKIK3 RankCLASSES1K4 B"
        using zfmisc_1_th_77 A9 ordinal1_def_2 sorry
      have A11: "unionTARSKIK3 RankCLASSES1K4 B c=TARSKIR1 RankCLASSES1K4 B"
        using classes1_th_34 sorry
      have "succORDINAL1K1 B <>HIDDENR2 A"
        using A6 sorry
      then have A12: "succORDINAL1K1 B c<XBOOLE-0R2 A"
        using A8 ordinal1_th_21 sorry
      have A13: "unionTARSKIK3 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 B)"
        using A11 classes1_th_32 A10 xboole_1_th_1 sorry
      have "succORDINAL1K1 B inTARSKIR2 A"
        using A12 ordinal1_th_11 sorry
      thus "unionTARSKIK3 X inTARSKIR2 RankCLASSES1K4 A"
        using A7 A13 classes1_th_31 sorry
    qed
    thus "unionTARSKIK3 X inTARSKIR2 RankCLASSES1K4 A"
      using A1 A2 classes1_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_36:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B iff RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A inTARSKIR2 B implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B) & (RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B &  not A inTARSKIR2 B implies  False )"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?OnP = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 Lamb2 implies RankCLASSES1K4 Lamb1 inTARSKIR2 RankCLASSES1K4 Lamb2"
    have A1: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
    proof(rule ballI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      let ?P = "\<lambda>Lamb1. ?OnP(A,Lamb1)"
      have A2: " for B be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?P(C)) implies ?P(B)"
      proof-
        have " for B be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies (A inTARSKIR2 C implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 C)) & A inTARSKIR2 B implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
        proof(rule ballI,rule impMI ,rule impI)
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          assume A3: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?OnP(A,C)"
            and A4: "A inTARSKIR2 B"
          have A5: "( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C) implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
          proof(rule impI)
            assume Given: " ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C"
            then obtain C where
              [ty]:"C be OrdinalORDINAL1M3" and 
              A6: "B =XBOOLE-0R4 succORDINAL1K1 C"
               sorry
            have A7: "A inTARSKIR2 C implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 C"
              using A3 A6 ordinal1_th_6 sorry
            have " not A inTARSKIR2 C implies RankCLASSES1K4 A =XBOOLE-0R4 RankCLASSES1K4 C"
            proof(rule impI)
              assume A8: " not A inTARSKIR2 C"
              have "A c=ORDINAL1R1 C & A <>HIDDENR2 C iff A c<XBOOLE-0R2 C"
                 sorry
              thus "RankCLASSES1K4 A =XBOOLE-0R4 RankCLASSES1K4 C"
                using A4 A6 A8 ordinal1_th_11 ordinal1_th_22 sorry
            qed
            then have "RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 C"
              using A7 ordinal1_def_2 sorry
            thus "RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
              using A6 classes1_th_32 sorry
          qed
          have "( for C be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 C) implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
          proof(rule impI)
            assume A9: " for C be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 C"
            then have A10: "B be limit-ordinalORDINAL1V4"
              using ordinal1_th_29 sorry
            have A11: "B <>HIDDENR2 succORDINAL1K1 A"
              using A9 sorry
            have "succORDINAL1K1 A c<XBOOLE-0R2 B"
              using A11 A4 ordinal1_th_21 sorry
            then have A12: "succORDINAL1K1 A inTARSKIR2 B"
              using ordinal1_th_11 sorry
            have "RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
              using classes1_th_32 sorry
            thus "RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
              using A10 A12 classes1_th_31 sorry
          qed
          thus "RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
            using A5 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
        using ordinal1_sch_2 A2 sorry
    qed "sorry"
    thus "A inTARSKIR2 B implies RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
       sorry
    assume A13: "RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
      and A14: " not A inTARSKIR2 B"
    have "B inTARSKIR2 A or B =XBOOLE-0R4 A"
      using A14 ordinal1_th_14 sorry
    thus " False "
      using A1 A13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_37:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B iff RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A c=ORDINAL1R1 B implies RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 B) & (RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 B &  not A c=ORDINAL1R1 B implies  False )"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    show "A c=ORDINAL1R1 B implies RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 B"
    proof(rule impI)
      have A1: "A c<XBOOLE-0R2 B iff A c=ORDINAL1R1 B & A <>HIDDENR2 B"
         sorry
      assume "A c=ORDINAL1R1 B"
      then have "RankCLASSES1K4 A =XBOOLE-0R4 RankCLASSES1K4 B or RankCLASSES1K4 A inTARSKIR2 RankCLASSES1K4 B"
        using classes1_th_36 A1 ordinal1_th_11 sorry
      thus "RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 B"
        using ordinal1_def_2 sorry
    qed
    assume A2: "RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 B"
      and A3: " not A c=ORDINAL1R1 B"
    have "B inTARSKIR2 A"
      using A3 ordinal1_th_16 sorry
    thus " False "
      using A2 ordinal1_th_5 classes1_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_38:
" for A be OrdinalORDINAL1M3 holds A c=TARSKIR1 RankCLASSES1K4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds A c=TARSKIR1 RankCLASSES1K4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. Lamb1 c=TARSKIR1 RankCLASSES1K4 Lamb1"
    have A1: "?P(0ORDINAL1K5)"
      using xboole_1_th_2 sorry
    have A2: " for B be OrdinalORDINAL1M3 holds ?P(B) implies ?P(succORDINAL1K1 B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds B c=TARSKIR1 RankCLASSES1K4 B implies succORDINAL1K1 B c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 B)"
      proof(rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume "B c=TARSKIR1 RankCLASSES1K4 B"
        then have "B inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 B)"
          using classes1_th_32 sorry
        then have "B c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 B) & {TARSKIK1 B} c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 B)"
          using ordinal1_def_2 zfmisc_1_th_31 sorry
        thus "succORDINAL1K1 B c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 B)"
          using xboole_1_th_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0ORDINAL1K5 & (A be limit-ordinalORDINAL1V4 & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies B c=TARSKIR1 RankCLASSES1K4 B)) implies A c=TARSKIR1 RankCLASSES1K4 A"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume "A <>HIDDENR2 0ORDINAL1K5"
          and A4: "A be limit-ordinalORDINAL1V4"
          and A5: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies B c=TARSKIR1 RankCLASSES1K4 B"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 RankCLASSES1K4 A"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A6: "x inHIDDENR3 A"
          then obtain B where 
            [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
             sorry
          have A7: "B c=TARSKIR1 RankCLASSES1K4 B"
            using A5 A6 sorry
          have A8: "succORDINAL1K1 B c=ORDINAL1R1 A"
            using A4 A6 ordinal1_th_28 ordinal1_def_2 sorry
          have A9: "B inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 B)"
            using A7 classes1_th_32 sorry
          have "RankCLASSES1K4 (succORDINAL1K1 B) c=TARSKIR1 RankCLASSES1K4 A"
            using A8 classes1_th_37 sorry
          thus "x inHIDDENR3 RankCLASSES1K4 A"
            using A9 sorry
        qed "sorry"
        thus "?P(A)"
          using tarski_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for B be OrdinalORDINAL1M3 holds ?P(B)"
      using ordinal2_sch_1 A1 A2 A3 sorry
    thus "A c=TARSKIR1 RankCLASSES1K4 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_39:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 A implies  not (X,RankCLASSES1K4 A)are-equipotentTARSKIR3 & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 RankCLASSES1K4 A"
proof(rule ballI,rule ballI,rule impI)
  let ?OnP = "\<lambda>Lamb1.  for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 Lamb1 implies  not (X,RankCLASSES1K4 Lamb1)are-equipotentTARSKIR3"
  have A1: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?OnP(B)) implies ?OnP(A)"
  proof-
    have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 B implies  not (X,RankCLASSES1K4 B)are-equipotentTARSKIR3)) implies ( for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 A implies  not (X,RankCLASSES1K4 A)are-equipotentTARSKIR3)"
    proof(rule ballI,rule impI,rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A2: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?OnP(B)"
      fix X assume [ty]: "X be setHIDDENM2"
      assume A3: "X inTARSKIR2 RankCLASSES1K4 A"
      have A4: "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies  not (X,RankCLASSES1K4 A)are-equipotentTARSKIR3"
      proof(rule impI)
        assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
        then obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A5: "A =XBOOLE-0R4 succORDINAL1K1 B"
           sorry
        have A6: "B c=ORDINAL1R1 A"
          using A5 ordinal1_th_6 ordinal1_def_2 sorry
        have A7: "RankCLASSES1K4 (succORDINAL1K1 B) =XBOOLE-0R4 boolSETFAM-1K9 RankCLASSES1K4 B"
          using classes1_lm_2 sorry
        then have A8: " not (RankCLASSES1K4 B,RankCLASSES1K4 A)are-equipotentTARSKIR3"
          using A5 card_1_th_13 sorry
        have "RankCLASSES1K4 B c=TARSKIR1 RankCLASSES1K4 A"
          using A6 classes1_th_37 sorry
        thus " not (X,RankCLASSES1K4 A)are-equipotentTARSKIR3"
          using A3 A5 A7 A8 card_1_th_24 sorry
      qed
      have "A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B) implies  not (X,RankCLASSES1K4 A)are-equipotentTARSKIR3"
      proof(rule impMI ,rule impI)
        assume A9: "A <>HIDDENR2 {}XBOOLE-0K1"
          and A10: " for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B"
        have "A be limit-ordinalORDINAL1V4"
          using A10 ordinal1_th_29 sorry
        then obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A11: "B inTARSKIR2 A"and A12: "X inTARSKIR2 RankCLASSES1K4 B"
          using A3 A9 classes1_th_31 sorry
        have A13: " not (X,RankCLASSES1K4 B)are-equipotentTARSKIR3 & X c=TARSKIR1 RankCLASSES1K4 B"
          using A2 A11 A12 ordinal1_def_2 sorry
        have "RankCLASSES1K4 B c=TARSKIR1 RankCLASSES1K4 A"
          using A11 classes1_th_36 ordinal1_def_2 sorry
        thus " not (X,RankCLASSES1K4 A)are-equipotentTARSKIR3"
          using A13 card_1_th_24 sorry
      qed
      thus " not (X,RankCLASSES1K4 A)are-equipotentTARSKIR3"
        using A3 A4 classes1_lm_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A14: " for A be OrdinalORDINAL1M3 holds ?OnP(A)"
    using ordinal1_sch_2 A1 sorry
  fix A assume [ty]: "A be OrdinalORDINAL1M3"
  fix X assume [ty]: "X be setHIDDENM2"
  assume A15: "X inTARSKIR2 RankCLASSES1K4 A"
  have A16: "cardCARD-1K1 X c=TARSKIR1 cardCARD-1K1 RankCLASSES1K4 A"
    using A15 card_1_th_11 ordinal1_def_2 sorry
  have "cardCARD-1K1 X <>HIDDENR2 cardCARD-1K1 RankCLASSES1K4 A"
    using A14 A15 card_1_th_5 sorry
  thus " not (X,RankCLASSES1K4 A)are-equipotentTARSKIR3 & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 RankCLASSES1K4 A"
    using A14 A15 A16 card_1_th_3 sorry
qed "sorry"

mtheorem classes1_th_40:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 A iff boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds (X c=TARSKIR1 RankCLASSES1K4 A implies boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)) & (boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A) implies X c=TARSKIR1 RankCLASSES1K4 A)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "X c=TARSKIR1 RankCLASSES1K4 A implies boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)"
    proof(rule impI)
      assume A1: "X c=TARSKIR1 RankCLASSES1K4 A"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 boolSETFAM-1K9 X implies x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        assume "x inHIDDENR3 boolSETFAM-1K9 X"
        then have A2: "xx c=TARSKIR1 RankCLASSES1K4 A"
          using A1 sorry
        have "RankCLASSES1K4 (succORDINAL1K1 A) =XBOOLE-0R4 boolSETFAM-1K9 RankCLASSES1K4 A"
          using classes1_lm_2 sorry
        thus "x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A)"
          using A2 sorry
      qed "sorry"
      thus "boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)"
        using tarski_def_3 sorry
    qed
    assume A3: "boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 RankCLASSES1K4 A"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      then have "{TARSKIK1 x} c=TARSKIR1 X"
        using zfmisc_1_th_31 sorry
      then have A4: "{TARSKIK1 x} inTARSKIR2 boolSETFAM-1K9 X"
         sorry
      have "RankCLASSES1K4 (succORDINAL1K1 A) =XBOOLE-0R4 boolSETFAM-1K9 RankCLASSES1K4 A & x inHIDDENR3 {TARSKIK1 x}"
        using classes1_lm_2 tarski_def_1 sorry
      thus "x inHIDDENR3 RankCLASSES1K4 A"
        using A3 A4 sorry
    qed "sorry"
    thus "X c=TARSKIR1 RankCLASSES1K4 A"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 Y & Y inTARSKIR2 RankCLASSES1K4 A implies X inTARSKIR2 RankCLASSES1K4 A"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 Y & Y inTARSKIR2 RankCLASSES1K4 A implies X inTARSKIR2 RankCLASSES1K4 A"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "X c=TARSKIR1 Y"
      and A2: "Y inTARSKIR2 RankCLASSES1K4 A"
    have A3: "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies X inTARSKIR2 RankCLASSES1K4 A"
    proof(rule impI)
      assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
      then obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A4: "A =XBOOLE-0R4 succORDINAL1K1 B"
         sorry
      have A5: "RankCLASSES1K4 (succORDINAL1K1 B) =XBOOLE-0R4 boolSETFAM-1K9 RankCLASSES1K4 B"
        using classes1_lm_2 sorry
      then have "X c=TARSKIR1 RankCLASSES1K4 B"
        using A1 A2 A4 xboole_1_th_1 sorry
      thus "X inTARSKIR2 RankCLASSES1K4 A"
        using A4 A5 sorry
    qed
    have "( for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B) implies X inTARSKIR2 RankCLASSES1K4 A"
    proof(rule impI)
      assume A6: " for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B"
      then have A7: "A be limit-ordinalORDINAL1V4"
        using ordinal1_th_29 sorry
      then obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A8: "B inTARSKIR2 A"and A9: "Y inTARSKIR2 RankCLASSES1K4 B"
        using A2 classes1_lm_2 classes1_th_31 sorry
      have "Y c=TARSKIR1 RankCLASSES1K4 B"
        using A9 ordinal1_def_2 sorry
      then have A10: "X c=TARSKIR1 RankCLASSES1K4 B"
        using A1 sorry
      have A11: "boolSETFAM-1K9 RankCLASSES1K4 B =XBOOLE-0R4 RankCLASSES1K4 (succORDINAL1K1 B)"
        using classes1_lm_2 sorry
      have "succORDINAL1K1 B inTARSKIR2 A"
        using A6 A8 ordinal1_th_28 ordinal1_th_29 sorry
      thus "X inTARSKIR2 RankCLASSES1K4 A"
        using A7 A10 A11 classes1_th_31 sorry
    qed
    thus "X inTARSKIR2 RankCLASSES1K4 A"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_42:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X inTARSKIR2 RankCLASSES1K4 A iff boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds (X inTARSKIR2 RankCLASSES1K4 A implies boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)) & (boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A) implies X inTARSKIR2 RankCLASSES1K4 A)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "X inTARSKIR2 RankCLASSES1K4 A implies boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
    proof(rule impI)
      assume A1: "X inTARSKIR2 RankCLASSES1K4 A"
      have "boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 A"
        using A1 classes1_th_41 sorry
      thus "boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
        using classes1_th_32 sorry
    qed
    assume "boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
    then have "X inTARSKIR2 boolSETFAM-1K9 X & boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 A"
      using classes1_th_32 zfmisc_1_def_1 sorry
    thus "X inTARSKIR2 RankCLASSES1K4 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_43:
" for x be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds x inTARSKIR2 RankCLASSES1K4 A iff {TARSKIK1 x} inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
proof-
  have " for x be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds  not (x inTARSKIR2 RankCLASSES1K4 A &  not {TARSKIK1 x} inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)) &  not ({TARSKIK1 x} inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A) &  not x inTARSKIR2 RankCLASSES1K4 A)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "x inTARSKIR2 RankCLASSES1K4 A iff {TARSKIK1 x} c=TARSKIR1 RankCLASSES1K4 A"
      using zfmisc_1_th_31 sorry
    thus " not (x inTARSKIR2 RankCLASSES1K4 A &  not {TARSKIK1 x} inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)) &  not ({TARSKIK1 x} inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A) &  not x inTARSKIR2 RankCLASSES1K4 A)"
      using classes1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_44:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A iff {TARSKIK2 x,y } inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds  not ((x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A) &  not {TARSKIK2 x,y } inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)) &  not ({TARSKIK2 x,y } inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A) &  not (x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A))"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A iff {TARSKIK2 x,y } c=TARSKIR1 RankCLASSES1K4 A"
      using zfmisc_1_th_32 sorry
    thus " not ((x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A) &  not {TARSKIK2 x,y } inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)) &  not ({TARSKIK2 x,y } inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A) &  not (x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A))"
      using classes1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_45:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A iff [TARSKIK4 x,y ] inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 (succORDINAL1K1 A))"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds  not ((x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A) &  not [TARSKIK4 x,y ] inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 (succORDINAL1K1 A))) &  not ([TARSKIK4 x,y ] inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 (succORDINAL1K1 A)) &  not (x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A))"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have A1: "x inTARSKIR2 RankCLASSES1K4 A iff {TARSKIK1 x} inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
      using classes1_th_43 sorry
    have "x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A iff {TARSKIK2 x,y } inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
      using classes1_th_44 sorry
    thus " not ((x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A) &  not [TARSKIK4 x,y ] inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 (succORDINAL1K1 A))) &  not ([TARSKIK4 x,y ] inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 (succORDINAL1K1 A)) &  not (x inTARSKIR2 RankCLASSES1K4 A & y inTARSKIR2 RankCLASSES1K4 A))"
      using A1 classes1_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_46:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X be epsilon-transitiveORDINAL1V1 & RankCLASSES1K4 A /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X =XBOOLE-0R4 RankCLASSES1K4 (succORDINAL1K1 A) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X implies Tarski-ClassCLASSES1K1 X c=TARSKIR1 RankCLASSES1K4 A"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X be epsilon-transitiveORDINAL1V1 & RankCLASSES1K4 A /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X =XBOOLE-0R4 RankCLASSES1K4 (succORDINAL1K1 A) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X implies Tarski-ClassCLASSES1K1 X c=TARSKIR1 RankCLASSES1K4 A"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "X be epsilon-transitiveORDINAL1V1"
      and A2: "RankCLASSES1K4 A /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X =XBOOLE-0R4 RankCLASSES1K4 (succORDINAL1K1 A) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
    have "( ex x be objectHIDDENM1 st x inHIDDENR3 Tarski-ClassCLASSES1K1 X &  not x inHIDDENR3 RankCLASSES1K4 A) implies  False "
    proof(rule impI)
      assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 Tarski-ClassCLASSES1K1 X &  not x inHIDDENR3 RankCLASSES1K4 A"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A3: "x inHIDDENR3 Tarski-ClassCLASSES1K1 X &  not x inHIDDENR3 RankCLASSES1K4 A"
         sorry
      have "x inHIDDENR3 Tarski-ClassCLASSES1K1 X \\SUBSET-1K6 RankCLASSES1K4 A"
        using A3 xboole_0_def_5 sorry
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A4: "Y inTARSKIR2 Tarski-ClassCLASSES1K1 X \\SUBSET-1K6 RankCLASSES1K4 A"and A5: " not ( ex x be objectHIDDENM1 st x inHIDDENR3 Tarski-ClassCLASSES1K1 X \\SUBSET-1K6 RankCLASSES1K4 A & x inHIDDENR3 Y)"
        using tarski_th_3 sorry
      have A6: "Y c=TARSKIR1 Tarski-ClassCLASSES1K1 X"
        using A4 ordinal1_def_2 A1 classes1_th_23 sorry
      have "Y c=TARSKIR1 RankCLASSES1K4 A"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 RankCLASSES1K4 A"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A7: "x inHIDDENR3 Y"
          then have " not x inHIDDENR3 Tarski-ClassCLASSES1K1 X \\SUBSET-1K6 RankCLASSES1K4 A"
            using A5 sorry
          thus "x inHIDDENR3 RankCLASSES1K4 A"
            using A6 A7 xboole_0_def_5 sorry
        qed "sorry"
        thus "Y c=TARSKIR1 RankCLASSES1K4 A"
          using tarski_def_3 sorry
      qed
      then have "Y inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
        using classes1_th_32 sorry
      then have A8: "Y inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
        using A4 xboole_0_def_4 sorry
      have " not Y inTARSKIR2 RankCLASSES1K4 A"
        using A4 xboole_0_def_5 sorry
      thus " False "
        using A2 A8 xboole_0_def_4 sorry
    qed
    thus "Tarski-ClassCLASSES1K1 X c=TARSKIR1 RankCLASSES1K4 A"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_47:
" for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies ( ex A be OrdinalORDINAL1M3 st Tarski-ClassCLASSES1K1 X c=TARSKIR1 RankCLASSES1K4 A)"
proof-
  have " for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies (( for A be OrdinalORDINAL1M3 holds  not Tarski-ClassCLASSES1K1 X c=TARSKIR1 RankCLASSES1K4 A) implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X be epsilon-transitiveORDINAL1V1"
    assume A2: " for A be OrdinalORDINAL1M3 holds  not Tarski-ClassCLASSES1K1 X c=TARSKIR1 RankCLASSES1K4 A"
    let ?P = "\<lambda>Lamb1.  ex A be OrdinalORDINAL1M3 st Lamb1 inHIDDENR3 RankCLASSES1K4 A"
    obtain Power where
      [ty]:"Power be setHIDDENM2" and 
      A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Power iff x inHIDDENR3 Tarski-ClassCLASSES1K1 X & ?P(x)"
      using xboole_0_sch_1 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be OrdinalORDINAL1M3 st (Lamb2 =HIDDENR1 A &  not Lamb1 inHIDDENR3 RankCLASSES1K4 A) & Lamb1 inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A)"
    have A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?P(x,y) & ?P(x,z) implies y =HIDDENR1 z"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ( ex A1 be OrdinalORDINAL1M3 st (y =HIDDENR1 A1 &  not x inHIDDENR3 RankCLASSES1K4 A1) & x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A1)) implies (( ex A2 be OrdinalORDINAL1M3 st (z =HIDDENR1 A2 &  not x inHIDDENR3 RankCLASSES1K4 A2) & x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A2)) implies (y <>HIDDENR2 z implies  False ))"
      proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume Given: " ex A1 be OrdinalORDINAL1M3 st (y =HIDDENR1 A1 &  not x inHIDDENR3 RankCLASSES1K4 A1) & x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A1)"
        then obtain A1 where
          [ty]:"A1 be OrdinalORDINAL1M3" and 
          A5: "y =HIDDENR1 A1"and A6: " not x inHIDDENR3 RankCLASSES1K4 A1"and A7: "x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A1)"
           sorry
        assume Given: " ex A2 be OrdinalORDINAL1M3 st (z =HIDDENR1 A2 &  not x inHIDDENR3 RankCLASSES1K4 A2) & x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A2)"
        then obtain A2 where
          [ty]:"A2 be OrdinalORDINAL1M3" and 
          A8: "z =HIDDENR1 A2"and A9: " not x inHIDDENR3 RankCLASSES1K4 A2"and A10: "x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A2)"
           sorry
        assume "y <>HIDDENR2 z"
        then have A11: "A1 inTARSKIR2 A2 or A2 inTARSKIR2 A1"
          using A5 A8 ordinal1_th_14 sorry
        have "succORDINAL1K1 A1 c=ORDINAL1R1 A2 implies  False "
        proof(rule impI)
          assume "succORDINAL1K1 A1 c=ORDINAL1R1 A2"
          then have "RankCLASSES1K4 (succORDINAL1K1 A1) c=TARSKIR1 RankCLASSES1K4 A2"
            using classes1_th_37 sorry
          thus " False "
            using A7 A9 sorry
        qed
        then have "RankCLASSES1K4 (succORDINAL1K1 A2) c=TARSKIR1 RankCLASSES1K4 A1"
          using A11 classes1_th_37 ordinal1_th_21 sorry
        thus " False "
          using A6 A10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A12: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff ( ex y be objectHIDDENM1 st y inHIDDENR3 Power & ?P(y,x))"
      using tarski_sch_1 A4 sorry
    have " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Y"
    proof(rule ballI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      have "RankCLASSES1K4 A /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X <>HIDDENR2 RankCLASSES1K4 (succORDINAL1K1 A) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
        using A1 A2 classes1_th_46 sorry
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A13: " not (y inHIDDENR3 RankCLASSES1K4 A /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X iff y inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X)"
        using tarski_th_2 sorry
      have A14: "A c=ORDINAL1R1 succORDINAL1K1 A"
        using ordinal1_th_6 ordinal1_def_2 sorry
      then have A15: "RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A)"
        using classes1_th_37 sorry
      have "RankCLASSES1K4 A /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 A) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
        using xboole_1_th_26 A14 classes1_th_37 sorry
      then have A16: "y inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A)"
        using A13 xboole_0_def_4 sorry
      have A17: "y inHIDDENR3 Tarski-ClassCLASSES1K1 X"
        using A13 xboole_0_def_4 sorry
      then have A18: " not y inHIDDENR3 RankCLASSES1K4 A"
        using A13 A15 xboole_0_def_4 sorry
      have "y inHIDDENR3 Power"
        using A3 A16 A17 sorry
      thus "A inTARSKIR2 Y"
        using A12 A16 A18 sorry
    qed "sorry"
    thus " False "
      using ordinal1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_48:
" for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies unionTARSKIK3 X c=TARSKIR1 X"
proof-
  have " for X be setHIDDENM2 holds  not (X be epsilon-transitiveORDINAL1V1 &  not unionTARSKIK3 X c=TARSKIR1 X)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies Y c=TARSKIR1 X) implies unionTARSKIK3 X c=TARSKIR1 X"
    proof(rule impI)
      assume A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies Y c=TARSKIR1 X"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 X implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 unionTARSKIK3 X"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A2: "x inHIDDENR3 Y"and A3: "Y inTARSKIR2 X"
          using tarski_def_4 sorry
        have "Y c=TARSKIR1 X"
          using A1 A3 sorry
        thus "x inHIDDENR3 X"
          using A2 sorry
      qed "sorry"
      thus "unionTARSKIK3 X c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    thus " not (X be epsilon-transitiveORDINAL1V1 &  not unionTARSKIK3 X c=TARSKIR1 X)"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_49:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 & Y be epsilon-transitiveORDINAL1V1 implies X \\/XBOOLE-0K2 Y be epsilon-transitiveORDINAL1V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X be epsilon-transitiveORDINAL1V1 & Y be epsilon-transitiveORDINAL1V1) &  not X \\/XBOOLE-0K2 Y be epsilon-transitiveORDINAL1V1)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for Z be setHIDDENM2 holds Z inTARSKIR2 X implies Z c=TARSKIR1 X) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 Y implies Z c=TARSKIR1 Y) implies X \\/XBOOLE-0K2 Y be epsilon-transitiveORDINAL1V1"
    proof(rule impMI ,rule impI)
      assume A1: " for Z be setHIDDENM2 holds Z inTARSKIR2 X implies Z c=TARSKIR1 X"
        and A2: " for Z be setHIDDENM2 holds Z inTARSKIR2 Y implies Z c=TARSKIR1 Y"
      have " for Z be setHIDDENM2 holds Z inTARSKIR2 X \\/XBOOLE-0K2 Y implies Z c=TARSKIR1 X \\/XBOOLE-0K2 Y"
      proof(rule ballI,rule impI)
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume "Z inTARSKIR2 X \\/XBOOLE-0K2 Y"
        then have "Z inTARSKIR2 X or Z inTARSKIR2 Y"
          using xboole_0_def_3 sorry
        then have A3: "Z c=TARSKIR1 X or Z c=TARSKIR1 Y"
          using A1 A2 sorry
        have "X c=TARSKIR1 X \\/XBOOLE-0K2 Y & Y c=TARSKIR1 X \\/XBOOLE-0K2 Y"
          using xboole_1_th_7 sorry
        thus "Z c=TARSKIR1 X \\/XBOOLE-0K2 Y"
          using A3 sorry
      qed "sorry"
      thus "X \\/XBOOLE-0K2 Y be epsilon-transitiveORDINAL1V1"
        using ordinal1_def_2 sorry
    qed
    thus " not ((X be epsilon-transitiveORDINAL1V1 & Y be epsilon-transitiveORDINAL1V1) &  not X \\/XBOOLE-0K2 Y be epsilon-transitiveORDINAL1V1)"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_50:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 & Y be epsilon-transitiveORDINAL1V1 implies X /\\XBOOLE-0K3 Y be epsilon-transitiveORDINAL1V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X be epsilon-transitiveORDINAL1V1 & Y be epsilon-transitiveORDINAL1V1) &  not X /\\XBOOLE-0K3 Y be epsilon-transitiveORDINAL1V1)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for Z be setHIDDENM2 holds Z inTARSKIR2 X implies Z c=TARSKIR1 X) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 Y implies Z c=TARSKIR1 Y) implies X /\\XBOOLE-0K3 Y be epsilon-transitiveORDINAL1V1"
    proof(rule impMI ,rule impI)
      assume A1: " for Z be setHIDDENM2 holds Z inTARSKIR2 X implies Z c=TARSKIR1 X"
        and A2: " for Z be setHIDDENM2 holds Z inTARSKIR2 Y implies Z c=TARSKIR1 Y"
      have " for Z be setHIDDENM2 holds Z inTARSKIR2 X /\\XBOOLE-0K3 Y implies Z c=TARSKIR1 X /\\XBOOLE-0K3 Y"
      proof(rule ballI,rule impI)
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume A3: "Z inTARSKIR2 X /\\XBOOLE-0K3 Y"
        then have A4: "Z inTARSKIR2 X"
          using xboole_0_def_4 sorry
        have A5: "Z inTARSKIR2 Y"
          using A3 xboole_0_def_4 sorry
        have A6: "Z c=TARSKIR1 X"
          using A1 A4 sorry
        have "Z c=TARSKIR1 Y"
          using A2 A5 sorry
        thus "Z c=TARSKIR1 X /\\XBOOLE-0K3 Y"
          using A6 xboole_1_th_19 sorry
      qed "sorry"
      thus "X /\\XBOOLE-0K3 Y be epsilon-transitiveORDINAL1V1"
        using ordinal1_def_2 sorry
    qed
    thus " not ((X be epsilon-transitiveORDINAL1V1 & Y be epsilon-transitiveORDINAL1V1) &  not X /\\XBOOLE-0K3 Y be epsilon-transitiveORDINAL1V1)"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve n for "ElementSUBSET-1M1-of omegaORDINAL1K4"
mdef classes1_def_7 ("the-transitive-closure-ofCLASSES1K5  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func the-transitive-closure-ofCLASSES1K5 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))"
    proof-
      have " ex UNI be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 UNI implies ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))) & (( ex g be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 g .FUNCT-1K1 n & domRELAT-1K1 g =XBOOLE-0R4 omegaORDINAL1K4) & g .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds g .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (g .FUNCT-1K1 k))) implies x inHIDDENR3 UNI)"
      proof-
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A1: "(domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4 & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for n be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 n))"
          using ordinal2_sch_18 sorry
        obtain UNI where 
          [ty]:"UNI be setHIDDENM2" and UNIDef:"UNI = unionTARSKIK3 (rngFUNCT-1K2 f)"
           sorry
        show " ex UNI be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 UNI implies ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))) & (( ex g be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 g .FUNCT-1K1 n & domRELAT-1K1 g =XBOOLE-0R4 omegaORDINAL1K4) & g .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds g .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (g .FUNCT-1K1 k))) implies x inHIDDENR3 UNI)"
        proof(rule bexI[of _ "UNI"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 UNI implies ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))"
          proof-
            have "x inHIDDENR3 UNI implies ( ex tVar8 be FunctionFUNCT-1M1 st  ex tVar9 be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 tVar8 .FUNCT-1K1 tVar9 & domRELAT-1K1 tVar8 =XBOOLE-0R4 omegaORDINAL1K4) & tVar8 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds tVar8 .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (tVar8 .FUNCT-1K1 k)))"
            proof(rule impI)
              assume "x inHIDDENR3 UNI"
              then obtain Y where
                [ty]:"Y be setHIDDENM2" and 
                A2: "x inHIDDENR3 Y"and A3: "Y inTARSKIR2 rngFUNCT-1K2 f"
                using tarski_def_4 sorry
              obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A4: "y inHIDDENR3 domRELAT-1K1 f"and A5: "Y =XBOOLE-0R4 f .FUNCT-1K1 y"
                using A3 funct_1_def_3 sorry
              have 
                [ty]:"y be ElementSUBSET-1M1-of omegaORDINAL1K4"
                using A1 A4 sorry
              show " ex tVar8 be FunctionFUNCT-1M1 st  ex tVar9 be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 tVar8 .FUNCT-1K1 tVar9 & domRELAT-1K1 tVar8 =XBOOLE-0R4 omegaORDINAL1K4) & tVar8 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds tVar8 .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (tVar8 .FUNCT-1K1 k))"
              proof(rule bexI[of _ "f"])
                show " ex tVar9 be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 tVar9 & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k))"
                proof(rule bexI[of _ "y"])
                  show "((x inHIDDENR3 f .FUNCT-1K1 y & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k))"
                    using A1 A2 A5 sorry
                qed "sorry"
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          let ?f = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 Lamb2"
          assume Given: " ex g be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 g .FUNCT-1K1 n & domRELAT-1K1 g =XBOOLE-0R4 omegaORDINAL1K4) & g .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds g .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 ?f(k,g .FUNCT-1K1 k))"
          then obtain g n where
            [ty]:"g be FunctionFUNCT-1M1" "n be ElementSUBSET-1M1-of omegaORDINAL1K4" and 
            A6: "x inHIDDENR3 g .FUNCT-1K1 n"and A7: "domRELAT-1K1 g =XBOOLE-0R4 omegaORDINAL1K4"and A8: "g .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X"and A9: " for k be NatORDINAL1M6 holds g .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 ?f(k,g .FUNCT-1K1 k)"
             sorry
          have A10: "domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4"
            using A1 sorry
          have A11: "f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X"
            using A1 sorry
          have A12: " for n be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 ?f(n,f .FUNCT-1K1 n)"
            using A1 sorry
          have "g =FUNCT-1R1 f"
            using ordinal2_sch_20 A7 A8 A9 A10 A11 A12 sorry
          then have "g .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 f"
            using A1 funct_1_def_3 sorry
          thus "x inHIDDENR3 UNI"
            using A6 tarski_def_4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))) implies it1 =HIDDENR1 it2"
    proof-
      have " for U1 be setHIDDENM2 holds  for U2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 U1 iff ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 U2 iff ( ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((x inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)))) implies U1 =XBOOLE-0R4 U2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1.  ex f be FunctionFUNCT-1M1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st ((Lamb1 inHIDDENR3 f .FUNCT-1K1 n & domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4) & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X) & ( for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k))"
        fix U1 assume [ty]: "U1 be setHIDDENM2"
        fix U2 assume [ty]: "U2 be setHIDDENM2"
        assume A13: " for x be objectHIDDENM1 holds x inHIDDENR3 U1 iff ?P(x)"
          and A14: " for x be objectHIDDENM1 holds x inHIDDENR3 U2 iff ?P(x)"
        show "U1 =XBOOLE-0R4 U2"
          using xboole_0_sch_2 A13 A14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem classes1_cl_3:
  mlet "X be setHIDDENM2"
"cluster the-transitive-closure-ofCLASSES1K5 X as-term-is epsilon-transitiveORDINAL1V1"
proof
(*coherence*)
  show "the-transitive-closure-ofCLASSES1K5 X be epsilon-transitiveORDINAL1V1"
  proof-
    have " for Y be setHIDDENM2 holds Y inTARSKIR2 the-transitive-closure-ofCLASSES1K5 X implies Y c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X"
    proof(rule ballI,rule impI)
      fix Y assume [ty]: "Y be setHIDDENM2"
      assume "Y inTARSKIR2 the-transitive-closure-ofCLASSES1K5 X"
      then obtain f n where
        [ty]:"f be FunctionFUNCT-1M1" "n be ElementSUBSET-1M1-of omegaORDINAL1K4" and 
        A1: "Y inTARSKIR2 f .FUNCT-1K1 n"and A2: "domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4 & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X"and A3: " for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)"
        using classes1_def_7 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 the-transitive-closure-ofCLASSES1K5 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 Y"
        then have A4: "x inHIDDENR3 unionTARSKIK3 (f .FUNCT-1K1 n)"
          using A1 tarski_def_4 sorry
        obtain m where 
          [ty]:"m be ElementSUBSET-1M1-of omegaORDINAL1K4" and mDef:"m = succORDINAL1K1 n"
          using ordinal1_def_12 sorry
        have "x inHIDDENR3 f .FUNCT-1K1 m"
          using A3 A4 sorry
        thus "x inHIDDENR3 the-transitive-closure-ofCLASSES1K5 X"
          using A2 A3 classes1_def_7 sorry
      qed "sorry"
      thus "Y c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X"
        using tarski_def_3 sorry
    qed "sorry"
    thus "the-transitive-closure-ofCLASSES1K5 X be epsilon-transitiveORDINAL1V1"
      using ordinal1_def_2 sorry
  qed
qed "sorry"

mtheorem classes1_th_51:
" for X be setHIDDENM2 holds the-transitive-closure-ofCLASSES1K5 X be epsilon-transitiveORDINAL1V1"
   sorry

mtheorem classes1_th_52:
" for X be setHIDDENM2 holds X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X"
proof-
  have " for X be setHIDDENM2 holds X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 the-transitive-closure-ofCLASSES1K5 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 X"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4"and A3: "f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X"and A4: " for n be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 n)"
        using ordinal2_sch_18 sorry
      obtain z where 
        [ty]:"z be ElementSUBSET-1M1-of omegaORDINAL1K4" and zDef:"z = 0ORDINAL1K5"
        using ordinal1_def_12 sorry
      have "x inHIDDENR3 f .FUNCT-1K1 z"
        using A1 A3 sorry
      thus "x inHIDDENR3 the-transitive-closure-ofCLASSES1K5 X"
        using A2 A3 A4 classes1_def_7 sorry
    qed "sorry"
    thus "X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_53:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y & Y be epsilon-transitiveORDINAL1V1 implies the-transitive-closure-ofCLASSES1K5 X c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y & Y be epsilon-transitiveORDINAL1V1 implies the-transitive-closure-ofCLASSES1K5 X c=TARSKIR1 Y"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
      and A2: "Y be epsilon-transitiveORDINAL1V1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 the-transitive-closure-ofCLASSES1K5 X implies x inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 the-transitive-closure-ofCLASSES1K5 X"
      then obtain f n where
        [ty]:"f be FunctionFUNCT-1M1" "n be ElementSUBSET-1M1-of omegaORDINAL1K4" and 
        A3: "x inHIDDENR3 f .FUNCT-1K1 n"and "domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4"and A4: "f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 X"and A5: " for k be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k)"
        using classes1_def_7 sorry
      let ?P = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1 c=TARSKIR1 Y"
      have A6: "?P(0ORDINAL1K5)"
        using A1 A4 sorry
      have A7: " for k be NatORDINAL1M6 holds ?P(k) implies ?P(succORDINAL1K1 k)"
      proof-
        have " for k be NatORDINAL1M6 holds f .FUNCT-1K1 k c=TARSKIR1 Y implies f .FUNCT-1K1 succORDINAL1K1 k c=TARSKIR1 Y"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatORDINAL1M6"
          assume "f .FUNCT-1K1 k c=TARSKIR1 Y"
          then have A8: "unionTARSKIK3 (f .FUNCT-1K1 k) c=TARSKIR1 unionTARSKIK3 Y"
            using zfmisc_1_th_77 sorry
          have "f .FUNCT-1K1 succORDINAL1K1 k =XBOOLE-0R4 unionTARSKIK3 (f .FUNCT-1K1 k) & unionTARSKIK3 Y c=TARSKIR1 Y"
            using A2 A5 classes1_th_48 sorry
          thus "f .FUNCT-1K1 succORDINAL1K1 k c=TARSKIR1 Y"
            using A8 xboole_1_th_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "?P(n)"
        using ordinal2_sch_17 A6 A7 sorry
      thus "x inHIDDENR3 Y"
        using A3 sorry
    qed "sorry"
    thus "the-transitive-closure-ofCLASSES1K5 X c=TARSKIR1 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_54:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (( for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be epsilon-transitiveORDINAL1V1 implies Y c=TARSKIR1 Z) & X c=TARSKIR1 Y) & Y be epsilon-transitiveORDINAL1V1 implies the-transitive-closure-ofCLASSES1K5 X =XBOOLE-0R4 Y"
  using classes1_th_53 classes1_th_52 sorry

mtheorem classes1_th_55:
" for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies the-transitive-closure-ofCLASSES1K5 X =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  not (X be epsilon-transitiveORDINAL1V1 &  not the-transitive-closure-ofCLASSES1K5 X =XBOOLE-0R4 X)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Z be epsilon-transitiveORDINAL1V1 implies X c=TARSKIR1 Z"
       sorry
    thus " not (X be epsilon-transitiveORDINAL1V1 &  not the-transitive-closure-ofCLASSES1K5 X =XBOOLE-0R4 X)"
      using classes1_th_54 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_56:
"the-transitive-closure-ofCLASSES1K5 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
  using classes1_th_55 sorry

mtheorem classes1_th_57:
" for A be OrdinalORDINAL1M3 holds the-transitive-closure-ofCLASSES1K5 A =XBOOLE-0R4 A"
  using classes1_th_55 sorry

mtheorem classes1_th_58:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies the-transitive-closure-ofCLASSES1K5 X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies the-transitive-closure-ofCLASSES1K5 X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have "Y c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 Y"
      using classes1_th_52 sorry
    then have "X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 Y"
      using A1 sorry
    thus "the-transitive-closure-ofCLASSES1K5 X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 Y"
      using classes1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_59:
" for X be setHIDDENM2 holds the-transitive-closure-ofCLASSES1K5 (the-transitive-closure-ofCLASSES1K5 X) =XBOOLE-0R4 the-transitive-closure-ofCLASSES1K5 X"
  using classes1_th_55 sorry

mtheorem classes1_th_60:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X & Y c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 Y"
      using classes1_th_52 sorry
    then have A1: "X \\/XBOOLE-0K2 Y c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y"
      using xboole_1_th_13 sorry
    have Cut1681: "the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 (the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y)"
      using A1 classes1_th_58 sorry
    have "the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y & the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y)"
    proof(rule conjMI)
      show "the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y"
        using classes1_th_49 classes1_th_55 Cut1681 sorry
      have "the-transitive-closure-ofCLASSES1K5 X c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y) & the-transitive-closure-ofCLASSES1K5 Y c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y)"
        using classes1_th_58 xboole_1_th_7 sorry
      thus "the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y)"
        using xboole_1_th_8 sorry
    qed
    thus "the-transitive-closure-ofCLASSES1K5 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 the-transitive-closure-ofCLASSES1K5 X \\/XBOOLE-0K2 the-transitive-closure-ofCLASSES1K5 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_61:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds the-transitive-closure-ofCLASSES1K5 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X /\\XBOOLE-0K3 the-transitive-closure-ofCLASSES1K5 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds the-transitive-closure-ofCLASSES1K5 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X /\\XBOOLE-0K3 the-transitive-closure-ofCLASSES1K5 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "the-transitive-closure-ofCLASSES1K5 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X & the-transitive-closure-ofCLASSES1K5 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 Y"
      using classes1_th_58 xboole_1_th_17 sorry
    thus "the-transitive-closure-ofCLASSES1K5 (X /\\XBOOLE-0K3 Y) c=TARSKIR1 the-transitive-closure-ofCLASSES1K5 X /\\XBOOLE-0K3 the-transitive-closure-ofCLASSES1K5 Y"
      using xboole_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_62:
" for X be setHIDDENM2 holds  ex A be OrdinalORDINAL1M3 st X c=TARSKIR1 RankCLASSES1K4 A"
proof-
  have " for X be setHIDDENM2 holds  ex tVar10 be OrdinalORDINAL1M3 st X c=TARSKIR1 RankCLASSES1K4 tVar10"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A1: "Tarski-ClassCLASSES1K1 (the-transitive-closure-ofCLASSES1K5 X) c=TARSKIR1 RankCLASSES1K4 A"
      using classes1_th_47 sorry
    show " ex tVar10 be OrdinalORDINAL1M3 st X c=TARSKIR1 RankCLASSES1K4 tVar10"
    proof(rule bexI[of _ "A"])
      have "the-transitive-closure-ofCLASSES1K5 X inTARSKIR2 Tarski-ClassCLASSES1K1 (the-transitive-closure-ofCLASSES1K5 X)"
        using classes1_th_2 sorry
      then have "X inTARSKIR2 Tarski-ClassCLASSES1K1 (the-transitive-closure-ofCLASSES1K5 X)"
        using classes1_th_3 classes1_th_52 sorry
      thus "X c=TARSKIR1 RankCLASSES1K4 A"
        using A1 ordinal1_def_2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef classes1_def_8 ("the-rank-ofCLASSES1K6  _ " [300]300 ) where
  mlet "x be objectHIDDENM1"
"func the-rank-ofCLASSES1K6 x \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it. x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 it) & ( for B be OrdinalORDINAL1M3 holds x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 B) implies it c=ORDINAL1R1 B)"
proof-
  (*existence*)
    show " ex it be OrdinalORDINAL1M3 st x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 it) & ( for B be OrdinalORDINAL1M3 holds x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 B) implies it c=ORDINAL1R1 B)"
    proof-
      have " ex A be OrdinalORDINAL1M3 st x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A) & ( for B be OrdinalORDINAL1M3 holds x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 B) implies A c=ORDINAL1R1 B)"
      proof-
        let ?P = "\<lambda>Lamb1. x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 Lamb1)"
        have 
          [ty]:"x be setHIDDENM2"
          using tarski_th_1 sorry
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A1: "x c=TARSKIR1 RankCLASSES1K4 A"
          using classes1_th_62 sorry
        have "x inTARSKIR2 boolSETFAM-1K9 RankCLASSES1K4 A"
          using A1 sorry
        then have "x inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
          using classes1_lm_2 sorry
        then have A2: " ex A be OrdinalORDINAL1M3 st ?P(A)"
           sorry
        show " ex A be OrdinalORDINAL1M3 st x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 A) & ( for B be OrdinalORDINAL1M3 holds x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 B) implies A c=ORDINAL1R1 B)"
          using ordinal1_sch_1 A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds (x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 it1) & ( for B be OrdinalORDINAL1M3 holds x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 B) implies it1 c=ORDINAL1R1 B)) & (x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 it2) & ( for B be OrdinalORDINAL1M3 holds x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 B) implies it2 c=ORDINAL1R1 B)) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

abbreviation(input) CLASSES1K7("the-rank-ofCLASSES1K7  _ " [300]300) where
  "the-rank-ofCLASSES1K7 X \<equiv> the-rank-ofCLASSES1K6 X"

mtheorem classes1_def_9:
  mlet "X be setHIDDENM2"
"redefine func the-rank-ofCLASSES1K7 X \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it. X c=TARSKIR1 RankCLASSES1K4 it & ( for B be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 B implies it c=ORDINAL1R1 B)"
proof
(*compatibility*)
  show " for it be OrdinalORDINAL1M3 holds it =HIDDENR1 the-rank-ofCLASSES1K7 X iff X c=TARSKIR1 RankCLASSES1K4 it & ( for B be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 B implies it c=ORDINAL1R1 B)"
  proof-
    have " for O be OrdinalORDINAL1M3 holds (O =XBOOLE-0R4 the-rank-ofCLASSES1K6 X implies X c=TARSKIR1 RankCLASSES1K4 O & ( for B be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 B implies O c=ORDINAL1R1 B)) & (X c=TARSKIR1 RankCLASSES1K4 O implies (( for B be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 B implies O c=ORDINAL1R1 B) implies O =XBOOLE-0R4 the-rank-ofCLASSES1K6 X))"
    proof(rule ballI,rule conjMI,rule impI,rule impI)
      fix O assume [ty]: "O be OrdinalORDINAL1M3"
      show "O =XBOOLE-0R4 the-rank-ofCLASSES1K6 X implies X c=TARSKIR1 RankCLASSES1K4 O & ( for B be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 B implies O c=ORDINAL1R1 B)"
      proof(rule impI,rule conjMI,rule ballI,rule impI)
        assume A1: "O =XBOOLE-0R4 the-rank-ofCLASSES1K6 X"
        then have "X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 O)"
          using classes1_def_8 sorry
        then have "X inTARSKIR2 boolSETFAM-1K9 RankCLASSES1K4 O"
          using classes1_lm_2 sorry
        thus "X c=TARSKIR1 RankCLASSES1K4 O"
           sorry
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume "X c=TARSKIR1 RankCLASSES1K4 B"
        then have "X inTARSKIR2 boolSETFAM-1K9 RankCLASSES1K4 B"
           sorry
        then have "X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 B)"
          using classes1_lm_2 sorry
        thus "O c=ORDINAL1R1 B"
          using A1 classes1_def_8 sorry
      qed "sorry"
      assume "X c=TARSKIR1 RankCLASSES1K4 O"
      then have "X inTARSKIR2 boolSETFAM-1K9 RankCLASSES1K4 O"
         sorry
      then have A2: "X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 O)"
        using classes1_lm_2 sorry
      assume A3: " for B be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 B implies O c=ORDINAL1R1 B"
      have " for B be OrdinalORDINAL1M3 holds X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 B) implies O c=ORDINAL1R1 B"
      proof(rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume "X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 B)"
        then have "X inTARSKIR2 boolSETFAM-1K9 RankCLASSES1K4 B"
          using classes1_lm_2 sorry
        thus "O c=ORDINAL1R1 B"
          using A3 sorry
      qed "sorry"
      thus "O =XBOOLE-0R4 the-rank-ofCLASSES1K6 X"
        using A2 classes1_def_8 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem classes1_th_63:
" for X be setHIDDENM2 holds the-rank-ofCLASSES1K7 (boolSETFAM-1K9 X) =XBOOLE-0R4 succORDINAL1K1 the-rank-ofCLASSES1K7 X"
proof-
  have " for X be setHIDDENM2 holds the-rank-ofCLASSES1K7 (boolSETFAM-1K9 X) =XBOOLE-0R4 succORDINAL1K1 the-rank-ofCLASSES1K7 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 X)"
      using classes1_def_9 sorry
    have A2: "boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 the-rank-ofCLASSES1K7 X)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 boolSETFAM-1K9 X implies x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 the-rank-ofCLASSES1K7 X)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        assume "x inHIDDENR3 boolSETFAM-1K9 X"
        then have A3: "xx c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 X)"
          using A1 sorry
        have "boolSETFAM-1K9 RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) =XBOOLE-0R4 RankCLASSES1K4 (succORDINAL1K1 the-rank-ofCLASSES1K7 X)"
          using classes1_lm_2 sorry
        thus "x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 the-rank-ofCLASSES1K7 X)"
          using A3 sorry
      qed "sorry"
      thus "boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 the-rank-ofCLASSES1K7 X)"
        using tarski_def_3 sorry
    qed
    have " for A be OrdinalORDINAL1M3 holds boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 A implies succORDINAL1K1 the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A4: "boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 A"
      let ?P = "\<lambda>Lamb1. X inTARSKIR2 RankCLASSES1K4 Lamb1"
      have A5: "X inTARSKIR2 boolSETFAM-1K9 X"
        using zfmisc_1_def_1 sorry
      then have A6: " ex A be OrdinalORDINAL1M3 st ?P(A)"
        using A4 sorry
      obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A7: "?P(B) & ( for C be OrdinalORDINAL1M3 holds ?P(C) implies B c=ORDINAL1R1 C)"
        using ordinal1_sch_1 A6 sorry
      have "( for C be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 C) implies  False "
      proof(rule impI)
        assume " for C be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 C"
        then have "B be limit-ordinalORDINAL1V4"
          using ordinal1_th_29 sorry
        then have " ex C be OrdinalORDINAL1M3 st C inTARSKIR2 B & X inTARSKIR2 RankCLASSES1K4 C"
          using A7 classes1_lm_2 classes1_th_31 sorry
        thus " False "
          using A7 ordinal1_th_5 sorry
      qed
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A8: "B =XBOOLE-0R4 succORDINAL1K1 C"
         sorry
      have "X c=TARSKIR1 RankCLASSES1K4 C"
        using A7 A8 classes1_th_32 sorry
      then have "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 C"
        using classes1_def_9 sorry
      then have A9: "the-rank-ofCLASSES1K7 X inTARSKIR2 B"
        using A8 ordinal1_th_22 sorry
      have "B c=ORDINAL1R1 A"
        using A4 A5 A7 sorry
      thus "succORDINAL1K1 the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A"
        using A9 ordinal1_th_21 sorry
    qed "sorry"
    thus "the-rank-ofCLASSES1K7 (boolSETFAM-1K9 X) =XBOOLE-0R4 succORDINAL1K1 the-rank-ofCLASSES1K7 X"
      using A2 classes1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_64:
" for A be OrdinalORDINAL1M3 holds the-rank-ofCLASSES1K7 (RankCLASSES1K4 A) =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds the-rank-ofCLASSES1K7 (RankCLASSES1K4 A) =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have " for B be OrdinalORDINAL1M3 holds RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 B implies A c=ORDINAL1R1 B"
      using classes1_th_37 sorry
    thus "the-rank-ofCLASSES1K7 (RankCLASSES1K4 A) =XBOOLE-0R4 A"
      using classes1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_65:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 RankCLASSES1K4 A iff the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds (X c=TARSKIR1 RankCLASSES1K4 A implies the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A) & (the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A implies X c=TARSKIR1 RankCLASSES1K4 A)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "X c=TARSKIR1 RankCLASSES1K4 A implies the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A"
      using classes1_def_9 sorry
    assume "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A"
    then have A1: "RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) c=TARSKIR1 RankCLASSES1K4 A"
      using classes1_th_37 sorry
    have "X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 X)"
      using classes1_def_9 sorry
    thus "X c=TARSKIR1 RankCLASSES1K4 A"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_66:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X inTARSKIR2 RankCLASSES1K4 A iff the-rank-ofCLASSES1K7 X inTARSKIR2 A"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds (X inTARSKIR2 RankCLASSES1K4 A implies the-rank-ofCLASSES1K7 X inTARSKIR2 A) & (the-rank-ofCLASSES1K7 X inTARSKIR2 A implies X inTARSKIR2 RankCLASSES1K4 A)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "X inTARSKIR2 RankCLASSES1K4 A implies the-rank-ofCLASSES1K7 X inTARSKIR2 A"
    proof(rule impI)
      assume "X inTARSKIR2 RankCLASSES1K4 A"
      then have "boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
        using classes1_th_42 sorry
      then have A1: "boolSETFAM-1K9 X c=TARSKIR1 RankCLASSES1K4 A"
        using classes1_th_32 sorry
      have "the-rank-ofCLASSES1K7 (boolSETFAM-1K9 X) =XBOOLE-0R4 succORDINAL1K1 the-rank-ofCLASSES1K7 X"
        using classes1_th_63 sorry
      then have A2: "the-rank-ofCLASSES1K7 X inTARSKIR2 the-rank-ofCLASSES1K7 (boolSETFAM-1K9 X)"
        using ordinal1_th_6 sorry
      have "the-rank-ofCLASSES1K7 (boolSETFAM-1K9 X) c=ORDINAL1R1 A"
        using A1 classes1_def_9 sorry
      thus "the-rank-ofCLASSES1K7 X inTARSKIR2 A"
        using A2 sorry
    qed
    assume A3: "the-rank-ofCLASSES1K7 X inTARSKIR2 A"
    have "X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 X)"
      using classes1_def_9 sorry
    then have A4: "X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 the-rank-ofCLASSES1K7 X)"
      using classes1_th_32 sorry
    have "RankCLASSES1K4 (succORDINAL1K1 the-rank-ofCLASSES1K7 X) c=TARSKIR1 RankCLASSES1K4 A"
      using A3 classes1_th_37 ordinal1_th_21 sorry
    thus "X inTARSKIR2 RankCLASSES1K4 A"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_67:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies the-rank-ofCLASSES1K7 X c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies the-rank-ofCLASSES1K7 X c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have "Y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 Y)"
      using classes1_def_9 sorry
    then have "X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 Y)"
      using A1 sorry
    thus "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
      using classes1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_68:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Y implies the-rank-ofCLASSES1K7 X inTARSKIR2 the-rank-ofCLASSES1K7 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Y implies the-rank-ofCLASSES1K7 X inTARSKIR2 the-rank-ofCLASSES1K7 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X inTARSKIR2 Y"
    have "Y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 Y)"
      using classes1_def_9 sorry
    thus "the-rank-ofCLASSES1K7 X inTARSKIR2 the-rank-ofCLASSES1K7 Y"
      using A1 classes1_th_66 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_69:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y inTARSKIR2 A)"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds (the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y inTARSKIR2 A)) & (( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y inTARSKIR2 A) implies the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?R = "the-rank-ofCLASSES1K7 X"
    have A1: "X c=TARSKIR1 RankCLASSES1K4 ?R"
      using classes1_def_9 sorry
    show "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y inTARSKIR2 A)"
      using A1 classes1_th_66 sorry
    assume A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y inTARSKIR2 A"
    have "X c=TARSKIR1 RankCLASSES1K4 A"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 RankCLASSES1K4 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        assume "x inHIDDENR3 X"
        then have "the-rank-ofCLASSES1K7 xx inTARSKIR2 A"
          using A2 sorry
        thus "x inHIDDENR3 RankCLASSES1K4 A"
          using classes1_th_66 sorry
      qed "sorry"
      thus "X c=TARSKIR1 RankCLASSES1K4 A"
        using tarski_def_3 sorry
    qed
    thus "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A"
      using classes1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_70:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 the-rank-ofCLASSES1K7 X iff ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y))"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds (A c=ORDINAL1R1 the-rank-ofCLASSES1K7 X implies ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y))) & (( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y)) implies A c=ORDINAL1R1 the-rank-ofCLASSES1K7 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "A c=ORDINAL1R1 the-rank-ofCLASSES1K7 X implies ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y))"
    proof-
      have "A c=ORDINAL1R1 the-rank-ofCLASSES1K7 X implies ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex tVar11 be setHIDDENM2 st tVar11 inTARSKIR2 X & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 tVar11))"
      proof(rule impI,rule ballI,rule impI)
        assume A1: "A c=ORDINAL1R1 the-rank-ofCLASSES1K7 X"
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume "B inTARSKIR2 A"
        then have " not the-rank-ofCLASSES1K7 X c=ORDINAL1R1 B"
          using A1 ordinal1_th_5 sorry
        then have " not X c=TARSKIR1 RankCLASSES1K4 B"
          using classes1_def_9 sorry
        then have A2: "X \\SUBSET-1K6 RankCLASSES1K4 B <>HIDDENR2 {}XBOOLE-0K1"
          using xboole_1_th_37 sorry
        let ?x = "the ElementSUBSET-1M1-of X \\SUBSET-1K6 RankCLASSES1K4 B"
        show " ex tVar11 be setHIDDENM2 st tVar11 inTARSKIR2 X & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 tVar11"
        proof(rule bexI[of _ "?x"],rule conjMI)
          have A3: " not ?x inTARSKIR2 RankCLASSES1K4 B"
            using A2 xboole_0_def_5 sorry
          show "the ElementSUBSET-1M1-of X \\SUBSET-1K6 RankCLASSES1K4 B inTARSKIR2 X"
            using A2 xboole_0_def_5 sorry
          show "B c=ORDINAL1R1 the-rank-ofCLASSES1K7 (the ElementSUBSET-1M1-of X \\SUBSET-1K6 RankCLASSES1K4 B)"
            using ordinal1_th_16 A3 classes1_th_66 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A4: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y)"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 the-rank-ofCLASSES1K7 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 A"
      then have 
        [ty]:"x be OrdinalORDINAL1M3"
         sorry
      obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A6: "Y inTARSKIR2 X"and A7: "x c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
        using A4 A5 sorry
      have "the-rank-ofCLASSES1K7 Y inTARSKIR2 the-rank-ofCLASSES1K7 X"
        using A6 classes1_th_68 sorry
      thus "x inHIDDENR3 the-rank-ofCLASSES1K7 X"
        using A7 ordinal1_th_12 sorry
    qed "sorry"
    thus "A c=ORDINAL1R1 the-rank-ofCLASSES1K7 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_71:
" for X be setHIDDENM2 holds the-rank-ofCLASSES1K7 X =XBOOLE-0R4 {}XBOOLE-0K1 iff X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds (the-rank-ofCLASSES1K7 X =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & (X =XBOOLE-0R4 {}XBOOLE-0K1 implies the-rank-ofCLASSES1K7 X =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    show "the-rank-ofCLASSES1K7 X =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    proof(rule impI)
      assume "the-rank-ofCLASSES1K7 X =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "X c=TARSKIR1 RankCLASSES1K4 ({}XBOOLE-0K1)"
        using classes1_def_9 sorry
      thus "X =XBOOLE-0R4 {}XBOOLE-0K1"
        using classes1_lm_2 sorry
    qed
    assume "X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have Cut1929: " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y inTARSKIR2 {}XBOOLE-0K1"
       sorry
    have "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=ORDINAL1R1 the-rank-ofCLASSES1K7 X"
    proof(rule conjMI)
      show "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 {}XBOOLE-0K1"
        using classes1_th_69 Cut1929 sorry
      show "{}XBOOLE-0K1 c=ORDINAL1R1 the-rank-ofCLASSES1K7 X"
         sorry
    qed
    thus "the-rank-ofCLASSES1K7 X =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_72:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds the-rank-ofCLASSES1K7 X =XBOOLE-0R4 succORDINAL1K1 A implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X & the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 A)"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds the-rank-ofCLASSES1K7 X =XBOOLE-0R4 succORDINAL1K1 A implies ( ex tVar12 be setHIDDENM2 st tVar12 inTARSKIR2 X & the-rank-ofCLASSES1K7 tVar12 =XBOOLE-0R4 A)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "the-rank-ofCLASSES1K7 X =XBOOLE-0R4 succORDINAL1K1 A"
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A2: "Y inTARSKIR2 X"and A3: "A c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
      using A1 classes1_th_70 ordinal1_th_6 sorry
    show " ex tVar12 be setHIDDENM2 st tVar12 inTARSKIR2 X & the-rank-ofCLASSES1K7 tVar12 =XBOOLE-0R4 A"
    proof(rule bexI[of _ "Y"])
      have "the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 A"
        using A1 ordinal1_th_22 A2 classes1_th_68 sorry
      thus "Y inTARSKIR2 X & the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 A"
        using A2 A3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_73:
" for A be OrdinalORDINAL1M3 holds the-rank-ofCLASSES1K7 A =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds the-rank-ofCLASSES1K7 A =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have Cut1950: "A c=TARSKIR1 RankCLASSES1K4 A"
      using classes1_th_38 sorry
    have "the-rank-ofCLASSES1K7 A c=ORDINAL1R1 A & A c=TARSKIR1 the-rank-ofCLASSES1K7 A"
    proof(rule conjMI)
      show "the-rank-ofCLASSES1K7 A c=ORDINAL1R1 A"
        using classes1_th_65 Cut1950 sorry
      let ?P = "\<lambda>Lamb1. Lamb1 c=ORDINAL1R1 the-rank-ofCLASSES1K7 Lamb1"
      have A1: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
      proof-
        have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies B c=ORDINAL1R1 the-rank-ofCLASSES1K7 B) implies A c=ORDINAL1R1 the-rank-ofCLASSES1K7 A"
        proof(rule ballI,rule impI)
          fix A assume [ty]: "A be OrdinalORDINAL1M3"
          assume A2: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies B c=ORDINAL1R1 the-rank-ofCLASSES1K7 B"
          have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 A & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y)"
          proof(rule ballI,rule impI)
            fix B assume [ty]: "B be OrdinalORDINAL1M3"
            assume A3: "B inTARSKIR2 A"
            obtain Y where 
              [ty]:"Y be setHIDDENM2" and YDef:"Y = B"
               sorry
            show " ex Y be setHIDDENM2 st Y inTARSKIR2 A & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
            proof(rule bexI[of _ "Y"])
              show "Y inTARSKIR2 A & B c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
                using A2 A3 sorry
            qed "sorry"
          qed "sorry"
          thus "A c=ORDINAL1R1 the-rank-ofCLASSES1K7 A"
            using classes1_th_70 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for B be OrdinalORDINAL1M3 holds ?P(B)"
        using ordinal1_sch_2 A1 sorry
      thus "A c=TARSKIR1 the-rank-ofCLASSES1K7 A"
         sorry
    qed
    thus "the-rank-ofCLASSES1K7 A =XBOOLE-0R4 A"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_74:
" for X be setHIDDENM2 holds the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) <>HIDDENR2 {}XBOOLE-0K1 & the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) be limit-ordinalORDINAL1V4"
proof-
  have " for X be setHIDDENM2 holds the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) <>HIDDENR2 {}XBOOLE-0K1 & ( not the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) be limit-ordinalORDINAL1V4 implies  False )"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "Tarski-ClassCLASSES1K1 X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X))"
      using classes1_def_9 sorry
    show "the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) <>HIDDENR2 {}XBOOLE-0K1"
    proof-
      have "the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
      proof(rule impI)
        assume "the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "Tarski-ClassCLASSES1K1 X c=TARSKIR1 {}XBOOLE-0K1"
          using classes1_def_9 classes1_lm_2 sorry
        thus " False "
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume " not the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) be limit-ordinalORDINAL1V4"
    then obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A2: "the-rank-ofCLASSES1K7 (Tarski-ClassCLASSES1K1 X) =XBOOLE-0R4 succORDINAL1K1 A"
      using ordinal1_th_29 sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A3: "Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"and A4: "the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 A"
      using A2 classes1_th_72 sorry
    have A5: "boolSETFAM-1K9 Y inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      using A3 classes1_th_4 sorry
    have A6: "the-rank-ofCLASSES1K7 (boolSETFAM-1K9 Y) =XBOOLE-0R4 succORDINAL1K1 A"
      using A4 classes1_th_63 sorry
    have "boolSETFAM-1K9 Y c=TARSKIR1 RankCLASSES1K4 A"
      using A1 A2 A5 classes1_th_32 sorry
    then have "succORDINAL1K1 A c=ORDINAL1R1 A"
      using A6 classes1_def_9 sorry
    then have "A inTARSKIR2 A"
      using ordinal1_th_21 sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve e, u for "setHIDDENM2"
theorem classes1_sch_1:
  fixes Xf0 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
   A1: " for e be objectHIDDENM1 holds e inHIDDENR3 Xf0 implies ( ex u be objectHIDDENM1 st Pp2(e,u))"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for e be objectHIDDENM1 holds e inHIDDENR3 Xf0 implies Pp2(e,f .FUNCT-1K1 e))"
  proof-
    have " not ( for f be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 Xf0 &  not Pp2(e,f .FUNCT-1K1 e)))))"
    proof-
      show " not ( for f be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 Xf0 &  not Pp2(e,f .FUNCT-1K1 e)))))"
      proof-
        have cases: "Xf0 =XBOOLE-0R4 {}XBOOLE-0K1 or Xf0 <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Xf0 =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( for f be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 Xf0 &  not Pp2(e,f .FUNCT-1K1 e)))))"
        proof(rule impI)
          assume "Xf0 =XBOOLE-0R4 {}XBOOLE-0K1"
          then have A2: " for e be objectHIDDENM1 holds e inHIDDENR3 Xf0 implies ( ex u be objectHIDDENM1 st u inHIDDENR3 {}XBOOLE-0K1 & Pp2(e,u))"
             sorry
          have " ex f be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 f c=TARSKIR1 {}XBOOLE-0K1) & ( for e be objectHIDDENM1 holds e inHIDDENR3 Xf0 implies Pp2(e,f .FUNCT-1K1 e))"
            using funct_1_sch_6 A2 sorry
          thus " not ( for f be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 Xf0 &  not Pp2(e,f .FUNCT-1K1 e)))))"
             sorry
        qed
        have case2: "Xf0 <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for f be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 Xf0 &  not Pp2(e,f .FUNCT-1K1 e)))))"
        proof(rule impI)
          assume "Xf0 <>HIDDENR2 {}XBOOLE-0K1"
          then obtain D where 
            [ty]:"D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and DDef:"D = Xf0"
             sorry
          let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex u be setHIDDENM2 st u inTARSKIR2 RankCLASSES1K4 Lamb2 & Pp2(Lamb1,u)"
          have A3: " for e be ElementSUBSET-1M1-of D holds  ex A be OrdinalORDINAL1M3 st ?Q(e,A)"
          proof-
            have " for e be ElementSUBSET-1M1-of D holds  not ( for A be OrdinalORDINAL1M3 holds  not ( ex u be setHIDDENM2 st u inTARSKIR2 RankCLASSES1K4 A & Pp2(e,u)))"
            proof(rule ballI)
              fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
              obtain u where
                [ty]:"u be objectHIDDENM1" and 
                A4: "Pp2(e,u)"
                using A1 sorry
              have 
                [ty]:"u be setHIDDENM2"
                using tarski_th_1 sorry
              have "u c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 u)"
                using classes1_def_9 sorry
              then have "u inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 the-rank-ofCLASSES1K7 u)"
                using classes1_th_32 sorry
              thus " not ( for A be OrdinalORDINAL1M3 holds  not ( ex u be setHIDDENM2 st u inTARSKIR2 RankCLASSES1K4 A & Pp2(e,u)))"
                using A4 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain F where
            [ty]:"F be FunctionFUNCT-1M1" and 
            A5: "domRELAT-1K1 F =XBOOLE-0R4 D & ( for d be ElementSUBSET-1M1-of D holds  ex A be OrdinalORDINAL1M3 st (A =XBOOLE-0R4 F .FUNCT-1K1 d & ?Q(d,A)) & ( for B be OrdinalORDINAL1M3 holds ?Q(d,B) implies A c=ORDINAL1R1 B))"
            using ordinal1_sch_6 A3 sorry
          have A6: " for e be objectHIDDENM1 holds e inHIDDENR3 Xf0 implies ( ex u be objectHIDDENM1 st u inHIDDENR3 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 F)) & Pp2(e,u))"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 Xf0 implies ( ex tVar14 be objectHIDDENM1 st tVar14 inHIDDENR3 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 F)) & Pp2(e,tVar14))"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume A7: "e inHIDDENR3 Xf0"
              then obtain A where
                [ty]:"A be OrdinalORDINAL1M3" and 
                A8: "A =XBOOLE-0R4 F .FUNCT-1K1 e"and A9: " ex u be setHIDDENM2 st u inTARSKIR2 RankCLASSES1K4 A & Pp2(e,u)"and " for B be OrdinalORDINAL1M3 holds ( ex u be setHIDDENM2 st u inTARSKIR2 RankCLASSES1K4 B & Pp2(e,u)) implies A c=ORDINAL1R1 B"
                using A5 sorry
              obtain u where
                [ty]:"u be setHIDDENM2" and 
                A10: "u inTARSKIR2 RankCLASSES1K4 A & Pp2(e,u)"
                using A9 sorry
              show " ex tVar14 be objectHIDDENM1 st tVar14 inHIDDENR3 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 F)) & Pp2(e,tVar14)"
              proof(rule bexI[of _ "u"])
                have "A inTARSKIR2 rngFUNCT-1K2 F"
                  using A5 A7 A8 funct_1_def_3 sorry
                then have "A inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 F)"
                  using ordinal2_th_19 sorry
                then have "RankCLASSES1K4 A c=TARSKIR1 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 F))"
                  using classes1_th_37 ordinal1_def_2 sorry
                thus "u inHIDDENR3 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 F)) & Pp2(e,u)"
                  using A10 sorry
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " ex f be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 f c=TARSKIR1 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 F))) & ( for e be objectHIDDENM1 holds e inHIDDENR3 Xf0 implies Pp2(e,f .FUNCT-1K1 e))"
            using funct_1_sch_6 A6 sorry
          thus " not ( for f be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 Xf0 &  not Pp2(e,f .FUNCT-1K1 e)))))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed

mdef classes1_def_10 ("'( _ , _ ')are-fiberwise-equipotentCLASSES1R2" [0,0]50 ) where
  mlet "F be RelationRELAT-1M1", "G be RelationRELAT-1M1"
"pred (F,G)are-fiberwise-equipotentCLASSES1R2 means
   for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"..

mtheorem CLASSES1R2_reflexivity:
" for G be RelationRELAT-1M1 holds (G,G)are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for G be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(G,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
     sorry
  thus " ?thesis "
    using classes1_def_10 sorry
qed

mtheorem CLASSES1R2_symmetry:
" for F be RelationRELAT-1M1 holds  for G be RelationRELAT-1M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies (G,F)are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for F be RelationRELAT-1M1 holds  for G be RelationRELAT-1M1 holds ( for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))) implies ( for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(G,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(F,x)))"
     sorry
  thus " ?thesis "
    using classes1_def_10 sorry
qed

mlemma classes1_lm_3:
" for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  not x inHIDDENR3 rngFUNCT-1K2 F implies CoimRELAT-1K13(F,x) =XBOOLE-0R4 {}XBOOLE-0K1"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be FunctionFUNCT-1M1"
  fix x assume [ty]: "x be objectHIDDENM1"
  assume A1: " not x inHIDDENR3 rngFUNCT-1K2 F"
  have "rngFUNCT-1K2 F meetsXBOOLE-0R5 {TARSKIK1 x} implies  False "
  proof(rule impI)
    assume "rngFUNCT-1K2 F meetsXBOOLE-0R5 {TARSKIK1 x}"
    then have " ex y be objectHIDDENM1 st y inHIDDENR3 rngFUNCT-1K2 F & y inHIDDENR3 {TARSKIK1 x}"
      using xboole_0_th_3 sorry
    thus " False "
      using A1 tarski_def_1 sorry
  qed
  thus "CoimRELAT-1K13(F,x) =XBOOLE-0R4 {}XBOOLE-0K1"
    using relat_1_th_138 sorry
qed "sorry"

mtheorem classes1_th_75:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies rngFUNCT-1K2 F =XBOOLE-0R4 rngFUNCT-1K2 G"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be FunctionFUNCT-1M1"
  fix G assume [ty]: "G be FunctionFUNCT-1M1"
  assume A1: "(F,G)are-fiberwise-equipotentCLASSES1R2"
  have "rngFUNCT-1K2 F c=TARSKIR1 rngFUNCT-1K2 G & rngFUNCT-1K2 G c=TARSKIR1 rngFUNCT-1K2 F"
  proof(rule conjMI)
    show "rngFUNCT-1K2 F c=TARSKIR1 rngFUNCT-1K2 G"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F &  not x inHIDDENR3 rngFUNCT-1K2 G implies  False "
      proof(rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 rngFUNCT-1K2 F"
          and A3: " not x inHIDDENR3 rngFUNCT-1K2 G"
        have A4: "cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
          using A1 sorry
        have A5: " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 F & F .FUNCT-1K1 y =HIDDENR1 x"
          using A2 funct_1_def_3 sorry
        have "CoimRELAT-1K13(G,x) =XBOOLE-0R4 {}XBOOLE-0K1"
          using A3 classes1_lm_3 sorry
        then have "x inHIDDENR3 {TARSKIK1 x} & F \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
          using A4 card_1_th_5 card_1_th_26 tarski_def_1 sorry
        thus " False "
          using A5 funct_1_def_7 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 F c=TARSKIR1 rngFUNCT-1K2 G"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 G &  not x inHIDDENR3 rngFUNCT-1K2 F implies  False "
    proof(rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 rngFUNCT-1K2 G"
        and A7: " not x inHIDDENR3 rngFUNCT-1K2 F"
      have A8: "cardCARD-1K1 (CoimRELAT-1K13(G,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(F,x))"
        using A1 sorry
      have A9: " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 G & G .FUNCT-1K1 y =HIDDENR1 x"
        using A6 funct_1_def_3 sorry
      have "CoimRELAT-1K13(F,x) =XBOOLE-0R4 {}XBOOLE-0K1"
        using A7 classes1_lm_3 sorry
      then have "x inHIDDENR3 {TARSKIK1 x} & CoimRELAT-1K13(G,x) =XBOOLE-0R4 {}XBOOLE-0K1"
        using A8 card_1_th_5 card_1_th_26 tarski_def_1 sorry
      thus " False "
        using A9 funct_1_def_7 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 G c=TARSKIR1 rngFUNCT-1K2 F"
      using tarski_def_3 sorry
  qed
  thus "rngFUNCT-1K2 F =XBOOLE-0R4 rngFUNCT-1K2 G"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem classes1_th_76:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds  for H be FunctionFUNCT-1M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 & (F,H)are-fiberwise-equipotentCLASSES1R2 implies (G,H)are-fiberwise-equipotentCLASSES1R2"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix F assume [ty]: "F be FunctionFUNCT-1M1"
  fix G assume [ty]: "G be FunctionFUNCT-1M1"
  fix H assume [ty]: "H be FunctionFUNCT-1M1"
  assume A1: "(F,G)are-fiberwise-equipotentCLASSES1R2"
    and A2: "(F,H)are-fiberwise-equipotentCLASSES1R2"
  have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(G,x)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(H,x))"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have "cardCARD-1K1 (CoimRELAT-1K13(G,x)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(F,x))"
      using A1 sorry
    also have "... = cardCARD-1K1 (CoimRELAT-1K13(H,x))"
      using A2 sorry
    finally show "cardCARD-1K1 (CoimRELAT-1K13(G,x)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(H,x))"
       sorry
  qed "sorry"
  thus "(G,H)are-fiberwise-equipotentCLASSES1R2"
    using classes1_def_10 sorry
qed "sorry"

mtheorem classes1_th_77:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 iff ( ex H be FunctionFUNCT-1M1 st ((domRELAT-1K1 H =XBOOLE-0R4 domRELAT-1K1 F & rngFUNCT-1K2 H =XBOOLE-0R4 domRELAT-1K1 G) & H be one-to-oneFUNCT-1V2) & F =FUNCT-1R1 G *FUNCT-1K3 H)"
proof-
  have " for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds ((F,G)are-fiberwise-equipotentCLASSES1R2 implies ( ex H be FunctionFUNCT-1M1 st ((domRELAT-1K1 H =XBOOLE-0R4 domRELAT-1K1 F & rngFUNCT-1K2 H =XBOOLE-0R4 domRELAT-1K1 G) & H be one-to-oneFUNCT-1V2) & F =FUNCT-1R1 G *FUNCT-1K3 H)) & (( ex H be FunctionFUNCT-1M1 st ((domRELAT-1K1 H =XBOOLE-0R4 domRELAT-1K1 F & rngFUNCT-1K2 H =XBOOLE-0R4 domRELAT-1K1 G) & H be one-to-oneFUNCT-1V2) & F =FUNCT-1R1 G *FUNCT-1K3 H) implies (F,G)are-fiberwise-equipotentCLASSES1R2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix G assume [ty]: "G be FunctionFUNCT-1M1"
    show "(F,G)are-fiberwise-equipotentCLASSES1R2 implies ( ex H be FunctionFUNCT-1M1 st ((domRELAT-1K1 H =XBOOLE-0R4 domRELAT-1K1 F & rngFUNCT-1K2 H =XBOOLE-0R4 domRELAT-1K1 G) & H be one-to-oneFUNCT-1V2) & F =FUNCT-1R1 G *FUNCT-1K3 H)"
    proof-
      have "(F,G)are-fiberwise-equipotentCLASSES1R2 implies ( ex tVar17 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar17 =XBOOLE-0R4 domRELAT-1K1 F & (rngFUNCT-1K2 tVar17 =XBOOLE-0R4 domRELAT-1K1 G & (tVar17 be one-to-oneFUNCT-1V2 & F =FUNCT-1R1 G *FUNCT-1K3 tVar17)))"
      proof(rule impI)
        assume A1: "(F,G)are-fiberwise-equipotentCLASSES1R2"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 be FunctionFUNCT-1M1 & ( for f be FunctionFUNCT-1M1 holds Lamb2 =HIDDENR1 f implies (domRELAT-1K1 f =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 Lamb1} & rngFUNCT-1K2 f =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 Lamb1}) & f be one-to-oneFUNCT-1V2)"
        have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies ( ex y be objectHIDDENM1 st ?P(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies ( ex tVar15 be objectHIDDENM1 st tVar15 be FunctionFUNCT-1M1 & ( for g be FunctionFUNCT-1M1 holds g =FUNCT-1R1 tVar15 implies (domRELAT-1K1 g =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 x} & rngFUNCT-1K2 g =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 x}) & g be one-to-oneFUNCT-1V2))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 F"
            have "cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
              using A1 sorry
            then obtain H where
              [ty]:"H be FunctionFUNCT-1M1" and 
              A3: "(H be one-to-oneFUNCT-1V2 & domRELAT-1K1 H =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 x}) & rngFUNCT-1K2 H =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              using wellord2_def_4 card_1_th_5 sorry
            show " ex tVar15 be objectHIDDENM1 st tVar15 be FunctionFUNCT-1M1 & ( for g be FunctionFUNCT-1M1 holds g =FUNCT-1R1 tVar15 implies (domRELAT-1K1 g =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 x} & rngFUNCT-1K2 g =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 x}) & g be one-to-oneFUNCT-1V2)"
            proof(rule bexI[of _ "H"],rule conjMI,rule ballI,rule impI)
              show "H be FunctionFUNCT-1M1"
                 sorry
              fix g assume [ty]: "g be FunctionFUNCT-1M1"
              assume "g =FUNCT-1R1 H"
              thus "(domRELAT-1K1 g =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 x} & rngFUNCT-1K2 g =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 x}) & g be one-to-oneFUNCT-1V2"
                using A3 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain W where
          [ty]:"W be FunctionFUNCT-1M1" and 
          A4: "domRELAT-1K1 W =XBOOLE-0R4 rngFUNCT-1K2 F & ( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies ?P(x,W .FUNCT-1K1 x))"
          using classes1_sch_1 A2 sorry
        let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  for H be FunctionFUNCT-1M1 holds H =XBOOLE-0R4 W .FUNCT-1K1 (F .FUNCT-1K1 Lamb1) implies Lamb2 =HIDDENR1 H .FUNCT-1K1 Lamb1"
        let ?df = "domRELAT-1K1 F"
        let ?dg = "domRELAT-1K1 G"
        have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 ?df implies ( ex y be objectHIDDENM1 st y inHIDDENR3 ?dg & ?Q(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies ( ex y be setHIDDENM2 st y inTARSKIR2 domRELAT-1K1 G & ( for g be FunctionFUNCT-1M1 holds g =XBOOLE-0R4 W .FUNCT-1K1 (F .FUNCT-1K1 x) implies y =HIDDENR1 g .FUNCT-1K1 x))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A6: "x inHIDDENR3 ?df"
            then have A7: "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
              using funct_1_def_3 sorry
            then obtain f where 
              [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = W .FUNCT-1K1 (F .FUNCT-1K1 x)"
              using A4 sorry
            have A8: "domRELAT-1K1 f =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x } & rngFUNCT-1K2 f =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
              using A4 A7 sorry
            obtain y where 
              [ty]:"y be setHIDDENM2" and yDef:"y = f .FUNCT-1K1 x"
               sorry
            show " ex y be setHIDDENM2 st y inTARSKIR2 domRELAT-1K1 G & ( for g be FunctionFUNCT-1M1 holds g =XBOOLE-0R4 W .FUNCT-1K1 (F .FUNCT-1K1 x) implies y =HIDDENR1 g .FUNCT-1K1 x)"
            proof(rule bexI[of _ "y"],rule conjMI,rule ballI,rule impI)
              have "F .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 x }"
                using tarski_def_1 sorry
              then have "x inHIDDENR3 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
                using A6 funct_1_def_7 sorry
              then have "f .FUNCT-1K1 x inTARSKIR2 G \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
                using A8 funct_1_def_3 sorry
              thus "y inTARSKIR2 domRELAT-1K1 G"
                using funct_1_def_7 sorry
              fix g assume [ty]: "g be FunctionFUNCT-1M1"
              assume "g =XBOOLE-0R4 W .FUNCT-1K1 (F .FUNCT-1K1 x)"
              thus "y =HIDDENR1 g .FUNCT-1K1 x"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain IT where
          [ty]:"IT be FunctionFUNCT-1M1" and 
          A9: "(domRELAT-1K1 IT =XBOOLE-0R4 ?df & rngFUNCT-1K2 IT c=TARSKIR1 ?dg) & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?df implies ?Q(x,IT .FUNCT-1K1 x))"
          using funct_1_sch_6 A5 sorry
        show " ex tVar17 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar17 =XBOOLE-0R4 domRELAT-1K1 F & (rngFUNCT-1K2 tVar17 =XBOOLE-0R4 domRELAT-1K1 G & (tVar17 be one-to-oneFUNCT-1V2 & F =FUNCT-1R1 G *FUNCT-1K3 tVar17))"
        proof(rule bexI[of _ "IT"],rule conjMI,rule conjMI,rule conjMI)
          show "domRELAT-1K1 IT =XBOOLE-0R4 domRELAT-1K1 F"
            using A9 sorry
          have "domRELAT-1K1 G c=TARSKIR1 rngFUNCT-1K2 IT"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 G implies x inHIDDENR3 rngFUNCT-1K2 IT"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A10: "x inHIDDENR3 ?dg"
              then have A11: "G .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 G"
                using funct_1_def_3 sorry
              have A12: "rngFUNCT-1K2 F =XBOOLE-0R4 rngFUNCT-1K2 G"
                using A1 classes1_th_75 sorry
              then obtain f where 
                [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = W .FUNCT-1K1 (G .FUNCT-1K1 x)"
                using A4 A11 sorry
              have A13: "domRELAT-1K1 f =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 G .FUNCT-1K1 x }"
                using A4 A11 A12 sorry
              have A14: "rngFUNCT-1K2 f =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 G .FUNCT-1K1 x }"
                using A4 A11 A12 sorry
              have "G .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 G .FUNCT-1K1 x }"
                using tarski_def_1 sorry
              then have "x inHIDDENR3 rngFUNCT-1K2 f"
                using A10 A14 funct_1_def_7 sorry
              then obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A15: "z inHIDDENR3 domRELAT-1K1 f"and A16: "f .FUNCT-1K1 z =HIDDENR1 x"
                using funct_1_def_3 sorry
              have A17: "z inHIDDENR3 ?df"
                using A13 A15 funct_1_def_7 sorry
              have "F .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 G .FUNCT-1K1 x }"
                using A13 A15 funct_1_def_7 sorry
              then have "F .FUNCT-1K1 z =XBOOLE-0R4 G .FUNCT-1K1 x"
                using tarski_def_1 sorry
              then have "IT .FUNCT-1K1 z =HIDDENR1 x"
                using A9 A16 A17 sorry
              thus "x inHIDDENR3 rngFUNCT-1K2 IT"
                using A9 A17 funct_1_def_3 sorry
            qed "sorry"
            thus "domRELAT-1K1 G c=TARSKIR1 rngFUNCT-1K2 IT"
              using tarski_def_3 sorry
          qed
          thus "rngFUNCT-1K2 IT =XBOOLE-0R4 domRELAT-1K1 G"
            using A9 sorry
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 IT & (y inHIDDENR3 domRELAT-1K1 IT & IT .FUNCT-1K1 x =XBOOLE-0R4 IT .FUNCT-1K1 y) implies x =HIDDENR1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A18: "x inHIDDENR3 domRELAT-1K1 IT"
              and A19: "y inHIDDENR3 domRELAT-1K1 IT"
              and A20: "IT .FUNCT-1K1 x =XBOOLE-0R4 IT .FUNCT-1K1 y"
            have A21: "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
              using A9 A18 funct_1_def_3 sorry
            have A22: "F .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 F"
              using A9 A19 funct_1_def_3 sorry
            then obtain f1 f2 where 
              [ty]:"f1 be FunctionFUNCT-1M1" and f1Def:"f1 = W .FUNCT-1K1 (F .FUNCT-1K1 x)" and
              [ty]:"f2 be FunctionFUNCT-1M1" and f2Def:"f2 = W .FUNCT-1K1 (F .FUNCT-1K1 y)"
              using A4 A21 sorry
            have A23: "IT .FUNCT-1K1 x =XBOOLE-0R4 f1 .FUNCT-1K1 x & IT .FUNCT-1K1 y =XBOOLE-0R4 f2 .FUNCT-1K1 y"
              using A9 A18 A19 sorry
            have A24: "domRELAT-1K1 f1 =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
              using A4 A21 sorry
            have A25: "rngFUNCT-1K2 f1 =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
              using A4 A21 sorry
            have A26: "f1 be one-to-oneFUNCT-1V2"
              using A4 A21 sorry
            have A27: "domRELAT-1K1 f2 =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 y }"
              using A4 A22 sorry
            have A28: "rngFUNCT-1K2 f2 =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 y }"
              using A4 A22 sorry
            have A29: "F .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 x }"
              using tarski_def_1 sorry
            have A30: "F .FUNCT-1K1 y inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 y }"
              using tarski_def_1 sorry
            have A31: "x inHIDDENR3 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
              using A9 A18 A29 funct_1_def_7 sorry
            have A32: "y inHIDDENR3 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 y }"
              using A9 A19 A30 funct_1_def_7 sorry
            have A33: "f1 .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f1"
              using A24 A31 funct_1_def_3 sorry
            have "f2 .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 f2"
              using A27 A32 funct_1_def_3 sorry
            then have "f1 .FUNCT-1K1 x inTARSKIR2 G \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x } /\\XBOOLE-0K3 G \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 y }"
              using A20 A23 A25 A28 A33 xboole_0_def_4 sorry
            then have "f1 .FUNCT-1K1 x inTARSKIR2 G \<inverse>FUNCT-1K6 ({TARSKIK1 F .FUNCT-1K1 x } /\\XBOOLE-0K3 {TARSKIK1 F .FUNCT-1K1 y })"
              using funct_1_th_68 sorry
            then have A34: "G .FUNCT-1K1 (f1 .FUNCT-1K1 x) inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 x } /\\XBOOLE-0K3 {TARSKIK1 F .FUNCT-1K1 y }"
              using funct_1_def_7 sorry
            then have A35: "G .FUNCT-1K1 (f1 .FUNCT-1K1 x) inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 x }"
              using xboole_0_def_4 sorry
            have A36: "G .FUNCT-1K1 (f1 .FUNCT-1K1 x) inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 y }"
              using A34 xboole_0_def_4 sorry
            have A37: "G .FUNCT-1K1 (f1 .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 x"
              using A35 tarski_def_1 sorry
            have "G .FUNCT-1K1 (f1 .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 y"
              using A36 tarski_def_1 sorry
            thus "x =HIDDENR1 y"
              using A20 A23 A24 A26 A31 A32 A37 sorry
          qed "sorry"
          thus "IT be one-to-oneFUNCT-1V2"
             sorry
          have A38: "domRELAT-1K1 (G *FUNCT-1K3 IT) =XBOOLE-0R4 ?df"
            using A9 relat_1_th_27 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x =XBOOLE-0R4 (G *FUNCT-1K3 IT).FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A39: "x inHIDDENR3 ?df"
            then have A40: "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
              using funct_1_def_3 sorry
            then obtain f where 
              [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = W .FUNCT-1K1 (F .FUNCT-1K1 x)"
              using A4 sorry
            have A41: "domRELAT-1K1 f =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x } & rngFUNCT-1K2 f =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
              using A4 A40 sorry
            have "F .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 x }"
              using tarski_def_1 sorry
            then have "x inHIDDENR3 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
              using A39 funct_1_def_7 sorry
            then have "f .FUNCT-1K1 x inTARSKIR2 G \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
              using A41 funct_1_def_3 sorry
            then have "G .FUNCT-1K1 (f .FUNCT-1K1 x) inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 x }"
              using funct_1_def_7 sorry
            then have A42: "G .FUNCT-1K1 (f .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 x"
              using tarski_def_1 sorry
            have "IT .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
              using A9 A39 sorry
            thus "F .FUNCT-1K1 x =XBOOLE-0R4 (G *FUNCT-1K3 IT).FUNCT-1K1 x"
              using A9 A39 A42 funct_1_th_13 sorry
          qed "sorry"
          thus "F =FUNCT-1R1 G *FUNCT-1K3 IT"
            using A38 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex H be FunctionFUNCT-1M1 st ((domRELAT-1K1 H =XBOOLE-0R4 domRELAT-1K1 F & rngFUNCT-1K2 H =XBOOLE-0R4 domRELAT-1K1 G) & H be one-to-oneFUNCT-1V2) & F =FUNCT-1R1 G *FUNCT-1K3 H"
    then obtain H where
      [ty]:"H be FunctionFUNCT-1M1" and 
      A43: "domRELAT-1K1 H =XBOOLE-0R4 domRELAT-1K1 F"and A44: "rngFUNCT-1K2 H =XBOOLE-0R4 domRELAT-1K1 G"and A45: "H be one-to-oneFUNCT-1V2"and A46: "F =FUNCT-1R1 G *FUNCT-1K3 H"
       sorry
    have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      let ?t = "H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      have A47: "?t be one-to-oneFUNCT-1V2"
        using A45 funct_1_th_52 sorry
      have A48: "domRELAT-1K1 ?t =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 x}"
        using A43 relat_1_th_62 relat_1_th_132 sorry
      have "rngFUNCT-1K2 ?t =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
      proof-
        have "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x}) =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
        proof-
          have "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x}) c=TARSKIR1 G \<inverse>FUNCT-1K6 {TARSKIK1 x} & G \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x})"
          proof(rule conjMI)
            show "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x}) c=TARSKIR1 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x}) implies z inHIDDENR3 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 rngFUNCT-1K2 ?t"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A49: "y inHIDDENR3 domRELAT-1K1 ?t"and A50: "?t .FUNCT-1K1 y =HIDDENR1 z"
                  using funct_1_def_3 sorry
                have "F .FUNCT-1K1 y inTARSKIR2 {TARSKIK1 x}"
                  using A48 A49 funct_1_def_7 sorry
                then have A51: "F .FUNCT-1K1 y =HIDDENR1 x"
                  using tarski_def_1 sorry
                have A52: "z =HIDDENR1 H .FUNCT-1K1 y"
                  using A49 A50 funct_1_th_47 sorry
                have "domRELAT-1K1 ?t =XBOOLE-0R4 domRELAT-1K1 H /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                  using relat_1_th_61 sorry
                then have A53: "y inHIDDENR3 domRELAT-1K1 H"
                  using A49 xboole_0_def_4 sorry
                then have A54: "z inHIDDENR3 domRELAT-1K1 G"
                  using A44 A52 funct_1_def_3 sorry
                have "x =HIDDENR1 G .FUNCT-1K1 z"
                  using A46 A51 A52 A53 funct_1_th_13 sorry
                then have "G .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x}"
                  using tarski_def_1 sorry
                thus "z inHIDDENR3 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                  using A54 funct_1_def_7 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x}) c=TARSKIR1 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
                using tarski_def_3 sorry
            qed
            have " for z be objectHIDDENM1 holds z inHIDDENR3 G \<inverse>FUNCT-1K6 {TARSKIK1 x} implies z inHIDDENR3 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x})"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume A55: "z inHIDDENR3 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              then have A56: "z inHIDDENR3 domRELAT-1K1 G"
                using funct_1_def_7 sorry
              have "G .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 x}"
                using A55 funct_1_def_7 sorry
              then have A57: "G .FUNCT-1K1 z =HIDDENR1 x"
                using tarski_def_1 sorry
              obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A58: "y inHIDDENR3 domRELAT-1K1 H"and A59: "H .FUNCT-1K1 y =HIDDENR1 z"
                using A44 A56 funct_1_def_3 sorry
              have "F .FUNCT-1K1 y =HIDDENR1 x"
                using A46 A57 A58 A59 funct_1_th_13 sorry
              then have "F .FUNCT-1K1 y inTARSKIR2 {TARSKIK1 x}"
                using tarski_def_1 sorry
              then have A60: "y inHIDDENR3 domRELAT-1K1 ?t"
                using A43 A48 A58 funct_1_def_7 sorry
              then have "?t .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 ?t"
                using funct_1_def_3 sorry
              thus "z inHIDDENR3 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x})"
                using A59 A60 funct_1_th_47 sorry
            qed "sorry"
            thus "G \<inverse>FUNCT-1K6 {TARSKIK1 x} c=TARSKIR1 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x})"
              using tarski_def_3 sorry
          qed
          thus "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 {TARSKIK1 x}) =XBOOLE-0R4 G \<inverse>FUNCT-1K6 {TARSKIK1 x}"
            using xboole_0_def_10 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
        using card_1_th_5 A47 A48 wellord2_def_4 sorry
    qed "sorry"
    thus "(F,G)are-fiberwise-equipotentCLASSES1R2"
      using classes1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_78:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 iff ( for X be setHIDDENM2 holds cardCARD-1K1 (F \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 cardCARD-1K1 (G \<inverse>FUNCT-1K6 X))"
proof-
  have " for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds ((F,G)are-fiberwise-equipotentCLASSES1R2 implies ( for X be setHIDDENM2 holds cardCARD-1K1 (F \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 cardCARD-1K1 (G \<inverse>FUNCT-1K6 X))) & (( for X be setHIDDENM2 holds cardCARD-1K1 (F \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 cardCARD-1K1 (G \<inverse>FUNCT-1K6 X)) implies (F,G)are-fiberwise-equipotentCLASSES1R2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix G assume [ty]: "G be FunctionFUNCT-1M1"
    show "(F,G)are-fiberwise-equipotentCLASSES1R2 implies ( for X be setHIDDENM2 holds cardCARD-1K1 (F \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 cardCARD-1K1 (G \<inverse>FUNCT-1K6 X))"
    proof(rule impI,rule ballI)
      assume "(F,G)are-fiberwise-equipotentCLASSES1R2"
      then obtain H where
        [ty]:"H be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 H =XBOOLE-0R4 domRELAT-1K1 F"and A2: "rngFUNCT-1K2 H =XBOOLE-0R4 domRELAT-1K1 G"and A3: "H be one-to-oneFUNCT-1V2"and A4: "F =FUNCT-1R1 G *FUNCT-1K3 H"
        using classes1_th_77 sorry
      fix X assume [ty]: "X be setHIDDENM2"
      let ?t = "H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X"
      have A5: "?t be one-to-oneFUNCT-1V2"
        using A3 funct_1_th_52 sorry
      have A6: "domRELAT-1K1 ?t =XBOOLE-0R4 F \<inverse>FUNCT-1K6 X"
        using A1 relat_1_th_62 relat_1_th_132 sorry
      have "rngFUNCT-1K2 ?t =XBOOLE-0R4 G \<inverse>FUNCT-1K6 X"
      proof-
        have "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 G \<inverse>FUNCT-1K6 X"
        proof-
          have "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X) c=TARSKIR1 G \<inverse>FUNCT-1K6 X & G \<inverse>FUNCT-1K6 X c=TARSKIR1 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X)"
          proof(rule conjMI)
            show "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X) c=TARSKIR1 G \<inverse>FUNCT-1K6 X"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X) implies z inHIDDENR3 G \<inverse>FUNCT-1K6 X"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 rngFUNCT-1K2 ?t"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A7: "y inHIDDENR3 domRELAT-1K1 ?t"and A8: "?t .FUNCT-1K1 y =HIDDENR1 z"
                  using funct_1_def_3 sorry
                have A9: "F .FUNCT-1K1 y inTARSKIR2 X"
                  using A6 A7 funct_1_def_7 sorry
                have A10: "z =HIDDENR1 H .FUNCT-1K1 y"
                  using A7 A8 funct_1_th_47 sorry
                have "domRELAT-1K1 ?t =XBOOLE-0R4 domRELAT-1K1 H /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X"
                  using relat_1_th_61 sorry
                then have A11: "y inHIDDENR3 domRELAT-1K1 H"
                  using A7 xboole_0_def_4 sorry
                then have A12: "z inHIDDENR3 domRELAT-1K1 G"
                  using A2 A10 funct_1_def_3 sorry
                have "G .FUNCT-1K1 z inTARSKIR2 X"
                  using A4 A9 A10 A11 funct_1_th_13 sorry
                thus "z inHIDDENR3 G \<inverse>FUNCT-1K6 X"
                  using A12 funct_1_def_7 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X) c=TARSKIR1 G \<inverse>FUNCT-1K6 X"
                using tarski_def_3 sorry
            qed
            have " for z be objectHIDDENM1 holds z inHIDDENR3 G \<inverse>FUNCT-1K6 X implies z inHIDDENR3 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X)"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume A13: "z inHIDDENR3 G \<inverse>FUNCT-1K6 X"
              then have A14: "z inHIDDENR3 domRELAT-1K1 G"
                using funct_1_def_7 sorry
              have A15: "G .FUNCT-1K1 z inTARSKIR2 X"
                using A13 funct_1_def_7 sorry
              obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A16: "y inHIDDENR3 domRELAT-1K1 H"and A17: "H .FUNCT-1K1 y =HIDDENR1 z"
                using A2 A14 funct_1_def_3 sorry
              have "F .FUNCT-1K1 y inTARSKIR2 X"
                using A4 A15 A16 A17 funct_1_th_13 sorry
              then have A18: "y inHIDDENR3 domRELAT-1K1 ?t"
                using A1 A6 A16 funct_1_def_7 sorry
              then have "?t .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 ?t"
                using funct_1_def_3 sorry
              thus "z inHIDDENR3 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X)"
                using A17 A18 funct_1_th_47 sorry
            qed "sorry"
            thus "G \<inverse>FUNCT-1K6 X c=TARSKIR1 rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X)"
              using tarski_def_3 sorry
          qed
          thus "rngFUNCT-1K2 (H  |RELAT-1K8 F \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 G \<inverse>FUNCT-1K6 X"
            using xboole_0_def_10 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "cardCARD-1K1 (F \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 cardCARD-1K1 (G \<inverse>FUNCT-1K6 X)"
        using card_1_th_5 A5 A6 wellord2_def_4 sorry
    qed "sorry"
    assume Cut2346: " for X be setHIDDENM2 holds cardCARD-1K1 (F \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 cardCARD-1K1 (G \<inverse>FUNCT-1K6 X)"
    have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
    proof-
      show " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
        using Cut2346 sorry
    qed
    thus "(F,G)are-fiberwise-equipotentCLASSES1R2"
      using classes1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_79:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds (rngFUNCT-1K2 F c=TARSKIR1 D & rngFUNCT-1K2 G c=TARSKIR1 D) & ( for d be ElementSUBSET-1M1-of D holds cardCARD-1K1 (CoimRELAT-1K13(F,d)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,d))) implies (F,G)are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds rngFUNCT-1K2 F c=TARSKIR1 D & rngFUNCT-1K2 G c=TARSKIR1 D implies (( for d be ElementSUBSET-1M1-of D holds cardCARD-1K1 (CoimRELAT-1K13(F,d)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,d))) implies (F,G)are-fiberwise-equipotentCLASSES1R2)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix G assume [ty]: "G be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 F c=TARSKIR1 D"
      and A2: "rngFUNCT-1K2 G c=TARSKIR1 D"
    assume A3: " for d be ElementSUBSET-1M1-of D holds cardCARD-1K1 (CoimRELAT-1K13(F,d)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,d))"
    have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
      proof-
        have cases: " not x inHIDDENR3 rngFUNCT-1K2 F or x inHIDDENR3 rngFUNCT-1K2 F"
           sorry
        have case1: " not x inHIDDENR3 rngFUNCT-1K2 F implies cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
        proof(rule impI)
          assume " not x inHIDDENR3 rngFUNCT-1K2 F"
          then have A4: "CoimRELAT-1K13(F,x) =XBOOLE-0R4 {}XBOOLE-0K1"
            using classes1_lm_3 sorry
          have "x inHIDDENR3 rngFUNCT-1K2 G implies  False "
          proof(rule impI)
            assume A5: "x inHIDDENR3 rngFUNCT-1K2 G"
            then obtain d where 
              [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
              using A2 sorry
            have "cardCARD-1K1 (CoimRELAT-1K13(G,d)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(F,d))"
              using A3 sorry
            then have A6: "G \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
              using A4 card_1_th_5 card_1_th_26 sorry
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A7: "y inHIDDENR3 domRELAT-1K1 G"and A8: "G .FUNCT-1K1 y =HIDDENR1 x"
              using A5 funct_1_def_3 sorry
            have "G .FUNCT-1K1 y inTARSKIR2 {TARSKIK1 x}"
              using A8 tarski_def_1 sorry
            thus " False "
              using A6 A7 funct_1_def_7 sorry
          qed
          thus "cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
            using A4 classes1_lm_3 sorry
        qed
        have case2: "x inHIDDENR3 rngFUNCT-1K2 F implies cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
        proof(rule impI)
          assume "x inHIDDENR3 rngFUNCT-1K2 F"
          then obtain d where 
            [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
            using A1 sorry
          have "cardCARD-1K1 (CoimRELAT-1K13(F,d)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,d))"
            using A3 sorry
          thus "cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "(F,G)are-fiberwise-equipotentCLASSES1R2"
      using classes1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_80:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G implies ((F,G)are-fiberwise-equipotentCLASSES1R2 iff ( ex P be PermutationFUNCT-2M2-of domRELAT-1K1 F st F =FUNCT-1R1 G *FUNCT-1K3 P))"
proof-
  have " for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G implies ((F,G)are-fiberwise-equipotentCLASSES1R2 implies ( ex P be PermutationFUNCT-2M2-of domRELAT-1K1 F st F =FUNCT-1R1 G *FUNCT-1K3 P)) & (( ex P be PermutationFUNCT-2M2-of domRELAT-1K1 F st F =FUNCT-1R1 G *FUNCT-1K3 P) implies (F,G)are-fiberwise-equipotentCLASSES1R2)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix G assume [ty]: "G be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G"
    show "(F,G)are-fiberwise-equipotentCLASSES1R2 implies ( ex P be PermutationFUNCT-2M2-of domRELAT-1K1 F st F =FUNCT-1R1 G *FUNCT-1K3 P)"
    proof-
      have "(F,G)are-fiberwise-equipotentCLASSES1R2 implies ( ex tVar18 be PermutationFUNCT-2M2-of domRELAT-1K1 F st F =FUNCT-1R1 G *FUNCT-1K3 tVar18)"
      proof(rule impI)
        assume "(F,G)are-fiberwise-equipotentCLASSES1R2"
        then obtain I where
          [ty]:"I be FunctionFUNCT-1M1" and 
          A2: "domRELAT-1K1 I =XBOOLE-0R4 domRELAT-1K1 F"and A3: "rngFUNCT-1K2 I =XBOOLE-0R4 domRELAT-1K1 G"and A4: "I be one-to-oneFUNCT-1V2"and A5: "F =FUNCT-1R1 G *FUNCT-1K3 I"
          using classes1_th_77 sorry
        have 
          [ty]:"I be FunctionFUNCT-2M1-of(domRELAT-1K1 F,domRELAT-1K1 F)"
          using A1 A2 A3 funct_2_th_2 sorry
        have 
          [ty]:"I be PermutationFUNCT-2M2-of domRELAT-1K1 F"
          using A1 A3 A4 funct_2_th_57 sorry
        show " ex tVar18 be PermutationFUNCT-2M2-of domRELAT-1K1 F st F =FUNCT-1R1 G *FUNCT-1K3 tVar18"
        proof(rule bexI[of _ "I"])
          show "F =FUNCT-1R1 G *FUNCT-1K3 I"
            using A5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex P be PermutationFUNCT-2M2-of domRELAT-1K1 F st F =FUNCT-1R1 G *FUNCT-1K3 P"
    then obtain P where
      [ty]:"P be PermutationFUNCT-2M2-of domRELAT-1K1 F" and 
      A6: "F =FUNCT-1R1 G *FUNCT-1K3 P"
       sorry
    have "P be FunctionFUNCT-2M1-of(domRELAT-1K1 F,domRELAT-1K1 F) & domRELAT-1K1 F =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELAT-1K1 F =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    then have "rngFUNCT-1K2 P =XBOOLE-0R4 domRELAT-1K1 F & domRELAT-1K1 P =XBOOLE-0R4 domRELAT-1K1 F"
      using funct_2_def_1 funct_2_def_3 sorry
    thus "(F,G)are-fiberwise-equipotentCLASSES1R2"
      using A1 A6 classes1_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_81:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies cardCARD-1K1 (domRELAT-1K1 F) =XBOOLE-0R4 cardCARD-1K1 (domRELAT-1K1 G)"
proof-
  have " for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies cardCARD-1K1 (domRELAT-1K1 F) =HIDDENR1 cardCARD-1K1 (domRELAT-1K1 G)"
  proof(rule ballI,rule ballI,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix G assume [ty]: "G be FunctionFUNCT-1M1"
    assume "(F,G)are-fiberwise-equipotentCLASSES1R2"
    then have "cardCARD-1K1 (F \<inverse>FUNCT-1K6 (rngFUNCT-1K2 F)) =XBOOLE-0R4 cardCARD-1K1 (G \<inverse>FUNCT-1K6 (rngFUNCT-1K2 F)) & rngFUNCT-1K2 F =XBOOLE-0R4 rngFUNCT-1K2 G"
      using classes1_th_75 classes1_th_78 sorry
    then have "cardCARD-1K1 (domRELAT-1K1 F) =HIDDENR1 cardCARD-1K1 (G \<inverse>FUNCT-1K6 (rngFUNCT-1K2 G))"
      using relat_1_th_134 sorry
    also have "... = cardCARD-1K1 (domRELAT-1K1 G)"
      using relat_1_th_134 sorry
    finally show "cardCARD-1K1 (domRELAT-1K1 F) =HIDDENR1 cardCARD-1K1 (domRELAT-1K1 G)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_82:
" for f be setHIDDENM2 holds  for p be RelationRELAT-1M1 holds  for x be setHIDDENM2 holds x inTARSKIR2 rngRELAT-1K2 p implies the-rank-ofCLASSES1K7 x inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 p,f ]"
proof-
  have " for f be setHIDDENM2 holds  for p be RelationRELAT-1M1 holds  for y be setHIDDENM2 holds y inTARSKIR2 rngRELAT-1K2 p implies the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 p,f ]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be setHIDDENM2"
    fix p assume [ty]: "p be RelationRELAT-1M1"
    fix y assume [ty]: "y be setHIDDENM2"
    assume "y inTARSKIR2 rngRELAT-1K2 p"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "[TARSKIK4 x,y ] inHIDDENR3 p"
      using xtuple_0_def_13 sorry
    have A2: "p inTARSKIR2 {TARSKIK2 p,f }"
      using tarski_def_2 sorry
    have A3: "{TARSKIK2 p,f } inTARSKIR2 {TARSKIK2 {TARSKIK2 p,f },{TARSKIK1 p} }"
      using tarski_def_2 sorry
    have A4: "y inTARSKIR2 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    have A5: "{TARSKIK2 x,y } inTARSKIR2 {TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} }"
      using tarski_def_2 sorry
    have A6: "the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K7 {TARSKIK2 x,y }"
      using A4 classes1_th_68 sorry
    have A7: "the-rank-ofCLASSES1K7 {TARSKIK2 x,y } inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 x,y ]"
      using A5 classes1_th_68 sorry
    have A8: "the-rank-ofCLASSES1K7 p inTARSKIR2 the-rank-ofCLASSES1K7 {TARSKIK2 p,f }"
      using A2 classes1_th_68 sorry
    have A9: "the-rank-ofCLASSES1K7 {TARSKIK2 p,f } inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 p,f ]"
      using A3 classes1_th_68 sorry
    have A10: "the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 x,y ]"
      using A6 A7 ordinal1_th_10 sorry
    have A11: "the-rank-ofCLASSES1K6 [TARSKIK4 x,y ] inTARSKIR2 the-rank-ofCLASSES1K7 p"
      using A1 classes1_th_68 sorry
    have A12: "the-rank-ofCLASSES1K7 p inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 p,f ]"
      using A8 A9 ordinal1_th_10 sorry
    have "the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K7 p"
      using A10 A11 ordinal1_th_10 sorry
    thus "the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 p,f ]"
      using A12 ordinal1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes1_th_83:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 h) & rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 h) & (f,g)are-fiberwise-equipotentCLASSES1R2 implies (h *FUNCT-1K3 f,h *FUNCT-1K3 g)are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & (rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 h & (rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 h & (f,g)are-fiberwise-equipotentCLASSES1R2)) implies (h *FUNCT-1K3 f,h *FUNCT-1K3 g)are-fiberwise-equipotentCLASSES1R2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 h"
      and A3: "rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 h"
      and A4: "(f,g)are-fiberwise-equipotentCLASSES1R2"
    obtain p where
      [ty]:"p be PermutationFUNCT-2M2-of domRELAT-1K1 f" and 
      A5: "f =FUNCT-1R1 g *FUNCT-1K3 p"
      using A1 A4 classes1_th_80 sorry
    have A6: "domRELAT-1K1 (h *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using A2 relat_1_th_27 sorry
    have A7: "domRELAT-1K1 (h *FUNCT-1K3 g) =XBOOLE-0R4 domRELAT-1K1 g"
      using A3 relat_1_th_27 sorry
    have "h *FUNCT-1K3 f =FUNCT-1R1 (h *FUNCT-1K3 g)*FUNCT-1K3 p"
      using A5 relat_1_th_36 sorry
    thus "(h *FUNCT-1K3 f,h *FUNCT-1K3 g)are-fiberwise-equipotentCLASSES1R2"
      using A1 A6 A7 classes1_th_80 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem classes1_sch_2:
  fixes Af0 Bf0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be ElementSUBSET-1M1-of Bf0 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be ElementSUBSET-1M1-of Bf0 holds x inTARSKIR2 Af0 implies f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x))"
  proof-
    have " ex tVar20 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar20 =XBOOLE-0R4 Af0 & ( for x be ElementSUBSET-1M1-of Bf0 holds x inTARSKIR2 Af0 implies tVar20 .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 be ElementSUBSET-1M1-of Bf0 implies ( ex x be ElementSUBSET-1M1-of Bf0 st x =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 Ff1(x))) & ( not Lamb1 be ElementSUBSET-1M1-of Bf0 implies Lamb2 =HIDDENR1 0ORDINAL1K5)"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex tVar19 be objectHIDDENM1 st (x be ElementSUBSET-1M1-of Bf0 implies ( ex xc be ElementSUBSET-1M1-of Bf0 st xc =HIDDENR1 x & tVar19 =HIDDENR1 Ff1(xc))) & ( not x be ElementSUBSET-1M1-of Bf0 implies tVar19 =HIDDENR1 0ORDINAL1K5))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 Af0"
          show " ex tVar19 be objectHIDDENM1 st (x be ElementSUBSET-1M1-of Bf0 implies ( ex xc be ElementSUBSET-1M1-of Bf0 st xc =HIDDENR1 x & tVar19 =HIDDENR1 Ff1(xc))) & ( not x be ElementSUBSET-1M1-of Bf0 implies tVar19 =HIDDENR1 0ORDINAL1K5)"
          proof-
            have cases: "x be ElementSUBSET-1M1-of Bf0 or  not x be ElementSUBSET-1M1-of Bf0"
               sorry
            have case1: "x be ElementSUBSET-1M1-of Bf0 implies ( ex tVar19 be objectHIDDENM1 st (x be ElementSUBSET-1M1-of Bf0 implies ( ex xc be ElementSUBSET-1M1-of Bf0 st xc =HIDDENR1 x & tVar19 =HIDDENR1 Ff1(xc))) & ( not x be ElementSUBSET-1M1-of Bf0 implies tVar19 =HIDDENR1 0ORDINAL1K5))"
            proof(rule impI)
              assume "x be ElementSUBSET-1M1-of Bf0"
              then obtain z where 
                [ty]:"z be ElementSUBSET-1M1-of Bf0" and zDef:"z = x"
                 sorry
              show " ex tVar19 be objectHIDDENM1 st (x be ElementSUBSET-1M1-of Bf0 implies ( ex xc be ElementSUBSET-1M1-of Bf0 st xc =HIDDENR1 x & tVar19 =HIDDENR1 Ff1(xc))) & ( not x be ElementSUBSET-1M1-of Bf0 implies tVar19 =HIDDENR1 0ORDINAL1K5)"
              proof(rule bexI[of _ "Ff1(z)"])
                show "(x be ElementSUBSET-1M1-of Bf0 implies ( ex xc be ElementSUBSET-1M1-of Bf0 st xc =HIDDENR1 x & Ff1(z) =HIDDENR1 Ff1(xc))) & ( not x be ElementSUBSET-1M1-of Bf0 implies Ff1(z) =HIDDENR1 0ORDINAL1K5)"
                   sorry
              qed "sorry"
            qed
            have case2: " not x be ElementSUBSET-1M1-of Bf0 implies  not ( for y be objectHIDDENM1 holds  not ((x be ElementSUBSET-1M1-of Bf0 implies ( ex xc be ElementSUBSET-1M1-of Bf0 st xc =HIDDENR1 x & y =HIDDENR1 Ff1(xc))) & ( not x be ElementSUBSET-1M1-of Bf0 implies y =HIDDENR1 0ORDINAL1K5)))"
            proof(rule impI)
              assume " not x be ElementSUBSET-1M1-of Bf0"
              thus " not ( for y be objectHIDDENM1 holds  not ((x be ElementSUBSET-1M1-of Bf0 implies ( ex xc be ElementSUBSET-1M1-of Bf0 st xc =HIDDENR1 x & y =HIDDENR1 Ff1(xc))) & ( not x be ElementSUBSET-1M1-of Bf0 implies y =HIDDENR1 0ORDINAL1K5)))"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "domRELAT-1K1 f =XBOOLE-0R4 Af0"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ?P(x,f .FUNCT-1K1 x)"
        using classes1_sch_1 A1 sorry
      show " ex tVar20 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar20 =XBOOLE-0R4 Af0 & ( for x be ElementSUBSET-1M1-of Bf0 holds x inTARSKIR2 Af0 implies tVar20 .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
        show "domRELAT-1K1 f =XBOOLE-0R4 Af0"
          using A2 sorry
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Bf0"
        assume "x inTARSKIR2 Af0"
        then have "?P(x,f .FUNCT-1K1 x)"
          using A3 sorry
        thus "f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem classes1_th_84:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds the-rank-ofCLASSES1K7 x inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 x,y ] & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 x,y ]"
proof(rule ballI,rule ballI,rule conjMI)
  fix x assume [ty]: "x be setHIDDENM2"
  fix y assume [ty]: "y be setHIDDENM2"
  have "{TARSKIK1 x} inTARSKIR2 {TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} }"
    using tarski_def_2 sorry
  then have A1: "the-rank-ofCLASSES1K7 {TARSKIK1 x} inTARSKIR2 the-rank-ofCLASSES1K7 {TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} }"
    using classes1_th_68 sorry
  have "x inTARSKIR2 {TARSKIK1 x}"
    using tarski_def_1 sorry
  then have "the-rank-ofCLASSES1K7 x inTARSKIR2 the-rank-ofCLASSES1K7 {TARSKIK1 x}"
    using classes1_th_68 sorry
  thus "the-rank-ofCLASSES1K7 x inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 x,y ]"
    using A1 ordinal1_th_10 sorry
  have "{TARSKIK2 x,y } inTARSKIR2 {TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} }"
    using tarski_def_2 sorry
  then have A2: "the-rank-ofCLASSES1K7 {TARSKIK2 x,y } inTARSKIR2 the-rank-ofCLASSES1K7 {TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} }"
    using classes1_th_68 sorry
  have "y inTARSKIR2 {TARSKIK2 x,y }"
    using tarski_def_2 sorry
  then have "the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K7 {TARSKIK2 x,y }"
    using classes1_th_68 sorry
  thus "the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 [TARSKIK4 x,y ]"
    using A2 ordinal1_th_10 sorry
qed "sorry"

end
