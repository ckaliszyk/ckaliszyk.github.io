theory xxreal_3
  imports xcmplx_1 xxreal_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z, w for "ExtRealXXREAL-0M1"
reserve r for "RealXREAL-0M1"
abbreviation(input) XXREAL_3R1(" _ <=XXREAL-3R1  _ " [50,50]50) where
  "x <=XXREAL-3R1 y \<equiv> x <=XXREAL-0R1 y"

mtheorem xxreal_3_def_1:
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"redefine pred x <=XXREAL-3R1 y means
   ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex q be ElementSUBSET-1M1-of REALNUMBERSK2 st (p =HIDDENR1 x & q =HIDDENR1 y) & p <=XXREAL-0R1 q if x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 otherwise x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
proof
(*compatibility*)
  show "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies (x <=XXREAL-3R1 y iff ( ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex q be ElementSUBSET-1M1-of REALNUMBERSK2 st (p =HIDDENR1 x & q =HIDDENR1 y) & p <=XXREAL-0R1 q))) & ( not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) implies (x <=XXREAL-3R1 y iff x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1))"
  proof-
    have "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies (x <=XXREAL-0R1 y iff ( ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex q be ElementSUBSET-1M1-of REALNUMBERSK2 st (p =HIDDENR1 x & q =HIDDENR1 y) & p <=XXREAL-0R1 q))) & ( not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) implies (x <=XXREAL-0R1 y iff x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1))"
    proof(rule conjMI)
      show "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies (x <=XXREAL-0R1 y iff ( ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex q be ElementSUBSET-1M1-of REALNUMBERSK2 st (p =HIDDENR1 x & q =HIDDENR1 y) & p <=XXREAL-0R1 q))"
         sorry
      show " not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) implies (x <=XXREAL-0R1 y iff x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1)"
      proof-
        have " not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) implies (x <=XXREAL-0R1 y implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1) &  not ( not ( not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 +inftyXXREAL-0K1) &  not x <=XXREAL-0R1 y)"
        proof(rule impI)
          assume A1: " not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2)"
          show "(x <=XXREAL-0R1 y implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1) &  not ( not ( not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 +inftyXXREAL-0K1) &  not x <=XXREAL-0R1 y)"
          proof-
            have cases: " not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2"
              using A1 sorry
            have case1: " not x inHIDDENR3 REALNUMBERSK2 implies (x <=XXREAL-0R1 y implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1) &  not ( not ( not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 +inftyXXREAL-0K1) &  not x <=XXREAL-0R1 y)"
            proof(rule impI,rule conjMI)
              assume A2: " not x inHIDDENR3 REALNUMBERSK2"
              show "x <=XXREAL-0R1 y implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
              proof-
                have "x <=XXREAL-0R1 y implies (x <>HIDDENR2 -inftyXXREAL-0K2 implies y =HIDDENR1 +inftyXXREAL-0K1)"
                proof(rule impI,rule impI)
                  assume A3: "x <=XXREAL-0R1 y"
                  assume "x <>HIDDENR2 -inftyXXREAL-0K2"
                  then have "x =HIDDENR1 +inftyXXREAL-0K1"
                    using A2 xxreal_0_th_14 sorry
                  thus "y =HIDDENR1 +inftyXXREAL-0K1"
                    using A3 xxreal_0_th_4 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              show " not ( not ( not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 +inftyXXREAL-0K1) &  not x <=XXREAL-0R1 y)"
                using xxreal_0_th_3 xxreal_0_th_5 sorry
            qed
            have case2: " not y inHIDDENR3 REALNUMBERSK2 implies (x <=XXREAL-0R1 y implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1) &  not ( not ( not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 +inftyXXREAL-0K1) &  not x <=XXREAL-0R1 y)"
            proof(rule impI,rule conjMI)
              assume A4: " not y inHIDDENR3 REALNUMBERSK2"
              show "x <=XXREAL-0R1 y implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
              proof-
                have "x <=XXREAL-0R1 y implies (x <>HIDDENR2 -inftyXXREAL-0K2 implies (y <>HIDDENR2 +inftyXXREAL-0K1 implies  not  True ))"
                proof(rule impI,rule impI,rule impI)
                  assume A5: "x <=XXREAL-0R1 y"
                  assume A6: "x <>HIDDENR2 -inftyXXREAL-0K2"
                  assume "y <>HIDDENR2 +inftyXXREAL-0K1"
                  then have "y =HIDDENR1 -inftyXXREAL-0K2"
                    using A4 xxreal_0_th_14 sorry
                  thus " not  True "
                    using A5 A6 xxreal_0_th_6 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              show " not ( not ( not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 +inftyXXREAL-0K1) &  not x <=XXREAL-0R1 y)"
                using xxreal_0_th_3 xxreal_0_th_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " ?thesis "
           sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
(*consistency*)
  show " True "
     sorry
qed "sorry"

mtheorem xxreal_3_cl_1:
"cluster  non realXREAL-0V1\<bar>positiveXXREAL-0V2 for ExtRealXXREAL-0M1"
proof
(*existence*)
  show " ex it be ExtRealXXREAL-0M1 st it be  non realXREAL-0V1\<bar>positiveXXREAL-0V2"
  proof-
    have " ex tVar1 be ExtRealXXREAL-0M1 st  not tVar1 be realXREAL-0V1 & tVar1 be positiveXXREAL-0V2"
    proof-
      show " ex tVar1 be ExtRealXXREAL-0M1 st  not tVar1 be realXREAL-0V1 & tVar1 be positiveXXREAL-0V2"
      proof(rule bexI[of _ "+inftyXXREAL-0K1"])
        show " not +inftyXXREAL-0K1 be realXREAL-0V1 & +inftyXXREAL-0K1 be positiveXXREAL-0V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_2:
"cluster  non realXREAL-0V1\<bar>negativeXXREAL-0V3 for ExtRealXXREAL-0M1"
proof
(*existence*)
  show " ex it be ExtRealXXREAL-0M1 st it be  non realXREAL-0V1\<bar>negativeXXREAL-0V3"
  proof-
    have " ex tVar2 be ExtRealXXREAL-0M1 st  not tVar2 be realXREAL-0V1 & tVar2 be negativeXXREAL-0V3"
    proof-
      show " ex tVar2 be ExtRealXXREAL-0M1 st  not tVar2 be realXREAL-0V1 & tVar2 be negativeXXREAL-0V3"
      proof(rule bexI[of _ "-inftyXXREAL-0K2"])
        show " not -inftyXXREAL-0K2 be realXREAL-0V1 & -inftyXXREAL-0K2 be negativeXXREAL-0V3"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_th_1:
" for x be  non realXREAL-0V1\<bar>positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1 holds x =HIDDENR1 +inftyXXREAL-0K1"
proof(rule ballI)
  fix x assume [ty]: "x be  non realXREAL-0V1\<bar>positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
  have " not x inHIDDENR3 REALNUMBERSK2"
     sorry
  thus "x =HIDDENR1 +inftyXXREAL-0K1"
    using xxreal_0_th_14 sorry
qed "sorry"

mtheorem xxreal_3_th_2:
" for x be  non realXREAL-0V1\<bar>negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1 holds x =HIDDENR1 -inftyXXREAL-0K2"
proof(rule ballI)
  fix x assume [ty]: "x be  non realXREAL-0V1\<bar>negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
  have " not x inHIDDENR3 REALNUMBERSK2"
     sorry
  thus "x =HIDDENR1 -inftyXXREAL-0K2"
    using xxreal_0_th_14 sorry
qed "sorry"

mtheorem xxreal_3_cl_3:
"cluster  non realXREAL-0V1\<bar> non negativeXXREAL-0V3 also-is positiveXXREAL-0V2 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it be  non realXREAL-0V1\<bar> non negativeXXREAL-0V3 implies it be positiveXXREAL-0V2"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_4:
"cluster  non realXREAL-0V1\<bar> non positiveXXREAL-0V2 also-is negativeXXREAL-0V3 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it be  non realXREAL-0V1\<bar> non positiveXXREAL-0V2 implies it be negativeXXREAL-0V3"
     sorry
qed "sorry"

mtheorem xxreal_3_th_3:
" for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 z implies ( ex y be RealXREAL-0M1 st x <XXREAL-0R3 y & y <XXREAL-0R3 z)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 z implies  not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 z"
    show " not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
    proof-
      have cases: "((x inHIDDENR3 REALNUMBERSK2 & z inHIDDENR3 REALNUMBERSK2 or (x =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 -inftyXXREAL-0K2)) or z =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 & z inHIDDENR3 REALNUMBERSK2 implies  not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & z inHIDDENR3 REALNUMBERSK2"
        thus " not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
          using A1 xreal_1_th_5 sorry
      qed
      have case2: "x =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 -inftyXXREAL-0K2 implies  not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 -inftyXXREAL-0K2"
        thus " not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
          using A1 xxreal_0_th_4 xxreal_0_th_6 sorry
      qed
      have case3: "z =HIDDENR1 +inftyXXREAL-0K1 implies  not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
      proof(rule impI)
        assume A2: "z =HIDDENR1 +inftyXXREAL-0K1"
        show " not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
        proof-
          have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x inHIDDENR3 REALNUMBERSK2"
            using A1 A2 xxreal_0_th_14 sorry
          have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies  not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
          proof(rule impI)
            assume "x =HIDDENR1 -inftyXXREAL-0K2"
            thus " not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
              using A2 sorry
          qed
          have case2: "x inHIDDENR3 REALNUMBERSK2 implies ( ex tVar3 be RealXREAL-0M1 st  not x <XXREAL-0R3 tVar3 &  not tVar3 <XXREAL-0R3 z)"
          proof(rule impI)
            assume "x inHIDDENR3 REALNUMBERSK2"
            then obtain x1 where 
              [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x"
               sorry
            show " ex tVar3 be RealXREAL-0M1 st  not x <XXREAL-0R3 tVar3 &  not tVar3 <XXREAL-0R3 z"
            proof(rule bexI[of _ "x1 +XCMPLX-0K2 \<one>\<^sub>M"])
              have A3: "x1 +XCMPLX-0K2 \<one>\<^sub>M inHIDDENR3 REALNUMBERSK2"
                using xreal_0_def_1 sorry
              have "x1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 x1 +XCMPLX-0K2 \<one>\<^sub>M"
                using xreal_1_th_8 sorry
              thus " not x <XXREAL-0R3 x1 +XCMPLX-0K2 \<one>\<^sub>M &  not x1 +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 z"
                using A2 A3 xxreal_0_th_9 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case4: "x =HIDDENR1 -inftyXXREAL-0K2 implies  not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
      proof(rule impI)
        assume A4: "x =HIDDENR1 -inftyXXREAL-0K2"
        show " not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
        proof-
          have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or z inHIDDENR3 REALNUMBERSK2"
            using A1 A4 xxreal_0_th_14 sorry
          have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies  not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
          proof(rule impI)
            assume "z =HIDDENR1 +inftyXXREAL-0K1"
            thus " not ( for y be RealXREAL-0M1 holds  not ( not x <XXREAL-0R3 y &  not y <XXREAL-0R3 z))"
              using A4 sorry
          qed
          have case2: "z inHIDDENR3 REALNUMBERSK2 implies ( ex tVar4 be RealXREAL-0M1 st  not x <XXREAL-0R3 tVar4 &  not tVar4 <XXREAL-0R3 z)"
          proof(rule impI)
            assume "z inHIDDENR3 REALNUMBERSK2"
            then obtain z1 where 
              [ty]:"z1 be RealXREAL-0M1" and z1Def:"z1 = z"
               sorry
            show " ex tVar4 be RealXREAL-0M1 st  not x <XXREAL-0R3 tVar4 &  not tVar4 <XXREAL-0R3 z"
            proof(rule bexI[of _ "z1 -XCMPLX-0K6 \<one>\<^sub>M"])
              have A5: "z1 -XCMPLX-0K6 \<one>\<^sub>M inHIDDENR3 REALNUMBERSK2"
                using xreal_0_def_1 sorry
              have "z1 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 z1 -XCMPLX-0K6 0NUMBERSK6"
                using xreal_1_th_10 sorry
              thus " not x <XXREAL-0R3 z1 -XCMPLX-0K6 \<one>\<^sub>M &  not z1 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 z"
                using A4 A5 xxreal_0_th_12 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef xxreal_3_def_2 (" _ +XXREAL-3K1  _ " [132,132]132 ) where
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"func x +XXREAL-3K1 y \<rightarrow> ExtRealXXREAL-0M1 means
  \<lambda>it.  ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a +XCMPLX-0K2 b if x be realXREAL-0V1 & y be realXREAL-0V1,
  \<lambda>it. it =HIDDENR1 +inftyXXREAL-0K1 if x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2,
  \<lambda>it. it =HIDDENR1 -inftyXXREAL-0K2 if x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1 otherwise \<lambda>it. it =HIDDENR1 0NUMBERSK6"
proof-
  (*existence*)
    show "(x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex it be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a +XCMPLX-0K2 b)) & ((x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2 implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 +inftyXXREAL-0K1)) & ((x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1 implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 -inftyXXREAL-0K2)) & ( not (x be realXREAL-0V1 & y be realXREAL-0V1) & ( not (x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1)) implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 0NUMBERSK6))))"
    proof-
      have "(x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex c be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & c =HIDDENR1 a +XCMPLX-0K2 b)) & (( not ( not ( not (x =HIDDENR1 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not (y =HIDDENR1 +inftyXXREAL-0K1 &  not x <>HIDDENR2 -inftyXXREAL-0K2)) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 +inftyXXREAL-0K1)) &  not ( not ( not (x =HIDDENR1 -inftyXXREAL-0K2 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not (y =HIDDENR1 -inftyXXREAL-0K2 &  not x <>HIDDENR2 +inftyXXREAL-0K1)) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 -inftyXXREAL-0K2))) &  not ((((( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not (x =HIDDENR1 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2)) &  not (y =HIDDENR1 +inftyXXREAL-0K1 &  not x <>HIDDENR2 -inftyXXREAL-0K2)) &  not (x =HIDDENR1 -inftyXXREAL-0K2 &  not y <>HIDDENR2 +inftyXXREAL-0K1)) &  not (y =HIDDENR1 -inftyXXREAL-0K2 &  not x <>HIDDENR2 +inftyXXREAL-0K1)) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 0NUMBERSK6)))"
      proof(rule conjMI)
        show "x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex c be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & c =HIDDENR1 a +XCMPLX-0K2 b)"
        proof-
          have "x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex tVar5 be ExtRealXXREAL-0M1 st  ex tVar6 be ComplexXCMPLX-0M1 st  ex tVar7 be ComplexXCMPLX-0M1 st (x =HIDDENR1 tVar6 & y =HIDDENR1 tVar7) & tVar6 +XCMPLX-0K2 tVar7 =HIDDENR1 tVar6 +XCMPLX-0K2 tVar7)"
          proof(rule impI)
            assume "x be realXREAL-0V1 & y be realXREAL-0V1"
            then obtain a b where 
              [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
               sorry
            show " ex tVar5 be ExtRealXXREAL-0M1 st  ex tVar6 be ComplexXCMPLX-0M1 st  ex tVar7 be ComplexXCMPLX-0M1 st (x =HIDDENR1 tVar6 & y =HIDDENR1 tVar7) & tVar6 +XCMPLX-0K2 tVar7 =HIDDENR1 tVar6 +XCMPLX-0K2 tVar7"
            proof(rule bexI[of _ "a +XCMPLX-0K2 b"])
              show " ex tVar6 be ComplexXCMPLX-0M1 st  ex tVar7 be ComplexXCMPLX-0M1 st (x =HIDDENR1 tVar6 & y =HIDDENR1 tVar7) & tVar6 +XCMPLX-0K2 tVar7 =HIDDENR1 tVar6 +XCMPLX-0K2 tVar7"
              proof(rule bexI[of _ "a"])
                show " ex tVar7 be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 tVar7) & a +XCMPLX-0K2 tVar7 =HIDDENR1 a +XCMPLX-0K2 tVar7"
                proof(rule bexI[of _ "b"])
                  show "(x =HIDDENR1 a & y =HIDDENR1 b) & a +XCMPLX-0K2 b =HIDDENR1 a +XCMPLX-0K2 b"
                     sorry
                qed "sorry"
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show "( not ( not ( not (x =HIDDENR1 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not (y =HIDDENR1 +inftyXXREAL-0K1 &  not x <>HIDDENR2 -inftyXXREAL-0K2)) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 +inftyXXREAL-0K1)) &  not ( not ( not (x =HIDDENR1 -inftyXXREAL-0K2 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not (y =HIDDENR1 -inftyXXREAL-0K2 &  not x <>HIDDENR2 +inftyXXREAL-0K1)) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 -inftyXXREAL-0K2))) &  not ((((( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not (x =HIDDENR1 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2)) &  not (y =HIDDENR1 +inftyXXREAL-0K1 &  not x <>HIDDENR2 -inftyXXREAL-0K2)) &  not (x =HIDDENR1 -inftyXXREAL-0K2 &  not y <>HIDDENR2 +inftyXXREAL-0K1)) &  not (y =HIDDENR1 -inftyXXREAL-0K2 &  not x <>HIDDENR2 +inftyXXREAL-0K1)) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ExtRealXXREAL-0M1 holds  for it2 be ExtRealXXREAL-0M1 holds (x be realXREAL-0V1 & y be realXREAL-0V1 implies (( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it1 =HIDDENR1 a +XCMPLX-0K2 b) & ( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it2 =HIDDENR1 a +XCMPLX-0K2 b) implies it1 =HIDDENR1 it2)) & ((x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2 implies (it1 =HIDDENR1 +inftyXXREAL-0K1 & it2 =HIDDENR1 +inftyXXREAL-0K1 implies it1 =HIDDENR1 it2)) & ((x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1 implies (it1 =HIDDENR1 -inftyXXREAL-0K2 & it2 =HIDDENR1 -inftyXXREAL-0K2 implies it1 =HIDDENR1 it2)) & ( not (x be realXREAL-0V1 & y be realXREAL-0V1) & ( not (x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1)) implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2))))"
       sorry
  (*consistency*)
    show " for it be ExtRealXXREAL-0M1 holds (((x be realXREAL-0V1 & y be realXREAL-0V1) & (x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) implies (( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a +XCMPLX-0K2 b) iff it =HIDDENR1 +inftyXXREAL-0K1)) & ((x be realXREAL-0V1 & y be realXREAL-0V1) & (x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1) implies (( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a +XCMPLX-0K2 b) iff it =HIDDENR1 -inftyXXREAL-0K2))) & ((x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) & (x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1) implies (it =HIDDENR1 +inftyXXREAL-0K1 iff it =HIDDENR1 -inftyXXREAL-0K2))"
       sorry
qed "sorry"

mtheorem XXREAL_3K1_commutativity:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 y +XXREAL-3K1 x"
proof-
  have " for it be ExtRealXXREAL-0M1 holds  for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds it =HIDDENR1 x +XXREAL-3K1 y implies it =HIDDENR1 y +XXREAL-3K1 x"
  proof-
    have " for it be ExtRealXXREAL-0M1 holds  for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a +XCMPLX-0K2 b)) & ((x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2 implies it =HIDDENR1 +inftyXXREAL-0K1) & ((x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1 implies it =HIDDENR1 -inftyXXREAL-0K2) & ( not (x be realXREAL-0V1 & y be realXREAL-0V1) & ( not (x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1)) implies it =HIDDENR1 0NUMBERSK6))) implies (y be realXREAL-0V1 & x be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (y =HIDDENR1 a & x =HIDDENR1 b) & it =HIDDENR1 a +XCMPLX-0K2 b)) & ((y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 implies it =HIDDENR1 +inftyXXREAL-0K1) & ((y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1 implies it =HIDDENR1 -inftyXXREAL-0K2) & ( not (y be realXREAL-0V1 & x be realXREAL-0V1) & ( not (y =HIDDENR1 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2) &  not (y =HIDDENR1 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y <>HIDDENR2 +inftyXXREAL-0K1)) implies it =HIDDENR1 0NUMBERSK6)))"
       sorry
    thus " ?thesis "
      using xxreal_3_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef xxreal_3_def_3 ("-XXREAL-3K2  _ " [132]132 ) where
  mlet "x be ExtRealXXREAL-0M1"
"func -XXREAL-3K2 x \<rightarrow> ExtRealXXREAL-0M1 means
  \<lambda>it.  ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it =HIDDENR1 -XCMPLX-0K4 a if x be realXREAL-0V1,
  \<lambda>it. it =HIDDENR1 -inftyXXREAL-0K2 if x =HIDDENR1 +inftyXXREAL-0K1 otherwise \<lambda>it. it =HIDDENR1 +inftyXXREAL-0K1"
proof-
  (*existence*)
    show "(x be realXREAL-0V1 implies ( ex it be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it =HIDDENR1 -XCMPLX-0K4 a)) & ((x =HIDDENR1 +inftyXXREAL-0K1 implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 -inftyXXREAL-0K2)) & ( not x be realXREAL-0V1 &  not x =HIDDENR1 +inftyXXREAL-0K1 implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 +inftyXXREAL-0K1)))"
    proof-
      have "(x be realXREAL-0V1 implies ( ex c be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & c =HIDDENR1 -XCMPLX-0K4 a)) & ( not (x =HIDDENR1 +inftyXXREAL-0K1 & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 -inftyXXREAL-0K2)) &  not (( not x be realXREAL-0V1 &  not x =HIDDENR1 +inftyXXREAL-0K1) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 +inftyXXREAL-0K1)))"
      proof(rule conjMI)
        show "x be realXREAL-0V1 implies ( ex c be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & c =HIDDENR1 -XCMPLX-0K4 a)"
        proof-
          have "x be realXREAL-0V1 implies ( ex tVar8 be ExtRealXXREAL-0M1 st  ex tVar9 be ComplexXCMPLX-0M1 st x =HIDDENR1 tVar9 & -XCMPLX-0K4 tVar9 =HIDDENR1 -XCMPLX-0K4 tVar9)"
          proof(rule impI)
            assume "x be realXREAL-0V1"
            then obtain a where 
              [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
               sorry
            show " ex tVar8 be ExtRealXXREAL-0M1 st  ex tVar9 be ComplexXCMPLX-0M1 st x =HIDDENR1 tVar9 & -XCMPLX-0K4 tVar9 =HIDDENR1 -XCMPLX-0K4 tVar9"
            proof(rule bexI[of _ "-XCMPLX-0K4 a"])
              show " ex tVar9 be ComplexXCMPLX-0M1 st x =HIDDENR1 tVar9 & -XCMPLX-0K4 tVar9 =HIDDENR1 -XCMPLX-0K4 tVar9"
              proof(rule bexI[of _ "a"])
                show "x =HIDDENR1 a & -XCMPLX-0K4 a =HIDDENR1 -XCMPLX-0K4 a"
                   sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show " not (x =HIDDENR1 +inftyXXREAL-0K1 & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 -inftyXXREAL-0K2)) &  not (( not x be realXREAL-0V1 &  not x =HIDDENR1 +inftyXXREAL-0K1) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 +inftyXXREAL-0K1))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ExtRealXXREAL-0M1 holds  for it2 be ExtRealXXREAL-0M1 holds (x be realXREAL-0V1 implies (( ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it1 =HIDDENR1 -XCMPLX-0K4 a) & ( ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it2 =HIDDENR1 -XCMPLX-0K4 a) implies it1 =HIDDENR1 it2)) & ((x =HIDDENR1 +inftyXXREAL-0K1 implies (it1 =HIDDENR1 -inftyXXREAL-0K2 & it2 =HIDDENR1 -inftyXXREAL-0K2 implies it1 =HIDDENR1 it2)) & ( not x be realXREAL-0V1 &  not x =HIDDENR1 +inftyXXREAL-0K1 implies (it1 =HIDDENR1 +inftyXXREAL-0K1 & it2 =HIDDENR1 +inftyXXREAL-0K1 implies it1 =HIDDENR1 it2)))"
       sorry
  (*consistency*)
    show " for it be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 & x =HIDDENR1 +inftyXXREAL-0K1 implies (( ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it =HIDDENR1 -XCMPLX-0K4 a) iff it =HIDDENR1 -inftyXXREAL-0K2)"
       sorry
qed "sorry"

mtheorem XXREAL_3K2_involutiveness:
" for x be ExtRealXXREAL-0M1 holds -XXREAL-3K2 (-XXREAL-3K2 x) =HIDDENR1 x"
proof-
  have " for it be ExtRealXXREAL-0M1 holds  for x be ExtRealXXREAL-0M1 holds it =HIDDENR1 -XXREAL-3K2 x implies x =HIDDENR1 -XXREAL-3K2 it"
  proof-
    have " for it be ExtRealXXREAL-0M1 holds  for x be ExtRealXXREAL-0M1 holds (x be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it =HIDDENR1 -XCMPLX-0K4 a)) & ((x =HIDDENR1 +inftyXXREAL-0K1 implies it =HIDDENR1 -inftyXXREAL-0K2) & ( not x be realXREAL-0V1 &  not x =HIDDENR1 +inftyXXREAL-0K1 implies it =HIDDENR1 +inftyXXREAL-0K1)) implies (it be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st it =HIDDENR1 a & x =HIDDENR1 -XCMPLX-0K4 a)) & ((it =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 -inftyXXREAL-0K2) & ( not it be realXREAL-0V1 &  not it =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 +inftyXXREAL-0K1))"
    proof-
      have " for y be ExtRealXXREAL-0M1 holds  for x be ExtRealXXREAL-0M1 holds (x be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & y =HIDDENR1 -XCMPLX-0K4 a)) & ((x =HIDDENR1 +inftyXXREAL-0K1 implies y =HIDDENR1 -inftyXXREAL-0K2) & ( not x be realXREAL-0V1 & x <>HIDDENR2 +inftyXXREAL-0K1 implies y =HIDDENR1 +inftyXXREAL-0K1)) implies (y be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st y =HIDDENR1 a & x =HIDDENR1 -XCMPLX-0K4 a)) & ((y =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 -inftyXXREAL-0K2) &  not (( not y be realXREAL-0V1 &  not y =HIDDENR1 +inftyXXREAL-0K1) &  not x =HIDDENR1 +inftyXXREAL-0K1))"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
        fix y assume [ty]: "y be ExtRealXXREAL-0M1"
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        assume A1: "x be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & y =HIDDENR1 -XCMPLX-0K4 a)"
          and A2: "x =HIDDENR1 +inftyXXREAL-0K1 implies y =HIDDENR1 -inftyXXREAL-0K2"
          and A3: " not x be realXREAL-0V1 & x <>HIDDENR2 +inftyXXREAL-0K1 implies y =HIDDENR1 +inftyXXREAL-0K1"
        show "y be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st y =HIDDENR1 a & x =HIDDENR1 -XCMPLX-0K4 a)"
        proof-
          have "y be realXREAL-0V1 implies ( ex tVar10 be ComplexXCMPLX-0M1 st y =HIDDENR1 tVar10 & x =HIDDENR1 -XCMPLX-0K4 tVar10)"
          proof(rule impI)
            assume "y be realXREAL-0V1"
            then obtain a where
              [ty]:"a be ComplexXCMPLX-0M1" and 
              A4: "x =HIDDENR1 a & y =HIDDENR1 -XCMPLX-0K4 a"
              using A1 A2 A3 sorry
            show " ex tVar10 be ComplexXCMPLX-0M1 st y =HIDDENR1 tVar10 & x =HIDDENR1 -XCMPLX-0K4 tVar10"
            proof(rule bexI[of _ "-XCMPLX-0K4 a"])
              show "y =HIDDENR1 -XCMPLX-0K4 a & x =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4 a)"
                using A4 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        have "x inHIDDENR3 REALNUMBERSK2 implies x be realXREAL-0V1"
           sorry
        thus "y =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 -inftyXXREAL-0K2"
          using A1 A2 xxreal_0_th_14 sorry
        show " not (( not y be realXREAL-0V1 &  not y =HIDDENR1 +inftyXXREAL-0K1) &  not x =HIDDENR1 +inftyXXREAL-0K1)"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using xxreal_3_def_3 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef xxreal_3_def_4 (" _ -XXREAL-3K3  _ " [132,132]132 ) where
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"func x -XXREAL-3K3 y \<rightarrow> ExtRealXXREAL-0M1 equals
  x +XXREAL-3K1 (-XXREAL-3K2 y)"
proof-
  (*coherence*)
    show "x +XXREAL-3K1 (-XXREAL-3K2 y) be ExtRealXXREAL-0M1"
       sorry
qed "sorry"

mtheorem xxreal_3_ident_1:
  mlet "x be RealXREAL-0M1", "y be RealXREAL-0M1", "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1"
"identify x +XXREAL-3K1 y with a +XCMPLX-0K2 b when x =HIDDENR1 a & y =HIDDENR1 b"
proof
(*compatibility*)
  show "x =HIDDENR1 a & y =HIDDENR1 b implies x +XXREAL-3K1 y =HIDDENR1 a +XCMPLX-0K2 b"
    using xxreal_3_def_2 sorry
qed "sorry"

mtheorem xxreal_3_ident_2:
  mlet "x be RealXREAL-0M1", "a be ComplexXCMPLX-0M1"
"identify -XXREAL-3K2 x with -XCMPLX-0K4 a when x =HIDDENR1 a"
proof
(*compatibility*)
  show "x =HIDDENR1 a implies -XXREAL-3K2 x =HIDDENR1 -XCMPLX-0K4 a"
    using xxreal_3_def_3 sorry
qed "sorry"

mtheorem xxreal_3_cl_5:
  mlet "r be RealXREAL-0M1"
"cluster -XXREAL-3K2 r as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "-XXREAL-3K2 r be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_6:
  mlet "r be RealXREAL-0M1", "s be RealXREAL-0M1"
"cluster r +XXREAL-3K1 s as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "r +XXREAL-3K1 s be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_7:
  mlet "r be RealXREAL-0M1", "s be RealXREAL-0M1"
"cluster r -XXREAL-3K3 s as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "r -XXREAL-3K3 s be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_8:
  mlet "x be RealXREAL-0M1", "y be  non realXREAL-0V1\<bar>ExtRealXXREAL-0M1"
"cluster x +XXREAL-3K1 y as-term-is  non realXREAL-0V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x +XXREAL-3K1 y implies it be  non realXREAL-0V1"
  proof-
    have " for z be objectHIDDENM1 holds z =HIDDENR1 x +XXREAL-3K1 y implies  not z be realXREAL-0V1"
    proof(rule ballI,rule impI)
      have " not y inHIDDENR3 REALNUMBERSK2"
         sorry
      then have A1: "y =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
        using xxreal_0_th_14 sorry
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z =HIDDENR1 x +XXREAL-3K1 y"
      thus " not z be realXREAL-0V1"
        using A1 xxreal_3_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_9:
  mlet "x be  non realXREAL-0V1\<bar>positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non realXREAL-0V1\<bar>positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x +XXREAL-3K1 y as-term-is  non realXREAL-0V1"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be  non realXREAL-0V1"
  proof-
    have " not x +XXREAL-3K1 y be realXREAL-0V1"
    proof-
      have "x =HIDDENR1 +inftyXXREAL-0K1"
        using xxreal_3_th_1 sorry
      thus " not x +XXREAL-3K1 y be realXREAL-0V1"
        using xxreal_3_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_10:
  mlet "x be  non realXREAL-0V1\<bar>negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non realXREAL-0V1\<bar>negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x +XXREAL-3K1 y as-term-is  non realXREAL-0V1"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be  non realXREAL-0V1"
  proof-
    have " not x +XXREAL-3K1 y be realXREAL-0V1"
    proof-
      have "x =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_3_th_2 sorry
      thus " not x +XXREAL-3K1 y be realXREAL-0V1"
        using xxreal_3_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_11:
  mlet "x be  non realXREAL-0V1\<bar>negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non realXREAL-0V1\<bar>positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x +XXREAL-3K1 y as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be zeroORDINAL1V8"
  proof-
    have "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_3_th_1 xxreal_3_th_2 sorry
    thus "x +XXREAL-3K1 y be zeroORDINAL1V8"
      using xxreal_3_def_2 sorry
  qed
qed "sorry"

mtheorem xxreal_3_ident_3:
  mlet "x be RealXREAL-0M1", "y be RealXREAL-0M1", "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1"
"identify x -XXREAL-3K3 y with a -XCMPLX-0K6 b when x =HIDDENR1 a & y =HIDDENR1 b"
proof
(*compatibility*)
  show "x =HIDDENR1 a & y =HIDDENR1 b implies x -XXREAL-3K3 y =HIDDENR1 a -XCMPLX-0K6 b"
     sorry
qed "sorry"

mtheorem xxreal_3_th_4:
" for x be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "x +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 x"
    proof-
      have cases: "x inHIDDENR3 REALNUMBERSK2 or (x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1)"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 implies x +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 x"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2"
        then obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = x"
           sorry
        have "r +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 r"
           sorry
        thus "x +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 x"
           sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 x"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1"
        thus "x +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 x"
          using xxreal_3_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_5:
"-XXREAL-3K2 -inftyXXREAL-0K2 =HIDDENR1 +inftyXXREAL-0K1"
  using xxreal_3_def_3 sorry

mtheorem xxreal_3_th_6:
"-XXREAL-3K2 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
  using xxreal_3_def_3 sorry

mlemma xxreal_3_lm_1:
"+inftyXXREAL-0K1 +XXREAL-3K1 +inftyXXREAL-0K1 =HIDDENR1 +inftyXXREAL-0K1"
  using xxreal_3_def_2 sorry

mlemma xxreal_3_lm_2:
"-inftyXXREAL-0K2 +XXREAL-3K1 -inftyXXREAL-0K2 =HIDDENR1 -inftyXXREAL-0K2"
  using xxreal_3_def_2 sorry

mtheorem xxreal_3_th_7:
" for x be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
    proof-
      have cases: "(x =HIDDENR1 -inftyXXREAL-0K2 or x inHIDDENR3 REALNUMBERSK2) or x =HIDDENR1 +inftyXXREAL-0K1"
        using xxreal_0_th_14 sorry
      have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2"
        thus "x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
          using xxreal_3_th_5 sorry
      qed
      have case2: "x inHIDDENR3 REALNUMBERSK2 implies x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2"
        then have 
          [ty]:"x be RealXREAL-0M1"
           sorry
        obtain y where 
          [ty]:"y be RealXREAL-0M1" and yDef:"y = -XXREAL-3K2 x"
           sorry
        have "x +XXREAL-3K1 y =HIDDENR1 0NUMBERSK6"
           sorry
        thus "x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
           sorry
      qed
      have case3: "x =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1"
        thus "x +XXREAL-3K1 (-XXREAL-3K2 x) =HIDDENR1 0NUMBERSK6"
          using xxreal_3_th_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_8:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 -XXREAL-3K2 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 -XXREAL-3K2 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x +XXREAL-3K1 y =HIDDENR1 0NUMBERSK6"
    show "x =HIDDENR1 -XXREAL-3K2 y"
    proof-
      have cases: "(x inHIDDENR3 REALNUMBERSK2 or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 implies x =HIDDENR1 -XXREAL-3K2 y"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2"
        then have 
          [ty]:"x be RealXREAL-0M1"
           sorry
        have "x +XXREAL-3K1 y be realXREAL-0V1"
          using A1 sorry
        then have 
          [ty]:"y be RealXREAL-0M1"
           sorry
        have "x +XXREAL-3K1 y =HIDDENR1 0NUMBERSK6"
          using A1 sorry
        then have "x =HIDDENR1 -XXREAL-3K2 y"
           sorry
        thus "x =HIDDENR1 -XXREAL-3K2 y"
           sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies x =HIDDENR1 -XXREAL-3K2 y"
      proof(rule impI)
        assume A2: "x =HIDDENR1 -inftyXXREAL-0K2"
        then have "y =HIDDENR1 +inftyXXREAL-0K1"
          using A1 xxreal_3_def_2 sorry
        thus "x =HIDDENR1 -XXREAL-3K2 y"
          using A2 xxreal_3_def_3 sorry
      qed
      have case3: "x =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 -XXREAL-3K2 y"
      proof(rule impI)
        assume A3: "x =HIDDENR1 +inftyXXREAL-0K1"
        then have "y =HIDDENR1 -inftyXXREAL-0K2"
          using A1 xxreal_3_def_2 sorry
        thus "x =HIDDENR1 -XXREAL-3K2 y"
          using A3 xxreal_3_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_3:
" for x be ExtRealXXREAL-0M1 holds -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2 iff x inHIDDENR3 REALNUMBERSK2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds (-XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 REALNUMBERSK2) & (x inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "-XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 REALNUMBERSK2"
    proof(rule impI)
      assume "-XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2"
      then obtain a where 
        [ty]:"a be RealXREAL-0M1" and aDef:"a = -XXREAL-3K2 x"
         sorry
      have "-XXREAL-3K2 a inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      thus "x inHIDDENR3 REALNUMBERSK2"
         sorry
    qed
    assume "x inHIDDENR3 REALNUMBERSK2"
    then obtain a where 
      [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
       sorry
    have "-XXREAL-3K2 a be realXREAL-0V1"
       sorry
    thus "-XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_4:
"-XXREAL-3K2 (+inftyXXREAL-0K1 +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 (-XXREAL-3K2 -inftyXXREAL-0K2)-XXREAL-3K3 +inftyXXREAL-0K1"
proof-
  have "-XXREAL-3K2 (+inftyXXREAL-0K1 +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 +inftyXXREAL-0K1 -XXREAL-3K3 +inftyXXREAL-0K1"
    using xxreal_3_def_3 sorry
  also have "... = (-XXREAL-3K2 -inftyXXREAL-0K2)-XXREAL-3K3 +inftyXXREAL-0K1"
    using xxreal_3_def_3 sorry
  finally show "-XXREAL-3K2 (+inftyXXREAL-0K1 +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 (-XXREAL-3K2 -inftyXXREAL-0K2)-XXREAL-3K3 +inftyXXREAL-0K1"
     sorry
qed

mlemma xxreal_3_lm_5:
"-XXREAL-3K2 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
  using xxreal_3_def_3 sorry

mlemma xxreal_3_lm_6:
" for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 (-XXREAL-3K2 +inftyXXREAL-0K1)+XXREAL-3K1 (-XXREAL-3K2 x)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 (-XXREAL-3K2 +inftyXXREAL-0K1)+XXREAL-3K1 (-XXREAL-3K2 x)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "x inHIDDENR3 REALNUMBERSK2"
    then have "x +XXREAL-3K1 +inftyXXREAL-0K1 =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_3_def_2 sorry
    thus "-XXREAL-3K2 (x +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 (-XXREAL-3K2 +inftyXXREAL-0K1)+XXREAL-3K1 (-XXREAL-3K2 x)"
      using A1 xxreal_3_def_2 xxreal_3_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_7:
" for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 (-XXREAL-3K2 -inftyXXREAL-0K2)+XXREAL-3K1 (-XXREAL-3K2 x)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 (-XXREAL-3K2 -inftyXXREAL-0K2)+XXREAL-3K1 (-XXREAL-3K2 x)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "x inHIDDENR3 REALNUMBERSK2"
    then have "x +XXREAL-3K1 -inftyXXREAL-0K2 =HIDDENR1 -inftyXXREAL-0K2"
      using xxreal_3_def_2 sorry
    thus "-XXREAL-3K2 (x +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 (-XXREAL-3K2 -inftyXXREAL-0K2)+XXREAL-3K1 (-XXREAL-3K2 x)"
      using A1 xxreal_3_def_2 xxreal_3_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_9:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    show "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
    proof-
      have cases: "(((((((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) or x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        using xxreal_0_th_14 sorry
      have case1: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume A1: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1"
        then have "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 -XXREAL-3K2 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        also have "... = (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
          using A1 xxreal_3_def_2 xxreal_3_lm_5 sorry
        finally show "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
           sorry
      qed
      have case2: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
          using xxreal_3_lm_4 sorry
      qed
      have case3: "x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
          using xxreal_3_lm_6 sorry
      qed
      have case4: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
          using xxreal_3_lm_4 sorry
      qed
      have case5: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume A2: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2"
        then have "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 -XXREAL-3K2 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        also have "... = (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
          using A2 xxreal_3_def_2 xxreal_3_th_5 sorry
        finally show "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
           sorry
      qed
      have case6: "x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
          using xxreal_3_lm_7 sorry
      qed
      have case7: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
          using xxreal_3_lm_6 sorry
      qed
      have case8: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
          using xxreal_3_lm_7 sorry
      qed
      have case9: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        then obtain a b where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
          [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
           sorry
        have "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 -XXREAL-3K2 (a +XXREAL-3K1 b)"
           sorry
        also have "... = (-XXREAL-3K2 a)+XXREAL-3K1 (-XXREAL-3K2 b)"
           sorry
        finally have "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 a)+XXREAL-3K1 (-XXREAL-3K2 b)"
           sorry
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 (-XXREAL-3K2 y)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 case7 case8 case9 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve f, g for "ExtRealXXREAL-0M1"
mtheorem xxreal_3_th_10:
" for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds -XXREAL-3K2 f =HIDDENR1 -XXREAL-3K2 g implies f =HIDDENR1 g"
proof-
  have " for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds -XXREAL-3K2 f =HIDDENR1 -XXREAL-3K2 g implies f =HIDDENR1 g"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be ExtRealXXREAL-0M1"
    fix g assume [ty]: "g be ExtRealXXREAL-0M1"
    assume A1: "-XXREAL-3K2 f =HIDDENR1 -XXREAL-3K2 g"
    show "f =HIDDENR1 g"
    proof-
      have cases: "(f inHIDDENR3 REALNUMBERSK2 or f =HIDDENR1 +inftyXXREAL-0K1) or f =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_0_th_14 sorry
      have case1: "f inHIDDENR3 REALNUMBERSK2 implies f =HIDDENR1 g"
      proof(rule impI)
        assume A2: "f inHIDDENR3 REALNUMBERSK2"
        have " not g inHIDDENR3 REALNUMBERSK2 implies  False "
        proof(rule impI)
          assume " not g inHIDDENR3 REALNUMBERSK2"
          then have "g =HIDDENR1 +inftyXXREAL-0K1 or g =HIDDENR1 -inftyXXREAL-0K2"
            using xxreal_0_th_14 sorry
          thus " False "
            using A1 A2 xxreal_3_def_3 sorry
        qed
        then have A3: " ex a be ComplexXCMPLX-0M1 st g =HIDDENR1 a & -XXREAL-3K2 g =HIDDENR1 -XCMPLX-0K4 a"
          using xxreal_3_def_3 sorry
        have " ex a be ComplexXCMPLX-0M1 st f =HIDDENR1 a & -XXREAL-3K2 f =HIDDENR1 -XCMPLX-0K4 a"
          using A2 xxreal_3_def_3 sorry
        thus "f =HIDDENR1 g"
          using A1 A3 sorry
      qed
      have case2: "f =HIDDENR1 +inftyXXREAL-0K1 implies f =HIDDENR1 g"
      proof(rule impI)
        assume "f =HIDDENR1 +inftyXXREAL-0K1"
        thus "f =HIDDENR1 g"
          using A1 xxreal_3_th_5 sorry
      qed
      have case3: "f =HIDDENR1 -inftyXXREAL-0K2 implies f =HIDDENR1 g"
      proof(rule impI)
        assume "f =HIDDENR1 -inftyXXREAL-0K2"
        then have "-XXREAL-3K2 (-XXREAL-3K2 g) =HIDDENR1 -inftyXXREAL-0K2"
          using A1 sorry
        thus "f =HIDDENR1 g"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_8:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1 implies ( not x =HIDDENR1 +inftyXXREAL-0K1 &  not y =HIDDENR1 +inftyXXREAL-0K1 implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
    assume " not x =HIDDENR1 +inftyXXREAL-0K1 &  not y =HIDDENR1 +inftyXXREAL-0K1"
    then have "((x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2"
      using xxreal_0_th_14 sorry
    thus " not  True "
      using A1 xxreal_3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_9:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2 implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2 implies ( not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 -inftyXXREAL-0K2 implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2"
    assume " not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 -inftyXXREAL-0K2"
    then have "((x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) or x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_0_th_14 sorry
    thus " not  True "
      using A1 xxreal_3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_11:
" for r be RealXREAL-0M1 holds  for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds r +XXREAL-3K1 f =HIDDENR1 r +XXREAL-3K1 g implies f =HIDDENR1 g"
proof-
  have " for r be RealXREAL-0M1 holds  for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds r +XXREAL-3K1 f =HIDDENR1 r +XXREAL-3K1 g implies f =HIDDENR1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be ExtRealXXREAL-0M1"
    fix g assume [ty]: "g be ExtRealXXREAL-0M1"
    assume A1: "r +XXREAL-3K1 f =HIDDENR1 r +XXREAL-3K1 g"
    show "f =HIDDENR1 g"
    proof-
      have cases: "(f inHIDDENR3 REALNUMBERSK2 or f =HIDDENR1 +inftyXXREAL-0K1) or f =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_0_th_14 sorry
      have case1: "f inHIDDENR3 REALNUMBERSK2 implies f =HIDDENR1 g"
      proof(rule impI)
        assume A2: "f inHIDDENR3 REALNUMBERSK2"
        have " not g inHIDDENR3 REALNUMBERSK2 implies  False "
        proof(rule impI)
          assume " not g inHIDDENR3 REALNUMBERSK2"
          then have "g =HIDDENR1 +inftyXXREAL-0K1 or g =HIDDENR1 -inftyXXREAL-0K2"
            using xxreal_0_th_14 sorry
          thus " False "
            using A1 A2 sorry
        qed
        then have A3: " ex c be ComplexXCMPLX-0M1 st  ex d be ComplexXCMPLX-0M1 st (r =HIDDENR1 c & g =HIDDENR1 d) & r +XXREAL-3K1 g =HIDDENR1 c +XCMPLX-0K2 d"
          using xxreal_3_def_2 sorry
        have " ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (r =HIDDENR1 a & f =HIDDENR1 b) & r +XXREAL-3K1 f =HIDDENR1 a +XCMPLX-0K2 b"
          using A2 xxreal_3_def_2 sorry
        thus "f =HIDDENR1 g"
          using A1 A3 sorry
      qed
      have case2: "f =HIDDENR1 +inftyXXREAL-0K1 implies f =HIDDENR1 g"
      proof(rule impI)
        assume A4: "f =HIDDENR1 +inftyXXREAL-0K1"
        then have "r +XXREAL-3K1 f =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        thus "f =HIDDENR1 g"
          using A1 A4 xxreal_3_lm_8 sorry
      qed
      have case3: "f =HIDDENR1 -inftyXXREAL-0K2 implies f =HIDDENR1 g"
      proof(rule impI)
        assume A5: "f =HIDDENR1 -inftyXXREAL-0K2"
        then have "r +XXREAL-3K1 f =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        thus "f =HIDDENR1 g"
          using A1 A5 xxreal_3_lm_9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_12:
" for r be RealXREAL-0M1 holds  for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds r -XXREAL-3K3 f =HIDDENR1 r -XXREAL-3K3 g implies f =HIDDENR1 g"
proof-
  have " for r be RealXREAL-0M1 holds  for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds r -XXREAL-3K3 f =HIDDENR1 r -XXREAL-3K3 g implies f =HIDDENR1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be ExtRealXXREAL-0M1"
    fix g assume [ty]: "g be ExtRealXXREAL-0M1"
    assume "r -XXREAL-3K3 f =HIDDENR1 r -XXREAL-3K3 g"
    then have "-XXREAL-3K2 f =HIDDENR1 -XXREAL-3K2 g"
      using xxreal_3_th_11 sorry
    thus "f =HIDDENR1 g"
      using xxreal_3_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_13:
" for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 +inftyXXREAL-0K1 implies +inftyXXREAL-0K1 -XXREAL-3K3 x =HIDDENR1 +inftyXXREAL-0K1 & x -XXREAL-3K3 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 +inftyXXREAL-0K1 implies +inftyXXREAL-0K1 -XXREAL-3K3 x =HIDDENR1 +inftyXXREAL-0K1 & x -XXREAL-3K3 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
  proof(rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 +inftyXXREAL-0K1"
    then have "-XXREAL-3K2 x <>HIDDENR2 -inftyXXREAL-0K2"
      using xxreal_3_th_5 sorry
    thus "+inftyXXREAL-0K1 -XXREAL-3K3 x =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_3_def_2 sorry
    have "-XXREAL-3K2 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
      using xxreal_3_def_3 sorry
    thus "x -XXREAL-3K3 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
      using A1 xxreal_3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_14:
" for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 -inftyXXREAL-0K2 implies -inftyXXREAL-0K2 -XXREAL-3K3 x =HIDDENR1 -inftyXXREAL-0K2 & x -XXREAL-3K3 -inftyXXREAL-0K2 =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 -inftyXXREAL-0K2 implies -inftyXXREAL-0K2 -XXREAL-3K3 x =HIDDENR1 -inftyXXREAL-0K2 & x -XXREAL-3K3 -inftyXXREAL-0K2 =HIDDENR1 +inftyXXREAL-0K1"
  proof(rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 -inftyXXREAL-0K2"
    have "-XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1 implies  False "
    proof(rule impI)
      assume "-XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1"
      then have "-XXREAL-3K2 (-XXREAL-3K2 x) =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_3_def_3 sorry
      thus " False "
        using A1 sorry
    qed
    thus "-inftyXXREAL-0K2 -XXREAL-3K3 x =HIDDENR1 -inftyXXREAL-0K2"
      using xxreal_3_def_2 sorry
    show "x -XXREAL-3K3 -inftyXXREAL-0K2 =HIDDENR1 +inftyXXREAL-0K1"
      using A1 xxreal_3_def_2 xxreal_3_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_15:
" for x be ExtRealXXREAL-0M1 holds x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
    proof-
      have cases: "(x inHIDDENR3 REALNUMBERSK2 or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 implies x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2"
        then obtain a where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
           sorry
        have "x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 a -XXREAL-3K3 0NUMBERSK6"
           sorry
        also have "... = x"
           sorry
        finally have "x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
           sorry
        thus "x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
           sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2"
        thus "x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
          using xxreal_3_th_14 sorry
      qed
      have case3: "x =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1"
        thus "x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 x"
          using xxreal_3_th_13 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_16:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 +inftyXXREAL-0K1"
  using xxreal_3_lm_8 sorry

mtheorem xxreal_3_th_17:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2 implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2"
  using xxreal_3_lm_9 sorry

mtheorem xxreal_3_th_18:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1 implies ( not x =HIDDENR1 +inftyXXREAL-0K1 &  not y =HIDDENR1 -inftyXXREAL-0K2 implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1"
    assume " not x =HIDDENR1 +inftyXXREAL-0K1 &  not y =HIDDENR1 -inftyXXREAL-0K2"
    then have "((x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_0_th_14 sorry
    thus " not  True "
      using A1 xxreal_3_th_13 xxreal_3_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_19:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2 implies x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2 implies ( not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 +inftyXXREAL-0K1 implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
    assume " not x =HIDDENR1 -inftyXXREAL-0K2 &  not y =HIDDENR1 +inftyXXREAL-0K1"
    then have "((x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) or x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2"
      using xxreal_0_th_14 sorry
    thus " not  True "
      using A1 xxreal_3_th_13 xxreal_3_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_20:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) & x +XXREAL-3K1 y inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) & x +XXREAL-3K1 y inHIDDENR3 REALNUMBERSK2 implies ( not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) & x +XXREAL-3K1 y inHIDDENR3 REALNUMBERSK2"
    have A2: "(x inHIDDENR3 REALNUMBERSK2 or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_0_th_14 sorry
    have A3: "(y inHIDDENR3 REALNUMBERSK2 or y =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_0_th_14 sorry
    assume " not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2)"
    thus " not  True "
      using A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_21:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & x -XXREAL-3K3 y inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & x -XXREAL-3K3 y inHIDDENR3 REALNUMBERSK2 implies ( not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & x -XXREAL-3K3 y inHIDDENR3 REALNUMBERSK2"
    have A2: "(x inHIDDENR3 REALNUMBERSK2 or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_0_th_14 sorry
    have A3: "(y inHIDDENR3 REALNUMBERSK2 or y =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_0_th_14 sorry
    assume " not (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2)"
    thus " not  True "
      using A1 A2 A3 xxreal_3_th_13 xxreal_3_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_22:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 implies (y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 implies (y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x be realXREAL-0V1"
    show "(y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
    proof-
      have cases: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1"
        using A1 xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies (y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        then obtain a b where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
          [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
           sorry
        have A2: "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 (b +XXREAL-3K1 a)-XXREAL-3K3 a"
           sorry
        also have "... = y"
           sorry
        finally have "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
           sorry
        have "(y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 (b -XXREAL-3K3 a)+XXREAL-3K1 a"
           sorry
        also have "... = y"
           sorry
        finally have "(y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y"
           sorry
        thus "(y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
          using A2 sorry
      qed
      have case2: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2 implies (y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
      proof(rule impI)
        assume A3: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2"
        then have "y -XXREAL-3K3 x =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        thus "(y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
          using A3 xxreal_3_def_2 sorry
      qed
      have case3: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1 implies (y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
      proof(rule impI)
        assume A4: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1"
        then have "y -XXREAL-3K3 x =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        thus "(y -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 y & (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
          using A4 xxreal_3_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_23:
" for x be ExtRealXXREAL-0M1 holds (x =HIDDENR1 +inftyXXREAL-0K1 iff -XXREAL-3K2 x =HIDDENR1 -inftyXXREAL-0K2) & (x =HIDDENR1 -inftyXXREAL-0K2 iff -XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds (( not (x =HIDDENR1 +inftyXXREAL-0K1 &  not -XXREAL-3K2 x =HIDDENR1 -inftyXXREAL-0K2) &  not (-XXREAL-3K2 x =HIDDENR1 -inftyXXREAL-0K2 &  not x =HIDDENR1 +inftyXXREAL-0K1)) &  not (x =HIDDENR1 -inftyXXREAL-0K2 &  not -XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1)) &  not (-XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1 &  not x =HIDDENR1 -inftyXXREAL-0K2)"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have "-XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 -inftyXXREAL-0K2"
    proof(rule impI)
      assume "-XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1"
      then have "-XXREAL-3K2 (-XXREAL-3K2 x) =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_3_def_3 sorry
      thus "x =HIDDENR1 -inftyXXREAL-0K2"
         sorry
    qed
    thus "(( not (x =HIDDENR1 +inftyXXREAL-0K1 &  not -XXREAL-3K2 x =HIDDENR1 -inftyXXREAL-0K2) &  not (-XXREAL-3K2 x =HIDDENR1 -inftyXXREAL-0K2 &  not x =HIDDENR1 +inftyXXREAL-0K1)) &  not (x =HIDDENR1 -inftyXXREAL-0K2 &  not -XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1)) &  not (-XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1 &  not x =HIDDENR1 -inftyXXREAL-0K2)"
      using xxreal_3_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_24:
" for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds z be realXREAL-0V1 implies x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds z be realXREAL-0V1 implies x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "z be realXREAL-0V1"
    show "x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
    proof-
      have cases: "(x =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2) or x be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xxreal_0_th_14 sorry
      have case1: "x =HIDDENR1 +inftyXXREAL-0K1 implies x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
      proof(rule impI)
        assume A2: "x =HIDDENR1 +inftyXXREAL-0K1"
        then have "x +XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using A1 xxreal_3_def_2 sorry
        thus "x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
          using A1 A2 xxreal_3_th_13 sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
      proof(rule impI)
        assume A3: "x =HIDDENR1 -inftyXXREAL-0K2"
        then have "x +XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using A1 xxreal_3_def_2 sorry
        thus "x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
          using A1 A3 xxreal_3_th_14 sorry
      qed
      have case3: "x be ElementSUBSET-1M1-of REALNUMBERSK2 implies x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
      proof(rule impI)
        assume "x be ElementSUBSET-1M1-of REALNUMBERSK2"
        then obtain a c where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
          [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
          using A1 sorry
        have "(x +XXREAL-3K1 z)-XXREAL-3K3 z =HIDDENR1 (a +XXREAL-3K1 c)-XXREAL-3K3 c"
           sorry
        thus "x =HIDDENR1 (x +XXREAL-3K1 z)-XXREAL-3K3 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_10:
"-XXREAL-3K2 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
  using xxreal_3_def_3 sorry

mlemma xxreal_3_lm_11:
" for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 (-XXREAL-3K2 -inftyXXREAL-0K2)+XXREAL-3K1 (-XXREAL-3K2 x)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 (-XXREAL-3K2 -inftyXXREAL-0K2)+XXREAL-3K1 (-XXREAL-3K2 x)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have A1: "-XXREAL-3K2 -inftyXXREAL-0K2 =HIDDENR1 +inftyXXREAL-0K1"
      using xxreal_3_th_23 sorry
    assume A2: "x inHIDDENR3 REALNUMBERSK2"
    then have "x +XXREAL-3K1 -inftyXXREAL-0K2 =HIDDENR1 -inftyXXREAL-0K2"
      using xxreal_3_def_2 sorry
    thus "-XXREAL-3K2 (x +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 (-XXREAL-3K2 -inftyXXREAL-0K2)+XXREAL-3K1 (-XXREAL-3K2 x)"
      using A2 A1 xxreal_3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_25:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    show "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
    proof-
      have cases: "(((((((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) or x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        using xxreal_0_th_14 sorry
      have case1: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume A1: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1"
        then have "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 -XXREAL-3K2 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        also have "... = (-XXREAL-3K2 y)-XXREAL-3K3 x"
          using A1 xxreal_3_def_2 xxreal_3_lm_10 sorry
        finally show "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
           sorry
      qed
      have case2: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
          using xxreal_3_lm_4 sorry
      qed
      have case3: "x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
          using xxreal_3_lm_6 sorry
      qed
      have case4: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
          using xxreal_3_lm_4 sorry
      qed
      have case5: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume A2: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2"
        then have "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 -XXREAL-3K2 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        also have "... = (-XXREAL-3K2 y)-XXREAL-3K3 x"
          using A2 xxreal_3_def_2 xxreal_3_th_5 sorry
        finally show "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
           sorry
      qed
      have case6: "x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
          using xxreal_3_lm_11 sorry
      qed
      have case7: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
          using xxreal_3_lm_6 sorry
      qed
      have case8: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2"
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
          using xxreal_3_lm_11 sorry
      qed
      have case9: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies -XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        then obtain a b where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
          [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
           sorry
        have "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 -XXREAL-3K2 (a +XXREAL-3K1 b)"
           sorry
        also have "... = (-XXREAL-3K2 a)+XXREAL-3K1 (-XXREAL-3K2 b)"
           sorry
        finally have "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 a)+XXREAL-3K1 (-XXREAL-3K2 b)"
           sorry
        thus "-XXREAL-3K2 (x +XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 y)-XXREAL-3K3 x"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 case7 case8 case9 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_26:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 (x -XXREAL-3K3 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 y & -XXREAL-3K2 (x -XXREAL-3K3 y) =HIDDENR1 y -XXREAL-3K3 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 (x -XXREAL-3K3 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 y & -XXREAL-3K2 (x -XXREAL-3K3 y) =HIDDENR1 y -XXREAL-3K3 x"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "-XXREAL-3K2 (x -XXREAL-3K3 y) =HIDDENR1 (-XXREAL-3K2 (-XXREAL-3K2 y))-XXREAL-3K3 x"
      using xxreal_3_th_25 sorry
    thus "-XXREAL-3K2 (x -XXREAL-3K3 y) =HIDDENR1 (-XXREAL-3K2 x)+XXREAL-3K1 y & -XXREAL-3K2 (x -XXREAL-3K3 y) =HIDDENR1 y -XXREAL-3K3 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_27:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 ((-XXREAL-3K2 x)+XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y & -XXREAL-3K2 ((-XXREAL-3K2 x)+XXREAL-3K1 y) =HIDDENR1 x +XXREAL-3K1 (-XXREAL-3K2 y)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 ((-XXREAL-3K2 x)+XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y & -XXREAL-3K2 ((-XXREAL-3K2 x)+XXREAL-3K1 y) =HIDDENR1 x +XXREAL-3K1 (-XXREAL-3K2 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "-XXREAL-3K2 ((-XXREAL-3K2 x)+XXREAL-3K1 y) =HIDDENR1 (-XXREAL-3K2 (-XXREAL-3K2 x))-XXREAL-3K3 y"
      using xxreal_3_th_25 sorry
    also have "... = x -XXREAL-3K3 y"
       sorry
    finally have "-XXREAL-3K2 ((-XXREAL-3K2 x)+XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
       sorry
    thus "-XXREAL-3K2 ((-XXREAL-3K2 x)+XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y & -XXREAL-3K2 ((-XXREAL-3K2 x)+XXREAL-3K1 y) =HIDDENR1 x +XXREAL-3K1 (-XXREAL-3K2 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_28:
" for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 y & y <XXREAL-0R3 +inftyXXREAL-0K1 implies z =HIDDENR1 (z +XXREAL-3K1 y)-XXREAL-3K3 y"
proof-
  have " for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 y & y <XXREAL-0R3 +inftyXXREAL-0K1 implies z =HIDDENR1 (z +XXREAL-3K1 y)-XXREAL-3K3 y"
  proof(rule ballI,rule ballI,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume "0NUMBERSK6 <=XXREAL-3R1 y & y <XXREAL-0R3 +inftyXXREAL-0K1"
    then have "y inHIDDENR3 REALNUMBERSK2"
      using xxreal_0_th_14 sorry
    thus "z =HIDDENR1 (z +XXREAL-3K1 y)-XXREAL-3K3 y"
      using xxreal_3_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_29:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (( not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1)) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)) &  not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds ( not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)) &  not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "( not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)) &  not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)"
    show "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
    proof-
      have cases: "(((((((((((x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2 or (x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) & z inHIDDENR3 REALNUMBERSK2) or (x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2) or (x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2) or (x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2) or (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 +inftyXXREAL-0K1) or (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 -inftyXXREAL-0K2) or (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) & z inHIDDENR3 REALNUMBERSK2) or (x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z =HIDDENR1 -inftyXXREAL-0K2) or (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2) or ((((x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 -inftyXXREAL-0K2 or (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & z =HIDDENR1 -inftyXXREAL-0K2) or (x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 +inftyXXREAL-0K1) or (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) & z =HIDDENR1 +inftyXXREAL-0K1)) or (x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) & z =HIDDENR1 +inftyXXREAL-0K1"
        using A1 xxreal_0_th_14 sorry
      have case1: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2"
        then obtain A B C where 
          [ty]:"A be RealXREAL-0M1" and ADef:"A = x" and
          [ty]:"B be RealXREAL-0M1" and BDef:"B = y" and
          [ty]:"C be RealXREAL-0M1" and CDef:"C = z"
           sorry
        have "(A +XXREAL-3K1 B)+XXREAL-3K1 C =HIDDENR1 (x +XXREAL-3K1 y)+XXREAL-3K1 z & A +XXREAL-3K1 (B +XXREAL-3K1 C) =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
           sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
           sorry
      qed
      have case2: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) & z inHIDDENR3 REALNUMBERSK2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A2: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) & z inHIDDENR3 REALNUMBERSK2"
        then have "x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1 & y +XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A2 sorry
      qed
      have case3: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A3: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2"
        then have "x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2 & y +XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A3 sorry
      qed
      have case4: "(x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A4: "(x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2"
        then have "x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        then have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using A4 xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A4 xxreal_3_def_2 sorry
      qed
      have case5: "(x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A5: "(x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2"
        then have "x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        then have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using A5 xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A5 xxreal_3_def_2 sorry
      qed
      have case6: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 +inftyXXREAL-0K1 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A6: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 +inftyXXREAL-0K1"
        then have "y +XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        then have "x +XXREAL-3K1 (y +XXREAL-3K1 z) =HIDDENR1 +inftyXXREAL-0K1"
          using A6 xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A6 xxreal_3_def_2 sorry
      qed
      have case7: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 -inftyXXREAL-0K2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A7: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 -inftyXXREAL-0K2"
        then have "y +XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        then have "x +XXREAL-3K1 (y +XXREAL-3K1 z) =HIDDENR1 -inftyXXREAL-0K2"
          using A7 xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A7 xxreal_3_def_2 sorry
      qed
      have case8: "(x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) & z inHIDDENR3 REALNUMBERSK2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A8: "(x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) & z inHIDDENR3 REALNUMBERSK2"
        then have "x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        then have A9: "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using A8 xxreal_3_def_2 sorry
        have "y +XXREAL-3K1 z <>HIDDENR2 -inftyXXREAL-0K2"
          using A8 xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A8 A9 xxreal_3_def_2 sorry
      qed
      have case9: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z =HIDDENR1 -inftyXXREAL-0K2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A10: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z =HIDDENR1 -inftyXXREAL-0K2"
        then have A11: "x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        then have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using A10 xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A10 A11 sorry
      qed
      have case10: "(x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A12: "(x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2"
        then have A13: "x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        then have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using A12 xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A12 A13 sorry
      qed
      have case11: "(((x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 -inftyXXREAL-0K2 or (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & z =HIDDENR1 -inftyXXREAL-0K2) or (x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 +inftyXXREAL-0K1) or (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) & z =HIDDENR1 +inftyXXREAL-0K1 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume "(((x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 -inftyXXREAL-0K2 or (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & z =HIDDENR1 -inftyXXREAL-0K2) or (x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z =HIDDENR1 +inftyXXREAL-0K1) or (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) & z =HIDDENR1 +inftyXXREAL-0K1"
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
           sorry
      qed
      have case12: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) & z =HIDDENR1 +inftyXXREAL-0K1 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A14: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) & z =HIDDENR1 +inftyXXREAL-0K1"
        then have "x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1 & y +XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A14 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 case7 case8 case9 case10 case11 case12 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_30:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (((( not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1)) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1)) &  not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2)) &  not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1)) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2) implies (x +XXREAL-3K1 y)-XXREAL-3K3 z =HIDDENR1 x +XXREAL-3K1 (y -XXREAL-3K3 z)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds ( not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1)) & (( not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) &  not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2)) & ( not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2))) implies (x +XXREAL-3K1 y)-XXREAL-3K3 z =HIDDENR1 x +XXREAL-3K1 (y -XXREAL-3K3 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1)"
      and A2: " not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) &  not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2)"
      and A3: " not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2)"
    have A4: " not (x =HIDDENR1 +inftyXXREAL-0K1 & -XXREAL-3K2 z =HIDDENR1 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & -XXREAL-3K2 z =HIDDENR1 +inftyXXREAL-0K1)"
      using A3 xxreal_3_th_23 sorry
    have " not (y =HIDDENR1 +inftyXXREAL-0K1 & -XXREAL-3K2 z =HIDDENR1 -inftyXXREAL-0K2) &  not (y =HIDDENR1 -inftyXXREAL-0K2 & -XXREAL-3K2 z =HIDDENR1 +inftyXXREAL-0K1)"
      using A2 xxreal_3_th_23 sorry
    thus "(x +XXREAL-3K1 y)-XXREAL-3K3 z =HIDDENR1 x +XXREAL-3K1 (y -XXREAL-3K3 z)"
      using A1 A4 xxreal_3_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_31:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (((( not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2)) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2)) &  not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)) &  not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1)) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2) implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) & ( not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & ( not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2) & ( not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) & ( not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2))))) implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1)"
      and A2: " not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2)"
      and A3: " not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2)"
      and A4: " not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)"
      and A5: " not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1)"
      and A6: " not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2)"
    show "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
    proof-
      have cases: "(x =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2) or x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
         sorry
      have case1: "x =HIDDENR1 +inftyXXREAL-0K1 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A7: "x =HIDDENR1 +inftyXXREAL-0K1"
        then have "x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1"
          using A1 xxreal_3_th_13 sorry
        then have A8: "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 +inftyXXREAL-0K1"
          using A5 A7 xxreal_3_th_13 sorry
        have "y +XXREAL-3K1 z <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A5 A7 xxreal_3_lm_8 sorry
        thus "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
          using A7 A8 xxreal_3_th_13 sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A9: "x =HIDDENR1 -inftyXXREAL-0K2"
        then have "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
          using A2 xxreal_3_th_14 sorry
        then have A10: "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 -inftyXXREAL-0K2"
          using A6 A9 xxreal_3_th_14 sorry
        have "y +XXREAL-3K1 z <>HIDDENR2 -inftyXXREAL-0K2"
          using A2 A6 A9 xxreal_3_lm_9 sorry
        thus "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
          using A9 A10 xxreal_3_th_14 sorry
      qed
      have case3: "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A11: "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
        then have "x inHIDDENR3 REALNUMBERSK2"
          using xxreal_0_th_14 sorry
        then obtain a where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
           sorry
        show "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
        proof-
          have cases: "(y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2) or y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
          have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
          proof(rule impI)
            assume A12: "y =HIDDENR1 +inftyXXREAL-0K1"
            then have "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2 & y +XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
              using A3 A11 xxreal_3_def_2 xxreal_3_th_13 sorry
            thus "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
              using A3 A12 xxreal_3_th_14 sorry
          qed
          have case2: "y =HIDDENR1 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
          proof(rule impI)
            assume A13: "y =HIDDENR1 -inftyXXREAL-0K2"
            then have "x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1 & y +XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
              using A4 A11 xxreal_3_def_2 xxreal_3_th_14 sorry
            thus "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
              using A4 A13 xxreal_3_th_13 sorry
          qed
          have case3: "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
          proof(rule impI)
            assume "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
            then have "y inHIDDENR3 REALNUMBERSK2"
              using xxreal_0_th_14 sorry
            then obtain b where 
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
               sorry
            have A14: "x -XXREAL-3K3 y =HIDDENR1 a -XXREAL-3K3 b"
               sorry
            show "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
            proof-
              have cases: "(z =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 -inftyXXREAL-0K2) or z <>HIDDENR2 +inftyXXREAL-0K1 & z <>HIDDENR2 -inftyXXREAL-0K2"
                 sorry
              have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
              proof(rule impI)
                assume "z =HIDDENR1 +inftyXXREAL-0K1"
                then have "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 -inftyXXREAL-0K2 & y +XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
                  using A14 xxreal_3_def_2 xxreal_3_th_13 sorry
                thus "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
                  using A11 xxreal_3_th_13 sorry
              qed
              have case2: "z =HIDDENR1 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
              proof(rule impI)
                assume "z =HIDDENR1 -inftyXXREAL-0K2"
                then have "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 +inftyXXREAL-0K1 & y +XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
                  using A14 xxreal_3_def_2 xxreal_3_th_14 sorry
                thus "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
                  using A11 xxreal_3_th_14 sorry
              qed
              have case3: "z <>HIDDENR2 +inftyXXREAL-0K1 & z <>HIDDENR2 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
              proof(rule impI)
                assume "z <>HIDDENR2 +inftyXXREAL-0K1 & z <>HIDDENR2 -inftyXXREAL-0K2"
                then have "z inHIDDENR3 REALNUMBERSK2"
                  using xxreal_0_th_14 sorry
                then obtain c where 
                  [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
                   sorry
                have "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 (a -XXREAL-3K3 b)-XXREAL-3K3 c & x -XXREAL-3K3 (y +XXREAL-3K1 z) =HIDDENR1 a -XXREAL-3K3 (b +XXREAL-3K1 c)"
                   sorry
                thus "(x -XXREAL-3K3 y)-XXREAL-3K3 z =HIDDENR1 x -XXREAL-3K3 (y +XXREAL-3K1 z)"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_32:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (((( not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2)) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1)) &  not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2)) &  not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2)) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1) & ( not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & ( not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) & ( not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2) & ( not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1))))) implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1)"
      and A2: " not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2)"
      and A3: " not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1)"
      and A4: " not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2)"
      and A5: " not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2)"
      and A6: " not (x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)"
    show "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
    proof-
      have cases: "(x =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2) or x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
         sorry
      have case1: "x =HIDDENR1 +inftyXXREAL-0K1 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
      proof(rule impI)
        assume A7: "x =HIDDENR1 +inftyXXREAL-0K1"
        then have "x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1"
          using A1 xxreal_3_th_13 sorry
        then have A8: "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using A5 A7 xxreal_3_def_2 sorry
        have "y -XXREAL-3K3 z <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A5 A7 xxreal_3_th_18 sorry
        thus "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
          using A7 A8 xxreal_3_th_13 sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
      proof(rule impI)
        assume A9: "x =HIDDENR1 -inftyXXREAL-0K2"
        then have "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
          using A2 xxreal_3_th_14 sorry
        then have A10: "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using A6 A9 xxreal_3_def_2 sorry
        have "y -XXREAL-3K3 z <>HIDDENR2 -inftyXXREAL-0K2"
          using A2 A6 A9 xxreal_3_th_19 sorry
        thus "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
          using A9 A10 xxreal_3_th_14 sorry
      qed
      have case3: "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
      proof(rule impI)
        assume A11: "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
        then have "x inHIDDENR3 REALNUMBERSK2"
          using xxreal_0_th_14 sorry
        then obtain a where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
           sorry
        show "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
        proof-
          have cases: "(y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2) or y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
          have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
          proof(rule impI)
            assume A12: "y =HIDDENR1 +inftyXXREAL-0K1"
            then have "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2 & y -XXREAL-3K3 z =HIDDENR1 +inftyXXREAL-0K1"
              using A3 A11 xxreal_3_th_13 sorry
            thus "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
              using A3 A12 xxreal_3_def_2 sorry
          qed
          have case2: "y =HIDDENR1 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
          proof(rule impI)
            assume A13: "y =HIDDENR1 -inftyXXREAL-0K2"
            then have "x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1 & y -XXREAL-3K3 z =HIDDENR1 -inftyXXREAL-0K2"
              using A4 A11 xxreal_3_th_14 sorry
            thus "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
              using A4 A13 xxreal_3_def_2 sorry
          qed
          have case3: "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
          proof(rule impI)
            assume "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
            then have "y inHIDDENR3 REALNUMBERSK2"
              using xxreal_0_th_14 sorry
            then obtain b where 
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
               sorry
            have A14: "x -XXREAL-3K3 y =HIDDENR1 a -XXREAL-3K3 b"
               sorry
            show "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
            proof-
              have cases: "(z =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 -inftyXXREAL-0K2) or z <>HIDDENR2 +inftyXXREAL-0K1 & z <>HIDDENR2 -inftyXXREAL-0K2"
                 sorry
              have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
              proof(rule impI)
                assume "z =HIDDENR1 +inftyXXREAL-0K1"
                then have "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1 & y -XXREAL-3K3 z =HIDDENR1 -inftyXXREAL-0K2"
                  using A14 xxreal_3_def_2 xxreal_3_th_13 sorry
                thus "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
                  using A11 xxreal_3_th_14 sorry
              qed
              have case2: "z =HIDDENR1 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
              proof(rule impI)
                assume "z =HIDDENR1 -inftyXXREAL-0K2"
                then have "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2 & y -XXREAL-3K3 z =HIDDENR1 +inftyXXREAL-0K1"
                  using A14 xxreal_3_def_2 xxreal_3_th_14 sorry
                thus "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
                  using A11 xxreal_3_th_13 sorry
              qed
              have case3: "z <>HIDDENR2 +inftyXXREAL-0K1 & z <>HIDDENR2 -inftyXXREAL-0K2 implies (x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
              proof(rule impI)
                assume "z <>HIDDENR2 +inftyXXREAL-0K1 & z <>HIDDENR2 -inftyXXREAL-0K2"
                then have "z inHIDDENR3 REALNUMBERSK2"
                  using xxreal_0_th_14 sorry
                then obtain c where 
                  [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
                   sorry
                have "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 (a -XXREAL-3K3 b)+XXREAL-3K1 c & x -XXREAL-3K3 (y -XXREAL-3K3 z) =HIDDENR1 a -XXREAL-3K3 (b -XXREAL-3K3 c)"
                   sorry
                thus "(x -XXREAL-3K3 y)+XXREAL-3K1 z =HIDDENR1 x -XXREAL-3K3 (y -XXREAL-3K3 z)"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_33:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds z be realXREAL-0V1 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds z be realXREAL-0V1 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "z be realXREAL-0V1"
    show "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
    proof-
      have cases: "((((x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1) or (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2) or (x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2) or (x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2) or (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2"
        using A1 xxreal_0_th_14 sorry
      have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
      proof(rule impI)
        assume A2: "x =HIDDENR1 -inftyXXREAL-0K2"
        show "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
        proof-
          have cases: "(y =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1) or y inHIDDENR3 REALNUMBERSK2"
            using xxreal_0_th_14 sorry
          have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
          proof(rule impI)
            assume A3: "y =HIDDENR1 -inftyXXREAL-0K2"
            have "(z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 (z +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 -inftyXXREAL-0K2 -XXREAL-3K3 (z +XXREAL-3K1 -inftyXXREAL-0K2)"
              using A1 xxreal_3_def_2 sorry
            also have "... = -inftyXXREAL-0K2 -XXREAL-3K3 -inftyXXREAL-0K2"
              using A1 xxreal_3_def_2 sorry
            finally have "(z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 (z +XXREAL-3K1 -inftyXXREAL-0K2) =HIDDENR1 -inftyXXREAL-0K2 -XXREAL-3K3 -inftyXXREAL-0K2"
               sorry
            thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
              using A2 A3 sorry
          qed
          have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
          proof(rule impI)
            assume A4: "y =HIDDENR1 +inftyXXREAL-0K1"
            have "(z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 -inftyXXREAL-0K2 -XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1)"
              using A1 xxreal_3_def_2 sorry
            also have "... = -inftyXXREAL-0K2 -XXREAL-3K3 +inftyXXREAL-0K1"
              using A1 xxreal_3_def_2 sorry
            finally have "(z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 -inftyXXREAL-0K2 -XXREAL-3K3 +inftyXXREAL-0K1"
               sorry
            thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
              using A2 A4 sorry
          qed
          have case3: "y inHIDDENR3 REALNUMBERSK2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
          proof(rule impI)
            assume A5: "y inHIDDENR3 REALNUMBERSK2"
            then obtain a b where
              [ty]:"a be ComplexXCMPLX-0M1" "b be ComplexXCMPLX-0M1" and 
              A6: "z =HIDDENR1 a & y =HIDDENR1 b"and "z +XXREAL-3K1 y =HIDDENR1 a +XCMPLX-0K2 b"
              using A1 xxreal_3_def_2 sorry
            have 
              [ty]:"a be RealXREAL-0M1" and
              [ty]:"b be RealXREAL-0M1"
              using A1 A5 A6 sorry
            have A7: "a +XXREAL-3K1 b inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            have "(z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 -inftyXXREAL-0K2 -XXREAL-3K3 (z +XXREAL-3K1 y)"
              using A1 xxreal_3_def_2 sorry
            also have "... = -inftyXXREAL-0K2"
              using A6 A7 xxreal_3_def_2 sorry
            also have "... = -inftyXXREAL-0K2 -XXREAL-3K3 y"
              using A5 xxreal_3_def_2 sorry
            finally have "(z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 -inftyXXREAL-0K2 -XXREAL-3K3 y"
               sorry
            thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
              using A2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
      proof(rule impI)
        assume A8: "y =HIDDENR1 +inftyXXREAL-0K1"
        show "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
        proof-
          have cases: "(x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1) or x inHIDDENR3 REALNUMBERSK2"
            using xxreal_0_th_14 sorry
          have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
          proof(rule impI)
            assume A9: "x =HIDDENR1 -inftyXXREAL-0K2"
            have "(z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 (z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 +inftyXXREAL-0K1"
              using A1 xxreal_3_def_2 sorry
            also have "... = -inftyXXREAL-0K2 -XXREAL-3K3 +inftyXXREAL-0K1"
              using A1 xxreal_3_def_2 sorry
            finally have "(z +XXREAL-3K1 -inftyXXREAL-0K2)-XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 -inftyXXREAL-0K2 -XXREAL-3K3 +inftyXXREAL-0K1"
               sorry
            thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
              using A8 A9 sorry
          qed
          have case2: "x =HIDDENR1 +inftyXXREAL-0K1 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
          proof(rule impI)
            assume A10: "x =HIDDENR1 +inftyXXREAL-0K1"
            have "(z +XXREAL-3K1 +inftyXXREAL-0K1)-XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 (z +XXREAL-3K1 +inftyXXREAL-0K1)-XXREAL-3K3 +inftyXXREAL-0K1"
              using A1 xxreal_3_def_2 sorry
            also have "... = +inftyXXREAL-0K1 -XXREAL-3K3 +inftyXXREAL-0K1"
              using A1 xxreal_3_def_2 sorry
            finally have "(z +XXREAL-3K1 +inftyXXREAL-0K1)-XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 +inftyXXREAL-0K1 -XXREAL-3K3 +inftyXXREAL-0K1"
               sorry
            thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
              using A8 A10 sorry
          qed
          have case3: "x inHIDDENR3 REALNUMBERSK2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
          proof(rule impI)
            assume A11: "x inHIDDENR3 REALNUMBERSK2"
            then obtain a b where
              [ty]:"a be ComplexXCMPLX-0M1" "b be ComplexXCMPLX-0M1" and 
              A12: "z =HIDDENR1 a & x =HIDDENR1 b"and "z +XXREAL-3K1 x =HIDDENR1 a +XCMPLX-0K2 b"
              using A1 xxreal_3_def_2 sorry
            have 
              [ty]:"a be RealXREAL-0M1" and
              [ty]:"b be RealXREAL-0M1"
              using A1 A11 A12 sorry
            have A13: "a +XXREAL-3K1 b inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            have A14: "-XXREAL-3K2 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
              using xxreal_3_def_3 sorry
            have "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 (z +XXREAL-3K1 x)-XXREAL-3K3 +inftyXXREAL-0K1"
              using A1 xxreal_3_def_2 sorry
            also have "... = (z +XXREAL-3K1 x)+XXREAL-3K1 -inftyXXREAL-0K2"
              using xxreal_3_def_3 sorry
            also have "... = -inftyXXREAL-0K2"
              using A12 A13 xxreal_3_def_2 sorry
            also have "... = x +XXREAL-3K1 (-XXREAL-3K2 +inftyXXREAL-0K1)"
              using A11 A14 xxreal_3_def_2 sorry
            finally have "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 +inftyXXREAL-0K1) =HIDDENR1 x +XXREAL-3K1 (-XXREAL-3K2 +inftyXXREAL-0K1)"
               sorry
            thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
              using A8 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      have case3: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
      proof(rule impI)
        assume "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2"
        then obtain a b c where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
          [ty]:"b be RealXREAL-0M1" and bDef:"b = y" and
          [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
           sorry
        have "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 (a +XXREAL-3K1 c)-XXREAL-3K3 (c +XXREAL-3K1 b)"
           sorry
        also have "... = a -XXREAL-3K3 b"
           sorry
        also have "... = x -XXREAL-3K3 y"
           sorry
        finally have "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
           sorry
        thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
           sorry
      qed
      have case4: "(x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
      proof(rule impI)
        assume A15: "(x =HIDDENR1 +inftyXXREAL-0K1 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2"
        then obtain c b where 
          [ty]:"c be RealXREAL-0M1" and cDef:"c = z" and
          [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
           sorry
        have A16: "z +XXREAL-3K1 y =HIDDENR1 c +XXREAL-3K1 b"
           sorry
        have "z +XXREAL-3K1 x =HIDDENR1 +inftyXXREAL-0K1 & x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1"
          using A15 xxreal_3_def_2 sorry
        thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
          using A16 xxreal_3_th_13 sorry
      qed
      have case5: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
      proof(rule impI)
        assume A17: "(x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2"
        then obtain c a where 
          [ty]:"c be RealXREAL-0M1" and cDef:"c = z" and
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
           sorry
        have "z +XXREAL-3K1 x =HIDDENR1 c +XXREAL-3K1 a & z +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2"
          using A17 xxreal_3_def_2 sorry
        then have "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_th_14 sorry
        also have "... = x -XXREAL-3K3 y"
          using A17 xxreal_3_th_14 sorry
        finally have "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
           sorry
        thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
           sorry
      qed
      have case6: "(x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2 implies (z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
      proof(rule impI)
        assume A18: "(x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) & z inHIDDENR3 REALNUMBERSK2"
        then have "z +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2 &  not z +XXREAL-3K1 x =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        then have "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_th_14 sorry
        also have "... = x -XXREAL-3K3 y"
          using A18 xxreal_3_th_14 sorry
        finally have "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
           sorry
        thus "(z +XXREAL-3K1 x)-XXREAL-3K3 (z +XXREAL-3K1 y) =HIDDENR1 x -XXREAL-3K3 y"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_34:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y be realXREAL-0V1 implies (z -XXREAL-3K3 y)+XXREAL-3K1 (y -XXREAL-3K3 x) =HIDDENR1 z -XXREAL-3K3 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y be realXREAL-0V1 implies (z -XXREAL-3K3 y)+XXREAL-3K1 (y -XXREAL-3K3 x) =HIDDENR1 z -XXREAL-3K3 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "y be realXREAL-0V1"
    have "(z -XXREAL-3K3 y)+XXREAL-3K1 (y -XXREAL-3K3 x) =HIDDENR1 (z -XXREAL-3K3 y)-XXREAL-3K3 (x -XXREAL-3K3 y)"
      using xxreal_3_th_27 sorry
    also have "... = z -XXREAL-3K3 x"
      using A1 xxreal_3_th_33 sorry
    finally show "(z -XXREAL-3K3 y)+XXREAL-3K1 (y -XXREAL-3K3 x) =HIDDENR1 z -XXREAL-3K3 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mlemma xxreal_3_lm_12:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-3R1 y"
    show "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
    proof-
      have cases: "((((x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
      proof(rule impI)
        assume A2: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        show "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
        proof-
          have cases: "(z =HIDDENR1 -inftyXXREAL-0K2 or z inHIDDENR3 REALNUMBERSK2) or z =HIDDENR1 +inftyXXREAL-0K1"
            using xxreal_0_th_14 sorry
          have case1: "z =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A3: "z =HIDDENR1 -inftyXXREAL-0K2"
            have "-inftyXXREAL-0K2 <=XXREAL-3R1 y +XXREAL-3K1 z"
              using xxreal_0_th_5 sorry
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A2 A3 xxreal_3_def_2 sorry
          qed
          have case2: "z inHIDDENR3 REALNUMBERSK2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume "z inHIDDENR3 REALNUMBERSK2"
            then have 
              [ty]:"x be RealXREAL-0M1" and
              [ty]:"y be RealXREAL-0M1" and
              [ty]:"z be RealXREAL-0M1"
              using A2 sorry
            have "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A1 xreal_1_th_6 sorry
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
               sorry
          qed
          have case3: "z =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A4: "z =HIDDENR1 +inftyXXREAL-0K1"
            have "x +XXREAL-3K1 z <=XXREAL-3R1 +inftyXXREAL-0K1"
              using xxreal_0_th_3 sorry
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A2 A4 xxreal_3_def_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      have case2: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
      proof(rule impI)
        assume A5: "x inHIDDENR3 REALNUMBERSK2 & y =HIDDENR1 +inftyXXREAL-0K1"
        show "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
        proof-
          have cases: "(z =HIDDENR1 -inftyXXREAL-0K2 or z inHIDDENR3 REALNUMBERSK2) or z =HIDDENR1 +inftyXXREAL-0K1"
            using xxreal_0_th_14 sorry
          have case1: "z =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A6: "z =HIDDENR1 -inftyXXREAL-0K2"
            have "-inftyXXREAL-0K2 <=XXREAL-3R1 y +XXREAL-3K1 z"
              using xxreal_0_th_5 sorry
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A5 A6 xxreal_3_def_2 sorry
          qed
          have case2: "z inHIDDENR3 REALNUMBERSK2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A7: "z inHIDDENR3 REALNUMBERSK2"
            have "x +XXREAL-3K1 z <=XXREAL-3R1 +inftyXXREAL-0K1"
              using xxreal_0_th_3 sorry
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A5 A7 xxreal_3_def_2 sorry
          qed
          have case3: "z =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume "z =HIDDENR1 +inftyXXREAL-0K1"
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A5 xxreal_3_lm_1 xxreal_0_th_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      have case3: "x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
      proof(rule impI)
        assume A8: "x =HIDDENR1 -inftyXXREAL-0K2 & y inHIDDENR3 REALNUMBERSK2"
        show "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
        proof-
          have cases: "(z =HIDDENR1 -inftyXXREAL-0K2 or z inHIDDENR3 REALNUMBERSK2) or z =HIDDENR1 +inftyXXREAL-0K1"
            using xxreal_0_th_14 sorry
          have case1: "z =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume "z =HIDDENR1 -inftyXXREAL-0K2"
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A8 xxreal_3_lm_2 xxreal_0_th_5 sorry
          qed
          have case2: "z inHIDDENR3 REALNUMBERSK2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A9: "z inHIDDENR3 REALNUMBERSK2"
            have "-inftyXXREAL-0K2 <=XXREAL-3R1 y +XXREAL-3K1 z"
              using xxreal_0_th_5 sorry
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A8 A9 xxreal_3_def_2 sorry
          qed
          have case3: "z =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A10: "z =HIDDENR1 +inftyXXREAL-0K1"
            have "x +XXREAL-3K1 z <=XXREAL-3R1 +inftyXXREAL-0K1"
              using xxreal_0_th_3 sorry
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A8 A10 xxreal_3_def_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      have case4: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
      proof(rule impI)
        assume A11: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1"
        show "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
        proof-
          have cases: "(z =HIDDENR1 -inftyXXREAL-0K2 or z inHIDDENR3 REALNUMBERSK2) or z =HIDDENR1 +inftyXXREAL-0K1"
            using xxreal_0_th_14 sorry
          have case1: "z =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume "z =HIDDENR1 -inftyXXREAL-0K2"
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A11 xxreal_3_lm_2 sorry
          qed
          have case2: "z inHIDDENR3 REALNUMBERSK2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A12: "z inHIDDENR3 REALNUMBERSK2"
            have "-inftyXXREAL-0K2 <=XXREAL-3R1 y +XXREAL-3K1 z"
              using xxreal_0_th_5 sorry
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A11 A12 xxreal_3_def_2 sorry
          qed
          have case3: "z =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          proof(rule impI)
            assume "z =HIDDENR1 +inftyXXREAL-0K1"
            thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
              using A11 xxreal_3_lm_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      have case5: "x =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1"
        thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          using A1 xxreal_0_th_4 sorry
      qed
      have case6: "y =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
      proof(rule impI)
        assume "y =HIDDENR1 -inftyXXREAL-0K2"
        thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
          using A1 xxreal_0_th_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_13:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6 implies x +XXREAL-3K1 y >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 implies  not ( not y >XXREAL-0R4 0NUMBERSK6 & x +XXREAL-3K1 y >XXREAL-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume "x >=XXREAL-0R2 0NUMBERSK6"
    then have "x +XXREAL-3K1 y >=XXREAL-0R2 0NUMBERSK6 +XXREAL-3K1 y"
      using xxreal_3_lm_12 sorry
    thus " not ( not y >XXREAL-0R4 0NUMBERSK6 & x +XXREAL-3K1 y >XXREAL-0R4 0NUMBERSK6)"
      using xxreal_3_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_14:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6 implies x +XXREAL-3K1 y <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 0NUMBERSK6 implies  not ( not y <XXREAL-0R3 0NUMBERSK6 & x +XXREAL-3K1 y <XXREAL-0R3 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume "x <=XXREAL-3R1 0NUMBERSK6"
    then have "x +XXREAL-3K1 y <=XXREAL-3R1 0NUMBERSK6 +XXREAL-3K1 y"
      using xxreal_3_lm_12 sorry
    thus " not ( not y <XXREAL-0R3 0NUMBERSK6 & x +XXREAL-3K1 y <XXREAL-0R3 0NUMBERSK6)"
      using xxreal_3_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_cl_12:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x +XXREAL-3K1 y as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be  non negativeXXREAL-0V3"
  proof-
    have "x +XXREAL-3K1 y >=XXREAL-0R2 0NUMBERSK6"
    proof-
      show "x +XXREAL-3K1 y >=XXREAL-0R2 0NUMBERSK6"
      proof-
        have cases: "x =HIDDENR1 0NUMBERSK6 or x >XXREAL-0R4 0NUMBERSK6"
           sorry
        have case1: "x =HIDDENR1 0NUMBERSK6 implies  not x +XXREAL-3K1 y be negativeXXREAL-0V3"
        proof(rule impI)
          assume Cut1261: "x =HIDDENR1 0NUMBERSK6"
          have "x +XXREAL-3K1 y >=XXREAL-0R2 0NUMBERSK6"
          proof-
            show "x +XXREAL-3K1 y >=XXREAL-0R2 0NUMBERSK6"
              using xxreal_3_th_4 Cut1261 sorry
          qed
          thus " not x +XXREAL-3K1 y be negativeXXREAL-0V3"
            using xxreal_0_def_7 sorry
        qed
        have case2: "x >XXREAL-0R4 0NUMBERSK6 implies  not x +XXREAL-3K1 y be negativeXXREAL-0V3"
        proof(rule impI)
          assume Cut1265: "x >XXREAL-0R4 0NUMBERSK6"
          have "x +XXREAL-3K1 y >=XXREAL-0R2 0NUMBERSK6"
          proof-
            show "x +XXREAL-3K1 y >=XXREAL-0R2 0NUMBERSK6"
              using xxreal_3_lm_13 Cut1265 sorry
          qed
          thus " not x +XXREAL-3K1 y be negativeXXREAL-0V3"
            using xxreal_0_def_7 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_13:
  mlet "x be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x +XXREAL-3K1 y as-term-is  non positiveXXREAL-0V2"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be  non positiveXXREAL-0V2"
  proof-
    have "x +XXREAL-3K1 y <=XXREAL-3R1 0NUMBERSK6"
    proof-
      show "x +XXREAL-3K1 y <=XXREAL-3R1 0NUMBERSK6"
      proof-
        have cases: "x =HIDDENR1 0NUMBERSK6 or x <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "x =HIDDENR1 0NUMBERSK6 implies  not x +XXREAL-3K1 y be positiveXXREAL-0V2"
        proof(rule impI)
          assume Cut1278: "x =HIDDENR1 0NUMBERSK6"
          have "x +XXREAL-3K1 y <=XXREAL-3R1 0NUMBERSK6"
          proof-
            show "x +XXREAL-3K1 y <=XXREAL-3R1 0NUMBERSK6"
              using xxreal_3_th_4 Cut1278 sorry
          qed
          thus " not x +XXREAL-3K1 y be positiveXXREAL-0V2"
            using xxreal_0_def_6 sorry
        qed
        have case2: "x <XXREAL-0R3 0NUMBERSK6 implies  not x +XXREAL-3K1 y be positiveXXREAL-0V2"
        proof(rule impI)
          assume Cut1282: "x <XXREAL-0R3 0NUMBERSK6"
          have "x +XXREAL-3K1 y <=XXREAL-3R1 0NUMBERSK6"
          proof-
            show "x +XXREAL-3K1 y <=XXREAL-3R1 0NUMBERSK6"
              using xxreal_3_lm_14 Cut1282 sorry
          qed
          thus " not x +XXREAL-3K1 y be positiveXXREAL-0V2"
            using xxreal_0_def_6 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_14:
  mlet "x be positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x +XXREAL-3K1 y as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be positiveXXREAL-0V2"
    using xxreal_3_lm_13 sorry
qed "sorry"

mtheorem xxreal_3_cl_15:
  mlet "x be positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster y +XXREAL-3K1 x as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "y +XXREAL-3K1 x be positiveXXREAL-0V2"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_16:
  mlet "x be negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x +XXREAL-3K1 y as-term-is negativeXXREAL-0V3"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be negativeXXREAL-0V3"
    using xxreal_3_lm_14 sorry
qed "sorry"

mtheorem xxreal_3_cl_17:
  mlet "x be negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster y +XXREAL-3K1 x as-term-is negativeXXREAL-0V3"
proof
(*coherence*)
  show "y +XXREAL-3K1 x be negativeXXREAL-0V3"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_18:
  mlet "x be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster -XXREAL-3K2 x as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "-XXREAL-3K2 x be  non negativeXXREAL-0V3"
  proof-
    have " not -XXREAL-3K2 x be negativeXXREAL-0V3"
    proof-
      have "-XXREAL-3K2 x <XXREAL-0R3 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "-XXREAL-3K2 x <XXREAL-0R3 0NUMBERSK6"
        then have "(-XXREAL-3K2 x)-XXREAL-3K3 (-XXREAL-3K2 x) <XXREAL-0R3 0NUMBERSK6"
           sorry
        thus " False "
          using xxreal_3_th_7 sorry
      qed
      thus " not -XXREAL-3K2 x be negativeXXREAL-0V3"
        using xxreal_0_def_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_19:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster -XXREAL-3K2 x as-term-is  non positiveXXREAL-0V2"
proof
(*coherence*)
  show "-XXREAL-3K2 x be  non positiveXXREAL-0V2"
  proof-
    have " not -XXREAL-3K2 x be positiveXXREAL-0V2"
    proof-
      have "-XXREAL-3K2 x >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "-XXREAL-3K2 x >XXREAL-0R4 0NUMBERSK6"
        then have "(-XXREAL-3K2 x)-XXREAL-3K3 (-XXREAL-3K2 x) >XXREAL-0R4 0NUMBERSK6"
           sorry
        thus " False "
          using xxreal_3_th_7 sorry
      qed
      thus " not -XXREAL-3K2 x be positiveXXREAL-0V2"
        using xxreal_0_def_6 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_20:
  mlet "x be positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster -XXREAL-3K2 x as-term-is negativeXXREAL-0V3"
proof
(*coherence*)
  show "-XXREAL-3K2 x be negativeXXREAL-0V3"
  proof-
    have "-XXREAL-3K2 x >=XXREAL-0R2 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "-XXREAL-3K2 x >=XXREAL-0R2 0NUMBERSK6"
      then have "(-XXREAL-3K2 x)-XXREAL-3K3 (-XXREAL-3K2 x) >XXREAL-0R4 0NUMBERSK6"
         sorry
      thus " False "
        using xxreal_3_th_7 sorry
    qed
    thus "-XXREAL-3K2 x be negativeXXREAL-0V3"
      using xxreal_0_def_7 sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_21:
  mlet "x be negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster -XXREAL-3K2 x as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "-XXREAL-3K2 x be positiveXXREAL-0V2"
  proof-
    have "-XXREAL-3K2 x <=XXREAL-3R1 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "-XXREAL-3K2 x <=XXREAL-3R1 0NUMBERSK6"
      then have "(-XXREAL-3K2 x)-XXREAL-3K3 (-XXREAL-3K2 x) <XXREAL-0R3 0NUMBERSK6"
         sorry
      thus " False "
        using xxreal_3_th_7 sorry
    qed
    thus "-XXREAL-3K2 x be positiveXXREAL-0V2"
      using xxreal_0_def_6 sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_22:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x -XXREAL-3K3 y as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "x -XXREAL-3K3 y be  non negativeXXREAL-0V3"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_23:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster y -XXREAL-3K3 x as-term-is  non positiveXXREAL-0V2"
proof
(*coherence*)
  show "y -XXREAL-3K3 x be  non positiveXXREAL-0V2"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_24:
  mlet "x be positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x -XXREAL-3K3 y as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "x -XXREAL-3K3 y be positiveXXREAL-0V2"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_25:
  mlet "x be positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster y -XXREAL-3K3 x as-term-is negativeXXREAL-0V3"
proof
(*coherence*)
  show "y -XXREAL-3K3 x be negativeXXREAL-0V3"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_26:
  mlet "x be negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x -XXREAL-3K3 y as-term-is negativeXXREAL-0V3"
proof
(*coherence*)
  show "x -XXREAL-3K3 y be negativeXXREAL-0V3"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_27:
  mlet "x be negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster y -XXREAL-3K3 x as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "y -XXREAL-3K3 x be positiveXXREAL-0V2"
     sorry
qed "sorry"

mlemma xxreal_3_lm_15:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y implies -XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y implies (-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2) & ( ex tVar11 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar11 =HIDDENR1 -XXREAL-3K2 y & tVar12 =HIDDENR1 -XXREAL-3K2 x) & tVar11 <=XXREAL-0R1 tVar12) or  not (-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2) & ( not (-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2) implies  not ( not -XXREAL-3K2 y =HIDDENR1 -inftyXXREAL-0K2 &  not -XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1))"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-3R1 y"
    show "(-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2) & ( ex tVar11 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar11 =HIDDENR1 -XXREAL-3K2 y & tVar12 =HIDDENR1 -XXREAL-3K2 x) & tVar11 <=XXREAL-0R1 tVar12) or  not (-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2) & ( not (-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2) implies  not ( not -XXREAL-3K2 y =HIDDENR1 -inftyXXREAL-0K2 &  not -XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1))"
    proof-
      have cases: "-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2 or  not (-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2)"
         sorry
      have case1: "-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2 implies ( ex tVar11 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar11 =HIDDENR1 -XXREAL-3K2 y & tVar12 =HIDDENR1 -XXREAL-3K2 x) & tVar11 <=XXREAL-0R1 tVar12)"
      proof(rule impMI ,rule impI)
        assume A2: "-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2"
          and A3: "-XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2"
        have "x inHIDDENR3 REALNUMBERSK2"
          using A3 xxreal_3_lm_3 sorry
        then obtain a where
          [ty]:"a be ComplexXCMPLX-0M1" and 
          A4: "x =HIDDENR1 a"and A5: "-XXREAL-3K2 x =HIDDENR1 -XCMPLX-0K4 a"
          using xxreal_3_def_3 sorry
        have "y inHIDDENR3 REALNUMBERSK2"
          using A2 xxreal_3_lm_3 sorry
        then obtain b where
          [ty]:"b be ComplexXCMPLX-0M1" and 
          A6: "y =HIDDENR1 b"and A7: "-XXREAL-3K2 y =HIDDENR1 -XCMPLX-0K4 b"
          using xxreal_3_def_3 sorry
        have "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
          using A2 A3 xxreal_3_lm_3 sorry
        then have 
          [ty]:"a be RealXREAL-0M1" and
          [ty]:"b be RealXREAL-0M1"
          using A6 A4 sorry
        obtain mb ma where 
          [ty]:"mb be ElementSUBSET-1M1-of REALNUMBERSK2" and mbDef:"mb = -XXREAL-3K2 b" and
          [ty]:"ma be ElementSUBSET-1M1-of REALNUMBERSK2" and maDef:"ma = -XXREAL-3K2 a"
          using xreal_0_def_1 sorry
        show " ex tVar11 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar11 =HIDDENR1 -XXREAL-3K2 y & tVar12 =HIDDENR1 -XXREAL-3K2 x) & tVar11 <=XXREAL-0R1 tVar12"
        proof(rule bexI[of _ "mb"])
          show " ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st (mb =HIDDENR1 -XXREAL-3K2 y & tVar12 =HIDDENR1 -XXREAL-3K2 x) & mb <=XXREAL-0R1 tVar12"
          proof(rule bexI[of _ "ma"],rule conjMI)
            show "mb =HIDDENR1 -XXREAL-3K2 y & ma =HIDDENR1 -XXREAL-3K2 x"
              using A7 A5 sorry
            show "mb <=XXREAL-0R1 ma"
              using A1 A6 A4 xreal_1_th_24 sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: " not (-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2) implies  not ( not -XXREAL-3K2 y =HIDDENR1 -inftyXXREAL-0K2 &  not -XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1)"
      proof(rule impI)
        assume " not (-XXREAL-3K2 y inHIDDENR3 REALNUMBERSK2 & -XXREAL-3K2 x inHIDDENR3 REALNUMBERSK2)"
        then have " not (y inHIDDENR3 REALNUMBERSK2 & x inHIDDENR3 REALNUMBERSK2)"
          using xxreal_3_lm_3 sorry
        then have "x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
          using A1 xxreal_3_def_1 sorry
        thus " not ( not -XXREAL-3K2 y =HIDDENR1 -inftyXXREAL-0K2 &  not -XXREAL-3K2 x =HIDDENR1 +inftyXXREAL-0K1)"
          using xxreal_3_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_35:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z"
  using xxreal_3_lm_12 sorry

mtheorem xxreal_3_th_36:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & z <=XXREAL-3R1 w implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & z <=XXREAL-3R1 w implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    fix w assume [ty]: "w be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-3R1 y"
      and A2: "z <=XXREAL-3R1 w"
    show "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
    proof-
      have cases: "(((x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 +inftyXXREAL-0K1 & w =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 -inftyXXREAL-0K2 & w =HIDDENR1 +inftyXXREAL-0K1) or  not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & w =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2 & w =HIDDENR1 +inftyXXREAL-0K1)"
         sorry
      have case1: "x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
      proof(rule impI)
        assume A3: "x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2"
        have A4: "w <>HIDDENR2 -inftyXXREAL-0K2 implies +inftyXXREAL-0K1 +XXREAL-3K1 w =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        have "y =HIDDENR1 +inftyXXREAL-0K1"
          using A1 A3 xxreal_0_th_4 sorry
        thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
          using A3 A4 sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
      proof(rule impI)
        assume A5: "x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1"
        have A6: "y <>HIDDENR2 -inftyXXREAL-0K2 implies +inftyXXREAL-0K1 +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_2 sorry
        have "w =HIDDENR1 +inftyXXREAL-0K1"
          using A2 A5 xxreal_0_th_4 sorry
        thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
          using A5 A6 sorry
      qed
      have case3: "y =HIDDENR1 +inftyXXREAL-0K1 & w =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
      proof(rule impI)
        assume A7: "y =HIDDENR1 +inftyXXREAL-0K1 & w =HIDDENR1 -inftyXXREAL-0K2"
        have A8: "x <>HIDDENR2 +inftyXXREAL-0K1 implies -inftyXXREAL-0K2 +XXREAL-3K1 x =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        have "z =HIDDENR1 -inftyXXREAL-0K2"
          using A2 A7 xxreal_0_th_6 sorry
        thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
          using A7 A8 sorry
      qed
      have case4: "y =HIDDENR1 -inftyXXREAL-0K2 & w =HIDDENR1 +inftyXXREAL-0K1 implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
      proof(rule impI)
        assume A9: "y =HIDDENR1 -inftyXXREAL-0K2 & w =HIDDENR1 +inftyXXREAL-0K1"
        have A10: "z <>HIDDENR2 +inftyXXREAL-0K1 implies -inftyXXREAL-0K2 +XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_2 sorry
        have "x =HIDDENR1 -inftyXXREAL-0K2"
          using A1 A9 xxreal_0_th_6 sorry
        thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
          using A9 A10 sorry
      qed
      have case5: " not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & w =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2 & w =HIDDENR1 +inftyXXREAL-0K1) implies x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
      proof(rule impI)
        assume A11: " not (x =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & w =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2 & w =HIDDENR1 +inftyXXREAL-0K1)"
        obtain a b where 
          [ty]:"a be ElementSUBSET-1M1-of ExtREALNUMBERSK7" and aDef:"a = x +XXREAL-3K1 z" and
          [ty]:"b be ElementSUBSET-1M1-of ExtREALNUMBERSK7" and bDef:"b = y +XXREAL-3K1 w"
          using xxreal_0_def_1 sorry
        have A12: " not (a =HIDDENR1 +inftyXXREAL-0K1 & b =HIDDENR1 -inftyXXREAL-0K2)"
        proof-
          have "a =HIDDENR1 +inftyXXREAL-0K1 & b =HIDDENR1 -inftyXXREAL-0K2 implies  not  True "
          proof(rule impMI ,rule impI)
            assume A13: "a =HIDDENR1 +inftyXXREAL-0K1"
              and A14: "b =HIDDENR1 -inftyXXREAL-0K2"
            have "x =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 +inftyXXREAL-0K1"
              using A13 xxreal_3_lm_8 sorry
            thus " not  True "
              using A1 A2 A11 A14 xxreal_3_lm_9 xxreal_0_th_4 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A15: "a inHIDDENR3 REALNUMBERSK2 & b inHIDDENR3 REALNUMBERSK2 implies a <=XXREAL-3R1 b"
        proof(rule impI)
          assume A16: "a inHIDDENR3 REALNUMBERSK2 & b inHIDDENR3 REALNUMBERSK2"
          then have A17: "z inHIDDENR3 REALNUMBERSK2 & w inHIDDENR3 REALNUMBERSK2"
            using A11 xxreal_3_th_20 sorry
          have "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
            using A11 A16 xxreal_3_th_20 sorry
          then obtain Ox Oy Os Ot where
            [ty]:"Ox be RealXREAL-0M1" "Oy be RealXREAL-0M1" "Os be RealXREAL-0M1" "Ot be RealXREAL-0M1" and 
            A18: "((Ox =HIDDENR1 x & Oy =HIDDENR1 y) & Os =HIDDENR1 z) & Ot =HIDDENR1 w"and A19: "Ox <=XXREAL-3R1 Oy & Os <=XXREAL-3R1 Ot"
            using A1 A2 A17 sorry
          have "Ox +XXREAL-3K1 Os <=XXREAL-3R1 Os +XXREAL-3K1 Oy & Os +XXREAL-3K1 Oy <=XXREAL-3R1 Ot +XXREAL-3K1 Oy"
            using A19 xreal_1_th_6 sorry
          thus "a <=XXREAL-3R1 b"
            using A18 xxreal_0_th_2 sorry
        qed
        have A20: "a =HIDDENR1 +inftyXXREAL-0K1 & b inHIDDENR3 REALNUMBERSK2 implies a <=XXREAL-3R1 b"
        proof(rule impMI ,rule impI)
          assume A21: "a =HIDDENR1 +inftyXXREAL-0K1"
            and "b inHIDDENR3 REALNUMBERSK2"
          have "x =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 +inftyXXREAL-0K1"
            using A21 xxreal_3_lm_8 sorry
          then have "y =HIDDENR1 +inftyXXREAL-0K1 or w =HIDDENR1 +inftyXXREAL-0K1"
            using A1 A2 xxreal_0_th_4 sorry
          then have "b =HIDDENR1 +inftyXXREAL-0K1"
            using A11 xxreal_3_def_2 sorry
          thus "a <=XXREAL-3R1 b"
            using xxreal_0_th_4 sorry
        qed
        have A22: "a inHIDDENR3 REALNUMBERSK2 & b =HIDDENR1 -inftyXXREAL-0K2 implies a <=XXREAL-3R1 b"
        proof(rule impMI ,rule impI)
          assume "a inHIDDENR3 REALNUMBERSK2"
            and A23: "b =HIDDENR1 -inftyXXREAL-0K2"
          have "y =HIDDENR1 -inftyXXREAL-0K2 or w =HIDDENR1 -inftyXXREAL-0K2"
            using A23 xxreal_3_lm_9 sorry
          then have "x =HIDDENR1 -inftyXXREAL-0K2 or z =HIDDENR1 -inftyXXREAL-0K2"
            using A1 A2 xxreal_0_th_6 sorry
          then have "a =HIDDENR1 -inftyXXREAL-0K2"
            using A11 xxreal_3_def_2 sorry
          thus "a <=XXREAL-3R1 b"
            using xxreal_0_th_5 sorry
        qed
        have "(((((((a inHIDDENR3 REALNUMBERSK2 & b inHIDDENR3 REALNUMBERSK2 or a inHIDDENR3 REALNUMBERSK2 & b =HIDDENR1 +inftyXXREAL-0K1) or a inHIDDENR3 REALNUMBERSK2 & b =HIDDENR1 -inftyXXREAL-0K2) or a =HIDDENR1 +inftyXXREAL-0K1 & b inHIDDENR3 REALNUMBERSK2) or a =HIDDENR1 +inftyXXREAL-0K1 & b =HIDDENR1 +inftyXXREAL-0K1) or a =HIDDENR1 +inftyXXREAL-0K1 & b =HIDDENR1 -inftyXXREAL-0K2) or a =HIDDENR1 -inftyXXREAL-0K2 & b inHIDDENR3 REALNUMBERSK2) or a =HIDDENR1 -inftyXXREAL-0K2 & b =HIDDENR1 +inftyXXREAL-0K1) or a =HIDDENR1 -inftyXXREAL-0K2 & b =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_0_th_14 sorry
        thus "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 w"
          using A15 A22 A20 A12 xxreal_0_th_4 xxreal_0_th_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_37:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & z <=XXREAL-3R1 w implies x -XXREAL-3K3 w <=XXREAL-3R1 y -XXREAL-3K3 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & z <=XXREAL-3R1 w implies x -XXREAL-3K3 w <=XXREAL-3R1 y -XXREAL-3K3 z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    fix w assume [ty]: "w be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-3R1 y"
      and A2: "z <=XXREAL-3R1 w"
    have "-XXREAL-3K2 w <=XXREAL-3R1 -XXREAL-3K2 z"
      using A2 xxreal_3_lm_15 sorry
    thus "x -XXREAL-3K3 w <=XXREAL-3R1 y -XXREAL-3K3 z"
      using A1 xxreal_3_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_38:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y iff -XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <=XXREAL-3R1 y implies -XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 x) &  not (-XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 x &  not x <=XXREAL-3R1 y)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    show "x <=XXREAL-3R1 y implies -XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 x"
      using xxreal_3_lm_15 sorry
    have "-XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 x implies -XXREAL-3K2 (-XXREAL-3K2 x) <=XXREAL-3R1 -XXREAL-3K2 (-XXREAL-3K2 y)"
      using xxreal_3_lm_15 sorry
    thus " not (-XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 x &  not x <=XXREAL-3R1 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_39:
" for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 z implies x <=XXREAL-3R1 x +XXREAL-3K1 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 z implies x <=XXREAL-3R1 x +XXREAL-3K1 z"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume "0NUMBERSK6 <=XXREAL-3R1 z"
    then have "x +XXREAL-3K1 0NUMBERSK6 <=XXREAL-3R1 x +XXREAL-3K1 z"
      using xxreal_3_th_36 sorry
    thus "x <=XXREAL-3R1 x +XXREAL-3K1 z"
      using xxreal_3_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_40:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y implies y -XXREAL-3K3 x >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y implies y -XXREAL-3K3 x >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume "x <=XXREAL-3R1 y"
    then have "-XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 x"
      using xxreal_3_lm_15 sorry
    then have "(-XXREAL-3K2 y)+XXREAL-3K1 y <=XXREAL-3R1 y +XXREAL-3K1 (-XXREAL-3K2 x)"
      using xxreal_3_th_36 sorry
    thus "y -XXREAL-3K3 x >=XXREAL-0R2 0NUMBERSK6"
      using xxreal_3_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_41:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 0NUMBERSK6) & (z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 0NUMBERSK6) implies (x -XXREAL-3K3 y <=XXREAL-3R1 z implies x <=XXREAL-3R1 z +XXREAL-3K1 y)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 0NUMBERSK6) & ((z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 0NUMBERSK6) & x -XXREAL-3K3 y <=XXREAL-3R1 z) implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 0NUMBERSK6"
      and A2: "z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 0NUMBERSK6"
      and A3: "x -XXREAL-3K3 y <=XXREAL-3R1 z"
    show "x <=XXREAL-3R1 z +XXREAL-3K1 y"
    proof-
      have cases: "(z =HIDDENR1 -inftyXXREAL-0K2 or z =HIDDENR1 +inftyXXREAL-0K1) or z inHIDDENR3 REALNUMBERSK2"
        using xxreal_0_th_14 sorry
      have case1: "z =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
      proof(rule impI)
        assume A4: "z =HIDDENR1 -inftyXXREAL-0K2"
        show "x <=XXREAL-3R1 z +XXREAL-3K1 y"
        proof-
          have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
            using A3 A4 xxreal_3_th_19 xxreal_0_th_6 sorry
          have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
          proof(rule impI)
            assume "x =HIDDENR1 -inftyXXREAL-0K2"
            thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
              using xxreal_0_th_5 sorry
          qed
          have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
          proof(rule impI)
            assume "y =HIDDENR1 +inftyXXREAL-0K1"
            thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
              using A1 A4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "z =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
      proof(rule impI)
        assume A5: "z =HIDDENR1 +inftyXXREAL-0K1"
        show "x <=XXREAL-3R1 z +XXREAL-3K1 y"
        proof-
          have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or y <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
          have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
          proof(rule impI)
            assume "y =HIDDENR1 -inftyXXREAL-0K2"
            thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
              using A2 A5 sorry
          qed
          have case2: "y <>HIDDENR2 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
          proof(rule impI)
            assume "y <>HIDDENR2 -inftyXXREAL-0K2"
            then have "z +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
              using A5 xxreal_3_def_2 sorry
            thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
              using xxreal_0_th_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case3: "z inHIDDENR3 REALNUMBERSK2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
      proof(rule impI)
        assume A6: "z inHIDDENR3 REALNUMBERSK2"
        show "x <=XXREAL-3R1 z +XXREAL-3K1 y"
        proof-
          have cases: "x -XXREAL-3K3 y inHIDDENR3 REALNUMBERSK2 or x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
            using A3 A6 xxreal_0_th_13 sorry
          have case1: "x -XXREAL-3K3 y inHIDDENR3 REALNUMBERSK2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
          proof(rule impI)
            assume A7: "x -XXREAL-3K3 y inHIDDENR3 REALNUMBERSK2"
            show "x <=XXREAL-3R1 z +XXREAL-3K1 y"
            proof-
              have cases: "(y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2) or x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
                using A7 xxreal_3_th_21 sorry
              have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
              proof(rule impI)
                assume "y =HIDDENR1 +inftyXXREAL-0K1"
                then have "z +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
                  using A6 xxreal_3_def_2 sorry
                thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
                  using xxreal_0_th_3 sorry
              qed
              have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
              proof(rule impI)
                assume "x =HIDDENR1 -inftyXXREAL-0K2"
                thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
                  using xxreal_0_th_5 sorry
              qed
              have case3: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
              proof(rule impI)
                assume "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
                then obtain a b c where 
                  [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = x" and
                  [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y" and
                  [ty]:"c be ElementSUBSET-1M1-of REALNUMBERSK2" and cDef:"c = z"
                  using A6 sorry
                have "a -XXREAL-3K3 b <=XXREAL-3R1 c"
                  using A3 sorry
                then have "a <=XXREAL-3R1 b +XXREAL-3K1 c"
                  using xreal_1_th_20 sorry
                thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed
          have case2: "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
          proof(rule impI)
            assume A8: "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
            show "x <=XXREAL-3R1 z +XXREAL-3K1 y"
            proof-
              have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
                using A8 xxreal_3_th_19 sorry
              have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
              proof(rule impI)
                assume "x =HIDDENR1 -inftyXXREAL-0K2"
                thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
                  using xxreal_0_th_5 sorry
              qed
              have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 z +XXREAL-3K1 y"
              proof(rule impI)
                assume "y =HIDDENR1 +inftyXXREAL-0K1"
                then have "z +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
                  using A6 xxreal_3_def_2 sorry
                thus "x <=XXREAL-3R1 z +XXREAL-3K1 y"
                  using xxreal_0_th_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_42:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 implies 0NUMBERSK6 <=XXREAL-3R1 z) & (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2 implies 0NUMBERSK6 <=XXREAL-3R1 z) implies (x <=XXREAL-3R1 z +XXREAL-3K1 y implies x -XXREAL-3K3 y <=XXREAL-3R1 z)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 implies 0NUMBERSK6 <=XXREAL-3R1 z) & ((x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2 implies 0NUMBERSK6 <=XXREAL-3R1 z) & x <=XXREAL-3R1 z +XXREAL-3K1 y) implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 implies 0NUMBERSK6 <=XXREAL-3R1 z"
      and A2: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2 implies 0NUMBERSK6 <=XXREAL-3R1 z"
      and A3: "x <=XXREAL-3R1 z +XXREAL-3K1 y"
    show "x -XXREAL-3K3 y <=XXREAL-3R1 z"
    proof-
      have cases: "(x =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2) or x inHIDDENR3 REALNUMBERSK2"
        using xxreal_0_th_14 sorry
      have case1: "x =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
      proof(rule impI)
        assume A4: "x =HIDDENR1 +inftyXXREAL-0K1"
        show "x -XXREAL-3K3 y <=XXREAL-3R1 z"
        proof-
          have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 +inftyXXREAL-0K1"
            using A3 A4 xxreal_3_lm_8 xxreal_0_th_4 sorry
          have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
          proof(rule impI)
            assume "z =HIDDENR1 +inftyXXREAL-0K1"
            thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
              using xxreal_0_th_3 sorry
          qed
          have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
          proof(rule impI)
            assume "y =HIDDENR1 +inftyXXREAL-0K1"
            thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
              using A1 A4 xxreal_3_th_7 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
      proof(rule impI)
        assume A5: "x =HIDDENR1 -inftyXXREAL-0K2"
        show "x -XXREAL-3K3 y <=XXREAL-3R1 z"
        proof-
          have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or -XXREAL-3K2 (-XXREAL-3K2 y) <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
          have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
          proof(rule impI)
            assume "y =HIDDENR1 -inftyXXREAL-0K2"
            thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
              using A2 A5 xxreal_3_th_7 sorry
          qed
          have case2: "-XXREAL-3K2 (-XXREAL-3K2 y) <>HIDDENR2 -inftyXXREAL-0K2 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
          proof(rule impI)
            assume "-XXREAL-3K2 (-XXREAL-3K2 y) <>HIDDENR2 -inftyXXREAL-0K2"
            then have "-XXREAL-3K2 y <>HIDDENR2 +inftyXXREAL-0K1"
              using xxreal_3_def_3 sorry
            then have "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
              using A5 xxreal_3_def_2 sorry
            thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
              using xxreal_0_th_5 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case3: "x inHIDDENR3 REALNUMBERSK2 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
      proof(rule impI)
        assume A6: "x inHIDDENR3 REALNUMBERSK2"
        show "x -XXREAL-3K3 y <=XXREAL-3R1 z"
        proof-
          have cases: "z +XXREAL-3K1 y inHIDDENR3 REALNUMBERSK2 or z +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
            using A3 A6 xxreal_0_th_10 sorry
          have case1: "z +XXREAL-3K1 y inHIDDENR3 REALNUMBERSK2 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
          proof(rule impI)
            assume A7: "z +XXREAL-3K1 y inHIDDENR3 REALNUMBERSK2"
            show "x -XXREAL-3K3 y <=XXREAL-3R1 z"
            proof-
              have cases: "(y =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 +inftyXXREAL-0K1) or z inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
                using A7 xxreal_3_th_20 sorry
              have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
              proof(rule impI)
                assume "y =HIDDENR1 +inftyXXREAL-0K1"
                then have "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
                  using A6 xxreal_3_def_2 xxreal_3_th_5 sorry
                thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
                  using xxreal_0_th_5 sorry
              qed
              have case2: "z =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
              proof(rule impI)
                assume "z =HIDDENR1 +inftyXXREAL-0K1"
                thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
                  using xxreal_0_th_3 sorry
              qed
              have case3: "z inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
              proof(rule impI)
                assume "z inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
                then obtain a b c where 
                  [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = x" and
                  [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y" and
                  [ty]:"c be ElementSUBSET-1M1-of REALNUMBERSK2" and cDef:"c = z"
                  using A6 sorry
                have "a <=XXREAL-3R1 b +XXREAL-3K1 c"
                  using A3 sorry
                then have "a -XXREAL-3K3 b <=XXREAL-3R1 c"
                  using xreal_1_th_20 sorry
                thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed
          have case2: "z +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
          proof(rule impI)
            assume A8: "z +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
            show "x -XXREAL-3K3 y <=XXREAL-3R1 z"
            proof-
              have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 +inftyXXREAL-0K1"
                using A8 xxreal_3_lm_8 sorry
              have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
              proof(rule impI)
                assume "z =HIDDENR1 +inftyXXREAL-0K1"
                thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
                  using xxreal_0_th_3 sorry
              qed
              have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies x -XXREAL-3K3 y <=XXREAL-3R1 z"
              proof(rule impI)
                assume "y =HIDDENR1 +inftyXXREAL-0K1"
                then have "x -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
                  using A6 xxreal_3_def_2 xxreal_3_th_5 sorry
                thus "x -XXREAL-3K3 y <=XXREAL-3R1 z"
                  using xxreal_0_th_5 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_43:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 REALNUMBERSK2 & x <XXREAL-0R3 y implies x +XXREAL-3K1 z <XXREAL-0R3 y +XXREAL-3K1 z & x -XXREAL-3K3 z <XXREAL-0R3 y -XXREAL-3K3 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 REALNUMBERSK2 & x <XXREAL-0R3 y implies  not x +XXREAL-3K1 z <XXREAL-0R3 y +XXREAL-3K1 z &  not x -XXREAL-3K3 z <XXREAL-0R3 y -XXREAL-3K3 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "z inHIDDENR3 REALNUMBERSK2"
      and A2: "x <XXREAL-0R3 y"
    have A3: "x +XXREAL-3K1 z <>HIDDENR2 y +XXREAL-3K1 z"
    proof-
      have "x +XXREAL-3K1 z =HIDDENR1 y +XXREAL-3K1 z implies  not  True "
      proof(rule impI)
        assume "x +XXREAL-3K1 z =HIDDENR1 y +XXREAL-3K1 z"
        then have "x =HIDDENR1 (y +XXREAL-3K1 z)-XXREAL-3K3 z"
          using A1 xxreal_3_th_22 sorry
        also have "... = y"
          using A1 xxreal_3_th_22 sorry
        finally have "x =HIDDENR1 y"
           sorry
        thus " not  True "
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A4: "x -XXREAL-3K3 z <>HIDDENR2 y -XXREAL-3K3 z"
    proof-
      have "x -XXREAL-3K3 z =HIDDENR1 y -XXREAL-3K3 z implies  not  True "
      proof(rule impI)
        assume "x -XXREAL-3K3 z =HIDDENR1 y -XXREAL-3K3 z"
        then have "x =HIDDENR1 (y -XXREAL-3K3 z)+XXREAL-3K1 z"
          using A1 xxreal_3_th_22 sorry
        also have "... = y"
          using A1 xxreal_3_th_22 sorry
        finally have "x =HIDDENR1 y"
           sorry
        thus " not  True "
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "x +XXREAL-3K1 z <=XXREAL-3R1 y +XXREAL-3K1 z & x -XXREAL-3K3 z <=XXREAL-3R1 y -XXREAL-3K3 z"
      using A2 xxreal_3_th_36 sorry
    thus " not x +XXREAL-3K1 z <XXREAL-0R3 y +XXREAL-3K1 z &  not x -XXREAL-3K3 z <XXREAL-0R3 y -XXREAL-3K3 z"
      using A3 A4 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_44:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-3R1 x & 0NUMBERSK6 <=XXREAL-3R1 y) & 0NUMBERSK6 <=XXREAL-3R1 z implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x & (0NUMBERSK6 <=XXREAL-3R1 y & 0NUMBERSK6 <=XXREAL-3R1 z) implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-3R1 x"
      and A2: "0NUMBERSK6 <=XXREAL-3R1 y"
      and A3: "0NUMBERSK6 <=XXREAL-3R1 z"
    show "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
    proof-
      have cases: "(((x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2 or x =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 +inftyXXREAL-0K1) or z =HIDDENR1 +inftyXXREAL-0K1"
        using A1 A2 A3 xxreal_0_th_14 sorry
      have case1: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) & z inHIDDENR3 REALNUMBERSK2"
        then obtain a b c d e where
          [ty]:"a be RealXREAL-0M1" "b be RealXREAL-0M1" "c be RealXREAL-0M1" "d be RealXREAL-0M1" "e be RealXREAL-0M1" and 
          A4: "(x =HIDDENR1 a & y =HIDDENR1 b) & z =HIDDENR1 c"and "x +XXREAL-3K1 y =HIDDENR1 d"and "y +XXREAL-3K1 z =HIDDENR1 e"
           sorry
        have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 (a +XXREAL-3K1 b)+XXREAL-3K1 c"
          using A4 sorry
        also have "... = a +XXREAL-3K1 (b +XXREAL-3K1 c)"
           sorry
        also have "... = x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A4 sorry
        finally have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
           sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
           sorry
      qed
      have case2: "x =HIDDENR1 +inftyXXREAL-0K1 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A5: "x =HIDDENR1 +inftyXXREAL-0K1"
        then have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1 +XXREAL-3K1 z"
          using A2 xxreal_3_def_2 sorry
        also have "... = +inftyXXREAL-0K1"
          using A3 xxreal_3_def_2 sorry
        also have "... = +inftyXXREAL-0K1 +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A2 A3 xxreal_3_def_2 sorry
        finally have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1 +XXREAL-3K1 (y +XXREAL-3K1 z)"
           sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A5 sorry
      qed
      have case3: "y =HIDDENR1 +inftyXXREAL-0K1 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A6: "y =HIDDENR1 +inftyXXREAL-0K1"
        then have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1 +XXREAL-3K1 z"
          using A1 xxreal_3_def_2 sorry
        also have "... = +inftyXXREAL-0K1"
          using A3 xxreal_3_def_2 sorry
        also have "... = x +XXREAL-3K1 +inftyXXREAL-0K1"
          using A1 xxreal_3_def_2 sorry
        also have "... = x +XXREAL-3K1 (+inftyXXREAL-0K1 +XXREAL-3K1 z)"
          using A3 xxreal_3_def_2 sorry
        finally have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (+inftyXXREAL-0K1 +XXREAL-3K1 z)"
           sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A6 sorry
      qed
      have case4: "z =HIDDENR1 +inftyXXREAL-0K1 implies (x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
      proof(rule impI)
        assume A7: "z =HIDDENR1 +inftyXXREAL-0K1"
        then have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using A1 A2 xxreal_3_def_2 sorry
        also have "... = x +XXREAL-3K1 +inftyXXREAL-0K1"
          using A1 xxreal_3_def_2 sorry
        also have "... = x +XXREAL-3K1 (y +XXREAL-3K1 +inftyXXREAL-0K1)"
          using A2 xxreal_3_def_2 sorry
        finally have "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 +inftyXXREAL-0K1)"
           sorry
        thus "(x +XXREAL-3K1 y)+XXREAL-3K1 z =HIDDENR1 x +XXREAL-3K1 (y +XXREAL-3K1 z)"
          using A7 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_45:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 implies (y +XXREAL-3K1 x <=XXREAL-3R1 z iff y <=XXREAL-3R1 z -XXREAL-3K3 x)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 implies (y +XXREAL-3K1 x <=XXREAL-3R1 z implies y <=XXREAL-3R1 z -XXREAL-3K3 x) & (y <=XXREAL-3R1 z -XXREAL-3K3 x implies y +XXREAL-3K1 x <=XXREAL-3R1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x be realXREAL-0V1"
    have A2: "(z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 z"
    proof-
      show "(z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 z"
      proof-
        have cases: "(z inHIDDENR3 REALNUMBERSK2 or z =HIDDENR1 -inftyXXREAL-0K2) or z =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_0_th_14 sorry
        have case1: "z inHIDDENR3 REALNUMBERSK2 implies (z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 z"
        proof(rule impI)
          assume "z inHIDDENR3 REALNUMBERSK2"
          then obtain a b where 
            [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
            [ty]:"b be RealXREAL-0M1" and bDef:"b = z"
            using A1 sorry
          have "(z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 (b -XXREAL-3K3 a)+XXREAL-3K1 a"
             sorry
          also have "... = z"
             sorry
          finally show "(z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 z"
             sorry
        qed
        have case2: "z =HIDDENR1 -inftyXXREAL-0K2 implies (z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 z"
        proof(rule impI)
          assume A3: "z =HIDDENR1 -inftyXXREAL-0K2"
          then have "(z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 -inftyXXREAL-0K2 +XXREAL-3K1 x"
            using A1 xxreal_3_th_14 sorry
          also have "... = z"
            using A1 A3 xxreal_3_def_2 sorry
          finally show "(z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 z"
             sorry
        qed
        have case3: "z =HIDDENR1 +inftyXXREAL-0K1 implies (z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 z"
        proof(rule impI)
          assume A4: "z =HIDDENR1 +inftyXXREAL-0K1"
          then have "(z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 +inftyXXREAL-0K1 +XXREAL-3K1 x"
            using A1 xxreal_3_th_13 sorry
          also have "... = z"
            using A1 A4 xxreal_3_def_2 sorry
          finally show "(z -XXREAL-3K3 x)+XXREAL-3K1 x =HIDDENR1 z"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    show "y +XXREAL-3K1 x <=XXREAL-3R1 z implies y <=XXREAL-3R1 z -XXREAL-3K3 x"
    proof(rule impI)
      have A5: "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
      proof-
        show "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
        proof-
          have cases: "y inHIDDENR3 REALNUMBERSK2 or (y =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1)"
            using xxreal_0_th_14 sorry
          have case1: "y inHIDDENR3 REALNUMBERSK2 implies (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
          proof(rule impI)
            assume "y inHIDDENR3 REALNUMBERSK2"
            then obtain a b where 
              [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = x" and
              [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y"
              using A1 xxreal_0_th_14 sorry
            have "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 (b +XXREAL-3K1 a)-XXREAL-3K3 a"
               sorry
            also have "... = y"
               sorry
            finally have "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
               sorry
            thus "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
               sorry
          qed
          have case2: "y =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1 implies (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
          proof(rule impI)
            assume A6: "y =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
            show "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
            proof-
              have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
                using A6 sorry
              have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
              proof(rule impI)
                assume A7: "y =HIDDENR1 -inftyXXREAL-0K2"
                then have "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 -inftyXXREAL-0K2 -XXREAL-3K3 x"
                  using A1 xxreal_3_def_2 sorry
                also have "... = y"
                  using A1 A7 xxreal_3_th_14 sorry
                finally show "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
                   sorry
              qed
              have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies (y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
              proof(rule impI)
                assume A8: "y =HIDDENR1 +inftyXXREAL-0K1"
                then have "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 +inftyXXREAL-0K1 -XXREAL-3K3 x"
                  using A1 xxreal_3_def_2 sorry
                also have "... = y"
                  using A1 A8 xxreal_3_th_13 sorry
                finally show "(y +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 y"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      assume "y +XXREAL-3K1 x <=XXREAL-3R1 z"
      thus "y <=XXREAL-3R1 z -XXREAL-3K3 x"
        using A5 xxreal_3_th_37 sorry
    qed
    assume "y <=XXREAL-3R1 z -XXREAL-3K3 x"
    thus "y +XXREAL-3K1 x <=XXREAL-3R1 z"
      using A2 xxreal_3_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_46:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 y implies 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 y implies  not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 x"
      and A2: "x <XXREAL-0R3 y"
    have A3: "x inHIDDENR3 REALNUMBERSK2"
      using A1 A2 xxreal_0_th_48 sorry
    have A4: "0NUMBERSK6 <>HIDDENR2 y -XXREAL-3K3 x"
    proof-
      have "0NUMBERSK6 =HIDDENR1 y -XXREAL-3K3 x implies  not  True "
      proof(rule impI)
        assume "0NUMBERSK6 =HIDDENR1 y -XXREAL-3K3 x"
        then have "x =HIDDENR1 (y -XXREAL-3K3 x)+XXREAL-3K1 x"
          using xxreal_3_th_4 sorry
        also have "... = y"
          using A3 xxreal_3_th_22 sorry
        finally have "x =HIDDENR1 y"
           sorry
        thus " not  True "
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "0NUMBERSK6 +XXREAL-3K1 x <XXREAL-0R3 y"
      using A2 xxreal_3_th_4 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
      using A3 A4 xxreal_3_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_16:
"0NUMBERSK6 inHIDDENR3 REALNUMBERSK2"
  using xreal_0_def_1 sorry

mtheorem xxreal_3_th_47:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-3R1 x & 0NUMBERSK6 <=XXREAL-3R1 z) & z +XXREAL-3K1 x <XXREAL-0R3 y implies z <XXREAL-0R3 y -XXREAL-3K3 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x & (0NUMBERSK6 <=XXREAL-3R1 z & z +XXREAL-3K1 x <XXREAL-0R3 y) implies  not z <XXREAL-0R3 y -XXREAL-3K3 x"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-3R1 x"
      and A2: "0NUMBERSK6 <=XXREAL-3R1 z"
      and A3: "z +XXREAL-3K1 x <XXREAL-0R3 y"
    have "x inHIDDENR3 REALNUMBERSK2"
    proof-
      have " not x inHIDDENR3 REALNUMBERSK2 implies  not  True "
      proof(rule impI)
        have A4: "x <>HIDDENR2 +inftyXXREAL-0K1"
        proof-
          have "x =HIDDENR1 +inftyXXREAL-0K1 implies  not  True "
          proof(rule impI)
            assume "x =HIDDENR1 +inftyXXREAL-0K1"
            then have "+inftyXXREAL-0K1 <XXREAL-0R3 y"
              using A2 A3 xxreal_3_def_2 sorry
            thus " not  True "
              using xxreal_0_th_4 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        assume " not x inHIDDENR3 REALNUMBERSK2"
        thus " not  True "
          using A1 A4 xxreal_0_th_10 xxreal_3_lm_16 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have "z <=XXREAL-3R1 y -XXREAL-3K3 x & z <>HIDDENR2 y -XXREAL-3K3 x"
      using A3 xxreal_3_th_22 xxreal_3_th_45 sorry
    thus " not z <XXREAL-0R3 y -XXREAL-3K3 x"
      using xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_48:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-3R1 x & 0NUMBERSK6 <=XXREAL-3R1 z) & z +XXREAL-3K1 x <XXREAL-0R3 y implies z <=XXREAL-3R1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x & (0NUMBERSK6 <=XXREAL-3R1 z & z +XXREAL-3K1 x <XXREAL-0R3 y) implies z <=XXREAL-3R1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-3R1 x"
      and A2: "0NUMBERSK6 <=XXREAL-3R1 z"
      and A3: "z +XXREAL-3K1 x <XXREAL-0R3 y"
    have "x inHIDDENR3 REALNUMBERSK2"
    proof-
      have " not x inHIDDENR3 REALNUMBERSK2 implies  not  True "
      proof(rule impI)
        have A4: "x <>HIDDENR2 +inftyXXREAL-0K1"
        proof-
          have "x =HIDDENR1 +inftyXXREAL-0K1 implies  not  True "
          proof(rule impI)
            assume "x =HIDDENR1 +inftyXXREAL-0K1"
            then have "+inftyXXREAL-0K1 <XXREAL-0R3 y"
              using A2 A3 xxreal_3_def_2 sorry
            thus " not  True "
              using xxreal_0_th_4 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        assume " not x inHIDDENR3 REALNUMBERSK2"
        thus " not  True "
          using A1 A4 xxreal_0_th_10 xxreal_3_lm_16 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have A5: "(z +XXREAL-3K1 x)-XXREAL-3K3 x =HIDDENR1 z"
      using xxreal_3_th_22 sorry
    have "y -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 y"
      using xxreal_3_th_15 sorry
    thus "z <=XXREAL-3R1 y"
      using A1 A3 A5 xxreal_3_th_37 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_49:
" for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x & x <XXREAL-0R3 z implies ( ex y be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 y & x +XXREAL-3K1 y <XXREAL-0R3 z)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x & x <XXREAL-0R3 z implies ( ex tVar13 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar13 &  not x +XXREAL-3K1 tVar13 <XXREAL-0R3 z)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-3R1 x"
      and A2: "x <XXREAL-0R3 z"
    show " ex tVar13 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar13 &  not x +XXREAL-3K1 tVar13 <XXREAL-0R3 z"
    proof-
      have cases: "0NUMBERSK6 <XXREAL-0R3 x or 0NUMBERSK6 =HIDDENR1 x"
        using A1 sorry
      have case1: "0NUMBERSK6 <XXREAL-0R3 x implies ( ex tVar13 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar13 &  not x +XXREAL-3K1 tVar13 <XXREAL-0R3 z)"
      proof(rule impI)
        assume A3: "0NUMBERSK6 <XXREAL-0R3 x"
        then have "0NUMBERSK6 <XXREAL-0R3 z -XXREAL-3K3 x"
          using A2 xxreal_3_th_46 sorry
        then obtain y where
          [ty]:"y be RealXREAL-0M1" and 
          A4: "0NUMBERSK6 <XXREAL-0R3 y"and A5: "y <XXREAL-0R3 z -XXREAL-3K3 x"
          using xxreal_3_th_3 sorry
        show " ex tVar13 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar13 &  not x +XXREAL-3K1 tVar13 <XXREAL-0R3 z"
        proof(rule bexI[of _ "y"])
          have A6: "x +XXREAL-3K1 y <=XXREAL-3R1 x +XXREAL-3K1 (z -XXREAL-3K3 x)"
            using A5 xxreal_3_th_36 sorry
          have A7: "x inHIDDENR3 REALNUMBERSK2"
            using A2 A3 xxreal_0_th_48 sorry
          then have A8: "x +XXREAL-3K1 (z -XXREAL-3K3 x) =HIDDENR1 z"
            using xxreal_3_th_22 sorry
          have "x +XXREAL-3K1 y <>HIDDENR2 z"
            using A7 A5 xxreal_3_th_22 sorry
          thus " not 0NUMBERSK6 <XXREAL-0R3 y &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
            using A4 A6 A8 xxreal_0_th_1 sorry
        qed "sorry"
      qed
      have case2: "0NUMBERSK6 =HIDDENR1 x implies ( ex tVar14 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar14 &  not x +XXREAL-3K1 tVar14 <XXREAL-0R3 z)"
      proof(rule impI)
        assume A9: "0NUMBERSK6 =HIDDENR1 x"
        obtain y where
          [ty]:"y be RealXREAL-0M1" and 
          A10: "0NUMBERSK6 <XXREAL-0R3 y & y <XXREAL-0R3 z"
          using A1 A2 xxreal_3_th_3 sorry
        show " ex tVar14 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar14 &  not x +XXREAL-3K1 tVar14 <XXREAL-0R3 z"
        proof(rule bexI[of _ "y"])
          show " not 0NUMBERSK6 <XXREAL-0R3 y &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
            using A9 A10 xxreal_3_th_4 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_50:
" for x be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x implies ( ex y be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 y & y +XXREAL-3K1 y <XXREAL-0R3 x)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x implies ( ex y be objectHIDDENM1 st 0NUMBERSK6 <XXREAL-0R3 y &  not y +XXREAL-3K1 y <XXREAL-0R3 x)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 x"
    then obtain x1 where
      [ty]:"x1 be RealXREAL-0M1" and 
      A1: "0NUMBERSK6 <XXREAL-0R3 x1"and A2: "x1 <XXREAL-0R3 x"
      using xxreal_3_th_3 sorry
    obtain x2 where
      [ty]:"x2 be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 x2"and A4: "x1 +XXREAL-3K1 x2 <XXREAL-0R3 x"
      using A1 A2 xxreal_3_th_49 sorry
    obtain y where 
      [ty]:"y be objectHIDDENM1" and yDef:"y = minXXREAL-0K4(x1,x2)"
       sorry
    show " ex y be objectHIDDENM1 st 0NUMBERSK6 <XXREAL-0R3 y &  not y +XXREAL-3K1 y <XXREAL-0R3 x"
    proof(rule bexI[of _ "y"])
      show "0NUMBERSK6 <XXREAL-0R3 y &  not y +XXREAL-3K1 y <XXREAL-0R3 x"
      proof-
        have cases: "x1 <=XXREAL-3R1 x2 or x2 <=XXREAL-3R1 x1"
           sorry
        have case1: "x1 <=XXREAL-3R1 x2 implies 0NUMBERSK6 <XXREAL-0R3 y &  not y +XXREAL-3K1 y <XXREAL-0R3 x"
        proof(rule impI,rule conjMI)
          assume A5: "x1 <=XXREAL-3R1 x2"
          thus "0NUMBERSK6 <XXREAL-0R3 y"
            using A1 xxreal_0_def_9 sorry
          have "y =HIDDENR1 x1"
            using A5 xxreal_0_def_9 sorry
          then have "y +XXREAL-3K1 y <=XXREAL-3R1 x1 +XXREAL-3K1 x2"
            using A5 xxreal_3_th_36 sorry
          thus " not y +XXREAL-3K1 y <XXREAL-0R3 x"
            using A4 xxreal_0_th_2 sorry
        qed
        have case2: "x2 <=XXREAL-3R1 x1 implies 0NUMBERSK6 <XXREAL-0R3 y &  not y +XXREAL-3K1 y <XXREAL-0R3 x"
        proof(rule impI,rule conjMI)
          assume A6: "x2 <=XXREAL-3R1 x1"
          thus "0NUMBERSK6 <XXREAL-0R3 y"
            using A3 xxreal_0_def_9 sorry
          have "y =HIDDENR1 x2"
            using A6 xxreal_0_def_9 sorry
          then have "y +XXREAL-3K1 y <=XXREAL-3R1 x1 +XXREAL-3K1 x2"
            using A6 xxreal_3_th_36 sorry
          thus " not y +XXREAL-3K1 y <XXREAL-0R3 x"
            using A4 xxreal_0_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_51:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <XXREAL-0R3 y & x <XXREAL-0R3 +inftyXXREAL-0K1) & -inftyXXREAL-0K2 <XXREAL-0R3 y implies 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y & (x <XXREAL-0R3 +inftyXXREAL-0K1 & -inftyXXREAL-0K2 <XXREAL-0R3 y) implies  not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
      and A2: "x <XXREAL-0R3 +inftyXXREAL-0K1"
      and A3: "-inftyXXREAL-0K2 <XXREAL-0R3 y"
    show " not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
    proof-
      have cases: "y =HIDDENR1 +inftyXXREAL-0K1 or y <>HIDDENR2 +inftyXXREAL-0K1"
         sorry
      have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies  not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
      proof(rule impI)
        assume "y =HIDDENR1 +inftyXXREAL-0K1"
        thus " not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
          using A2 xxreal_3_th_13 sorry
      qed
      have case2: "y <>HIDDENR2 +inftyXXREAL-0K1 implies  not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
      proof(rule impI)
        assume A4: "y <>HIDDENR2 +inftyXXREAL-0K1"
        show " not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
        proof-
          have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
          have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies  not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
          proof(rule impI)
            assume "x =HIDDENR1 -inftyXXREAL-0K2"
            thus " not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
              using A3 xxreal_3_th_14 sorry
          qed
          have case2: "x <>HIDDENR2 -inftyXXREAL-0K2 implies  not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
          proof(rule impI)
            assume A5: "x <>HIDDENR2 -inftyXXREAL-0K2"
            have A6: "y inHIDDENR3 REALNUMBERSK2"
              using A3 A4 xxreal_0_th_14 sorry
            have "x inHIDDENR3 REALNUMBERSK2"
              using A2 A5 xxreal_0_th_14 sorry
            then obtain a b where 
              [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
              using A6 sorry
            have "b -XXREAL-3K3 a >XXREAL-0R4 0NUMBERSK6"
              using A1 xreal_1_th_50 sorry
            thus " not 0NUMBERSK6 <XXREAL-0R3 y -XXREAL-3K3 x"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_52:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) & x +XXREAL-3K1 y <XXREAL-0R3 z implies ((x <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 +inftyXXREAL-0K1) & z <>HIDDENR2 -inftyXXREAL-0K2) & x <XXREAL-0R3 z -XXREAL-3K3 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) & x +XXREAL-3K1 y <XXREAL-0R3 z implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1)"
      and A2: "x +XXREAL-3K1 y <XXREAL-0R3 z"
    show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
    proof-
      have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or z <>HIDDENR2 +inftyXXREAL-0K1"
         sorry
      have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
      proof(rule impI)
        assume A3: "z =HIDDENR1 +inftyXXREAL-0K1"
        then have "x <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A2 xxreal_3_def_2 sorry
        then have A4: "x <XXREAL-0R3 +inftyXXREAL-0K1"
          using xxreal_0_th_4 sorry
        have "y <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A2 A3 xxreal_3_def_2 sorry
        thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
          using A3 A4 xxreal_3_th_13 sorry
      qed
      have case2: "z <>HIDDENR2 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
      proof(rule impI)
        assume A5: "z <>HIDDENR2 +inftyXXREAL-0K1"
        have A6: "-inftyXXREAL-0K2 <=XXREAL-3R1 x +XXREAL-3K1 y"
          using xxreal_0_th_5 sorry
        then have "z inHIDDENR3 REALNUMBERSK2"
          using A2 A5 xxreal_0_th_14 sorry
        then obtain c where 
          [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
           sorry
        have A7: "x +XXREAL-3K1 y <XXREAL-0R3 +inftyXXREAL-0K1"
          using A2 xxreal_0_th_2 xxreal_0_th_4 sorry
        then have A8: "x <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 xxreal_3_def_2 sorry
        have A9: "y <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A7 xxreal_3_def_2 sorry
        show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
        proof-
          have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or y <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
          have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
          proof(rule impI)
            assume A10: "y =HIDDENR1 -inftyXXREAL-0K2"
            then have "x <XXREAL-0R3 +inftyXXREAL-0K1"
              using A1 xxreal_0_th_4 sorry
            thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
              using A2 A6 A10 xxreal_3_th_14 sorry
          qed
          have case2: "y <>HIDDENR2 -inftyXXREAL-0K2 implies x <>HIDDENR2 +inftyXXREAL-0K1 & (y <>HIDDENR2 +inftyXXREAL-0K1 & (z <>HIDDENR2 -inftyXXREAL-0K2 &  not x <XXREAL-0R3 z -XXREAL-3K3 y))"
          proof(rule impI)
            assume "y <>HIDDENR2 -inftyXXREAL-0K2"
            then have "y inHIDDENR3 REALNUMBERSK2"
              using A9 xxreal_0_th_14 sorry
            then obtain b where 
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
               sorry
            show "x <>HIDDENR2 +inftyXXREAL-0K1 & (y <>HIDDENR2 +inftyXXREAL-0K1 & (z <>HIDDENR2 -inftyXXREAL-0K2 &  not x <XXREAL-0R3 z -XXREAL-3K3 y))"
            proof-
              have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x <>HIDDENR2 -inftyXXREAL-0K2"
                 sorry
              have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies x <>HIDDENR2 +inftyXXREAL-0K1 & (y <>HIDDENR2 +inftyXXREAL-0K1 & (z <>HIDDENR2 -inftyXXREAL-0K2 &  not x <XXREAL-0R3 z -XXREAL-3K3 y))"
              proof(rule impI,rule conjMI,rule conjMI,rule conjMI)
                assume A11: "x =HIDDENR1 -inftyXXREAL-0K2"
                thus "x <>HIDDENR2 +inftyXXREAL-0K1"
                   sorry
                have A12: "z -XXREAL-3K3 y =HIDDENR1 c -XXREAL-3K3 b"
                   sorry
                thus "y <>HIDDENR2 +inftyXXREAL-0K1"
                   sorry
                show "z <>HIDDENR2 -inftyXXREAL-0K2"
                  using A12 sorry
                have "c -XXREAL-3K3 b inHIDDENR3 REALNUMBERSK2"
                  using xreal_0_def_1 sorry
                thus " not x <XXREAL-0R3 z -XXREAL-3K3 y"
                  using A11 xxreal_0_th_12 sorry
              qed
              have case2: "x <>HIDDENR2 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
              proof(rule impI)
                assume "x <>HIDDENR2 -inftyXXREAL-0K2"
                then have "x inHIDDENR3 REALNUMBERSK2"
                  using A8 xxreal_0_th_14 sorry
                then obtain a where 
                  [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
                   sorry
                have "x +XXREAL-3K1 y =HIDDENR1 a +XXREAL-3K1 b"
                   sorry
                then have "a <XXREAL-0R3 c -XXREAL-3K3 b"
                  using A2 xreal_1_th_20 sorry
                thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z -XXREAL-3K3 y"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_53:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & x <XXREAL-0R3 z -XXREAL-3K3 y implies ((x <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 +inftyXXREAL-0K1) & z <>HIDDENR2 -inftyXXREAL-0K2) & x +XXREAL-3K1 y <XXREAL-0R3 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & x <XXREAL-0R3 z -XXREAL-3K3 y implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2)"
      and A2: "x <XXREAL-0R3 z -XXREAL-3K3 y"
    show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
    proof-
      have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x <>HIDDENR2 -inftyXXREAL-0K2"
         sorry
      have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
      proof(rule impI)
        assume A3: "x =HIDDENR1 -inftyXXREAL-0K2"
        have A4: "-inftyXXREAL-0K2 <=XXREAL-3R1 z"
          using xxreal_0_th_5 sorry
        have "z <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A2 A3 xxreal_3_th_14 sorry
        then have A5: "-inftyXXREAL-0K2 <XXREAL-0R3 z"
          using A4 xxreal_0_th_1 sorry
        have "y <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A2 A3 xxreal_3_th_13 sorry
        thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
          using A3 A5 xxreal_3_def_2 sorry
      qed
      have case2: "x <>HIDDENR2 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
      proof(rule impI)
        assume A6: "x <>HIDDENR2 -inftyXXREAL-0K2"
        have A7: "z -XXREAL-3K3 y <=XXREAL-3R1 +inftyXXREAL-0K1"
          using xxreal_0_th_4 sorry
        then have "x inHIDDENR3 REALNUMBERSK2"
          using A2 A6 xxreal_0_th_14 sorry
        then obtain a where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
           sorry
        have A8: "-inftyXXREAL-0K2 <=XXREAL-3R1 x"
          using xxreal_0_th_5 sorry
        then have A9: "z <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A2 xxreal_3_th_14 sorry
        have A10: "y <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A2 A8 xxreal_3_th_13 sorry
        show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
        proof-
          have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or y <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
          have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
          proof(rule impI)
            assume A11: "y =HIDDENR1 -inftyXXREAL-0K2"
            have "-inftyXXREAL-0K2 <=XXREAL-3R1 z"
              using xxreal_0_th_5 sorry
            then have "-inftyXXREAL-0K2 <XXREAL-0R3 z"
              using A1 A11 xxreal_0_th_1 sorry
            thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
              using A2 A7 A11 xxreal_3_def_2 sorry
          qed
          have case2: "y <>HIDDENR2 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
          proof(rule impI)
            assume "y <>HIDDENR2 -inftyXXREAL-0K2"
            then have "y inHIDDENR3 REALNUMBERSK2"
              using A10 xxreal_0_th_14 sorry
            then obtain b where 
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
               sorry
            show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
            proof-
              have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or z <>HIDDENR2 +inftyXXREAL-0K1"
                 sorry
              have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
              proof(rule impI)
                assume A12: "z =HIDDENR1 +inftyXXREAL-0K1"
                have "a +XXREAL-3K1 b inHIDDENR3 REALNUMBERSK2"
                  using xreal_0_def_1 sorry
                thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
                  using A12 xxreal_0_th_9 sorry
              qed
              have case2: "z <>HIDDENR2 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
              proof(rule impI)
                assume "z <>HIDDENR2 +inftyXXREAL-0K1"
                then have "z inHIDDENR3 REALNUMBERSK2"
                  using A9 xxreal_0_th_14 sorry
                then obtain c where 
                  [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
                   sorry
                have "z -XXREAL-3K3 y =HIDDENR1 c -XXREAL-3K3 b"
                   sorry
                then have "a +XXREAL-3K1 b <XXREAL-0R3 c"
                  using A2 xreal_1_th_20 sorry
                thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 +inftyXXREAL-0K1) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x +XXREAL-3K1 y <XXREAL-0R3 z"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_54:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & x -XXREAL-3K3 y <XXREAL-0R3 z implies ((x <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2) & z <>HIDDENR2 -inftyXXREAL-0K2) & x <XXREAL-0R3 z +XXREAL-3K1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & x -XXREAL-3K3 y <XXREAL-0R3 z implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2)"
      and A2: "x -XXREAL-3K3 y <XXREAL-0R3 z"
    show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
    proof-
      have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or z <>HIDDENR2 +inftyXXREAL-0K1"
         sorry
      have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
      proof(rule impI)
        assume A3: "z =HIDDENR1 +inftyXXREAL-0K1"
        then have "x <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A2 xxreal_3_th_13 sorry
        then have A4: "x <XXREAL-0R3 +inftyXXREAL-0K1"
          using xxreal_0_th_4 sorry
        have "y <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A2 A3 xxreal_3_th_14 sorry
        thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
          using A3 A4 xxreal_3_def_2 sorry
      qed
      have case2: "z <>HIDDENR2 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
      proof(rule impI)
        assume A5: "z <>HIDDENR2 +inftyXXREAL-0K1"
        have A6: "-inftyXXREAL-0K2 <=XXREAL-3R1 x -XXREAL-3K3 y"
          using xxreal_0_th_5 sorry
        then have "z inHIDDENR3 REALNUMBERSK2"
          using A2 A5 xxreal_0_th_14 sorry
        then obtain c where 
          [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
           sorry
        have A7: "x -XXREAL-3K3 y <XXREAL-0R3 +inftyXXREAL-0K1"
          using A2 xxreal_0_th_2 xxreal_0_th_4 sorry
        then have A8: "x <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 xxreal_3_th_13 sorry
        have A9: "y <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A7 xxreal_3_th_14 sorry
        show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
        proof-
          have cases: "y =HIDDENR1 +inftyXXREAL-0K1 or y <>HIDDENR2 +inftyXXREAL-0K1"
             sorry
          have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
          proof(rule impI)
            assume A10: "y =HIDDENR1 +inftyXXREAL-0K1"
            then have "x <XXREAL-0R3 +inftyXXREAL-0K1"
              using A1 xxreal_0_th_4 sorry
            thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
              using A2 A6 A10 xxreal_3_def_2 sorry
          qed
          have case2: "y <>HIDDENR2 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
          proof(rule impI)
            assume "y <>HIDDENR2 +inftyXXREAL-0K1"
            then have "y inHIDDENR3 REALNUMBERSK2"
              using A9 xxreal_0_th_14 sorry
            then obtain b where 
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
               sorry
            show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
            proof-
              have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x <>HIDDENR2 -inftyXXREAL-0K2"
                 sorry
              have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
              proof(rule impI)
                assume A11: "x =HIDDENR1 -inftyXXREAL-0K2"
                have "c +XXREAL-3K1 b inHIDDENR3 REALNUMBERSK2"
                  using xreal_0_def_1 sorry
                thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
                  using A11 xxreal_0_th_12 sorry
              qed
              have case2: "x <>HIDDENR2 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
              proof(rule impI)
                assume "x <>HIDDENR2 -inftyXXREAL-0K2"
                then have "x inHIDDENR3 REALNUMBERSK2"
                  using A8 xxreal_0_th_14 sorry
                then obtain a where 
                  [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
                   sorry
                have "x -XXREAL-3K3 y =HIDDENR1 a -XXREAL-3K3 b"
                   sorry
                then have "a <XXREAL-0R3 c +XXREAL-3K1 b"
                  using A2 xreal_1_th_19 sorry
                thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x <XXREAL-0R3 z +XXREAL-3K1 y"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_55:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) & x <XXREAL-0R3 z +XXREAL-3K1 y implies ((x <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2) & z <>HIDDENR2 -inftyXXREAL-0K2) & x -XXREAL-3K3 y <XXREAL-0R3 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) & x <XXREAL-0R3 z +XXREAL-3K1 y implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (z =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or z =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1)"
      and A2: "x <XXREAL-0R3 z +XXREAL-3K1 y"
    show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
    proof-
      have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x <>HIDDENR2 -inftyXXREAL-0K2"
         sorry
      have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
      proof(rule impI)
        assume A3: "x =HIDDENR1 -inftyXXREAL-0K2"
        have A4: "-inftyXXREAL-0K2 <=XXREAL-3R1 z"
          using xxreal_0_th_5 sorry
        have "z <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A2 A3 xxreal_3_def_2 sorry
        then have A5: "-inftyXXREAL-0K2 <XXREAL-0R3 z"
          using A4 xxreal_0_th_1 sorry
        have "y <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A2 A3 xxreal_3_def_2 sorry
        thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
          using A3 A5 xxreal_3_th_14 sorry
      qed
      have case2: "x <>HIDDENR2 -inftyXXREAL-0K2 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
      proof(rule impI)
        assume A6: "x <>HIDDENR2 -inftyXXREAL-0K2"
        have A7: "z +XXREAL-3K1 y <=XXREAL-3R1 +inftyXXREAL-0K1"
          using xxreal_0_th_4 sorry
        then have "x inHIDDENR3 REALNUMBERSK2"
          using A2 A6 xxreal_0_th_14 sorry
        then obtain a where 
          [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
           sorry
        have A8: "-inftyXXREAL-0K2 <=XXREAL-3R1 x"
          using xxreal_0_th_5 sorry
        then have A9: "z <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A2 xxreal_3_def_2 sorry
        have A10: "y <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A2 A8 xxreal_3_def_2 sorry
        show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
        proof-
          have cases: "y =HIDDENR1 +inftyXXREAL-0K1 or y <>HIDDENR2 +inftyXXREAL-0K1"
             sorry
          have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
          proof(rule impI)
            assume A11: "y =HIDDENR1 +inftyXXREAL-0K1"
            have "-inftyXXREAL-0K2 <=XXREAL-3R1 z"
              using xxreal_0_th_5 sorry
            then have "-inftyXXREAL-0K2 <XXREAL-0R3 z"
              using A1 A11 xxreal_0_th_1 sorry
            thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
              using A2 A7 A11 xxreal_3_th_13 sorry
          qed
          have case2: "y <>HIDDENR2 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
          proof(rule impI)
            assume "y <>HIDDENR2 +inftyXXREAL-0K1"
            then have "y inHIDDENR3 REALNUMBERSK2"
              using A10 xxreal_0_th_14 sorry
            then obtain b where 
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
               sorry
            show "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
            proof-
              have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or z <>HIDDENR2 +inftyXXREAL-0K1"
                 sorry
              have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
              proof(rule impI)
                assume A12: "z =HIDDENR1 +inftyXXREAL-0K1"
                have "a -XXREAL-3K3 b inHIDDENR3 REALNUMBERSK2"
                  using xreal_0_def_1 sorry
                thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
                  using A12 xxreal_0_th_9 sorry
              qed
              have case2: "z <>HIDDENR2 +inftyXXREAL-0K1 implies (( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
              proof(rule impI)
                assume "z <>HIDDENR2 +inftyXXREAL-0K1"
                then have "z inHIDDENR3 REALNUMBERSK2"
                  using A9 xxreal_0_th_14 sorry
                then obtain c where 
                  [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
                   sorry
                have "z +XXREAL-3K1 y =HIDDENR1 c +XXREAL-3K1 b"
                   sorry
                then have "a -XXREAL-3K3 b <XXREAL-0R3 c"
                  using A2 xreal_1_th_19 sorry
                thus "(( not x <>HIDDENR2 +inftyXXREAL-0K1 &  not y <>HIDDENR2 -inftyXXREAL-0K2) &  not z <>HIDDENR2 -inftyXXREAL-0K2) &  not x -XXREAL-3K3 y <XXREAL-0R3 z"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_56:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2) & x +XXREAL-3K1 y <=XXREAL-3R1 z implies y <>HIDDENR2 +inftyXXREAL-0K1 & x <=XXREAL-3R1 z -XXREAL-3K3 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2) & x +XXREAL-3K1 y <=XXREAL-3R1 z implies y <>HIDDENR2 +inftyXXREAL-0K1 & x <=XXREAL-3R1 z -XXREAL-3K3 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2)"
      and A2: "x +XXREAL-3K1 y <=XXREAL-3R1 z"
    show "y <>HIDDENR2 +inftyXXREAL-0K1"
    proof-
      have "y =HIDDENR1 +inftyXXREAL-0K1 implies  False "
      proof(rule impI)
        assume A3: "y =HIDDENR1 +inftyXXREAL-0K1"
        then have "x +XXREAL-3K1 y =HIDDENR1 +inftyXXREAL-0K1"
          using A1 xxreal_3_def_2 sorry
        thus " False "
          using A1 A2 A3 xxreal_0_th_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "x <=XXREAL-3R1 z -XXREAL-3K3 y"
    proof-
      have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or z <>HIDDENR2 +inftyXXREAL-0K1"
         sorry
      have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 z -XXREAL-3K3 y"
      proof(rule impI)
        assume "z =HIDDENR1 +inftyXXREAL-0K1"
        then have "z -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1"
          using A1 xxreal_3_th_13 sorry
        thus "x <=XXREAL-3R1 z -XXREAL-3K3 y"
          using xxreal_0_th_4 sorry
      qed
      have case2: "z <>HIDDENR2 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 z -XXREAL-3K3 y"
      proof(rule impI)
        assume A4: "z <>HIDDENR2 +inftyXXREAL-0K1"
        then have A5: "x +XXREAL-3K1 y <XXREAL-0R3 +inftyXXREAL-0K1"
          using A2 xxreal_0_th_2 xxreal_0_th_4 sorry
        then have A6: "x <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 xxreal_3_def_2 sorry
        have A7: "y <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 A5 xxreal_3_def_2 sorry
        show "x <=XXREAL-3R1 z -XXREAL-3K3 y"
        proof-
          have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
          have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z -XXREAL-3K3 y"
          proof(rule impI)
            assume "x =HIDDENR1 -inftyXXREAL-0K2"
            thus "x <=XXREAL-3R1 z -XXREAL-3K3 y"
              using xxreal_0_th_5 sorry
          qed
          have case2: "x <>HIDDENR2 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z -XXREAL-3K3 y"
          proof(rule impI)
            assume "x <>HIDDENR2 -inftyXXREAL-0K2"
            then have "x inHIDDENR3 REALNUMBERSK2"
              using A6 xxreal_0_th_14 sorry
            then obtain a where 
              [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
               sorry
            show "x <=XXREAL-3R1 z -XXREAL-3K3 y"
            proof-
              have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or y <>HIDDENR2 -inftyXXREAL-0K2"
                 sorry
              have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z -XXREAL-3K3 y"
              proof(rule impI)
                assume "y =HIDDENR1 -inftyXXREAL-0K2"
                then have "z -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1"
                  using A1 xxreal_3_th_14 sorry
                thus "x <=XXREAL-3R1 z -XXREAL-3K3 y"
                  using xxreal_0_th_4 sorry
              qed
              have case2: "y <>HIDDENR2 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 z -XXREAL-3K3 y"
              proof(rule impI)
                assume "y <>HIDDENR2 -inftyXXREAL-0K2"
                then have "y inHIDDENR3 REALNUMBERSK2"
                  using A7 xxreal_0_th_14 sorry
                then obtain b where 
                  [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
                   sorry
                have "a +XXREAL-3K1 b inHIDDENR3 REALNUMBERSK2"
                  using xreal_0_def_1 sorry
                then have "z <>HIDDENR2 -inftyXXREAL-0K2"
                  using A2 xxreal_0_th_12 sorry
                then have "z inHIDDENR3 REALNUMBERSK2"
                  using A4 xxreal_0_th_14 sorry
                then obtain c where 
                  [ty]:"c be RealXREAL-0M1" and cDef:"c = z"
                   sorry
                have "x +XXREAL-3K1 y =HIDDENR1 a +XXREAL-3K1 b"
                   sorry
                then have "a <=XXREAL-3R1 c -XXREAL-3K3 b"
                  using A2 xreal_1_th_19 sorry
                thus "x <=XXREAL-3R1 z -XXREAL-3K3 y"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_57:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (( not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) &  not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1)) &  not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1)) & x <=XXREAL-3R1 z -XXREAL-3K3 y implies y <>HIDDENR2 +inftyXXREAL-0K1 & x +XXREAL-3K1 y <=XXREAL-3R1 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) & ( not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) & ( not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1) & x <=XXREAL-3R1 z -XXREAL-3K3 y)) implies y <>HIDDENR2 +inftyXXREAL-0K1 & x +XXREAL-3K1 y <=XXREAL-3R1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2)"
      and A2: " not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1)"
      and A3: " not (y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1)"
      and A4: "x <=XXREAL-3R1 z -XXREAL-3K3 y"
    show A5: "y <>HIDDENR2 +inftyXXREAL-0K1"
    proof-
      have "y =HIDDENR1 +inftyXXREAL-0K1 implies  False "
      proof(rule impI)
        assume A6: "y =HIDDENR1 +inftyXXREAL-0K1"
        then have "z -XXREAL-3K3 y =HIDDENR1 -inftyXXREAL-0K2"
          using A3 xxreal_3_th_13 sorry
        thus " False "
          using A2 A4 A6 xxreal_0_th_6 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "x +XXREAL-3K1 y <=XXREAL-3R1 z"
    proof-
      have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
        using A5 sorry
      have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies x +XXREAL-3K1 y <=XXREAL-3R1 z"
      proof(rule impI)
        assume "y =HIDDENR1 -inftyXXREAL-0K2"
        then have "x +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2"
          using A1 xxreal_3_def_2 sorry
        thus "x +XXREAL-3K1 y <=XXREAL-3R1 z"
          using xxreal_0_th_5 sorry
      qed
      have case2: "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 implies x +XXREAL-3K1 y <=XXREAL-3R1 z"
      proof(rule impI)
        assume A7: "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
        have "-XXREAL-3K2 -inftyXXREAL-0K2 =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_3 sorry
        then have A8: "-XXREAL-3K2 y <>HIDDENR2 -inftyXXREAL-0K2"
          using A7 sorry
        have "-XXREAL-3K2 +inftyXXREAL-0K1 =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_3 sorry
        then have "-XXREAL-3K2 y <>HIDDENR2 +inftyXXREAL-0K1"
          using A7 sorry
        then have "(z -XXREAL-3K3 y)+XXREAL-3K1 y =HIDDENR1 z +XXREAL-3K1 ((-XXREAL-3K2 y)+XXREAL-3K1 y)"
          using A7 A8 xxreal_3_th_29 sorry
        also have "... = z +XXREAL-3K1 0NUMBERSK6"
          using xxreal_3_th_7 sorry
        also have "... = z"
          using xxreal_3_th_4 sorry
        finally have "(z -XXREAL-3K3 y)+XXREAL-3K1 y =HIDDENR1 z"
           sorry
        thus "x +XXREAL-3K1 y <=XXREAL-3R1 z"
          using A4 xxreal_3_th_36 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_58:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) & x -XXREAL-3K3 y <=XXREAL-3R1 z implies y <>HIDDENR2 -inftyXXREAL-0K2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) & x -XXREAL-3K3 y <=XXREAL-3R1 z implies (y =HIDDENR1 -inftyXXREAL-0K2 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)"
      and A2: "x -XXREAL-3K3 y <=XXREAL-3R1 z"
    assume A3: "y =HIDDENR1 -inftyXXREAL-0K2"
    then have "x -XXREAL-3K3 y =HIDDENR1 +inftyXXREAL-0K1"
      using A1 xxreal_3_th_14 sorry
    thus " False "
      using A1 A2 A3 xxreal_0_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_59:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds ( not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) &  not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)) & x <=XXREAL-3R1 z +XXREAL-3K1 y implies y <>HIDDENR2 -inftyXXREAL-0K2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2) & ( not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) & x <=XXREAL-3R1 z +XXREAL-3K1 y) implies (y =HIDDENR1 -inftyXXREAL-0K2 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: " not (x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2)"
      and A2: " not (y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1)"
      and A3: "x <=XXREAL-3R1 z +XXREAL-3K1 y"
    assume A4: "y =HIDDENR1 -inftyXXREAL-0K2"
    then have "z +XXREAL-3K1 y =HIDDENR1 -inftyXXREAL-0K2"
      using A2 xxreal_3_def_2 sorry
    thus " False "
      using A1 A3 A4 xxreal_0_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_60:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <=XXREAL-3R1 -XXREAL-3K2 y implies y <=XXREAL-3R1 -XXREAL-3K2 x) & (-XXREAL-3K2 x <=XXREAL-3R1 y implies -XXREAL-3K2 y <=XXREAL-3R1 x)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <=XXREAL-3R1 -XXREAL-3K2 y implies y <=XXREAL-3R1 -XXREAL-3K2 x) &  not (-XXREAL-3K2 x <=XXREAL-3R1 y &  not -XXREAL-3K2 y <=XXREAL-3R1 x)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "x <=XXREAL-3R1 -XXREAL-3K2 y implies -XXREAL-3K2 (-XXREAL-3K2 y) <=XXREAL-3R1 -XXREAL-3K2 x"
      using xxreal_3_th_38 sorry
    thus "x <=XXREAL-3R1 -XXREAL-3K2 y implies y <=XXREAL-3R1 -XXREAL-3K2 x"
       sorry
    have "-XXREAL-3K2 x <=XXREAL-3R1 y implies -XXREAL-3K2 y <=XXREAL-3R1 -XXREAL-3K2 (-XXREAL-3K2 x)"
      using xxreal_3_th_38 sorry
    thus " not (-XXREAL-3K2 x <=XXREAL-3R1 y &  not -XXREAL-3K2 y <=XXREAL-3R1 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_61:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds ( for e be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 e implies x <XXREAL-0R3 y +XXREAL-3K1 e) implies x <=XXREAL-3R1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds ( for e be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 e implies x <XXREAL-0R3 y +XXREAL-3K1 e) implies x <=XXREAL-3R1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: " for e be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 e implies x <XXREAL-0R3 y +XXREAL-3K1 e"
    show "x <=XXREAL-3R1 y"
    proof-
      have cases: "(y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2) or y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
         sorry
      have case1: "y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 y"
      proof(rule impI)
        assume A2: "y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2"
        show "x <=XXREAL-3R1 y"
        proof-
          have cases: "y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2"
            using A2 sorry
          have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 y"
          proof(rule impI)
            assume "y =HIDDENR1 +inftyXXREAL-0K1"
            thus "x <=XXREAL-3R1 y"
              using xxreal_0_th_4 sorry
          qed
          have case2: "y =HIDDENR1 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 y"
          proof(rule impI)
            assume A3: "y =HIDDENR1 -inftyXXREAL-0K2"
            have "x <XXREAL-0R3 y +XXREAL-3K1 \<one>\<^sub>M"
              using A1 sorry
            thus "x <=XXREAL-3R1 y"
              using A3 xxreal_3_def_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 implies x <=XXREAL-3R1 y"
      proof(rule impI)
        assume A4: "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
        show "x <=XXREAL-3R1 y"
        proof-
          have cases: "x =HIDDENR1 +inftyXXREAL-0K1 or x <>HIDDENR2 +inftyXXREAL-0K1"
             sorry
          have case1: "x =HIDDENR1 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 y"
          proof(rule impI)
            assume A5: "x =HIDDENR1 +inftyXXREAL-0K1"
            have "x <XXREAL-0R3 y +XXREAL-3K1 \<one>\<^sub>M"
              using A1 sorry
            thus "x <=XXREAL-3R1 y"
              using A5 xxreal_0_th_4 sorry
          qed
          have case2: "x <>HIDDENR2 +inftyXXREAL-0K1 implies x <=XXREAL-3R1 y"
          proof(rule impI)
            assume A6: "x <>HIDDENR2 +inftyXXREAL-0K1"
            have "x <>HIDDENR2 -inftyXXREAL-0K2 implies ( not x <=XXREAL-3R1 y implies  False )"
            proof(rule impI,rule impI)
              assume A7: "x <>HIDDENR2 -inftyXXREAL-0K2"
              then have "x inHIDDENR3 REALNUMBERSK2"
                using A6 xxreal_0_th_14 sorry
              then obtain x1 where 
                [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x"
                 sorry
              have "-inftyXXREAL-0K2 <=XXREAL-3R1 x"
                using xxreal_0_th_5 sorry
              then have A8: "-inftyXXREAL-0K2 <XXREAL-0R3 x"
                using A7 xxreal_0_th_1 sorry
              have "y inHIDDENR3 REALNUMBERSK2"
                using A4 xxreal_0_th_14 sorry
              then obtain y1 where 
                [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
                 sorry
              assume A9: " not x <=XXREAL-3R1 y"
              have "y <XXREAL-0R3 +inftyXXREAL-0K1"
                using A4 xxreal_0_th_4 sorry
              then have "0NUMBERSK6 <XXREAL-0R3 x -XXREAL-3K3 y"
                using A9 A8 xxreal_3_th_51 sorry
              then have "x <XXREAL-0R3 y +XXREAL-3K1 (x1 -XXREAL-3K3 y1)"
                using A1 sorry
              then have "x <XXREAL-0R3 (y +XXREAL-3K1 x)-XXREAL-3K3 y"
                using xxreal_3_th_30 sorry
              then have "x <XXREAL-0R3 x +XXREAL-3K1 (y -XXREAL-3K3 y)"
                using A4 xxreal_3_th_30 sorry
              then have "x <XXREAL-0R3 x +XXREAL-3K1 0NUMBERSK6"
                using xxreal_3_th_7 sorry
              thus " False "
                using xxreal_3_th_4 sorry
            qed
            thus "x <=XXREAL-3R1 y"
              using xxreal_0_th_5 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve t for "ExtRealXXREAL-0M1"
mtheorem xxreal_3_th_62:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds (t <>HIDDENR2 -inftyXXREAL-0K2 & t <>HIDDENR2 +inftyXXREAL-0K1) & x <XXREAL-0R3 y implies x +XXREAL-3K1 t <XXREAL-0R3 y +XXREAL-3K1 t"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds (t <>HIDDENR2 -inftyXXREAL-0K2 & t <>HIDDENR2 +inftyXXREAL-0K1) & x <XXREAL-0R3 y implies  not x +XXREAL-3K1 t <XXREAL-0R3 y +XXREAL-3K1 t"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "t <>HIDDENR2 -inftyXXREAL-0K2 & t <>HIDDENR2 +inftyXXREAL-0K1"
      and A2: "x <XXREAL-0R3 y"
    have A3: "t -XXREAL-3K3 t =HIDDENR1 0NUMBERSK6"
      using xxreal_3_th_7 sorry
    have A4: "x +XXREAL-3K1 t =HIDDENR1 y +XXREAL-3K1 t implies  False "
    proof(rule impI)
      assume "x +XXREAL-3K1 t =HIDDENR1 y +XXREAL-3K1 t"
      then have "x +XXREAL-3K1 (t -XXREAL-3K3 t) =HIDDENR1 (y +XXREAL-3K1 t)-XXREAL-3K3 t"
        using A1 xxreal_3_th_30 sorry
      then have "x +XXREAL-3K1 0NUMBERSK6 =HIDDENR1 y +XXREAL-3K1 (t -XXREAL-3K3 t)"
        using A1 A3 xxreal_3_th_30 sorry
      then have "x =HIDDENR1 y +XXREAL-3K1 0NUMBERSK6"
        using A3 xxreal_3_th_4 sorry
      thus " False "
        using A2 xxreal_3_th_4 sorry
    qed
    have "x +XXREAL-3K1 t <=XXREAL-3R1 y +XXREAL-3K1 t"
      using A2 xxreal_3_th_36 sorry
    thus " not x +XXREAL-3K1 t <XXREAL-0R3 y +XXREAL-3K1 t"
      using A4 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_63:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds (t <>HIDDENR2 -inftyXXREAL-0K2 & t <>HIDDENR2 +inftyXXREAL-0K1) & x <XXREAL-0R3 y implies x -XXREAL-3K3 t <XXREAL-0R3 y -XXREAL-3K3 t"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds (t <>HIDDENR2 -inftyXXREAL-0K2 & t <>HIDDENR2 +inftyXXREAL-0K1) & x <XXREAL-0R3 y implies  not x -XXREAL-3K3 t <XXREAL-0R3 y -XXREAL-3K3 t"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "t <>HIDDENR2 -inftyXXREAL-0K2 & t <>HIDDENR2 +inftyXXREAL-0K1"
      and A2: "x <XXREAL-0R3 y"
    have A3: "t -XXREAL-3K3 t =HIDDENR1 0NUMBERSK6"
      using xxreal_3_th_7 sorry
    have A4: "x -XXREAL-3K3 t =HIDDENR1 y -XXREAL-3K3 t implies  False "
    proof(rule impI)
      assume "x -XXREAL-3K3 t =HIDDENR1 y -XXREAL-3K3 t"
      then have "x -XXREAL-3K3 (t -XXREAL-3K3 t) =HIDDENR1 (y -XXREAL-3K3 t)+XXREAL-3K1 t"
        using A1 xxreal_3_th_32 sorry
      then have "x -XXREAL-3K3 0NUMBERSK6 =HIDDENR1 y -XXREAL-3K3 (t -XXREAL-3K3 t)"
        using A1 A3 xxreal_3_th_32 sorry
      then have "x =HIDDENR1 y +XXREAL-3K1 0NUMBERSK6"
        using A3 xxreal_3_th_4 sorry
      thus " False "
        using A2 xxreal_3_th_4 sorry
    qed
    have "x -XXREAL-3K3 t <=XXREAL-3R1 y -XXREAL-3K3 t"
      using A2 xxreal_3_th_37 sorry
    thus " not x -XXREAL-3K3 t <XXREAL-0R3 y -XXREAL-3K3 t"
      using A4 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_64:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y & w <XXREAL-0R3 z implies x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  for w be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y & w <XXREAL-0R3 z implies  not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    fix w assume [ty]: "w be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
      and A2: "w <XXREAL-0R3 z"
    have Cut2407: "-inftyXXREAL-0K2 <=XXREAL-3R1 w"
      using xxreal_0_th_5 sorry
    show " not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
    proof-
      have cases: "w =HIDDENR1 -inftyXXREAL-0K2 or -inftyXXREAL-0K2 <XXREAL-0R3 w"
        using xxreal_0_th_1 Cut2407 sorry
      have case1: "w =HIDDENR1 -inftyXXREAL-0K2 implies  not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
      proof(rule impI)
        assume A3: "w =HIDDENR1 -inftyXXREAL-0K2"
        have A4: "y <>HIDDENR2 -inftyXXREAL-0K2 & z <>HIDDENR2 -inftyXXREAL-0K2"
          using A1 A2 xxreal_0_th_5 sorry
        have "x <>HIDDENR2 +inftyXXREAL-0K1"
          using A1 xxreal_0_th_3 sorry
        then have "x +XXREAL-3K1 w =HIDDENR1 -inftyXXREAL-0K2"
          using A3 xxreal_3_def_2 sorry
        thus " not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
          using A4 xxreal_3_lm_9 xxreal_0_th_6 sorry
      qed
      have case2: "-inftyXXREAL-0K2 <XXREAL-0R3 w implies  not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
      proof(rule impI)
        assume A5: "-inftyXXREAL-0K2 <XXREAL-0R3 w"
        show " not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
        proof-
          have cases: "y =HIDDENR1 +inftyXXREAL-0K1 or y <>HIDDENR2 +inftyXXREAL-0K1"
             sorry
          have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies  not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A6: "y =HIDDENR1 +inftyXXREAL-0K1"
            have A7: "z <=XXREAL-3R1 +inftyXXREAL-0K1"
              using xxreal_0_th_4 sorry
            have "y +XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
              using A5 A2 A6 xxreal_3_def_2 sorry
            thus " not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
              using A1 A2 A6 A7 xxreal_3_lm_8 xxreal_0_th_4 sorry
          qed
          have case2: "y <>HIDDENR2 +inftyXXREAL-0K1 implies  not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
          proof(rule impI)
            assume A8: "y <>HIDDENR2 +inftyXXREAL-0K1"
            have "-inftyXXREAL-0K2 <=XXREAL-3R1 x"
              using xxreal_0_th_5 sorry
            then have "y inHIDDENR3 REALNUMBERSK2"
              using A1 A8 xxreal_0_th_14 sorry
            then have A9: "y +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
              using A2 xxreal_3_th_43 sorry
            have "z <=XXREAL-3R1 +inftyXXREAL-0K1"
              using xxreal_0_th_4 sorry
            then have "w inHIDDENR3 REALNUMBERSK2"
              using A5 A2 xxreal_0_th_14 sorry
            then have "x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 w"
              using A1 xxreal_3_th_43 sorry
            thus " not x +XXREAL-3K1 w <XXREAL-0R3 y +XXREAL-3K1 z"
              using A9 xxreal_0_th_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_65:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x & z +XXREAL-3K1 x <=XXREAL-3R1 y implies z <=XXREAL-3R1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-3R1 x implies  not (z +XXREAL-3K1 x <=XXREAL-3R1 y &  not z <=XXREAL-3R1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume "0NUMBERSK6 <=XXREAL-3R1 x"
    then have "z <=XXREAL-3R1 z +XXREAL-3K1 x"
      using xxreal_3_th_39 sorry
    thus " not (z +XXREAL-3K1 x <=XXREAL-3R1 y &  not z <=XXREAL-3R1 y)"
      using xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef xxreal_3_def_5 (" _ *XXREAL-3K4  _ " [164,164]164 ) where
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"func x *XXREAL-3K4 y \<rightarrow> ExtRealXXREAL-0M1 means
  \<lambda>it.  ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a *XCMPLX-0K3 b if x be realXREAL-0V1 & y be realXREAL-0V1,
  \<lambda>it. it =HIDDENR1 +inftyXXREAL-0K1 if ( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3),
  \<lambda>it. it =HIDDENR1 -inftyXXREAL-0K2 if ( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2) otherwise \<lambda>it. it =HIDDENR1 0NUMBERSK6"
proof-
  (*existence*)
    show "(x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex it be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a *XCMPLX-0K3 b)) & ((( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3) implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 +inftyXXREAL-0K1)) & ((( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2) implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 -inftyXXREAL-0K2)) & ( not (x be realXREAL-0V1 & y be realXREAL-0V1) & ( not (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3)) &  not (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2))) implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 0NUMBERSK6))))"
    proof-
      have "(x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex c be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & c =HIDDENR1 a *XCMPLX-0K3 b)) & (( not (( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2) &  not (x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3))) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 +inftyXXREAL-0K1)) &  not (( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3) &  not (x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2))) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 -inftyXXREAL-0K2))) &  not ((( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2) &  not (x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3)))) &  not ( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3) &  not (x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2)))) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 0NUMBERSK6)))"
      proof(rule conjMI)
        show "x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex c be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & c =HIDDENR1 a *XCMPLX-0K3 b)"
        proof-
          have "x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex tVar16 be ExtRealXXREAL-0M1 st  ex tVar17 be ComplexXCMPLX-0M1 st  ex tVar18 be ComplexXCMPLX-0M1 st (x =HIDDENR1 tVar17 & y =HIDDENR1 tVar18) & tVar17 *XCMPLX-0K3 tVar18 =HIDDENR1 tVar17 *XCMPLX-0K3 tVar18)"
          proof(rule impI)
            assume "x be realXREAL-0V1 & y be realXREAL-0V1"
            then obtain a b where 
              [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
              [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
               sorry
            show " ex tVar16 be ExtRealXXREAL-0M1 st  ex tVar17 be ComplexXCMPLX-0M1 st  ex tVar18 be ComplexXCMPLX-0M1 st (x =HIDDENR1 tVar17 & y =HIDDENR1 tVar18) & tVar17 *XCMPLX-0K3 tVar18 =HIDDENR1 tVar17 *XCMPLX-0K3 tVar18"
            proof(rule bexI[of _ "a *XCMPLX-0K3 b"])
              show " ex tVar17 be ComplexXCMPLX-0M1 st  ex tVar18 be ComplexXCMPLX-0M1 st (x =HIDDENR1 tVar17 & y =HIDDENR1 tVar18) & tVar17 *XCMPLX-0K3 tVar18 =HIDDENR1 tVar17 *XCMPLX-0K3 tVar18"
              proof(rule bexI[of _ "a"])
                show " ex tVar18 be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 tVar18) & a *XCMPLX-0K3 tVar18 =HIDDENR1 a *XCMPLX-0K3 tVar18"
                proof(rule bexI[of _ "b"])
                  show "(x =HIDDENR1 a & y =HIDDENR1 b) & a *XCMPLX-0K3 b =HIDDENR1 a *XCMPLX-0K3 b"
                     sorry
                qed "sorry"
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show "( not (( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2) &  not (x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3))) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 +inftyXXREAL-0K1)) &  not (( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3) &  not (x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2))) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 -inftyXXREAL-0K2))) &  not ((( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2) &  not (x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3)))) &  not ( not (x be realXREAL-0V1 & y be realXREAL-0V1) &  not ( not (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3) &  not (x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2)))) & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ExtRealXXREAL-0M1 holds  for it2 be ExtRealXXREAL-0M1 holds (x be realXREAL-0V1 & y be realXREAL-0V1 implies (( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it1 =HIDDENR1 a *XCMPLX-0K3 b) & ( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it2 =HIDDENR1 a *XCMPLX-0K3 b) implies it1 =HIDDENR1 it2)) & ((( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3) implies (it1 =HIDDENR1 +inftyXXREAL-0K1 & it2 =HIDDENR1 +inftyXXREAL-0K1 implies it1 =HIDDENR1 it2)) & ((( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2) implies (it1 =HIDDENR1 -inftyXXREAL-0K2 & it2 =HIDDENR1 -inftyXXREAL-0K2 implies it1 =HIDDENR1 it2)) & ( not (x be realXREAL-0V1 & y be realXREAL-0V1) & ( not (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3)) &  not (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2))) implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2))))"
       sorry
  (*consistency*)
    show " for it be ExtRealXXREAL-0M1 holds (((x be realXREAL-0V1 & y be realXREAL-0V1) & (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3)) implies (( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a *XCMPLX-0K3 b) iff it =HIDDENR1 +inftyXXREAL-0K1)) & ((x be realXREAL-0V1 & y be realXREAL-0V1) & (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2)) implies (( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a *XCMPLX-0K3 b) iff it =HIDDENR1 -inftyXXREAL-0K2))) & ((( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3)) & (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2)) implies (it =HIDDENR1 +inftyXXREAL-0K1 iff it =HIDDENR1 -inftyXXREAL-0K2))"
       sorry
qed "sorry"

mtheorem XXREAL_3K4_commutativity:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 y =HIDDENR1 y *XXREAL-3K4 x"
proof-
  have " for it be ExtRealXXREAL-0M1 holds  for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds it =HIDDENR1 x *XXREAL-3K4 y implies it =HIDDENR1 y *XXREAL-3K4 x"
  proof-
    have " for it be ExtRealXXREAL-0M1 holds  for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x be realXREAL-0V1 & y be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & y =HIDDENR1 b) & it =HIDDENR1 a *XCMPLX-0K3 b)) & ((( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3) implies it =HIDDENR1 +inftyXXREAL-0K1) & ((( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2) implies it =HIDDENR1 -inftyXXREAL-0K2) & ( not (x be realXREAL-0V1 & y be realXREAL-0V1) & ( not (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3)) &  not (( not x be realXREAL-0V1 or  not y be realXREAL-0V1) & (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2))) implies it =HIDDENR1 0NUMBERSK6))) implies (y be realXREAL-0V1 & x be realXREAL-0V1 implies ( ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (y =HIDDENR1 a & x =HIDDENR1 b) & it =HIDDENR1 a *XCMPLX-0K3 b)) & ((( not y be realXREAL-0V1 or  not x be realXREAL-0V1) & (y be positiveXXREAL-0V2 & x be positiveXXREAL-0V2 or y be negativeXXREAL-0V3 & x be negativeXXREAL-0V3) implies it =HIDDENR1 +inftyXXREAL-0K1) & ((( not y be realXREAL-0V1 or  not x be realXREAL-0V1) & (y be positiveXXREAL-0V2 & x be negativeXXREAL-0V3 or y be negativeXXREAL-0V3 & x be positiveXXREAL-0V2) implies it =HIDDENR1 -inftyXXREAL-0K2) & ( not (y be realXREAL-0V1 & x be realXREAL-0V1) & ( not (( not y be realXREAL-0V1 or  not x be realXREAL-0V1) & (y be positiveXXREAL-0V2 & x be positiveXXREAL-0V2 or y be negativeXXREAL-0V3 & x be negativeXXREAL-0V3)) &  not (( not y be realXREAL-0V1 or  not x be realXREAL-0V1) & (y be positiveXXREAL-0V2 & x be negativeXXREAL-0V3 or y be negativeXXREAL-0V3 & x be positiveXXREAL-0V2))) implies it =HIDDENR1 0NUMBERSK6)))"
       sorry
    thus " ?thesis "
      using xxreal_3_def_5 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_ident_4:
  mlet "x be RealXREAL-0M1", "y be RealXREAL-0M1", "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1"
"identify x *XXREAL-3K4 y with a *XCMPLX-0K3 b when x =HIDDENR1 a & y =HIDDENR1 b"
proof
(*compatibility*)
  show "x =HIDDENR1 a & y =HIDDENR1 b implies x *XXREAL-3K4 y =HIDDENR1 a *XCMPLX-0K3 b"
    using xxreal_3_def_5 sorry
qed "sorry"

mdef xxreal_3_def_6 (" _ \<inverse>XXREAL-3K5" [228]228 ) where
  mlet "x be ExtRealXXREAL-0M1"
"func x \<inverse>XXREAL-3K5 \<rightarrow> ExtRealXXREAL-0M1 means
  \<lambda>it.  ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it =HIDDENR1 a \<inverse>XCMPLX-0K5 if x be realXREAL-0V1 otherwise \<lambda>it. it =HIDDENR1 0NUMBERSK6"
proof-
  (*existence*)
    show "(x be realXREAL-0V1 implies ( ex it be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it =HIDDENR1 a \<inverse>XCMPLX-0K5)) & ( not x be realXREAL-0V1 implies ( ex it be ExtRealXXREAL-0M1 st it =HIDDENR1 0NUMBERSK6))"
    proof-
      have "(x be realXREAL-0V1 implies ( ex c be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & c =HIDDENR1 a \<inverse>XCMPLX-0K5)) &  not ( not x be realXREAL-0V1 & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 0NUMBERSK6))"
      proof(rule conjMI)
        show "x be realXREAL-0V1 implies ( ex c be ExtRealXXREAL-0M1 st  ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & c =HIDDENR1 a \<inverse>XCMPLX-0K5)"
        proof-
          have "x be realXREAL-0V1 implies ( ex tVar19 be ExtRealXXREAL-0M1 st  ex tVar20 be ComplexXCMPLX-0M1 st x =HIDDENR1 tVar20 & tVar20 \<inverse>XCMPLX-0K5 =HIDDENR1 tVar20 \<inverse>XCMPLX-0K5)"
          proof(rule impI)
            assume "x be realXREAL-0V1"
            then obtain a where 
              [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
               sorry
            show " ex tVar19 be ExtRealXXREAL-0M1 st  ex tVar20 be ComplexXCMPLX-0M1 st x =HIDDENR1 tVar20 & tVar20 \<inverse>XCMPLX-0K5 =HIDDENR1 tVar20 \<inverse>XCMPLX-0K5"
            proof(rule bexI[of _ "a \<inverse>XCMPLX-0K5"])
              show " ex tVar20 be ComplexXCMPLX-0M1 st x =HIDDENR1 tVar20 & tVar20 \<inverse>XCMPLX-0K5 =HIDDENR1 tVar20 \<inverse>XCMPLX-0K5"
              proof(rule bexI[of _ "a"])
                show "x =HIDDENR1 a & a \<inverse>XCMPLX-0K5 =HIDDENR1 a \<inverse>XCMPLX-0K5"
                   sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show " not ( not x be realXREAL-0V1 & ( for VarFor1 be ExtRealXXREAL-0M1 holds  not VarFor1 =HIDDENR1 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ExtRealXXREAL-0M1 holds  for it2 be ExtRealXXREAL-0M1 holds (x be realXREAL-0V1 implies (( ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it1 =HIDDENR1 a \<inverse>XCMPLX-0K5) & ( ex a be ComplexXCMPLX-0M1 st x =HIDDENR1 a & it2 =HIDDENR1 a \<inverse>XCMPLX-0K5) implies it1 =HIDDENR1 it2)) & ( not x be realXREAL-0V1 implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be ExtRealXXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem xxreal_3_ident_5:
  mlet "x be RealXREAL-0M1", "a be ComplexXCMPLX-0M1"
"identify x \<inverse>XXREAL-3K5 with a \<inverse>XCMPLX-0K5 when x =HIDDENR1 a"
proof
(*compatibility*)
  show "x =HIDDENR1 a implies x \<inverse>XXREAL-3K5 =HIDDENR1 a \<inverse>XCMPLX-0K5"
    using xxreal_3_def_6 sorry
qed "sorry"

mdef xxreal_3_def_7 (" _ '/XXREAL-3K6  _ " [164,164]164 ) where
  mlet "x be ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"func x /XXREAL-3K6 y \<rightarrow> ExtRealXXREAL-0M1 equals
  x *XXREAL-3K4 y \<inverse>XXREAL-3K5"
proof-
  (*coherence*)
    show "x *XXREAL-3K4 y \<inverse>XXREAL-3K5 be ExtRealXXREAL-0M1"
       sorry
qed "sorry"

mtheorem xxreal_3_ident_6:
  mlet "x be RealXREAL-0M1", "y be RealXREAL-0M1", "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1"
"identify x /XXREAL-3K6 y with a /XCMPLX-0K7 b when x =HIDDENR1 a & y =HIDDENR1 b"
proof
(*compatibility*)
  show "x =HIDDENR1 a & y =HIDDENR1 b implies x /XXREAL-3K6 y =HIDDENR1 a /XCMPLX-0K7 b"
  proof-
    have "x =HIDDENR1 a & y =HIDDENR1 b implies a /XCMPLX-0K7 b =HIDDENR1 x /XXREAL-3K6 y"
    proof(rule impI)
      obtain y1 where 
        [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y \<inverse>XXREAL-3K5"
         sorry
      assume "x =HIDDENR1 a & y =HIDDENR1 b"
      then have "a /XCMPLX-0K7 b =HIDDENR1 x *XXREAL-3K4 y1"
         sorry
      also have "... = x /XXREAL-3K6 y"
         sorry
      finally show "a /XCMPLX-0K7 b =HIDDENR1 x /XXREAL-3K6 y"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma xxreal_3_lm_17:
" for x be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
    proof-
      have cases: "(x inHIDDENR3 REALNUMBERSK2 or x =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 implies x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2"
        then have " ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (x =HIDDENR1 a & 0NUMBERSK6 =HIDDENR1 b) & x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 a *XCMPLX-0K3 b"
          using xxreal_3_def_5 sorry
        thus "x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
           sorry
      qed
      have case2: "x =HIDDENR1 +inftyXXREAL-0K1 implies x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1"
        thus "x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
          using xxreal_3_def_5 sorry
      qed
      have case3: "x =HIDDENR1 -inftyXXREAL-0K2 implies x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2"
        thus "x *XXREAL-3K4 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
          using xxreal_3_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_cl_28:
  mlet "x be positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x *XXREAL-3K4 y as-term-is negativeXXREAL-0V3"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be negativeXXREAL-0V3"
  proof-
    show "x *XXREAL-3K4 y be negativeXXREAL-0V3"
    proof-
      have cases: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or ( not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2)"
         sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies x *XXREAL-3K4 y be negativeXXREAL-0V3"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        then have 
          [ty]:"x be RealXREAL-0M1" and
          [ty]:"y be RealXREAL-0M1"
           sorry
        have "x *XXREAL-3K4 y <XXREAL-0R3 0NUMBERSK6"
           sorry
        thus "x *XXREAL-3K4 y be negativeXXREAL-0V3"
           sorry
      qed
      have case2: " not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2 implies x *XXREAL-3K4 y be negativeXXREAL-0V3"
      proof(rule impI)
        assume " not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2"
        then have " not x be realXREAL-0V1 or  not y be realXREAL-0V1"
          using xreal_0_def_1 sorry
        thus "x *XXREAL-3K4 y be negativeXXREAL-0V3"
          using xxreal_3_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem xxreal_3_cl_29:
  mlet "x be negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x *XXREAL-3K4 y as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be positiveXXREAL-0V2"
  proof-
    show "x *XXREAL-3K4 y be positiveXXREAL-0V2"
    proof-
      have cases: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or ( not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2)"
         sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies x *XXREAL-3K4 y be positiveXXREAL-0V2"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        then have 
          [ty]:"x be RealXREAL-0M1" and
          [ty]:"y be RealXREAL-0M1"
           sorry
        have "x *XXREAL-3K4 y >XXREAL-0R4 0NUMBERSK6"
           sorry
        thus "x *XXREAL-3K4 y be positiveXXREAL-0V2"
           sorry
      qed
      have case2: " not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2 implies x *XXREAL-3K4 y be positiveXXREAL-0V2"
      proof(rule impI)
        assume " not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2"
        then have " not x be realXREAL-0V1 or  not y be realXREAL-0V1"
          using xreal_0_def_1 sorry
        thus "x *XXREAL-3K4 y be positiveXXREAL-0V2"
          using xxreal_3_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem xxreal_3_cl_30:
  mlet "x be positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x *XXREAL-3K4 y as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be positiveXXREAL-0V2"
  proof-
    show "x *XXREAL-3K4 y be positiveXXREAL-0V2"
    proof-
      have cases: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or ( not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2)"
         sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies x *XXREAL-3K4 y be positiveXXREAL-0V2"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
        then have 
          [ty]:"x be RealXREAL-0M1" and
          [ty]:"y be RealXREAL-0M1"
           sorry
        have "x *XXREAL-3K4 y >XXREAL-0R4 0NUMBERSK6"
           sorry
        thus "x *XXREAL-3K4 y be positiveXXREAL-0V2"
           sorry
      qed
      have case2: " not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2 implies x *XXREAL-3K4 y be positiveXXREAL-0V2"
      proof(rule impI)
        assume " not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2"
        then have " not x be realXREAL-0V1 or  not y be realXREAL-0V1"
          using xreal_0_def_1 sorry
        thus "x *XXREAL-3K4 y be positiveXXREAL-0V2"
          using xxreal_3_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem xxreal_3_cl_31:
  mlet "x be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x *XXREAL-3K4 y as-term-is  non positiveXXREAL-0V2"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be  non positiveXXREAL-0V2"
  proof-
    have "x *XXREAL-3K4 y <=XXREAL-3R1 0NUMBERSK6"
    proof-
      show "x *XXREAL-3K4 y <=XXREAL-3R1 0NUMBERSK6"
      proof-
        have cases: "(x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6) or x <XXREAL-0R3 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6"
           sorry
        have case1: "x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6 implies  not x *XXREAL-3K4 y be positiveXXREAL-0V2"
        proof(rule impI)
          assume Cut2612: "x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6"
          have "x *XXREAL-3K4 y <=XXREAL-3R1 0NUMBERSK6"
          proof-
            show "x *XXREAL-3K4 y <=XXREAL-3R1 0NUMBERSK6"
              using xxreal_3_lm_17 Cut2612 sorry
          qed
          thus " not x *XXREAL-3K4 y be positiveXXREAL-0V2"
            using xxreal_0_def_6 sorry
        qed
        have case2: "x <XXREAL-0R3 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6 implies  not x *XXREAL-3K4 y be positiveXXREAL-0V2"
        proof(rule impI)
          assume Cut2616: "x <XXREAL-0R3 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6"
          have "x *XXREAL-3K4 y <=XXREAL-3R1 0NUMBERSK6"
          proof-
            show "x *XXREAL-3K4 y <=XXREAL-3R1 0NUMBERSK6"
              using Cut2616 sorry
          qed
          thus " not x *XXREAL-3K4 y be positiveXXREAL-0V2"
            using xxreal_0_def_6 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_32:
  mlet "x be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x *XXREAL-3K4 y as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be  non negativeXXREAL-0V3"
  proof-
    have "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
    proof-
      show "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
      proof-
        have cases: "(x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6) or x <XXREAL-0R3 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6 implies  not x *XXREAL-3K4 y be negativeXXREAL-0V3"
        proof(rule impI)
          assume Cut2629: "x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6"
          have "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
          proof-
            show "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
              using xxreal_3_lm_17 Cut2629 sorry
          qed
          thus " not x *XXREAL-3K4 y be negativeXXREAL-0V3"
            using xxreal_0_def_7 sorry
        qed
        have case2: "x <XXREAL-0R3 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6 implies  not x *XXREAL-3K4 y be negativeXXREAL-0V3"
        proof(rule impI)
          assume Cut2633: "x <XXREAL-0R3 0NUMBERSK6 & y <XXREAL-0R3 0NUMBERSK6"
          have "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
          proof-
            show "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
              using Cut2633 sorry
          qed
          thus " not x *XXREAL-3K4 y be negativeXXREAL-0V3"
            using xxreal_0_def_7 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_33:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x *XXREAL-3K4 y as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be  non negativeXXREAL-0V3"
  proof-
    have "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
    proof-
      show "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
      proof-
        have cases: "(x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6) or x >XXREAL-0R4 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6"
           sorry
        have case1: "x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6 implies  not x *XXREAL-3K4 y be negativeXXREAL-0V3"
        proof(rule impI)
          assume Cut2646: "x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6"
          have "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
          proof-
            show "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
              using xxreal_3_lm_17 Cut2646 sorry
          qed
          thus " not x *XXREAL-3K4 y be negativeXXREAL-0V3"
            using xxreal_0_def_7 sorry
        qed
        have case2: "x >XXREAL-0R4 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6 implies  not x *XXREAL-3K4 y be negativeXXREAL-0V3"
        proof(rule impI)
          assume Cut2650: "x >XXREAL-0R4 0NUMBERSK6 & y >XXREAL-0R4 0NUMBERSK6"
          have "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
          proof-
            show "x *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
              using Cut2650 sorry
          qed
          thus " not x *XXREAL-3K4 y be negativeXXREAL-0V3"
            using xxreal_0_def_7 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_34:
  mlet "x be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x \<inverse>XXREAL-3K5 as-term-is  non positiveXXREAL-0V2"
proof
(*coherence*)
  show "x \<inverse>XXREAL-3K5 be  non positiveXXREAL-0V2"
  proof-
    have " not x \<inverse>XXREAL-3K5 be positiveXXREAL-0V2"
    proof-
      show " not x \<inverse>XXREAL-3K5 be positiveXXREAL-0V2"
      proof-
        have cases: "x be realXREAL-0V1 or  not x be realXREAL-0V1"
           sorry
        have case1: "x be realXREAL-0V1 implies  not x \<inverse>XXREAL-3K5 be positiveXXREAL-0V2"
        proof(rule impI)
          assume "x be realXREAL-0V1"
          then have 
            [ty]:"x be RealXREAL-0M1"
             sorry
          have "x \<inverse>XXREAL-3K5 be  non positiveXXREAL-0V2"
             sorry
          thus " not x \<inverse>XXREAL-3K5 be positiveXXREAL-0V2"
             sorry
        qed
        have case2: " not x be realXREAL-0V1 implies  not x \<inverse>XXREAL-3K5 be positiveXXREAL-0V2"
        proof(rule impI)
          assume " not x be realXREAL-0V1"
          thus " not x \<inverse>XXREAL-3K5 be positiveXXREAL-0V2"
            using xxreal_3_def_6 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_35:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x \<inverse>XXREAL-3K5 as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "x \<inverse>XXREAL-3K5 be  non negativeXXREAL-0V3"
  proof-
    have " not x \<inverse>XXREAL-3K5 be negativeXXREAL-0V3"
    proof-
      show " not x \<inverse>XXREAL-3K5 be negativeXXREAL-0V3"
      proof-
        have cases: "x be realXREAL-0V1 or  not x be realXREAL-0V1"
           sorry
        have case1: "x be realXREAL-0V1 implies  not x \<inverse>XXREAL-3K5 be negativeXXREAL-0V3"
        proof(rule impI)
          assume "x be realXREAL-0V1"
          then have 
            [ty]:"x be RealXREAL-0M1"
             sorry
          have "x \<inverse>XXREAL-3K5 be  non negativeXXREAL-0V3"
             sorry
          thus " not x \<inverse>XXREAL-3K5 be negativeXXREAL-0V3"
             sorry
        qed
        have case2: " not x be realXREAL-0V1 implies  not x \<inverse>XXREAL-3K5 be negativeXXREAL-0V3"
        proof(rule impI)
          assume " not x be realXREAL-0V1"
          thus " not x \<inverse>XXREAL-3K5 be negativeXXREAL-0V3"
            using xxreal_3_def_6 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_36:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x /XXREAL-3K6 y as-term-is  non positiveXXREAL-0V2"
proof
(*coherence*)
  show "x /XXREAL-3K6 y be  non positiveXXREAL-0V2"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_37:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster y /XXREAL-3K6 x as-term-is  non positiveXXREAL-0V2"
proof
(*coherence*)
  show "y /XXREAL-3K6 x be  non positiveXXREAL-0V2"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_38:
  mlet "x be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1", "y be  non negativeXXREAL-0V3\<bar>ExtRealXXREAL-0M1"
"cluster x /XXREAL-3K6 y as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "x /XXREAL-3K6 y be  non negativeXXREAL-0V3"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_39:
  mlet "x be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1", "y be  non positiveXXREAL-0V2\<bar>ExtRealXXREAL-0M1"
"cluster x /XXREAL-3K6 y as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "x /XXREAL-3K6 y be  non negativeXXREAL-0V3"
     sorry
qed "sorry"

mlemma xxreal_3_lm_18:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not x be realXREAL-0V1 & x *XXREAL-3K4 y =HIDDENR1 0NUMBERSK6 implies y =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  not x be realXREAL-0V1 & x *XXREAL-3K4 y =HIDDENR1 0NUMBERSK6 implies y =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: " not x be realXREAL-0V1"
      and A2: "x *XXREAL-3K4 y =HIDDENR1 0NUMBERSK6"
    have " not (x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3)"
      using A2 sorry
    thus "y =HIDDENR1 0NUMBERSK6"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_cl_40:
  mlet "x be  non zeroORDINAL1V8\<bar>ExtRealXXREAL-0M1", "y be  non zeroORDINAL1V8\<bar>ExtRealXXREAL-0M1"
"cluster x *XXREAL-3K4 y as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be  non zeroORDINAL1V8"
  proof-
    have "x *XXREAL-3K4 y be zeroORDINAL1V8 implies  False "
    proof-
      show "x *XXREAL-3K4 y be zeroORDINAL1V8 implies  False "
      proof-
        have cases: "x be realXREAL-0V1 & y be realXREAL-0V1 or ( not x be realXREAL-0V1 or  not y be realXREAL-0V1)"
           sorry
        have case1: "x be realXREAL-0V1 & y be realXREAL-0V1 implies (x *XXREAL-3K4 y be zeroORDINAL1V8 implies  False )"
        proof(rule impI,rule impI)
          assume "x be realXREAL-0V1 & y be realXREAL-0V1"
          then obtain r s where 
            [ty]:"r be RealXREAL-0M1" and rDef:"r = x" and
            [ty]:"s be RealXREAL-0M1" and sDef:"s = y"
             sorry
          assume "x *XXREAL-3K4 y be zeroORDINAL1V8"
          then have "r *XXREAL-3K4 s =HIDDENR1 0NUMBERSK6"
             sorry
          thus " False "
             sorry
        qed
        have case2: " not x be realXREAL-0V1 or  not y be realXREAL-0V1 implies  not x *XXREAL-3K4 y be zeroORDINAL1V8"
        proof(rule impI)
          assume " not x be realXREAL-0V1 or  not y be realXREAL-0V1"
          then have "x *XXREAL-3K4 y <>HIDDENR2 0NUMBERSK6"
            using xxreal_3_lm_18 sorry
          thus " not x *XXREAL-3K4 y be zeroORDINAL1V8"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_3_cl_41:
  mlet "x be zeroORDINAL1V8\<bar>ExtRealXXREAL-0M1", "y be ExtRealXXREAL-0M1"
"cluster x *XXREAL-3K4 y as-term-is zeroORDINAL1V8 for ExtRealXXREAL-0M1"
proof
(*coherence*)
  show " for it be ExtRealXXREAL-0M1 holds it =HIDDENR1 x *XXREAL-3K4 y implies it be zeroORDINAL1V8"
    using xxreal_3_lm_17 sorry
qed "sorry"

mlemma xxreal_3_lm_19:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x =HIDDENR1 0NUMBERSK6 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x =HIDDENR1 0NUMBERSK6 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x =HIDDENR1 0NUMBERSK6"
    then have "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 0NUMBERSK6"
       sorry
    also have "... = (x *XXREAL-3K4 y)*XXREAL-3K4 z"
      using A1 sorry
    finally show "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_20:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y =HIDDENR1 0NUMBERSK6 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y =HIDDENR1 0NUMBERSK6 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "y =HIDDENR1 0NUMBERSK6"
    then have "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 0NUMBERSK6"
       sorry
    also have "... = (x *XXREAL-3K4 y)*XXREAL-3K4 z"
      using A1 sorry
    finally show "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_21:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not y be realXREAL-0V1 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not y be realXREAL-0V1 implies ( not x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z implies  not  True )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume " not y be realXREAL-0V1"
    then have A1: " not y inHIDDENR3 REALNUMBERSK2"
       sorry
    assume A2: " not x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
    then have A3: "x <>HIDDENR2 0NUMBERSK6 & z <>HIDDENR2 0NUMBERSK6"
      using xxreal_3_lm_19 sorry
    show " not  True "
    proof-
      have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1"
        using A1 xxreal_0_th_14 sorry
      have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies  not  True "
      proof(rule impI)
        assume A4: "y =HIDDENR1 -inftyXXREAL-0K2"
        show " not  True "
        proof-
          have cases: "((x be positiveXXREAL-0V2 & z be positiveXXREAL-0V2 or x be positiveXXREAL-0V2 & z be negativeXXREAL-0V3) or x be negativeXXREAL-0V3 & z be positiveXXREAL-0V2) or x be negativeXXREAL-0V3 & z be negativeXXREAL-0V3"
            using A3 sorry
          have case1: "x be positiveXXREAL-0V2 & z be positiveXXREAL-0V2 implies  not  True "
          proof(rule impI)
            assume A5: "x be positiveXXREAL-0V2 & z be positiveXXREAL-0V2"
            then have "x *XXREAL-3K4 (-inftyXXREAL-0K2 *XXREAL-3K4 z) =HIDDENR1 x *XXREAL-3K4 -inftyXXREAL-0K2"
              using xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2"
              using A5 xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2 *XXREAL-3K4 z"
              using A5 xxreal_3_def_5 sorry
            also have "... = (x *XXREAL-3K4 -inftyXXREAL-0K2)*XXREAL-3K4 z"
              using A5 xxreal_3_def_5 sorry
            finally have "x *XXREAL-3K4 (-inftyXXREAL-0K2 *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 -inftyXXREAL-0K2)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A4 sorry
          qed
          have case2: "x be positiveXXREAL-0V2 & z be negativeXXREAL-0V3 implies  not  True "
          proof(rule impI)
            assume A6: "x be positiveXXREAL-0V2 & z be negativeXXREAL-0V3"
            then have "x *XXREAL-3K4 (-inftyXXREAL-0K2 *XXREAL-3K4 z) =HIDDENR1 x *XXREAL-3K4 +inftyXXREAL-0K1"
              using xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1"
              using A6 xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2 *XXREAL-3K4 z"
              using A6 xxreal_3_def_5 sorry
            also have "... = (x *XXREAL-3K4 -inftyXXREAL-0K2)*XXREAL-3K4 z"
              using A6 xxreal_3_def_5 sorry
            finally have "x *XXREAL-3K4 (-inftyXXREAL-0K2 *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 -inftyXXREAL-0K2)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A4 sorry
          qed
          have case3: "x be negativeXXREAL-0V3 & z be positiveXXREAL-0V2 implies  not  True "
          proof(rule impI)
            assume A7: "x be negativeXXREAL-0V3 & z be positiveXXREAL-0V2"
            then have "x *XXREAL-3K4 (-inftyXXREAL-0K2 *XXREAL-3K4 z) =HIDDENR1 x *XXREAL-3K4 -inftyXXREAL-0K2"
              using xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1"
              using A7 xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1 *XXREAL-3K4 z"
              using A7 xxreal_3_def_5 sorry
            also have "... = (x *XXREAL-3K4 -inftyXXREAL-0K2)*XXREAL-3K4 z"
              using A7 xxreal_3_def_5 sorry
            finally have "x *XXREAL-3K4 (-inftyXXREAL-0K2 *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 -inftyXXREAL-0K2)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A4 sorry
          qed
          have case4: "x be negativeXXREAL-0V3 & z be negativeXXREAL-0V3 implies  not  True "
          proof(rule impI)
            assume A8: "x be negativeXXREAL-0V3 & z be negativeXXREAL-0V3"
            then have "x *XXREAL-3K4 (-inftyXXREAL-0K2 *XXREAL-3K4 z) =HIDDENR1 x *XXREAL-3K4 +inftyXXREAL-0K1"
              using xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2"
              using A8 xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1 *XXREAL-3K4 z"
              using A8 xxreal_3_def_5 sorry
            also have "... = (x *XXREAL-3K4 -inftyXXREAL-0K2)*XXREAL-3K4 z"
              using A8 xxreal_3_def_5 sorry
            finally have "x *XXREAL-3K4 (-inftyXXREAL-0K2 *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 -inftyXXREAL-0K2)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies  not  True "
      proof(rule impI)
        assume A9: "y =HIDDENR1 +inftyXXREAL-0K1"
        show " not  True "
        proof-
          have cases: "((x be positiveXXREAL-0V2 & z be positiveXXREAL-0V2 or x be positiveXXREAL-0V2 & z be negativeXXREAL-0V3) or x be negativeXXREAL-0V3 & z be positiveXXREAL-0V2) or x be negativeXXREAL-0V3 & z be negativeXXREAL-0V3"
            using A3 sorry
          have case1: "x be positiveXXREAL-0V2 & z be positiveXXREAL-0V2 implies  not  True "
          proof(rule impI)
            assume A10: "x be positiveXXREAL-0V2 & z be positiveXXREAL-0V2"
            then have "x *XXREAL-3K4 (+inftyXXREAL-0K1 *XXREAL-3K4 z) =HIDDENR1 x *XXREAL-3K4 +inftyXXREAL-0K1"
              using xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1"
              using A10 xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1 *XXREAL-3K4 z"
              using A10 xxreal_3_def_5 sorry
            also have "... = (x *XXREAL-3K4 +inftyXXREAL-0K1)*XXREAL-3K4 z"
              using A10 xxreal_3_def_5 sorry
            finally have "x *XXREAL-3K4 (+inftyXXREAL-0K1 *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 +inftyXXREAL-0K1)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A9 sorry
          qed
          have case2: "x be positiveXXREAL-0V2 & z be negativeXXREAL-0V3 implies  not  True "
          proof(rule impI)
            assume A11: "x be positiveXXREAL-0V2 & z be negativeXXREAL-0V3"
            then have "x *XXREAL-3K4 (+inftyXXREAL-0K1 *XXREAL-3K4 z) =HIDDENR1 x *XXREAL-3K4 -inftyXXREAL-0K2"
              using xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2"
              using A11 xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1 *XXREAL-3K4 z"
              using A11 xxreal_3_def_5 sorry
            also have "... = (x *XXREAL-3K4 +inftyXXREAL-0K1)*XXREAL-3K4 z"
              using A11 xxreal_3_def_5 sorry
            finally have "x *XXREAL-3K4 (+inftyXXREAL-0K1 *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 +inftyXXREAL-0K1)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A9 sorry
          qed
          have case3: "x be negativeXXREAL-0V3 & z be positiveXXREAL-0V2 implies  not  True "
          proof(rule impI)
            assume A12: "x be negativeXXREAL-0V3 & z be positiveXXREAL-0V2"
            then have "x *XXREAL-3K4 (+inftyXXREAL-0K1 *XXREAL-3K4 z) =HIDDENR1 x *XXREAL-3K4 +inftyXXREAL-0K1"
              using xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2"
              using A12 xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2 *XXREAL-3K4 z"
              using A12 xxreal_3_def_5 sorry
            also have "... = (x *XXREAL-3K4 +inftyXXREAL-0K1)*XXREAL-3K4 z"
              using A12 xxreal_3_def_5 sorry
            finally have "x *XXREAL-3K4 (+inftyXXREAL-0K1 *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 +inftyXXREAL-0K1)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A9 sorry
          qed
          have case4: "x be negativeXXREAL-0V3 & z be negativeXXREAL-0V3 implies  not  True "
          proof(rule impI)
            assume A13: "x be negativeXXREAL-0V3 & z be negativeXXREAL-0V3"
            then have "x *XXREAL-3K4 (+inftyXXREAL-0K1 *XXREAL-3K4 z) =HIDDENR1 x *XXREAL-3K4 -inftyXXREAL-0K2"
              using xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1"
              using A13 xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2 *XXREAL-3K4 z"
              using A13 xxreal_3_def_5 sorry
            also have "... = (x *XXREAL-3K4 +inftyXXREAL-0K1)*XXREAL-3K4 z"
              using A13 xxreal_3_def_5 sorry
            finally have "x *XXREAL-3K4 (+inftyXXREAL-0K1 *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 +inftyXXREAL-0K1)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A9 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_22:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not x be realXREAL-0V1 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds  not x be realXREAL-0V1 implies ( not x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z implies  not  True )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume " not x be realXREAL-0V1"
    then have A1: " not x inHIDDENR3 REALNUMBERSK2"
       sorry
    assume A2: " not x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
    then have A3: "y <>HIDDENR2 0NUMBERSK6 & z <>HIDDENR2 0NUMBERSK6"
      using xxreal_3_lm_19 xxreal_3_lm_20 sorry
    show " not  True "
    proof-
      have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1"
        using A1 xxreal_0_th_14 sorry
      have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies  not  True "
      proof(rule impI)
        assume A4: "x =HIDDENR1 -inftyXXREAL-0K2"
        show " not  True "
        proof-
          have cases: "((y be positiveXXREAL-0V2 & z be positiveXXREAL-0V2 or y be positiveXXREAL-0V2 & z be negativeXXREAL-0V3) or y be negativeXXREAL-0V3 & z be positiveXXREAL-0V2) or y be negativeXXREAL-0V3 & z be negativeXXREAL-0V3"
            using A3 sorry
          have case1: "y be positiveXXREAL-0V2 & z be positiveXXREAL-0V2 implies  not  True "
          proof(rule impI)
            assume A5: "y be positiveXXREAL-0V2 & z be positiveXXREAL-0V2"
            then have "-inftyXXREAL-0K2 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 -inftyXXREAL-0K2"
              using xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2 *XXREAL-3K4 z"
              using A5 xxreal_3_def_5 sorry
            also have "... = (-inftyXXREAL-0K2 *XXREAL-3K4 y)*XXREAL-3K4 z"
              using A5 xxreal_3_def_5 sorry
            finally have "-inftyXXREAL-0K2 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (-inftyXXREAL-0K2 *XXREAL-3K4 y)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A4 sorry
          qed
          have case2: "y be positiveXXREAL-0V2 & z be negativeXXREAL-0V3 implies  not  True "
          proof(rule impI)
            assume A6: "y be positiveXXREAL-0V2 & z be negativeXXREAL-0V3"
            then have "-inftyXXREAL-0K2 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 +inftyXXREAL-0K1"
              using xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2 *XXREAL-3K4 z"
              using A6 xxreal_3_def_5 sorry
            also have "... = (-inftyXXREAL-0K2 *XXREAL-3K4 y)*XXREAL-3K4 z"
              using A6 xxreal_3_def_5 sorry
            finally have "-inftyXXREAL-0K2 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (-inftyXXREAL-0K2 *XXREAL-3K4 y)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A4 sorry
          qed
          have case3: "y be negativeXXREAL-0V3 & z be positiveXXREAL-0V2 implies  not  True "
          proof(rule impI)
            assume A7: "y be negativeXXREAL-0V3 & z be positiveXXREAL-0V2"
            then have "-inftyXXREAL-0K2 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 +inftyXXREAL-0K1"
              using xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1 *XXREAL-3K4 z"
              using A7 xxreal_3_def_5 sorry
            also have "... = (-inftyXXREAL-0K2 *XXREAL-3K4 y)*XXREAL-3K4 z"
              using A7 xxreal_3_def_5 sorry
            finally have "-inftyXXREAL-0K2 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (-inftyXXREAL-0K2 *XXREAL-3K4 y)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A4 sorry
          qed
          have case4: "y be negativeXXREAL-0V3 & z be negativeXXREAL-0V3 implies  not  True "
          proof(rule impI)
            assume A8: "y be negativeXXREAL-0V3 & z be negativeXXREAL-0V3"
            then have "-inftyXXREAL-0K2 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 -inftyXXREAL-0K2"
              using xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1 *XXREAL-3K4 z"
              using A8 xxreal_3_def_5 sorry
            also have "... = (-inftyXXREAL-0K2 *XXREAL-3K4 y)*XXREAL-3K4 z"
              using A8 xxreal_3_def_5 sorry
            finally have "-inftyXXREAL-0K2 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (-inftyXXREAL-0K2 *XXREAL-3K4 y)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      have case2: "x =HIDDENR1 +inftyXXREAL-0K1 implies  not  True "
      proof(rule impI)
        assume A9: "x =HIDDENR1 +inftyXXREAL-0K1"
        show " not  True "
        proof-
          have cases: "((y be positiveXXREAL-0V2 & z be positiveXXREAL-0V2 or y be positiveXXREAL-0V2 & z be negativeXXREAL-0V3) or y be negativeXXREAL-0V3 & z be positiveXXREAL-0V2) or y be negativeXXREAL-0V3 & z be negativeXXREAL-0V3"
            using A3 sorry
          have case1: "y be positiveXXREAL-0V2 & z be positiveXXREAL-0V2 implies  not  True "
          proof(rule impI)
            assume A10: "y be positiveXXREAL-0V2 & z be positiveXXREAL-0V2"
            then have "+inftyXXREAL-0K1 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 +inftyXXREAL-0K1"
              using xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1 *XXREAL-3K4 z"
              using A10 xxreal_3_def_5 sorry
            also have "... = (+inftyXXREAL-0K1 *XXREAL-3K4 y)*XXREAL-3K4 z"
              using A10 xxreal_3_def_5 sorry
            finally have "+inftyXXREAL-0K1 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (+inftyXXREAL-0K1 *XXREAL-3K4 y)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A9 sorry
          qed
          have case2: "y be positiveXXREAL-0V2 & z be negativeXXREAL-0V3 implies  not  True "
          proof(rule impI)
            assume A11: "y be positiveXXREAL-0V2 & z be negativeXXREAL-0V3"
            then have "+inftyXXREAL-0K1 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 -inftyXXREAL-0K2"
              using xxreal_3_def_5 sorry
            also have "... = +inftyXXREAL-0K1 *XXREAL-3K4 z"
              using A11 xxreal_3_def_5 sorry
            also have "... = (+inftyXXREAL-0K1 *XXREAL-3K4 y)*XXREAL-3K4 z"
              using A11 xxreal_3_def_5 sorry
            finally have "+inftyXXREAL-0K1 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (+inftyXXREAL-0K1 *XXREAL-3K4 y)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A9 sorry
          qed
          have case3: "y be negativeXXREAL-0V3 & z be positiveXXREAL-0V2 implies  not  True "
          proof(rule impI)
            assume A12: "y be negativeXXREAL-0V3 & z be positiveXXREAL-0V2"
            then have "+inftyXXREAL-0K1 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 -inftyXXREAL-0K2"
              using xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2 *XXREAL-3K4 z"
              using A12 xxreal_3_def_5 sorry
            also have "... = (+inftyXXREAL-0K1 *XXREAL-3K4 y)*XXREAL-3K4 z"
              using A12 xxreal_3_def_5 sorry
            finally have "+inftyXXREAL-0K1 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (+inftyXXREAL-0K1 *XXREAL-3K4 y)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A9 sorry
          qed
          have case4: "y be negativeXXREAL-0V3 & z be negativeXXREAL-0V3 implies  not  True "
          proof(rule impI)
            assume A13: "y be negativeXXREAL-0V3 & z be negativeXXREAL-0V3"
            then have "+inftyXXREAL-0K1 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 +inftyXXREAL-0K1"
              using xxreal_3_def_5 sorry
            also have "... = -inftyXXREAL-0K2 *XXREAL-3K4 z"
              using A13 xxreal_3_def_5 sorry
            also have "... = (+inftyXXREAL-0K1 *XXREAL-3K4 y)*XXREAL-3K4 z"
              using A13 xxreal_3_def_5 sorry
            finally have "+inftyXXREAL-0K1 *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (+inftyXXREAL-0K1 *XXREAL-3K4 y)*XXREAL-3K4 z"
               sorry
            thus " not  True "
              using A2 A9 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_66:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    show "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
    proof-
      have cases: "((x be realXREAL-0V1 & y be realXREAL-0V1) & z be realXREAL-0V1 or ( not x be realXREAL-0V1 or  not z be realXREAL-0V1)) or  not y be realXREAL-0V1"
         sorry
      have case1: "(x be realXREAL-0V1 & y be realXREAL-0V1) & z be realXREAL-0V1 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
      proof(rule impI)
        assume "(x be realXREAL-0V1 & y be realXREAL-0V1) & z be realXREAL-0V1"
        then obtain r s t where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = x" and
          [ty]:"s be RealXREAL-0M1" and sDef:"s = y" and
          [ty]:"t be RealXREAL-0M1" and tDef:"t = z"
           sorry
        obtain rs sx where 
          [ty]:"rs be RealXREAL-0M1" and rsDef:"rs = r *XXREAL-3K4 s" and
          [ty]:"sx be RealXREAL-0M1" and sxDef:"sx = s *XXREAL-3K4 t"
           sorry
        have "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 r *XXREAL-3K4 sx"
           sorry
        also have "... = rs *XXREAL-3K4 t"
           sorry
        also have "... = (x *XXREAL-3K4 y)*XXREAL-3K4 z"
           sorry
        finally show "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
           sorry
      qed
      have case2: " not x be realXREAL-0V1 or  not z be realXREAL-0V1 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
      proof(rule impI)
        assume " not x be realXREAL-0V1 or  not z be realXREAL-0V1"
        thus "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
          using xxreal_3_lm_22 sorry
      qed
      have case3: " not y be realXREAL-0V1 implies x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
      proof(rule impI)
        assume " not y be realXREAL-0V1"
        thus "x *XXREAL-3K4 (y *XXREAL-3K4 z) =HIDDENR1 (x *XXREAL-3K4 y)*XXREAL-3K4 z"
          using xxreal_3_lm_21 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_cl_42:
  mlet "r be RealXREAL-0M1"
"cluster r \<inverse>XXREAL-3K5 as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "r \<inverse>XXREAL-3K5 be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_43:
  mlet "r be RealXREAL-0M1", "s be RealXREAL-0M1"
"cluster r *XXREAL-3K4 s as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "r *XXREAL-3K4 s be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_44:
  mlet "r be RealXREAL-0M1", "s be RealXREAL-0M1"
"cluster r /XXREAL-3K6 s as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "r /XXREAL-3K6 s be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_45:
"cluster -inftyXXREAL-0K2 \<inverse>XXREAL-3K5 as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show "-inftyXXREAL-0K2 \<inverse>XXREAL-3K5 be zeroORDINAL1V8"
    using xxreal_3_def_6 sorry
qed "sorry"

mtheorem xxreal_3_cl_46:
"cluster +inftyXXREAL-0K1 \<inverse>XXREAL-3K5 as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show "+inftyXXREAL-0K1 \<inverse>XXREAL-3K5 be zeroORDINAL1V8"
    using xxreal_3_def_6 sorry
qed "sorry"

mtheorem xxreal_3_th_67:
" for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
proof-
  have " for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be ExtRealXXREAL-0M1"
    fix g assume [ty]: "g be ExtRealXXREAL-0M1"
    show "(f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
    proof-
      have cases: "(((f inHIDDENR3 REALNUMBERSK2 & g inHIDDENR3 REALNUMBERSK2 or f =HIDDENR1 +inftyXXREAL-0K1) or f =HIDDENR1 -inftyXXREAL-0K2) or g =HIDDENR1 +inftyXXREAL-0K1) or g =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_0_th_14 sorry
      have case1: "f inHIDDENR3 REALNUMBERSK2 & g inHIDDENR3 REALNUMBERSK2 implies (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
      proof(rule impI)
        assume "f inHIDDENR3 REALNUMBERSK2 & g inHIDDENR3 REALNUMBERSK2"
        then obtain f1 g1 where 
          [ty]:"f1 be RealXREAL-0M1" and f1Def:"f1 = f" and
          [ty]:"g1 be RealXREAL-0M1" and g1Def:"g1 = g"
           sorry
        have A1: "( ex a be ComplexXCMPLX-0M1 st f1 =HIDDENR1 a & f \<inverse>XXREAL-3K5 =HIDDENR1 a \<inverse>XCMPLX-0K5) & ( ex b be ComplexXCMPLX-0M1 st g1 =HIDDENR1 b & g \<inverse>XXREAL-3K5 =HIDDENR1 b \<inverse>XCMPLX-0K5)"
          using xxreal_3_def_6 sorry
        then have " ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (f \<inverse>XXREAL-3K5 =HIDDENR1 a & g \<inverse>XXREAL-3K5 =HIDDENR1 b) & f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5 =HIDDENR1 a *XCMPLX-0K3 b"
          using xxreal_3_def_5 sorry
        then have "f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5 =HIDDENR1 (f1 *XXREAL-3K4 g1)\<inverse>XXREAL-3K5"
          using A1 xcmplx_1_th_204 sorry
        thus "(f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
           sorry
      qed
      have case2: "f =HIDDENR1 +inftyXXREAL-0K1 implies (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
      proof(rule impI)
        assume A2: "f =HIDDENR1 +inftyXXREAL-0K1"
        have "(g be positiveXXREAL-0V2 or g be negativeXXREAL-0V3) or g =HIDDENR1 0NUMBERSK6"
           sorry
        then have "((f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 +inftyXXREAL-0K1 \<inverse>XXREAL-3K5 or (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 -inftyXXREAL-0K2 \<inverse>XXREAL-3K5) or (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 (0NUMBERSK6)\<inverse>XXREAL-3K5"
          using A2 xxreal_3_def_5 sorry
        thus "(f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
          using A2 sorry
      qed
      have case3: "f =HIDDENR1 -inftyXXREAL-0K2 implies (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
      proof(rule impI)
        assume A3: "f =HIDDENR1 -inftyXXREAL-0K2"
        have "(g be positiveXXREAL-0V2 or g be negativeXXREAL-0V3) or g =HIDDENR1 0NUMBERSK6"
           sorry
        then have "((f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 +inftyXXREAL-0K1 \<inverse>XXREAL-3K5 or (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 -inftyXXREAL-0K2 \<inverse>XXREAL-3K5) or (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 (0NUMBERSK6)\<inverse>XXREAL-3K5"
          using A3 xxreal_3_def_5 sorry
        thus "(f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
          using A3 sorry
      qed
      have case4: "g =HIDDENR1 +inftyXXREAL-0K1 implies (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
      proof(rule impI)
        assume A4: "g =HIDDENR1 +inftyXXREAL-0K1"
        have "(f be positiveXXREAL-0V2 or f be negativeXXREAL-0V3) or f =HIDDENR1 0NUMBERSK6"
           sorry
        then have "((f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 +inftyXXREAL-0K1 \<inverse>XXREAL-3K5 or (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 -inftyXXREAL-0K2 \<inverse>XXREAL-3K5) or (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 (0NUMBERSK6)\<inverse>XXREAL-3K5"
          using A4 xxreal_3_def_5 sorry
        thus "(f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
          using A4 sorry
      qed
      have case5: "g =HIDDENR1 -inftyXXREAL-0K2 implies (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
      proof(rule impI)
        assume A5: "g =HIDDENR1 -inftyXXREAL-0K2"
        have "(f be positiveXXREAL-0V2 or f be negativeXXREAL-0V3) or f =HIDDENR1 0NUMBERSK6"
           sorry
        then have "((f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 +inftyXXREAL-0K1 \<inverse>XXREAL-3K5 or (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 -inftyXXREAL-0K2 \<inverse>XXREAL-3K5) or (f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 (0NUMBERSK6)\<inverse>XXREAL-3K5"
          using A5 xxreal_3_def_5 sorry
        thus "(f *XXREAL-3K4 g)\<inverse>XXREAL-3K5 =HIDDENR1 f \<inverse>XXREAL-3K5 *XXREAL-3K4 g \<inverse>XXREAL-3K5"
          using A5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_68:
" for r be RealXREAL-0M1 holds  for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 & r *XXREAL-3K4 f =HIDDENR1 r *XXREAL-3K4 g implies f =HIDDENR1 g"
proof-
  have " for r be RealXREAL-0M1 holds  for f be ExtRealXXREAL-0M1 holds  for g be ExtRealXXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 & r *XXREAL-3K4 f =HIDDENR1 r *XXREAL-3K4 g implies f =HIDDENR1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be ExtRealXXREAL-0M1"
    fix g assume [ty]: "g be ExtRealXXREAL-0M1"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
      and A2: "r *XXREAL-3K4 f =HIDDENR1 r *XXREAL-3K4 g"
    have A3: "r be positiveXXREAL-0V2 or r be negativeXXREAL-0V3"
      using A1 sorry
    show "f =HIDDENR1 g"
    proof-
      have cases: "(f inHIDDENR3 REALNUMBERSK2 or f =HIDDENR1 +inftyXXREAL-0K1) or f =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_0_th_14 sorry
      have case1: "f inHIDDENR3 REALNUMBERSK2 implies f =HIDDENR1 g"
      proof(rule impI)
        assume A4: "f inHIDDENR3 REALNUMBERSK2"
        have " not g inHIDDENR3 REALNUMBERSK2 implies  False "
        proof(rule impI)
          assume " not g inHIDDENR3 REALNUMBERSK2"
          then have "g =HIDDENR1 +inftyXXREAL-0K1 or g =HIDDENR1 -inftyXXREAL-0K2"
            using xxreal_0_th_14 sorry
          thus " False "
            using A2 A3 A4 xxreal_3_def_5 sorry
        qed
        then have A5: " ex c be ComplexXCMPLX-0M1 st  ex d be ComplexXCMPLX-0M1 st (r =HIDDENR1 c & g =HIDDENR1 d) & r *XXREAL-3K4 g =HIDDENR1 c *XCMPLX-0K3 d"
          using xxreal_3_def_5 sorry
        have " ex a be ComplexXCMPLX-0M1 st  ex b be ComplexXCMPLX-0M1 st (r =HIDDENR1 a & f =HIDDENR1 b) & r *XXREAL-3K4 f =HIDDENR1 a *XCMPLX-0K3 b"
          using A4 xxreal_3_def_5 sorry
        thus "f =HIDDENR1 g"
          using A1 A2 A5 xcmplx_1_th_5 sorry
      qed
      have case2: "f =HIDDENR1 +inftyXXREAL-0K1 implies (f <>HIDDENR2 g implies  not  True )"
      proof(rule impI,rule impI)
        assume A6: "f =HIDDENR1 +inftyXXREAL-0K1"
        assume "f <>HIDDENR2 g"
        then have "g inHIDDENR3 REALNUMBERSK2 or g =HIDDENR1 -inftyXXREAL-0K2"
          using A6 xxreal_0_th_14 sorry
        thus " not  True "
          using A2 A3 A6 xxreal_3_def_5 sorry
      qed
      have case3: "f =HIDDENR1 -inftyXXREAL-0K2 implies (f <>HIDDENR2 g implies  not  True )"
      proof(rule impI,rule impI)
        assume A7: "f =HIDDENR1 -inftyXXREAL-0K2"
        assume "f <>HIDDENR2 g"
        then have "g inHIDDENR3 REALNUMBERSK2 or g =HIDDENR1 +inftyXXREAL-0K1"
          using A7 xxreal_0_th_14 sorry
        thus " not  True "
          using A2 A3 A7 xxreal_3_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_69:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) & x *XXREAL-3K4 y =HIDDENR1 +inftyXXREAL-0K1 implies y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) & x *XXREAL-3K4 y =HIDDENR1 +inftyXXREAL-0K1 implies (y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
      and A2: "x *XXREAL-3K4 y =HIDDENR1 +inftyXXREAL-0K1"
    assume "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
    then have A3: "y inHIDDENR3 REALNUMBERSK2"
      using xxreal_0_th_14 sorry
    have "x inHIDDENR3 REALNUMBERSK2"
      using A1 xxreal_0_th_14 sorry
    then obtain a b where 
      [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
      [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
      using A3 sorry
    have "x *XXREAL-3K4 y =HIDDENR1 a *XXREAL-3K4 b"
       sorry
    thus " False "
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_70:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) & x *XXREAL-3K4 y =HIDDENR1 -inftyXXREAL-0K2 implies y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) & x *XXREAL-3K4 y =HIDDENR1 -inftyXXREAL-0K2 implies (y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
      and A2: "x *XXREAL-3K4 y =HIDDENR1 -inftyXXREAL-0K2"
    assume "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
    then have A3: "y inHIDDENR3 REALNUMBERSK2"
      using xxreal_0_th_14 sorry
    have "x inHIDDENR3 REALNUMBERSK2"
      using A1 xxreal_0_th_14 sorry
    then obtain a b where 
      [ty]:"a be RealXREAL-0M1" and aDef:"a = x" and
      [ty]:"b be RealXREAL-0M1" and bDef:"b = y"
      using A3 sorry
    have "x *XXREAL-3K4 y =HIDDENR1 a *XXREAL-3K4 b"
       sorry
    thus " False "
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_23:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 y inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or x *XXREAL-3K4 y =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 y inHIDDENR3 REALNUMBERSK2 implies ( not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2 implies (x *XXREAL-3K4 y <>HIDDENR2 0NUMBERSK6 implies  False ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x *XXREAL-3K4 y inHIDDENR3 REALNUMBERSK2"
    assume " not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2"
    then have A2: " not x be realXREAL-0V1 or  not y be realXREAL-0V1"
      using xreal_0_def_1 sorry
    assume A3: "x *XXREAL-3K4 y <>HIDDENR2 0NUMBERSK6"
    show " False "
    proof-
      have cases: "(x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3) or (x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2)"
        using A3 sorry
      have case1: "x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3 implies  False "
      proof(rule impI)
        assume "x be positiveXXREAL-0V2 & y be positiveXXREAL-0V2 or x be negativeXXREAL-0V3 & y be negativeXXREAL-0V3"
        thus " False "
          using A1 A2 xxreal_3_def_5 sorry
      qed
      have case2: "x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2 implies  False "
      proof(rule impI)
        assume "x be positiveXXREAL-0V2 & y be negativeXXREAL-0V3 or x be negativeXXREAL-0V3 & y be positiveXXREAL-0V2"
        thus " False "
          using A1 A2 xxreal_3_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_71:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & 0NUMBERSK6 <=XXREAL-3R1 z implies x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & 0NUMBERSK6 <=XXREAL-3R1 z implies x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-3R1 y"
      and A2: "0NUMBERSK6 <=XXREAL-3R1 z"
    show "x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
    proof-
      have cases: "z =HIDDENR1 0NUMBERSK6 or z >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      have case1: "z =HIDDENR1 0NUMBERSK6 implies x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
      proof(rule impI)
        assume "z =HIDDENR1 0NUMBERSK6"
        thus "x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
           sorry
      qed
      have case2: "z >XXREAL-0R4 0NUMBERSK6 implies x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
      proof(rule impI)
        assume A3: "z >XXREAL-0R4 0NUMBERSK6"
        show "x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
        proof-
          have cases: "x =HIDDENR1 0NUMBERSK6 or x <>HIDDENR2 0NUMBERSK6"
             sorry
          have case1: "x =HIDDENR1 0NUMBERSK6 implies x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
          proof(rule impI)
            assume A4: "x =HIDDENR1 0NUMBERSK6"
            then have "z *XXREAL-3K4 y >=XXREAL-0R2 0NUMBERSK6"
              using A1 A2 sorry
            thus "x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
              using A4 sorry
          qed
          have case2: "x <>HIDDENR2 0NUMBERSK6 implies (x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 & y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2) & ( ex tVar21 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar22 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar21 =HIDDENR1 x *XXREAL-3K4 z & tVar22 =HIDDENR1 y *XXREAL-3K4 z) & tVar21 <=XXREAL-0R1 tVar22) or ( not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or  not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2) & ( not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or  not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1))"
          proof(rule impI)
            assume A5: "x <>HIDDENR2 0NUMBERSK6"
            show "(x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 & y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2) & ( ex tVar21 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar22 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar21 =HIDDENR1 x *XXREAL-3K4 z & tVar22 =HIDDENR1 y *XXREAL-3K4 z) & tVar21 <=XXREAL-0R1 tVar22) or ( not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or  not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2) & ( not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or  not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1))"
            proof-
              have cases: "x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 & y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or ( not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or  not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2)"
                 sorry
              have case1: "x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 & y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 implies ( ex tVar21 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar22 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar21 =HIDDENR1 x *XXREAL-3K4 z & tVar22 =HIDDENR1 y *XXREAL-3K4 z) & tVar21 <=XXREAL-0R1 tVar22)"
              proof(rule impI)
                assume A6: "x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 & y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2"
                have "y *XXREAL-3K4 z =HIDDENR1 0NUMBERSK6 implies y =HIDDENR1 0NUMBERSK6"
                  using A3 sorry
                then have 
                  [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" and
                  [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and
                  [ty]:"z be ElementSUBSET-1M1-of REALNUMBERSK2"
                  using A3 A5 A6 xxreal_3_lm_23 sorry
                obtain p q where 
                  [ty]:"p be ElementSUBSET-1M1-of REALNUMBERSK2" and pDef:"p = x *XXREAL-3K4 z" and
                  [ty]:"q be ElementSUBSET-1M1-of REALNUMBERSK2" and qDef:"q = y *XXREAL-3K4 z"
                  using xreal_0_def_1 sorry
                show " ex tVar21 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar22 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar21 =HIDDENR1 x *XXREAL-3K4 z & tVar22 =HIDDENR1 y *XXREAL-3K4 z) & tVar21 <=XXREAL-0R1 tVar22"
                proof(rule bexI[of _ "p"])
                  show " ex tVar22 be ElementSUBSET-1M1-of REALNUMBERSK2 st (p =HIDDENR1 x *XXREAL-3K4 z & tVar22 =HIDDENR1 y *XXREAL-3K4 z) & p <=XXREAL-0R1 tVar22"
                  proof(rule bexI[of _ "q"])
                    show "(p =HIDDENR1 x *XXREAL-3K4 z & q =HIDDENR1 y *XXREAL-3K4 z) & p <=XXREAL-0R1 q"
                      using A1 A2 xreal_1_th_64 sorry
                  qed "sorry"
                qed "sorry"
              qed
              have case2: " not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or  not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
              proof(rule impI)
                assume A7: " not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or  not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2"
                show " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                proof-
                  have cases: " not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 or  not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2"
                    using A7 sorry
                  have case1: " not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                  proof(rule impI)
                    assume A8: " not x *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2"
                    show " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                    proof-
                      have cases: "x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 or x *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1"
                        using A8 xxreal_0_th_14 sorry
                      have case1: "x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                      proof(rule impI)
                        assume "x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2"
                        thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                           sorry
                      qed
                      have case2: "x *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                      proof(rule impI)
                        assume "x *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1"
                        then have A9: "x <>HIDDENR2 -inftyXXREAL-0K2"
                          using A3 sorry
                        have A10: "( not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2) or  not z inHIDDENR3 REALNUMBERSK2"
                          using A8 xreal_0_def_1 sorry
                        show " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                        proof-
                          have cases: "((y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 -inftyXXREAL-0K2) or  not z inHIDDENR3 REALNUMBERSK2 & (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2)"
                            using A9 A10 xxreal_0_th_14 sorry
                          have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          proof(rule impI)
                            assume "y =HIDDENR1 +inftyXXREAL-0K1"
                            thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                              using A3 xxreal_3_def_5 sorry
                          qed
                          have case2: "x =HIDDENR1 +inftyXXREAL-0K1 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          proof(rule impI)
                            assume "x =HIDDENR1 +inftyXXREAL-0K1"
                            then have "y =HIDDENR1 +inftyXXREAL-0K1"
                              using A1 xxreal_0_th_4 sorry
                            thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                              using A3 xxreal_3_def_5 sorry
                          qed
                          have case3: "y =HIDDENR1 -inftyXXREAL-0K2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          proof(rule impI)
                            assume "y =HIDDENR1 -inftyXXREAL-0K2"
                            then have "x =HIDDENR1 -inftyXXREAL-0K2"
                              using A1 xxreal_0_th_6 sorry
                            thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                              using A3 xxreal_3_def_5 sorry
                          qed
                          have case4: " not z inHIDDENR3 REALNUMBERSK2 & (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          proof(rule impMI ,rule impI)
                            assume A11: " not z inHIDDENR3 REALNUMBERSK2"
                              and "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
                            have A12: "z =HIDDENR1 +inftyXXREAL-0K1"
                              using A3 A11 xxreal_0_th_14 sorry
                            show " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                            proof-
                              have cases: "x <XXREAL-0R3 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 x"
                                using A5 sorry
                              have case1: "x <XXREAL-0R3 0NUMBERSK6 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                              proof(rule impI)
                                assume "x <XXREAL-0R3 0NUMBERSK6"
                                thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                                  using A12 xxreal_3_def_5 sorry
                              qed
                              have case2: "0NUMBERSK6 <XXREAL-0R3 x implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                              proof(rule impI)
                                assume "0NUMBERSK6 <XXREAL-0R3 x"
                                then have "0NUMBERSK6 <XXREAL-0R3 y"
                                  using A1 sorry
                                thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                                  using A12 xxreal_3_def_5 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          show " ?thesis "
                            using cases case1 case2 case3 case4 sorry
                        qed
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  have case2: " not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                  proof(rule impI)
                    assume " not y *XXREAL-3K4 z inHIDDENR3 REALNUMBERSK2"
                    then have A13: "( not x inHIDDENR3 REALNUMBERSK2 or  not y inHIDDENR3 REALNUMBERSK2) or  not z inHIDDENR3 REALNUMBERSK2"
                      using xreal_0_def_1 sorry
                    show " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                    proof-
                      have cases: "(((x =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 -inftyXXREAL-0K2) or  not z inHIDDENR3 REALNUMBERSK2 & (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2)"
                        using A13 xxreal_0_th_14 sorry
                      have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                      proof(rule impI)
                        assume "x =HIDDENR1 -inftyXXREAL-0K2"
                        thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          using A3 xxreal_3_def_5 sorry
                      qed
                      have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                      proof(rule impI)
                        assume "y =HIDDENR1 +inftyXXREAL-0K1"
                        thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          using A3 xxreal_3_def_5 sorry
                      qed
                      have case3: "x =HIDDENR1 +inftyXXREAL-0K1 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                      proof(rule impI)
                        assume "x =HIDDENR1 +inftyXXREAL-0K1"
                        then have "y =HIDDENR1 +inftyXXREAL-0K1"
                          using A1 xxreal_0_th_4 sorry
                        thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          using A3 xxreal_3_def_5 sorry
                      qed
                      have case4: "y =HIDDENR1 -inftyXXREAL-0K2 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                      proof(rule impI)
                        assume "y =HIDDENR1 -inftyXXREAL-0K2"
                        then have "x =HIDDENR1 -inftyXXREAL-0K2"
                          using A1 xxreal_0_th_6 sorry
                        thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          using A3 xxreal_3_def_5 sorry
                      qed
                      have case5: " not z inHIDDENR3 REALNUMBERSK2 & (x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2) implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                      proof(rule impMI ,rule impI)
                        assume A14: " not z inHIDDENR3 REALNUMBERSK2"
                          and "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
                        have A15: "z =HIDDENR1 +inftyXXREAL-0K1"
                          using A3 A14 xxreal_0_th_14 sorry
                        show " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                        proof-
                          have cases: "x <XXREAL-0R3 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 x"
                            using A5 sorry
                          have case1: "x <XXREAL-0R3 0NUMBERSK6 implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          proof(rule impI)
                            assume "x <XXREAL-0R3 0NUMBERSK6"
                            thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                              using A15 xxreal_3_def_5 sorry
                          qed
                          have case2: "0NUMBERSK6 <XXREAL-0R3 x implies  not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                          proof(rule impI)
                            assume "0NUMBERSK6 <XXREAL-0R3 x"
                            then have "0NUMBERSK6 <XXREAL-0R3 y"
                              using A1 sorry
                            thus " not ( not x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2 &  not y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1)"
                              using A15 xxreal_3_def_5 sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      show " ?thesis "
                        using cases case1 case2 case3 case4 case5 sorry
                    qed
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_72:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (x <XXREAL-0R3 y & 0NUMBERSK6 <XXREAL-0R3 z) & z <>HIDDENR2 +inftyXXREAL-0K1 implies x *XXREAL-3K4 z <XXREAL-0R3 y *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y & (0NUMBERSK6 <XXREAL-0R3 z & z <>HIDDENR2 +inftyXXREAL-0K1) implies  not x *XXREAL-3K4 z <XXREAL-0R3 y *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
      and A2: "0NUMBERSK6 <XXREAL-0R3 z"
      and A3: "z <>HIDDENR2 +inftyXXREAL-0K1"
    have A4: "x *XXREAL-3K4 z =HIDDENR1 y *XXREAL-3K4 z implies  False "
    proof(rule impI)
      have A5: "x <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
        using A1 xxreal_0_th_3 xxreal_0_th_5 sorry
      assume A6: "x *XXREAL-3K4 z =HIDDENR1 y *XXREAL-3K4 z"
      show " False "
      proof-
        have cases: "(x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 -inftyXXREAL-0K2"
          using A5 xxreal_0_th_14 sorry
        have case1: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 implies  False "
        proof(rule impI)
          assume A7: "x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2"
          have "z inHIDDENR3 REALNUMBERSK2"
            using A2 A3 xxreal_0_th_14 sorry
          then have 
            [ty]:"x be RealXREAL-0M1" and
            [ty]:"y be RealXREAL-0M1" and
            [ty]:"z be RealXREAL-0M1"
            using A7 sorry
          have "x *XXREAL-3K4 z <XXREAL-0R3 y *XXREAL-3K4 z"
            using A1 A2 xreal_1_th_68 sorry
          thus " False "
            using A6 sorry
        qed
        have case2: "y =HIDDENR1 +inftyXXREAL-0K1 implies  False "
        proof(rule impI)
          assume A8: "y =HIDDENR1 +inftyXXREAL-0K1"
          then have "y *XXREAL-3K4 z =HIDDENR1 +inftyXXREAL-0K1"
            using A2 xxreal_3_def_5 sorry
          then have "x =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2"
            using A2 A3 A6 xxreal_3_th_69 sorry
          thus " False "
            using A1 A2 A6 A8 sorry
        qed
        have case3: "x =HIDDENR1 -inftyXXREAL-0K2 implies  False "
        proof(rule impI)
          assume A9: "x =HIDDENR1 -inftyXXREAL-0K2"
          then have "x *XXREAL-3K4 z =HIDDENR1 -inftyXXREAL-0K2"
            using A2 xxreal_3_def_5 sorry
          then have "y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2"
            using A2 A3 A6 xxreal_3_th_70 sorry
          thus " False "
            using A1 A2 A6 A9 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    have "x *XXREAL-3K4 z <=XXREAL-3R1 y *XXREAL-3K4 z"
      using A1 A2 xxreal_3_th_71 sorry
    thus " not x *XXREAL-3K4 z <XXREAL-0R3 y *XXREAL-3K4 z"
      using A4 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_73:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 y inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 REALNUMBERSK2 & y inHIDDENR3 REALNUMBERSK2 or x *XXREAL-3K4 y =HIDDENR1 0NUMBERSK6"
  using xxreal_3_lm_23 sorry

mtheorem xxreal_3_th_74:
"+inftyXXREAL-0K1 \<inverse>XXREAL-3K5 =HIDDENR1 0NUMBERSK6"
   sorry

mtheorem xxreal_3_th_75:
"-inftyXXREAL-0K2 \<inverse>XXREAL-3K5 =HIDDENR1 0NUMBERSK6"
   sorry

mtheorem xxreal_3_th_76:
" for x be ExtRealXXREAL-0M1 holds x /XXREAL-3K6 +inftyXXREAL-0K1 =HIDDENR1 0NUMBERSK6"
   sorry

mtheorem xxreal_3_th_77:
" for x be ExtRealXXREAL-0M1 holds x /XXREAL-3K6 -inftyXXREAL-0K2 =HIDDENR1 0NUMBERSK6"
   sorry

mtheorem xxreal_3_th_78:
" for x be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1) & x <>HIDDENR2 0NUMBERSK6 implies x /XXREAL-3K6 x =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x <>HIDDENR2 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1 implies (x <>HIDDENR2 0NUMBERSK6 implies x /XXREAL-3K6 x =HIDDENR1 \<one>\<^sub>M)"
  proof(rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x <>HIDDENR2 -inftyXXREAL-0K2 & x <>HIDDENR2 +inftyXXREAL-0K1"
    then have "x inHIDDENR3 REALNUMBERSK2"
      using xxreal_0_th_14 sorry
    then obtain a where 
      [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
       sorry
    assume "x <>HIDDENR2 0NUMBERSK6"
    then have "a /XXREAL-3K6 a =HIDDENR1 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    thus "x /XXREAL-3K6 x =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_79:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & 0NUMBERSK6 <XXREAL-0R3 z implies x /XXREAL-3K6 z <=XXREAL-3R1 y /XXREAL-3K6 z"
  using xxreal_3_th_71 sorry

mtheorem xxreal_3_th_80:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (x <XXREAL-0R3 y & 0NUMBERSK6 <XXREAL-0R3 z) & z <>HIDDENR2 +inftyXXREAL-0K1 implies x /XXREAL-3K6 z <XXREAL-0R3 y /XXREAL-3K6 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y & (0NUMBERSK6 <XXREAL-0R3 z & z <>HIDDENR2 +inftyXXREAL-0K1) implies  not x /XXREAL-3K6 z <XXREAL-0R3 y /XXREAL-3K6 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
      and A2: "0NUMBERSK6 <XXREAL-0R3 z"
      and A3: "z <>HIDDENR2 +inftyXXREAL-0K1"
    show " not x /XXREAL-3K6 z <XXREAL-0R3 y /XXREAL-3K6 z"
    proof-
      have cases: "z =HIDDENR1 -inftyXXREAL-0K2 or z inHIDDENR3 REALNUMBERSK2"
        using A3 xxreal_0_th_14 sorry
      have case1: "z =HIDDENR1 -inftyXXREAL-0K2 implies  not x /XXREAL-3K6 z <XXREAL-0R3 y /XXREAL-3K6 z"
      proof(rule impI)
        assume "z =HIDDENR1 -inftyXXREAL-0K2"
        thus " not x /XXREAL-3K6 z <XXREAL-0R3 y /XXREAL-3K6 z"
          using A2 sorry
      qed
      have case2: "z inHIDDENR3 REALNUMBERSK2 implies  not x /XXREAL-3K6 z <XXREAL-0R3 y /XXREAL-3K6 z"
      proof(rule impI)
        assume "z inHIDDENR3 REALNUMBERSK2"
        then have 
          [ty]:"z be RealXREAL-0M1"
           sorry
        have "z \<inverse>XXREAL-3K5 >XXREAL-0R4 0NUMBERSK6"
          using A2 sorry
        thus " not x /XXREAL-3K6 z <XXREAL-0R3 y /XXREAL-3K6 z"
          using A1 xxreal_3_th_72 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_81:
" for x be ExtRealXXREAL-0M1 holds \<one>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds \<one>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "\<one>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x"
    proof-
      have cases: "x inHIDDENR3 REALNUMBERSK2 or (x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1)"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 implies \<one>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2"
        then obtain y where 
          [ty]:"x be RealXREAL-0M1" and
          [ty]:"y be RealXREAL-0M1" and yDef:"y = \<one>\<^sub>M"
           sorry
        have "y *XXREAL-3K4 x =HIDDENR1 x"
           sorry
        thus "\<one>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x"
           sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1 implies \<one>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x"
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1"
        thus "\<one>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x"
          using xxreal_3_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_82:
" for y be ExtRealXXREAL-0M1 holds y \<inverse>XXREAL-3K5 =HIDDENR1 0NUMBERSK6 implies (y =HIDDENR1 +inftyXXREAL-0K1 or y =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 0NUMBERSK6"
proof-
  have " for y be ExtRealXXREAL-0M1 holds y \<inverse>XXREAL-3K5 =HIDDENR1 0NUMBERSK6 implies (y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2 implies y =HIDDENR1 0NUMBERSK6)"
  proof(rule ballI,rule impI,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "y \<inverse>XXREAL-3K5 =HIDDENR1 0NUMBERSK6"
    assume "y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 -inftyXXREAL-0K2"
    then have "y inHIDDENR3 REALNUMBERSK2"
      using xxreal_0_th_14 sorry
    then have 
      [ty]:"y be RealXREAL-0M1"
       sorry
    have "(y \<inverse>XXREAL-3K5)\<inverse>XXREAL-3K5 =HIDDENR1 0NUMBERSK6"
      using A1 sorry
    thus "y =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_83:
" for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 y & y <>HIDDENR2 +inftyXXREAL-0K1 implies +inftyXXREAL-0K1 /XXREAL-3K6 y =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have " for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 y & y <>HIDDENR2 +inftyXXREAL-0K1 implies +inftyXXREAL-0K1 /XXREAL-3K6 y =HIDDENR1 +inftyXXREAL-0K1"
  proof(rule ballI,rule impMI ,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 y"
      and A2: "y <>HIDDENR2 +inftyXXREAL-0K1"
    have "y \<inverse>XXREAL-3K5 <>HIDDENR2 0NUMBERSK6"
      using A1 A2 xxreal_3_th_82 sorry
    thus "+inftyXXREAL-0K1 /XXREAL-3K6 y =HIDDENR1 +inftyXXREAL-0K1"
      using A1 xxreal_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_84:
" for y be ExtRealXXREAL-0M1 holds y <XXREAL-0R3 0NUMBERSK6 & -inftyXXREAL-0K2 <>HIDDENR2 y implies -inftyXXREAL-0K2 /XXREAL-3K6 y =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have " for y be ExtRealXXREAL-0M1 holds y <XXREAL-0R3 0NUMBERSK6 & -inftyXXREAL-0K2 <>HIDDENR2 y implies -inftyXXREAL-0K2 /XXREAL-3K6 y =HIDDENR1 +inftyXXREAL-0K1"
  proof(rule ballI,rule impMI ,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "y <XXREAL-0R3 0NUMBERSK6"
      and A2: "-inftyXXREAL-0K2 <>HIDDENR2 y"
    have "y \<inverse>XXREAL-3K5 <>HIDDENR2 0NUMBERSK6"
      using A1 A2 xxreal_3_th_82 sorry
    thus "-inftyXXREAL-0K2 /XXREAL-3K6 y =HIDDENR1 +inftyXXREAL-0K1"
      using A1 xxreal_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_85:
" for y be ExtRealXXREAL-0M1 holds y <XXREAL-0R3 0NUMBERSK6 & -inftyXXREAL-0K2 <>HIDDENR2 y implies +inftyXXREAL-0K1 /XXREAL-3K6 y =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for y be ExtRealXXREAL-0M1 holds y <XXREAL-0R3 0NUMBERSK6 & -inftyXXREAL-0K2 <>HIDDENR2 y implies +inftyXXREAL-0K1 /XXREAL-3K6 y =HIDDENR1 -inftyXXREAL-0K2"
  proof(rule ballI,rule impMI ,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "y <XXREAL-0R3 0NUMBERSK6"
      and A2: "-inftyXXREAL-0K2 <>HIDDENR2 y"
    have "y \<inverse>XXREAL-3K5 <>HIDDENR2 0NUMBERSK6"
      using A1 A2 xxreal_3_th_82 sorry
    thus "+inftyXXREAL-0K1 /XXREAL-3K6 y =HIDDENR1 -inftyXXREAL-0K2"
      using A1 xxreal_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_86:
" for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 y & y <>HIDDENR2 +inftyXXREAL-0K1 implies -inftyXXREAL-0K2 /XXREAL-3K6 y =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have " for y be ExtRealXXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 y & y <>HIDDENR2 +inftyXXREAL-0K1 implies -inftyXXREAL-0K2 /XXREAL-3K6 y =HIDDENR1 -inftyXXREAL-0K2"
  proof(rule ballI,rule impMI ,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 y"
      and A2: "y <>HIDDENR2 +inftyXXREAL-0K1"
    have "y \<inverse>XXREAL-3K5 <>HIDDENR2 0NUMBERSK6"
      using A1 A2 xxreal_3_th_82 sorry
    thus "-inftyXXREAL-0K2 /XXREAL-3K6 y =HIDDENR1 -inftyXXREAL-0K2"
      using A1 xxreal_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_87:
" for x be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) & x <>HIDDENR2 0NUMBERSK6 implies x *XXREAL-3K4 (\<one>\<^sub>M /XXREAL-3K6 x) =HIDDENR1 \<one>\<^sub>M & (\<one>\<^sub>M /XXREAL-3K6 x)*XXREAL-3K4 x =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for x be ExtRealXXREAL-0M1 holds (x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2) & x <>HIDDENR2 0NUMBERSK6 implies x *XXREAL-3K4 (\<one>\<^sub>M /XXREAL-3K6 x) =HIDDENR1 \<one>\<^sub>M & (\<one>\<^sub>M /XXREAL-3K6 x)*XXREAL-3K4 x =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume A1: "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
      and A2: "x <>HIDDENR2 0NUMBERSK6"
    have "x inHIDDENR3 REALNUMBERSK2"
      using A1 xxreal_0_th_14 sorry
    then obtain a where 
      [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
       sorry
    have "x *XXREAL-3K4 (\<one>\<^sub>M /XXREAL-3K6 x) =HIDDENR1 a *XXREAL-3K4 (\<one>\<^sub>M /XXREAL-3K6 a)"
       sorry
    also have "... = \<one>\<^sub>M"
      using A2 xcmplx_1_th_106 sorry
    finally have "x *XXREAL-3K4 (\<one>\<^sub>M /XXREAL-3K6 x) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "x *XXREAL-3K4 (\<one>\<^sub>M /XXREAL-3K6 x) =HIDDENR1 \<one>\<^sub>M & (\<one>\<^sub>M /XXREAL-3K6 x)*XXREAL-3K4 x =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_88:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (-inftyXXREAL-0K2 <>HIDDENR2 y & y <>HIDDENR2 +inftyXXREAL-0K1) & y <>HIDDENR2 0NUMBERSK6 implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x & x *XXREAL-3K4 (y /XXREAL-3K6 y) =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -inftyXXREAL-0K2 <>HIDDENR2 y & (y <>HIDDENR2 +inftyXXREAL-0K1 & y <>HIDDENR2 0NUMBERSK6) implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x & x *XXREAL-3K4 (y /XXREAL-3K6 y) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "-inftyXXREAL-0K2 <>HIDDENR2 y"
      and A2: "y <>HIDDENR2 +inftyXXREAL-0K1"
      and A3: "y <>HIDDENR2 0NUMBERSK6"
    obtain b where 
      [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = y"
      using A1 A2 xxreal_0_th_14 sorry
    have A4: "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
    proof-
      show "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
      proof-
        have cases: "(x =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 -inftyXXREAL-0K2) or x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
           sorry
        have case1: "x =HIDDENR1 +inftyXXREAL-0K1 implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
        proof(rule impI)
          assume A5: "x =HIDDENR1 +inftyXXREAL-0K1"
          show "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
          proof-
            have cases: "0NUMBERSK6 <XXREAL-0R3 y or y <XXREAL-0R3 0NUMBERSK6"
              using A3 sorry
            have case1: "0NUMBERSK6 <XXREAL-0R3 y implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
            proof(rule impI)
              assume A6: "0NUMBERSK6 <XXREAL-0R3 y"
              then have "x *XXREAL-3K4 y =HIDDENR1 +inftyXXREAL-0K1"
                using A5 xxreal_3_def_5 sorry
              thus "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
                using A2 A5 A6 xxreal_3_th_83 sorry
            qed
            have case2: "y <XXREAL-0R3 0NUMBERSK6 implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
            proof(rule impI)
              assume A7: "y <XXREAL-0R3 0NUMBERSK6"
              then have "x *XXREAL-3K4 y =HIDDENR1 -inftyXXREAL-0K2"
                using A5 xxreal_3_def_5 sorry
              thus "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
                using A1 A5 A7 xxreal_3_th_84 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
        proof(rule impI)
          assume A8: "x =HIDDENR1 -inftyXXREAL-0K2"
          show "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
          proof-
            have cases: "0NUMBERSK6 <XXREAL-0R3 y or y <XXREAL-0R3 0NUMBERSK6"
              using A3 sorry
            have case1: "0NUMBERSK6 <XXREAL-0R3 y implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
            proof(rule impI)
              assume A9: "0NUMBERSK6 <XXREAL-0R3 y"
              then have "x *XXREAL-3K4 y =HIDDENR1 -inftyXXREAL-0K2"
                using A8 xxreal_3_def_5 sorry
              thus "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
                using A2 A8 A9 xxreal_3_th_86 sorry
            qed
            have case2: "y <XXREAL-0R3 0NUMBERSK6 implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
            proof(rule impI)
              assume A10: "y <XXREAL-0R3 0NUMBERSK6"
              then have "x *XXREAL-3K4 y =HIDDENR1 +inftyXXREAL-0K1"
                using A8 xxreal_3_def_5 sorry
              thus "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
                using A1 A8 A10 xxreal_3_th_85 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have case3: "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2 implies (x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
        proof(rule impI)
          assume "x <>HIDDENR2 +inftyXXREAL-0K1 & x <>HIDDENR2 -inftyXXREAL-0K2"
          then have "x inHIDDENR3 REALNUMBERSK2"
            using xxreal_0_th_14 sorry
          then obtain a where 
            [ty]:"a be RealXREAL-0M1" and aDef:"a = x"
             sorry
          have "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 (a *XXREAL-3K4 b)/XXREAL-3K6 b"
             sorry
          also have "... = a"
            using A3 xcmplx_1_th_89 sorry
          finally have "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 a"
             sorry
          thus "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    have "y /XXREAL-3K6 y =HIDDENR1 \<one>\<^sub>M"
      using A1 A2 A3 xxreal_3_th_78 sorry
    thus "(x *XXREAL-3K4 y)/XXREAL-3K6 y =HIDDENR1 x & x *XXREAL-3K4 (y /XXREAL-3K6 y) =HIDDENR1 x"
      using A4 xxreal_3_th_81 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_89:
" for y be ExtRealXXREAL-0M1 holds +inftyXXREAL-0K1 *XXREAL-3K4 y <>HIDDENR2 \<one>\<^sub>M & -inftyXXREAL-0K2 *XXREAL-3K4 y <>HIDDENR2 \<one>\<^sub>M"
proof-
  have " for y be ExtRealXXREAL-0M1 holds  not +inftyXXREAL-0K1 *XXREAL-3K4 y <>HIDDENR2 \<one>\<^sub>M &  not -inftyXXREAL-0K2 *XXREAL-3K4 y <>HIDDENR2 \<one>\<^sub>M"
  proof(rule ballI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "(y =HIDDENR1 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 y) or y <XXREAL-0R3 0NUMBERSK6"
       sorry
    thus " not +inftyXXREAL-0K1 *XXREAL-3K4 y <>HIDDENR2 \<one>\<^sub>M &  not -inftyXXREAL-0K2 *XXREAL-3K4 y <>HIDDENR2 \<one>\<^sub>M"
      using xxreal_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_90:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 y <>HIDDENR2 +inftyXXREAL-0K1 & x *XXREAL-3K4 y <>HIDDENR2 -inftyXXREAL-0K2 implies x inHIDDENR3 REALNUMBERSK2 or y inHIDDENR3 REALNUMBERSK2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 y <>HIDDENR2 +inftyXXREAL-0K1 & x *XXREAL-3K4 y <>HIDDENR2 -inftyXXREAL-0K2 implies ( not x inHIDDENR3 REALNUMBERSK2 &  not y inHIDDENR3 REALNUMBERSK2 implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x *XXREAL-3K4 y <>HIDDENR2 +inftyXXREAL-0K1"
      and A2: "x *XXREAL-3K4 y <>HIDDENR2 -inftyXXREAL-0K2"
    assume A3: " not x inHIDDENR3 REALNUMBERSK2 &  not y inHIDDENR3 REALNUMBERSK2"
    show " False "
    proof-
      have cases: "((x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 or x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1) or x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2"
        using A3 xxreal_0_th_14 sorry
      have case1: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1 implies  False "
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 +inftyXXREAL-0K1"
        thus " False "
          using A1 xxreal_3_def_5 sorry
      qed
      have case2: "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2 implies  False "
      proof(rule impI)
        assume "x =HIDDENR1 +inftyXXREAL-0K1 & y =HIDDENR1 -inftyXXREAL-0K2"
        thus " False "
          using A2 xxreal_3_def_5 sorry
      qed
      have case3: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1 implies  False "
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 +inftyXXREAL-0K1"
        thus " False "
          using A2 xxreal_3_def_5 sorry
      qed
      have case4: "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2 implies  False "
      proof(rule impI)
        assume "x =HIDDENR1 -inftyXXREAL-0K2 & y =HIDDENR1 -inftyXXREAL-0K2"
        thus " False "
          using A1 xxreal_3_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xxreal_3_th_91:
" for x be ExtRealXXREAL-0M1 holds (-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds (-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "(-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
    proof-
      have cases: "(x inHIDDENR3 REALNUMBERSK2 or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 implies (-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2"
        then obtain y where 
          [ty]:"x be RealXREAL-0M1" and
          [ty]:"y be RealXREAL-0M1" and yDef:"y = -XXREAL-3K2 \<one>\<^sub>M"
           sorry
        have "y *XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
           sorry
        thus "(-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
           sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies (-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
      proof(rule impI)
        assume A1: "x =HIDDENR1 -inftyXXREAL-0K2"
        then have "(-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_5 sorry
        also have "... = -XXREAL-3K2 x"
          using A1 xxreal_3_def_3 sorry
        finally show "(-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
           sorry
      qed
      have case3: "x =HIDDENR1 +inftyXXREAL-0K1 implies (-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
      proof(rule impI)
        assume A2: "x =HIDDENR1 +inftyXXREAL-0K1"
        then have "(-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_5 sorry
        also have "... = -XXREAL-3K2 x"
          using A2 xxreal_3_def_3 sorry
        finally show "(-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x =HIDDENR1 -XXREAL-3K2 x"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_92:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 x *XXREAL-3K4 y =HIDDENR1 (-XXREAL-3K2 x)*XXREAL-3K4 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds -XXREAL-3K2 x *XXREAL-3K4 y =HIDDENR1 (-XXREAL-3K2 x)*XXREAL-3K4 y"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "-XXREAL-3K2 x *XXREAL-3K4 y =HIDDENR1 (-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 (x *XXREAL-3K4 y)"
      using xxreal_3_th_91 sorry
    also have "... = ((-XXREAL-3K2 \<one>\<^sub>M)*XXREAL-3K4 x)*XXREAL-3K4 y"
      using xxreal_3_th_66 sorry
    also have "... = (-XXREAL-3K2 x)*XXREAL-3K4 y"
      using xxreal_3_th_91 sorry
    finally show "-XXREAL-3K2 x *XXREAL-3K4 y =HIDDENR1 (-XXREAL-3K2 x)*XXREAL-3K4 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_93:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y =HIDDENR1 -XXREAL-3K2 z implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y =HIDDENR1 -XXREAL-3K2 z implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "y =HIDDENR1 -XXREAL-3K2 z"
    then have "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 (0NUMBERSK6)"
      using xxreal_3_th_7 sorry
    also have "... = x *XXREAL-3K4 y -XXREAL-3K3 x *XXREAL-3K4 y"
      using xxreal_3_th_7 sorry
    also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 (-XXREAL-3K2 y)"
      using xxreal_3_th_92 sorry
    also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      using A1 sorry
    finally show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_94:
" for x be ExtRealXXREAL-0M1 holds \<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds \<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    show "\<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
    proof-
      have cases: "(x inHIDDENR3 REALNUMBERSK2 or x =HIDDENR1 -inftyXXREAL-0K2) or x =HIDDENR1 +inftyXXREAL-0K1"
        using xxreal_0_th_14 sorry
      have case1: "x inHIDDENR3 REALNUMBERSK2 implies \<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
      proof(rule impI)
        assume "x inHIDDENR3 REALNUMBERSK2"
        then have 
          [ty]:"x be RealXREAL-0M1"
           sorry
        have "\<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
           sorry
        thus "\<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
           sorry
      qed
      have case2: "x =HIDDENR1 -inftyXXREAL-0K2 implies \<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
      proof(rule impI)
        assume A1: "x =HIDDENR1 -inftyXXREAL-0K2"
        then have "\<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 -inftyXXREAL-0K2"
          using xxreal_3_def_5 sorry
        also have "... = x +XXREAL-3K1 x"
          using A1 xxreal_3_def_2 sorry
        finally show "\<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
           sorry
      qed
      have case3: "x =HIDDENR1 +inftyXXREAL-0K1 implies \<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
      proof(rule impI)
        assume A2: "x =HIDDENR1 +inftyXXREAL-0K1"
        then have "\<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 +inftyXXREAL-0K1"
          using xxreal_3_def_5 sorry
        also have "... = x +XXREAL-3K1 x"
          using A2 xxreal_3_def_2 sorry
        finally show "\<two>\<^sub>M *XXREAL-3K4 x =HIDDENR1 x +XXREAL-3K1 x"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_24:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (y +XXREAL-3K1 y) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (y +XXREAL-3K1 y) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 y"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "x *XXREAL-3K4 (y +XXREAL-3K1 y) =HIDDENR1 x *XXREAL-3K4 (\<two>\<^sub>M *XXREAL-3K4 y)"
      using xxreal_3_th_94 sorry
    also have "... = \<two>\<^sub>M *XXREAL-3K4 (x *XXREAL-3K4 y)"
      using xxreal_3_th_66 sorry
    also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 y"
      using xxreal_3_th_94 sorry
    finally show "x *XXREAL-3K4 (y +XXREAL-3K1 y) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_25:
" for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (0NUMBERSK6 +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 (0NUMBERSK6) +XXREAL-3K1 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (0NUMBERSK6 +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 (0NUMBERSK6) +XXREAL-3K1 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    have "x *XXREAL-3K4 (0NUMBERSK6 +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 z"
      using xxreal_3_th_4 sorry
    also have "... = x *XXREAL-3K4 (0NUMBERSK6) +XXREAL-3K1 x *XXREAL-3K4 z"
      using xxreal_3_th_4 sorry
    finally show "x *XXREAL-3K4 (0NUMBERSK6 +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 (0NUMBERSK6) +XXREAL-3K1 x *XXREAL-3K4 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_26:
" for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (0NUMBERSK6)*XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 (0NUMBERSK6)*XXREAL-3K4 y +XXREAL-3K1 (0NUMBERSK6)*XXREAL-3K4 z"
   sorry

mlemma xxreal_3_lm_27:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 & y be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 & y be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x be realXREAL-0V1"
      and A2: "y be realXREAL-0V1"
    obtain r s where 
      [ty]:"r be RealXREAL-0M1" and rDef:"r = x" and
      [ty]:"s be RealXREAL-0M1" and sDef:"s = y"
      using A1 A2 sorry
    have A3: "x *XXREAL-3K4 y =HIDDENR1 r *XXREAL-3K4 s"
       sorry
    show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
    proof-
      have cases: "(z inHIDDENR3 REALNUMBERSK2 or z =HIDDENR1 -inftyXXREAL-0K2) or z =HIDDENR1 +inftyXXREAL-0K1"
        using xxreal_0_th_14 sorry
      have case1: "z inHIDDENR3 REALNUMBERSK2 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume "z inHIDDENR3 REALNUMBERSK2"
        then obtain t where 
          [ty]:"t be RealXREAL-0M1" and tDef:"t = z"
           sorry
        obtain u v w where 
          [ty]:"u be RealXREAL-0M1" and uDef:"u = s +XXREAL-3K1 t" and
          [ty]:"v be RealXREAL-0M1" and vDef:"v = r *XXREAL-3K4 s" and
          [ty]:"w be RealXREAL-0M1" and wDef:"w = r *XXREAL-3K4 t"
           sorry
        have "r *XXREAL-3K4 u =HIDDENR1 v +XXREAL-3K1 w"
           sorry
        thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
           sorry
      qed
      have case2: "z =HIDDENR1 -inftyXXREAL-0K2 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume A4: "z =HIDDENR1 -inftyXXREAL-0K2"
        then have A5: "y +XXREAL-3K1 z =HIDDENR1 -inftyXXREAL-0K2"
          using A2 xxreal_3_def_2 sorry
        show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
        proof-
          have cases: "(x be zeroORDINAL1V8 or x be positiveXXREAL-0V2) or x be negativeXXREAL-0V3"
             sorry
          have case1: "x be zeroORDINAL1V8 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume "x be zeroORDINAL1V8"
            then have "x =HIDDENR1 0NUMBERSK6"
               sorry
            thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using xxreal_3_lm_26 sorry
          qed
          have case2: "x be positiveXXREAL-0V2 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume A6: "x be positiveXXREAL-0V2"
            then have "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 -inftyXXREAL-0K2"
              using A5 xxreal_3_def_5 sorry
            also have "... = x *XXREAL-3K4 y +XXREAL-3K1 -inftyXXREAL-0K2"
              using A3 xxreal_3_def_2 sorry
            also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using A4 A6 xxreal_3_def_5 sorry
            finally show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
               sorry
          qed
          have case3: "x be negativeXXREAL-0V3 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume A7: "x be negativeXXREAL-0V3"
            then have "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 +inftyXXREAL-0K1"
              using A5 xxreal_3_def_5 sorry
            also have "... = x *XXREAL-3K4 y +XXREAL-3K1 +inftyXXREAL-0K1"
              using A3 xxreal_3_def_2 sorry
            also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using A4 A7 xxreal_3_def_5 sorry
            finally show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      have case3: "z =HIDDENR1 +inftyXXREAL-0K1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume A8: "z =HIDDENR1 +inftyXXREAL-0K1"
        then have A9: "y +XXREAL-3K1 z =HIDDENR1 +inftyXXREAL-0K1"
          using A2 xxreal_3_def_2 sorry
        show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
        proof-
          have cases: "(x be zeroORDINAL1V8 or x be positiveXXREAL-0V2) or x be negativeXXREAL-0V3"
             sorry
          have case1: "x be zeroORDINAL1V8 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume "x be zeroORDINAL1V8"
            then have "x =HIDDENR1 0NUMBERSK6"
               sorry
            thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using xxreal_3_lm_26 sorry
          qed
          have case2: "x be positiveXXREAL-0V2 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume A10: "x be positiveXXREAL-0V2"
            then have "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 +inftyXXREAL-0K1"
              using A9 xxreal_3_def_5 sorry
            also have "... = x *XXREAL-3K4 y +XXREAL-3K1 +inftyXXREAL-0K1"
              using A3 xxreal_3_def_2 sorry
            also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using A8 A10 xxreal_3_def_5 sorry
            finally show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
               sorry
          qed
          have case3: "x be negativeXXREAL-0V3 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume A11: "x be negativeXXREAL-0V3"
            then have "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 -inftyXXREAL-0K2"
              using A9 xxreal_3_def_5 sorry
            also have "... = x *XXREAL-3K4 y +XXREAL-3K1 -inftyXXREAL-0K2"
              using A3 xxreal_3_def_2 sorry
            also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using A8 A11 xxreal_3_def_5 sorry
            finally show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_3_lm_28:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 &  not y be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 &  not y be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x be realXREAL-0V1"
      and A2: " not y be realXREAL-0V1"
    show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
    proof-
      have cases: "z be realXREAL-0V1 or  not z be realXREAL-0V1"
         sorry
      have case1: "z be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume "z be realXREAL-0V1"
        thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          using A1 xxreal_3_lm_27 sorry
      qed
      have case2: " not z be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume " not z be realXREAL-0V1"
        then have A3: " not z inHIDDENR3 REALNUMBERSK2"
           sorry
        have A4: " not y inHIDDENR3 REALNUMBERSK2"
          using A2 sorry
        show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
        proof-
          have cases: "((y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2 or y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1) or y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2) or y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1"
            using A4 A3 xxreal_0_th_14 sorry
          have case1: "y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume "y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 -inftyXXREAL-0K2"
            thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using xxreal_3_lm_24 sorry
          qed
          have case2: "y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume "y =HIDDENR1 -inftyXXREAL-0K2 & z =HIDDENR1 +inftyXXREAL-0K1"
            thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using xxreal_3_th_5 xxreal_3_th_93 sorry
          qed
          have case3: "y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume "y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 -inftyXXREAL-0K2"
            thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using xxreal_3_th_6 xxreal_3_th_93 sorry
          qed
          have case4: "y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume "y =HIDDENR1 +inftyXXREAL-0K1 & z =HIDDENR1 +inftyXXREAL-0K1"
            thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using xxreal_3_lm_24 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_95:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x be realXREAL-0V1"
    show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
    proof-
      have cases: "y be realXREAL-0V1 & z be realXREAL-0V1 or ( not y be realXREAL-0V1 or  not z be realXREAL-0V1)"
         sorry
      have case1: "y be realXREAL-0V1 & z be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume "y be realXREAL-0V1 & z be realXREAL-0V1"
        thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          using A1 xxreal_3_lm_27 sorry
      qed
      have case2: " not y be realXREAL-0V1 or  not z be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume " not y be realXREAL-0V1 or  not z be realXREAL-0V1"
        thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          using A1 xxreal_3_lm_28 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_96:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y >=XXREAL-0R2 0NUMBERSK6 & z >=XXREAL-0R2 0NUMBERSK6 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y >=XXREAL-0R2 0NUMBERSK6 & z >=XXREAL-0R2 0NUMBERSK6 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "y >=XXREAL-0R2 0NUMBERSK6 & z >=XXREAL-0R2 0NUMBERSK6"
    show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
    proof-
      have cases: "(y =HIDDENR1 0NUMBERSK6 or z =HIDDENR1 0NUMBERSK6) or y >XXREAL-0R4 0NUMBERSK6 & z >XXREAL-0R4 0NUMBERSK6"
        using A1 sorry
      have case1: "y =HIDDENR1 0NUMBERSK6 or z =HIDDENR1 0NUMBERSK6 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume "y =HIDDENR1 0NUMBERSK6 or z =HIDDENR1 0NUMBERSK6"
        thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          using xxreal_3_lm_25 sorry
      qed
      have case2: "y >XXREAL-0R4 0NUMBERSK6 & z >XXREAL-0R4 0NUMBERSK6 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
      proof(rule impI)
        assume A2: "y >XXREAL-0R4 0NUMBERSK6 & z >XXREAL-0R4 0NUMBERSK6"
        show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
        proof-
          have cases: "x be realXREAL-0V1 or  not x be realXREAL-0V1"
             sorry
          have case1: "x be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume "x be realXREAL-0V1"
            thus "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              using xxreal_3_th_95 sorry
          qed
          have case2: " not x be realXREAL-0V1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
          proof(rule impI)
            assume " not x be realXREAL-0V1"
            then have A3: " not x inHIDDENR3 REALNUMBERSK2"
               sorry
            show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
            proof-
              have cases: "x =HIDDENR1 -inftyXXREAL-0K2 or x =HIDDENR1 +inftyXXREAL-0K1"
                using A3 xxreal_0_th_14 sorry
              have case1: "x =HIDDENR1 -inftyXXREAL-0K2 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              proof(rule impI)
                assume A4: "x =HIDDENR1 -inftyXXREAL-0K2"
                then have "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 -inftyXXREAL-0K2"
                  using A2 xxreal_3_def_5 sorry
                also have "... = -inftyXXREAL-0K2 +XXREAL-3K1 x *XXREAL-3K4 z"
                  using A2 A4 xxreal_3_def_2 sorry
                also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
                  using A2 A4 xxreal_3_def_5 sorry
                finally show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
                   sorry
              qed
              have case2: "x =HIDDENR1 +inftyXXREAL-0K1 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
              proof(rule impI)
                assume A5: "x =HIDDENR1 +inftyXXREAL-0K1"
                then have "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 +inftyXXREAL-0K1"
                  using A2 xxreal_3_def_5 sorry
                also have "... = +inftyXXREAL-0K1 +XXREAL-3K1 x *XXREAL-3K4 z"
                  using A2 A5 xxreal_3_def_2 sorry
                also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
                  using A2 A5 xxreal_3_def_5 sorry
                finally show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_97:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y <=XXREAL-3R1 0NUMBERSK6 & z <=XXREAL-3R1 0NUMBERSK6 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y <=XXREAL-3R1 0NUMBERSK6 & z <=XXREAL-3R1 0NUMBERSK6 implies x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "y <=XXREAL-3R1 0NUMBERSK6 & z <=XXREAL-3R1 0NUMBERSK6"
    have "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 -XXREAL-3K2 (-XXREAL-3K2 x *XXREAL-3K4 (y +XXREAL-3K1 z))"
       sorry
    also have "... = -XXREAL-3K2 x *XXREAL-3K4 (-XXREAL-3K2 (y +XXREAL-3K1 z))"
      using xxreal_3_th_92 sorry
    also have "... = -XXREAL-3K2 x *XXREAL-3K4 ((-XXREAL-3K2 y)+XXREAL-3K1 (-XXREAL-3K2 z))"
      using xxreal_3_th_9 sorry
    also have "... = -XXREAL-3K2 (x *XXREAL-3K4 (-XXREAL-3K2 y) +XXREAL-3K1 x *XXREAL-3K4 (-XXREAL-3K2 z))"
      using A1 xxreal_3_th_96 sorry
    also have "... = -XXREAL-3K2 ((-XXREAL-3K2 x *XXREAL-3K4 y)+XXREAL-3K1 x *XXREAL-3K4 (-XXREAL-3K2 z))"
      using xxreal_3_th_92 sorry
    also have "... = -XXREAL-3K2 ((-XXREAL-3K2 x *XXREAL-3K4 y)+XXREAL-3K1 (-XXREAL-3K2 x *XXREAL-3K4 z))"
      using xxreal_3_th_92 sorry
    also have "... = -XXREAL-3K2 (-XXREAL-3K2 (x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z))"
      using xxreal_3_th_9 sorry
    also have "... = x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
       sorry
    finally show "x *XXREAL-3K4 (y +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_98:
" for x be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x *XXREAL-3K4 (0NUMBERSK6 +XXREAL-3K1 z) =HIDDENR1 x *XXREAL-3K4 (0NUMBERSK6) +XXREAL-3K1 x *XXREAL-3K4 z"
  using xxreal_3_lm_25 sorry

mtheorem xxreal_3_th_99:
" for f be ExtRealXXREAL-0M1 holds (-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
proof-
  have " for f be ExtRealXXREAL-0M1 holds (-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
  proof(rule ballI)
    fix f assume [ty]: "f be ExtRealXXREAL-0M1"
    show "(-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
    proof-
      have cases: "(f inHIDDENR3 REALNUMBERSK2 or f =HIDDENR1 +inftyXXREAL-0K1) or f =HIDDENR1 -inftyXXREAL-0K2"
        using xxreal_0_th_14 sorry
      have case1: "f inHIDDENR3 REALNUMBERSK2 implies (-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
      proof(rule impI)
        assume A1: "f inHIDDENR3 REALNUMBERSK2"
        then obtain g where 
          [ty]:"g be RealXREAL-0M1" and gDef:"g = f"
           sorry
        have A2: "-XXREAL-3K2 f =HIDDENR1 -XXREAL-3K2 g"
           sorry
        obtain a where
          [ty]:"a be ComplexXCMPLX-0M1" and 
          A3: "f =HIDDENR1 a"and A4: "f \<inverse>XXREAL-3K5 =HIDDENR1 a \<inverse>XCMPLX-0K5"
          using A1 xxreal_3_def_6 sorry
        have A5: "(-XCMPLX-0K4 a)\<inverse>XCMPLX-0K5 =HIDDENR1 -XCMPLX-0K4 a \<inverse>XCMPLX-0K5"
          using xcmplx_1_th_222 sorry
        have " ex m be ComplexXCMPLX-0M1 st -XXREAL-3K2 f =HIDDENR1 m & -XXREAL-3K2 f \<inverse>XXREAL-3K5 =HIDDENR1 m \<inverse>XCMPLX-0K5"
        proof-
          have " ex tVar23 be ComplexXCMPLX-0M1 st -XXREAL-3K2 f =HIDDENR1 tVar23 & -XXREAL-3K2 f \<inverse>XXREAL-3K5 =HIDDENR1 tVar23 \<inverse>XCMPLX-0K5"
          proof-
            show " ex tVar23 be ComplexXCMPLX-0M1 st -XXREAL-3K2 f =HIDDENR1 tVar23 & -XXREAL-3K2 f \<inverse>XXREAL-3K5 =HIDDENR1 tVar23 \<inverse>XCMPLX-0K5"
            proof(rule bexI[of _ "-XCMPLX-0K4 a"],rule conjMI)
              show "-XXREAL-3K2 f =HIDDENR1 -XCMPLX-0K4 a"
                using A3 A2 sorry
              show "-XXREAL-3K2 f \<inverse>XXREAL-3K5 =HIDDENR1 (-XCMPLX-0K4 a)\<inverse>XCMPLX-0K5"
                using A4 A5 A2 xxreal_3_def_3 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        thus "(-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
          using A2 xxreal_3_def_6 sorry
      qed
      have case2: "f =HIDDENR1 +inftyXXREAL-0K1 implies (-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
      proof(rule impI)
        assume A6: "f =HIDDENR1 +inftyXXREAL-0K1"
        then have "(-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -inftyXXREAL-0K2 \<inverse>XXREAL-3K5"
          using xxreal_3_def_3 sorry
        also have "... = -XXREAL-3K2 f \<inverse>XXREAL-3K5"
          using A6 sorry
        finally show "(-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
           sorry
      qed
      have case3: "f =HIDDENR1 -inftyXXREAL-0K2 implies (-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
      proof(rule impI)
        assume A7: "f =HIDDENR1 -inftyXXREAL-0K2"
        then have "(-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 +inftyXXREAL-0K1 \<inverse>XXREAL-3K5"
          using xxreal_3_def_3 sorry
        also have "... = -XXREAL-3K2 f \<inverse>XXREAL-3K5"
          using A7 sorry
        finally show "(-XXREAL-3K2 f)\<inverse>XXREAL-3K5 =HIDDENR1 -XXREAL-3K2 f \<inverse>XXREAL-3K5"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_100:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 implies x *XXREAL-3K4 (y -XXREAL-3K3 z) =HIDDENR1 x *XXREAL-3K4 y -XXREAL-3K3 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x be realXREAL-0V1 implies x *XXREAL-3K4 (y -XXREAL-3K3 z) =HIDDENR1 x *XXREAL-3K4 y -XXREAL-3K3 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume "x be realXREAL-0V1"
    then have "x *XXREAL-3K4 (y -XXREAL-3K3 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 x *XXREAL-3K4 (-XXREAL-3K2 z)"
      using xxreal_3_th_95 sorry
    also have "... = x *XXREAL-3K4 y +XXREAL-3K1 (-XXREAL-3K2 x *XXREAL-3K4 z)"
      using xxreal_3_th_92 sorry
    finally have "x *XXREAL-3K4 (y -XXREAL-3K3 z) =HIDDENR1 x *XXREAL-3K4 y +XXREAL-3K1 (-XXREAL-3K2 x *XXREAL-3K4 z)"
       sorry
    thus "x *XXREAL-3K4 (y -XXREAL-3K3 z) =HIDDENR1 x *XXREAL-3K4 y -XXREAL-3K3 x *XXREAL-3K4 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_101:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & z <=XXREAL-3R1 0NUMBERSK6 implies y *XXREAL-3K4 z <=XXREAL-3R1 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & z <=XXREAL-3R1 0NUMBERSK6 implies y *XXREAL-3K4 z <=XXREAL-3R1 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume "x <=XXREAL-3R1 y & z <=XXREAL-3R1 0NUMBERSK6"
    then have A1: "x *XXREAL-3K4 (-XXREAL-3K2 z) <=XXREAL-3R1 y *XXREAL-3K4 (-XXREAL-3K2 z)"
      using xxreal_3_th_71 sorry
    have "-XXREAL-3K2 x *XXREAL-3K4 z =HIDDENR1 x *XXREAL-3K4 (-XXREAL-3K2 z) & -XXREAL-3K2 y *XXREAL-3K4 z =HIDDENR1 y *XXREAL-3K4 (-XXREAL-3K2 z)"
      using xxreal_3_th_92 sorry
    thus "y *XXREAL-3K4 z <=XXREAL-3R1 x *XXREAL-3K4 z"
      using A1 xxreal_3_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_102:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (x <XXREAL-0R3 y & z <XXREAL-0R3 0NUMBERSK6) & z <>HIDDENR2 -inftyXXREAL-0K2 implies y *XXREAL-3K4 z <XXREAL-0R3 x *XXREAL-3K4 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (x <XXREAL-0R3 y & z <XXREAL-0R3 0NUMBERSK6) & z <>HIDDENR2 -inftyXXREAL-0K2 implies  not y *XXREAL-3K4 z <XXREAL-0R3 x *XXREAL-3K4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume "(x <XXREAL-0R3 y & z <XXREAL-0R3 0NUMBERSK6) & z <>HIDDENR2 -inftyXXREAL-0K2"
    then have A1: "x *XXREAL-3K4 (-XXREAL-3K2 z) <XXREAL-0R3 y *XXREAL-3K4 (-XXREAL-3K2 z)"
      using xxreal_3_th_5 xxreal_3_th_10 xxreal_3_th_72 sorry
    have "-XXREAL-3K2 x *XXREAL-3K4 z =HIDDENR1 x *XXREAL-3K4 (-XXREAL-3K2 z) & -XXREAL-3K2 y *XXREAL-3K4 z =HIDDENR1 y *XXREAL-3K4 (-XXREAL-3K2 z)"
      using xxreal_3_th_92 sorry
    thus " not y *XXREAL-3K4 z <XXREAL-0R3 x *XXREAL-3K4 z"
      using A1 xxreal_3_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_103:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <=XXREAL-3R1 y & z <XXREAL-0R3 0NUMBERSK6 implies y /XXREAL-3K6 z <=XXREAL-3R1 x /XXREAL-3K6 z"
  using xxreal_3_th_101 sorry

mtheorem xxreal_3_th_104:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds (x <XXREAL-0R3 y & z <XXREAL-0R3 0NUMBERSK6) & z <>HIDDENR2 -inftyXXREAL-0K2 implies y /XXREAL-3K6 z <XXREAL-0R3 x /XXREAL-3K6 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y & (0NUMBERSK6 >XXREAL-0R4 z & z <>HIDDENR2 -inftyXXREAL-0K2) implies  not y /XXREAL-3K6 z <XXREAL-0R3 x /XXREAL-3K6 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
      and A2: "0NUMBERSK6 >XXREAL-0R4 z"
      and A3: "z <>HIDDENR2 -inftyXXREAL-0K2"
    show " not y /XXREAL-3K6 z <XXREAL-0R3 x /XXREAL-3K6 z"
    proof-
      have cases: "z =HIDDENR1 +inftyXXREAL-0K1 or z inHIDDENR3 REALNUMBERSK2"
        using A3 xxreal_0_th_14 sorry
      have case1: "z =HIDDENR1 +inftyXXREAL-0K1 implies  not y /XXREAL-3K6 z <XXREAL-0R3 x /XXREAL-3K6 z"
      proof(rule impI)
        assume "z =HIDDENR1 +inftyXXREAL-0K1"
        thus " not y /XXREAL-3K6 z <XXREAL-0R3 x /XXREAL-3K6 z"
          using A2 sorry
      qed
      have case2: "z inHIDDENR3 REALNUMBERSK2 implies  not y /XXREAL-3K6 z <XXREAL-0R3 x /XXREAL-3K6 z"
      proof(rule impI)
        assume "z inHIDDENR3 REALNUMBERSK2"
        then have 
          [ty]:"z be RealXREAL-0M1"
           sorry
        have "z \<inverse>XXREAL-3K5 <XXREAL-0R3 0NUMBERSK6"
          using A2 sorry
        thus " not y /XXREAL-3K6 z <XXREAL-0R3 x /XXREAL-3K6 z"
          using A1 xxreal_3_th_102 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_th_105:
" for x be ExtRealXXREAL-0M1 holds x /XXREAL-3K6 \<two>\<^sub>M +XXREAL-3K1 x /XXREAL-3K6 \<two>\<^sub>M =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x /XXREAL-3K6 \<two>\<^sub>M +XXREAL-3K1 x /XXREAL-3K6 \<two>\<^sub>M =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have "x /XXREAL-3K6 \<two>\<^sub>M +XXREAL-3K1 x /XXREAL-3K6 \<two>\<^sub>M =HIDDENR1 (x +XXREAL-3K1 x)/XXREAL-3K6 \<two>\<^sub>M"
      using xxreal_3_th_95 sorry
    also have "... = (\<two>\<^sub>M *XXREAL-3K4 x)/XXREAL-3K6 \<two>\<^sub>M"
      using xxreal_3_th_94 sorry
    also have "... = x *XXREAL-3K4 (\<two>\<^sub>M /XXREAL-3K6 \<two>\<^sub>M)"
      using xxreal_3_th_66 sorry
    also have "... = x"
      using xxreal_3_th_81 sorry
    finally have "x /XXREAL-3K6 \<two>\<^sub>M +XXREAL-3K1 x /XXREAL-3K6 \<two>\<^sub>M =HIDDENR1 x"
       sorry
    thus "x /XXREAL-3K6 \<two>\<^sub>M +XXREAL-3K1 x /XXREAL-3K6 \<two>\<^sub>M =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_3_cl_47:
  mlet "x be NatORDINAL1M6", "y be NatORDINAL1M6"
"cluster x +XXREAL-3K1 y as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be naturalORDINAL1V7"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_48:
  mlet "x be NatORDINAL1M6", "y be NatORDINAL1M6"
"cluster x *XXREAL-3K4 y as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "x *XXREAL-3K4 y be naturalORDINAL1V7"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_49:
"cluster -XXREAL-3K2 \<one>\<^sub>M as-term-is dim-likeINT-1V2"
proof
(*coherence*)
  show "-XXREAL-3K2 \<one>\<^sub>M be dim-likeINT-1V2"
     sorry
qed "sorry"

mtheorem xxreal_3_cl_50:
  mlet "n be dim-likeINT-1V2\<bar>numberORDINAL1M2"
"cluster n +XXREAL-3K1 \<one>\<^sub>M as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "n +XXREAL-3K1 \<one>\<^sub>M be naturalORDINAL1V7"
     sorry
qed "sorry"

end
