theory funct_2
  imports setfam_1 mcart_1 partfun1
begin
(*begin*)
reserve P, Q, X, Y, Z for "setHIDDENM2"
reserve p, x, x9, x1, x2, y, z for "objectHIDDENM1"
mdef funct_2_def_1 ("quasi-totalFUNCT-2V1\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"attr quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> for RelationRELSET-1M1-of(X,Y) means
  \<lambda>R. X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R if \<lambda>R. Y <>HIDDENR2 {}XBOOLE-0K1 otherwise \<lambda>R. R =RELAT-1R1 {}XBOOLE-0K1"
proof-
  (*consistency*)
    show " for R be RelationRELSET-1M1-of(X,Y) holds  True "
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
      show " True "
         sorry
    qed "sorry"
qed "sorry"

mtheorem funct_2_cl_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(X,Y) st it be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
  proof-
    have " ex tVar1 be PartFuncPARTFUN1M1-of(X,Y) st tVar1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
    proof-
      show " ex tVar1 be PartFuncPARTFUN1M1-of(X,Y) st tVar1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
      proof-
        have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar1 be PartFuncPARTFUN1M1-of(X,Y) st tVar1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
        proof(rule impI)
          assume A1: "Y =XBOOLE-0R4 {}XBOOLE-0K1"
          obtain R where 
            [ty]:"R be PartFuncPARTFUN1M1-of(X,Y)" and RDef:"R = {}XBOOLE-0K1"
            using relset_1_th_12 sorry
          show " ex tVar1 be PartFuncPARTFUN1M1-of(X,Y) st tVar1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
          proof(rule bexI[of _ "R"])
            show "R be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
              using A1 funct_2_def_1 sorry
          qed "sorry"
        qed
        have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar2 be PartFuncPARTFUN1M1-of(X,Y) st tVar2 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
        proof(rule impI)
          assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A3: "X =XBOOLE-0R4 domRELAT-1K1 f"and A4: "rngFUNCT-1K2 f c=TARSKIR1 Y"
            using funct_1_th_8 sorry
          obtain R where 
            [ty]:"R be PartFuncPARTFUN1M1-of(X,Y)" and RDef:"R = f"
            using A3 A4 relset_1_th_4 sorry
          show " ex tVar2 be PartFuncPARTFUN1M1-of(X,Y) st tVar2 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
          proof(rule bexI[of _ "R"])
            show "R be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
              using A2 A3 funct_2_def_1 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_cl_2:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster totalPARTFUN1V1\<^bsub>(X)\<^esub> also-is quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> for RelationRELSET-1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(X,Y) holds it be totalPARTFUN1V1\<^bsub>(X)\<^esub> implies it be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
  proof-
    have " for f be RelationRELSET-1M1-of(X,Y) holds  not (f be totalPARTFUN1V1\<^bsub>(X)\<^esub> &  not f be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
    proof(rule ballI)
      fix f assume [ty]: "f be RelationRELSET-1M1-of(X,Y)"
      have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X implies Y <>HIDDENR2 {}XBOOLE-0K1 & X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f or Y =XBOOLE-0R4 {}XBOOLE-0K1 & (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies f =RELAT-1R1 {}XBOOLE-0K1)"
      proof(rule impI)
        assume A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
        show "Y <>HIDDENR2 {}XBOOLE-0K1 & X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f or Y =XBOOLE-0R4 {}XBOOLE-0K1 & (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies f =RELAT-1R1 {}XBOOLE-0K1)"
        proof-
          have cases: "Y <>HIDDENR2 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
             sorry
          have case1: "Y <>HIDDENR2 {}XBOOLE-0K1 implies X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
          proof(rule impI)
            assume "Y <>HIDDENR2 {}XBOOLE-0K1"
            show "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
              using A1 sorry
          qed
          have case2: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies f =RELAT-1R1 {}XBOOLE-0K1"
          proof(rule impI)
            assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
            thus "f =RELAT-1R1 {}XBOOLE-0K1"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " not (f be totalPARTFUN1V1\<^bsub>(X)\<^esub> &  not f be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
        using partfun1_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) FUNCT_2M1("FunctionFUNCT-2M1-of'( _ , _ ')" [0,0]70) where
  "FunctionFUNCT-2M1-of(X,Y) \<equiv> quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>\<bar>PartFuncPARTFUN1M1-of(X,Y)"

mtheorem funct_2_cl_3:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be setHIDDENM2"
"cluster quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> also-is totalPARTFUN1V1\<^bsub>(X)\<^esub> for RelationRELSET-1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(X,Y) holds it be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem funct_2_cl_4:
  mlet "X be setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> also-is totalPARTFUN1V1\<^bsub>(X)\<^esub> for RelationRELSET-1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(X,Y) holds it be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
    using funct_2_def_1 sorry
qed "sorry"

mtheorem funct_2_cl_5:
  mlet "X be setHIDDENM2"
"cluster quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub> also-is totalPARTFUN1V1\<^bsub>(X)\<^esub> for RelationRELSET-1M1-of(X,X)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(X,X) holds it be quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have " for VarFor1 be RelationRELSET-1M1-of(X,X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>)"
    proof-
      show " for VarFor1 be RelationRELSET-1M1-of(X,X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>)"
      proof-
        have cases: "X =XBOOLE-0R4 {}XBOOLE-0K1 or X <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( for VarFor1 be RelationRELSET-1M1-of(X,X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>))"
        proof(rule impI)
          assume "X =XBOOLE-0R4 {}XBOOLE-0K1"
          thus " for VarFor1 be RelationRELSET-1M1-of(X,X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>)"
             sorry
        qed
        have case2: "X <>HIDDENR2 {}XBOOLE-0K1 implies ( for VarFor1 be RelationRELSET-1M1-of(X,X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>))"
        proof(rule impI)
          assume "X <>HIDDENR2 {}XBOOLE-0K1"
          thus " for VarFor1 be RelationRELSET-1M1-of(X,X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_cl_6:
  mlet "X be setHIDDENM2"
"cluster quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,X :],X)\<^esub> also-is totalPARTFUN1V1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> for RelationRELSET-1M1-of([:ZFMISC-1K2 X,X :],X)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of([:ZFMISC-1K2 X,X :],X) holds it be quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,X :],X)\<^esub> implies it be totalPARTFUN1V1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub>"
  proof-
    have " for VarFor1 be RelationRELSET-1M1-of([:ZFMISC-1K2 X,X :],X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,X :],X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub>)"
    proof-
      show " for VarFor1 be RelationRELSET-1M1-of([:ZFMISC-1K2 X,X :],X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,X :],X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub>)"
      proof-
        have cases: "X =XBOOLE-0R4 {}XBOOLE-0K1 or X <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( for VarFor1 be RelationRELSET-1M1-of([:ZFMISC-1K2 X,X :],X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,X :],X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub>))"
        proof(rule impI)
          assume "X =XBOOLE-0R4 {}XBOOLE-0K1"
          thus " for VarFor1 be RelationRELSET-1M1-of([:ZFMISC-1K2 X,X :],X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,X :],X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub>)"
             sorry
        qed
        have case2: "X <>HIDDENR2 {}XBOOLE-0K1 implies ( for VarFor1 be RelationRELSET-1M1-of([:ZFMISC-1K2 X,X :],X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,X :],X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub>))"
        proof(rule impI)
          assume "X <>HIDDENR2 {}XBOOLE-0K1"
          thus " for VarFor1 be RelationRELSET-1M1-of([:ZFMISC-1K2 X,X :],X) holds  not (VarFor1 be quasi-totalFUNCT-2V1\<^bsub>([:ZFMISC-1K2 X,X :],X)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub>)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_th_1:
" for f be FunctionFUNCT-1M1 holds f be FunctionFUNCT-2M1-of(domRELAT-1K1 f,rngFUNCT-1K2 f)"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  obtain R where 
    [ty]:"R be RelationRELSET-1M1-of(domRELAT-1K1 f,rngFUNCT-1K2 f)" and RDef:"R = f"
    using relset_1_th_4 sorry
  have "rngRELSET-1K2\<^bsub>(rngFUNCT-1K2 f)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1 or rngRELSET-1K2\<^bsub>(rngFUNCT-1K2 f)\<^esub> R =XBOOLE-0R4 {}XBOOLE-0K1"
     sorry
  thus "f be FunctionFUNCT-2M1-of(domRELAT-1K1 f,rngFUNCT-1K2 f)"
    using funct_2_def_1 sorry
qed "sorry"

mtheorem funct_2_th_2:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 Y implies f be FunctionFUNCT-2M1-of(domRELAT-1K1 f,Y)"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 Y implies f be FunctionFUNCT-2M1-of(domRELAT-1K1 f,Y)"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "rngFUNCT-1K2 f c=TARSKIR1 Y"
    then obtain R where 
      [ty]:"R be RelationRELSET-1M1-of(domRELAT-1K1 f,Y)" and RDef:"R = f"
      using relset_1_th_4 sorry
    have "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then have "R be quasi-totalFUNCT-2V1\<^bsub>(domRELAT-1K1 f,Y)\<^esub>"
      using funct_2_def_1 sorry
    thus "f be FunctionFUNCT-2M1-of(domRELAT-1K1 f,Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 Y) implies f be FunctionFUNCT-2M1-of(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 Y) implies f be FunctionFUNCT-2M1-of(X,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 X"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 Y"
    have "rngFUNCT-1K2 f c=TARSKIR1 Y"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 Y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 f"
        then have " ex x be objectHIDDENM1 st x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x"
          using A1 funct_1_def_3 sorry
        thus "y inHIDDENR3 Y"
          using A2 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 Y"
        using tarski_def_3 sorry
    qed
    then obtain R where 
      [ty]:"R be RelationRELSET-1M1-of(domRELAT-1K1 f,Y)" and RDef:"R = f"
      using relset_1_th_4 sorry
    have "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then have "R be quasi-totalFUNCT-2V1\<^bsub>(domRELAT-1K1 f,Y)\<^esub>"
      using funct_2_def_1 sorry
    thus "f be FunctionFUNCT-2M1-of(X,Y)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies  not (x inHIDDENR3 X &  not f .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not (x inHIDDENR3 X &  not f .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> f)"
      using funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X"
    then have "f .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
      using funct_2_th_4 sorry
    thus "f .FUNCT-1K1 x inTARSKIR2 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Z implies f be FunctionFUNCT-2M1-of(X,Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1 implies (rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Z implies f be FunctionFUNCT-2M1-of(X,Z))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    assume A2: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Z"
    have "Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    proof(rule impI)
      assume "Z =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1"
        using A2 sorry
      thus "X =XBOOLE-0R4 {}XBOOLE-0K1"
        using A1 relat_1_th_42 sorry
    qed
    thus "f be FunctionFUNCT-2M1-of(X,Z)"
      using A1 A2 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & Y c=TARSKIR1 Z implies f be FunctionFUNCT-2M1-of(X,Z)"
  using relset_1_th_7 sorry

theorem funct_2_sch_1:
  fixes Xf0 Yf0 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Yf0 & Pp2(x,y))"
  shows " ex f be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies Pp2(x,f .FUNCT-1K1 x)"
  proof-
    have " ex tVar3 be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 &  not Pp2(x,tVar3 .FUNCT-1K1 x))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "domRELAT-1K1 f =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 f c=TARSKIR1 Yf0"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies Pp2(x,f .FUNCT-1K1 x)"
        using funct_1_sch_6 A1 sorry
      have 
        [ty]:"f be FunctionFUNCT-2M1-of(Xf0,Yf0)"
        using A2 funct_2_th_2 sorry
      show " ex tVar3 be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 &  not Pp2(x,tVar3 .FUNCT-1K1 x))"
      proof(rule bexI[of _ "f"])
        show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 &  not Pp2(x,f .FUNCT-1K1 x))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem funct_2_sch_2:
  fixes Xf0 Yf0 Ff1 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies Ff1(x) inHIDDENR3 Yf0"
  shows " ex f be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Yf0 & ?P(x,y))"
      using A1 sorry
    show " ex f be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
      using funct_2_sch_1 A2 sorry
  qed

mdef funct_2_def_2 ("FuncsFUNCT-2K1'( _ , _ ')" [0,0]228 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"func FuncsFUNCT-2K1(X,Y) \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
    proof-
      have " ex tVar4 be setHIDDENM2 st  for z be objectHIDDENM1 holds (z inHIDDENR3 tVar4 implies ( ex f be FunctionFUNCT-1M1 st (z =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & (( ex f be FunctionFUNCT-1M1 st z =HIDDENR1 f & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies z inHIDDENR3 tVar4)"
      proof-
        let ?P = "\<lambda>Lamb1.  ex f be FunctionFUNCT-1M1 st (Lamb1 =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y"
        obtain F where
          [ty]:"F be setHIDDENM2" and 
          A1: " for z be objectHIDDENM1 holds z inHIDDENR3 F iff z inHIDDENR3 boolSETFAM-1K9 ([:ZFMISC-1K2 X,Y :]) & ?P(z)"
          using xboole_0_sch_1 sorry
        show " ex tVar4 be setHIDDENM2 st  for z be objectHIDDENM1 holds (z inHIDDENR3 tVar4 implies ( ex f be FunctionFUNCT-1M1 st (z =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & (( ex f be FunctionFUNCT-1M1 st z =HIDDENR1 f & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies z inHIDDENR3 tVar4)"
        proof(rule bexI[of _ "F"],rule ballI,rule conjMI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          show "z inHIDDENR3 F implies ( ex f be FunctionFUNCT-1M1 st (z =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
            using A1 sorry
          assume Given: " ex f be FunctionFUNCT-1M1 st z =HIDDENR1 f & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y)"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A2: "z =HIDDENR1 f"and A3: "domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y"
             sorry
          have "f c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
          proof-
            have " for p be objectHIDDENM1 holds p inHIDDENR3 f implies p inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be objectHIDDENM1"
              assume A4: "p inHIDDENR3 f"
              then obtain x y where
                [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
                A5: "p =HIDDENR1 [TARSKIK4 x,y ]"
                using relat_1_def_1 sorry
              have 
                [ty]:"y be setHIDDENM2"
                using tarski_th_1 sorry
              have A6: "x inHIDDENR3 domRELAT-1K1 f"
                using A4 A5 xtuple_0_def_12 sorry
              then have "y =XBOOLE-0R4 f .FUNCT-1K1 x"
                using A4 A5 funct_1_def_2 sorry
              then have "y inTARSKIR2 rngFUNCT-1K2 f"
                using A6 funct_1_def_3 sorry
              thus "p inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
                using A3 A5 A6 zfmisc_1_def_2 sorry
            qed "sorry"
            thus "f c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
              using tarski_def_3 sorry
          qed
          thus "z inHIDDENR3 F"
            using A1 A2 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies it1 =HIDDENR1 it2"
    proof-
      have " for F1 be setHIDDENM2 holds  for F2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 F1 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 F2 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies F1 =HIDDENR1 F2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix F1 assume [ty]: "F1 be setHIDDENM2"
        fix F2 assume [ty]: "F2 be setHIDDENM2"
        assume A7: " for x be objectHIDDENM1 holds x inHIDDENR3 F1 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
          and A8: " for x be objectHIDDENM1 holds x inHIDDENR3 F2 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 F1 iff x inHIDDENR3 F2"
        proof-
          have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 F1 &  not x inHIDDENR3 F2) &  not (x inHIDDENR3 F2 &  not x inHIDDENR3 F1)"
          proof(rule ballI)
            fix x assume [ty]: "x be objectHIDDENM1"
            have "x inHIDDENR3 F1 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
              using A7 sorry
            thus " not (x inHIDDENR3 F1 &  not x inHIDDENR3 F2) &  not (x inHIDDENR3 F2 &  not x inHIDDENR3 F1)"
              using A8 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "F1 =HIDDENR1 F2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_2_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies f inTARSKIR2 FuncsFUNCT-2K1(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies f inTARSKIR2 FuncsFUNCT-2K1(X,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Y"
       sorry
    thus "f inTARSKIR2 FuncsFUNCT-2K1(X,Y)"
      using A1 funct_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_9:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds f inTARSKIR2 FuncsFUNCT-2K1(X,X)"
  using funct_2_th_8 sorry

mtheorem funct_2_cl_7:
  mlet "X be setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,Y) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,Y) be  non emptyXBOOLE-0V1"
    using funct_2_th_8 sorry
qed "sorry"

mtheorem funct_2_cl_8:
  mlet "X be setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,X) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,X) be  non emptyXBOOLE-0V1"
    using funct_2_th_8 sorry
qed "sorry"

mtheorem funct_2_cl_9:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(X,Y) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(X,Y) be emptyXBOOLE-0V1"
  proof-
    have "FuncsFUNCT-2K1(X,Y) be  non emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      assume "FuncsFUNCT-2K1(X,Y) be  non emptyXBOOLE-0V1"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        "the ElementSUBSET-1M1-of FuncsFUNCT-2K1(X,Y) =XBOOLE-0R4 f"and A1: "domRELAT-1K1 f =XBOOLE-0R4 X"and A2: "rngFUNCT-1K2 f c=TARSKIR1 {}XBOOLE-0K1"
        using funct_2_def_2 sorry
      have "rngFUNCT-1K2 f =XBOOLE-0R4 {}XBOOLE-0K1"
        using A2 sorry
      thus " False "
        using A1 relat_1_th_42 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x)) implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x)) implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x)"
    show "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f iff y inHIDDENR3 Y"
        proof-
          have " for y be objectHIDDENM1 holds  not (y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f &  not y inHIDDENR3 Y) &  not (y inHIDDENR3 Y &  not y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f)"
          proof(rule ballI)
            fix y assume [ty]: "y be objectHIDDENM1"
            have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
              using A2 funct_2_def_1 sorry
            then have "y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x)"
              using funct_1_def_3 sorry
            thus " not (y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f &  not y inHIDDENR3 Y) &  not (y inHIDDENR3 Y &  not y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f)"
              using A1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
          using tarski_th_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & f .FUNCT-1K1 x =HIDDENR1 y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & f .FUNCT-1K1 x =HIDDENR1 y))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & f .FUNCT-1K1 x =HIDDENR1 y))"
      using A1 funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_12:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,Y) holds  for f2 be FunctionFUNCT-2M1-of(X,Y) holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x) implies f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,Y) holds  for f2 be FunctionFUNCT-2M1-of(X,Y) holds  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x)) &  not f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(X,Y)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(X,Y)"
    show " not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x)) &  not f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2)"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x)) &  not f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2)"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus " not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x)) &  not f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2)"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x)) &  not f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2)"
      proof(rule impI)
        assume "Y <>HIDDENR2 {}XBOOLE-0K1"
        then have "domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> f2 =XBOOLE-0R4 X"
          using funct_2_def_1 sorry
        thus " not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x)) &  not f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_13:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>\<bar>RelationRELSET-1M1-of(X,Y) holds  for g be quasi-totalFUNCT-2V1\<^bsub>(Y,Z)\<^esub>\<bar>RelationRELSET-1M1-of(Y,Z) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies Z =XBOOLE-0R4 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1) implies f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g be quasi-totalFUNCT-2V1\<^bsub>(X,Z)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>\<bar>RelationRELSET-1M1-of(X,Y) holds  for g be quasi-totalFUNCT-2V1\<^bsub>(Y,Z)\<^esub>\<bar>RelationRELSET-1M1-of(Y,Z) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies Z =XBOOLE-0R4 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1) implies Z <>HIDDENR2 {}XBOOLE-0K1 & X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> (f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g) or Z =XBOOLE-0R4 {}XBOOLE-0K1 & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g =RELAT-1R1 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>\<bar>RelationRELSET-1M1-of(X,Y)"
    fix g assume [ty]: "g be quasi-totalFUNCT-2V1\<^bsub>(Y,Z)\<^esub>\<bar>RelationRELSET-1M1-of(Y,Z)"
    assume A1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies Z =XBOOLE-0R4 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
    show "Z <>HIDDENR2 {}XBOOLE-0K1 & X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> (f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g) or Z =XBOOLE-0R4 {}XBOOLE-0K1 & (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g =RELAT-1R1 {}XBOOLE-0K1)"
    proof-
      have cases: "Z <>HIDDENR2 {}XBOOLE-0K1 or Z =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      have case1: "Z <>HIDDENR2 {}XBOOLE-0K1 implies X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> (f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g)"
      proof(rule impI)
        assume A2: "Z <>HIDDENR2 {}XBOOLE-0K1"
        then have A3: "domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
          using funct_2_def_1 sorry
        have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Y"
          using A1 A2 funct_2_def_1 sorry
        thus "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> (f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g)"
          using A3 relat_1_th_27 sorry
      qed
      have case2: "Z =XBOOLE-0R4 {}XBOOLE-0K1 implies f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g =RELAT-1R1 {}XBOOLE-0K1"
      proof(rule impI)
        assume "Z =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "f *RELSET-1K4\<^bsub>(X,Y,Y,Z)\<^esub> g =RELAT-1R1 {}XBOOLE-0K1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_14:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds (Z <>HIDDENR2 {}XBOOLE-0K1 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y) & rngRELSET-1K2\<^bsub>(Z)\<^esub> g =XBOOLE-0R4 Z implies rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) =XBOOLE-0R4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds Z <>HIDDENR2 {}XBOOLE-0K1 implies  not ((rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y & rngRELSET-1K2\<^bsub>(Z)\<^esub> g =XBOOLE-0R4 Z) &  not rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) =XBOOLE-0R4 Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
    assume "Z <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    thus " not ((rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y & rngRELSET-1K2\<^bsub>(Z)\<^esub> g =XBOOLE-0R4 Z) &  not rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) =XBOOLE-0R4 Z)"
      using relat_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_15:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-1M1 holds Y <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X implies (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-1M1 holds Y <>HIDDENR2 {}XBOOLE-0K1 implies  not (x inHIDDENR3 X &  not (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using funct_2_def_1 sorry
    thus " not (x inHIDDENR3 X &  not (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x))"
      using funct_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies (rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y iff ( for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 implies ( for g be FunctionFUNCT-2M1-of(Y,Z) holds  for h be FunctionFUNCT-2M1-of(Y,Z) holds g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f =RELSET-1R2\<^bsub>(X,Z)\<^esub> h *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f implies g =RELSET-1R2\<^bsub>(Y,Z)\<^esub> h)))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies (rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y implies ( for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 implies ( for g be FunctionFUNCT-2M1-of(Y,Z) holds  for h be FunctionFUNCT-2M1-of(Y,Z) holds g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f =RELSET-1R2\<^bsub>(X,Z)\<^esub> h *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f implies g =RELSET-1R2\<^bsub>(Y,Z)\<^esub> h))) & (( for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 implies ( for g be FunctionFUNCT-2M1-of(Y,Z) holds  for h be FunctionFUNCT-2M1-of(Y,Z) holds g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f =RELSET-1R2\<^bsub>(X,Z)\<^esub> h *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f implies g =RELSET-1R2\<^bsub>(Y,Z)\<^esub> h)) implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1"
    show "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y implies ( for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 implies ( for g be FunctionFUNCT-2M1-of(Y,Z) holds  for h be FunctionFUNCT-2M1-of(Y,Z) holds g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f =RELSET-1R2\<^bsub>(X,Z)\<^esub> h *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f implies g =RELSET-1R2\<^bsub>(Y,Z)\<^esub> h))"
    proof-
      have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y implies ( for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 implies ( for g be FunctionFUNCT-2M1-of(Y,Z) holds  for h be FunctionFUNCT-2M1-of(Y,Z) holds  not (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f =RELSET-1R2\<^bsub>(X,Z)\<^esub> h *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f &  not g =RELSET-1R2\<^bsub>(Y,Z)\<^esub> h)))"
      proof(rule impI,rule ballI,rule impI,rule ballI,rule ballI)
        assume A2: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume A3: "Z <>HIDDENR2 {}XBOOLE-0K1"
        fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
        fix h assume [ty]: "h be FunctionFUNCT-2M1-of(Y,Z)"
        have "domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y & domRELSET-1K1\<^bsub>(Y)\<^esub> h =XBOOLE-0R4 Y"
          using A3 funct_2_def_1 sorry
        thus " not (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f =RELSET-1R2\<^bsub>(X,Z)\<^esub> h *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f &  not g =RELSET-1R2\<^bsub>(Y,Z)\<^esub> h)"
          using A2 funct_1_th_86 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A4: " for Z be setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 implies ( for g be FunctionFUNCT-2M1-of(Y,Z) holds  for h be FunctionFUNCT-2M1-of(Y,Z) holds g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f =RELSET-1R2\<^bsub>(X,Z)\<^esub> h *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f implies g =RELSET-1R2\<^bsub>(Y,Z)\<^esub> h)"
    have " for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (domRELAT-1K1 g =XBOOLE-0R4 Y & domRELAT-1K1 h =XBOOLE-0R4 Y) & g *FUNCT-1K3 f =FUNCT-1R1 h *FUNCT-1K3 f implies g =FUNCT-1R1 h"
    proof-
      have " for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 g =XBOOLE-0R4 Y & domRELAT-1K1 h =XBOOLE-0R4 Y implies  not (g *FUNCT-1K3 f =FUNCT-1R1 h *FUNCT-1K3 f &  not g =FUNCT-1R1 h)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix g assume [ty]: "g be FunctionFUNCT-1M1"
        fix h assume [ty]: "h be FunctionFUNCT-1M1"
        assume A5: "domRELAT-1K1 g =XBOOLE-0R4 Y"
          and A6: "domRELAT-1K1 h =XBOOLE-0R4 Y"
        have A7: "rngFUNCT-1K2 g <>HIDDENR2 {}XBOOLE-0K1"
          using A1 A5 relat_1_th_42 sorry
        have A8: "g be FunctionFUNCT-2M1-of(Y,rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 h)"
          using A5 funct_2_th_2 xboole_1_th_7 sorry
        have "h be FunctionFUNCT-2M1-of(Y,rngFUNCT-1K2 g \\/XBOOLE-0K2 rngFUNCT-1K2 h)"
          using A6 funct_2_th_2 xboole_1_th_7 sorry
        thus " not (g *FUNCT-1K3 f =FUNCT-1R1 h *FUNCT-1K3 f &  not g =FUNCT-1R1 h)"
          using A4 A7 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
      using funct_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_17:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be RelationRELSET-1M1-of(X,Y) holds idPARTFUN1K6 X *RELSET-1K4\<^bsub>(X,X,X,Y)\<^esub> f =RELSET-1R2\<^bsub>(X,Y)\<^esub> f & f *RELSET-1K4\<^bsub>(X,Y,Y,Y)\<^esub> idPARTFUN1K6 Y =RELSET-1R2\<^bsub>(X,Y)\<^esub> f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be RelationRELSET-1M1-of(X,Y) holds idPARTFUN1K6 X *RELSET-1K4\<^bsub>(X,X,X,Y)\<^esub> f =RELSET-1R2\<^bsub>(X,Y)\<^esub> f & f *RELSET-1K4\<^bsub>(X,Y,Y,Y)\<^esub> idPARTFUN1K6 Y =RELSET-1R2\<^bsub>(X,Y)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be RelationRELSET-1M1-of(X,Y)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f c=TARSKIR1 X"
       sorry
    thus "idPARTFUN1K6 X *RELSET-1K4\<^bsub>(X,X,X,Y)\<^esub> f =RELSET-1R2\<^bsub>(X,Y)\<^esub> f"
      using relat_1_th_51 sorry
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Y"
       sorry
    thus "f *RELSET-1K4\<^bsub>(X,Y,Y,Y)\<^esub> idPARTFUN1K6 Y =RELSET-1R2\<^bsub>(X,Y)\<^esub> f"
      using relat_1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_18:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds f *PARTFUN1K1\<^bsub>(Y,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Y,Y)\<^esub> idPARTFUN1K6 Y implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds f *PARTFUN1K1\<^bsub>(Y,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Y,Y)\<^esub> idPARTFUN1K6 Y implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    assume "f *PARTFUN1K1\<^bsub>(Y,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Y,Y)\<^esub> idPARTFUN1K6 Y"
    then have "rngRELSET-1K2\<^bsub>(Y)\<^esub> (f *PARTFUN1K1\<^bsub>(Y,X,X,Y)\<^esub> g) =XBOOLE-0R4 Y"
       sorry
    then have "Y c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
      using relat_1_th_26 sorry
    thus "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_19:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies (f be one-to-oneFUNCT-1V2 iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies  not (f be one-to-oneFUNCT-1V2 &  not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) &  not x1 =HIDDENR1 x2))) &  not (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) &  not x1 =HIDDENR1 x2)) &  not f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not (f be one-to-oneFUNCT-1V2 &  not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) &  not x1 =HIDDENR1 x2))) &  not (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) &  not x1 =HIDDENR1 x2)) &  not f be one-to-oneFUNCT-1V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_20:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies Y =XBOOLE-0R4 {}XBOOLE-0K1) & g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f be one-to-oneFUNCT-1V2 implies f be one-to-oneFUNCT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds Z <>HIDDENR2 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1 implies  not (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f be one-to-oneFUNCT-1V2 &  not f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
    assume "Z <>HIDDENR2 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A1: "Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Y)\<^esub> g"
      using funct_2_def_1 sorry
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Y"
       sorry
    thus " not (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f be one-to-oneFUNCT-1V2 &  not f be one-to-oneFUNCT-1V2)"
      using A1 funct_1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_21:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies (f be one-to-oneFUNCT-1V2 iff ( for Z be setHIDDENM2 holds  for g be FunctionFUNCT-2M1-of(Z,X) holds  for h be FunctionFUNCT-2M1-of(Z,X) holds f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> h implies g =RELSET-1R2\<^bsub>(Z,X)\<^esub> h))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies (f be one-to-oneFUNCT-1V2 implies ( for Z be setHIDDENM2 holds  for g be FunctionFUNCT-2M1-of(Z,X) holds  for h be FunctionFUNCT-2M1-of(Z,X) holds f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> h implies g =RELSET-1R2\<^bsub>(Z,X)\<^esub> h)) & (( for Z be setHIDDENM2 holds  for g be FunctionFUNCT-2M1-of(Z,X) holds  for h be FunctionFUNCT-2M1-of(Z,X) holds f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> h implies g =RELSET-1R2\<^bsub>(Z,X)\<^esub> h) implies f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
    have A3: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using A2 funct_2_def_1 sorry
    show "f be one-to-oneFUNCT-1V2 implies ( for Z be setHIDDENM2 holds  for g be FunctionFUNCT-2M1-of(Z,X) holds  for h be FunctionFUNCT-2M1-of(Z,X) holds f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> h implies g =RELSET-1R2\<^bsub>(Z,X)\<^esub> h)"
    proof-
      have "f be one-to-oneFUNCT-1V2 implies ( for Z be setHIDDENM2 holds  for g be FunctionFUNCT-2M1-of(Z,X) holds  for h be FunctionFUNCT-2M1-of(Z,X) holds  not (f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> h &  not g =RELSET-1R2\<^bsub>(Z,X)\<^esub> h))"
      proof(rule impI,rule ballI,rule ballI,rule ballI)
        assume A4: "f be one-to-oneFUNCT-1V2"
        fix Z assume [ty]: "Z be setHIDDENM2"
        fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Z,X)"
        fix h assume [ty]: "h be FunctionFUNCT-2M1-of(Z,X)"
        have A5: "rngRELSET-1K2\<^bsub>(X)\<^esub> g c=TARSKIR1 X & rngRELSET-1K2\<^bsub>(X)\<^esub> h c=TARSKIR1 X"
           sorry
        have "domRELSET-1K1\<^bsub>(Z)\<^esub> g =XBOOLE-0R4 Z & domRELSET-1K1\<^bsub>(Z)\<^esub> h =XBOOLE-0R4 Z"
          using A1 funct_2_def_1 sorry
        thus " not (f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> h &  not g =RELSET-1R2\<^bsub>(Z,X)\<^esub> h)"
          using A3 A4 A5 funct_1_th_27 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A6: " for Z be setHIDDENM2 holds  for g be FunctionFUNCT-2M1-of(Z,X) holds  for h be FunctionFUNCT-2M1-of(Z,X) holds f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> g =RELSET-1R2\<^bsub>(Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(Z,X,X,Y)\<^esub> h implies g =RELSET-1R2\<^bsub>(Z,X)\<^esub> h"
    have " for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (rngFUNCT-1K2 g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f & rngFUNCT-1K2 h c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f) & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h implies (f *FUNCT-1K3 g =FUNCT-1R1 f *FUNCT-1K3 h implies g =FUNCT-1R1 h)"
    proof(rule ballI,rule ballI,rule impI)
      fix g assume [ty]: "g be FunctionFUNCT-1M1"
      fix h assume [ty]: "h be FunctionFUNCT-1M1"
      assume "(rngFUNCT-1K2 g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f & rngFUNCT-1K2 h c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f) & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h"
      then have "g be FunctionFUNCT-2M1-of(domRELAT-1K1 g,X) & h be FunctionFUNCT-2M1-of(domRELAT-1K1 g,X)"
        using A3 funct_2_th_2 sorry
      thus "f *FUNCT-1K3 g =FUNCT-1R1 f *FUNCT-1K3 h implies g =FUNCT-1R1 h"
        using A6 sorry
    qed "sorry"
    thus "f be one-to-oneFUNCT-1V2"
      using funct_1_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds (Z <>HIDDENR2 {}XBOOLE-0K1 & rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) =XBOOLE-0R4 Z) & g be one-to-oneFUNCT-1V2 implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds Z <>HIDDENR2 {}XBOOLE-0K1 & (rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) =XBOOLE-0R4 Z & g be one-to-oneFUNCT-1V2) implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
    assume A1: "Z <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) =XBOOLE-0R4 Z"
      and A3: "g be one-to-oneFUNCT-1V2"
    have A4: "domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
      using A1 funct_2_def_1 sorry
    have "rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) c=TARSKIR1 rngRELSET-1K2\<^bsub>(Z)\<^esub> g"
      using relat_1_th_26 sorry
    then have "rngRELSET-1K2\<^bsub>(Z)\<^esub> g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
      using A2 sorry
    then have "Y c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
      using A3 A4 funct_1_th_29 sorry
    thus "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_2_def_3 ("ontoFUNCT-2V2\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "Y be setHIDDENM2"
"attr ontoFUNCT-2V2\<^bsub>(Y)\<^esub> for Y -valuedRELAT-1V5\<bar>RelationRELAT-1M1 means
  (\<lambda>f. rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y)"..

mtheorem funct_2_th_23:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X implies f be one-to-oneFUNCT-1V2 & g be ontoFUNCT-2V2\<^bsub>(X)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X implies f be one-to-oneFUNCT-1V2 & g be ontoFUNCT-2V2\<^bsub>(X)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    assume A1: "g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
    show "f be one-to-oneFUNCT-1V2"
    proof-
      show "f be one-to-oneFUNCT-1V2"
      proof-
        have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies f be one-to-oneFUNCT-1V2"
        proof(rule impI)
          assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
          thus "f be one-to-oneFUNCT-1V2"
             sorry
        qed
        have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies f be one-to-oneFUNCT-1V2"
        proof(rule impI)
          assume "Y <>HIDDENR2 {}XBOOLE-0K1"
          then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
            using funct_2_def_1 sorry
          thus "f be one-to-oneFUNCT-1V2"
            using A1 funct_1_th_31 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have "rngRELSET-1K2\<^bsub>(X)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f) =XBOOLE-0R4 X"
      using A1 sorry
    then have Cut578: "X c=TARSKIR1 rngRELSET-1K2\<^bsub>(X)\<^esub> g"
      using relat_1_th_26 sorry
    have "rngRELSET-1K2\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
    proof-
      show "rngRELSET-1K2\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
        using Cut578 sorry
    qed
    thus "g be ontoFUNCT-2V2\<^bsub>(X)\<^esub>"
      using funct_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_24:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds ((Z =XBOOLE-0R4 {}XBOOLE-0K1 implies Y =XBOOLE-0R4 {}XBOOLE-0K1) & g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f be one-to-oneFUNCT-1V2) & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y implies f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds Z <>HIDDENR2 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ((g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f be one-to-oneFUNCT-1V2 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y) &  not (f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
    assume "Z <>HIDDENR2 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Y)\<^esub> g"
      using funct_2_def_1 sorry
    thus " not ((g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f be one-to-oneFUNCT-1V2 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y) &  not (f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2))"
      using funct_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_25:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds f be one-to-oneFUNCT-1V2 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y implies f \<inverse>FUNCT-1K4 be FunctionFUNCT-2M1-of(Y,X)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds f be one-to-oneFUNCT-1V2 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y implies f \<inverse>FUNCT-1K4 be FunctionFUNCT-2M1-of(Y,X)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
    have A3: "rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (f \<inverse>FUNCT-1K4)"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
          using A1 funct_1_th_33 sorry
        thus "x inHIDDENR3 X"
           sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    have "domRELAT-1K1 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 Y"
      using A1 A2 funct_1_th_33 sorry
    then obtain R where 
      [ty]:"R be RelationRELSET-1M1-of(Y,X)" and RDef:"R = f \<inverse>FUNCT-1K4"
      using A3 relset_1_th_4 sorry
    have "R be quasi-totalFUNCT-2V1\<^bsub>(Y,X)\<^esub>"
    proof-
      have "X <>HIDDENR2 {}XBOOLE-0K1 & Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Y)\<^esub> R or X =XBOOLE-0R4 {}XBOOLE-0K1 & (X =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 {}XBOOLE-0K1)"
      proof-
        show "X <>HIDDENR2 {}XBOOLE-0K1 & Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Y)\<^esub> R or X =XBOOLE-0R4 {}XBOOLE-0K1 & (X =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 {}XBOOLE-0K1)"
        proof-
          have cases: "X <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
             sorry
          have case1: "X <>HIDDENR2 {}XBOOLE-0K1 implies Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Y)\<^esub> R"
          proof(rule impI)
            assume "X <>HIDDENR2 {}XBOOLE-0K1"
            show "Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Y)\<^esub> R"
              using A1 A2 funct_1_th_33 sorry
          qed
          have case2: "X =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 {}XBOOLE-0K1"
          proof(rule impI)
            assume "X =XBOOLE-0R4 {}XBOOLE-0K1"
            then have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1"
               sorry
            then have "domRELAT-1K1 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 {}XBOOLE-0K1"
              using A1 funct_1_th_32 sorry
            thus "R =RELAT-1R1 {}XBOOLE-0K1"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    thus "f \<inverse>FUNCT-1K4 be FunctionFUNCT-2M1-of(Y,X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_26:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y <>HIDDENR2 {}XBOOLE-0K1 & f be one-to-oneFUNCT-1V2) & x inHIDDENR3 X implies f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x) =HIDDENR1 x"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies  not ((f be one-to-oneFUNCT-1V2 & x inHIDDENR3 X) &  not f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x) =HIDDENR1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not ((f be one-to-oneFUNCT-1V2 & x inHIDDENR3 X) &  not f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x) =HIDDENR1 x)"
      using funct_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_27:
" for X be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds f be ontoFUNCT-2V2\<^bsub>(Y)\<^esub> & g be ontoFUNCT-2V2\<^bsub>(Z)\<^esub> implies g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f be ontoFUNCT-2V2\<^bsub>(Z)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
  fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
  assume A1: "f be ontoFUNCT-2V2\<^bsub>(Y)\<^esub>"
    and A2: "g be ontoFUNCT-2V2\<^bsub>(Z)\<^esub>"
  have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =HIDDENR1 Y"
    using A1 sorry
  also have "... = domRELSET-1K1\<^bsub>(Y)\<^esub> g"
    using funct_2_def_1 sorry
  finally have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =HIDDENR1 domRELSET-1K1\<^bsub>(Y)\<^esub> g"
     sorry
  then have "rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) =HIDDENR1 rngRELSET-1K2\<^bsub>(Z)\<^esub> g"
    using relat_1_th_28 sorry
  also have "... = Z"
    using A2 sorry
  finally have "rngRELSET-1K2\<^bsub>(Z)\<^esub> (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f) =HIDDENR1 Z"
     sorry
  thus "g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f be ontoFUNCT-2V2\<^bsub>(Z)\<^esub>"
     sorry
qed "sorry"

mtheorem funct_2_th_28:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds (((X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1) & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y) & f be one-to-oneFUNCT-1V2) & ( for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds y inHIDDENR3 Y & g .FUNCT-1K1 y =HIDDENR1 x iff x inHIDDENR3 X & f .FUNCT-1K1 x =HIDDENR1 y) implies g =FUNCT-1R1 f \<inverse>FUNCT-1K4"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies  not (((rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y & f be one-to-oneFUNCT-1V2) & ( for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  not ((y inHIDDENR3 Y & g .FUNCT-1K1 y =HIDDENR1 x) &  not (x inHIDDENR3 X & f .FUNCT-1K1 x =HIDDENR1 y)) &  not ((x inHIDDENR3 X & f .FUNCT-1K1 x =HIDDENR1 y) &  not (y inHIDDENR3 Y & g .FUNCT-1K1 y =HIDDENR1 x)))) &  not g =FUNCT-1R1 f \<inverse>FUNCT-1K4)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    assume "X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    thus " not (((rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y & f be one-to-oneFUNCT-1V2) & ( for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  not ((y inHIDDENR3 Y & g .FUNCT-1K1 y =HIDDENR1 x) &  not (x inHIDDENR3 X & f .FUNCT-1K1 x =HIDDENR1 y)) &  not ((x inHIDDENR3 X & f .FUNCT-1K1 x =HIDDENR1 y) &  not (y inHIDDENR3 Y & g .FUNCT-1K1 y =HIDDENR1 x)))) &  not g =FUNCT-1R1 f \<inverse>FUNCT-1K4)"
      using funct_1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_29:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y <>HIDDENR2 {}XBOOLE-0K1 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y) & f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K4 *FUNCT-1K3 f =FUNCT-1R1 idPARTFUN1K6 X & f *FUNCT-1K3 f \<inverse>FUNCT-1K4 =FUNCT-1R1 idPARTFUN1K6 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies  not ((rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y & f be one-to-oneFUNCT-1V2) &  not (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f =FUNCT-1R1 idPARTFUN1K6 X & f *FUNCT-1K3 f \<inverse>FUNCT-1K4 =FUNCT-1R1 idPARTFUN1K6 Y))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not ((rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y & f be one-to-oneFUNCT-1V2) &  not (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f =FUNCT-1R1 idPARTFUN1K6 X & f *FUNCT-1K3 f \<inverse>FUNCT-1K4 =FUNCT-1R1 idPARTFUN1K6 Y))"
      using funct_1_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_30:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds (((X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1) & rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y) & g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X) & f be one-to-oneFUNCT-1V2 implies g =FUNCT-1R1 f \<inverse>FUNCT-1K4"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies  not (((rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y & g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X) & f be one-to-oneFUNCT-1V2) &  not g =FUNCT-1R1 f \<inverse>FUNCT-1K4)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    assume "X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    thus " not (((rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y & g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X) & f be one-to-oneFUNCT-1V2) &  not g =FUNCT-1R1 f \<inverse>FUNCT-1K4)"
      using funct_1_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_31:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 & ( ex g be FunctionFUNCT-2M1-of(Y,X) st g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X) implies f be one-to-oneFUNCT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies (( ex g be FunctionFUNCT-2M1-of(Y,X) st g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X) implies f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    assume Given: " ex g be FunctionFUNCT-2M1-of(Y,X) st g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
    then obtain g where
      [ty]:"g be FunctionFUNCT-2M1-of(Y,X)" and 
      A2: "g *PARTFUN1K1\<^bsub>(X,Y,Y,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
       sorry
    show "f be one-to-oneFUNCT-1V2"
      using A2 A1 funct_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_32:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & Z c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(X,Y)\<^esub> Z be FunctionFUNCT-2M1-of(Z,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & Z c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(X,Y)\<^esub> Z be FunctionFUNCT-2M1-of(Z,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
      and A2: "Z c=TARSKIR1 X"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using A1 funct_2_def_1 sorry
    then have A3: "Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(X,Y)\<^esub> Z)"
      using A2 relat_1_th_62 sorry
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> (f  |PARTFUN1K2\<^bsub>(X,Y)\<^esub> Z) c=TARSKIR1 Y"
       sorry
    then obtain R where 
      [ty]:"R be RelationRELSET-1M1-of(Z,Y)" and RDef:"R = f  |PARTFUN1K2\<^bsub>(X,Y)\<^esub> Z"
      using A3 relset_1_th_4 sorry
    have "R be quasi-totalFUNCT-2V1\<^bsub>(Z,Y)\<^esub>"
    proof-
      have "Y <>HIDDENR2 {}XBOOLE-0K1 & Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Z)\<^esub> R or Y =XBOOLE-0R4 {}XBOOLE-0K1 & (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 {}XBOOLE-0K1)"
      proof-
        show "Y <>HIDDENR2 {}XBOOLE-0K1 & Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Z)\<^esub> R or Y =XBOOLE-0R4 {}XBOOLE-0K1 & (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 {}XBOOLE-0K1)"
        proof-
          have cases: "Y <>HIDDENR2 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
             sorry
          have case1: "Y <>HIDDENR2 {}XBOOLE-0K1 implies Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Z)\<^esub> R"
          proof(rule impI)
            assume "Y <>HIDDENR2 {}XBOOLE-0K1"
            have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
              using A1 funct_2_def_1 sorry
            thus "Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Z)\<^esub> R"
              using A2 relat_1_th_62 sorry
          qed
          have case2: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies R =RELAT-1R1 {}XBOOLE-0K1"
          proof(rule impI)
            assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
            thus "R =RELAT-1R1 {}XBOOLE-0K1"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    thus "f  |PARTFUN1K2\<^bsub>(X,Y)\<^esub> Z be FunctionFUNCT-2M1-of(Z,Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_33:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds X c=TARSKIR1 Z implies f  |PARTFUN1K2\<^bsub>(X,Y)\<^esub> Z =RELSET-1R2\<^bsub>(X,Y)\<^esub> f"
  using relset_1_th_19 sorry

mtheorem funct_2_th_34:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X) & f .FUNCT-1K1 x inTARSKIR2 Z implies (Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X) & f .FUNCT-1K1 x inTARSKIR2 Z implies (Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X"
      and A2: "f .FUNCT-1K1 x inTARSKIR2 Z"
    have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using A1 funct_2_def_1 sorry
    then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f)"
      using A2 funct_1_th_54 sorry
    thus "(Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using funct_1_th_55 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_35:
" for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for y be objectHIDDENM1 holds ( ex x be objectHIDDENM1 st (x inHIDDENR3 X & x inHIDDENR3 P) & y =HIDDENR1 f .FUNCT-1K1 x) implies y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P)"
proof-
  have " for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for y be objectHIDDENM1 holds ( ex x be objectHIDDENM1 st (x inHIDDENR3 X & x inHIDDENR3 P) & y =HIDDENR1 f .FUNCT-1K1 x) implies y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix P assume [ty]: "P be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    fix y assume [ty]: "y be objectHIDDENM1"
    assume Given: " ex x be objectHIDDENM1 st (x inHIDDENR3 X & x inHIDDENR3 P) & y =HIDDENR1 f .FUNCT-1K1 x"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "(x inHIDDENR3 X & x inHIDDENR3 P) & y =HIDDENR1 f .FUNCT-1K1 x"
       sorry
    show "y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P"
      using A1 A2 funct_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_36:
" for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P c=TARSKIR1 Y"
   sorry

(*\$CT*)
mtheorem funct_2_th_38:
" for Q be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q iff x inHIDDENR3 X & f .FUNCT-1K1 x inTARSKIR2 Q)"
proof-
  have " for Q be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q &  not (x inHIDDENR3 X & f .FUNCT-1K1 x inTARSKIR2 Q)) &  not ((x inHIDDENR3 X & f .FUNCT-1K1 x inTARSKIR2 Q) &  not x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Q assume [ty]: "Q be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " for x be objectHIDDENM1 holds  not (x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q &  not (x inHIDDENR3 X & f .FUNCT-1K1 x inTARSKIR2 Q)) &  not ((x inHIDDENR3 X & f .FUNCT-1K1 x inTARSKIR2 Q) &  not x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q)"
      using funct_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_39:
" for Q be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q c=TARSKIR1 X"
   sorry

mtheorem funct_2_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1 implies f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f /\\SUBSET-1K8\<^bsub>(Y)\<^esub> Y =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
      using xboole_1_th_28 sorry
    then have A1: "f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (rngRELSET-1K2\<^bsub>(Y)\<^esub> f)"
      using relat_1_th_133 sorry
    assume "Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus "f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 X"
      using A1 relat_1_th_134 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1) iff rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
  using funct_1_th_73 funct_1_th_72 sorry

mtheorem funct_2_th_42:
" for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & P c=TARSKIR1 X implies P c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P)"
proof-
  have " for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1 implies  not (P c=TARSKIR1 X &  not P c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix P assume [ty]: "P be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not (P c=TARSKIR1 X &  not P c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P))"
      using funct_1_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_43:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1 implies f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    then have "f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (rngRELSET-1K2\<^bsub>(Y)\<^esub> f) =XBOOLE-0R4 X"
      using relat_1_th_134 sorry
    thus "f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X) =XBOOLE-0R4 X"
      using A1 relat_1_th_113 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_44:
" for Q be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds (Z =XBOOLE-0R4 {}XBOOLE-0K1 implies Y =XBOOLE-0R4 {}XBOOLE-0K1) implies f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q c=TARSKIR1 (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(X,Z)\<^esub> (g .:RELSET-1K7\<^bsub>(Y,Z)\<^esub> Q)"
proof-
  have " for Q be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds Z <>HIDDENR2 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1 implies f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q c=TARSKIR1 (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(X,Z)\<^esub> (g .:RELSET-1K7\<^bsub>(Y,Z)\<^esub> Q)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Q assume [ty]: "Q be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
    assume "Z <>HIDDENR2 {}XBOOLE-0K1 or Y =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A1: "domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Y"
       sorry
    thus "f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Q c=TARSKIR1 (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(X,Z)\<^esub> (g .:RELSET-1K7\<^bsub>(Y,Z)\<^esub> Q)"
      using A1 funct_1_th_90 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_45:
" for P be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of({}XBOOLE-0K1,Y) holds f .:RELSET-1K7\<^bsub>({}XBOOLE-0K1,Y)\<^esub> P =FUNCT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem funct_2_th_46:
" for Q be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of({}XBOOLE-0K1,Y) holds f \<inverse>RELSET-1K8\<^bsub>({}XBOOLE-0K1,Y)\<^esub> Q =FUNCT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem funct_2_th_47:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies f .FUNCT-1K1 x inTARSKIR2 Y"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies f .FUNCT-1K1 x inTARSKIR2 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f =XBOOLE-0R4 {TARSKIK1 x}"
      using funct_2_def_1 sorry
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Y"
       sorry
    then have "{TARSKIK1 f .FUNCT-1K1 x } c=TARSKIR1 Y"
      using A1 funct_1_th_4 sorry
    thus "f .FUNCT-1K1 x inTARSKIR2 Y"
      using zfmisc_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_48:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y)"
    assume "Y <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f =XBOOLE-0R4 {TARSKIK1 x}"
      using funct_2_def_1 sorry
    thus "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
      using funct_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_49:
" for P be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y) holds Y <>HIDDENR2 {}XBOOLE-0K1 implies f .:RELSET-1K7\<^bsub>({TARSKIK1 x},Y)\<^esub> P c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x }"
proof-
  have " for P be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y) holds  not ( not Y <>HIDDENR2 {}XBOOLE-0K1 &  not f .:RELSET-1K7\<^bsub>({TARSKIK1 x},Y)\<^esub> P c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x })"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix P assume [ty]: "P be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of({TARSKIK1 x},Y)"
    have "f .:RELSET-1K7\<^bsub>({TARSKIK1 x},Y)\<^esub> P c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
      using relat_1_th_111 sorry
    thus " not ( not Y <>HIDDENR2 {}XBOOLE-0K1 &  not f .:RELSET-1K7\<^bsub>({TARSKIK1 x},Y)\<^esub> P c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x })"
      using funct_2_th_48 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_50:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,{TARSKIK1 y}) holds x inHIDDENR3 X implies f .FUNCT-1K1 x =HIDDENR1 y"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of(X,{TARSKIK1 y}) holds  not (x inHIDDENR3 X &  not f .FUNCT-1K1 x =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,{TARSKIK1 y})"
    have "x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 y}"
      using funct_2_th_5 sorry
    thus " not (x inHIDDENR3 X &  not f .FUNCT-1K1 x =HIDDENR1 y)"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_51:
" for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for f1 be FunctionFUNCT-2M1-of(X,{TARSKIK1 y}) holds  for f2 be FunctionFUNCT-2M1-of(X,{TARSKIK1 y}) holds f1 =RELSET-1R2\<^bsub>(X,{TARSKIK1 y})\<^esub> f2"
proof-
  have " for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for f1 be FunctionFUNCT-2M1-of(X,{TARSKIK1 y}) holds  for f2 be FunctionFUNCT-2M1-of(X,{TARSKIK1 y}) holds f1 =RELSET-1R2\<^bsub>(X,{TARSKIK1 y})\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(X,{TARSKIK1 y})"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(X,{TARSKIK1 y})"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 X"
      then have "f1 .FUNCT-1K1 x =HIDDENR1 y"
        using funct_2_th_50 sorry
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        using A1 funct_2_th_50 sorry
    qed "sorry"
    thus "f1 =RELSET-1R2\<^bsub>(X,{TARSKIK1 y})\<^esub> f2"
      using funct_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_52:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "X =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    thus " for f be FunctionFUNCT-2M1-of(X,X) holds domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_cl_10:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "f be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>\<bar>PartFuncPARTFUN1M1-of(X,Y)", "g be quasi-totalFUNCT-2V1\<^bsub>(X,X)\<^esub>\<bar>PartFuncPARTFUN1M1-of(X,X)"
"cluster f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g as-term-is quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g implies it be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
    proof-
      show " for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
      proof-
        have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies ( for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>))"
        proof(rule impI)
          assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
          thus " for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
             sorry
        qed
        have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>))"
        proof(rule impI)
          assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1"
          then have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
            using funct_2_def_1 sorry
          then have "domRELSET-1K1\<^bsub>(X)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g) =HIDDENR1 g \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> X"
            using relat_1_th_147 sorry
          also have "... = domRELSET-1K1\<^bsub>(X)\<^esub> g"
            using relset_1_th_22 sorry
          also have "... = X"
            using funct_2_th_52 sorry
          finally have "domRELSET-1K1\<^bsub>(X)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g) =HIDDENR1 X"
             sorry
          thus " for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
            using A1 funct_2_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_cl_11:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "f be quasi-totalFUNCT-2V1\<^bsub>(Y,Y)\<^esub>\<bar>PartFuncPARTFUN1M1-of(Y,Y)", "g be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>\<bar>PartFuncPARTFUN1M1-of(X,Y)"
"cluster f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g as-term-is quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub> for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g implies it be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
    proof-
      show " for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
      proof-
        have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies ( for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>))"
        proof(rule impI)
          assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
          thus " for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
             sorry
        qed
        have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>))"
        proof(rule impI)
          assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1"
          have "domRELSET-1K1\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
            using funct_2_th_52 sorry
          then have "domRELSET-1K1\<^bsub>(X)\<^esub> (f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g) =HIDDENR1 g \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y"
            using relat_1_th_147 sorry
          also have "... = domRELSET-1K1\<^bsub>(X)\<^esub> g"
            using relset_1_th_22 sorry
          also have "... = X"
            using A1 funct_2_def_1 sorry
          finally have "domRELSET-1K1\<^bsub>(X)\<^esub> (f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g) =HIDDENR1 X"
             sorry
          thus " for VarFor1 be PartFuncPARTFUN1M1-of(X,Y) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,Y,Y,Y)\<^esub> g &  not VarFor1 be quasi-totalFUNCT-2V1\<^bsub>(X,Y)\<^esub>)"
            using A1 funct_2_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_th_53:
" for X be setHIDDENM2 holds  for f be RelationRELSET-1M1-of(X,X) holds  for g be RelationRELSET-1M1-of(X,X) holds rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & rngRELSET-1K2\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X implies rngRELSET-1K2\<^bsub>(X)\<^esub> (g *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> f) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for f be RelationRELSET-1M1-of(X,X) holds  for g be RelationRELSET-1M1-of(X,X) holds rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & rngRELSET-1K2\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X implies rngRELSET-1K2\<^bsub>(X)\<^esub> (g *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> f) =HIDDENR1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be RelationRELSET-1M1-of(X,X)"
    fix g assume [ty]: "g be RelationRELSET-1M1-of(X,X)"
    assume A1: "rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      and A2: "rngRELSET-1K2\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
    have "rngRELSET-1K2\<^bsub>(X)\<^esub> (g *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> f) =HIDDENR1 f .:RELSET-1K7\<^bsub>(X,X)\<^esub> X"
      using A2 relat_1_th_127 sorry
    also have "... = X"
      using A1 relset_1_th_22 sorry
    finally show "rngRELSET-1K2\<^bsub>(X)\<^esub> (g *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> f) =HIDDENR1 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_54:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> f & rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X implies g =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds  not ((g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> f & rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X) &  not g =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,X)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    thus " not ((g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> f & rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X) &  not g =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X)"
      using funct_1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_55:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> g =RELSET-1R2\<^bsub>(X,X)\<^esub> f & f be one-to-oneFUNCT-1V2 implies g =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds  not ((f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> g =RELSET-1R2\<^bsub>(X,X)\<^esub> f & f be one-to-oneFUNCT-1V2) &  not g =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,X)"
    have A1: "rngRELSET-1K2\<^bsub>(X)\<^esub> g c=TARSKIR1 X"
       sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    thus " not ((f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> g =RELSET-1R2\<^bsub>(X,X)\<^esub> f & f be one-to-oneFUNCT-1V2) &  not g =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X)"
      using A1 funct_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_56:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds f be one-to-oneFUNCT-1V2 iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2)"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds  not (f be one-to-oneFUNCT-1V2 &  not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) &  not x1 =HIDDENR1 x2))) &  not (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) &  not x1 =HIDDENR1 x2)) &  not f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,X)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    thus " not (f be one-to-oneFUNCT-1V2 &  not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) &  not x1 =HIDDENR1 x2))) &  not (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) &  not x1 =HIDDENR1 x2)) &  not f be one-to-oneFUNCT-1V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_2_def_4 ("bijectiveFUNCT-2V3\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"attr bijectiveFUNCT-2V3\<^bsub>(X,Y)\<^esub> for X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f. f be one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(Y)\<^esub>)"..

mtheorem funct_2_cl_12:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster bijectiveFUNCT-2V3\<^bsub>(X,Y)\<^esub> also-is one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(Y)\<^esub> for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it be bijectiveFUNCT-2V3\<^bsub>(X,Y)\<^esub> implies it be one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(Y)\<^esub>"
     sorry
qed "sorry"

mtheorem funct_2_cl_13:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(Y)\<^esub> also-is bijectiveFUNCT-2V3\<^bsub>(X,Y)\<^esub> for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Y) holds it be one-to-oneFUNCT-1V2\<bar>ontoFUNCT-2V2\<^bsub>(Y)\<^esub> implies it be bijectiveFUNCT-2V3\<^bsub>(X,Y)\<^esub>"
     sorry
qed "sorry"

mtheorem funct_2_cl_14:
  mlet "X be setHIDDENM2"
"cluster bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub> for FunctionFUNCT-2M1-of(X,X)"
proof
(*existence*)
  show " ex it be FunctionFUNCT-2M1-of(X,X) st it be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>"
  proof-
    have " ex tVar5 be FunctionFUNCT-2M1-of(X,X) st tVar5 be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>"
    proof-
      show " ex tVar5 be FunctionFUNCT-2M1-of(X,X) st tVar5 be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>"
      proof(rule bexI[of _ "idPARTFUN1K6 X"])
        have "idPARTFUN1K6 X be one-to-oneFUNCT-1V2 & rngRELSET-1K2\<^bsub>(X)\<^esub> (idPARTFUN1K6 X) =XBOOLE-0R4 X"
        proof-
          show "idPARTFUN1K6 X be one-to-oneFUNCT-1V2 & rngRELSET-1K2\<^bsub>(X)\<^esub> (idPARTFUN1K6 X) =XBOOLE-0R4 X"
             sorry
        qed
        thus "idPARTFUN1K6 X be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>"
          using funct_2_def_3 funct_2_def_4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax FUNCT_2M2 :: " Set \<Rightarrow> Ty" ("PermutationFUNCT-2M2-of  _ " [70]70)
translations "PermutationFUNCT-2M2-of X" \<rightharpoonup> "bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>\<bar>FunctionFUNCT-2M1-of(X,X)"

mtheorem funct_2_th_57:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds f be one-to-oneFUNCT-1V2 & rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X implies f be PermutationFUNCT-2M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds f be one-to-oneFUNCT-1V2 & rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X implies f be PermutationFUNCT-2M2-of X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,X)"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
    have "f be ontoFUNCT-2V2\<^bsub>(X)\<^esub>"
      using A2 sorry
    thus "f be PermutationFUNCT-2M2-of X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_58:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds f be one-to-oneFUNCT-1V2 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 X & x2 inHIDDENR3 X) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2)"
  using funct_2_th_56 sorry

mtheorem funct_2_cl_15:
  mlet "X be setHIDDENM2", "f be ontoFUNCT-2V2\<^bsub>(X)\<^esub>\<bar>PartFuncPARTFUN1M1-of(X,X)", "g be ontoFUNCT-2V2\<^bsub>(X)\<^esub>\<bar>PartFuncPARTFUN1M1-of(X,X)"
"cluster f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> g as-term-is ontoFUNCT-2V2\<^bsub>(X)\<^esub> for PartFuncPARTFUN1M1-of(X,X)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,X) holds it =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> g implies it be ontoFUNCT-2V2\<^bsub>(X)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(X,X) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> g &  not VarFor1 be ontoFUNCT-2V2\<^bsub>(X)\<^esub>)"
    proof-
      have "rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & rngRELSET-1K2\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
        using funct_2_def_3 sorry
      then have "rngRELSET-1K2\<^bsub>(X)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> g) =XBOOLE-0R4 X"
        using funct_2_th_53 sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(X,X) holds  not (VarFor1 =HIDDENR1 f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> g &  not VarFor1 be ontoFUNCT-2V2\<^bsub>(X)\<^esub>)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_cl_16:
  mlet "X be setHIDDENM2", "f be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>\<bar>FunctionFUNCT-2M1-of(X,X)", "g be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>\<bar>FunctionFUNCT-2M1-of(X,X)"
"cluster g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f as-term-is bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub> for FunctionFUNCT-2M1-of(X,X)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(X,X) holds it =HIDDENR1 g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f implies it be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>"
     sorry
qed "sorry"

mtheorem funct_2_cl_17:
  mlet "X be setHIDDENM2"
"cluster reflexiveRELAT-2V1\<bar>totalPARTFUN1V1\<^bsub>(X)\<^esub> also-is bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub> for FunctionFUNCT-2M1-of(X,X)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(X,X) holds it be reflexiveRELAT-2V1\<bar>totalPARTFUN1V1\<^bsub>(X)\<^esub> implies it be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>"
  proof-
    have " for f be FunctionFUNCT-2M1-of(X,X) holds f be reflexiveRELAT-2V1\<bar>totalPARTFUN1V1\<^bsub>(X)\<^esub> implies f be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,X)"
      assume A1: "f be reflexiveRELAT-2V1\<bar>totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      have A2: "fieldRELAT-1K3 f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f \\/SUBSET-1K4\<^bsub>(X)\<^esub> rngRELSET-1K2\<^bsub>(X)\<^esub> f"
        using relat_1_def_6 sorry
      have "f be one-to-oneFUNCT-1V2 & f be ontoFUNCT-2V2\<^bsub>(X)\<^esub>"
      proof(rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            fix x2 assume [ty]: "x2 be objectHIDDENM1"
            assume A3: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
              and A4: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
              and A5: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
            have "x1 inHIDDENR3 fieldRELAT-1K3 f"
              using A2 A3 xboole_0_def_3 sorry
            then have "[TARSKIK4 x1,x1 ] inHIDDENR3 f"
              using A1 relat_2_def_1 relat_2_def_9 sorry
            then have A6: "x1 =HIDDENR1 f .FUNCT-1K1 x1"
              using A3 funct_1_def_2 sorry
            have "x2 inHIDDENR3 fieldRELAT-1K3 f"
              using A2 A4 xboole_0_def_3 sorry
            then have "[TARSKIK4 x2,x2 ] inHIDDENR3 f"
              using A1 relat_2_def_1 relat_2_def_9 sorry
            thus "x1 =HIDDENR1 x2"
              using A4 A5 A6 funct_1_def_2 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        have "rngRELSET-1K2\<^bsub>(X)\<^esub> f c=TARSKIR1 X & X c=TARSKIR1 rngRELSET-1K2\<^bsub>(X)\<^esub> f"
        proof(rule conjMI)
          show "rngRELSET-1K2\<^bsub>(X)\<^esub> f c=TARSKIR1 X"
             sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X"
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
              using partfun1_def_2 sorry
            then have "x inHIDDENR3 fieldRELAT-1K3 f"
              using A2 xboole_0_def_3 sorry
            then have "[TARSKIK4 x,x ] inHIDDENR3 f"
              using A1 relat_2_def_1 relat_2_def_9 sorry
            thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> f"
              using xtuple_0_def_13 sorry
          qed "sorry"
          thus "X c=TARSKIR1 rngRELSET-1K2\<^bsub>(X)\<^esub> f"
            using tarski_def_3 sorry
        qed
        thus "f be ontoFUNCT-2V2\<^bsub>(X)\<^esub>"
          using xboole_0_def_10 funct_2_def_3 sorry
      qed
      thus "f be bijectiveFUNCT-2V3\<^bsub>(X,X)\<^esub>"
        using funct_2_def_4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax FUNCT_2K2 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ \<inverse>FUNCT-2K2\<^bsub>'( _ ')\<^esub>" [228,0]228)
translations "f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub>" \<rightharpoonup> "f \<inverse>FUNCT-1K4"

mtheorem funct_2_add_1:
  mlet "X be setHIDDENM2", "f be PermutationFUNCT-2M2-of X"
"cluster f \<inverse>FUNCT-1K4 as-term-is PermutationFUNCT-2M2-of X"
proof
(*coherence*)
  show "f \<inverse>FUNCT-1K4 be PermutationFUNCT-2M2-of X"
  proof-
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    then have A1: "rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 X"
      using funct_1_th_33 sorry
    have "rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_3 sorry
    then have "f \<inverse>FUNCT-1K4 be FunctionFUNCT-2M1-of(X,X)"
      using funct_2_th_25 sorry
    thus "f \<inverse>FUNCT-1K4 be PermutationFUNCT-2M2-of X"
      using A1 funct_2_th_57 sorry
  qed
qed "sorry"

mtheorem funct_2_th_59:
" for X be setHIDDENM2 holds  for f be PermutationFUNCT-2M2-of X holds  for g be PermutationFUNCT-2M2-of X holds g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> g implies f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
proof-
  have " for X be setHIDDENM2 holds  for f be PermutationFUNCT-2M2-of X holds  for g be PermutationFUNCT-2M2-of X holds  not (g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> g &  not f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PermutationFUNCT-2M2-of X"
    fix g assume [ty]: "g be PermutationFUNCT-2M2-of X"
    have A1: "rngRELSET-1K2\<^bsub>(X)\<^esub> f c=TARSKIR1 X"
       sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    thus " not (g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> g &  not f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X)"
      using A1 funct_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_60:
" for X be setHIDDENM2 holds  for f be PermutationFUNCT-2M2-of X holds  for g be PermutationFUNCT-2M2-of X holds g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X implies g =RELSET-1R2\<^bsub>(X,X)\<^esub> f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for f be PermutationFUNCT-2M2-of X holds  for g be PermutationFUNCT-2M2-of X holds  not (g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X &  not g =RELSET-1R2\<^bsub>(X,X)\<^esub> f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PermutationFUNCT-2M2-of X"
    fix g assume [ty]: "g be PermutationFUNCT-2M2-of X"
    have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    have "rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
      using funct_2_def_3 funct_2_th_52 sorry
    thus " not (g *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X &  not g =RELSET-1R2\<^bsub>(X,X)\<^esub> f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub>)"
      using A1 funct_1_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_61:
" for X be setHIDDENM2 holds  for f be PermutationFUNCT-2M2-of X holds f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X & f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
proof-
  have " for X be setHIDDENM2 holds  for f be PermutationFUNCT-2M2-of X holds f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X & f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PermutationFUNCT-2M2-of X"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X & rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_3 funct_2_th_52 sorry
    thus "f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X & f *PARTFUN1K1\<^bsub>(X,X,X,X)\<^esub> f \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
      using funct_1_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_62:
" for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for f be PermutationFUNCT-2M2-of X holds P c=TARSKIR1 X implies f .:RELSET-1K7\<^bsub>(X,X)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> P =XBOOLE-0R4 P & f \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> (f .:RELSET-1K7\<^bsub>(X,X)\<^esub> P) =XBOOLE-0R4 P"
proof-
  have " for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for f be PermutationFUNCT-2M2-of X holds P c=TARSKIR1 X implies f .:RELSET-1K7\<^bsub>(X,X)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> P =XBOOLE-0R4 P & f \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> (f .:RELSET-1K7\<^bsub>(X,X)\<^esub> P) =XBOOLE-0R4 P"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix P assume [ty]: "P be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PermutationFUNCT-2M2-of X"
    assume A1: "P c=TARSKIR1 X"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    then have A2: "P c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> (f .:RELSET-1K7\<^bsub>(X,X)\<^esub> P)"
      using A1 funct_1_th_76 sorry
    have "f \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> (f .:RELSET-1K7\<^bsub>(X,X)\<^esub> P) c=TARSKIR1 P & rngRELSET-1K2\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_3 funct_1_th_82 sorry
    thus "f .:RELSET-1K7\<^bsub>(X,X)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> P =XBOOLE-0R4 P & f \<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> (f .:RELSET-1K7\<^bsub>(X,X)\<^esub> P) =XBOOLE-0R4 P"
      using A1 A2 funct_1_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem funct_2_cl_18:
  mlet "X be setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Z be setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,D)", "g be FunctionFUNCT-2M1-of(D,Z)"
"cluster g *PARTFUN1K1\<^bsub>(X,D,D,Z)\<^esub> f as-term-is quasi-totalFUNCT-2V1\<^bsub>(X,Z)\<^esub> for PartFuncPARTFUN1M1-of(X,Z)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(X,Z) holds it =HIDDENR1 g *PARTFUN1K1\<^bsub>(X,D,D,Z)\<^esub> f implies it be quasi-totalFUNCT-2V1\<^bsub>(X,Z)\<^esub>"
    using funct_2_th_13 sorry
qed "sorry"

syntax FUNCT_2K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .FUNCT-2K3\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c" \<rightharpoonup> "f .FUNCT-1K1 c"

mtheorem funct_2_add_2:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "c be ElementSUBSET-1M1-of C"
"cluster f .FUNCT-1K1 c as-term-is ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show "f .FUNCT-1K1 c be ElementSUBSET-1M1-of D"
  proof-
    have "D be  non emptyXBOOLE-0V1 or D be emptyXBOOLE-0V1"
       sorry
    thus "f .FUNCT-1K1 c be ElementSUBSET-1M1-of D"
      using funct_2_th_5 subset_1_def_1 sorry
  qed
qed "sorry"

theorem funct_2_sch_3:
  fixes Cf0 Df0 Pp2 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: " for x be ElementSUBSET-1M1-of Cf0 holds  ex y be ElementSUBSET-1M1-of Df0 st Pp2(x,y)"
  shows " ex f be FunctionFUNCT-2M1-of(Cf0,Df0) st  for x be ElementSUBSET-1M1-of Cf0 holds Pp2(x,f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x)"
  proof-
    have " ex tVar6 be FunctionFUNCT-2M1-of(Cf0,Df0) st  for x be ElementSUBSET-1M1-of Cf0 holds Pp2(x,tVar6 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x)"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 inHIDDENR3 Cf0 & Lamb2 inHIDDENR3 Df0) & Pp2(Lamb1,Lamb2)"
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Cf0 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Df0 & ?R(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Cf0 implies  not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Df0 & ((x inHIDDENR3 Cf0 & y inHIDDENR3 Df0) & Pp2(x,y))))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 Cf0"
          then have " ex y be ElementSUBSET-1M1-of Df0 st Pp2(x,y)"
            using A1 sorry
          thus " not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Df0 & ((x inHIDDENR3 Cf0 & y inHIDDENR3 Df0) & Pp2(x,y))))"
            using A3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(Cf0,Df0)" and 
        A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Cf0 implies ?R(x,f .FUNCT-1K1 x)"
        using funct_2_sch_1 A2 sorry
      show " ex tVar6 be FunctionFUNCT-2M1-of(Cf0,Df0) st  for x be ElementSUBSET-1M1-of Cf0 holds Pp2(x,tVar6 .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x)"
      proof(rule bexI[of _ "f"],rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Cf0"
        show "Pp2(x,f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x)"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem funct_2_sch_4:
  fixes Cf0 Df0 Ff1 
  assumes
[ty]: "Cf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be ElementSUBSET-1M1-of Cf0 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Df0"
  shows " ex f be FunctionFUNCT-2M1-of(Cf0,Df0) st  for x be ElementSUBSET-1M1-of Cf0 holds f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =XBOOLE-0R4 Ff1(x)"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =XBOOLE-0R4 Ff1(Lamb1)"
    have A1: " for x be ElementSUBSET-1M1-of Cf0 holds  ex y be ElementSUBSET-1M1-of Df0 st ?P(x,y)"
       sorry
    show " ex f be FunctionFUNCT-2M1-of(Cf0,Df0) st  for x be ElementSUBSET-1M1-of Cf0 holds f .FUNCT-2K3\<^bsub>(Cf0,Df0)\<^esub> x =XBOOLE-0R4 Ff1(x)"
      using funct_2_sch_3 A1 sorry
  qed

mtheorem funct_2_th_63:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,Y) holds  for f2 be FunctionFUNCT-2M1-of(X,Y) holds ( for x be ElementSUBSET-1M1-of X holds f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x) implies f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(X,Y) holds  for f2 be FunctionFUNCT-2M1-of(X,Y) holds ( for x be ElementSUBSET-1M1-of X holds f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x) implies f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(X,Y)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(X,Y)"
    assume " for x be ElementSUBSET-1M1-of X holds f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
    then have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
       sorry
    thus "f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> f2"
      using funct_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_64:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for y be objectHIDDENM1 holds y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P implies ( ex x be objectHIDDENM1 st (x inHIDDENR3 X & x inHIDDENR3 P) & y =HIDDENR1 f .FUNCT-1K1 x)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for y be objectHIDDENM1 holds y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P implies ( ex tVar7 be objectHIDDENM1 st tVar7 inTARSKIR2 X & (tVar7 inHIDDENR3 P & y =HIDDENR1 f .FUNCT-1K1 tVar7))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P assume [ty]: "P be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"and A2: "x inHIDDENR3 P & y =HIDDENR1 f .FUNCT-1K1 x"
      using funct_1_def_6 sorry
    have 
      [ty]:"x be setHIDDENM2"
      using tarski_th_1 sorry
    show " ex tVar7 be objectHIDDENM1 st tVar7 inTARSKIR2 X & (tVar7 inHIDDENR3 P & y =HIDDENR1 f .FUNCT-1K1 tVar7)"
    proof(rule bexI[of _ "x"],rule conjMI)
      show "x inTARSKIR2 X"
        using A1 sorry
      show "x inHIDDENR3 P & y =HIDDENR1 f .FUNCT-1K1 x"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_65:
" for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for y be objectHIDDENM1 holds y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P implies ( ex c be ElementSUBSET-1M1-of X st c inTARSKIR2 P & y =HIDDENR1 f .FUNCT-1K1 c)"
proof-
  have " for P be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for y be objectHIDDENM1 holds y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P implies ( ex tVar8 be ElementSUBSET-1M1-of X st tVar8 inTARSKIR2 P & y =HIDDENR1 f .FUNCT-1K1 tVar8)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix P assume [ty]: "P be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> P"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"and A2: "x inHIDDENR3 P & y =HIDDENR1 f .FUNCT-1K1 x"
      using funct_2_th_64 sorry
    obtain c where 
      [ty]:"c be ElementSUBSET-1M1-of X" and cDef:"c = x"
      using A1 sorry
    show " ex tVar8 be ElementSUBSET-1M1-of X st tVar8 inTARSKIR2 P & y =HIDDENR1 f .FUNCT-1K1 tVar8"
    proof(rule bexI[of _ "c"])
      show "c inTARSKIR2 P & y =HIDDENR1 f .FUNCT-1K1 c"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem funct_2_th_66:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be setHIDDENM2 holds f inTARSKIR2 FuncsFUNCT-2K1(X,Y) implies f be FunctionFUNCT-2M1-of(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be setHIDDENM2 holds f inTARSKIR2 FuncsFUNCT-2K1(X,Y) implies f be FunctionFUNCT-2M1-of(X,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be setHIDDENM2"
    assume "f inTARSKIR2 FuncsFUNCT-2K1(X,Y)"
    then have " not (Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1) & ( ex f9 be FunctionFUNCT-1M1 st (f9 =XBOOLE-0R4 f & domRELAT-1K1 f9 =XBOOLE-0R4 X) & rngFUNCT-1K2 f9 c=TARSKIR1 Y)"
      using funct_2_def_2 sorry
    thus "f be FunctionFUNCT-2M1-of(X,Y)"
      using funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem funct_2_sch_5:
  fixes Af0 Bf0 Ff1 Gf1 Cp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (Cp1(x) implies Ff1(x) inHIDDENR3 Bf0) & ( not Cp1(x) implies Gf1(x) inHIDDENR3 Bf0)"
  shows " ex f be FunctionFUNCT-2M1-of(Af0,Bf0) st  for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x))"
  proof-
    have " not ( for f be FunctionFUNCT-2M1-of(Af0,Bf0) holds  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 &  not ( not (Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Gf1(x))))))"
    proof-
      have A2: "Bf0 =XBOOLE-0R4 {}XBOOLE-0K1 implies (Af0 <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
      proof(rule impI,rule impI)
        let ?x = "the ElementSUBSET-1M1-of Af0"
        assume A3: "Bf0 =XBOOLE-0R4 {}XBOOLE-0K1"
        assume A4: "Af0 <>HIDDENR2 {}XBOOLE-0K1"
        then have "Cp1(?x) implies Ff1(?x) inHIDDENR3 Bf0"
          using A1 sorry
        thus " False "
          using A1 A3 A4 sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A5: "domRELAT-1K1 f =XBOOLE-0R4 Af0"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x))"
        using partfun1_sch_1 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 Bf0"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 Bf0"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 rngFUNCT-1K2 f"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A7: "x inHIDDENR3 domRELAT-1K1 f"and A8: "y =HIDDENR1 f .FUNCT-1K1 x"
            using funct_1_def_3 sorry
          have A9: " not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x)"
            using A5 A6 A7 sorry
          have "Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
            using A5 A6 A7 sorry
          thus "y inHIDDENR3 Bf0"
            using A1 A5 A7 A8 A9 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 f c=TARSKIR1 Bf0"
          using tarski_def_3 sorry
      qed
      then have "f be FunctionFUNCT-2M1-of(Af0,Bf0)"
        using A5 A2 funct_2_def_1 relset_1_th_4 sorry
      thus " not ( for f be FunctionFUNCT-2M1-of(Af0,Bf0) holds  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 &  not ( not (Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Gf1(x))))))"
        using A6 sorry
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem funct_2_th_67:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X implies f be FunctionFUNCT-2M1-of(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  not (domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X &  not f be FunctionFUNCT-2M1-of(X,Y))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Y"
       sorry
    thus " not (domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X &  not f be FunctionFUNCT-2M1-of(X,Y))"
      using funct_2_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_68:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f be totalPARTFUN1V1\<^bsub>(X)\<^esub> implies f be FunctionFUNCT-2M1-of(X,Y)"
   sorry

mtheorem funct_2_th_69:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f be FunctionFUNCT-2M1-of(X,Y) implies f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
   sorry

mtheorem funct_2_th_70:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies <:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
   sorry

mtheorem funct_2_cl_19:
  mlet "X be setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,X)"
"cluster <:PARTFUN1K3 f,X,X :> as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "<:PARTFUN1K3 f,X,X :> be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem funct_2_th_71:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies ( ex g be FunctionFUNCT-2M1-of(X,Y) st  for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies ( ex tVar9 be FunctionFUNCT-2M1-of(X,Y) st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not tVar9 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    assume A1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    show " ex tVar9 be FunctionFUNCT-2M1-of(X,Y) st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not tVar9 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x)"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar9 be FunctionFUNCT-2M1-of(X,Y) st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not tVar9 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x))"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        then obtain g where 
          [ty]:"g be FunctionFUNCT-2M1-of(X,Y)" and gDef:"g = f"
          using A1 sorry
        show " ex tVar9 be FunctionFUNCT-2M1-of(X,Y) st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not tVar9 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x)"
        proof(rule bexI[of _ "g"])
          show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x)"
             sorry
        qed "sorry"
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar10 be FunctionFUNCT-2M1-of(X,Y) st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not tVar10 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x))"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1"
        let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
        let ?y = "the ElementSUBSET-1M1-of Y"
        let ?G = "\<lambda>Lamb1. ?y"
        have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (?P(x) implies ?F(x) inTARSKIR2 Y) & ( not ?P(x) implies ?G(x) inTARSKIR2 Y)"
          using A2 partfun1_th_4 sorry
        obtain g where
          [ty]:"g be FunctionFUNCT-2M1-of(X,Y)" and 
          A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (?P(x) implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)) & ( not ?P(x) implies g .FUNCT-1K1 x =XBOOLE-0R4 ?G(x))"
          using funct_2_sch_5 A3 sorry
        show " ex tVar10 be FunctionFUNCT-2M1-of(X,Y) st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not tVar10 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x)"
        proof(rule bexI[of _ "g"])
          show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x)"
            using A4 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_72:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds FuncsFUNCT-2K1(X,Y) c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds FuncsFUNCT-2K1(X,Y) c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(X,Y) implies x inHIDDENR3 PFuncsPARTFUN1K4(X,Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
      then have " ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y"
        using funct_2_def_2 sorry
      thus "x inHIDDENR3 PFuncsPARTFUN1K4(X,Y)"
        using partfun1_def_3 sorry
    qed "sorry"
    thus "FuncsFUNCT-2K1(X,Y) c=TARSKIR1 PFuncsPARTFUN1K4(X,Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_73:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g implies f =RELSET-1R2\<^bsub>(X,Y)\<^esub> g"
  using partfun1_th_66 sorry

mtheorem funct_2_th_74:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds f toleratesPARTFUN1R1 g implies f =RELSET-1R2\<^bsub>(X,X)\<^esub> g"
  using partfun1_th_66 sorry

mtheorem funct_2_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies (f toleratesPARTFUN1R1 g iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies  not (f toleratesPARTFUN1R1 g &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))) &  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)) &  not f toleratesPARTFUN1R1 g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,Y)"
    assume "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> g =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    thus " not (f toleratesPARTFUN1R1 g &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))) &  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)) &  not f toleratesPARTFUN1R1 g)"
      using partfun1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_76:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds f toleratesPARTFUN1R1 g iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds  not (f toleratesPARTFUN1R1 g &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))) &  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)) &  not f toleratesPARTFUN1R1 g)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,X)"
    have "X =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    thus " not (f toleratesPARTFUN1R1 g &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))) &  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)) &  not f toleratesPARTFUN1R1 g)"
      using funct_2_th_75 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_77:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies ( ex g be FunctionFUNCT-2M1-of(X,Y) st f toleratesPARTFUN1R1 g)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies ( ex tVar11 be FunctionFUNCT-2M1-of(X,Y) st f toleratesPARTFUN1R1 tVar11)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    assume A1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    then obtain g where
      [ty]:"g be FunctionFUNCT-2M1-of(X,Y)" and 
      A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using funct_2_th_71 sorry
    show " ex tVar11 be FunctionFUNCT-2M1-of(X,Y) st f toleratesPARTFUN1R1 tVar11"
    proof(rule bexI[of _ "g"])
      show "f toleratesPARTFUN1R1 g"
        using A1 A2 funct_2_th_75 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_78:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,X) holds  for g be PartFuncPARTFUN1M1-of(X,X) holds  for h be FunctionFUNCT-2M1-of(X,X) holds f toleratesPARTFUN1R1 h & g toleratesPARTFUN1R1 h implies f toleratesPARTFUN1R1 g"
  using partfun1_th_67 sorry

mtheorem funct_2_th_79:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g implies ( ex h be FunctionFUNCT-2M1-of(X,Y) st f toleratesPARTFUN1R1 h & g toleratesPARTFUN1R1 h)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g implies  not ( for h be FunctionFUNCT-2M1-of(X,Y) holds  not (f toleratesPARTFUN1R1 h & g toleratesPARTFUN1R1 h))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    assume "(Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g"
    then have " ex h be PartFuncPARTFUN1M1-of(X,Y) st (h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h"
      using partfun1_th_68 sorry
    thus " not ( for h be FunctionFUNCT-2M1-of(X,Y) holds  not (f toleratesPARTFUN1R1 h & g toleratesPARTFUN1R1 h))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_80:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g implies g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
  using partfun1_def_5 sorry

mtheorem funct_2_th_81:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds f toleratesPARTFUN1R1 g implies g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,X)\<^esub> f"
  using partfun1_def_5 sorry

mtheorem funct_2_th_82:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be setHIDDENM2 holds g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies g be FunctionFUNCT-2M1-of(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be setHIDDENM2 holds g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies g be FunctionFUNCT-2M1-of(X,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be setHIDDENM2"
    assume "g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
    then have " ex g9 be PartFuncPARTFUN1M1-of(X,Y) st (g9 =XBOOLE-0R4 g & g9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g9"
      using partfun1_def_5 sorry
    thus "g be FunctionFUNCT-2M1-of(X,Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_83:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    show "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 or (Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1)"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1"
        thus "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1 implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
      proof(rule impI)
        assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
        have " for g be objectHIDDENM1 holds g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies g inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
        proof(rule ballI,rule impI)
          fix g assume [ty]: "g be objectHIDDENM1"
          assume "g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
          then have "g be FunctionFUNCT-2M1-of(X,Y)"
            using funct_2_th_82 sorry
          thus "g inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
            using A1 funct_2_th_8 sorry
        qed "sorry"
        thus "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
          using tarski_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_84:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) =XBOOLE-0R4 FuncsFUNCT-2K1(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) =XBOOLE-0R4 FuncsFUNCT-2K1(X,Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) =XBOOLE-0R4 FuncsFUNCT-2K1(X,Y)"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 or (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1)"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) =XBOOLE-0R4 FuncsFUNCT-2K1(X,Y)"
      proof(rule impI)
        assume A1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1"
        then have "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) =XBOOLE-0R4 {}XBOOLE-0K1"
           sorry
        thus "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) =XBOOLE-0R4 FuncsFUNCT-2K1(X,Y)"
          using A1 sorry
      qed
      have case2: "(Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) =XBOOLE-0R4 FuncsFUNCT-2K1(X,Y)"
      proof(rule impI)
        assume A2: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
        have " for g be objectHIDDENM1 holds g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) iff g inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
        proof-
          have " for g be objectHIDDENM1 holds (g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) implies g inHIDDENR3 FuncsFUNCT-2K1(X,Y)) & (g inHIDDENR3 FuncsFUNCT-2K1(X,Y) implies g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>))"
          proof(rule ballI,rule conjMI,rule impI)
            fix g assume [ty]: "g be objectHIDDENM1"
            show "g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) implies g inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
            proof(rule impI)
              assume "g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>)"
              then have "g be FunctionFUNCT-2M1-of(X,Y)"
                using funct_2_th_82 sorry
              thus "g inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
                using A2 funct_2_th_8 sorry
            qed
            assume A3: "g inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
            then obtain g9 where 
              [ty]:"g9 be PartFuncPARTFUN1M1-of(X,Y)" and g9Def:"g9 = g"
              using funct_2_th_66 sorry
            have A4: "<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> toleratesPARTFUN1R1 g9"
              using partfun1_th_60 sorry
            have "g be FunctionFUNCT-2M1-of(X,Y)"
              using A3 funct_2_th_66 sorry
            thus "g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>)"
              using A2 A4 partfun1_def_5 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>) =XBOOLE-0R4 FuncsFUNCT-2K1(X,Y)"
          using tarski_th_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_85:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =XBOOLE-0R4 {TARSKIK1 f}"
  using partfun1_th_72 sorry

mtheorem funct_2_th_86:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds TotFuncsPARTFUN1K5\<^bsub>(X,X)\<^esub> (<:PARTFUN1K3 f,X,X :>) =XBOOLE-0R4 {TARSKIK1 f}"
  using partfun1_th_72 sorry

mtheorem funct_2_th_87:
" for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds  for g be FunctionFUNCT-2M1-of(X,{TARSKIK1 y}) holds TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f =XBOOLE-0R4 {TARSKIK1 g}"
proof-
  have " for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds  for g be FunctionFUNCT-2M1-of(X,{TARSKIK1 y}) holds TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f =XBOOLE-0R4 {TARSKIK1 g}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y})"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,{TARSKIK1 y})"
    have " for h be objectHIDDENM1 holds h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f iff h =HIDDENR1 g"
    proof-
      have " for h be objectHIDDENM1 holds (h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f implies h =HIDDENR1 g) &  not (h =HIDDENR1 g &  not h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f)"
      proof(rule ballI,rule conjMI)
        fix h assume [ty]: "h be objectHIDDENM1"
        show "h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f implies h =HIDDENR1 g"
        proof(rule impI)
          assume "h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f"
          then have "h be FunctionFUNCT-2M1-of(X,{TARSKIK1 y})"
            using funct_2_th_82 sorry
          thus "h =HIDDENR1 g"
            using funct_2_th_51 sorry
        qed
        have "f toleratesPARTFUN1R1 g"
          using partfun1_th_61 sorry
        thus " not (h =HIDDENR1 g &  not h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f)"
          using partfun1_def_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "TotFuncsPARTFUN1K5\<^bsub>(X,{TARSKIK1 y})\<^esub> f =XBOOLE-0R4 {TARSKIK1 g}"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_88:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    assume A1: "g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
    have " for h be objectHIDDENM1 holds h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
    proof(rule ballI,rule impI)
      fix h assume [ty]: "h be objectHIDDENM1"
      assume A2: "h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
      then obtain h9 where 
        [ty]:"h9 be PartFuncPARTFUN1M1-of(X,Y)" and h9Def:"h9 = h"
        using partfun1_th_69 sorry
      have A3: "h9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
        using A2 partfun1_th_70 sorry
      have "g toleratesPARTFUN1R1 h9"
        using A1 A2 partfun1_th_58 partfun1_th_71 sorry
      thus "h inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
        using A3 partfun1_def_5 sorry
    qed "sorry"
    thus "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_89:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f & TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g implies g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f implies  not (TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g &  not g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    assume A1: "domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
    have " not (TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g &  not g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f)"
    proof-
      show " not (TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g &  not g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f)"
      proof-
        have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 or (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1)"
           sorry
        have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 implies  not (TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g &  not g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f)"
        proof(rule impI)
          assume "Y =XBOOLE-0R4 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1"
          thus " not (TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g &  not g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f)"
             sorry
        qed
        have case2: "(Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) implies (TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g implies g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f)"
        proof(rule impI)
          assume A2: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
          show "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g implies g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
          proof(rule impI)
            assume A3: "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              obtain h where
                [ty]:"h be FunctionFUNCT-2M1-of(X,Y)" and 
                A4: "f toleratesPARTFUN1R1 h"
                using A2 funct_2_th_77 sorry
              have "h inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
                using A2 A4 partfun1_def_5 sorry
              then have A5: "g toleratesPARTFUN1R1 h"
                using A3 partfun1_th_71 sorry
              assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> g"
                using A1 xboole_0_def_4 sorry
              thus "g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
                using A5 A2 A4 partfun1_th_67 partfun1_def_4 sorry
            qed "sorry"
            thus "g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
              using A1 grfunc_1_th_2 sorry
          qed
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g &  not g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_90:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g & ( for y be objectHIDDENM1 holds Y <>HIDDENR2 {TARSKIK1 y}) implies g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g & ( for y be objectHIDDENM1 holds Y <>HIDDENR2 {TARSKIK1 y}) implies g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    assume A1: "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f c=TARSKIR1 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
      and A2: " for y be objectHIDDENM1 holds Y <>HIDDENR2 {TARSKIK1 y}"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
    proof-
      show "domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      proof-
        have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
        proof(rule impI)
          assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
          thus "domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
             sorry
        qed
        have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
        proof(rule impI)
          assume A3: "Y <>HIDDENR2 {}XBOOLE-0K1"
          show "domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
          proof-
            let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1"
            let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies  False "
            proof(rule ballI,rule impMI ,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                and A5: " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
              have A6: "Y <>HIDDENR2 {TARSKIK1 g .FUNCT-1K1 x }"
                using A2 sorry
              have "g .FUNCT-1K1 x inTARSKIR2 Y"
                using A4 partfun1_th_4 sorry
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A7: "y inHIDDENR3 Y"and A8: "y <>HIDDENR2 g .FUNCT-1K1 x"
                using A6 zfmisc_1_th_35 sorry
              let ?G = "\<lambda>Lamb1. y"
              have A9: " for x9 be objectHIDDENM1 holds x9 inHIDDENR3 X implies (?P(x9) implies ?F(x9) inTARSKIR2 Y) & ( not ?P(x9) implies ?G(x9) inHIDDENR3 Y)"
                using A7 partfun1_th_4 sorry
              obtain h where
                [ty]:"h be FunctionFUNCT-2M1-of(X,Y)" and 
                A10: " for x9 be objectHIDDENM1 holds x9 inHIDDENR3 X implies (?P(x9) implies h .FUNCT-1K1 x9 =XBOOLE-0R4 ?F(x9)) & ( not ?P(x9) implies h .FUNCT-1K1 x9 =HIDDENR1 ?G(x9))"
                using funct_2_sch_5 A9 sorry
              have "f toleratesPARTFUN1R1 h"
              proof-
                have " for x9 be objectHIDDENM1 holds x9 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> h implies f .FUNCT-1K1 x9 =HIDDENR1 h .FUNCT-1K1 x9"
                proof(rule ballI,rule impI)
                  fix x9 assume [ty]: "x9 be objectHIDDENM1"
                  assume "x9 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> h"
                  then have "x9 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
                    using xboole_0_def_4 sorry
                  thus "f .FUNCT-1K1 x9 =HIDDENR1 h .FUNCT-1K1 x9"
                    using A10 sorry
                qed "sorry"
                thus "f toleratesPARTFUN1R1 h"
                  using partfun1_def_4 sorry
              qed
              then have A11: "h inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
                using A3 partfun1_def_5 sorry
              have "x inHIDDENR3 X"
                using A4 sorry
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> h"
                using A3 funct_2_def_1 sorry
              then have A12: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> h"
                using A4 xboole_0_def_4 sorry
              have "h .FUNCT-1K1 x =HIDDENR1 y"
                using A4 A5 A10 sorry
              thus " False "
                using A8 A11 A12 A1 partfun1_th_71 partfun1_def_4 sorry
            qed "sorry"
            thus "domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
              using tarski_def_3 sorry
          qed
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
      using A1 funct_2_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_91:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds ( for y be objectHIDDENM1 holds Y <>HIDDENR2 {TARSKIK1 y}) & TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f =XBOOLE-0R4 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g implies f =RELSET-1R2\<^bsub>(X,Y)\<^esub> g"
  using funct_2_th_90 sorry

mtheorem funct_2_cl_20:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that  non emptyXBOOLE-0V1 for FunctionFUNCT-2M1-of(A,B)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(A,B) holds it be  non emptyXBOOLE-0V1"
    using funct_2_def_1 relat_1_th_38 sorry
qed "sorry"

(*begin*)
theorem funct_2_sch_6:
  fixes Df0 Rf0 Af0 Bf0 Ff1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Rf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Rf0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Rf0"
  shows " ex f be FunctionFUNCT-2M1-of(Df0,Rf0) st f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> Af0 =XBOOLE-0R4 Bf0 & ( for x be ElementSUBSET-1M1-of Df0 holds x <>HIDDENR2 Af0 implies f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x =XBOOLE-0R4 Ff1(x))"
  proof-
    have " ex tVar12 be FunctionFUNCT-2M1-of(Df0,Rf0) st tVar12 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> Af0 =XBOOLE-0R4 Bf0 & ( for x be ElementSUBSET-1M1-of Df0 holds  not ( not x <>HIDDENR2 Af0 &  not tVar12 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x =XBOOLE-0R4 Ff1(x)))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 =XBOOLE-0R4 Af0 implies Lamb2 =XBOOLE-0R4 Bf0) & (Lamb1 <>HIDDENR2 Af0 implies Lamb2 =XBOOLE-0R4 Ff1(Lamb1))"
      have A1: " for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Rf0 st ?P(x,y)"
      proof-
        have " for x be ElementSUBSET-1M1-of Df0 holds  not ( for y be ElementSUBSET-1M1-of Rf0 holds  not ((x =XBOOLE-0R4 Af0 implies y =XBOOLE-0R4 Bf0) & (x <>HIDDENR2 Af0 implies y =XBOOLE-0R4 Ff1(x))))"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of Df0"
          have "x =XBOOLE-0R4 Af0 implies  not ( for y be ElementSUBSET-1M1-of Rf0 holds  not ?P(x,y))"
             sorry
          thus " not ( for y be ElementSUBSET-1M1-of Rf0 holds  not ((x =XBOOLE-0R4 Af0 implies y =XBOOLE-0R4 Bf0) & (x <>HIDDENR2 Af0 implies y =XBOOLE-0R4 Ff1(x))))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(Df0,Rf0)" and 
        A2: " for x be ElementSUBSET-1M1-of Df0 holds ?P(x,f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x)"
        using funct_2_sch_3 A1 sorry
      show " ex tVar12 be FunctionFUNCT-2M1-of(Df0,Rf0) st tVar12 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> Af0 =XBOOLE-0R4 Bf0 & ( for x be ElementSUBSET-1M1-of Df0 holds  not ( not x <>HIDDENR2 Af0 &  not tVar12 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x =XBOOLE-0R4 Ff1(x)))"
      proof(rule bexI[of _ "f"])
        show "f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> Af0 =XBOOLE-0R4 Bf0 & ( for x be ElementSUBSET-1M1-of Df0 holds  not ( not x <>HIDDENR2 Af0 &  not f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x =XBOOLE-0R4 Ff1(x)))"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem funct_2_sch_7:
  fixes Df0 Rf0 A1f0 A2f0 B1f0 B2f0 Ff1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Rf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "A1f0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "A2f0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "B1f0 be ElementSUBSET-1M1-of Rf0" and
  [ty]: "B2f0 be ElementSUBSET-1M1-of Rf0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Rf0" and
   A1: "A1f0 <>HIDDENR2 A2f0"
  shows " ex f be FunctionFUNCT-2M1-of(Df0,Rf0) st (f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> A1f0 =XBOOLE-0R4 B1f0 & f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> A2f0 =XBOOLE-0R4 B2f0) & ( for x be ElementSUBSET-1M1-of Df0 holds x <>HIDDENR2 A1f0 & x <>HIDDENR2 A2f0 implies f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x =XBOOLE-0R4 Ff1(x))"
  proof-
    have " ex tVar13 be FunctionFUNCT-2M1-of(Df0,Rf0) st (tVar13 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> A1f0 =XBOOLE-0R4 B1f0 & tVar13 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> A2f0 =XBOOLE-0R4 B2f0) & ( for x be ElementSUBSET-1M1-of Df0 holds  not (( not x <>HIDDENR2 A1f0 &  not x <>HIDDENR2 A2f0) &  not tVar13 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x =XBOOLE-0R4 Ff1(x)))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. ((Lamb1 =XBOOLE-0R4 A1f0 implies Lamb2 =XBOOLE-0R4 B1f0) & (Lamb1 =XBOOLE-0R4 A2f0 implies Lamb2 =XBOOLE-0R4 B2f0)) & (Lamb1 <>HIDDENR2 A1f0 & Lamb1 <>HIDDENR2 A2f0 implies Lamb2 =XBOOLE-0R4 Ff1(Lamb1))"
      have A2: " for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Rf0 st ?P(x,y)"
      proof-
        have " for x be ElementSUBSET-1M1-of Df0 holds  not ( for y be ElementSUBSET-1M1-of Rf0 holds  not (((x =XBOOLE-0R4 A1f0 implies y =XBOOLE-0R4 B1f0) & (x =XBOOLE-0R4 A2f0 implies y =XBOOLE-0R4 B2f0)) & (x <>HIDDENR2 A1f0 & x <>HIDDENR2 A2f0 implies y =XBOOLE-0R4 Ff1(x))))"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of Df0"
          have A3: "x =XBOOLE-0R4 A2f0 implies  not ( for y be ElementSUBSET-1M1-of Rf0 holds  not ?P(x,y))"
            using A1 sorry
          have "x =XBOOLE-0R4 A1f0 implies  not ( for y be ElementSUBSET-1M1-of Rf0 holds  not ?P(x,y))"
            using A1 sorry
          thus " not ( for y be ElementSUBSET-1M1-of Rf0 holds  not (((x =XBOOLE-0R4 A1f0 implies y =XBOOLE-0R4 B1f0) & (x =XBOOLE-0R4 A2f0 implies y =XBOOLE-0R4 B2f0)) & (x <>HIDDENR2 A1f0 & x <>HIDDENR2 A2f0 implies y =XBOOLE-0R4 Ff1(x))))"
            using A3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(Df0,Rf0)" and 
        A4: " for x be ElementSUBSET-1M1-of Df0 holds ?P(x,f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x)"
        using funct_2_sch_3 A2 sorry
      show " ex tVar13 be FunctionFUNCT-2M1-of(Df0,Rf0) st (tVar13 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> A1f0 =XBOOLE-0R4 B1f0 & tVar13 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> A2f0 =XBOOLE-0R4 B2f0) & ( for x be ElementSUBSET-1M1-of Df0 holds  not (( not x <>HIDDENR2 A1f0 &  not x <>HIDDENR2 A2f0) &  not tVar13 .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x =XBOOLE-0R4 Ff1(x)))"
      proof(rule bexI[of _ "f"])
        show "(f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> A1f0 =XBOOLE-0R4 B1f0 & f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> A2f0 =XBOOLE-0R4 B2f0) & ( for x be ElementSUBSET-1M1-of Df0 holds  not (( not x <>HIDDENR2 A1f0 &  not x <>HIDDENR2 A2f0) &  not f .FUNCT-2K3\<^bsub>(Df0,Rf0)\<^esub> x =XBOOLE-0R4 Ff1(x)))"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem funct_2_th_92:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 FuncsFUNCT-2K1(A,B) implies domRELAT-1K1 f =XBOOLE-0R4 A & rngFUNCT-1K2 f c=TARSKIR1 B"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  assume "f inTARSKIR2 FuncsFUNCT-2K1(A,B)"
  then have " ex g be FunctionFUNCT-1M1 st (f =FUNCT-1R1 g & domRELAT-1K1 g =XBOOLE-0R4 A) & rngFUNCT-1K2 g c=TARSKIR1 B"
    using funct_2_def_2 sorry
  thus "domRELAT-1K1 f =XBOOLE-0R4 A & rngFUNCT-1K2 f c=TARSKIR1 B"
     sorry
qed "sorry"

theorem funct_2_sch_8:
  fixes Xf0 Yf0 Ff1 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: " for x be ElementSUBSET-1M1-of Xf0 holds Ff1(x) inHIDDENR3 Yf0"
  shows " ex f be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be ElementSUBSET-1M1-of Xf0 holds f .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)"
  proof-
    have " not ( for f be FunctionFUNCT-2M1-of(Xf0,Yf0) holds  not ( for x be ElementSUBSET-1M1-of Xf0 holds f .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Yf0 & ?P(x,y))"
        using A1 sorry
      have " ex f be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ?P(x,f .FUNCT-1K1 x)"
        using funct_2_sch_1 A2 sorry
      then obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(Xf0,Yf0)" and 
        A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
         sorry
      have " for x be ElementSUBSET-1M1-of Xf0 holds f .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)"
        using A3 sorry
      thus " not ( for f be FunctionFUNCT-2M1-of(Xf0,Yf0) holds  not ( for x be ElementSUBSET-1M1-of Xf0 holds f .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem funct_2_sch_9:
  fixes Xf0 Yf0 Ff1 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Yf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: " for x be ElementSUBSET-1M1-of Xf0 holds Ff1(x) be ElementSUBSET-1M1-of Yf0"
  shows " ex f be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be ElementSUBSET-1M1-of Xf0 holds f .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)"
  proof-
    have " ex tVar14 be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be ElementSUBSET-1M1-of Xf0 holds tVar14 .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)"
    proof-
      have A2: " for x be ElementSUBSET-1M1-of Xf0 holds Ff1(x) inHIDDENR3 Yf0"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Xf0"
        have "Ff1(x) be ElementSUBSET-1M1-of Yf0"
          using A1 sorry
        thus "Ff1(x) inHIDDENR3 Yf0"
           sorry
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(Xf0,Yf0)" and 
        A3: " for x be ElementSUBSET-1M1-of Xf0 holds f .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)"
        using funct_2_sch_8 A2 sorry
      show " ex tVar14 be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be ElementSUBSET-1M1-of Xf0 holds tVar14 .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)"
      proof(rule bexI[of _ "f"])
        show " for x be ElementSUBSET-1M1-of Xf0 holds f .FUNCT-2K3\<^bsub>(Xf0,Yf0)\<^esub> x =HIDDENR1 Ff1(x)"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

syntax FUNCT_2K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("pr1FUNCT-2K4\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,228]228)
translations "pr1FUNCT-2K4\<^bsub>(A,B,C)\<^esub> f" \<rightharpoonup> "pr1MCART-1K11 f"

mtheorem funct_2_def_5:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(A,[:ZFMISC-1K2 B,C :])"
"redefine func pr1FUNCT-2K4\<^bsub>(A,B,C)\<^esub> f \<rightarrow> FunctionFUNCT-2M1-of(A,B) means
  \<lambda>it.  for x be ElementSUBSET-1M1-of A holds it .FUNCT-2K3\<^bsub>(A,B)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`1XTUPLE-0K1"
proof
(*compatibility*)
  show " for it be FunctionFUNCT-2M1-of(A,B) holds it =HIDDENR1 pr1FUNCT-2K4\<^bsub>(A,B,C)\<^esub> f iff ( for x be ElementSUBSET-1M1-of A holds it .FUNCT-2K3\<^bsub>(A,B)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`1XTUPLE-0K1)"
  proof-
    have " for IT be FunctionFUNCT-2M1-of(A,B) holds (IT =FUNCT-1R1 pr1MCART-1K11 f implies ( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,B)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`1XTUPLE-0K1)) & (( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,B)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`1XTUPLE-0K1) implies IT =HIDDENR1 pr1MCART-1K11 f)"
    proof(rule ballI,rule conjMI,rule impI)
      fix IT assume [ty]: "IT be FunctionFUNCT-2M1-of(A,B)"
      have A4: "domRELAT-1K1 (pr1MCART-1K11 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(A)\<^esub> f"
        using mcart_1_def_12 sorry
      then have A5: "domRELAT-1K1 (pr1MCART-1K11 f) =XBOOLE-0R4 A"
        using funct_2_def_1 sorry
      thus "IT =FUNCT-1R1 pr1MCART-1K11 f implies ( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,B)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`1XTUPLE-0K1)"
        using A4 mcart_1_def_12 sorry
      assume " for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,B)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`1XTUPLE-0K1"
      then have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> f implies IT .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1"
         sorry
      have "domRELSET-1K1\<^bsub>(A)\<^esub> IT =XBOOLE-0R4 domRELSET-1K1\<^bsub>(A)\<^esub> f"
        using A4 A5 funct_2_def_1 sorry
      thus "IT =HIDDENR1 pr1MCART-1K11 f"
        using A6 mcart_1_def_12 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_add_3:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(A,[:ZFMISC-1K2 B,C :])"
"cluster pr1MCART-1K11 f as-term-is FunctionFUNCT-2M1-of(A,B)"
proof
(*coherence*)
  show "pr1MCART-1K11 f be FunctionFUNCT-2M1-of(A,B)"
  proof-
    have A1: "domRELAT-1K1 (pr1MCART-1K11 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(A)\<^esub> f"
      using mcart_1_def_12 sorry
    have A2: "rngFUNCT-1K2 (pr1MCART-1K11 f) c=TARSKIR1 B"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (pr1MCART-1K11 f) implies x inHIDDENR3 B"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (pr1MCART-1K11 f)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "y inHIDDENR3 domRELAT-1K1 (pr1MCART-1K11 f) & x =HIDDENR1 pr1MCART-1K11 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have "x =HIDDENR1 (f .FUNCT-1K1 y)`1XTUPLE-0K1 & f .FUNCT-1K1 y inTARSKIR2 [:ZFMISC-1K2 B,C :]"
          using A1 A3 funct_2_th_5 mcart_1_def_12 sorry
        thus "x inHIDDENR3 B"
          using mcart_1_th_10 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (pr1MCART-1K11 f) c=TARSKIR1 B"
        using tarski_def_3 sorry
    qed
    have "domRELAT-1K1 (pr1MCART-1K11 f) =XBOOLE-0R4 A"
      using A1 funct_2_def_1 sorry
    thus "pr1MCART-1K11 f be FunctionFUNCT-2M1-of(A,B)"
      using A2 funct_2_th_2 sorry
  qed
qed "sorry"

syntax FUNCT_2K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("pr2FUNCT-2K5\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,228]228)
translations "pr2FUNCT-2K5\<^bsub>(A,B,C)\<^esub> f" \<rightharpoonup> "pr2MCART-1K12 f"

mtheorem funct_2_def_6:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(A,[:ZFMISC-1K2 B,C :])"
"redefine func pr2FUNCT-2K5\<^bsub>(A,B,C)\<^esub> f \<rightarrow> FunctionFUNCT-2M1-of(A,C) means
  \<lambda>it.  for x be ElementSUBSET-1M1-of A holds it .FUNCT-2K3\<^bsub>(A,C)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`2XTUPLE-0K2"
proof
(*compatibility*)
  show " for it be FunctionFUNCT-2M1-of(A,C) holds it =HIDDENR1 pr2FUNCT-2K5\<^bsub>(A,B,C)\<^esub> f iff ( for x be ElementSUBSET-1M1-of A holds it .FUNCT-2K3\<^bsub>(A,C)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`2XTUPLE-0K2)"
  proof-
    have " for IT be FunctionFUNCT-2M1-of(A,C) holds (IT =FUNCT-1R1 pr2MCART-1K12 f implies ( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,C)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`2XTUPLE-0K2)) & (( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,C)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`2XTUPLE-0K2) implies IT =HIDDENR1 pr2MCART-1K12 f)"
    proof(rule ballI,rule conjMI,rule impI)
      fix IT assume [ty]: "IT be FunctionFUNCT-2M1-of(A,C)"
      have A10: "domRELAT-1K1 (pr2MCART-1K12 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(A)\<^esub> f"
        using mcart_1_def_13 sorry
      then have A11: "domRELAT-1K1 (pr2MCART-1K12 f) =XBOOLE-0R4 A"
        using funct_2_def_1 sorry
      thus "IT =FUNCT-1R1 pr2MCART-1K12 f implies ( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,C)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`2XTUPLE-0K2)"
        using A10 mcart_1_def_13 sorry
      assume " for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,C)\<^esub> x =HIDDENR1 (f .FUNCT-2K3\<^bsub>(A,[:ZFMISC-1K2 B,C :])\<^esub> x)`2XTUPLE-0K2"
      then have A12: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> f implies IT .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2"
         sorry
      have "domRELSET-1K1\<^bsub>(A)\<^esub> IT =XBOOLE-0R4 domRELSET-1K1\<^bsub>(A)\<^esub> f"
        using A10 A11 funct_2_def_1 sorry
      thus "IT =HIDDENR1 pr2MCART-1K12 f"
        using A12 mcart_1_def_13 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_2_add_4:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(A,[:ZFMISC-1K2 B,C :])"
"cluster pr2MCART-1K12 f as-term-is FunctionFUNCT-2M1-of(A,C)"
proof
(*coherence*)
  show "pr2MCART-1K12 f be FunctionFUNCT-2M1-of(A,C)"
  proof-
    have A7: "domRELAT-1K1 (pr2MCART-1K12 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(A)\<^esub> f"
      using mcart_1_def_13 sorry
    have A8: "rngFUNCT-1K2 (pr2MCART-1K12 f) c=TARSKIR1 C"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (pr2MCART-1K12 f) implies x inHIDDENR3 C"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (pr2MCART-1K12 f)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A9: "y inHIDDENR3 domRELAT-1K1 (pr2MCART-1K12 f) & x =HIDDENR1 pr2MCART-1K12 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have "x =HIDDENR1 (f .FUNCT-1K1 y)`2XTUPLE-0K2 & f .FUNCT-1K1 y inTARSKIR2 [:ZFMISC-1K2 B,C :]"
          using A7 A9 funct_2_th_5 mcart_1_def_13 sorry
        thus "x inHIDDENR3 C"
          using mcart_1_th_10 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (pr2MCART-1K12 f) c=TARSKIR1 C"
        using tarski_def_3 sorry
    qed
    have "domRELAT-1K1 (pr2MCART-1K12 f) =XBOOLE-0R4 A"
      using A7 funct_2_def_1 sorry
    thus "pr2MCART-1K12 f be FunctionFUNCT-2M1-of(A,C)"
      using A8 funct_2_th_2 sorry
  qed
qed "sorry"

syntax FUNCT_2R1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ =FUNCT-2R1\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [50,0,0,0,0,50]50)
translations "f1 =FUNCT-2R1\<^bsub>(A1,B1,A2,B2)\<^esub> f2" \<rightharpoonup> "f1 =HIDDENR1 f2"

mtheorem funct_2_def_7:
  mlet "A1 be setHIDDENM2", "B1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "A2 be setHIDDENM2", "B2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(A1,B1)", "f2 be FunctionFUNCT-2M1-of(A2,B2)"
"redefine pred f1 =FUNCT-2R1\<^bsub>(A1,B1,A2,B2)\<^esub> f2 means
  A1 =XBOOLE-0R4 A2 & ( for a be ElementSUBSET-1M1-of A1 holds f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a)"
proof
(*compatibility*)
  show "f1 =FUNCT-2R1\<^bsub>(A1,B1,A2,B2)\<^esub> f2 iff A1 =XBOOLE-0R4 A2 & ( for a be ElementSUBSET-1M1-of A1 holds f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a)"
  proof-
    have "(f1 =FUNCT-1R1 f2 implies A1 =XBOOLE-0R4 A2 & ( for a be ElementSUBSET-1M1-of A1 holds f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a)) & (A1 =XBOOLE-0R4 A2 & ( for a be ElementSUBSET-1M1-of A1 holds f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a) implies f1 =HIDDENR1 f2)"
    proof(rule conjMI,rule impMI ,rule impI)
      have A1: "domRELSET-1K1\<^bsub>(A1)\<^esub> f1 =XBOOLE-0R4 A1"
        using funct_2_def_1 sorry
      thus "f1 =FUNCT-1R1 f2 implies A1 =XBOOLE-0R4 A2 & ( for a be ElementSUBSET-1M1-of A1 holds f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a)"
        using funct_2_def_1 sorry
      assume A2: "A1 =XBOOLE-0R4 A2"
        and A3: " for a be ElementSUBSET-1M1-of A1 holds f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a"
      have A4: "domRELSET-1K1\<^bsub>(A2)\<^esub> f2 =XBOOLE-0R4 A2"
        using funct_2_def_1 sorry
      have " for a be objectHIDDENM1 holds a inHIDDENR3 A1 implies f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a"
        using A3 sorry
      thus "f1 =HIDDENR1 f2"
        using A1 A4 A2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax FUNCT_2R2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ =FUNCT-2R2\<^bsub>'( _ , _ ')\<^esub>  _ " [50,0,0,50]50)
translations "f1 =FUNCT-2R2\<^bsub>(A,B)\<^esub> f2" \<rightharpoonup> "f1 =HIDDENR1 f2"

mtheorem funct_2_def_8:
  mlet "A be setHIDDENM2", "B be setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(A,B)", "f2 be FunctionFUNCT-2M1-of(A,B)"
"redefine pred f1 =FUNCT-2R2\<^bsub>(A,B)\<^esub> f2 means
   for a be ElementSUBSET-1M1-of A holds f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a"
proof
(*compatibility*)
  show "f1 =FUNCT-2R2\<^bsub>(A,B)\<^esub> f2 iff ( for a be ElementSUBSET-1M1-of A holds f1 .FUNCT-1K1 a =XBOOLE-0R4 f2 .FUNCT-1K1 a)"
    using funct_2_th_63 sorry
qed "sorry"

mtheorem funct_2_th_93:
" for N be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(N,boolSETFAM-1K9 N) holds  ex R be RelationRELSET-1M2-of N st  for i be setHIDDENM2 holds i inTARSKIR2 N implies ImRELAT-1K12(R,i) =XBOOLE-0R4 f .FUNCT-1K1 i"
proof-
  have " for N be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(N,boolSETFAM-1K9 N) holds  ex tVar15 be RelationRELSET-1M2-of N st  for i be setHIDDENM2 holds  not (i inTARSKIR2 N &  not ImRELAT-1K12(tVar15,i) =XBOOLE-0R4 f .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI)
    fix N assume [ty]: "N be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(N,boolSETFAM-1K9 N)"
    let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1"
    have A1: " for i be ElementSUBSET-1M1-of N holds i inTARSKIR2 [#]SUBSET-1K2 N implies ?F(i) c=TARSKIR1 [#]SUBSET-1K2 N"
    proof-
      have " for i be ElementSUBSET-1M1-of N holds i inTARSKIR2 [#]SUBSET-1K2 N implies f .FUNCT-1K1 i c=TARSKIR1 [#]SUBSET-1K2 N"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of N"
        assume "i inTARSKIR2 [#]SUBSET-1K2 N"
        then have "f .FUNCT-1K1 i inTARSKIR2 boolSETFAM-1K9 N"
          using funct_2_th_5 sorry
        thus "f .FUNCT-1K1 i c=TARSKIR1 [#]SUBSET-1K2 N"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain R where
      [ty]:"R be RelationRELSET-1M2-of [#]SUBSET-1K2 N" and 
      A2: " for i be ElementSUBSET-1M1-of N holds i inTARSKIR2 [#]SUBSET-1K2 N implies ImRELAT-1K12(R,i) =XBOOLE-0R4 ?F(i)"
      using relset_1_sch_3 A1 sorry
    have 
      [ty]:"R be RelationRELSET-1M2-of N"
       sorry
    show " ex tVar15 be RelationRELSET-1M2-of N st  for i be setHIDDENM2 holds  not (i inTARSKIR2 N &  not ImRELAT-1K12(tVar15,i) =XBOOLE-0R4 f .FUNCT-1K1 i)"
    proof(rule bexI[of _ "R"])
      show " for i be setHIDDENM2 holds  not (i inTARSKIR2 N &  not ImRELAT-1K12(R,i) =XBOOLE-0R4 f .FUNCT-1K1 i)"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_94:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds (idPARTFUN1K6 X)\<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> A =XBOOLE-0R4 A"
proof-
  have " for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds A =HIDDENR1 (idPARTFUN1K6 X)\<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> A"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
    have "A =HIDDENR1 (idPARTFUN1K6 X)\<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> (idPARTFUN1K6 X .:RELSET-1K7\<^bsub>(X,X)\<^esub> A)"
      using funct_2_th_62 sorry
    also have "... = (idPARTFUN1K6 X)\<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> A"
      using funct_1_th_92 sorry
    finally show "A =HIDDENR1 (idPARTFUN1K6 X)\<inverse>RELSET-1K8\<^bsub>(X,X)\<^esub> A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve A, B for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem funct_2_th_95:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds  for A0 be SubsetSUBSET-1M2-of A holds  for B0 be SubsetSUBSET-1M2-of B holds f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0 c=TARSKIR1 B0 iff A0 c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds  for A0 be SubsetSUBSET-1M2-of A holds  for B0 be SubsetSUBSET-1M2-of B holds (f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0 c=TARSKIR1 B0 implies A0 c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0) & (A0 c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0 implies f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0 c=TARSKIR1 B0)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
    fix A0 assume [ty]: "A0 be SubsetSUBSET-1M2-of A"
    fix B0 assume [ty]: "B0 be SubsetSUBSET-1M2-of B"
    show "f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0 c=TARSKIR1 B0 implies A0 c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0"
    proof(rule impI)
      assume "f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0 c=TARSKIR1 B0"
      then have A1: "f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> (f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0) c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0"
        using relat_1_th_143 sorry
      have "A0 c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> (f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0)"
        using funct_2_th_42 sorry
      thus "A0 c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0"
        using A1 sorry
    qed
    show "A0 c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0 implies f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0 c=TARSKIR1 B0"
    proof(rule impI)
      assume "A0 c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0"
      then have A2: "f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0 c=TARSKIR1 f .:RELSET-1K7\<^bsub>(A,B)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0"
        using relat_1_th_123 sorry
      have "f .:RELSET-1K7\<^bsub>(A,B)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(A,B)\<^esub> B0 c=TARSKIR1 B0"
        using funct_1_th_75 sorry
      thus "f .:RELSET-1K7\<^bsub>(A,B)\<^esub> A0 c=TARSKIR1 B0"
        using A2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_96:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds  for A0 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A holds  for f0 be FunctionFUNCT-2M1-of(A0,B) holds ( for c be ElementSUBSET-1M1-of A holds c inTARSKIR2 A0 implies f .FUNCT-2K3\<^bsub>(A,B)\<^esub> c =XBOOLE-0R4 f0 .FUNCT-1K1 c) implies f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> A0 =FUNCT-1R1 f0"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds  for A0 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A holds  for f0 be FunctionFUNCT-2M1-of(A0,B) holds ( for c be ElementSUBSET-1M1-of A holds c inTARSKIR2 A0 implies f .FUNCT-2K3\<^bsub>(A,B)\<^esub> c =XBOOLE-0R4 f0 .FUNCT-1K1 c) implies f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> A0 =FUNCT-1R1 f0"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
    fix A0 assume [ty]: "A0 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of A"
    fix f0 assume [ty]: "f0 be FunctionFUNCT-2M1-of(A0,B)"
    assume A1: " for c be ElementSUBSET-1M1-of A holds c inTARSKIR2 A0 implies f .FUNCT-2K3\<^bsub>(A,B)\<^esub> c =XBOOLE-0R4 f0 .FUNCT-1K1 c"
    obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(A0,B)" and gDef:"g = f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> A0"
      using funct_2_th_32 sorry
    have " for c be ElementSUBSET-1M3\<^bsub>(A)\<^esub>-of A0 holds g .FUNCT-2K3\<^bsub>(A0,B)\<^esub> c =XBOOLE-0R4 f0 .FUNCT-2K3\<^bsub>(A0,B)\<^esub> c"
    proof-
      have " for c be ElementSUBSET-1M3\<^bsub>(A)\<^esub>-of A0 holds g .FUNCT-2K3\<^bsub>(A0,B)\<^esub> c =HIDDENR1 f0 .FUNCT-2K3\<^bsub>(A0,B)\<^esub> c"
      proof(rule ballI)
        fix c assume [ty]: "c be ElementSUBSET-1M3\<^bsub>(A)\<^esub>-of A0"
        have "g .FUNCT-2K3\<^bsub>(A0,B)\<^esub> c =HIDDENR1 f .FUNCT-2K3\<^bsub>(A,B)\<^esub> c"
          using funct_1_th_49 sorry
        also have "... = f0 .FUNCT-2K3\<^bsub>(A0,B)\<^esub> c"
          using A1 sorry
        finally show "g .FUNCT-2K3\<^bsub>(A0,B)\<^esub> c =HIDDENR1 f0 .FUNCT-2K3\<^bsub>(A0,B)\<^esub> c"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> A0 =FUNCT-1R1 f0"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_97:
" for f be FunctionFUNCT-1M1 holds  for A0 be setHIDDENM2 holds  for C be setHIDDENM2 holds C c=TARSKIR1 A0 implies f .:FUNCT-1K5 C =XBOOLE-0R4 (f  |RELAT-1K8 A0).:FUNCT-1K5 C"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for A0 be setHIDDENM2 holds  for C be setHIDDENM2 holds C c=TARSKIR1 A0 implies (f  |RELAT-1K8 A0).:FUNCT-1K5 C =HIDDENR1 f .:FUNCT-1K5 C"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix A0 assume [ty]: "A0 be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    assume A1: "C c=TARSKIR1 A0"
    have "(f  |RELAT-1K8 A0).:FUNCT-1K5 C =HIDDENR1 (f *FUNCT-1K3 idPARTFUN1K6 A0).:FUNCT-1K5 C"
      using relat_1_th_65 sorry
    also have "... = f .:FUNCT-1K5 (idPARTFUN1K6 A0 .:RELSET-1K7\<^bsub>(A0,A0)\<^esub> C)"
      using relat_1_th_126 sorry
    also have "... = f .:FUNCT-1K5 C"
      using A1 funct_1_th_92 sorry
    finally show "(f  |RELAT-1K8 A0).:FUNCT-1K5 C =HIDDENR1 f .:FUNCT-1K5 C"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_98:
" for f be FunctionFUNCT-1M1 holds  for A0 be setHIDDENM2 holds  for D be setHIDDENM2 holds f \<inverse>FUNCT-1K6 D c=TARSKIR1 A0 implies f \<inverse>FUNCT-1K6 D =XBOOLE-0R4 (f  |RELAT-1K8 A0)\<inverse>FUNCT-1K6 D"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for A0 be setHIDDENM2 holds  for D be setHIDDENM2 holds f \<inverse>FUNCT-1K6 D c=TARSKIR1 A0 implies (f  |RELAT-1K8 A0)\<inverse>FUNCT-1K6 D =HIDDENR1 f \<inverse>FUNCT-1K6 D"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix A0 assume [ty]: "A0 be setHIDDENM2"
    fix D assume [ty]: "D be setHIDDENM2"
    assume A1: "f \<inverse>FUNCT-1K6 D c=TARSKIR1 A0"
    have "(f  |RELAT-1K8 A0)\<inverse>FUNCT-1K6 D =HIDDENR1 (f *FUNCT-1K3 idPARTFUN1K6 A0)\<inverse>FUNCT-1K6 D"
      using relat_1_th_65 sorry
    also have "... = (idPARTFUN1K6 A0)\<inverse>RELSET-1K8\<^bsub>(A0,A0)\<^esub> (f \<inverse>FUNCT-1K6 D)"
      using relat_1_th_146 sorry
    also have "... = f \<inverse>FUNCT-1K6 D"
      using A1 funct_2_th_94 sorry
    finally show "(f  |RELAT-1K8 A0)\<inverse>FUNCT-1K6 D =HIDDENR1 f \<inverse>FUNCT-1K6 D"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem funct_2_sch_10:
  fixes Af0 Bf0 Ff1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
   A1: " for a be ElementSUBSET-1M1-of Af0 holds Bf0 meetsXBOOLE-0R5 Ff1(a)"
  shows " ex t be FunctionFUNCT-2M1-of(Af0,Bf0) st  for a be ElementSUBSET-1M1-of Af0 holds t .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> a inTARSKIR2 Ff1(a)"
  proof-
    have " ex tVar16 be FunctionFUNCT-2M1-of(Af0,Bf0) st  for a be ElementSUBSET-1M1-of Af0 holds tVar16 .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> a inTARSKIR2 Ff1(a)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 Ff1(Lamb1)"
      have A2: " for e be objectHIDDENM1 holds e inHIDDENR3 Af0 implies ( ex u be objectHIDDENM1 st u inHIDDENR3 Bf0 & ?P(e,u))"
        using A1 xboole_0_th_3 sorry
      obtain t where
        [ty]:"t be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 t =XBOOLE-0R4 Af0 & rngFUNCT-1K2 t c=TARSKIR1 Bf0"and A4: " for e be objectHIDDENM1 holds e inHIDDENR3 Af0 implies ?P(e,t .FUNCT-1K1 e)"
        using funct_1_sch_6 A2 sorry
      have 
        [ty]:"t be FunctionFUNCT-2M1-of(Af0,Bf0)"
        using A3 funct_2_def_1 relset_1_th_4 sorry
      show " ex tVar16 be FunctionFUNCT-2M1-of(Af0,Bf0) st  for a be ElementSUBSET-1M1-of Af0 holds tVar16 .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> a inTARSKIR2 Ff1(a)"
      proof(rule bexI[of _ "t"],rule ballI)
        fix a assume [ty]: "a be ElementSUBSET-1M1-of Af0"
        show "t .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> a inTARSKIR2 Ff1(a)"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem funct_2_th_99:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FunctionFUNCT-2M1-of(X,D) holds  for i be ElementSUBSET-1M1-of X holds p /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(X,D)\<^esub> i"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix p assume [ty]: "p be FunctionFUNCT-2M1-of(X,D)"
  fix i assume [ty]: "i be ElementSUBSET-1M1-of X"
  have "i inTARSKIR2 X"
     sorry
  then have "i inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> p"
    using funct_2_def_1 sorry
  thus "p /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(X,D)\<^esub> i"
    using partfun1_def_6 sorry
qed "sorry"

mtheorem funct_2_ident_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FunctionFUNCT-2M1-of(X,D)", "i be ElementSUBSET-1M1-of X"
"identify p /.PARTFUN1K7\<^bsub>(D)\<^esub> i with p .FUNCT-2K3\<^bsub>(X,D)\<^esub> i"
proof
(*compatibility*)
  show "p /.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 p .FUNCT-2K3\<^bsub>(X,D)\<^esub> i"
    using funct_2_th_99 sorry
qed "sorry"

mtheorem funct_2_th_100:
" for S be setHIDDENM2 holds  for X be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(S,X) holds  for A be SubsetSUBSET-1M2-of X holds (X =XBOOLE-0R4 {}XBOOLE-0K1 implies S =XBOOLE-0R4 {}XBOOLE-0K1) implies (f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A)`SUBSET-1K3\<^bsub>(S)\<^esub> =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix S assume [ty]: "S be setHIDDENM2"
  fix X assume [ty]: "X be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(S,X)"
  fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
  assume A1: "X =XBOOLE-0R4 {}XBOOLE-0K1 implies S =XBOOLE-0R4 {}XBOOLE-0K1"
  have "A /\\SUBSET-1K9\<^bsub>(X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 {}XBOOLE-0K1"
    using xboole_0_def_7 xboole_1_th_79 sorry
  then have "f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A /\\SUBSET-1K9\<^bsub>(S)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> ({}SUBSET-1K1 X)"
    using funct_1_th_68 sorry
  also have "... = {}XBOOLE-0K1"
     sorry
  finally have "f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A /\\SUBSET-1K9\<^bsub>(S)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 {}XBOOLE-0K1"
     sorry
  then have A2: "f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A missesXBOOLE-0R1 f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub>"
     sorry
  have "f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A \\/SUBSET-1K4\<^bsub>(S)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> (A \\/SUBSET-1K4\<^bsub>(X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub>)"
    using relat_1_th_140 sorry
  also have "... = f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> ([#]SUBSET-1K2 X)"
    using subset_1_th_10 sorry
  also have "... = [#]SUBSET-1K2 S"
    using A1 funct_2_th_40 sorry
  finally have "f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A \\/SUBSET-1K4\<^bsub>(S)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 [#]SUBSET-1K2 S"
     sorry
  then have "(f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A)`SUBSET-1K3\<^bsub>(S)\<^esub> /\\SUBSET-1K9\<^bsub>(S)\<^esub> (f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(S)\<^esub> =HIDDENR1 ([#]SUBSET-1K2 S)`SUBSET-1K3\<^bsub>(S)\<^esub>"
    using xboole_1_th_53 sorry
  also have "... = {}SUBSET-1K1 S"
    using xboole_1_th_37 sorry
  finally have "(f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A)`SUBSET-1K3\<^bsub>(S)\<^esub> /\\SUBSET-1K9\<^bsub>(S)\<^esub> (f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(S)\<^esub> =HIDDENR1 {}SUBSET-1K1 S"
     sorry
  then have "(f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A)`SUBSET-1K3\<^bsub>(S)\<^esub> missesXBOOLE-0R1 (f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(S)\<^esub>"
     sorry
  thus "(f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A)`SUBSET-1K3\<^bsub>(S)\<^esub> =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(S,X)\<^esub> A `SUBSET-1K3\<^bsub>(X)\<^esub>"
    using A2 subset_1_th_25 sorry
qed "sorry"

mtheorem funct_2_th_101:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,D) holds Y c=TARSKIR1 X & f .:RELSET-1K7\<^bsub>(X,D)\<^esub> Y c=TARSKIR1 Z implies f  |PARTFUN1K2\<^bsub>(X,D)\<^esub> Y be FunctionFUNCT-2M1-of(Y,Z)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix Z assume [ty]: "Z be setHIDDENM2"
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,D)"
  assume A1: "Y c=TARSKIR1 X"
    and A2: "f .:RELSET-1K7\<^bsub>(X,D)\<^esub> Y c=TARSKIR1 Z"
  have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
    using funct_2_def_1 sorry
  then have A3: "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(X,D)\<^esub> Y) =XBOOLE-0R4 Y"
    using A1 relat_1_th_62 sorry
  have A4: "Z =XBOOLE-0R4 {}XBOOLE-0K1 implies Y =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule impI)
    assume "Z =XBOOLE-0R4 {}XBOOLE-0K1"
    then have "rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(X,D)\<^esub> Y) =XBOOLE-0R4 {}XBOOLE-0K1"
      using A2 relat_1_th_115 sorry
    thus "Y =XBOOLE-0R4 {}XBOOLE-0K1"
      using A3 relat_1_th_42 sorry
  qed
  have "rngRELSET-1K2\<^bsub>(D)\<^esub> (f  |PARTFUN1K2\<^bsub>(X,D)\<^esub> Y) c=TARSKIR1 Z"
    using A2 relat_1_th_115 sorry
  thus "f  |PARTFUN1K2\<^bsub>(X,D)\<^esub> Y be FunctionFUNCT-2M1-of(Y,Z)"
    using A3 A4 funct_2_def_1 relset_1_th_4 sorry
qed "sorry"

mdef funct_2_def_9 (" _ \<inverse>FUNCT-2K6\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228 ) where
  mlet "T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(T,S)", "G be Subset-FamilySETFAM-1M1-of S"
"func f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> G \<rightarrow> Subset-FamilySETFAM-1M1-of T means
  \<lambda>it.  for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 it iff ( ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)"
proof-
  (*existence*)
    show " ex it be Subset-FamilySETFAM-1M1-of T st  for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 it iff ( ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)"
    proof-
      have " not ( for VarFor1 be Subset-FamilySETFAM-1M1-of T holds  not ( for A be SubsetSUBSET-1M2-of T holds  not (A inTARSKIR2 VarFor1 & ( for B be SubsetSUBSET-1M2-of S holds  not (B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B))) &  not ( not ( for B be SubsetSUBSET-1M2-of S holds  not (B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)) &  not A inTARSKIR2 VarFor1)))"
      proof-
        let ?P = "\<lambda>Lamb1.  ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & Lamb1 =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B"
        have " ex R be Subset-FamilySETFAM-1M1-of T st  for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 R iff ?P(A)"
          using subset_1_sch_3 sorry
        thus " not ( for VarFor1 be Subset-FamilySETFAM-1M1-of T holds  not ( for A be SubsetSUBSET-1M2-of T holds  not (A inTARSKIR2 VarFor1 & ( for B be SubsetSUBSET-1M2-of S holds  not (B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B))) &  not ( not ( for B be SubsetSUBSET-1M2-of S holds  not (B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)) &  not A inTARSKIR2 VarFor1)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Subset-FamilySETFAM-1M1-of T holds  for it2 be Subset-FamilySETFAM-1M1-of T holds ( for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 it1 iff ( ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)) & ( for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 it2 iff ( ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)) implies it1 =HIDDENR1 it2"
    proof-
      have " for R1 be Subset-FamilySETFAM-1M1-of T holds  for R2 be Subset-FamilySETFAM-1M1-of T holds ( for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 R1 iff ( ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)) & ( for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 R2 iff ( ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)) implies R1 =HIDDENR1 R2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix R1 assume [ty]: "R1 be Subset-FamilySETFAM-1M1-of T"
        fix R2 assume [ty]: "R2 be Subset-FamilySETFAM-1M1-of T"
        assume A1: " for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 R1 iff ( ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)"
          and A2: " for A be SubsetSUBSET-1M2-of T holds A inTARSKIR2 R2 iff ( ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & A =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 R1 iff x inHIDDENR3 R2"
        proof-
          have " for x be objectHIDDENM1 holds (x inHIDDENR3 R1 implies x inHIDDENR3 R2) & (x inHIDDENR3 R2 implies x inHIDDENR3 R1)"
          proof(rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 R1 implies x inHIDDENR3 R2"
            proof(rule impI)
              assume A3: "x inHIDDENR3 R1"
              then have 
                [ty]:"x be SubsetSUBSET-1M2-of T"
                 sorry
              have " ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & x =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B"
                using A1 A3 sorry
              thus "x inHIDDENR3 R2"
                using A2 sorry
            qed
            assume A4: "x inHIDDENR3 R2"
            then have 
              [ty]:"x be SubsetSUBSET-1M2-of T"
               sorry
            have " ex B be SubsetSUBSET-1M2-of S st B inTARSKIR2 G & x =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> B"
              using A2 A4 sorry
            thus "x inHIDDENR3 R1"
              using A1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "R1 =HIDDENR1 R2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_2_th_102:
" for T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(T,S) holds  for A be Subset-FamilySETFAM-1M1-of S holds  for B be Subset-FamilySETFAM-1M1-of S holds A c=TARSKIR1 B implies f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> A c=TARSKIR1 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix T assume [ty]: "T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(T,S)"
  fix A assume [ty]: "A be Subset-FamilySETFAM-1M1-of S"
  fix B assume [ty]: "B be Subset-FamilySETFAM-1M1-of S"
  assume A1: "A c=TARSKIR1 B"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> A implies x inHIDDENR3 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A2: "x inHIDDENR3 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> A"
    then have 
      [ty]:"x be SubsetSUBSET-1M2-of T"
       sorry
    have " ex C be SubsetSUBSET-1M2-of S st C inTARSKIR2 B & x =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> C"
    proof-
      have " ex tVar17 be SubsetSUBSET-1M2-of S st tVar17 inTARSKIR2 B & x =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> tVar17"
      proof-
        obtain C where
          [ty]:"C be SubsetSUBSET-1M2-of S" and 
          A3: "C inTARSKIR2 A & x =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> C"
          using A2 funct_2_def_9 sorry
        show " ex tVar17 be SubsetSUBSET-1M2-of S st tVar17 inTARSKIR2 B & x =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> tVar17"
        proof(rule bexI[of _ "C"])
          show "C inTARSKIR2 B & x =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> C"
            using A1 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus "x inHIDDENR3 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B"
      using funct_2_def_9 sorry
  qed "sorry"
  thus "f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> A c=TARSKIR1 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B"
    using tarski_def_3 sorry
qed "sorry"

mdef funct_2_def_10 (" _ .:FUNCT-2K7\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200 ) where
  mlet "T be setHIDDENM2", "S be setHIDDENM2", "f be FunctionFUNCT-2M1-of(T,S)", "G be Subset-FamilySETFAM-1M1-of T"
"func f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> G \<rightarrow> Subset-FamilySETFAM-1M1-of S means
  \<lambda>it.  for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 it iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)"
proof-
  (*existence*)
    show " ex it be Subset-FamilySETFAM-1M1-of S st  for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 it iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)"
    proof-
      have " ex R be Subset-FamilySETFAM-1M1-of S st  for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 R iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)"
      proof-
        show " ex R be Subset-FamilySETFAM-1M1-of S st  for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 R iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)"
        proof-
          have " not ( for R be Subset-FamilySETFAM-1M1-of S holds  not ( for A be SubsetSUBSET-1M2-of S holds  not (A inTARSKIR2 R & ( for B be SubsetSUBSET-1M2-of T holds  not (B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B))) &  not ( not ( for B be SubsetSUBSET-1M2-of T holds  not (B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)) &  not A inTARSKIR2 R)))"
          proof-
            let ?P = "\<lambda>Lamb1.  ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & Lamb1 =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B"
            have " ex R be Subset-FamilySETFAM-1M1-of S st  for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 R iff ?P(A)"
              using subset_1_sch_3 sorry
            thus " not ( for R be Subset-FamilySETFAM-1M1-of S holds  not ( for A be SubsetSUBSET-1M2-of S holds  not (A inTARSKIR2 R & ( for B be SubsetSUBSET-1M2-of T holds  not (B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B))) &  not ( not ( for B be SubsetSUBSET-1M2-of T holds  not (B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)) &  not A inTARSKIR2 R)))"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Subset-FamilySETFAM-1M1-of S holds  for it2 be Subset-FamilySETFAM-1M1-of S holds ( for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 it1 iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)) & ( for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 it2 iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)) implies it1 =HIDDENR1 it2"
    proof-
      have " for R1 be Subset-FamilySETFAM-1M1-of S holds  for R2 be Subset-FamilySETFAM-1M1-of S holds ( for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 R1 iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)) & ( for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 R2 iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)) implies R1 =HIDDENR1 R2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix R1 assume [ty]: "R1 be Subset-FamilySETFAM-1M1-of S"
        fix R2 assume [ty]: "R2 be Subset-FamilySETFAM-1M1-of S"
        assume A1: " for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 R1 iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)"
          and A2: " for A be SubsetSUBSET-1M2-of S holds A inTARSKIR2 R2 iff ( ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 R1 iff x inHIDDENR3 R2"
        proof-
          have " for x be objectHIDDENM1 holds (x inHIDDENR3 R1 implies x inHIDDENR3 R2) & (x inHIDDENR3 R2 implies x inHIDDENR3 R1)"
          proof(rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 R1 implies x inHIDDENR3 R2"
            proof(rule impI)
              assume A3: "x inHIDDENR3 R1"
              then have 
                [ty]:"x be SubsetSUBSET-1M2-of S"
                 sorry
              have " ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & x =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B"
                using A1 A3 sorry
              thus "x inHIDDENR3 R2"
                using A2 sorry
            qed
            assume A4: "x inHIDDENR3 R2"
            then have 
              [ty]:"x be SubsetSUBSET-1M2-of S"
               sorry
            have " ex B be SubsetSUBSET-1M2-of T st B inTARSKIR2 G & x =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> B"
              using A2 A4 sorry
            thus "x inHIDDENR3 R1"
              using A1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "R1 =HIDDENR1 R2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_2_th_103:
" for T be setHIDDENM2 holds  for S be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(T,S) holds  for A be Subset-FamilySETFAM-1M1-of T holds  for B be Subset-FamilySETFAM-1M1-of T holds A c=TARSKIR1 B implies f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> A c=TARSKIR1 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix T assume [ty]: "T be setHIDDENM2"
  fix S assume [ty]: "S be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(T,S)"
  fix A assume [ty]: "A be Subset-FamilySETFAM-1M1-of T"
  fix B assume [ty]: "B be Subset-FamilySETFAM-1M1-of T"
  assume A1: "A c=TARSKIR1 B"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> A implies x inHIDDENR3 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A2: "x inHIDDENR3 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> A"
    then have 
      [ty]:"x be SubsetSUBSET-1M2-of S"
       sorry
    have " ex C be SubsetSUBSET-1M2-of T st C inTARSKIR2 B & x =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> C"
    proof-
      have " ex tVar18 be SubsetSUBSET-1M2-of T st tVar18 inTARSKIR2 B & x =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> tVar18"
      proof-
        obtain C where
          [ty]:"C be SubsetSUBSET-1M2-of T" and 
          A3: "C inTARSKIR2 A & x =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> C"
          using A2 funct_2_def_10 sorry
        show " ex tVar18 be SubsetSUBSET-1M2-of T st tVar18 inTARSKIR2 B & x =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> tVar18"
        proof(rule bexI[of _ "C"])
          show "C inTARSKIR2 B & x =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> C"
            using A1 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus "x inHIDDENR3 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B"
      using funct_2_def_10 sorry
  qed "sorry"
  thus "f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> A c=TARSKIR1 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_2_th_104:
" for T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(T,S) holds  for B be Subset-FamilySETFAM-1M1-of S holds  for P be SubsetSUBSET-1M2-of S holds f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B be CoverSETFAM-1M2-of P implies B be CoverSETFAM-1M2-of P"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix T assume [ty]: "T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(T,S)"
  fix B assume [ty]: "B be Subset-FamilySETFAM-1M1-of S"
  fix P assume [ty]: "P be SubsetSUBSET-1M2-of S"
  assume "f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B be CoverSETFAM-1M2-of P"
  then have A1: "P c=TARSKIR1 unionSETFAM-1K5\<^bsub>(S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B)"
    using setfam_1_def_11 sorry
  have "P c=TARSKIR1 unionSETFAM-1K5\<^bsub>(S)\<^esub> B"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 P implies x inHIDDENR3 unionSETFAM-1K5\<^bsub>(S)\<^esub> B"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 P"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A2: "x inHIDDENR3 Y"and A3: "Y inTARSKIR2 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B"
        using A1 tarski_def_4 sorry
      have " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 B"
      proof-
        have " ex tVar19 be setHIDDENM2 st x inHIDDENR3 tVar19 & tVar19 inTARSKIR2 B"
        proof-
          have 
            [ty]:"Y be SubsetSUBSET-1M2-of S"
            using A3 sorry
          obtain Y1 where
            [ty]:"Y1 be SubsetSUBSET-1M2-of T" and 
            A4: "Y1 inTARSKIR2 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> B"and A5: "Y =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> Y1"
            using A3 funct_2_def_10 sorry
          obtain Y2 where
            [ty]:"Y2 be SubsetSUBSET-1M2-of S" and 
            A6: "Y2 inTARSKIR2 B & Y1 =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> Y2"
            using A4 funct_2_def_9 sorry
          have A7: "f .:RELSET-1K7\<^bsub>(T,S)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> Y2 c=TARSKIR1 Y2"
            using funct_1_th_75 sorry
          have 
            [ty]:"Y2 be setHIDDENM2"
             sorry
          show " ex tVar19 be setHIDDENM2 st x inHIDDENR3 tVar19 & tVar19 inTARSKIR2 B"
          proof(rule bexI[of _ "Y2"])
            show "x inHIDDENR3 Y2 & Y2 inTARSKIR2 B"
              using A2 A5 A6 A7 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      thus "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(S)\<^esub> B"
        using tarski_def_4 sorry
    qed "sorry"
    thus "P c=TARSKIR1 unionSETFAM-1K5\<^bsub>(S)\<^esub> B"
      using tarski_def_3 sorry
  qed
  thus "B be CoverSETFAM-1M2-of P"
    using setfam_1_def_11 sorry
qed "sorry"

mtheorem funct_2_th_105:
" for T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(T,S) holds  for B be Subset-FamilySETFAM-1M1-of T holds  for P be SubsetSUBSET-1M2-of T holds B be CoverSETFAM-1M2-of P implies f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B) be CoverSETFAM-1M2-of P"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix T assume [ty]: "T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(T,S)"
  fix B assume [ty]: "B be Subset-FamilySETFAM-1M1-of T"
  fix P assume [ty]: "P be SubsetSUBSET-1M2-of T"
  assume "B be CoverSETFAM-1M2-of P"
  then have A1: "P c=TARSKIR1 unionSETFAM-1K5\<^bsub>(T)\<^esub> B"
    using setfam_1_def_11 sorry
  have "P c=TARSKIR1 unionSETFAM-1K5\<^bsub>(T)\<^esub> (f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B))"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 P implies x inHIDDENR3 unionSETFAM-1K5\<^bsub>(T)\<^esub> (f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 P"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A2: "x inHIDDENR3 Y"and A3: "Y inTARSKIR2 B"
        using A1 tarski_def_4 sorry
      have " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B)"
      proof-
        have " ex tVar20 be setHIDDENM2 st x inHIDDENR3 tVar20 & tVar20 inTARSKIR2 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B)"
        proof-
          have 
            [ty]:"Y be SubsetSUBSET-1M2-of T"
            using A3 sorry
          let ?Z = "f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> (f .:RELSET-1K7\<^bsub>(T,S)\<^esub> Y)"
          show " ex tVar20 be setHIDDENM2 st x inHIDDENR3 tVar20 & tVar20 inTARSKIR2 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B)"
          proof(rule bexI[of _ "?Z"])
            have "domRELSET-1K1\<^bsub>(T)\<^esub> f =XBOOLE-0R4 T"
              using funct_2_def_1 sorry
            then have A4: "Y c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> (f .:RELSET-1K7\<^bsub>(T,S)\<^esub> Y)"
              using funct_1_th_76 sorry
            have "f .:RELSET-1K7\<^bsub>(T,S)\<^esub> Y inTARSKIR2 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B"
              using A3 funct_2_def_10 sorry
            thus "x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> (f .:RELSET-1K7\<^bsub>(T,S)\<^esub> Y) & f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> (f .:RELSET-1K7\<^bsub>(T,S)\<^esub> Y) inTARSKIR2 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B)"
              using A2 A4 funct_2_def_9 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      thus "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(T)\<^esub> (f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B))"
        using tarski_def_4 sorry
    qed "sorry"
    thus "P c=TARSKIR1 unionSETFAM-1K5\<^bsub>(T)\<^esub> (f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B))"
      using tarski_def_3 sorry
  qed
  thus "f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> B) be CoverSETFAM-1M2-of P"
    using setfam_1_def_11 sorry
qed "sorry"

mtheorem funct_2_th_106:
" for T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(T,S) holds  for Q be Subset-FamilySETFAM-1M1-of S holds unionSETFAM-1K5\<^bsub>(S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> Q) c=TARSKIR1 unionSETFAM-1K5\<^bsub>(S)\<^esub> Q"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix T assume [ty]: "T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(T,S)"
  fix Q assume [ty]: "Q be Subset-FamilySETFAM-1M1-of S"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 unionSETFAM-1K5\<^bsub>(S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> Q) implies x inHIDDENR3 unionSETFAM-1K5\<^bsub>(S)\<^esub> Q"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> Q) implies x inHIDDENR3 unionSETFAM-1K5\<^bsub>(S)\<^esub> Q"
    proof(rule impI)
      assume "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> Q)"
      then obtain A where
        [ty]:"A be setHIDDENM2" and 
        A1: "x inHIDDENR3 A"and A2: "A inTARSKIR2 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> Q"
        using tarski_def_4 sorry
      have 
        [ty]:"A be SubsetSUBSET-1M2-of S"
        using A2 sorry
      obtain A1 where
        [ty]:"A1 be SubsetSUBSET-1M2-of T" and 
        A3: "A1 inTARSKIR2 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> Q"and A4: "A =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(T,S)\<^esub> A1"
        using A2 funct_2_def_10 sorry
      obtain A2 where
        [ty]:"A2 be SubsetSUBSET-1M2-of S" and 
        A5: "A2 inTARSKIR2 Q & A1 =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> A2"
        using A3 funct_2_def_9 sorry
      have "f .:RELSET-1K7\<^bsub>(T,S)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> A2 c=TARSKIR1 A2"
        using funct_1_th_75 sorry
      thus "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(S)\<^esub> Q"
        using A1 A4 A5 tarski_def_4 sorry
    qed
  qed "sorry"
  thus "unionSETFAM-1K5\<^bsub>(S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> Q) c=TARSKIR1 unionSETFAM-1K5\<^bsub>(S)\<^esub> Q"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_2_th_107:
" for T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(T,S) holds  for P be Subset-FamilySETFAM-1M1-of T holds unionSETFAM-1K5\<^bsub>(T)\<^esub> P c=TARSKIR1 unionSETFAM-1K5\<^bsub>(T)\<^esub> (f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> P))"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix T assume [ty]: "T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(T,S)"
  fix P assume [ty]: "P be Subset-FamilySETFAM-1M1-of T"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 unionSETFAM-1K5\<^bsub>(T)\<^esub> P implies x inHIDDENR3 unionSETFAM-1K5\<^bsub>(T)\<^esub> (f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> P))"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(T)\<^esub> P"
    then obtain A where
      [ty]:"A be setHIDDENM2" and 
      A1: "x inHIDDENR3 A"and A2: "A inTARSKIR2 P"
      using tarski_def_4 sorry
    have A3: "A c=TARSKIR1 T"
      using A2 sorry
    have 
      [ty]:"A be SubsetSUBSET-1M2-of T"
      using A2 sorry
    obtain A1 where 
      [ty]:"A1 be SubsetSUBSET-1M2-of S" and A1Def:"A1 = f .:RELSET-1K7\<^bsub>(T,S)\<^esub> A"
       sorry
    obtain A2 where 
      [ty]:"A2 be SubsetSUBSET-1M2-of T" and A2Def:"A2 = f \<inverse>RELSET-1K8\<^bsub>(T,S)\<^esub> A1"
       sorry
    have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(T)\<^esub> f"
      using A3 funct_2_def_1 sorry
    then have A4: "A c=TARSKIR1 A2"
      using funct_1_th_76 sorry
    have "A1 inTARSKIR2 f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> P"
      using A2 funct_2_def_10 sorry
    then have "A2 inTARSKIR2 f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> P)"
      using funct_2_def_9 sorry
    thus "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(T)\<^esub> (f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> P))"
      using A1 A4 tarski_def_4 sorry
  qed "sorry"
  thus "unionSETFAM-1K5\<^bsub>(T)\<^esub> P c=TARSKIR1 unionSETFAM-1K5\<^bsub>(T)\<^esub> (f \<inverse>FUNCT-2K6\<^bsub>(T,S)\<^esub> (f .:FUNCT-2K7\<^bsub>(T,S)\<^esub> P))"
    using tarski_def_3 sorry
qed "sorry"

mdef funct_2_def_11 (" _ '/*FUNCT-2K8\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [228,0,0,0,228]228 ) where
  mlet "X be setHIDDENM2", "Z be setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,Y)", "p be Z -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"assume rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELAT-1K1 p func p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f \<rightarrow> FunctionFUNCT-2M1-of(X,Z) equals
  p *FUNCT-1K3 f"
proof-
  (*coherence*)
    show "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELAT-1K1 p implies p *FUNCT-1K3 f be FunctionFUNCT-2M1-of(X,Z)"
    proof(rule impI)
      assume Assume: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELAT-1K1 p"
      have A1: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELAT-1K1 p"
        using Assume sorry
      show "p *FUNCT-1K3 f be FunctionFUNCT-2M1-of(X,Z)"
      proof-
        have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
          using funct_2_def_1 sorry
        then have "domRELSET-1K1\<^bsub>(X)\<^esub> (p *FUNCT-1K3 f) =XBOOLE-0R4 X"
          using A1 relat_1_th_27 sorry
        then have A2: "p *FUNCT-1K3 f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
           sorry
        have "rngRELSET-1K2\<^bsub>(Z)\<^esub> (p *FUNCT-1K3 f) c=TARSKIR1 Z"
           sorry
        thus "p *FUNCT-1K3 f be FunctionFUNCT-2M1-of(X,Z)"
          using A2 relset_1_th_4 sorry
      qed
    qed
qed "sorry"

reserve Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve f for "FunctionFUNCT-2M1-of(X,Y)"
reserve p for "PartFuncPARTFUN1M1-of(Y,Z)"
reserve x for "ElementSUBSET-1M1-of X"
mtheorem funct_2_th_108:
" for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for p be PartFuncPARTFUN1M1-of(Y,Z) holds  for x be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p implies p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 (f .FUNCT-1K1 x)"
proof-
  have " for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for p be PartFuncPARTFUN1M1-of(Y,Z) holds  for x be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p implies p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 (f .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix p assume [ty]: "p be PartFuncPARTFUN1M1-of(Y,Z)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p"
    have "p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f =RELSET-1R2\<^bsub>(X,Z)\<^esub> p *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f"
      using A2 funct_2_def_11 sorry
    thus "p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 (f .FUNCT-1K1 x)"
      using A1 funct_2_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_109:
" for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for p be PartFuncPARTFUN1M1-of(Y,Z) holds  for x be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p implies p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-1K1 x =XBOOLE-0R4 p /.PARTFUN1K7\<^bsub>(Z)\<^esub> (f .FUNCT-1K1 x)"
proof-
  have " for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for p be PartFuncPARTFUN1M1-of(Y,Z) holds  for x be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 & rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p implies p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-1K1 x =HIDDENR1 p /.PARTFUN1K7\<^bsub>(Z)\<^esub> (f .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix p assume [ty]: "p be PartFuncPARTFUN1M1-of(Y,Z)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p"
    have A3: "f .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
      using A1 funct_2_th_4 sorry
    have "p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 (f .FUNCT-1K1 x)"
      using A1 A2 funct_2_th_108 sorry
    also have "... = p /.PARTFUN1K7\<^bsub>(Z)\<^esub> (f .FUNCT-1K1 x)"
      using A2 A3 partfun1_def_6 sorry
    finally show "p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-1K1 x =HIDDENR1 p /.PARTFUN1K7\<^bsub>(Z)\<^esub> (f .FUNCT-1K1 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve g for "FunctionFUNCT-2M1-of(X,X)"
mtheorem funct_2_th_110:
" for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for p be PartFuncPARTFUN1M1-of(Y,Z) holds  for g be FunctionFUNCT-2M1-of(X,X) holds rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p implies p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(X,X,X,Z)\<^esub> g =FUNCT-2R2\<^bsub>(X,Z)\<^esub> p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g)"
proof-
  have " for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for p be PartFuncPARTFUN1M1-of(Y,Z) holds  for g be FunctionFUNCT-2M1-of(X,X) holds rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p implies p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(X,X,X,Z)\<^esub> g =HIDDENR1 p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix p assume [ty]: "p be PartFuncPARTFUN1M1-of(Y,Z)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,X)"
    have A1: "rngRELSET-1K2\<^bsub>(Y)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g) c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
      using relat_1_th_26 sorry
    assume A2: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> p"
    then have "p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(X,X,X,Z)\<^esub> g =HIDDENR1 (p *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)*PARTFUN1K1\<^bsub>(X,X,X,Z)\<^esub> g"
      using funct_2_def_11 sorry
    also have "... = p *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g)"
      using relat_1_th_36 sorry
    also have "... = p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g)"
      using A2 A1 funct_2_def_11 xboole_1_th_1 sorry
    finally show "p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f *PARTFUN1K1\<^bsub>(X,X,X,Z)\<^esub> g =HIDDENR1 p /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> (f *PARTFUN1K1\<^bsub>(X,X,X,Y)\<^esub> g)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_111:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds f be constantFUNCT-1V5 iff ( ex y be ElementSUBSET-1M1-of Y st rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 y})"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (f be constantFUNCT-1V5 implies ( ex y be ElementSUBSET-1M1-of Y st rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 y})) & (( ex y be ElementSUBSET-1M1-of Y st rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 y}) implies f be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    show "f be constantFUNCT-1V5 implies ( ex y be ElementSUBSET-1M1-of Y st rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 y})"
    proof(rule impI)
      obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
        using xboole_0_def_1 sorry
      let ?y = "f .FUNCT-1K1 x"
      obtain y where 
        [ty]:"y be ElementSUBSET-1M1-of Y" and yDef:"y = ?y"
        using A1 funct_2_th_5 sorry
      assume A2: "f be constantFUNCT-1V5"
      show " ex y be ElementSUBSET-1M1-of Y st rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 y}"
      proof(rule bexI[of _ "y"])
        have " for y9 be objectHIDDENM1 holds y9 inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f iff y9 =HIDDENR1 y"
        proof-
          have " for y9 be objectHIDDENM1 holds (y9 inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f implies y9 =HIDDENR1 y) & (y9 =HIDDENR1 y implies y9 inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f)"
          proof(rule ballI,rule conjMI,rule impI)
            fix y9 assume [ty]: "y9 be objectHIDDENM1"
            show "y9 inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f implies y9 =HIDDENR1 y"
            proof(rule impI)
              assume "y9 inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
              then have " ex x9 be objectHIDDENM1 st x9 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & y9 =HIDDENR1 f .FUNCT-1K1 x9"
                using funct_1_def_3 sorry
              thus "y9 =HIDDENR1 y"
                using A2 A1 sorry
            qed
            assume "y9 =HIDDENR1 y"
            thus "y9 inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
              using A1 funct_2_th_4 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 y}"
          using tarski_def_1 sorry
      qed "sorry"
    qed
    assume Given: " ex y be ElementSUBSET-1M1-of Y st rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 y}"
    then obtain y where
      [ty]:"y be ElementSUBSET-1M1-of Y" and 
      A3: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 y}"
       sorry
    have " for x be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies (x9 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x9)"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix x9 assume [ty]: "x9 be objectHIDDENM1"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      then have A4: "f .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
        using funct_2_th_4 sorry
      assume "x9 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      then have A5: "f .FUNCT-1K1 x9 inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
        using funct_2_th_4 sorry
      have "f .FUNCT-1K1 x =HIDDENR1 y"
        using A3 A4 tarski_def_1 sorry
      also have "... = f .FUNCT-1K1 x9"
        using A3 A5 tarski_def_1 sorry
      finally show "f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x9"
         sorry
    qed "sorry"
    thus "f be constantFUNCT-1V5"
      using funct_1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_112:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of A holds  for f be FunctionFUNCT-2M1-of(A,B) holds f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x inTARSKIR2 rngRELSET-1K2\<^bsub>(B)\<^esub> f"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of A"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
  have "domRELSET-1K1\<^bsub>(A)\<^esub> f =XBOOLE-0R4 A"
    using funct_2_def_1 sorry
  thus "f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x inTARSKIR2 rngRELSET-1K2\<^bsub>(B)\<^esub> f"
    using funct_1_def_3 sorry
qed "sorry"

mtheorem funct_2_th_113:
" for y be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(B)\<^esub> f implies ( ex x be ElementSUBSET-1M1-of A st y =HIDDENR1 f .FUNCT-1K1 x)"
proof-
  have " for y be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(B)\<^esub> f implies ( ex tVar22 be ElementSUBSET-1M1-of A st y =HIDDENR1 f .FUNCT-1K1 tVar22)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
    assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(B)\<^esub> f"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 A"and A2: "f .FUNCT-1K1 x =HIDDENR1 y"
      using funct_2_th_11 sorry
    have 
      [ty]:"x be ElementSUBSET-1M1-of A"
      using A1 sorry
    show " ex tVar22 be ElementSUBSET-1M1-of A st y =HIDDENR1 f .FUNCT-1K1 tVar22"
    proof(rule bexI[of _ "x"])
      show "y =HIDDENR1 f .FUNCT-1K1 x"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_114:
" for Z be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds ( for x be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x inTARSKIR2 Z) implies rngRELSET-1K2\<^bsub>(B)\<^esub> f c=TARSKIR1 Z"
proof-
  have " for Z be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds ( for x be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x inTARSKIR2 Z) implies rngRELSET-1K2\<^bsub>(B)\<^esub> f c=TARSKIR1 Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
    assume A1: " for x be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x inTARSKIR2 Z"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(B)\<^esub> f implies y inHIDDENR3 Z"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(B)\<^esub> f"
      then have " ex x be ElementSUBSET-1M1-of A st f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x =HIDDENR1 y"
        using funct_2_th_113 sorry
      thus "y inHIDDENR3 Z"
        using A1 sorry
    qed "sorry"
    thus "rngRELSET-1K2\<^bsub>(B)\<^esub> f c=TARSKIR1 Z"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve X, Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve Z, S, T for "setHIDDENM2"
reserve f for "FunctionFUNCT-2M1-of(X,Y)"
reserve g for "PartFuncPARTFUN1M1-of(Y,Z)"
reserve x for "ElementSUBSET-1M1-of X"
mtheorem funct_2_th_115:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(Y,Z) holds  for x be ElementSUBSET-1M1-of X holds g be totalPARTFUN1V1\<^bsub>(Y)\<^esub> implies g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(Y,Z) holds  for x be ElementSUBSET-1M1-of X holds g be totalPARTFUN1V1\<^bsub>(Y)\<^esub> implies g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(Y,Z)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume "g be totalPARTFUN1V1\<^bsub>(Y)\<^esub>"
    then have "domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
       sorry
    then have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> g"
       sorry
    thus "g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
      using funct_2_th_108 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_116:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(Y,Z) holds  for x be ElementSUBSET-1M1-of X holds g be totalPARTFUN1V1\<^bsub>(Y)\<^esub> implies g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(Z)\<^esub> (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(Y,Z) holds  for x be ElementSUBSET-1M1-of X holds g be totalPARTFUN1V1\<^bsub>(Y)\<^esub> implies g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(Z)\<^esub> (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(Y,Z)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume "g be totalPARTFUN1V1\<^bsub>(Y)\<^esub>"
    then have "domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
       sorry
    then have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> g"
       sorry
    thus "g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(Z)\<^esub> (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
      using funct_2_th_109 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_117:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be setHIDDENM2 holds  for S be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(Y,Z) holds rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S) implies (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f =FUNCT-2R2\<^bsub>(X,Z)\<^esub> g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be setHIDDENM2 holds  for S be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(Y,Z) holds rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S) implies (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f =FUNCT-2R2\<^bsub>(X,Z)\<^esub> g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix S assume [ty]: "S be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(Y,Z)"
    assume A1: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)"
    have " for x be ElementSUBSET-1M1-of X holds (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =HIDDENR1 g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
      have A2: "domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S) c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> g"
        using relat_1_th_60 sorry
      have A3: "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> f"
        using funct_2_th_4 sorry
      have "(g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =HIDDENR1 (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S).FUNCT-1K1 (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
        using A1 funct_2_th_108 sorry
      also have "... = g .FUNCT-1K1 (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
        using A1 A3 funct_1_th_47 sorry
      also have "... = g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x"
        using A1 A2 funct_2_th_108 xboole_1_th_1 sorry
      finally show "(g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =HIDDENR1 g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x"
         sorry
    qed "sorry"
    thus "(g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f =FUNCT-2R2\<^bsub>(X,Z)\<^esub> g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f"
      using funct_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_118:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be setHIDDENM2 holds  for S be setHIDDENM2 holds  for T be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(Y,Z) holds rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S) & S c=TARSKIR1 T implies (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f =FUNCT-2R2\<^bsub>(X,Z)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> T)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be setHIDDENM2 holds  for S be setHIDDENM2 holds  for T be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(Y,Z) holds rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S) implies (S c=TARSKIR1 T implies (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f =HIDDENR1 (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> T)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix S assume [ty]: "S be setHIDDENM2"
    fix T assume [ty]: "T be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(Y,Z)"
    assume A1: "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)"
    assume "S c=TARSKIR1 T"
    then have "g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S c=RELSET-1R1\<^bsub>(Y,Z)\<^esub> g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> T"
      using relat_1_th_75 sorry
    then have A2: "domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S) c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> T)"
      using relat_1_th_11 sorry
    have "(g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f =HIDDENR1 g /*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f"
      using A1 funct_2_th_117 sorry
    also have "... = (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> T)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f"
      using A1 A2 funct_2_th_117 xboole_1_th_1 sorry
    finally show "(g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> S)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f =HIDDENR1 (g  |PARTFUN1K2\<^bsub>(Y,Z)\<^esub> T)/*FUNCT-2K8\<^bsub>(X,Z,Y)\<^esub> f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_119:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be FunctionFUNCT-2M1-of(D,[:ZFMISC-1K2 A,B :]) holds  for d be ElementSUBSET-1M1-of D holds H .FUNCT-2K3\<^bsub>(D,[:ZFMISC-1K2 A,B :])\<^esub> d =HIDDENR1 [TARSKIK4 pr1FUNCT-2K4\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,A)\<^esub> d,pr2FUNCT-2K5\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,B)\<^esub> d ]"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be FunctionFUNCT-2M1-of(D,[:ZFMISC-1K2 A,B :]) holds  for d be ElementSUBSET-1M1-of D holds H .FUNCT-2K3\<^bsub>(D,[:ZFMISC-1K2 A,B :])\<^esub> d =HIDDENR1 [TARSKIK4 pr1FUNCT-2K4\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,A)\<^esub> d,pr2FUNCT-2K5\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,B)\<^esub> d ]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be FunctionFUNCT-2M1-of(D,[:ZFMISC-1K2 A,B :])"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    have "H .FUNCT-2K3\<^bsub>(D,[:ZFMISC-1K2 A,B :])\<^esub> d =HIDDENR1 [TARSKIK4 (H .FUNCT-2K3\<^bsub>(D,[:ZFMISC-1K2 A,B :])\<^esub> d)`1XTUPLE-0K1,(H .FUNCT-2K3\<^bsub>(D,[:ZFMISC-1K2 A,B :])\<^esub> d)`2XTUPLE-0K2 ]"
      using mcart_1_th_21 sorry
    also have "... = [TARSKIK4 (H .FUNCT-2K3\<^bsub>(D,[:ZFMISC-1K2 A,B :])\<^esub> d)`1XTUPLE-0K1,pr2FUNCT-2K5\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,B)\<^esub> d ]"
      using funct_2_def_6 sorry
    also have "... = [TARSKIK4 pr1FUNCT-2K4\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,A)\<^esub> d,pr2FUNCT-2K5\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,B)\<^esub> d ]"
      using funct_2_def_5 sorry
    finally show "H .FUNCT-2K3\<^bsub>(D,[:ZFMISC-1K2 A,B :])\<^esub> d =HIDDENR1 [TARSKIK4 pr1FUNCT-2K4\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,A)\<^esub> d,pr2FUNCT-2K5\<^bsub>(D,A,B)\<^esub> H .FUNCT-2K3\<^bsub>(D,B)\<^esub> d ]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_120:
" for A1 be setHIDDENM2 holds  for A2 be setHIDDENM2 holds  for B1 be setHIDDENM2 holds  for B2 be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A1,A2) holds  for g be FunctionFUNCT-2M1-of(B1,B2) holds f toleratesPARTFUN1R1 g implies f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g be FunctionFUNCT-2M1-of(A1 /\\XBOOLE-0K3 B1,A2 /\\XBOOLE-0K3 B2)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix A1 assume [ty]: "A1 be setHIDDENM2"
  fix A2 assume [ty]: "A2 be setHIDDENM2"
  fix B1 assume [ty]: "B1 be setHIDDENM2"
  fix B2 assume [ty]: "B2 be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A1,A2)"
  fix g assume [ty]: "g be FunctionFUNCT-2M1-of(B1,B2)"
  assume A1: "f toleratesPARTFUN1R1 g"
  have A2: "domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) c=TARSKIR1 domRELSET-1K1\<^bsub>(A1)\<^esub> f /\\SUBSET-1K9\<^bsub>(B1)\<^esub> domRELSET-1K1\<^bsub>(B1)\<^esub> g & domRELSET-1K1\<^bsub>(A1)\<^esub> f /\\SUBSET-1K9\<^bsub>(B1)\<^esub> domRELSET-1K1\<^bsub>(B1)\<^esub> g c=TARSKIR1 A1 /\\XBOOLE-0K3 B1"
    using xboole_1_th_27 xtuple_0_th_24 sorry
  have A3: "domRELSET-1K1\<^bsub>(A1)\<^esub> f =XBOOLE-0R4 A1 & (A1 <>HIDDENR2 {}XBOOLE-0K1 & (domRELSET-1K1\<^bsub>(B1)\<^esub> g =XBOOLE-0R4 B1 & B1 <>HIDDENR2 {}XBOOLE-0K1)) implies (A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1 implies A2 /\\XBOOLE-0K3 B2 <>HIDDENR2 {}XBOOLE-0K1) & domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1"
  proof(rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
    let ?a = "the ElementSUBSET-1M1-of A1 /\\XBOOLE-0K3 B1"
    assume A4: "domRELSET-1K1\<^bsub>(A1)\<^esub> f =XBOOLE-0R4 A1"
      and "A1 <>HIDDENR2 {}XBOOLE-0K1"
      and A5: "domRELSET-1K1\<^bsub>(B1)\<^esub> g =XBOOLE-0R4 B1"
      and "B1 <>HIDDENR2 {}XBOOLE-0K1"
    show "A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1 implies A2 /\\XBOOLE-0K3 B2 <>HIDDENR2 {}XBOOLE-0K1"
    proof(rule impI)
      assume A6: "A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1"
      then have "?a inTARSKIR2 A1"
        using xboole_0_def_4 sorry
      then have A7: "f .FUNCT-1K1 ?a inTARSKIR2 rngRELSET-1K2\<^bsub>(A2)\<^esub> f"
        using A4 funct_1_def_3 sorry
      have "f .FUNCT-1K1 ?a =XBOOLE-0R4 g .FUNCT-1K1 ?a & ?a inTARSKIR2 B1"
        using A1 A4 A5 A6 xboole_0_def_4 sorry
      then have "f .FUNCT-1K1 ?a inTARSKIR2 rngRELSET-1K2\<^bsub>(B2)\<^esub> g"
        using A5 funct_1_def_3 sorry
      thus "A2 /\\XBOOLE-0K3 B2 <>HIDDENR2 {}XBOOLE-0K1"
        using A7 xboole_0_def_4 sorry
    qed
    show "domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1"
    proof-
      have "domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) c=TARSKIR1 A1 /\\XBOOLE-0K3 B1 & A1 /\\XBOOLE-0K3 B1 c=TARSKIR1 domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g)"
      proof(rule conjMI)
        show "domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) c=TARSKIR1 A1 /\\XBOOLE-0K3 B1"
          using A2 sorry
        have " for a be objectHIDDENM1 holds a inHIDDENR3 A1 /\\XBOOLE-0K3 B1 implies a inHIDDENR3 domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g)"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume A8: "a inHIDDENR3 A1 /\\XBOOLE-0K3 B1"
          then have "a inHIDDENR3 A1"
            using xboole_0_def_4 sorry
          then have A9: "[TARSKIK4 a,f .FUNCT-1K1 a ] inHIDDENR3 f"
            using A4 funct_1_def_2 sorry
          have "f .FUNCT-1K1 a =XBOOLE-0R4 g .FUNCT-1K1 a & a inHIDDENR3 B1"
            using A1 A4 A5 A8 xboole_0_def_4 sorry
          then have "[TARSKIK4 a,f .FUNCT-1K1 a ] inHIDDENR3 g"
            using A5 funct_1_def_2 sorry
          then have "[TARSKIK4 a,f .FUNCT-1K1 a ] inHIDDENR3 f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g"
            using A9 xboole_0_def_4 sorry
          thus "a inHIDDENR3 domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g)"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "A1 /\\XBOOLE-0K3 B1 c=TARSKIR1 domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g)"
          using tarski_def_3 sorry
      qed
      thus "domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1"
        using xboole_0_def_10 sorry
    qed
  qed
  have "rngRELSET-1K2\<^bsub>(A2)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) c=TARSKIR1 rngRELSET-1K2\<^bsub>(A2)\<^esub> f /\\SUBSET-1K9\<^bsub>(B2)\<^esub> rngRELSET-1K2\<^bsub>(B2)\<^esub> g & rngRELSET-1K2\<^bsub>(A2)\<^esub> f /\\SUBSET-1K9\<^bsub>(B2)\<^esub> rngRELSET-1K2\<^bsub>(B2)\<^esub> g c=TARSKIR1 A2 /\\XBOOLE-0K3 B2"
    using relat_1_th_13 xboole_1_th_27 sorry
  then have A10: "rngRELSET-1K2\<^bsub>(A2)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) c=TARSKIR1 A2 /\\XBOOLE-0K3 B2"
     sorry
  have A11: "A2 =XBOOLE-0R4 {}XBOOLE-0K1 or A2 <>HIDDENR2 {}XBOOLE-0K1"
     sorry
  have A12: "B2 =XBOOLE-0R4 {}XBOOLE-0K1 or B2 <>HIDDENR2 {}XBOOLE-0K1"
     sorry
  have A13: "(A2 /\\XBOOLE-0K3 B2 <>HIDDENR2 {}XBOOLE-0K1 & domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1 or A1 /\\XBOOLE-0K3 B1 =XBOOLE-0R4 {}XBOOLE-0K1 & (A1 /\\XBOOLE-0K3 B1 =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1)) or (A2 /\\XBOOLE-0K3 B2 =XBOOLE-0R4 {}XBOOLE-0K1 & A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1) & (A2 /\\XBOOLE-0K3 B2 =XBOOLE-0R4 {}XBOOLE-0K1 & A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1 implies f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g =FUNCT-1R1 {}XBOOLE-0K1)"
  proof-
    show "(A2 /\\XBOOLE-0K3 B2 <>HIDDENR2 {}XBOOLE-0K1 & domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1 or A1 /\\XBOOLE-0K3 B1 =XBOOLE-0R4 {}XBOOLE-0K1 & (A1 /\\XBOOLE-0K3 B1 =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1)) or (A2 /\\XBOOLE-0K3 B2 =XBOOLE-0R4 {}XBOOLE-0K1 & A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1) & (A2 /\\XBOOLE-0K3 B2 =XBOOLE-0R4 {}XBOOLE-0K1 & A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1 implies f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g =FUNCT-1R1 {}XBOOLE-0K1)"
    proof-
      have cases: "(A2 /\\XBOOLE-0K3 B2 <>HIDDENR2 {}XBOOLE-0K1 or A1 /\\XBOOLE-0K3 B1 =XBOOLE-0R4 {}XBOOLE-0K1) or A2 /\\XBOOLE-0K3 B2 =XBOOLE-0R4 {}XBOOLE-0K1 & A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "A2 /\\XBOOLE-0K3 B2 <>HIDDENR2 {}XBOOLE-0K1 implies domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1"
      proof(rule impI)
        assume "A2 /\\XBOOLE-0K3 B2 <>HIDDENR2 {}XBOOLE-0K1"
        thus "domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1"
          using A12 A3 funct_2_def_1 A11 sorry
      qed
      have case2: "A1 /\\XBOOLE-0K3 B1 =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1"
      proof(rule impI)
        assume "A1 /\\XBOOLE-0K3 B1 =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "domRELSET-1K1\<^bsub>(A1)\<^esub> (f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g) =XBOOLE-0R4 A1 /\\XBOOLE-0K3 B1"
          using A2 sorry
      qed
      have case3: "A2 /\\XBOOLE-0K3 B2 =XBOOLE-0R4 {}XBOOLE-0K1 & A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1 implies f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g =FUNCT-1R1 {}XBOOLE-0K1"
      proof(rule impI)
        assume "A2 /\\XBOOLE-0K3 B2 =XBOOLE-0R4 {}XBOOLE-0K1 & A1 /\\XBOOLE-0K3 B1 <>HIDDENR2 {}XBOOLE-0K1"
        thus "f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g =FUNCT-1R1 {}XBOOLE-0K1"
          using A12 A3 funct_2_def_1 A11 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed
  show "f /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 B1,B2 :])\<^esub> g be FunctionFUNCT-2M1-of(A1 /\\XBOOLE-0K3 B1,A2 /\\XBOOLE-0K3 B2)"
    using A10 A13 funct_2_def_1 relset_1_th_4 sorry
qed "sorry"

mtheorem funct_2_cl_21:
  mlet "A be setHIDDENM2", "B be setHIDDENM2"
"cluster FuncsFUNCT-2K1(A,B) as-term-is functionalFUNCT-1V6"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(A,B) be functionalFUNCT-1V6"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(A,B) implies x be setHIDDENM2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 FuncsFUNCT-2K1(A,B)"
      then have " ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 A) & rngFUNCT-1K2 f c=TARSKIR1 B"
        using funct_2_def_2 sorry
      thus "x be setHIDDENM2"
         sorry
    qed "sorry"
    thus "FuncsFUNCT-2K1(A,B) be functionalFUNCT-1V6"
      using funct_1_def_13 sorry
  qed
qed "sorry"

mdef funct_2_def_12 ("FUNCTION-DOMAINFUNCT-2M3-of'( _ , _ ')" [0,0]70 ) where
  mlet "A be setHIDDENM2", "B be setHIDDENM2"
"mode FUNCTION-DOMAINFUNCT-2M3-of(A,B) \<rightarrow>  non emptyXBOOLE-0V1\<bar>setHIDDENM2 means
  (\<lambda>it.  for x be ElementSUBSET-1M1-of it holds x be FunctionFUNCT-2M1-of(A,B))"
proof-
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st  for x be ElementSUBSET-1M1-of it holds x be FunctionFUNCT-2M1-of(A,B)"
    proof-
      have " ex IT be setHIDDENM2 st  for g be ElementSUBSET-1M1-of IT holds g be FunctionFUNCT-2M1-of(A,B)"
      proof-
        obtain IT where 
          [ty]:"IT be setHIDDENM2" and ITDef:"IT = {TARSKIK1 the FunctionFUNCT-2M1-of(A,B) }"
           sorry
        show " ex IT be setHIDDENM2 st  for g be ElementSUBSET-1M1-of IT holds g be FunctionFUNCT-2M1-of(A,B)"
        proof(rule bexI[of _ "IT"],rule ballI)
          fix g assume [ty]: "g be ElementSUBSET-1M1-of IT"
          show "g be FunctionFUNCT-2M1-of(A,B)"
            using tarski_def_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_2_cl_22:
  mlet "A be setHIDDENM2", "B be setHIDDENM2"
"cluster note-that functionalFUNCT-1V6 for FUNCTION-DOMAINFUNCT-2M3-of(A,B)"
proof
(*coherence*)
  show " for it be FUNCTION-DOMAINFUNCT-2M3-of(A,B) holds it be functionalFUNCT-1V6"
    using funct_2_def_12 sorry
qed "sorry"

mtheorem funct_2_th_121:
" for P be setHIDDENM2 holds  for Q be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(P,Q) holds {TARSKIK1 f} be FUNCTION-DOMAINFUNCT-2M3-of(P,Q)"
proof-
  have " for P be setHIDDENM2 holds  for Q be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(P,Q) holds {TARSKIK1 f} be FUNCTION-DOMAINFUNCT-2M3-of(P,Q)"
  proof(rule ballI,rule ballI,rule ballI)
    fix P assume [ty]: "P be setHIDDENM2"
    fix Q assume [ty]: "Q be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(P,Q)"
    have " for g be ElementSUBSET-1M1-of {TARSKIK1 f} holds g be FunctionFUNCT-2M1-of(P,Q)"
      using tarski_def_1 sorry
    thus "{TARSKIK1 f} be FUNCTION-DOMAINFUNCT-2M3-of(P,Q)"
      using funct_2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_122:
" for P be setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds FuncsFUNCT-2K1(P,B) be FUNCTION-DOMAINFUNCT-2M3-of(P,B)"
proof-
  have " for P be setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds FuncsFUNCT-2K1(P,B) be FUNCTION-DOMAINFUNCT-2M3-of(P,B)"
  proof(rule ballI,rule ballI)
    fix P assume [ty]: "P be setHIDDENM2"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have " for f be ElementSUBSET-1M1-of FuncsFUNCT-2K1(P,B) holds f be FunctionFUNCT-2M1-of(P,B)"
      using funct_2_th_66 sorry
    thus "FuncsFUNCT-2K1(P,B) be FUNCTION-DOMAINFUNCT-2M3-of(P,B)"
      using funct_2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_2K9("FuncsFUNCT-2K9'( _ , _ ')" [0,0]228) where
  "FuncsFUNCT-2K9(A,B) \<equiv> FuncsFUNCT-2K1(A,B)"

mtheorem funct_2_add_5:
  mlet "A be setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(A,B) as-term-is FUNCTION-DOMAINFUNCT-2M3-of(A,B)"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(A,B) be FUNCTION-DOMAINFUNCT-2M3-of(A,B)"
    using funct_2_th_122 sorry
qed "sorry"

syntax FUNCT_2M4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Ty" ("ElementFUNCT-2M4\<^bsub>'( _ , _ ')\<^esub>-of  _ " [0,0,70]70)
translations "ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of F" \<rightharpoonup> "ElementSUBSET-1M1-of F"

mtheorem funct_2_add_6:
  mlet "A be setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FUNCTION-DOMAINFUNCT-2M3-of(A,B)"
"cluster note-that FunctionFUNCT-2M1-of(A,B) for ElementSUBSET-1M1-of F"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of F holds it be FunctionFUNCT-2M1-of(A,B)"
    using funct_2_def_12 sorry
qed "sorry"

mtheorem funct_2_cl_23:
  mlet "I be setHIDDENM2"
"cluster idPARTFUN1K6 I as-term-is totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 idPARTFUN1K6 I implies it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
     sorry
qed "sorry"

syntax FUNCT_2K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/.FUNCT-2K10\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "F /.FUNCT-2K10\<^bsub>(X,A)\<^esub> x" \<rightharpoonup> "F /.PARTFUN1K7\<^bsub>(A)\<^esub> x"

mtheorem funct_2_def_13:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FunctionFUNCT-2M1-of(X,A)", "x be setHIDDENM2"
"assume x inTARSKIR2 X redefine func F /.FUNCT-2K10\<^bsub>(X,A)\<^esub> x \<rightarrow> ElementSUBSET-1M1-of A equals
  F .FUNCT-1K1 x"
proof
(*compatibility*)
  show "x inTARSKIR2 X implies ( for it be ElementSUBSET-1M1-of A holds it =HIDDENR1 F /.FUNCT-2K10\<^bsub>(X,A)\<^esub> x iff it =HIDDENR1 F .FUNCT-1K1 x)"
  proof(rule impI)
    assume Assume: "x inTARSKIR2 X"
    have A1: "x inTARSKIR2 X"
      using Assume sorry
    show " for it be ElementSUBSET-1M1-of A holds it =HIDDENR1 F /.FUNCT-2K10\<^bsub>(X,A)\<^esub> x iff it =HIDDENR1 F .FUNCT-1K1 x"
    proof-
      have " for a be ElementSUBSET-1M1-of A holds  not (a =HIDDENR1 F /.PARTFUN1K7\<^bsub>(A)\<^esub> x &  not a =HIDDENR1 F .FUNCT-1K1 x) &  not (a =HIDDENR1 F .FUNCT-1K1 x &  not a =HIDDENR1 F /.PARTFUN1K7\<^bsub>(A)\<^esub> x)"
      proof(rule ballI)
        fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
        have "x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> F"
          using A1 funct_2_def_1 sorry
        thus " not (a =HIDDENR1 F /.PARTFUN1K7\<^bsub>(A)\<^esub> x &  not a =HIDDENR1 F .FUNCT-1K1 x) &  not (a =HIDDENR1 F .FUNCT-1K1 x &  not a =HIDDENR1 F /.PARTFUN1K7\<^bsub>(A)\<^esub> x)"
          using partfun1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  qed
qed "sorry"

mtheorem funct_2_th_123:
" for X be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be X -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f *FUNCT-1K3 g) =XBOOLE-0R4 domRELAT-1K1 g"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
  fix g assume [ty]: "g be X -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
  have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
    using funct_2_def_1 sorry
  then have "rngRELSET-1K2\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
     sorry
  thus "domRELAT-1K1 (f *FUNCT-1K3 g) =XBOOLE-0R4 domRELAT-1K1 g"
    using relat_1_th_27 sorry
qed "sorry"

mtheorem funct_2_th_124:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,X) holds ( for x be ElementSUBSET-1M1-of X holds f .FUNCT-2K3\<^bsub>(X,X)\<^esub> x =XBOOLE-0R4 x) implies f =FUNCT-2R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
   sorry

abbreviation(input) FUNCT_2M5("ActionFUNCT-2M5-of'( _ , _ ')" [0,0]70) where
  "ActionFUNCT-2M5-of(O,E) \<equiv> FunctionFUNCT-2M1-of(O,FuncsFUNCT-2K1(E,E))"

mtheorem funct_2_th_125:
" for x be setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of({TARSKIK1 x},A) holds  for g be FunctionFUNCT-2M1-of({TARSKIK1 x},A) holds f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x implies f =FUNCT-2R2\<^bsub>({TARSKIK1 x},A)\<^esub> g"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be setHIDDENM2"
  fix A assume [ty]: "A be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of({TARSKIK1 x},A)"
  fix g assume [ty]: "g be FunctionFUNCT-2M1-of({TARSKIK1 x},A)"
  assume A1: "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
  have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "y inHIDDENR3 {TARSKIK1 x}"
    then have "y =HIDDENR1 x"
      using tarski_def_1 sorry
    thus "f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
      using A1 sorry
  qed "sorry"
  thus "f =FUNCT-2R2\<^bsub>({TARSKIK1 x},A)\<^esub> g"
     sorry
qed "sorry"

mtheorem funct_2_th_126:
" for A be setHIDDENM2 holds idPARTFUN1K6 A inTARSKIR2 FuncsFUNCT-2K1(A,A)"
proof(rule ballI)
  fix A assume [ty]: "A be setHIDDENM2"
  have "domRELSET-1K1\<^bsub>(A)\<^esub> (idPARTFUN1K6 A) =XBOOLE-0R4 A & rngRELSET-1K2\<^bsub>(A)\<^esub> (idPARTFUN1K6 A) =XBOOLE-0R4 A"
     sorry
  thus "idPARTFUN1K6 A inTARSKIR2 FuncsFUNCT-2K1(A,A)"
    using funct_2_def_2 sorry
qed "sorry"

mtheorem funct_2_th_127:
"FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 idPARTFUN1K6 ({}XBOOLE-0K1) }"
proof-
  have "( for f be objectHIDDENM1 holds f inHIDDENR3 FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1) implies f inHIDDENR3 {TARSKIK1 idPARTFUN1K6 ({}XBOOLE-0K1) }) & {TARSKIK1 idPARTFUN1K6 ({}XBOOLE-0K1) } c=TARSKIR1 FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1)"
  proof(rule conjMI)
    show " for f be objectHIDDENM1 holds f inHIDDENR3 FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1) implies f inHIDDENR3 {TARSKIK1 idPARTFUN1K6 ({}XBOOLE-0K1) }"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be objectHIDDENM1"
      assume "f inHIDDENR3 FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1)"
      then obtain f9 where 
        [ty]:"f9 be FunctionFUNCT-2M1-of({}XBOOLE-0K1,{}XBOOLE-0K1)" and f9Def:"f9 = f"
        using funct_2_th_66 sorry
      have "f9 =FUNCT-2R2\<^bsub>({}XBOOLE-0K1,{}XBOOLE-0K1)\<^esub> idPARTFUN1K6 ({}XBOOLE-0K1)"
         sorry
      thus "f inHIDDENR3 {TARSKIK1 idPARTFUN1K6 ({}XBOOLE-0K1) }"
        using tarski_def_1 sorry
    qed "sorry"
    show "{TARSKIK1 idPARTFUN1K6 ({}XBOOLE-0K1) } c=TARSKIR1 FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1)"
      using funct_2_th_126 zfmisc_1_th_31 sorry
  qed
  thus "FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 idPARTFUN1K6 ({}XBOOLE-0K1) }"
    using tarski_def_3 xboole_0_def_10 sorry
qed

mtheorem funct_2_th_128:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f inTARSKIR2 FuncsFUNCT-2K1(A,B) & g inTARSKIR2 FuncsFUNCT-2K1(B,C) implies g *FUNCT-1K3 f inTARSKIR2 FuncsFUNCT-2K1(A,C)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  fix C assume [ty]: "C be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  assume A1: "f inTARSKIR2 FuncsFUNCT-2K1(A,B)"
    and A2: "g inTARSKIR2 FuncsFUNCT-2K1(B,C)"
  have A3: " ex g9 be FunctionFUNCT-1M1 st (g9 =FUNCT-1R1 g & domRELAT-1K1 g9 =XBOOLE-0R4 B) & rngFUNCT-1K2 g9 c=TARSKIR1 C"
    using A2 funct_2_def_2 sorry
  have "rngFUNCT-1K2 (g *FUNCT-1K3 f) c=TARSKIR1 rngFUNCT-1K2 g"
    using relat_1_th_26 sorry
  then have A4: "rngFUNCT-1K2 (g *FUNCT-1K3 f) c=TARSKIR1 C"
    using A3 sorry
  have " ex f9 be FunctionFUNCT-1M1 st (f9 =FUNCT-1R1 f & domRELAT-1K1 f9 =XBOOLE-0R4 A) & rngFUNCT-1K2 f9 c=TARSKIR1 B"
    using A1 funct_2_def_2 sorry
  then have "domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 A"
    using A3 relat_1_th_27 sorry
  thus "g *FUNCT-1K3 f inTARSKIR2 FuncsFUNCT-2K1(A,C)"
    using A4 funct_2_def_2 sorry
qed "sorry"

mtheorem funct_2_th_129:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds FuncsFUNCT-2K1(A,B) <>HIDDENR2 {}XBOOLE-0K1 & FuncsFUNCT-2K1(B,C) <>HIDDENR2 {}XBOOLE-0K1 implies FuncsFUNCT-2K1(A,C) <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds FuncsFUNCT-2K1(A,B) <>HIDDENR2 {}XBOOLE-0K1 & FuncsFUNCT-2K1(B,C) <>HIDDENR2 {}XBOOLE-0K1 implies  not FuncsFUNCT-2K1(A,C) <>HIDDENR2 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    assume A1: "FuncsFUNCT-2K1(A,B) <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "FuncsFUNCT-2K1(B,C) <>HIDDENR2 {}XBOOLE-0K1"
    obtain g where
      [ty]:"g be objectHIDDENM1" and 
      A3: "g inHIDDENR3 FuncsFUNCT-2K1(B,C)"
      using A2 xboole_0_def_1 sorry
    have " ex f be objectHIDDENM1 st f inHIDDENR3 FuncsFUNCT-2K1(A,B)"
      using A1 xboole_0_def_1 sorry
    thus " not FuncsFUNCT-2K1(A,C) <>HIDDENR2 {}XBOOLE-0K1"
      using A3 funct_2_th_128 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_2_th_130:
" for A be setHIDDENM2 holds {}XBOOLE-0K1 be FunctionFUNCT-2M1-of(A,{}XBOOLE-0K1)"
  using funct_2_def_1 relset_1_th_12 sorry

theorem funct_2_sch_11:
  fixes Xf0 Yf0 Ff1 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: " for x be setHIDDENM2 holds x inTARSKIR2 Xf0 implies Ff1(x) inHIDDENR3 Yf0"
  shows " ex f be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be setHIDDENM2 holds x inTARSKIR2 Xf0 implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
  proof-
    have " ex tVar24 be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be setHIDDENM2 holds  not (x inTARSKIR2 Xf0 &  not tVar24 .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Yf0 & ?P(x,y))"
        using A1 sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(Xf0,Yf0)" and 
        A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ?P(x,f .FUNCT-1K1 x)"
        using funct_2_sch_1 A2 sorry
      show " ex tVar24 be FunctionFUNCT-2M1-of(Xf0,Yf0) st  for x be setHIDDENM2 holds  not (x inTARSKIR2 Xf0 &  not tVar24 .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
      proof(rule bexI[of _ "f"])
        show " for x be setHIDDENM2 holds  not (x inTARSKIR2 Xf0 &  not f .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

end
