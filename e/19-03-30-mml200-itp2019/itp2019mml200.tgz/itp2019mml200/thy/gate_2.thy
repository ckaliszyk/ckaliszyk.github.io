theory gate_2
  imports gate_1
begin
(*begin*)
reserve a, b, c, d for "setHIDDENM2"
mtheorem gate_2_th_1:
" for s0 be setHIDDENM2 holds  for s1 be setHIDDENM2 holds  for s2 be setHIDDENM2 holds  for s3 be setHIDDENM2 holds  for s4 be setHIDDENM2 holds  for s5 be setHIDDENM2 holds  for s6 be setHIDDENM2 holds  for s7 be setHIDDENM2 holds  for ns0 be setHIDDENM2 holds  for ns1 be setHIDDENM2 holds  for ns2 be setHIDDENM2 holds  for ns3 be setHIDDENM2 holds  for ns4 be setHIDDENM2 holds  for ns5 be setHIDDENM2 holds  for ns6 be setHIDDENM2 holds  for ns7 be setHIDDENM2 holds  for q1 be setHIDDENM2 holds  for q2 be setHIDDENM2 holds  for q3 be setHIDDENM2 holds  for nq1 be setHIDDENM2 holds  for nq2 be setHIDDENM2 holds  for nq3 be setHIDDENM2 holds ((((((((((((((((((s0 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1) & (s1 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,q1) be emptyXBOOLE-0V1)) & (s2 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,q2,q1) be emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1)) & (s5 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,NOT1GATE-1K1 q2,q1) be emptyXBOOLE-0V1)) & (s6 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1)) & (s7 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,q2,q1) be emptyXBOOLE-0V1)) & (ns0 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1)) & (ns1 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,nq1) be emptyXBOOLE-0V1)) & (ns2 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1)) & (ns3 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,nq1) be emptyXBOOLE-0V1)) & (ns4 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1)) & (ns5 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,nq1) be emptyXBOOLE-0V1)) & (ns6 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1)) & (ns7 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,nq2,nq1) be emptyXBOOLE-0V1)) & (nq1 be  non emptyXBOOLE-0V1 iff  not NOT1GATE-1K1 q1 be emptyXBOOLE-0V1)) & (nq2 be  non emptyXBOOLE-0V1 iff  not XOR2GATE-1K4(q1,q2) be emptyXBOOLE-0V1)) & (nq3 be  non emptyXBOOLE-0V1 iff  not OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be emptyXBOOLE-0V1) implies (((((((ns1 be  non emptyXBOOLE-0V1 iff s0 be  non emptyXBOOLE-0V1) & (ns2 be  non emptyXBOOLE-0V1 iff s1 be  non emptyXBOOLE-0V1)) & (ns3 be  non emptyXBOOLE-0V1 iff s2 be  non emptyXBOOLE-0V1)) & (ns4 be  non emptyXBOOLE-0V1 iff s3 be  non emptyXBOOLE-0V1)) & (ns5 be  non emptyXBOOLE-0V1 iff s4 be  non emptyXBOOLE-0V1)) & (ns6 be  non emptyXBOOLE-0V1 iff s5 be  non emptyXBOOLE-0V1)) & (ns7 be  non emptyXBOOLE-0V1 iff s6 be  non emptyXBOOLE-0V1)) & (ns0 be  non emptyXBOOLE-0V1 iff s7 be  non emptyXBOOLE-0V1)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix s0 assume [ty]: "s0 be setHIDDENM2"
  fix s1 assume [ty]: "s1 be setHIDDENM2"
  fix s2 assume [ty]: "s2 be setHIDDENM2"
  fix s3 assume [ty]: "s3 be setHIDDENM2"
  fix s4 assume [ty]: "s4 be setHIDDENM2"
  fix s5 assume [ty]: "s5 be setHIDDENM2"
  fix s6 assume [ty]: "s6 be setHIDDENM2"
  fix s7 assume [ty]: "s7 be setHIDDENM2"
  fix ns0 assume [ty]: "ns0 be setHIDDENM2"
  fix ns1 assume [ty]: "ns1 be setHIDDENM2"
  fix ns2 assume [ty]: "ns2 be setHIDDENM2"
  fix ns3 assume [ty]: "ns3 be setHIDDENM2"
  fix ns4 assume [ty]: "ns4 be setHIDDENM2"
  fix ns5 assume [ty]: "ns5 be setHIDDENM2"
  fix ns6 assume [ty]: "ns6 be setHIDDENM2"
  fix ns7 assume [ty]: "ns7 be setHIDDENM2"
  fix q1 assume [ty]: "q1 be setHIDDENM2"
  fix q2 assume [ty]: "q2 be setHIDDENM2"
  fix q3 assume [ty]: "q3 be setHIDDENM2"
  fix nq1 assume [ty]: "nq1 be setHIDDENM2"
  fix nq2 assume [ty]: "nq2 be setHIDDENM2"
  fix nq3 assume [ty]: "nq3 be setHIDDENM2"
  show "((((((((((((((((((s0 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1) & (s1 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,q1) be emptyXBOOLE-0V1)) & (s2 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,q2,q1) be emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1)) & (s5 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,NOT1GATE-1K1 q2,q1) be emptyXBOOLE-0V1)) & (s6 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1)) & (s7 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,q2,q1) be emptyXBOOLE-0V1)) & (ns0 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1)) & (ns1 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,nq1) be emptyXBOOLE-0V1)) & (ns2 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1)) & (ns3 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,nq1) be emptyXBOOLE-0V1)) & (ns4 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1)) & (ns5 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,nq1) be emptyXBOOLE-0V1)) & (ns6 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1)) & (ns7 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,nq2,nq1) be emptyXBOOLE-0V1)) & (nq1 be  non emptyXBOOLE-0V1 iff  not NOT1GATE-1K1 q1 be emptyXBOOLE-0V1)) & (nq2 be  non emptyXBOOLE-0V1 iff  not XOR2GATE-1K4(q1,q2) be emptyXBOOLE-0V1)) & (nq3 be  non emptyXBOOLE-0V1 iff  not OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be emptyXBOOLE-0V1) implies (((((((ns1 be  non emptyXBOOLE-0V1 iff s0 be  non emptyXBOOLE-0V1) & (ns2 be  non emptyXBOOLE-0V1 iff s1 be  non emptyXBOOLE-0V1)) & (ns3 be  non emptyXBOOLE-0V1 iff s2 be  non emptyXBOOLE-0V1)) & (ns4 be  non emptyXBOOLE-0V1 iff s3 be  non emptyXBOOLE-0V1)) & (ns5 be  non emptyXBOOLE-0V1 iff s4 be  non emptyXBOOLE-0V1)) & (ns6 be  non emptyXBOOLE-0V1 iff s5 be  non emptyXBOOLE-0V1)) & (ns7 be  non emptyXBOOLE-0V1 iff s6 be  non emptyXBOOLE-0V1)) & (ns0 be  non emptyXBOOLE-0V1 iff s7 be  non emptyXBOOLE-0V1)"
  proof-
    have "(s0 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1) & ((s1 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,q1) be emptyXBOOLE-0V1) & ((s2 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1) & ((s3 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,q2,q1) be emptyXBOOLE-0V1) & ((s4 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1) & ((s5 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,NOT1GATE-1K1 q2,q1) be emptyXBOOLE-0V1) & ((s6 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1) & ((s7 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,q2,q1) be emptyXBOOLE-0V1) & ((ns0 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1) & ((ns1 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,nq1) be emptyXBOOLE-0V1) & ((ns2 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1) & ((ns3 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,nq1) be emptyXBOOLE-0V1) & ((ns4 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1) & ((ns5 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,nq1) be emptyXBOOLE-0V1) & ((ns6 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1) & ((ns7 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,nq2,nq1) be emptyXBOOLE-0V1) & (((nq1 be  non emptyXBOOLE-0V1 iff  not NOT1GATE-1K1 q1 be emptyXBOOLE-0V1) & (nq2 be  non emptyXBOOLE-0V1 iff  not XOR2GATE-1K4(q1,q2) be emptyXBOOLE-0V1)) & (nq3 be  non emptyXBOOLE-0V1 iff  not OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be emptyXBOOLE-0V1))))))))))))))))) implies (ns1 be  non emptyXBOOLE-0V1 iff s0 be  non emptyXBOOLE-0V1) & ((ns2 be  non emptyXBOOLE-0V1 iff s1 be  non emptyXBOOLE-0V1) & ((ns3 be  non emptyXBOOLE-0V1 iff s2 be  non emptyXBOOLE-0V1) & ((ns4 be  non emptyXBOOLE-0V1 iff s3 be  non emptyXBOOLE-0V1) & ((ns5 be  non emptyXBOOLE-0V1 iff s4 be  non emptyXBOOLE-0V1) & ((ns6 be  non emptyXBOOLE-0V1 iff s5 be  non emptyXBOOLE-0V1) & ((ns7 be  non emptyXBOOLE-0V1 iff s6 be  non emptyXBOOLE-0V1) & ( not ( not ns0 be emptyXBOOLE-0V1 & s7 be emptyXBOOLE-0V1) &  not ( not s7 be emptyXBOOLE-0V1 & ns0 be emptyXBOOLE-0V1))))))))"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
      assume A1: "s0 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1"
        and A2: "s1 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,q1) be emptyXBOOLE-0V1"
        and A3: "s2 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1"
        and A4: "s3 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 q3,q2,q1) be emptyXBOOLE-0V1"
        and A5: "s4 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1"
        and A6: "s5 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,NOT1GATE-1K1 q2,q1) be emptyXBOOLE-0V1"
        and A7: "s6 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,q2,NOT1GATE-1K1 q1) be emptyXBOOLE-0V1"
        and A8: "s7 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(q3,q2,q1) be emptyXBOOLE-0V1"
        and A9: "ns0 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1"
        and A10: "ns1 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,nq1) be emptyXBOOLE-0V1"
        and A11: "ns2 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1"
        and A12: "ns3 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,nq1) be emptyXBOOLE-0V1"
        and A13: "ns4 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1"
        and A14: "ns5 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,nq1) be emptyXBOOLE-0V1"
        and A15: "ns6 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,nq2,NOT1GATE-1K1 nq1) be emptyXBOOLE-0V1"
        and A16: "ns7 be  non emptyXBOOLE-0V1 iff  not AND3GATE-1K8(nq3,nq2,nq1) be emptyXBOOLE-0V1"
        and A17: "(nq1 be  non emptyXBOOLE-0V1 iff  not NOT1GATE-1K1 q1 be emptyXBOOLE-0V1) & (nq2 be  non emptyXBOOLE-0V1 iff  not XOR2GATE-1K4(q1,q2) be emptyXBOOLE-0V1)"
        and A18: "nq3 be  non emptyXBOOLE-0V1 iff  not OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be emptyXBOOLE-0V1"
      have "ns1 be  non emptyXBOOLE-0V1 iff (NOT1GATE-1K1 nq3 be  non emptyXBOOLE-0V1 &  not ( not XOR2GATE-1K4(q1,q2) be emptyXBOOLE-0V1)) &  not q1 be  non emptyXBOOLE-0V1"
        using A10 A17 sorry
      then have "ns1 be  non emptyXBOOLE-0V1 iff ((( not ( not q3 be emptyXBOOLE-0V1) or  not ( not NOT1GATE-1K1 q1 be emptyXBOOLE-0V1)) & ( not ( not q1 be emptyXBOOLE-0V1) or  not ( not XOR2GATE-1K4(q2,q3) be emptyXBOOLE-0V1))) &  not q2 be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1"
        using A18 sorry
      thus "ns1 be  non emptyXBOOLE-0V1 iff s0 be  non emptyXBOOLE-0V1"
        using A1 sorry
      have "ns2 be  non emptyXBOOLE-0V1 iff (( not AND2GATE-1K2(q3,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1 &  not AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3)) be  non emptyXBOOLE-0V1) &  not q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
        using A11 A17 A18 gate_1_th_6 sorry
      then have "ns2 be  non emptyXBOOLE-0V1 iff ((( not q3 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) &  not q3 be  non emptyXBOOLE-0V1) &  not q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      thus "ns2 be  non emptyXBOOLE-0V1 iff s1 be  non emptyXBOOLE-0V1"
        using A2 sorry
      have "ns3 be  non emptyXBOOLE-0V1 iff (NOT1GATE-1K1 nq3 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1"
        using A12 A17 sorry
      then have "ns3 be  non emptyXBOOLE-0V1 iff ((( not q3 be  non emptyXBOOLE-0V1 or  not NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1) & ( not q1 be  non emptyXBOOLE-0V1 or  not XOR2GATE-1K4(q2,q3) be  non emptyXBOOLE-0V1)) & q2 be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1"
        using A18 sorry
      thus "ns3 be  non emptyXBOOLE-0V1 iff s2 be  non emptyXBOOLE-0V1"
        using A3 sorry
      have "ns4 be  non emptyXBOOLE-0V1 iff ((AND2GATE-1K2(q3,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1 or AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3)) be  non emptyXBOOLE-0V1) & q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
        using A13 A17 A18 gate_1_th_6 sorry
      then have "ns4 be  non emptyXBOOLE-0V1 iff ( not q3 be  non emptyXBOOLE-0V1 & q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      thus "ns4 be  non emptyXBOOLE-0V1 iff s3 be  non emptyXBOOLE-0V1"
        using A4 sorry
      have "ns5 be  non emptyXBOOLE-0V1 iff (nq3 be  non emptyXBOOLE-0V1 &  not XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1"
        using A14 A17 sorry
      then have "ns5 be  non emptyXBOOLE-0V1 iff ((AND2GATE-1K2(q3,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1 or AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3)) be  non emptyXBOOLE-0V1) &  not q2 be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1"
        using A18 sorry
      then have "ns5 be  non emptyXBOOLE-0V1 iff (q3 be  non emptyXBOOLE-0V1 & NOT1GATE-1K1 q2 be  non emptyXBOOLE-0V1) & NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1"
         sorry
      thus "ns5 be  non emptyXBOOLE-0V1 iff s4 be  non emptyXBOOLE-0V1"
        using A5 sorry
      have "ns6 be  non emptyXBOOLE-0V1 iff ((AND2GATE-1K2(q3,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1 or AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3)) be  non emptyXBOOLE-0V1) &  not q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
        using A15 A17 A18 gate_1_th_6 sorry
      then have "ns6 be  non emptyXBOOLE-0V1 iff (q3 be  non emptyXBOOLE-0V1 &  not q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      thus "ns6 be  non emptyXBOOLE-0V1 iff s5 be  non emptyXBOOLE-0V1"
        using A6 sorry
      have "ns7 be  non emptyXBOOLE-0V1 iff (nq3 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1"
        using A16 A17 sorry
      then have "ns7 be  non emptyXBOOLE-0V1 iff ((AND2GATE-1K2(q3,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1 or AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3)) be  non emptyXBOOLE-0V1) & q2 be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1"
        using A18 sorry
      then have "ns7 be  non emptyXBOOLE-0V1 iff (q3 be  non emptyXBOOLE-0V1 & q2 be  non emptyXBOOLE-0V1) & NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1"
         sorry
      thus "ns7 be  non emptyXBOOLE-0V1 iff s6 be  non emptyXBOOLE-0V1"
        using A7 sorry
      have "ns0 be  non emptyXBOOLE-0V1 iff (( not AND2GATE-1K2(q3,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1 &  not AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3)) be  non emptyXBOOLE-0V1) & q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
        using A9 A17 A18 gate_1_th_6 sorry
      then have "ns0 be  non emptyXBOOLE-0V1 iff ((( not q3 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) & q3 be  non emptyXBOOLE-0V1) & q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      thus " not ( not ns0 be emptyXBOOLE-0V1 & s7 be emptyXBOOLE-0V1) &  not ( not s7 be emptyXBOOLE-0V1 & ns0 be emptyXBOOLE-0V1)"
        using A8 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem gate_2_th_2:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds AND3GATE-1K8(AND2GATE-1K2(a,d),AND2GATE-1K2(b,d),AND2GATE-1K2(c,d)) be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(AND3GATE-1K8(a,b,c),d) be  non emptyXBOOLE-0V1"
proof-
  have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  not ( not AND3GATE-1K8(AND2GATE-1K2(a,d),AND2GATE-1K2(b,d),AND2GATE-1K2(c,d)) be emptyXBOOLE-0V1 & AND2GATE-1K2(AND3GATE-1K8(a,b,c),d) be emptyXBOOLE-0V1) &  not ( not AND2GATE-1K2(AND3GATE-1K8(a,b,c),d) be emptyXBOOLE-0V1 & AND3GATE-1K8(AND2GATE-1K2(a,d),AND2GATE-1K2(b,d),AND2GATE-1K2(c,d)) be emptyXBOOLE-0V1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix b assume [ty]: "b be setHIDDENM2"
    fix c assume [ty]: "c be setHIDDENM2"
    fix d assume [ty]: "d be setHIDDENM2"
    have "((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(a,b,c) be  non emptyXBOOLE-0V1 & d be  non emptyXBOOLE-0V1"
       sorry
    thus " not ( not AND3GATE-1K8(AND2GATE-1K2(a,d),AND2GATE-1K2(b,d),AND2GATE-1K2(c,d)) be emptyXBOOLE-0V1 & AND2GATE-1K2(AND3GATE-1K8(a,b,c),d) be emptyXBOOLE-0V1) &  not ( not AND2GATE-1K2(AND3GATE-1K8(a,b,c),d) be emptyXBOOLE-0V1 & AND3GATE-1K8(AND2GATE-1K2(a,d),AND2GATE-1K2(b,d),AND2GATE-1K2(c,d)) be emptyXBOOLE-0V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem gate_2_th_3:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds ((( not AND2GATE-1K2(a,b) be  non emptyXBOOLE-0V1 iff OR2GATE-1K3(NOT1GATE-1K1 a,NOT1GATE-1K1 b) be  non emptyXBOOLE-0V1) & (OR2GATE-1K3(a,b) be  non emptyXBOOLE-0V1 & OR2GATE-1K3(c,b) be  non emptyXBOOLE-0V1 iff OR2GATE-1K3(AND2GATE-1K2(a,c),b) be  non emptyXBOOLE-0V1)) & ((OR2GATE-1K3(a,b) be  non emptyXBOOLE-0V1 & OR2GATE-1K3(c,b) be  non emptyXBOOLE-0V1) & OR2GATE-1K3(d,b) be  non emptyXBOOLE-0V1 iff OR2GATE-1K3(AND3GATE-1K8(a,c,d),b) be  non emptyXBOOLE-0V1)) & (OR2GATE-1K3(a,b) be  non emptyXBOOLE-0V1 & (a be  non emptyXBOOLE-0V1 iff c be  non emptyXBOOLE-0V1) implies OR2GATE-1K3(c,b) be  non emptyXBOOLE-0V1)"
proof-
  have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds ((((( not (AND2GATE-1K2(a,b) be emptyXBOOLE-0V1 & OR2GATE-1K3(NOT1GATE-1K1 a,NOT1GATE-1K1 b) be emptyXBOOLE-0V1) &  not ( not OR2GATE-1K3(NOT1GATE-1K1 a,NOT1GATE-1K1 b) be emptyXBOOLE-0V1 &  not AND2GATE-1K2(a,b) be emptyXBOOLE-0V1)) &  not (( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not OR2GATE-1K3(c,b) be emptyXBOOLE-0V1) & OR2GATE-1K3(AND2GATE-1K2(a,c),b) be emptyXBOOLE-0V1)) &  not ( not OR2GATE-1K3(AND2GATE-1K2(a,c),b) be emptyXBOOLE-0V1 &  not ( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not OR2GATE-1K3(c,b) be emptyXBOOLE-0V1))) &  not ((( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not OR2GATE-1K3(c,b) be emptyXBOOLE-0V1) &  not OR2GATE-1K3(d,b) be emptyXBOOLE-0V1) & OR2GATE-1K3(AND3GATE-1K8(a,c,d),b) be emptyXBOOLE-0V1)) &  not ( not OR2GATE-1K3(AND3GATE-1K8(a,c,d),b) be emptyXBOOLE-0V1 &  not (( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not OR2GATE-1K3(c,b) be emptyXBOOLE-0V1) &  not OR2GATE-1K3(d,b) be emptyXBOOLE-0V1))) &  not ((( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not ( not a be emptyXBOOLE-0V1 & c be emptyXBOOLE-0V1)) &  not ( not c be emptyXBOOLE-0V1 & a be emptyXBOOLE-0V1)) & OR2GATE-1K3(c,b) be emptyXBOOLE-0V1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix b assume [ty]: "b be setHIDDENM2"
    fix c assume [ty]: "c be setHIDDENM2"
    fix d assume [ty]: "d be setHIDDENM2"
    have A1: "OR2GATE-1K3(a,b) be  non emptyXBOOLE-0V1 & OR2GATE-1K3(c,b) be  non emptyXBOOLE-0V1 iff (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) & (c be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1)"
       sorry
    have A2: "(OR2GATE-1K3(a,b) be  non emptyXBOOLE-0V1 & OR2GATE-1K3(c,b) be  non emptyXBOOLE-0V1) & OR2GATE-1K3(d,b) be  non emptyXBOOLE-0V1 iff ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) & (c be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1)) & (d be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1)"
       sorry
    have " not AND2GATE-1K2(a,b) be  non emptyXBOOLE-0V1 iff  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1)"
       sorry
    thus "((((( not (AND2GATE-1K2(a,b) be emptyXBOOLE-0V1 & OR2GATE-1K3(NOT1GATE-1K1 a,NOT1GATE-1K1 b) be emptyXBOOLE-0V1) &  not ( not OR2GATE-1K3(NOT1GATE-1K1 a,NOT1GATE-1K1 b) be emptyXBOOLE-0V1 &  not AND2GATE-1K2(a,b) be emptyXBOOLE-0V1)) &  not (( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not OR2GATE-1K3(c,b) be emptyXBOOLE-0V1) & OR2GATE-1K3(AND2GATE-1K2(a,c),b) be emptyXBOOLE-0V1)) &  not ( not OR2GATE-1K3(AND2GATE-1K2(a,c),b) be emptyXBOOLE-0V1 &  not ( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not OR2GATE-1K3(c,b) be emptyXBOOLE-0V1))) &  not ((( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not OR2GATE-1K3(c,b) be emptyXBOOLE-0V1) &  not OR2GATE-1K3(d,b) be emptyXBOOLE-0V1) & OR2GATE-1K3(AND3GATE-1K8(a,c,d),b) be emptyXBOOLE-0V1)) &  not ( not OR2GATE-1K3(AND3GATE-1K8(a,c,d),b) be emptyXBOOLE-0V1 &  not (( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not OR2GATE-1K3(c,b) be emptyXBOOLE-0V1) &  not OR2GATE-1K3(d,b) be emptyXBOOLE-0V1))) &  not ((( not OR2GATE-1K3(a,b) be emptyXBOOLE-0V1 &  not ( not a be emptyXBOOLE-0V1 & c be emptyXBOOLE-0V1)) &  not ( not c be emptyXBOOLE-0V1 & a be emptyXBOOLE-0V1)) & OR2GATE-1K3(c,b) be emptyXBOOLE-0V1)"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem gate_2_th_4:
" for s0 be setHIDDENM2 holds  for s1 be setHIDDENM2 holds  for s2 be setHIDDENM2 holds  for s3 be setHIDDENM2 holds  for s4 be setHIDDENM2 holds  for s5 be setHIDDENM2 holds  for s6 be setHIDDENM2 holds  for s7 be setHIDDENM2 holds  for ns0 be setHIDDENM2 holds  for ns1 be setHIDDENM2 holds  for ns2 be setHIDDENM2 holds  for ns3 be setHIDDENM2 holds  for ns4 be setHIDDENM2 holds  for ns5 be setHIDDENM2 holds  for ns6 be setHIDDENM2 holds  for ns7 be setHIDDENM2 holds  for q1 be setHIDDENM2 holds  for q2 be setHIDDENM2 holds  for q3 be setHIDDENM2 holds  for nq1 be setHIDDENM2 holds  for nq2 be setHIDDENM2 holds  for nq3 be setHIDDENM2 holds  for R be setHIDDENM2 holds ((((((((((((((((((s0 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1) & (s1 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,q1) be  non emptyXBOOLE-0V1)) & (s2 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,q2,q1) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1)) & (s5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,NOT1GATE-1K1 q2,q1) be  non emptyXBOOLE-0V1)) & (s6 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1)) & (s7 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,q2,q1) be  non emptyXBOOLE-0V1)) & (ns0 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1)) & (ns1 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,nq1) be  non emptyXBOOLE-0V1)) & (ns2 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1)) & (ns3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,nq1) be  non emptyXBOOLE-0V1)) & (ns4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1)) & (ns5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,nq1) be  non emptyXBOOLE-0V1)) & (ns6 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1)) & (ns7 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,nq2,nq1) be  non emptyXBOOLE-0V1)) & (nq1 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(NOT1GATE-1K1 q1,R) be  non emptyXBOOLE-0V1)) & (nq2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(XOR2GATE-1K4(q1,q2),R) be  non emptyXBOOLE-0V1)) & (nq3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))),R) be  non emptyXBOOLE-0V1) implies (((((((ns1 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s0,R) be  non emptyXBOOLE-0V1) & (ns2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s1,R) be  non emptyXBOOLE-0V1)) & (ns3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s2,R) be  non emptyXBOOLE-0V1)) & (ns4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s3,R) be  non emptyXBOOLE-0V1)) & (ns5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s4,R) be  non emptyXBOOLE-0V1)) & (ns6 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s5,R) be  non emptyXBOOLE-0V1)) & (ns7 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s6,R) be  non emptyXBOOLE-0V1)) & (ns0 be  non emptyXBOOLE-0V1 iff OR2GATE-1K3(s7,NOT1GATE-1K1 R) be  non emptyXBOOLE-0V1)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix s0 assume [ty]: "s0 be setHIDDENM2"
  fix s1 assume [ty]: "s1 be setHIDDENM2"
  fix s2 assume [ty]: "s2 be setHIDDENM2"
  fix s3 assume [ty]: "s3 be setHIDDENM2"
  fix s4 assume [ty]: "s4 be setHIDDENM2"
  fix s5 assume [ty]: "s5 be setHIDDENM2"
  fix s6 assume [ty]: "s6 be setHIDDENM2"
  fix s7 assume [ty]: "s7 be setHIDDENM2"
  fix ns0 assume [ty]: "ns0 be setHIDDENM2"
  fix ns1 assume [ty]: "ns1 be setHIDDENM2"
  fix ns2 assume [ty]: "ns2 be setHIDDENM2"
  fix ns3 assume [ty]: "ns3 be setHIDDENM2"
  fix ns4 assume [ty]: "ns4 be setHIDDENM2"
  fix ns5 assume [ty]: "ns5 be setHIDDENM2"
  fix ns6 assume [ty]: "ns6 be setHIDDENM2"
  fix ns7 assume [ty]: "ns7 be setHIDDENM2"
  fix q1 assume [ty]: "q1 be setHIDDENM2"
  fix q2 assume [ty]: "q2 be setHIDDENM2"
  fix q3 assume [ty]: "q3 be setHIDDENM2"
  fix nq1 assume [ty]: "nq1 be setHIDDENM2"
  fix nq2 assume [ty]: "nq2 be setHIDDENM2"
  fix nq3 assume [ty]: "nq3 be setHIDDENM2"
  fix R assume [ty]: "R be setHIDDENM2"
  show "((((((((((((((((((s0 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1) & (s1 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,q1) be  non emptyXBOOLE-0V1)) & (s2 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,q2,q1) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1)) & (s5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,NOT1GATE-1K1 q2,q1) be  non emptyXBOOLE-0V1)) & (s6 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1)) & (s7 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,q2,q1) be  non emptyXBOOLE-0V1)) & (ns0 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1)) & (ns1 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,nq1) be  non emptyXBOOLE-0V1)) & (ns2 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1)) & (ns3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,nq1) be  non emptyXBOOLE-0V1)) & (ns4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1)) & (ns5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,nq1) be  non emptyXBOOLE-0V1)) & (ns6 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1)) & (ns7 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,nq2,nq1) be  non emptyXBOOLE-0V1)) & (nq1 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(NOT1GATE-1K1 q1,R) be  non emptyXBOOLE-0V1)) & (nq2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(XOR2GATE-1K4(q1,q2),R) be  non emptyXBOOLE-0V1)) & (nq3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))),R) be  non emptyXBOOLE-0V1) implies (((((((ns1 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s0,R) be  non emptyXBOOLE-0V1) & (ns2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s1,R) be  non emptyXBOOLE-0V1)) & (ns3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s2,R) be  non emptyXBOOLE-0V1)) & (ns4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s3,R) be  non emptyXBOOLE-0V1)) & (ns5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s4,R) be  non emptyXBOOLE-0V1)) & (ns6 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s5,R) be  non emptyXBOOLE-0V1)) & (ns7 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s6,R) be  non emptyXBOOLE-0V1)) & (ns0 be  non emptyXBOOLE-0V1 iff OR2GATE-1K3(s7,NOT1GATE-1K1 R) be  non emptyXBOOLE-0V1)"
  proof-
    have "(s0 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1) & ((s1 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,q1) be  non emptyXBOOLE-0V1) & ((s2 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1) & ((s3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,q2,q1) be  non emptyXBOOLE-0V1) & ((s4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1) & ((s5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,NOT1GATE-1K1 q2,q1) be  non emptyXBOOLE-0V1) & ((s6 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1) & ((s7 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,q2,q1) be  non emptyXBOOLE-0V1) & ((ns0 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1) & ((ns1 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,nq1) be  non emptyXBOOLE-0V1) & ((ns2 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1) & ((ns3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,nq1) be  non emptyXBOOLE-0V1) & ((ns4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1) & ((ns5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,nq1) be  non emptyXBOOLE-0V1) & ((ns6 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1) & ((ns7 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,nq2,nq1) be  non emptyXBOOLE-0V1) & ((nq1 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(NOT1GATE-1K1 q1,R) be  non emptyXBOOLE-0V1) & ((nq2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(XOR2GATE-1K4(q1,q2),R) be  non emptyXBOOLE-0V1) & (nq3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))),R) be  non emptyXBOOLE-0V1)))))))))))))))))) implies (ns1 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s0,R) be  non emptyXBOOLE-0V1) & ((ns2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s1,R) be  non emptyXBOOLE-0V1) & ((ns3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s2,R) be  non emptyXBOOLE-0V1) & ((ns4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s3,R) be  non emptyXBOOLE-0V1) & ((ns5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s4,R) be  non emptyXBOOLE-0V1) & ((ns6 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s5,R) be  non emptyXBOOLE-0V1) & ((ns7 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s6,R) be  non emptyXBOOLE-0V1) & ( not ( not ns0 be emptyXBOOLE-0V1 & OR2GATE-1K3(s7,NOT1GATE-1K1 R) be emptyXBOOLE-0V1) &  not ( not OR2GATE-1K3(s7,NOT1GATE-1K1 R) be emptyXBOOLE-0V1 & ns0 be emptyXBOOLE-0V1))))))))"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
      assume A1: "s0 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1"
        and A2: "s1 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,NOT1GATE-1K1 q2,q1) be  non emptyXBOOLE-0V1"
        and A3: "s2 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1"
        and A4: "s3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 q3,q2,q1) be  non emptyXBOOLE-0V1"
        and A5: "s4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,NOT1GATE-1K1 q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1"
        and A6: "s5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,NOT1GATE-1K1 q2,q1) be  non emptyXBOOLE-0V1"
        and A7: "s6 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,q2,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1"
        and A8: "s7 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q3,q2,q1) be  non emptyXBOOLE-0V1"
        and A9: "ns0 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1"
        and A10: "ns1 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,NOT1GATE-1K1 nq2,nq1) be  non emptyXBOOLE-0V1"
        and A11: "ns2 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1"
        and A12: "ns3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(NOT1GATE-1K1 nq3,nq2,nq1) be  non emptyXBOOLE-0V1"
        and A13: "ns4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1"
        and A14: "ns5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,NOT1GATE-1K1 nq2,nq1) be  non emptyXBOOLE-0V1"
        and A15: "ns6 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,nq2,NOT1GATE-1K1 nq1) be  non emptyXBOOLE-0V1"
        and A16: "ns7 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(nq3,nq2,nq1) be  non emptyXBOOLE-0V1"
        and A17: "nq1 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(NOT1GATE-1K1 q1,R) be  non emptyXBOOLE-0V1"
        and A18: "nq2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(XOR2GATE-1K4(q1,q2),R) be  non emptyXBOOLE-0V1"
        and A19: "nq3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))),R) be  non emptyXBOOLE-0V1"
      have "ns1 be  non emptyXBOOLE-0V1 iff (( not nq3 be  non emptyXBOOLE-0V1 & ( not XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1 or  not R be  non emptyXBOOLE-0V1)) &  not q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A10 A17 A18 sorry
      then have "ns1 be  non emptyXBOOLE-0V1 iff (((( not q3 be  non emptyXBOOLE-0V1 or  not NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1) & ( not q1 be  non emptyXBOOLE-0V1 or  not XOR2GATE-1K4(q2,q3) be  non emptyXBOOLE-0V1)) &  not q2 be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A19 sorry
      thus "ns1 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s0,R) be  non emptyXBOOLE-0V1"
        using A1 sorry
      have "ns2 be  non emptyXBOOLE-0V1 iff (( not nq3 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1) & ( not NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1 or  not R be  non emptyXBOOLE-0V1)"
        using A11 A17 A18 sorry
      then have "ns2 be  non emptyXBOOLE-0V1 iff (( not nq3 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      then have "ns2 be  non emptyXBOOLE-0V1 iff ((( not AND2GATE-1K2(q3,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1 &  not AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3)) be  non emptyXBOOLE-0V1) &  not q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A19 sorry
      then have "ns2 be  non emptyXBOOLE-0V1 iff (((( not q3 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) &  not q3 be  non emptyXBOOLE-0V1) &  not q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
         sorry
      thus "ns2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s1,R) be  non emptyXBOOLE-0V1"
        using A2 sorry
      have "ns3 be  non emptyXBOOLE-0V1 iff ((( not nq3 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A12 A17 A18 sorry
      then have "ns3 be  non emptyXBOOLE-0V1 iff (((( not q3 be  non emptyXBOOLE-0V1 or  not NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1) & ( not q1 be  non emptyXBOOLE-0V1 or  not XOR2GATE-1K4(q2,q3) be  non emptyXBOOLE-0V1)) & q2 be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A19 sorry
      thus "ns3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s2,R) be  non emptyXBOOLE-0V1"
        using A3 sorry
      have "ns4 be  non emptyXBOOLE-0V1 iff ((OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be  non emptyXBOOLE-0V1 & R be  non emptyXBOOLE-0V1) &  not nq2 be  non emptyXBOOLE-0V1) &  not AND2GATE-1K2(NOT1GATE-1K1 q1,R) be  non emptyXBOOLE-0V1"
        using A13 A17 A19 sorry
      then have "ns4 be  non emptyXBOOLE-0V1 iff ((OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be  non emptyXBOOLE-0V1 & R be  non emptyXBOOLE-0V1) &  not XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
        using A18 sorry
      then have "ns4 be  non emptyXBOOLE-0V1 iff (((q3 be  non emptyXBOOLE-0V1 & NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q2,q3) be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1) & q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      then have "ns4 be  non emptyXBOOLE-0V1 iff (( not q3 be  non emptyXBOOLE-0V1 & R be  non emptyXBOOLE-0V1) & q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      thus "ns4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s3,R) be  non emptyXBOOLE-0V1"
        using A4 sorry
      have "ns5 be  non emptyXBOOLE-0V1 iff ((nq3 be  non emptyXBOOLE-0V1 & ( not XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1 or  not R be  non emptyXBOOLE-0V1)) &  not q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A14 A17 A18 sorry
      then have "ns5 be  non emptyXBOOLE-0V1 iff ((OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be  non emptyXBOOLE-0V1 &  not q2 be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A19 sorry
      then have "ns5 be  non emptyXBOOLE-0V1 iff ((q3 be  non emptyXBOOLE-0V1 & NOT1GATE-1K1 q2 be  non emptyXBOOLE-0V1) & NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
         sorry
      thus "ns5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s4,R) be  non emptyXBOOLE-0V1"
        using A5 sorry
      have "ns6 be  non emptyXBOOLE-0V1 iff ((nq3 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1) & ( not NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1 or  not R be  non emptyXBOOLE-0V1)"
        using A15 A17 A18 sorry
      then have "ns6 be  non emptyXBOOLE-0V1 iff ((nq3 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      then have "ns6 be  non emptyXBOOLE-0V1 iff (((q3 be  non emptyXBOOLE-0V1 & NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q2,q3) be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1) &  not q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
        using A19 sorry
      then have "ns6 be  non emptyXBOOLE-0V1 iff ((q3 be  non emptyXBOOLE-0V1 & R be  non emptyXBOOLE-0V1) &  not q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1"
         sorry
      thus "ns6 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s5,R) be  non emptyXBOOLE-0V1"
        using A6 sorry
      have "ns7 be  non emptyXBOOLE-0V1 iff ((nq3 be  non emptyXBOOLE-0V1 & XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A16 A17 A18 sorry
      then have "ns7 be  non emptyXBOOLE-0V1 iff ((OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be  non emptyXBOOLE-0V1 & q2 be  non emptyXBOOLE-0V1) &  not q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
        using A19 sorry
      then have "ns7 be  non emptyXBOOLE-0V1 iff ((q3 be  non emptyXBOOLE-0V1 & q2 be  non emptyXBOOLE-0V1) & NOT1GATE-1K1 q1 be  non emptyXBOOLE-0V1) & R be  non emptyXBOOLE-0V1"
         sorry
      thus "ns7 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(s6,R) be  non emptyXBOOLE-0V1"
        using A7 sorry
      have "ns0 be  non emptyXBOOLE-0V1 iff (q1 be  non emptyXBOOLE-0V1 &  not XOR2GATE-1K4(q1,q2) be  non emptyXBOOLE-0V1) &  not OR2GATE-1K3(AND2GATE-1K2(q3,NOT1GATE-1K1 q1),AND2GATE-1K2(q1,XOR2GATE-1K4(q2,q3))) be  non emptyXBOOLE-0V1 or  not R be  non emptyXBOOLE-0V1"
        using A9 A17 A18 A19 sorry
      then have "ns0 be  non emptyXBOOLE-0V1 iff ((q1 be  non emptyXBOOLE-0V1 & q2 be  non emptyXBOOLE-0V1) &  not AND2GATE-1K2(q3,NOT1GATE-1K1 q1) be  non emptyXBOOLE-0V1) &  not XOR2GATE-1K4(q2,q3) be  non emptyXBOOLE-0V1 or  not R be  non emptyXBOOLE-0V1"
         sorry
      then have "ns0 be  non emptyXBOOLE-0V1 iff ((q1 be  non emptyXBOOLE-0V1 & q2 be  non emptyXBOOLE-0V1) & q1 be  non emptyXBOOLE-0V1) & q3 be  non emptyXBOOLE-0V1 or  not R be  non emptyXBOOLE-0V1"
         sorry
      thus " not ( not ns0 be emptyXBOOLE-0V1 & OR2GATE-1K3(s7,NOT1GATE-1K1 R) be emptyXBOOLE-0V1) &  not ( not OR2GATE-1K3(s7,NOT1GATE-1K1 R) be emptyXBOOLE-0V1 & ns0 be emptyXBOOLE-0V1)"
        using A8 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

end
