theory int_1
  imports real_1 nat_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve X for "setHIDDENM2"
reserve x, y, z for "objectHIDDENM1"
reserve k, l, n for "NatNAT-1M1"
reserve r for "RealXREAL-0M1"
mlemma int_1_lm_1:
" for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } implies ( ex k be NatNAT-1M1 st z =HIDDENR1 -XCMPLX-0K4 k)"
proof-
  have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] } implies ( ex tVar1 be NatNAT-1M1 st z =HIDDENR1 -XCMPLX-0K4 tVar1)"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    have A1: "[:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] c=TARSKIR1 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      using arytm_2_th_2 zfmisc_1_th_95 sorry
    assume A2: "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
    then have A3: " not z inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      using xboole_0_def_5 sorry
    have "z inHIDDENR3 NATNUMBERSK1 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
      using A2 xboole_0_def_3 sorry
    then have "z inHIDDENR3 INTNUMBERSK5"
      using A3 numbers_def_4 xboole_0_def_5 sorry
    then obtain z9 where 
      [ty]:"z9 be ElementSUBSET-1M1-of REALNUMBERSK2" and z9Def:"z9 = z"
      using numbers_th_15 sorry
    obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      "x inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A4: "y inHIDDENR3 NATNUMBERSK1"and A5: "z =HIDDENR1 [TARSKIK4 x,y ]"
      using A2 zfmisc_1_th_84 sorry
    have 
      [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2"
      using A4 numbers_th_19 sorry
    have "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
      using A2 sorry
    then obtain x9 y9 where
      [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A6: "z9 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A7: "y =XBOOLE-0R4 y9"and A8: "+ARYTM-0K1(z9,y) =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
      using A4 A1 arytm_0_def_1 arytm_2_th_2 sorry
    have "x9 =XBOOLE-0R4 y9"
      using A5 A6 A7 xtuple_0_th_1 sorry
    then have A9: "y9 -ARYTM-1K2 x9 =XBOOLE-0R4 0NUMBERSK6"
      using arytm_1_th_18 sorry
    have 
      [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A4 sorry
    show " ex tVar1 be NatNAT-1M1 st z =HIDDENR1 -XCMPLX-0K4 tVar1"
    proof(rule bexI[of _ "y"])
      obtain x1 x2 y1 y2 where
        [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A10: "z9 =XBOOLE-0R4 [*ARYTM-0K5 x1,x2 *]"and A11: "y =XBOOLE-0R4 [*ARYTM-0K5 y1,y2 *]"and A12: "z9 +XCMPLX-0K2 y =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
        using xcmplx_0_def_4 sorry
      have A13: "x2 =XBOOLE-0R4 0NUMBERSK6"
        using A10 arytm_0_th_24 sorry
      then have A14: "+ARYTM-0K1(x2,y2) =XBOOLE-0R4 0NUMBERSK6"
        using A11 arytm_0_th_11 arytm_0_th_24 sorry
      have "y2 =XBOOLE-0R4 0NUMBERSK6"
        using A11 arytm_0_th_24 sorry
      then have A15: "y =XBOOLE-0R4 y1"
        using A11 arytm_0_def_5 sorry
      have "z9 =XBOOLE-0R4 x1"
        using A10 A13 arytm_0_def_5 sorry
      then have "z9 +XCMPLX-0K2 y =XBOOLE-0R4 0NUMBERSK6"
        using A12 A15 A8 A9 A14 arytm_0_def_5 sorry
      thus "z =HIDDENR1 -XCMPLX-0K4 y"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_1_lm_2:
" for x be objectHIDDENM1 holds  for k be NatNAT-1M1 holds x =HIDDENR1 -XCMPLX-0K4 k & k <>HIDDENR2 x implies x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
proof-
  have " for x be objectHIDDENM1 holds  for k be NatNAT-1M1 holds x =HIDDENR1 -XCMPLX-0K4 k & k <>HIDDENR2 x implies x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "x =HIDDENR1 -XCMPLX-0K4 k"
      and A2: "k <>HIDDENR2 x"
    obtain r where 
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = x"
      using A1 xreal_0_def_1 sorry
    have "r +XCMPLX-0K2 k =XBOOLE-0R4 0NUMBERSK6"
      using A1 sorry
    then obtain x1 x2 y1 y2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A3: "r =XBOOLE-0R4 [*ARYTM-0K5 x1,x2 *]"and A4: "k =XBOOLE-0R4 [*ARYTM-0K5 y1,y2 *]"and A5: "0NUMBERSK6 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
      using xcmplx_0_def_4 sorry
    have A6: "k inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have "k inTARSKIR2 REALNUMBERSK2"
      using numbers_th_19 sorry
    then have A7: "y2 =XBOOLE-0R4 0NUMBERSK6"
      using A4 arytm_0_th_24 sorry
    then have A8: "y1 =XBOOLE-0R4 k"
      using A4 arytm_0_def_5 sorry
    have "+ARYTM-0K1(x2,y2) =XBOOLE-0R4 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
      using A5 arytm_0_th_24 sorry
    then have A9: "+ARYTM-0K1(x1,y1) =XBOOLE-0R4 0NUMBERSK6"
      using A5 arytm_0_def_5 sorry
    have A10: "x1 inTARSKIR2 REAL+ARYTM-2K2 implies  False "
    proof(rule impI)
      assume "x1 inTARSKIR2 REAL+ARYTM-2K2"
      then obtain x9 y9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A11: "x1 =XBOOLE-0R4 x9"and A12: "y1 =XBOOLE-0R4 y9"and A13: "0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
        using A6 A8 A9 arytm_0_def_1 arytm_2_th_2 sorry
      have A14: "y9 =XBOOLE-0R4 0NUMBERSK6"
        using A13 arytm_2_th_5 sorry
      have "x9 =XBOOLE-0R4 0NUMBERSK6"
        using A13 arytm_2_th_5 sorry
      thus " False "
        using A2 A3 A4 A7 A11 A12 A14 arytm_0_th_24 sorry
    qed
    have "x2 =XBOOLE-0R4 0NUMBERSK6"
      using A3 arytm_0_th_24 sorry
    then have A15: "x1 =XBOOLE-0R4 r"
      using A3 arytm_0_def_5 sorry
    have "r inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      using numbers_def_1 xboole_0_def_5 sorry
    then have "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      using A15 A10 xboole_0_def_3 sorry
    then obtain x9 y9 where
      [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A16: "x1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A17: "y1 =XBOOLE-0R4 y9"and A18: "0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
      using A6 A15 A8 A9 arytm_0_def_1 arytm_2_th_2 sorry
    have A19: "0NUMBERSK6 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
      using tarski_def_1 sorry
    have A20: " not r inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      using numbers_def_1 xboole_0_def_5 sorry
    have "x9 =XBOOLE-0R4 y9"
      using A18 arytm_0_th_6 sorry
    then have "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
      using A15 A8 A16 A17 A19 zfmisc_1_th_87 A6 sorry
    thus "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      using A20 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) INT_1K1("INTINT-1K1" 355) where
  "INTINT-1K1 \<equiv> INTNUMBERSK5"

mtheorem int_1_def_1:
"redefine func INTINT-1K1 \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k)"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 INTINT-1K1 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k))"
  proof-
    have " for I be setHIDDENM2 holds (I =XBOOLE-0R4 INTNUMBERSK5 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 I iff ( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k))) & (( for x be objectHIDDENM1 holds x inHIDDENR3 I iff ( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k)) implies I =HIDDENR1 INTNUMBERSK5)"
    proof(rule ballI,rule conjMI,rule impI)
      fix I assume [ty]: "I be setHIDDENM2"
      show "I =XBOOLE-0R4 INTNUMBERSK5 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 I iff ( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k))"
      proof-
        have "I =XBOOLE-0R4 INTNUMBERSK5 implies ( for x be objectHIDDENM1 holds (x inHIDDENR3 I implies ( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k)) & (( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k) implies x inHIDDENR3 I))"
        proof(rule impI,rule ballI,rule conjMI,rule impI)
          assume A1: "I =XBOOLE-0R4 INTNUMBERSK5"
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 I implies ( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k)"
          proof-
            have "x inHIDDENR3 I implies  not ( for k be NatNAT-1M1 holds  not x =HIDDENR1 k &  not x =HIDDENR1 -XCMPLX-0K4 k)"
            proof(rule impI)
              assume A2: "x inHIDDENR3 I"
              then have A3: " not x inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                using A1 numbers_def_4 xboole_0_def_5 sorry
              show " not ( for k be NatNAT-1M1 holds  not x =HIDDENR1 k &  not x =HIDDENR1 -XCMPLX-0K4 k)"
              proof-
                have cases: "x inHIDDENR3 NATNUMBERSK1 or x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
                  using A1 A2 numbers_def_4 xboole_0_def_3 sorry
                have case1: "x inHIDDENR3 NATNUMBERSK1 implies  not ( for k be NatNAT-1M1 holds  not x =HIDDENR1 k &  not x =HIDDENR1 -XCMPLX-0K4 k)"
                proof(rule impI)
                  assume "x inHIDDENR3 NATNUMBERSK1"
                  thus " not ( for k be NatNAT-1M1 holds  not x =HIDDENR1 k &  not x =HIDDENR1 -XCMPLX-0K4 k)"
                     sorry
                qed
                have case2: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] implies  not ( for k be NatNAT-1M1 holds  not x =HIDDENR1 k &  not x =HIDDENR1 -XCMPLX-0K4 k)"
                proof(rule impI)
                  assume "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
                  then have "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                    using A3 xboole_0_def_5 sorry
                  thus " not ( for k be NatNAT-1M1 holds  not x =HIDDENR1 k &  not x =HIDDENR1 -XCMPLX-0K4 k)"
                    using int_1_lm_1 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " ?thesis "
               sorry
          qed
          assume Given: " ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A4: "x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k"
             sorry
          show "x inHIDDENR3 I"
          proof-
            have cases: "x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k & k <>HIDDENR2 x"
              using A4 sorry
            have case1: "x =HIDDENR1 k implies x inHIDDENR3 I"
            proof(rule impI)
              assume "x =HIDDENR1 k"
              then have A5: "x inHIDDENR3 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              then have "x inHIDDENR3 REALNUMBERSK2"
                using numbers_th_19 sorry
              then have A6: " not x inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                using numbers_def_1 xboole_0_def_5 sorry
              have "x inHIDDENR3 NATNUMBERSK1 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
                using xboole_0_def_3 A5 sorry
              thus "x inHIDDENR3 I"
                using A1 A6 numbers_def_4 xboole_0_def_5 sorry
            qed
            have case2: "x =HIDDENR1 -XCMPLX-0K4 k & k <>HIDDENR2 x implies x inHIDDENR3 I"
            proof(rule impI)
              assume "x =HIDDENR1 -XCMPLX-0K4 k & k <>HIDDENR2 x"
              then have A7: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                using int_1_lm_2 sorry
              then have A8: " not x inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                using xboole_0_def_5 sorry
              have "x inHIDDENR3 NATNUMBERSK1 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
                using A7 xboole_0_def_3 sorry
              thus "x inHIDDENR3 I"
                using A1 A8 numbers_def_4 xboole_0_def_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      assume A9: " for x be objectHIDDENM1 holds x inHIDDENR3 I iff ( ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k)"
      have "I c=TARSKIR1 INTNUMBERSK5 & INTNUMBERSK5 c=TARSKIR1 I"
      proof(rule conjMI)
        show "I c=TARSKIR1 INTNUMBERSK5"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 I implies x inHIDDENR3 INTNUMBERSK5"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 I"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A10: "x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k"
              using A9 sorry
            show "x inHIDDENR3 INTNUMBERSK5"
            proof-
              have cases: "x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k & k <>HIDDENR2 x"
                using A10 sorry
              have case1: "x =HIDDENR1 k implies x inHIDDENR3 INTNUMBERSK5"
              proof(rule impI)
                assume "x =HIDDENR1 k"
                then have A11: "x inHIDDENR3 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                then have "x inHIDDENR3 REALNUMBERSK2"
                  using numbers_th_19 sorry
                then have A12: " not x inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                  using numbers_def_1 xboole_0_def_5 sorry
                have "x inHIDDENR3 NATNUMBERSK1 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
                  using xboole_0_def_3 A11 sorry
                thus "x inHIDDENR3 INTNUMBERSK5"
                  using A12 numbers_def_4 xboole_0_def_5 sorry
              qed
              have case2: "x =HIDDENR1 -XCMPLX-0K4 k & k <>HIDDENR2 x implies x inHIDDENR3 INTNUMBERSK5"
              proof(rule impI)
                assume "x =HIDDENR1 -XCMPLX-0K4 k & k <>HIDDENR2 x"
                then have A13: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                  using int_1_lm_2 sorry
                then have A14: " not x inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                  using xboole_0_def_5 sorry
                have "x inHIDDENR3 NATNUMBERSK1 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
                  using A13 xboole_0_def_3 sorry
                thus "x inHIDDENR3 INTNUMBERSK5"
                  using A14 numbers_def_4 xboole_0_def_5 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus "I c=TARSKIR1 INTNUMBERSK5"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 INTNUMBERSK5 implies x inHIDDENR3 I"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A15: "x inHIDDENR3 INTNUMBERSK5"
          then have A16: " not x inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
            using numbers_def_4 xboole_0_def_5 sorry
          show "x inHIDDENR3 I"
          proof-
            have cases: "x inHIDDENR3 NATNUMBERSK1 or x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
              using A15 numbers_def_4 xboole_0_def_3 sorry
            have case1: "x inHIDDENR3 NATNUMBERSK1 implies x inHIDDENR3 I"
            proof(rule impI)
              assume "x inHIDDENR3 NATNUMBERSK1"
              thus "x inHIDDENR3 I"
                using A9 sorry
            qed
            have case2: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] implies x inHIDDENR3 I"
            proof(rule impI)
              assume "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :]"
              then have "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },NATNUMBERSK1 :] \\SUBSET-1K6 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
                using A16 xboole_0_def_5 sorry
              then have " ex k be NatNAT-1M1 st x =HIDDENR1 k or x =HIDDENR1 -XCMPLX-0K4 k"
                using int_1_lm_1 sorry
              thus "x inHIDDENR3 I"
                using A9 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "INTNUMBERSK5 c=TARSKIR1 I"
          using tarski_def_3 sorry
      qed
      thus "I =HIDDENR1 INTNUMBERSK5"
        using xboole_0_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef int_1_def_2 ("integerINT-1V1" 70 ) where
"attr integerINT-1V1 for NumberORDINAL1M1 means
  (\<lambda>i. i inHIDDENR3 INTINT-1K1)"..

mtheorem int_1_cl_1:
"cluster integerINT-1V1 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be integerINT-1V1"
  proof-
    have " ex tVar2 be RealXREAL-0M1 st tVar2 be integerINT-1V1"
    proof-
      show " ex tVar2 be RealXREAL-0M1 st tVar2 be integerINT-1V1"
      proof(rule bexI[of _ "0NUMBERSK6"])
        have "0NUMBERSK6 inTARSKIR2 INTINT-1K1"
        proof-
          show "0NUMBERSK6 inTARSKIR2 INTINT-1K1"
            using int_1_def_1 sorry
        qed
        thus "0NUMBERSK6 be integerINT-1V1"
          using int_1_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem int_1_cl_2:
"cluster integerINT-1V1 for numberORDINAL1M2"
proof
(*existence*)
  show " ex it be numberORDINAL1M2 st it be integerINT-1V1"
  proof-
    have " ex tVar3 be numberORDINAL1M2 st tVar3 be integerINT-1V1"
    proof-
      show " ex tVar3 be numberORDINAL1M2 st tVar3 be integerINT-1V1"
      proof(rule bexI[of _ "0NUMBERSK6"])
        have "0NUMBERSK6 inTARSKIR2 INTINT-1K1"
        proof-
          show "0NUMBERSK6 inTARSKIR2 INTINT-1K1"
            using int_1_def_1 sorry
        qed
        thus "0NUMBERSK6 be integerINT-1V1"
          using int_1_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem int_1_cl_3:
"cluster note-that integerINT-1V1 for ElementSUBSET-1M1-of INTINT-1K1"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of INTINT-1K1 holds it be integerINT-1V1"
     sorry
qed "sorry"

syntax INT_1M1 :: "Ty" ("IntegerINT-1M1" 70)
translations "IntegerINT-1M1" \<rightharpoonup> "integerINT-1V1\<bar>NumberORDINAL1M1"

mtheorem int_1_th_1:
" for r be RealXREAL-0M1 holds  for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds r =HIDDENR1 k or r =HIDDENR1 -XCMPLX-0K4 k implies r be IntegerINT-1M1"
proof-
  have " for r be RealXREAL-0M1 holds  for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds r =HIDDENR1 k or r =HIDDENR1 -XCMPLX-0K4 k implies r be IntegerINT-1M1"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: "k be NatNAT-1M1"
      using tarski_th_1 sorry
    assume "r =HIDDENR1 k or r =HIDDENR1 -XCMPLX-0K4 k"
    then have "r inHIDDENR3 INTINT-1K1"
      using A1 int_1_def_1 sorry
    thus "r be IntegerINT-1M1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_2:
" for r be RealXREAL-0M1 holds r be IntegerINT-1M1 implies ( ex k be NatNAT-1M1 st r =HIDDENR1 k or r =HIDDENR1 -XCMPLX-0K4 k)"
proof-
  have " for r be RealXREAL-0M1 holds r be IntegerINT-1M1 implies  not ( for k be NatNAT-1M1 holds  not r =HIDDENR1 k &  not r =HIDDENR1 -XCMPLX-0K4 k)"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "r be IntegerINT-1M1"
    then have "r be ElementSUBSET-1M1-of INTINT-1K1"
      using int_1_def_2 sorry
    thus " not ( for k be NatNAT-1M1 holds  not r =HIDDENR1 k &  not r =HIDDENR1 -XCMPLX-0K4 k)"
      using int_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_cl_4:
"cluster naturalORDINAL1V7 also-is integerINT-1V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be naturalORDINAL1V7 implies it be integerINT-1V1"
  proof-
    have " for e be objectHIDDENM1 holds e be naturalORDINAL1V7 implies e be integerINT-1V1"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume A1: "e be naturalORDINAL1V7"
      have 
        [ty]:"e be NatNAT-1M1"
        using A1 tarski_th_1 sorry
      have "e be IntegerINT-1M1"
        using int_1_th_1 sorry
      thus "e be integerINT-1V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem int_1_cl_5:
"cluster integerINT-1V1 also-is realXREAL-0V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be integerINT-1V1 implies it be realXREAL-0V1"
    using numbers_th_15 sorry
qed "sorry"

reserve i, i0, i1, i2, i3, i4, i5, i8, i9, j for "IntegerINT-1M1"
mtheorem int_1_cl_6:
  mlet "i1 be IntegerINT-1M1", "i2 be IntegerINT-1M1"
"cluster i1 +XCMPLX-0K2 i2 as-term-is integerINT-1V1"
proof
(*coherence*)
  show "i1 +XCMPLX-0K2 i2 be integerINT-1V1"
  proof-
    obtain l where
      [ty]:"l be NatNAT-1M1" and 
      A1: "i2 =HIDDENR1 l or i2 =HIDDENR1 -XCMPLX-0K4 l"
      using int_1_th_2 sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A2: "i1 =HIDDENR1 k or i1 =HIDDENR1 -XCMPLX-0K4 k"
      using int_1_th_2 sorry
    have A3: "i1 =HIDDENR1 -XCMPLX-0K4 k & i2 =HIDDENR1 l implies i1 +XCMPLX-0K2 i2 be IntegerINT-1M1"
    proof(rule impMI ,rule impI)
      have A4: "l -XCMPLX-0K6 k <=XXREAL-0R1 0NUMBERSK6 implies l -XCMPLX-0K6 k be IntegerINT-1M1"
      proof(rule impI)
        assume "l -XCMPLX-0K6 k <=XXREAL-0R1 0NUMBERSK6"
        then have "l <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 k"
          using xreal_1_th_20 sorry
        then obtain z where
          [ty]:"z be NatNAT-1M1" and 
          A5: "k =XBOOLE-0R4 l +XCMPLX-0K2 z"
          using nat_1_th_10 sorry
        have "-XCMPLX-0K4 z =HIDDENR1 (-XCMPLX-0K4 k)+XCMPLX-0K2 l"
          using A5 sorry
        thus "l -XCMPLX-0K6 k be IntegerINT-1M1"
          using int_1_th_1 sorry
      qed
      assume A6: "i1 =HIDDENR1 -XCMPLX-0K4 k"
        and A7: "i2 =HIDDENR1 l"
      have "0NUMBERSK6 <=XXREAL-0R1 l -XCMPLX-0K6 k implies l -XCMPLX-0K6 k be IntegerINT-1M1"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-0R1 l -XCMPLX-0K6 k"
        then have "0NUMBERSK6 +XCMPLX-0K2 k <=XXREAL-0R1 l"
          using xreal_1_th_19 sorry
        then have " ex z be NatNAT-1M1 st l =XBOOLE-0R4 k +XCMPLX-0K2 z"
          using nat_1_th_10 sorry
        thus "l -XCMPLX-0K6 k be IntegerINT-1M1"
           sorry
      qed
      thus "i1 +XCMPLX-0K2 i2 be IntegerINT-1M1"
        using A6 A7 A4 sorry
    qed
    have A8: "i1 =HIDDENR1 k & i2 =HIDDENR1 -XCMPLX-0K4 l implies i1 +XCMPLX-0K2 i2 be IntegerINT-1M1"
    proof(rule impMI ,rule impI)
      have A9: "k -XCMPLX-0K6 l <=XXREAL-0R1 0NUMBERSK6 implies k -XCMPLX-0K6 l be IntegerINT-1M1"
      proof(rule impI)
        assume "k -XCMPLX-0K6 l <=XXREAL-0R1 0NUMBERSK6"
        then have "k <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 l"
          using xreal_1_th_20 sorry
        then obtain z where
          [ty]:"z be NatNAT-1M1" and 
          A10: "l =XBOOLE-0R4 k +XCMPLX-0K2 z"
          using nat_1_th_10 sorry
        have "-XCMPLX-0K4 z =HIDDENR1 (-XCMPLX-0K4 l)+XCMPLX-0K2 k"
          using A10 sorry
        thus "k -XCMPLX-0K6 l be IntegerINT-1M1"
          using int_1_th_1 sorry
      qed
      assume A11: "i1 =HIDDENR1 k"
        and A12: "i2 =HIDDENR1 -XCMPLX-0K4 l"
      have "0NUMBERSK6 <=XXREAL-0R1 k -XCMPLX-0K6 l implies k -XCMPLX-0K6 l be IntegerINT-1M1"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-0R1 k -XCMPLX-0K6 l"
        then have "0NUMBERSK6 +XCMPLX-0K2 l <=XXREAL-0R1 k"
          using xreal_1_th_19 sorry
        then have " ex z be NatNAT-1M1 st k =XBOOLE-0R4 l +XCMPLX-0K2 z"
          using nat_1_th_10 sorry
        thus "k -XCMPLX-0K6 l be IntegerINT-1M1"
           sorry
      qed
      thus "i1 +XCMPLX-0K2 i2 be IntegerINT-1M1"
        using A11 A12 A9 sorry
    qed
    have "i1 =HIDDENR1 -XCMPLX-0K4 k & i2 =HIDDENR1 -XCMPLX-0K4 l implies i1 +XCMPLX-0K2 i2 be IntegerINT-1M1"
    proof(rule impMI ,rule impI)
      assume A13: "i1 =HIDDENR1 -XCMPLX-0K4 k"
        and A14: "i2 =HIDDENR1 -XCMPLX-0K4 l"
      have "i1 +XCMPLX-0K2 i2 =HIDDENR1 -XCMPLX-0K4 (k +XCMPLX-0K2 l)"
        using A13 A14 sorry
      thus "i1 +XCMPLX-0K2 i2 be IntegerINT-1M1"
        using int_1_th_1 sorry
    qed
    thus "i1 +XCMPLX-0K2 i2 be integerINT-1V1"
      using A2 A1 A8 A3 sorry
  qed
qed "sorry"

mtheorem int_1_cl_7:
  mlet "i1 be IntegerINT-1M1", "i2 be IntegerINT-1M1"
"cluster i1 *XCMPLX-0K3 i2 as-term-is integerINT-1V1"
proof
(*coherence*)
  show "i1 *XCMPLX-0K3 i2 be integerINT-1V1"
  proof-
    obtain l where
      [ty]:"l be NatNAT-1M1" and 
      A15: "i2 =HIDDENR1 l or i2 =HIDDENR1 -XCMPLX-0K4 l"
      using int_1_th_2 sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A16: "i1 =HIDDENR1 k or i1 =HIDDENR1 -XCMPLX-0K4 k"
      using int_1_th_2 sorry
    have A17: "i1 =HIDDENR1 -XCMPLX-0K4 k & i2 =HIDDENR1 -XCMPLX-0K4 l implies i1 *XCMPLX-0K3 i2 be IntegerINT-1M1"
    proof(rule impMI ,rule impI)
      assume A18: "i1 =HIDDENR1 -XCMPLX-0K4 k"
        and A19: "i2 =HIDDENR1 -XCMPLX-0K4 l"
      have "i1 *XCMPLX-0K3 i2 =XBOOLE-0R4 k *XCMPLX-0K3 l"
        using A18 A19 sorry
      thus "i1 *XCMPLX-0K3 i2 be IntegerINT-1M1"
         sorry
    qed
    have "i1 =HIDDENR1 -XCMPLX-0K4 k & i2 =HIDDENR1 l or i1 =HIDDENR1 k & i2 =HIDDENR1 -XCMPLX-0K4 l implies i1 *XCMPLX-0K3 i2 be IntegerINT-1M1"
    proof(rule impI)
      assume "i1 =HIDDENR1 -XCMPLX-0K4 k & i2 =HIDDENR1 l or i1 =HIDDENR1 k & i2 =HIDDENR1 -XCMPLX-0K4 l"
      then have "i1 *XCMPLX-0K3 i2 =HIDDENR1 -XCMPLX-0K4 k *XCMPLX-0K3 l"
         sorry
      thus "i1 *XCMPLX-0K3 i2 be IntegerINT-1M1"
        using int_1_th_1 sorry
    qed
    thus "i1 *XCMPLX-0K3 i2 be integerINT-1V1"
      using A16 A15 A17 sorry
  qed
qed "sorry"

mtheorem int_1_cl_8:
  mlet "i0 be IntegerINT-1M1"
"cluster -XCMPLX-0K4 i0 as-term-is integerINT-1V1"
proof
(*coherence*)
  show "-XCMPLX-0K4 i0 be integerINT-1V1"
  proof-
    have " ex k be NatNAT-1M1 st i0 =HIDDENR1 k or i0 =HIDDENR1 -XCMPLX-0K4 k"
      using int_1_th_2 sorry
    thus "-XCMPLX-0K4 i0 be integerINT-1V1"
      using int_1_th_1 sorry
  qed
qed "sorry"

mtheorem int_1_cl_9:
  mlet "i1 be IntegerINT-1M1", "i2 be IntegerINT-1M1"
"cluster i1 -XCMPLX-0K6 i2 as-term-is integerINT-1V1"
proof
(*coherence*)
  show "i1 -XCMPLX-0K6 i2 be integerINT-1V1"
  proof-
    have "i1 -XCMPLX-0K6 i2 =XBOOLE-0R4 i1 +XCMPLX-0K2 (-XCMPLX-0K4 i2)"
       sorry
    thus "i1 -XCMPLX-0K6 i2 be integerINT-1V1"
       sorry
  qed
qed "sorry"

mtheorem int_1_th_3:
" for i0 be IntegerINT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 i0 implies i0 inHIDDENR3 NATNUMBERSK1"
proof-
  have " for i0 be IntegerINT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 i0 implies i0 inHIDDENR3 NATNUMBERSK1"
  proof(rule ballI,rule impI)
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "i0 =HIDDENR1 k or i0 =HIDDENR1 -XCMPLX-0K4 k"
      using int_1_th_2 sorry
    assume "0NUMBERSK6 <=XXREAL-0R1 i0"
    then have "i0 =HIDDENR1 -XCMPLX-0K4 k implies i0 be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
    thus "i0 inHIDDENR3 NATNUMBERSK1"
      using A1 ordinal1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_4:
" for r be RealXREAL-0M1 holds r be IntegerINT-1M1 implies r +XCMPLX-0K2 \<one>\<^sub>M be IntegerINT-1M1 & r -XCMPLX-0K6 \<one>\<^sub>M be IntegerINT-1M1"
   sorry

mtheorem int_1_th_5:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 <=XXREAL-0R1 i1 implies i1 -XCMPLX-0K6 i2 inTARSKIR2 NATNUMBERSK1"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 <=XXREAL-0R1 i1 implies i1 -XCMPLX-0K6 i2 inTARSKIR2 NATNUMBERSK1"
  proof(rule ballI,rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    assume "i2 <=XXREAL-0R1 i1"
    then have "i2 -XCMPLX-0K6 i2 <=XXREAL-0R1 i1 -XCMPLX-0K6 i2"
      using xreal_1_th_9 sorry
    thus "i1 -XCMPLX-0K6 i2 inTARSKIR2 NATNUMBERSK1"
      using int_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_6:
" for k be NatNAT-1M1 holds  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i1 +XCMPLX-0K2 k =HIDDENR1 i2 implies i1 <=XXREAL-0R1 i2"
proof-
  have " for k be NatNAT-1M1 holds  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i1 +XCMPLX-0K2 k =HIDDENR1 i2 implies i1 <=XXREAL-0R1 i2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    obtain i0 where 
      [ty]:"i0 be IntegerINT-1M1" and i0Def:"i0 = k"
       sorry
    assume "i1 +XCMPLX-0K2 k =HIDDENR1 i2"
    then have "0NUMBERSK6 +XCMPLX-0K2 (i1 +XCMPLX-0K2 k) <=XXREAL-0R1 k +XCMPLX-0K2 i2"
      using xreal_1_th_6 sorry
    then have "(i1 +XCMPLX-0K2 i0)-XCMPLX-0K6 i0 <=XXREAL-0R1 (i2 +XCMPLX-0K2 i0)-XCMPLX-0K6 i0"
      using xreal_1_th_9 sorry
    thus "i1 <=XXREAL-0R1 i2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_1_lm_3:
" for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds j <XXREAL-0R3 \<one>\<^sub>M implies j =XBOOLE-0R4 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix j assume [ty]: "j be ElementSUBSET-1M1-of NATNUMBERSK1"
  assume "j <XXREAL-0R3 \<one>\<^sub>M"
  then have "j <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
     sorry
  thus "j =XBOOLE-0R4 0NUMBERSK6"
    using nat_1_th_13 sorry
qed "sorry"

mlemma int_1_lm_4:
" for i1 be IntegerINT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 i1 implies \<one>\<^sub>M <=XXREAL-0R1 i1"
proof-
  have " for i1 be IntegerINT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 i1 implies \<one>\<^sub>M <=XXREAL-0R1 i1"
  proof(rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 i1"
    then obtain i2 where 
      [ty]:"i2 be ElementSUBSET-1M1-of NATNUMBERSK1" and i2Def:"i2 = i1"
      using int_1_th_3 sorry
    have "0NUMBERSK6 <>HIDDENR2 i2"
      using A1 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 i1"
      using int_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_7:
" for i0 be IntegerINT-1M1 holds  for i1 be IntegerINT-1M1 holds i0 <XXREAL-0R3 i1 implies i0 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 i1"
proof-
  have " for i0 be IntegerINT-1M1 holds  for i1 be IntegerINT-1M1 holds i0 <XXREAL-0R3 i1 implies i0 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 i1"
  proof(rule ballI,rule ballI,rule impI)
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    assume "i0 <XXREAL-0R3 i1"
    then have "i0 +XCMPLX-0K2 (-XCMPLX-0K4 i0) <XXREAL-0R3 i1 +XCMPLX-0K2 (-XCMPLX-0K4 i0)"
      using xreal_1_th_6 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 i1 +XCMPLX-0K2 (-XCMPLX-0K4 i0)"
      using int_1_lm_4 sorry
    then have "\<one>\<^sub>M +XCMPLX-0K2 i0 <=XXREAL-0R1 (i1 +XCMPLX-0K2 (-XCMPLX-0K4 i0))+XCMPLX-0K2 i0"
      using xreal_1_th_6 sorry
    thus "i0 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 i1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_8:
" for i1 be IntegerINT-1M1 holds i1 <XXREAL-0R3 0NUMBERSK6 implies i1 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for i1 be IntegerINT-1M1 holds i1 <XXREAL-0R3 0NUMBERSK6 implies i1 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    assume "i1 <XXREAL-0R3 0NUMBERSK6"
    then have "0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 i1"
      using xreal_1_th_58 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 -XCMPLX-0K4 i1"
      using int_1_lm_4 sorry
    then have "-XCMPLX-0K4 (-XCMPLX-0K4 i1) <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
      using xreal_1_th_24 sorry
    thus "i1 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_9:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i1 *XCMPLX-0K3 i2 =XBOOLE-0R4 \<one>\<^sub>M iff i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds (i1 *XCMPLX-0K3 i2 =XBOOLE-0R4 \<one>\<^sub>M implies i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) &  not ( not ( not (i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M) &  not (i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)) &  not i1 *XCMPLX-0K3 i2 =XBOOLE-0R4 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    show "i1 *XCMPLX-0K3 i2 =XBOOLE-0R4 \<one>\<^sub>M implies i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    proof-
      have "i1 *XCMPLX-0K3 i2 =XBOOLE-0R4 \<one>\<^sub>M implies  not ( not (i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M) &  not (i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M))"
      proof(rule impI)
        assume A1: "i1 *XCMPLX-0K3 i2 =XBOOLE-0R4 \<one>\<^sub>M"
        then have A2: " not i2 =HIDDENR1 0NUMBERSK6"
           sorry
        have A3: "i1 <XXREAL-0R3 0NUMBERSK6 & i2 <XXREAL-0R3 0NUMBERSK6 implies i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
        proof(rule impMI ,rule impI)
          have A4: "(-XCMPLX-0K4 i1)*XCMPLX-0K3 (-XCMPLX-0K4 i2) =XBOOLE-0R4 i1 *XCMPLX-0K3 i2"
             sorry
          assume A5: "i1 <XXREAL-0R3 0NUMBERSK6"
            and A6: "i2 <XXREAL-0R3 0NUMBERSK6"
          have A7: "-XCMPLX-0K4 i2 be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A6 int_1_th_3 sorry
          have "-XCMPLX-0K4 i1 be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A5 int_1_th_3 sorry
          then have "-XCMPLX-0K4 (-XCMPLX-0K4 i1) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
            using A1 A7 A4 nat_1_th_15 sorry
          thus "i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
            using A1 sorry
        qed
        have A8: "0NUMBERSK6 <XXREAL-0R3 i1 & 0NUMBERSK6 <XXREAL-0R3 i2 implies i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M"
        proof(rule impMI ,rule impI)
          assume A9: "0NUMBERSK6 <XXREAL-0R3 i1"
            and A10: "0NUMBERSK6 <XXREAL-0R3 i2"
          have A11: "i2 be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A10 int_1_th_3 sorry
          have "i1 be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A9 int_1_th_3 sorry
          thus "i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M"
            using A1 A11 nat_1_th_15 sorry
        qed
        have " not i1 =HIDDENR1 0NUMBERSK6"
          using A1 sorry
        thus " not ( not (i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M) &  not (i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M))"
          using A1 A2 A8 A3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " not ( not ( not (i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M) &  not (i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)) &  not i1 *XCMPLX-0K3 i2 =XBOOLE-0R4 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_10:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i1 *XCMPLX-0K3 i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M iff i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds (i1 *XCMPLX-0K3 i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) & (i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies i1 *XCMPLX-0K3 i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    show "i1 *XCMPLX-0K3 i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    proof-
      have "i1 *XCMPLX-0K3 i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies  not ( not (i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M) &  not (i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M))"
      proof(rule impI)
        assume "i1 *XCMPLX-0K3 i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
        then have "(-XCMPLX-0K4 i1)*XCMPLX-0K3 i2 =XBOOLE-0R4 \<one>\<^sub>M"
           sorry
        then have "-XCMPLX-0K4 (-XCMPLX-0K4 i1) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or -XCMPLX-0K4 i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
          using int_1_th_9 sorry
        thus " not ( not (i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M) &  not (i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "i1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M & i2 =HIDDENR1 \<one>\<^sub>M or i1 =HIDDENR1 \<one>\<^sub>M & i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    thus "i1 *XCMPLX-0K3 i2 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_1_lm_5:
" for i0 be IntegerINT-1M1 holds  for i1 be IntegerINT-1M1 holds i0 <=XXREAL-0R1 i1 implies ( ex k be NatNAT-1M1 st i0 +XCMPLX-0K2 k =HIDDENR1 i1)"
proof-
  have " for i0 be IntegerINT-1M1 holds  for i1 be IntegerINT-1M1 holds i0 <=XXREAL-0R1 i1 implies  not ( for k be NatNAT-1M1 holds  not i0 +XCMPLX-0K2 k =HIDDENR1 i1)"
  proof(rule ballI,rule ballI,rule impI)
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    assume "i0 <=XXREAL-0R1 i1"
    then obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = i1 -XCMPLX-0K6 i0"
      using int_1_th_5 sorry
    have "i0 +XCMPLX-0K2 k =HIDDENR1 i1"
       sorry
    thus " not ( for k be NatNAT-1M1 holds  not i0 +XCMPLX-0K2 k =HIDDENR1 i1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_1_lm_6:
" for i0 be IntegerINT-1M1 holds  for i1 be IntegerINT-1M1 holds i0 <=XXREAL-0R1 i1 implies ( ex k be NatNAT-1M1 st i1 -XCMPLX-0K6 k =HIDDENR1 i0)"
proof-
  have " for i0 be IntegerINT-1M1 holds  for i1 be IntegerINT-1M1 holds i0 <=XXREAL-0R1 i1 implies  not ( for k be NatNAT-1M1 holds  not i1 -XCMPLX-0K6 k =HIDDENR1 i0)"
  proof(rule ballI,rule ballI,rule impI)
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    assume "i0 <=XXREAL-0R1 i1"
    then obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = i1 -XCMPLX-0K6 i0"
      using int_1_th_5 sorry
    have "i1 -XCMPLX-0K6 k =HIDDENR1 i0"
       sorry
    thus " not ( for k be NatNAT-1M1 holds  not i1 -XCMPLX-0K6 k =HIDDENR1 i0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem int_1_sch_1:
  fixes Pp1 
  shows " ex X be SubsetSUBSET-1M2-of INTINT-1K1 st  for x be IntegerINT-1M1 holds x inHIDDENR3 X iff Pp1(x)"
  proof-
    have " ex tVar4 be SubsetSUBSET-1M2-of INTINT-1K1 st  for i0 be IntegerINT-1M1 holds  not (i0 inHIDDENR3 tVar4 &  not Pp1(i0)) &  not (Pp1(i0) &  not i0 inHIDDENR3 tVar4)"
    proof-
      let ?P1 = "\<lambda>Lamb1.  ex i0 be IntegerINT-1M1 st i0 =HIDDENR1 Lamb1 & Pp1(i0)"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: " for y be objectHIDDENM1 holds y inHIDDENR3 X iff y inHIDDENR3 INTINT-1K1 & ?P1(y)"
        using xboole_0_sch_1 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 INTINT-1K1"
        using A1 sorry
      then have 
        [ty]:"X be SubsetSUBSET-1M2-of INTINT-1K1"
        using tarski_def_3 sorry
      show " ex tVar4 be SubsetSUBSET-1M2-of INTINT-1K1 st  for i0 be IntegerINT-1M1 holds  not (i0 inHIDDENR3 tVar4 &  not Pp1(i0)) &  not (Pp1(i0) &  not i0 inHIDDENR3 tVar4)"
      proof(rule bexI[of _ "X"],rule ballI)
        fix i0 assume [ty]: "i0 be IntegerINT-1M1"
        have A2: "i0 inHIDDENR3 X implies Pp1(i0)"
        proof(rule impI)
          assume "i0 inHIDDENR3 X"
          then have " ex i1 be IntegerINT-1M1 st i0 =HIDDENR1 i1 & Pp1(i1)"
            using A1 sorry
          thus "Pp1(i0)"
             sorry
        qed
        have "Pp1(i0) implies i0 inHIDDENR3 X"
          using int_1_def_2 A1 sorry
        thus " not (i0 inHIDDENR3 X &  not Pp1(i0)) &  not (Pp1(i0) &  not i0 inHIDDENR3 X)"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem int_1_sch_2:
  fixes Ff0 Pp1 
  assumes
[ty]: "Ff0 be IntegerINT-1M1" and
   A1: "Pp1(Ff0)" and
   A2: " for i2 be IntegerINT-1M1 holds Ff0 <=XXREAL-0R1 i2 implies (Pp1(i2) implies Pp1(i2 +XCMPLX-0K2 \<one>\<^sub>M))"
  shows " for i0 be IntegerINT-1M1 holds Ff0 <=XXREAL-0R1 i0 implies Pp1(i0)"
  proof(rule ballI,rule impI)
    let ?Q = "\<lambda>Lamb1.  for i2 be IntegerINT-1M1 holds Lamb1 =XBOOLE-0R4 i2 -XCMPLX-0K6 Ff0 implies Pp1(i2)"
    have A3: " for k be NatNAT-1M1 holds ?Q(k) implies ?Q(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( for i2 be IntegerINT-1M1 holds k =XBOOLE-0R4 i2 -XCMPLX-0K6 Ff0 implies Pp1(i2)) implies ( for i2 be IntegerINT-1M1 holds k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i2 -XCMPLX-0K6 Ff0 implies Pp1(i2))"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        obtain i8 where 
          [ty]:"i8 be IntegerINT-1M1" and i8Def:"i8 = k"
           sorry
        assume A4: "?Q(k)"
        fix i2 assume [ty]: "i2 be IntegerINT-1M1"
        assume A5: "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i2 -XCMPLX-0K6 Ff0"
        then have "i2 -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 i8 +XCMPLX-0K2 Ff0"
           sorry
        then have A6: "Ff0 <=XXREAL-0R1 i2 -XCMPLX-0K6 \<one>\<^sub>M"
          using int_1_th_6 sorry
        have "k =XBOOLE-0R4 (i2 -XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 Ff0"
          using A5 sorry
        then have "Pp1((i2 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A2 A4 A6 sorry
        thus "Pp1(i2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    assume "Ff0 <=XXREAL-0R1 i0"
    then obtain l where 
      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = i0 -XCMPLX-0K6 Ff0"
      using int_1_th_5 sorry
    have A7: "l =XBOOLE-0R4 i0 -XCMPLX-0K6 Ff0"
       sorry
    have A8: "?Q(0NUMBERSK6)"
      using A1 sorry
    have " for k be NatNAT-1M1 holds ?Q(k)"
      using nat_1_sch_2 A8 A3 sorry
    thus "Pp1(i0)"
      using A7 sorry
  qed "sorry"

theorem int_1_sch_3:
  fixes Ff0 Pp1 
  assumes
[ty]: "Ff0 be IntegerINT-1M1" and
   A1: "Pp1(Ff0)" and
   A2: " for i2 be IntegerINT-1M1 holds i2 <=XXREAL-0R1 Ff0 implies (Pp1(i2) implies Pp1(i2 -XCMPLX-0K6 \<one>\<^sub>M))"
  shows " for i0 be IntegerINT-1M1 holds i0 <=XXREAL-0R1 Ff0 implies Pp1(i0)"
  proof(rule ballI,rule impI)
    let ?Q = "\<lambda>Lamb1.  for i2 be IntegerINT-1M1 holds Lamb1 =HIDDENR1 -XCMPLX-0K4 i2 implies Pp1(i2)"
    have A3: " for i2 be IntegerINT-1M1 holds -XCMPLX-0K4 Ff0 <=XXREAL-0R1 i2 implies (?Q(i2) implies ?Q(i2 +XCMPLX-0K2 \<one>\<^sub>M))"
    proof-
      have " for i2 be IntegerINT-1M1 holds -XCMPLX-0K4 Ff0 <=XXREAL-0R1 i2 & ( for i2c be IntegerINT-1M1 holds i2 =HIDDENR1 -XCMPLX-0K4 i2c implies Pp1(i2c)) implies ( for i3 be IntegerINT-1M1 holds i2 +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 -XCMPLX-0K4 i3 implies Pp1(i3))"
      proof(rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
        fix i2 assume [ty]: "i2 be IntegerINT-1M1"
        assume A4: "-XCMPLX-0K4 Ff0 <=XXREAL-0R1 i2"
          and A5: "?Q(i2)"
        fix i3 assume [ty]: "i3 be IntegerINT-1M1"
        assume A6: "i2 +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 -XCMPLX-0K4 i3"
        then have A7: "i2 =HIDDENR1 -XCMPLX-0K4 (i3 +XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
        have "-XCMPLX-0K4 ((-XCMPLX-0K4 i3)-XCMPLX-0K6 \<one>\<^sub>M) <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 Ff0)"
          using A4 A6 xreal_1_th_24 sorry
        then have "Pp1((i3 +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
          using A2 A5 A7 sorry
        thus "Pp1(i3)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    assume "i0 <=XXREAL-0R1 Ff0"
    then have A8: "-XCMPLX-0K4 Ff0 <=XXREAL-0R1 -XCMPLX-0K4 i0"
      using xreal_1_th_24 sorry
    have A9: "?Q(-XCMPLX-0K4 Ff0)"
      using A1 sorry
    have " for i2 be IntegerINT-1M1 holds -XCMPLX-0K4 Ff0 <=XXREAL-0R1 i2 implies ?Q(i2)"
      using int_1_sch_2 A9 A3 sorry
    thus "Pp1(i0)"
      using A8 sorry
  qed "sorry"

theorem int_1_sch_4:
  fixes Ff0 Pp1 
  assumes
[ty]: "Ff0 be IntegerINT-1M1" and
   A1: "Pp1(Ff0)" and
   A2: " for i2 be IntegerINT-1M1 holds Pp1(i2) implies Pp1(i2 -XCMPLX-0K6 \<one>\<^sub>M) & Pp1(i2 +XCMPLX-0K2 \<one>\<^sub>M)"
  shows " for i0 be IntegerINT-1M1 holds Pp1(i0)"
  proof(rule ballI)
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    have A3: "Pp1(Ff0)"
      using A1 sorry
    have A4: "i0 <=XXREAL-0R1 Ff0 implies Pp1(i0)"
    proof(rule impI)
      have A5: " for i2 be IntegerINT-1M1 holds i2 <=XXREAL-0R1 Ff0 implies (Pp1(i2) implies Pp1(i2 -XCMPLX-0K6 \<one>\<^sub>M))"
        using A2 sorry
      have A6: " for i2 be IntegerINT-1M1 holds i2 <=XXREAL-0R1 Ff0 implies Pp1(i2)"
        using int_1_sch_3 A3 A5 sorry
      assume "i0 <=XXREAL-0R1 Ff0"
      thus "Pp1(i0)"
        using A6 sorry
    qed
    have "Ff0 <=XXREAL-0R1 i0 implies Pp1(i0)"
    proof(rule impI)
      have A7: " for i2 be IntegerINT-1M1 holds Ff0 <=XXREAL-0R1 i2 implies (Pp1(i2) implies Pp1(i2 +XCMPLX-0K2 \<one>\<^sub>M))"
        using A2 sorry
      have A8: " for i2 be IntegerINT-1M1 holds Ff0 <=XXREAL-0R1 i2 implies Pp1(i2)"
        using int_1_sch_2 A3 A7 sorry
      assume "Ff0 <=XXREAL-0R1 i0"
      thus "Pp1(i0)"
        using A8 sorry
    qed
    thus "Pp1(i0)"
      using A4 sorry
  qed "sorry"

theorem int_1_sch_5:
  fixes Ff0 Pp1 
  assumes
[ty]: "Ff0 be IntegerINT-1M1" and
   A1: " for i1 be IntegerINT-1M1 holds Pp1(i1) implies Ff0 <=XXREAL-0R1 i1" and
   A2: " ex i1 be IntegerINT-1M1 st Pp1(i1)"
  shows " ex i0 be IntegerINT-1M1 st Pp1(i0) & ( for i1 be IntegerINT-1M1 holds Pp1(i1) implies i0 <=XXREAL-0R1 i1)"
  proof-
    have " ex i0 be setHIDDENM2 st Pp1(i0) & ( for i1 be IntegerINT-1M1 holds  not (Pp1(i1) &  not i0 <=XXREAL-0R1 i1))"
    proof-
      let ?Q = "\<lambda>Lamb1. Pp1(Ff0 +XCMPLX-0K2 Lamb1)"
      obtain i1 where
        [ty]:"i1 be IntegerINT-1M1" and 
        A3: "Pp1(i1)"
        using A2 sorry
      have " ex k be NatNAT-1M1 st Ff0 +XCMPLX-0K2 k =HIDDENR1 i1"
        using A1 A3 int_1_lm_5 sorry
      then have A4: " ex k be NatNAT-1M1 st ?Q(k)"
        using A3 sorry
      obtain l where
        [ty]:"l be NatNAT-1M1" and 
        A5: "?Q(l) & ( for n be NatNAT-1M1 holds ?Q(n) implies l <=XXREAL-0R1 n)"
        using nat_1_sch_5 A4 sorry
      obtain i0 where 
        [ty]:"i0 be setHIDDENM2" and i0Def:"i0 = Ff0 +XCMPLX-0K2 l"
         sorry
      show " ex i0 be setHIDDENM2 st Pp1(i0) & ( for i1 be IntegerINT-1M1 holds  not (Pp1(i1) &  not i0 <=XXREAL-0R1 i1))"
      proof(rule bexI[of _ "i0"])
        have " for i1 be IntegerINT-1M1 holds Pp1(i1) implies i0 <=XXREAL-0R1 i1"
        proof(rule ballI,rule impI)
          fix i1 assume [ty]: "i1 be IntegerINT-1M1"
          assume A6: "Pp1(i1)"
          then have " ex n be NatNAT-1M1 st Ff0 +XCMPLX-0K2 n =HIDDENR1 i1"
            using A1 int_1_lm_5 sorry
          then have "i0 -XCMPLX-0K6 Ff0 <=XXREAL-0R1 i1 -XCMPLX-0K6 Ff0"
            using A5 A6 sorry
          thus "i0 <=XXREAL-0R1 i1"
            using xreal_1_th_9 sorry
        qed "sorry"
        thus "Pp1(i0) & ( for i1 be IntegerINT-1M1 holds  not (Pp1(i1) &  not i0 <=XXREAL-0R1 i1))"
          using A5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem int_1_sch_6:
  fixes Ff0 Pp1 
  assumes
[ty]: "Ff0 be IntegerINT-1M1" and
   A1: " for i1 be IntegerINT-1M1 holds Pp1(i1) implies i1 <=XXREAL-0R1 Ff0" and
   A2: " ex i1 be IntegerINT-1M1 st Pp1(i1)"
  shows " ex i0 be IntegerINT-1M1 st Pp1(i0) & ( for i1 be IntegerINT-1M1 holds Pp1(i1) implies i1 <=XXREAL-0R1 i0)"
  proof-
    have " ex i0 be setHIDDENM2 st Pp1(i0) & ( for i1 be IntegerINT-1M1 holds  not (Pp1(i1) &  not i1 <=XXREAL-0R1 i0))"
    proof-
      let ?Q = "\<lambda>Lamb1. Pp1(Ff0 -XCMPLX-0K6 Lamb1)"
      obtain i1 where
        [ty]:"i1 be IntegerINT-1M1" and 
        A3: "Pp1(i1)"
        using A2 sorry
      have " ex k be NatNAT-1M1 st i1 =HIDDENR1 Ff0 -XCMPLX-0K6 k"
        using A1 A3 int_1_lm_6 sorry
      then have A4: " ex k be NatNAT-1M1 st ?Q(k)"
        using A3 sorry
      obtain l where
        [ty]:"l be NatNAT-1M1" and 
        A5: "?Q(l) & ( for n be NatNAT-1M1 holds ?Q(n) implies l <=XXREAL-0R1 n)"
        using nat_1_sch_5 A4 sorry
      obtain i0 where 
        [ty]:"i0 be setHIDDENM2" and i0Def:"i0 = Ff0 -XCMPLX-0K6 l"
         sorry
      show " ex i0 be setHIDDENM2 st Pp1(i0) & ( for i1 be IntegerINT-1M1 holds  not (Pp1(i1) &  not i1 <=XXREAL-0R1 i0))"
      proof(rule bexI[of _ "i0"])
        have " for i1 be IntegerINT-1M1 holds Pp1(i1) implies i1 <=XXREAL-0R1 i0"
        proof(rule ballI,rule impI)
          fix i1 assume [ty]: "i1 be IntegerINT-1M1"
          assume A6: "Pp1(i1)"
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A7: "Ff0 -XCMPLX-0K6 n =HIDDENR1 i1"
            using A1 int_1_lm_6 sorry
          have "l <=XXREAL-0R1 n"
            using A5 A6 A7 sorry
          then have "(Ff0 +XCMPLX-0K2 (-XCMPLX-0K4 i0))-XCMPLX-0K6 Ff0 <=XXREAL-0R1 (Ff0 -XCMPLX-0K6 i1)-XCMPLX-0K6 Ff0"
            using A7 xreal_1_th_9 sorry
          then have "-XCMPLX-0K4 i0 <=XXREAL-0R1 (Ff0 +XCMPLX-0K2 (-XCMPLX-0K4 i1))-XCMPLX-0K6 Ff0"
             sorry
          thus "i1 <=XXREAL-0R1 i0"
            using xreal_1_th_24 sorry
        qed "sorry"
        thus "Pp1(i0) & ( for i1 be IntegerINT-1M1 holds  not (Pp1(i1) &  not i1 <=XXREAL-0R1 i0))"
          using A5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef int_1_def_3 (" _ dividesINT-1R1  _ " [50,50]50 ) where
  mlet "i1 be IntegerINT-1M1", "i2 be IntegerINT-1M1"
"pred i1 dividesINT-1R1 i2 means
   ex i3 be IntegerINT-1M1 st i2 =HIDDENR1 i1 *XCMPLX-0K3 i3"..

mtheorem INT_1R1_reflexivity:
" for i2 be IntegerINT-1M1 holds i2 dividesINT-1R1 i2"
proof-
  have " for i2 be IntegerINT-1M1 holds  ex i3 be IntegerINT-1M1 st i2 =HIDDENR1 i2 *XCMPLX-0K3 i3"
  proof-
    have " for a be IntegerINT-1M1 holds  ex tVar7 be IntegerINT-1M1 st a =HIDDENR1 a *XCMPLX-0K3 tVar7"
    proof(rule ballI)
      fix a assume [ty]: "a be IntegerINT-1M1"
      show " ex tVar7 be IntegerINT-1M1 st a =HIDDENR1 a *XCMPLX-0K3 tVar7"
      proof(rule bexI[of _ "\<one>\<^sub>M"])
        show "a =HIDDENR1 a *XCMPLX-0K3 \<one>\<^sub>M"
           sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using int_1_def_3 sorry
qed

mdef int_1_def_4 ("'( _ , _ ')are-congruent-modINT-1R2  _ " [0,0,50]50 ) where
  mlet "i1 be IntegerINT-1M1", "i2 be IntegerINT-1M1", "i3 be IntegerINT-1M1"
"pred (i1,i2)are-congruent-modINT-1R2 i3 means
  i3 dividesINT-1R1 i1 -XCMPLX-0K6 i2"..

abbreviation(input) INT_1R3("'( _ , _ ')are-congruent-modINT-1R3  _ " [0,0,50]50) where
  "(i1,i2)are-congruent-modINT-1R3 i3 \<equiv> (i1,i2)are-congruent-modINT-1R2 i3"

mtheorem int_1_def_5:
  mlet "i1 be IntegerINT-1M1", "i2 be IntegerINT-1M1", "i3 be IntegerINT-1M1"
"redefine pred (i1,i2)are-congruent-modINT-1R3 i3 means
   ex i4 be IntegerINT-1M1 st i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
proof
(*compatibility*)
  show "(i1,i2)are-congruent-modINT-1R3 i3 iff ( ex i4 be IntegerINT-1M1 st i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2)"
  proof-
    have "((i1,i2)are-congruent-modINT-1R2 i3 implies ( ex i4 be IntegerINT-1M1 st i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2)) & (( ex i4 be IntegerINT-1M1 st i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2) implies (i1,i2)are-congruent-modINT-1R2 i3)"
    proof(rule conjMI,rule impI)
      show "(i1,i2)are-congruent-modINT-1R2 i3 implies ( ex i4 be IntegerINT-1M1 st i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2)"
      proof-
        have " not ((i1,i2)are-congruent-modINT-1R2 i3 & ( for i4 be IntegerINT-1M1 holds  not i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2))"
        proof-
          have "i3 dividesINT-1R1 i1 -XCMPLX-0K6 i2 implies  not ( for i4 be IntegerINT-1M1 holds  not i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2)"
          proof(rule impI)
            assume "i3 dividesINT-1R1 i1 -XCMPLX-0K6 i2"
            thus " not ( for i4 be IntegerINT-1M1 holds  not i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2)"
               sorry
          qed
          thus " not ((i1,i2)are-congruent-modINT-1R2 i3 & ( for i4 be IntegerINT-1M1 holds  not i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2))"
            using int_1_def_4 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      assume Given: " ex i4 be IntegerINT-1M1 st i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
      then obtain i4 where
        [ty]:"i4 be IntegerINT-1M1" and 
        A1: "i3 *XCMPLX-0K3 i4 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
         sorry
      have "i1 -XCMPLX-0K6 i2 =HIDDENR1 i3 *XCMPLX-0K3 i4"
      proof-
        show "i1 -XCMPLX-0K6 i2 =HIDDENR1 i3 *XCMPLX-0K3 i4"
          using A1 sorry
      qed
      thus "(i1,i2)are-congruent-modINT-1R2 i3"
        using bexI[of _ "i4"] int_1_def_3 int_1_def_4 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem int_1_th_11:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds (i1,i1)are-congruent-modINT-1R3 i2"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds (i1,i1)are-congruent-modINT-1R3 i2"
  proof(rule ballI,rule ballI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    have "i2 *XCMPLX-0K3 (0NUMBERSK6) =XBOOLE-0R4 i1 -XCMPLX-0K6 i1"
       sorry
    thus "(i1,i1)are-congruent-modINT-1R3 i2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_12:
" for i1 be IntegerINT-1M1 holds (i1,0NUMBERSK6)are-congruent-modINT-1R3 i1 & (0NUMBERSK6,i1)are-congruent-modINT-1R3 i1"
proof-
  have " for i1 be IntegerINT-1M1 holds (i1,0NUMBERSK6)are-congruent-modINT-1R3 i1 & (0NUMBERSK6,i1)are-congruent-modINT-1R3 i1"
  proof(rule ballI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    have A1: "i1 *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 -XCMPLX-0K6 i1"
       sorry
    show "(i1,0NUMBERSK6)are-congruent-modINT-1R3 i1 & (0NUMBERSK6,i1)are-congruent-modINT-1R3 i1"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_13:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 \<one>\<^sub>M"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    have "i1 -XCMPLX-0K6 i2 =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 (i1 -XCMPLX-0K6 i2)"
       sorry
    thus "(i1,i2)are-congruent-modINT-1R3 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_14:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i3 implies (i2,i1)are-congruent-modINT-1R3 i3"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i3 implies (i2,i1)are-congruent-modINT-1R3 i3"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i3 assume [ty]: "i3 be IntegerINT-1M1"
    assume "(i1,i2)are-congruent-modINT-1R3 i3"
    then obtain i0 where
      [ty]:"i0 be IntegerINT-1M1" and 
      A1: "i1 -XCMPLX-0K6 i2 =XBOOLE-0R4 i3 *XCMPLX-0K3 i0"
       sorry
    have "i2 -XCMPLX-0K6 i1 =XBOOLE-0R4 i3 *XCMPLX-0K3 (-XCMPLX-0K4 i0)"
      using A1 sorry
    thus "(i2,i1)are-congruent-modINT-1R3 i3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_15:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i2,i3)are-congruent-modINT-1R3 i5 implies (i1,i3)are-congruent-modINT-1R3 i5"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i2,i3)are-congruent-modINT-1R3 i5 implies (i1,i3)are-congruent-modINT-1R3 i5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i3 assume [ty]: "i3 be IntegerINT-1M1"
    fix i5 assume [ty]: "i5 be IntegerINT-1M1"
    assume A1: "(i1,i2)are-congruent-modINT-1R3 i5"
      and A2: "(i2,i3)are-congruent-modINT-1R3 i5"
    obtain i8 where
      [ty]:"i8 be IntegerINT-1M1" and 
      A3: "i5 *XCMPLX-0K3 i8 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
      using A1 sorry
    obtain i9 where
      [ty]:"i9 be IntegerINT-1M1" and 
      A4: "i5 *XCMPLX-0K3 i9 =XBOOLE-0R4 i2 -XCMPLX-0K6 i3"
      using A2 sorry
    have "i5 *XCMPLX-0K3 (i8 +XCMPLX-0K2 i9) =XBOOLE-0R4 i1 -XCMPLX-0K6 i3"
      using A3 A4 sorry
    thus "(i1,i3)are-congruent-modINT-1R3 i5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_16:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i4 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i3,i4)are-congruent-modINT-1R3 i5 implies (i1 +XCMPLX-0K2 i3,i2 +XCMPLX-0K2 i4)are-congruent-modINT-1R3 i5"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i4 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i3,i4)are-congruent-modINT-1R3 i5 implies (i1 +XCMPLX-0K2 i3,i2 +XCMPLX-0K2 i4)are-congruent-modINT-1R3 i5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i3 assume [ty]: "i3 be IntegerINT-1M1"
    fix i4 assume [ty]: "i4 be IntegerINT-1M1"
    fix i5 assume [ty]: "i5 be IntegerINT-1M1"
    assume A1: "(i1,i2)are-congruent-modINT-1R3 i5"
      and A2: "(i3,i4)are-congruent-modINT-1R3 i5"
    obtain i8 where
      [ty]:"i8 be IntegerINT-1M1" and 
      A3: "i5 *XCMPLX-0K3 i8 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
      using A1 sorry
    obtain i9 where
      [ty]:"i9 be IntegerINT-1M1" and 
      A4: "i5 *XCMPLX-0K3 i9 =XBOOLE-0R4 i3 -XCMPLX-0K6 i4"
      using A2 sorry
    have "i5 *XCMPLX-0K3 (i8 +XCMPLX-0K2 i9) =XBOOLE-0R4 (i1 +XCMPLX-0K2 i3)-XCMPLX-0K6 (i2 +XCMPLX-0K2 i4)"
      using A3 A4 sorry
    thus "(i1 +XCMPLX-0K2 i3,i2 +XCMPLX-0K2 i4)are-congruent-modINT-1R3 i5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_17:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i4 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i3,i4)are-congruent-modINT-1R3 i5 implies (i1 -XCMPLX-0K6 i3,i2 -XCMPLX-0K6 i4)are-congruent-modINT-1R3 i5"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i4 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i3,i4)are-congruent-modINT-1R3 i5 implies (i1 -XCMPLX-0K6 i3,i2 -XCMPLX-0K6 i4)are-congruent-modINT-1R3 i5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i3 assume [ty]: "i3 be IntegerINT-1M1"
    fix i4 assume [ty]: "i4 be IntegerINT-1M1"
    fix i5 assume [ty]: "i5 be IntegerINT-1M1"
    assume A1: "(i1,i2)are-congruent-modINT-1R3 i5"
      and A2: "(i3,i4)are-congruent-modINT-1R3 i5"
    obtain i8 where
      [ty]:"i8 be IntegerINT-1M1" and 
      A3: "i5 *XCMPLX-0K3 i8 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
      using A1 sorry
    obtain i9 where
      [ty]:"i9 be IntegerINT-1M1" and 
      A4: "i5 *XCMPLX-0K3 i9 =XBOOLE-0R4 i3 -XCMPLX-0K6 i4"
      using A2 sorry
    have "(i1 -XCMPLX-0K6 i3)-XCMPLX-0K6 (i2 -XCMPLX-0K6 i4) =XBOOLE-0R4 i5 *XCMPLX-0K3 (i8 -XCMPLX-0K6 i9)"
      using A3 A4 sorry
    thus "(i1 -XCMPLX-0K6 i3,i2 -XCMPLX-0K6 i4)are-congruent-modINT-1R3 i5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_18:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i4 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i3,i4)are-congruent-modINT-1R3 i5 implies (i1 *XCMPLX-0K3 i3,i2 *XCMPLX-0K3 i4)are-congruent-modINT-1R3 i5"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i4 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i3,i4)are-congruent-modINT-1R3 i5 implies (i1 *XCMPLX-0K3 i3,i2 *XCMPLX-0K3 i4)are-congruent-modINT-1R3 i5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i3 assume [ty]: "i3 be IntegerINT-1M1"
    fix i4 assume [ty]: "i4 be IntegerINT-1M1"
    fix i5 assume [ty]: "i5 be IntegerINT-1M1"
    assume A1: "(i1,i2)are-congruent-modINT-1R3 i5"
      and A2: "(i3,i4)are-congruent-modINT-1R3 i5"
    obtain i8 where
      [ty]:"i8 be IntegerINT-1M1" and 
      A3: "i5 *XCMPLX-0K3 i8 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
      using A1 sorry
    obtain i9 where
      [ty]:"i9 be IntegerINT-1M1" and 
      A4: "i5 *XCMPLX-0K3 i9 =XBOOLE-0R4 i3 -XCMPLX-0K6 i4"
      using A2 sorry
    have "i1 *XCMPLX-0K3 i3 -XCMPLX-0K6 i2 *XCMPLX-0K3 i4 =HIDDENR1 (i1 -XCMPLX-0K6 i2)*XCMPLX-0K3 i3 +XCMPLX-0K2 (i3 -XCMPLX-0K6 i4)*XCMPLX-0K3 i2"
       sorry
    also have "... = (i5 *XCMPLX-0K3 i8)*XCMPLX-0K3 i3 +XCMPLX-0K2 (i5 *XCMPLX-0K3 i9)*XCMPLX-0K3 i2"
      using A3 A4 sorry
    also have "... = i5 *XCMPLX-0K3 (i8 *XCMPLX-0K3 i3 +XCMPLX-0K2 i9 *XCMPLX-0K3 i2)"
       sorry
    finally have "i1 *XCMPLX-0K3 i3 -XCMPLX-0K6 i2 *XCMPLX-0K3 i4 =HIDDENR1 i5 *XCMPLX-0K3 (i8 *XCMPLX-0K3 i3 +XCMPLX-0K2 i9 *XCMPLX-0K3 i2)"
       sorry
    thus "(i1 *XCMPLX-0K3 i3,i2 *XCMPLX-0K3 i4)are-congruent-modINT-1R3 i5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_19:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1 +XCMPLX-0K2 i2,i3)are-congruent-modINT-1R3 i5 iff (i1,i3 -XCMPLX-0K6 i2)are-congruent-modINT-1R3 i5"
   sorry

mtheorem int_1_th_20:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i4 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds i4 *XCMPLX-0K3 i5 =HIDDENR1 i3 implies ((i1,i2)are-congruent-modINT-1R3 i3 implies (i1,i2)are-congruent-modINT-1R3 i4)"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i4 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds i4 *XCMPLX-0K3 i5 =HIDDENR1 i3 implies ((i1,i2)are-congruent-modINT-1R3 i3 implies (i1,i2)are-congruent-modINT-1R3 i4)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i3 assume [ty]: "i3 be IntegerINT-1M1"
    fix i4 assume [ty]: "i4 be IntegerINT-1M1"
    fix i5 assume [ty]: "i5 be IntegerINT-1M1"
    assume A1: "i4 *XCMPLX-0K3 i5 =HIDDENR1 i3"
    assume "(i1,i2)are-congruent-modINT-1R3 i3"
    then obtain i0 where
      [ty]:"i0 be IntegerINT-1M1" and 
      A2: "i3 *XCMPLX-0K3 i0 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
       sorry
    have "i1 -XCMPLX-0K6 i2 =XBOOLE-0R4 i4 *XCMPLX-0K3 (i5 *XCMPLX-0K3 i0)"
      using A1 A2 sorry
    thus "(i1,i2)are-congruent-modINT-1R3 i4"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_21:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 iff (i1 +XCMPLX-0K2 i5,i2)are-congruent-modINT-1R3 i5"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds ((i1,i2)are-congruent-modINT-1R3 i5 implies (i1 +XCMPLX-0K2 i5,i2)are-congruent-modINT-1R3 i5) & ((i1 +XCMPLX-0K2 i5,i2)are-congruent-modINT-1R3 i5 implies (i1,i2)are-congruent-modINT-1R3 i5)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i5 assume [ty]: "i5 be IntegerINT-1M1"
    show "(i1,i2)are-congruent-modINT-1R3 i5 implies (i1 +XCMPLX-0K2 i5,i2)are-congruent-modINT-1R3 i5"
    proof(rule impI)
      assume "(i1,i2)are-congruent-modINT-1R3 i5"
      then obtain i0 where
        [ty]:"i0 be IntegerINT-1M1" and 
        A1: "i5 *XCMPLX-0K3 i0 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
         sorry
      have "i5 *XCMPLX-0K3 (i0 +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 (i1 +XCMPLX-0K2 i5)-XCMPLX-0K6 i2"
        using A1 sorry
      thus "(i1 +XCMPLX-0K2 i5,i2)are-congruent-modINT-1R3 i5"
         sorry
    qed
    assume "(i1 +XCMPLX-0K2 i5,i2)are-congruent-modINT-1R3 i5"
    then obtain i0 where
      [ty]:"i0 be IntegerINT-1M1" and 
      A2: "i5 *XCMPLX-0K3 i0 =XBOOLE-0R4 (i1 +XCMPLX-0K2 i5)-XCMPLX-0K6 i2"
       sorry
    have "i5 *XCMPLX-0K3 (i0 -XCMPLX-0K6 \<one>\<^sub>M) =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
      using A2 sorry
    thus "(i1,i2)are-congruent-modINT-1R3 i5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_22:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 iff (i1 -XCMPLX-0K6 i5,i2)are-congruent-modINT-1R3 i5"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds ((i1,i2)are-congruent-modINT-1R3 i5 implies (i1 -XCMPLX-0K6 i5,i2)are-congruent-modINT-1R3 i5) & ((i1 -XCMPLX-0K6 i5,i2)are-congruent-modINT-1R3 i5 implies (i1,i2)are-congruent-modINT-1R3 i5)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i5 assume [ty]: "i5 be IntegerINT-1M1"
    show "(i1,i2)are-congruent-modINT-1R3 i5 implies (i1 -XCMPLX-0K6 i5,i2)are-congruent-modINT-1R3 i5"
    proof(rule impI)
      assume "(i1,i2)are-congruent-modINT-1R3 i5"
      then obtain i0 where
        [ty]:"i0 be IntegerINT-1M1" and 
        A1: "i5 *XCMPLX-0K3 i0 =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
         sorry
      have "i5 *XCMPLX-0K3 (i0 -XCMPLX-0K6 \<one>\<^sub>M) =XBOOLE-0R4 (i1 -XCMPLX-0K6 i5)-XCMPLX-0K6 i2"
        using A1 sorry
      thus "(i1 -XCMPLX-0K6 i5,i2)are-congruent-modINT-1R3 i5"
         sorry
    qed
    assume "(i1 -XCMPLX-0K6 i5,i2)are-congruent-modINT-1R3 i5"
    then obtain i0 where
      [ty]:"i0 be IntegerINT-1M1" and 
      A2: "i5 *XCMPLX-0K3 i0 =XBOOLE-0R4 (i1 -XCMPLX-0K6 i5)-XCMPLX-0K6 i2"
       sorry
    have "i5 *XCMPLX-0K3 (i0 +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 i1 -XCMPLX-0K6 i2"
      using A2 sorry
    thus "(i1,i2)are-congruent-modINT-1R3 i5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_23:
" for r be RealXREAL-0M1 holds  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds ((i1 <=XXREAL-0R1 r & r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 i1) & i2 <=XXREAL-0R1 r) & r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 i2 implies i1 =HIDDENR1 i2"
proof-
  have " for r be RealXREAL-0M1 holds  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i1 <=XXREAL-0R1 r & (r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 i1 & (i2 <=XXREAL-0R1 r & r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 i2)) implies i1 =HIDDENR1 i2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    assume A1: "i1 <=XXREAL-0R1 r"
      and A2: "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 i1"
      and A3: "i2 <=XXREAL-0R1 r"
      and A4: "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 i2"
    have "i2 =HIDDENR1 i1 +XCMPLX-0K2 (i2 -XCMPLX-0K6 i1)"
       sorry
    then obtain i0 where
      [ty]:"i0 be IntegerINT-1M1" and 
      A5: "i2 =HIDDENR1 i1 +XCMPLX-0K2 i0"
       sorry
    have A6: "0NUMBERSK6 <XXREAL-0R3 i0 & i1 <>HIDDENR2 i2 implies  False "
    proof(rule impMI ,rule impI)
      assume A7: "0NUMBERSK6 <XXREAL-0R3 i0"
        and "i1 <>HIDDENR2 i2"
      have "\<one>\<^sub>M <=XXREAL-0R1 i0"
        using A7 int_1_lm_4 sorry
      then have "(r -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 i1 +XCMPLX-0K2 i0"
        using A2 xreal_1_th_8 sorry
      thus " False "
        using A3 A5 sorry
    qed
    have A8: "i0 <XXREAL-0R3 0NUMBERSK6 & i1 <>HIDDENR2 i2 implies  False "
    proof(rule impMI ,rule impI)
      assume A9: "i0 <XXREAL-0R3 0NUMBERSK6"
        and "i1 <>HIDDENR2 i2"
      have "i0 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A9 int_1_th_8 sorry
      then have "i1 +XCMPLX-0K2 i0 <=XXREAL-0R1 r +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A1 xreal_1_th_7 sorry
      thus " False "
        using A4 A5 sorry
    qed
    have "i0 =HIDDENR1 0NUMBERSK6 implies i2 =HIDDENR1 i1"
      using A5 sorry
    thus "i1 =HIDDENR1 i2"
      using A8 A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_24:
" for r be RealXREAL-0M1 holds  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds ((r <=XXREAL-0R1 i1 & i1 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M) & r <=XXREAL-0R1 i2) & i2 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M implies i1 =HIDDENR1 i2"
proof-
  have " for r be RealXREAL-0M1 holds  for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds r <=XXREAL-0R1 i1 & (i1 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M & (r <=XXREAL-0R1 i2 & i2 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M)) implies i1 =HIDDENR1 i2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    assume A1: "r <=XXREAL-0R1 i1"
      and A2: "i1 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      and A3: "r <=XXREAL-0R1 i2"
      and A4: "i2 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
    have "i2 =HIDDENR1 i1 +XCMPLX-0K2 (i2 -XCMPLX-0K6 i1)"
       sorry
    then obtain i0 where
      [ty]:"i0 be IntegerINT-1M1" and 
      A5: "i2 =HIDDENR1 i1 +XCMPLX-0K2 i0"
       sorry
    have A6: "i0 <XXREAL-0R3 0NUMBERSK6 & i1 <>HIDDENR2 i2 implies  False "
    proof(rule impMI ,rule impI)
      assume A7: "i0 <XXREAL-0R3 0NUMBERSK6"
        and "i1 <>HIDDENR2 i2"
      have "i0 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A7 int_1_th_8 sorry
      then have "i1 +XCMPLX-0K2 i0 <XXREAL-0R3 (r +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A2 xreal_1_th_8 sorry
      thus " False "
        using A3 A5 sorry
    qed
    have A8: "0NUMBERSK6 <XXREAL-0R3 i0 & i1 <>HIDDENR2 i2 implies  False "
    proof(rule impMI ,rule impI)
      assume A9: "0NUMBERSK6 <XXREAL-0R3 i0"
        and "i1 <>HIDDENR2 i2"
      have "\<one>\<^sub>M <=XXREAL-0R1 i0"
        using A9 int_1_lm_4 sorry
      thus " False "
        using A1 A4 A5 xreal_1_th_7 sorry
    qed
    have "i0 =HIDDENR1 0NUMBERSK6 implies i2 =HIDDENR1 i1"
      using A5 sorry
    thus "i1 =HIDDENR1 i2"
      using A6 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve r1, p, p1, g, g1, g2 for "RealXREAL-0M1"
reserve Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
mlemma int_1_lm_7:
" for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st r <XXREAL-0R3 n"
proof-
  have " for r be RealXREAL-0M1 holds  ex tVar9 be NatNAT-1M1 st  not r <XXREAL-0R3 tVar9"
  proof(rule ballI)
    let ?P = "\<lambda>Lamb1.  for r be RealXREAL-0M1 holds r inHIDDENR3 NATNUMBERSK1 implies  not Lamb1 <XXREAL-0R3 r"
    fix r assume [ty]: "r be RealXREAL-0M1"
    obtain Y where
      [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
      A1: " for p1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds p1 inTARSKIR2 Y iff ?P(p1)"
      using subset_1_sch_3 sorry
    obtain N where 
      [ty]:"N be SubsetSUBSET-1M2-of REALNUMBERSK2" and NDef:"N = NATNUMBERSK1"
      using numbers_th_19 sorry
    have " for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds r inHIDDENR3 N & p1 inHIDDENR3 Y implies r <=XXREAL-0R1 p1"
      using A1 sorry
    then obtain g2 where
      [ty]:"g2 be RealXREAL-0M1" and 
      A2: " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 N & p inHIDDENR3 Y implies r <=XXREAL-0R1 g2 & g2 <=XXREAL-0R1 p"
      using axioms_th_1 sorry
    have A3: "g2 +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 g2 +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_th_6 sorry
    have " for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st r inHIDDENR3 NATNUMBERSK1 & g <XXREAL-0R3 r"
    proof-
      have "( ex g1 be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds r inHIDDENR3 NATNUMBERSK1 implies  not g1 <XXREAL-0R3 r) implies  False "
      proof(rule impI)
        assume Given: " ex g1 be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds r inHIDDENR3 NATNUMBERSK1 implies  not g1 <XXREAL-0R3 r"
        then obtain g1 where
          [ty]:"g1 be RealXREAL-0M1" and 
          A4: " for r be RealXREAL-0M1 holds r inHIDDENR3 NATNUMBERSK1 implies  not g1 <XXREAL-0R3 r"
           sorry
        have "g1 inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have A5: "g1 inHIDDENR3 Y"
          using A1 A4 sorry
        have " not g2 -XCMPLX-0K6 \<one>\<^sub>M inTARSKIR2 Y implies  False "
        proof(rule impI)
          obtain g21 where 
            [ty]:"g21 be ElementSUBSET-1M1-of REALNUMBERSK2" and g21Def:"g21 = g2 -XCMPLX-0K6 \<one>\<^sub>M"
            using xreal_0_def_1 sorry
          assume " not g2 -XCMPLX-0K6 \<one>\<^sub>M inTARSKIR2 Y"
          then have " not ?P(g21)"
            using A1 sorry
          then obtain r1 where
            [ty]:"r1 be RealXREAL-0M1" and 
            A6: "r1 inHIDDENR3 NATNUMBERSK1"and A7: "g2 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1"
             sorry
          have A8: "r1 +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 NATNUMBERSK1"
            using A6 axioms_th_2 sorry
          have "(g2 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 r1 +XCMPLX-0K2 \<one>\<^sub>M"
            using A7 xreal_1_th_6 sorry
          thus " False "
            using A2 A5 A8 sorry
        qed
        thus " False "
          using A2 A3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain p where
      [ty]:"p be RealXREAL-0M1" and 
      A9: "p inHIDDENR3 NATNUMBERSK1"and A10: "r <XXREAL-0R3 p"
       sorry
    have 
      [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A9 sorry
    show " ex tVar9 be NatNAT-1M1 st  not r <XXREAL-0R3 tVar9"
    proof(rule bexI[of _ "p"])
      show " not r <XXREAL-0R3 p"
        using A10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef int_1_def_6 ("['\\INT-1K2  _ '/]" [0]164 ) where
  mlet "r be RealXREAL-0M1"
"func [\\INT-1K2 r/] \<rightarrow> IntegerINT-1M1 means
  \<lambda>it. it <=XXREAL-0R1 r & r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 it"
proof-
  (*existence*)
    show " ex it be IntegerINT-1M1 st it <=XXREAL-0R1 r & r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 it"
    proof-
      have " not ( for VarFor1 be IntegerINT-1M1 holds  not (VarFor1 <=XXREAL-0R1 r &  not r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 VarFor1))"
      proof-
        let ?P = "\<lambda>Lamb1. r <XXREAL-0R3 Lamb1"
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A1: "-XCMPLX-0K4 r <XXREAL-0R3 n"
          using int_1_lm_7 sorry
        have A2: "-XCMPLX-0K4 n <XXREAL-0R3 -XCMPLX-0K4 (-XCMPLX-0K4 r)"
          using A1 xreal_1_th_24 sorry
        have A3: " for i1 be IntegerINT-1M1 holds ?P(i1) implies -XCMPLX-0K4 n <=XXREAL-0R1 i1"
        proof-
          have " for i1 be IntegerINT-1M1 holds r <XXREAL-0R3 i1 implies -XCMPLX-0K4 n <=XXREAL-0R1 i1"
          proof(rule ballI,rule impI)
            fix i1 assume [ty]: "i1 be IntegerINT-1M1"
            assume "r <XXREAL-0R3 i1"
            then have "r +XCMPLX-0K2 (-XCMPLX-0K4 n) <XXREAL-0R3 i1 +XCMPLX-0K2 r"
              using A2 xreal_1_th_8 sorry
            thus "-XCMPLX-0K4 n <=XXREAL-0R1 i1"
              using xreal_1_th_6 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " ex n be NatNAT-1M1 st r <XXREAL-0R3 n"
          using int_1_lm_7 sorry
        then have A4: " ex i0 be IntegerINT-1M1 st ?P(i0)"
           sorry
        obtain i1 where
          [ty]:"i1 be IntegerINT-1M1" and 
          A5: "?P(i1) & ( for i2 be IntegerINT-1M1 holds ?P(i2) implies i1 <=XXREAL-0R1 i2)"
          using int_1_sch_5 A3 A4 sorry
        have A6: "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 i1 -XCMPLX-0K6 \<one>\<^sub>M"
          using A5 xreal_1_th_9 sorry
        have "r <XXREAL-0R3 i1 -XCMPLX-0K6 \<one>\<^sub>M implies i1 <=XXREAL-0R1 i1 -XCMPLX-0K6 \<one>\<^sub>M"
          using A5 sorry
        thus " not ( for VarFor1 be IntegerINT-1M1 holds  not (VarFor1 <=XXREAL-0R1 r &  not r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 VarFor1))"
          using A6 xreal_1_th_146 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be IntegerINT-1M1 holds  for it2 be IntegerINT-1M1 holds (it1 <=XXREAL-0R1 r & r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 it1) & (it2 <=XXREAL-0R1 r & r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 it2) implies it1 =HIDDENR1 it2"
      using int_1_th_23 sorry
qed "sorry"

mtheorem INT_1K2_projectivity:
" for r be RealXREAL-0M1 holds [\\INT-1K2 [\\INT-1K2 r/] /] =HIDDENR1 [\\INT-1K2 r/]"
proof-
  have " for it be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds it =HIDDENR1 [\\INT-1K2 r/] implies it =HIDDENR1 [\\INT-1K2 it/]"
  proof-
    have " for it be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds it <=XXREAL-0R1 r & r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 it implies it <=XXREAL-0R1 it & it -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 it"
      using xreal_1_th_44 sorry
    thus " ?thesis "
      using int_1_def_6 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_25:
" for r be RealXREAL-0M1 holds [\\INT-1K2 r/] =HIDDENR1 r iff r be integerINT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  not ([\\INT-1K2 r/] =HIDDENR1 r &  not r be integerINT-1V1) &  not (r be integerINT-1V1 &  not [\\INT-1K2 r/] =HIDDENR1 r)"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r be IntegerINT-1M1 implies [\\INT-1K2 r/] =HIDDENR1 r"
    proof(rule impI)
      have "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      then have A1: "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (r +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_9 sorry
      assume "r be IntegerINT-1M1"
      thus "[\\INT-1K2 r/] =HIDDENR1 r"
        using A1 int_1_def_6 sorry
    qed
    thus " not ([\\INT-1K2 r/] =HIDDENR1 r &  not r be integerINT-1V1) &  not (r be integerINT-1V1 &  not [\\INT-1K2 r/] =HIDDENR1 r)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_26:
" for r be RealXREAL-0M1 holds [\\INT-1K2 r/] <XXREAL-0R3 r iff  not r be integerINT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  not ( not [\\INT-1K2 r/] <XXREAL-0R3 r & r be integerINT-1V1) &  not ( not r be integerINT-1V1 & [\\INT-1K2 r/] <XXREAL-0R3 r)"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have " not r be IntegerINT-1M1 implies [\\INT-1K2 r/] <XXREAL-0R3 r"
    proof(rule impI)
      assume A1: " not r be IntegerINT-1M1"
      have "[\\INT-1K2 r/] <=XXREAL-0R1 r"
        using int_1_def_6 sorry
      thus "[\\INT-1K2 r/] <XXREAL-0R3 r"
        using A1 xxreal_0_th_1 sorry
    qed
    thus " not ( not [\\INT-1K2 r/] <XXREAL-0R3 r & r be integerINT-1V1) &  not ( not r be integerINT-1V1 & [\\INT-1K2 r/] <XXREAL-0R3 r)"
      using int_1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_27:
" for r be RealXREAL-0M1 holds [\\INT-1K2 r/] -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r & [\\INT-1K2 r/] <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  not [\\INT-1K2 r/] -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r &  not [\\INT-1K2 r/] <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "[\\INT-1K2 r/] <=XXREAL-0R1 r"
      using int_1_def_6 sorry
    then have A1: "[\\INT-1K2 r/] +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_8 sorry
    then have "[\\INT-1K2 r/] +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 (r +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using xreal_1_th_6 sorry
    thus " not [\\INT-1K2 r/] -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r &  not [\\INT-1K2 r/] <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_28:
" for r be RealXREAL-0M1 holds  for i0 be IntegerINT-1M1 holds [\\INT-1K2 r/] +XCMPLX-0K2 i0 =HIDDENR1 [\\INT-1K2 r +XCMPLX-0K2 i0 /]"
proof-
  have " for r be RealXREAL-0M1 holds  for i0 be IntegerINT-1M1 holds [\\INT-1K2 r/] +XCMPLX-0K2 i0 =HIDDENR1 [\\INT-1K2 r +XCMPLX-0K2 i0 /]"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    have "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/]"
      using int_1_def_6 sorry
    then have "(r -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 i0 <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 i0"
      using xreal_1_th_6 sorry
    then have A1: "(r +XCMPLX-0K2 i0)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 i0"
       sorry
    have "[\\INT-1K2 r/] <=XXREAL-0R1 r"
      using int_1_def_6 sorry
    then have "[\\INT-1K2 r/] +XCMPLX-0K2 i0 <=XXREAL-0R1 r +XCMPLX-0K2 i0"
      using xreal_1_th_6 sorry
    thus "[\\INT-1K2 r/] +XCMPLX-0K2 i0 =HIDDENR1 [\\INT-1K2 r +XCMPLX-0K2 i0 /]"
      using A1 int_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_29:
" for r be RealXREAL-0M1 holds r <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  not r <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/]"
      using int_1_def_6 sorry
    then have "(r -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    thus " not r <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef int_1_def_7 ("['/INT-1K3  _ '\\]" [0]164 ) where
  mlet "r be RealXREAL-0M1"
"func [/INT-1K3 r\\] \<rightarrow> IntegerINT-1M1 means
  \<lambda>it. r <=XXREAL-0R1 it & it <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  (*existence*)
    show " ex it be IntegerINT-1M1 st r <=XXREAL-0R1 it & it <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
    proof-
      have " not ( for VarFor1 be IntegerINT-1M1 holds  not (r <=XXREAL-0R1 VarFor1 &  not VarFor1 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M))"
      proof-
        have A1: "r be IntegerINT-1M1 implies r <=XXREAL-0R1 [\\INT-1K2 r/] & [\\INT-1K2 r/] <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
        proof(rule impI)
          have A2: "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
            using xreal_1_th_6 sorry
          assume "r be IntegerINT-1M1"
          thus "r <=XXREAL-0R1 [\\INT-1K2 r/] & [\\INT-1K2 r/] <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
            using A2 int_1_th_25 sorry
        qed
        have " not r be IntegerINT-1M1 implies r <=XXREAL-0R1 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
          using int_1_th_29 xreal_1_th_6 int_1_th_26 sorry
        thus " not ( for VarFor1 be IntegerINT-1M1 holds  not (r <=XXREAL-0R1 VarFor1 &  not VarFor1 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M))"
          using A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be IntegerINT-1M1 holds  for it2 be IntegerINT-1M1 holds (r <=XXREAL-0R1 it1 & it1 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M) & (r <=XXREAL-0R1 it2 & it2 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M) implies it1 =HIDDENR1 it2"
      using int_1_th_24 sorry
qed "sorry"

mtheorem INT_1K3_projectivity:
" for r be RealXREAL-0M1 holds [/INT-1K3 [/INT-1K3 r\\] \\] =HIDDENR1 [/INT-1K3 r\\]"
proof-
  have " for it be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds it =HIDDENR1 [/INT-1K3 r\\] implies it =HIDDENR1 [/INT-1K3 it\\]"
  proof-
    have " for it be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds r <=XXREAL-0R1 it & it <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M implies it <=XXREAL-0R1 it & it <XXREAL-0R3 it +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_29 sorry
    thus " ?thesis "
      using int_1_def_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_30:
" for r be RealXREAL-0M1 holds [/INT-1K3 r\\] =HIDDENR1 r iff r be integerINT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  not ([/INT-1K3 r\\] =HIDDENR1 r &  not r be integerINT-1V1) &  not (r be integerINT-1V1 &  not [/INT-1K3 r\\] =HIDDENR1 r)"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    thus " not ([/INT-1K3 r\\] =HIDDENR1 r &  not r be integerINT-1V1) &  not (r be integerINT-1V1 &  not [/INT-1K3 r\\] =HIDDENR1 r)"
      using int_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_31:
" for r be RealXREAL-0M1 holds r <XXREAL-0R3 [/INT-1K3 r\\] iff  not r be integerINT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  not ( not r <XXREAL-0R3 [/INT-1K3 r\\] & r be integerINT-1V1) &  not ( not r be integerINT-1V1 & r <XXREAL-0R3 [/INT-1K3 r\\])"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have " not r be IntegerINT-1M1 implies r <XXREAL-0R3 [/INT-1K3 r\\]"
    proof(rule impI)
      assume A1: " not r be IntegerINT-1M1"
      have "r <=XXREAL-0R1 [/INT-1K3 r\\]"
        using int_1_def_7 sorry
      thus "r <XXREAL-0R3 [/INT-1K3 r\\]"
        using A1 xxreal_0_th_1 sorry
    qed
    thus " not ( not r <XXREAL-0R3 [/INT-1K3 r\\] & r be integerINT-1V1) &  not ( not r be integerINT-1V1 & r <XXREAL-0R3 [/INT-1K3 r\\])"
      using int_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_32:
" for r be RealXREAL-0M1 holds r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [/INT-1K3 r\\] & r <XXREAL-0R3 [/INT-1K3 r\\] +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  not r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [/INT-1K3 r\\] &  not r <XXREAL-0R3 [/INT-1K3 r\\] +XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r <=XXREAL-0R1 [/INT-1K3 r\\]"
      using int_1_def_7 sorry
    then have A1: "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 [/INT-1K3 r\\] +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_8 sorry
    then have "r +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 ([/INT-1K3 r\\] +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using xreal_1_th_6 sorry
    thus " not r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [/INT-1K3 r\\] &  not r <XXREAL-0R3 [/INT-1K3 r\\] +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_33:
" for r be RealXREAL-0M1 holds  for i0 be IntegerINT-1M1 holds [/INT-1K3 r\\] +XCMPLX-0K2 i0 =HIDDENR1 [/INT-1K3 r +XCMPLX-0K2 i0 \\]"
proof-
  have " for r be RealXREAL-0M1 holds  for i0 be IntegerINT-1M1 holds [/INT-1K3 r\\] +XCMPLX-0K2 i0 =HIDDENR1 [/INT-1K3 r +XCMPLX-0K2 i0 \\]"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i0 assume [ty]: "i0 be IntegerINT-1M1"
    have "[/INT-1K3 r\\] <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      using int_1_def_7 sorry
    then have "[/INT-1K3 r\\] +XCMPLX-0K2 i0 <XXREAL-0R3 (r +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 i0"
      using xreal_1_th_6 sorry
    then have A1: "[/INT-1K3 r\\] +XCMPLX-0K2 i0 <XXREAL-0R3 (r +XCMPLX-0K2 i0)+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    have "r <=XXREAL-0R1 [/INT-1K3 r\\]"
      using int_1_def_7 sorry
    then have "r +XCMPLX-0K2 i0 <=XXREAL-0R1 [/INT-1K3 r\\] +XCMPLX-0K2 i0"
      using xreal_1_th_6 sorry
    thus "[/INT-1K3 r\\] +XCMPLX-0K2 i0 =HIDDENR1 [/INT-1K3 r +XCMPLX-0K2 i0 \\]"
      using A1 int_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_34:
" for r be RealXREAL-0M1 holds [\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\] iff r be integerINT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  not ([\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\] &  not r be integerINT-1V1) &  not (r be integerINT-1V1 &  not [\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\])"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: " not r be IntegerINT-1M1 implies [\\INT-1K2 r/] <>HIDDENR2 [/INT-1K3 r\\]"
    proof(rule impI)
      assume A2: " not r be IntegerINT-1M1"
      then have "[\\INT-1K2 r/] <XXREAL-0R3 r"
        using int_1_th_26 sorry
      thus "[\\INT-1K2 r/] <>HIDDENR2 [/INT-1K3 r\\]"
        using A2 int_1_th_31 sorry
    qed
    have "r be IntegerINT-1M1 implies ([\\INT-1K2 r/] =HIDDENR1 r & r =HIDDENR1 [/INT-1K3 r\\]) & [\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\]"
    proof(rule impI,rule conjMI)
      assume "r be IntegerINT-1M1"
      thus "[\\INT-1K2 r/] =HIDDENR1 r & r =HIDDENR1 [/INT-1K3 r\\]"
        using int_1_th_25 int_1_th_30 sorry
      thus "[\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\]"
         sorry
    qed
    thus " not ([\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\] &  not r be integerINT-1V1) &  not (r be integerINT-1V1 &  not [\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\])"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_35:
" for r be RealXREAL-0M1 holds [\\INT-1K2 r/] <XXREAL-0R3 [/INT-1K3 r\\] iff  not r be integerINT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  not ( not [\\INT-1K2 r/] <XXREAL-0R3 [/INT-1K3 r\\] & r be integerINT-1V1) &  not ( not r be integerINT-1V1 & [\\INT-1K2 r/] <XXREAL-0R3 [/INT-1K3 r\\])"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have " not r be IntegerINT-1M1 implies [\\INT-1K2 r/] <XXREAL-0R3 [/INT-1K3 r\\]"
    proof(rule impI)
      assume A1: " not r be IntegerINT-1M1"
      then have A2: "r <XXREAL-0R3 [/INT-1K3 r\\]"
        using int_1_th_31 sorry
      have "[\\INT-1K2 r/] <XXREAL-0R3 r"
        using A1 int_1_th_26 sorry
      thus "[\\INT-1K2 r/] <XXREAL-0R3 [/INT-1K3 r\\]"
        using A2 xxreal_0_th_2 sorry
    qed
    thus " not ( not [\\INT-1K2 r/] <XXREAL-0R3 [/INT-1K3 r\\] & r be integerINT-1V1) &  not ( not r be integerINT-1V1 & [\\INT-1K2 r/] <XXREAL-0R3 [/INT-1K3 r\\])"
      using int_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_36:
" for r be RealXREAL-0M1 holds [\\INT-1K2 r/] <=XXREAL-0R1 [/INT-1K3 r\\]"
proof-
  have " for r be RealXREAL-0M1 holds [\\INT-1K2 r/] <=XXREAL-0R1 [/INT-1K3 r\\]"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "r <=XXREAL-0R1 [/INT-1K3 r\\]"
      using int_1_def_7 sorry
    have "[\\INT-1K2 r/] <=XXREAL-0R1 r"
      using int_1_def_6 sorry
    thus "[\\INT-1K2 r/] <=XXREAL-0R1 [/INT-1K3 r\\]"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_37:
" for r be RealXREAL-0M1 holds [\\INT-1K2 [/INT-1K3 r\\] /] =HIDDENR1 [/INT-1K3 r\\]"
  using int_1_th_25 sorry

(*\$CT 2*)
mtheorem int_1_th_40:
" for r be RealXREAL-0M1 holds [/INT-1K3 [\\INT-1K2 r/] \\] =HIDDENR1 [\\INT-1K2 r/]"
  using int_1_th_30 sorry

mtheorem int_1_th_41:
" for r be RealXREAL-0M1 holds [\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\] iff  not [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [/INT-1K3 r\\]"
proof-
  have " for r be RealXREAL-0M1 holds  not ([\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\] & [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [/INT-1K3 r\\]) &  not ( not [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [/INT-1K3 r\\] &  not [\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\])"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?Diff = "[/INT-1K3 r\\] +XCMPLX-0K2 (-XCMPLX-0K4 [\\INT-1K2 r/])"
    have A1: " not r be IntegerINT-1M1 implies [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [/INT-1K3 r\\] & [\\INT-1K2 r/] <>HIDDENR2 [/INT-1K3 r\\]"
    proof(rule impI)
      assume " not r be IntegerINT-1M1"
      then have "[\\INT-1K2 r/] <XXREAL-0R3 [/INT-1K3 r\\]"
        using int_1_th_35 sorry
      then have "[\\INT-1K2 r/] +XCMPLX-0K2 (-XCMPLX-0K4 [\\INT-1K2 r/]) <XXREAL-0R3 ?Diff"
        using xreal_1_th_6 sorry
      then have A2: "\<one>\<^sub>M <=XXREAL-0R1 ?Diff"
        using int_1_lm_4 sorry
      have "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/]"
        using int_1_def_6 sorry
      then have A3: "-XCMPLX-0K4 [\\INT-1K2 r/] <XXREAL-0R3 -XCMPLX-0K4 (r -XCMPLX-0K6 \<one>\<^sub>M)"
        using xreal_1_th_24 sorry
      have "[/INT-1K3 r\\] <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
        using int_1_def_7 sorry
      then have "?Diff <XXREAL-0R3 (r +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 (r -XCMPLX-0K6 \<one>\<^sub>M))"
        using A3 xreal_1_th_8 sorry
      then have "(?Diff +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <=XXREAL-0R1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using int_1_th_7 sorry
      then have "[\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 [\\INT-1K2 r/] +XCMPLX-0K2 ?Diff"
        using A2 xxreal_0_th_1 sorry
      thus "[\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [/INT-1K3 r\\] & [\\INT-1K2 r/] <>HIDDENR2 [/INT-1K3 r\\]"
         sorry
    qed
    have "r be IntegerINT-1M1 implies [\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\] & [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M <>HIDDENR2 [/INT-1K3 r\\]"
    proof(rule impI)
      assume "r be IntegerINT-1M1"
      then have "[\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\]"
        using int_1_th_34 sorry
      thus "[\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\] & [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M <>HIDDENR2 [/INT-1K3 r\\]"
         sorry
    qed
    thus " not ([\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\] & [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [/INT-1K3 r\\]) &  not ( not [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 [/INT-1K3 r\\] &  not [\\INT-1K2 r/] =HIDDENR1 [/INT-1K3 r\\])"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef int_1_def_8 ("fracINT-1K4  _ " [240]240 ) where
  mlet "r be RealXREAL-0M1"
"func fracINT-1K4 r \<rightarrow> numberORDINAL1M2 equals
  r -XCMPLX-0K6 [\\INT-1K2 r/]"
proof-
  (*coherence*)
    show "r -XCMPLX-0K6 [\\INT-1K2 r/] be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem int_1_cl_10:
  mlet "r be RealXREAL-0M1"
"cluster fracINT-1K4 r as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "fracINT-1K4 r be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem int_1_th_42:
" for r be RealXREAL-0M1 holds r =HIDDENR1 [\\INT-1K2 r/] +XCMPLX-0K2 fracINT-1K4 r"
   sorry

mtheorem int_1_th_43:
" for r be RealXREAL-0M1 holds fracINT-1K4 r <XXREAL-0R3 \<one>\<^sub>M & 0NUMBERSK6 <=XXREAL-0R1 fracINT-1K4 r"
proof-
  have " for r be RealXREAL-0M1 holds  not fracINT-1K4 r <XXREAL-0R3 \<one>\<^sub>M & 0NUMBERSK6 <=XXREAL-0R1 fracINT-1K4 r"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/]"
      using int_1_def_6 sorry
    then have "fracINT-1K4 r +XCMPLX-0K2 (r -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 (r -XCMPLX-0K6 [\\INT-1K2 r/])+XCMPLX-0K2 [\\INT-1K2 r/]"
      using xreal_1_th_6 sorry
    then have "((fracINT-1K4 r +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))+XCMPLX-0K2 r)-XCMPLX-0K6 r <XXREAL-0R3 r -XCMPLX-0K6 r"
      using xreal_1_th_9 sorry
    then have A1: "(fracINT-1K4 r -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    have "[\\INT-1K2 r/] <=XXREAL-0R1 r"
      using int_1_def_6 sorry
    then have "[\\INT-1K2 r/] +XCMPLX-0K2 (r -XCMPLX-0K6 [\\INT-1K2 r/]) <=XXREAL-0R1 r +XCMPLX-0K2 fracINT-1K4 r"
      using xreal_1_th_6 sorry
    then have "r -XCMPLX-0K6 r <=XXREAL-0R1 (r +XCMPLX-0K2 fracINT-1K4 r)-XCMPLX-0K6 r"
      using xreal_1_th_9 sorry
    thus " not fracINT-1K4 r <XXREAL-0R3 \<one>\<^sub>M & 0NUMBERSK6 <=XXREAL-0R1 fracINT-1K4 r"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_44:
" for r be RealXREAL-0M1 holds [\\INT-1K2 fracINT-1K4 r/] =HIDDENR1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds [\\INT-1K2 fracINT-1K4 r/] =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "[\\INT-1K2 fracINT-1K4 r/] =HIDDENR1 [\\INT-1K2 r +XCMPLX-0K2 (-XCMPLX-0K4 [\\INT-1K2 r/]) /]"
       sorry
    also have "... = [\\INT-1K2 r/] +XCMPLX-0K2 (-XCMPLX-0K4 [\\INT-1K2 r/])"
      using int_1_th_28 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "[\\INT-1K2 fracINT-1K4 r/] =HIDDENR1 0NUMBERSK6"
       sorry
    thus "[\\INT-1K2 fracINT-1K4 r/] =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_45:
" for r be RealXREAL-0M1 holds fracINT-1K4 r =XBOOLE-0R4 0NUMBERSK6 iff r be integerINT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  not (fracINT-1K4 r =XBOOLE-0R4 0NUMBERSK6 &  not r be integerINT-1V1) &  not (r be integerINT-1V1 &  not fracINT-1K4 r =XBOOLE-0R4 0NUMBERSK6)"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r be IntegerINT-1M1 implies fracINT-1K4 r =XBOOLE-0R4 0NUMBERSK6"
    proof(rule impI)
      assume "r be IntegerINT-1M1"
      then have "r =HIDDENR1 [\\INT-1K2 r/]"
        using int_1_th_25 sorry
      thus "fracINT-1K4 r =XBOOLE-0R4 0NUMBERSK6"
         sorry
    qed
    thus " not (fracINT-1K4 r =XBOOLE-0R4 0NUMBERSK6 &  not r be integerINT-1V1) &  not (r be integerINT-1V1 &  not fracINT-1K4 r =XBOOLE-0R4 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_46:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 fracINT-1K4 r iff  not r be integerINT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 fracINT-1K4 r & r be integerINT-1V1) &  not ( not r be integerINT-1V1 & 0NUMBERSK6 <XXREAL-0R3 fracINT-1K4 r)"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have " not r be IntegerINT-1M1 implies 0NUMBERSK6 <XXREAL-0R3 fracINT-1K4 r"
    proof(rule impI)
      assume " not r be IntegerINT-1M1"
      then have "0NUMBERSK6 <>HIDDENR2 fracINT-1K4 r"
         sorry
      thus "0NUMBERSK6 <XXREAL-0R3 fracINT-1K4 r"
        using int_1_th_43 sorry
    qed
    thus " not ( not 0NUMBERSK6 <XXREAL-0R3 fracINT-1K4 r & r be integerINT-1V1) &  not ( not r be integerINT-1V1 & 0NUMBERSK6 <XXREAL-0R3 fracINT-1K4 r)"
      using int_1_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef int_1_def_9 (" _ divINT-1K5  _ " [132,132]132 ) where
  mlet "i1 be IntegerINT-1M1", "i2 be IntegerINT-1M1"
"func i1 divINT-1K5 i2 \<rightarrow> IntegerINT-1M1 equals
  [\\INT-1K2 i1 /XCMPLX-0K7 i2 /]"
proof-
  (*coherence*)
    show "[\\INT-1K2 i1 /XCMPLX-0K7 i2 /] be IntegerINT-1M1"
       sorry
qed "sorry"

mdef int_1_def_10 (" _ modINT-1K6  _ " [132,132]132 ) where
  mlet "i1 be IntegerINT-1M1", "i2 be IntegerINT-1M1"
"func i1 modINT-1K6 i2 \<rightarrow> IntegerINT-1M1 equals
  i1 -XCMPLX-0K6 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 if i2 <>HIDDENR2 0NUMBERSK6 otherwise 0NUMBERSK6"
proof-
  (*coherence*)
    show "(i2 <>HIDDENR2 0NUMBERSK6 implies i1 -XCMPLX-0K6 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 be IntegerINT-1M1) & ( not i2 <>HIDDENR2 0NUMBERSK6 implies 0NUMBERSK6 be IntegerINT-1M1)"
       sorry
  (*consistency*)
    show " for it be IntegerINT-1M1 holds  True "
       sorry
qed "sorry"

mtheorem int_1_th_47:
" for r be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies [\\INT-1K2 r /XCMPLX-0K7 r /] =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI,rule impI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume "r <>HIDDENR2 0NUMBERSK6"
  then have "[\\INT-1K2 r /XCMPLX-0K7 r /] =HIDDENR1 [\\INT-1K2 \<one>\<^sub>M/]"
    using xcmplx_1_th_60 sorry
  also have "... = \<one>\<^sub>M"
    using int_1_th_25 sorry
  finally show "[\\INT-1K2 r /XCMPLX-0K7 r /] =HIDDENR1 \<one>\<^sub>M"
     sorry
qed "sorry"

mtheorem int_1_th_48:
" for i be IntegerINT-1M1 holds i divINT-1K5 0NUMBERSK6 =HIDDENR1 0NUMBERSK6"
proof(rule ballI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  have A1: "i /XCMPLX-0K7 (0NUMBERSK6) =HIDDENR1 i *XCMPLX-0K3 (0NUMBERSK6)\<inverse>XCMPLX-0K5"
    using xcmplx_0_def_9 sorry
  also have "... = i *XCMPLX-0K3 (0NUMBERSK6)"
     sorry
  finally have "i /XCMPLX-0K7 (0NUMBERSK6) =HIDDENR1 i *XCMPLX-0K3 (0NUMBERSK6)"
     sorry
  have "0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6"
     sorry
  thus "i divINT-1K5 0NUMBERSK6 =HIDDENR1 0NUMBERSK6"
    using A1 int_1_def_6 sorry
qed "sorry"

mtheorem int_1_th_49:
" for i be IntegerINT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies i divINT-1K5 i =HIDDENR1 \<one>\<^sub>M"
  using int_1_th_47 sorry

mtheorem int_1_th_50:
" for i be IntegerINT-1M1 holds i modINT-1K6 i =HIDDENR1 0NUMBERSK6"
proof(rule ballI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  show "i modINT-1K6 i =HIDDENR1 0NUMBERSK6"
  proof-
    have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "i =HIDDENR1 0NUMBERSK6 implies i modINT-1K6 i =HIDDENR1 0NUMBERSK6"
    proof(rule impI)
      assume "i =HIDDENR1 0NUMBERSK6"
      thus "i modINT-1K6 i =HIDDENR1 0NUMBERSK6"
        using int_1_def_10 sorry
    qed
    have case2: "i <>HIDDENR2 0NUMBERSK6 implies i modINT-1K6 i =HIDDENR1 0NUMBERSK6"
    proof(rule impI)
      assume A1: "i <>HIDDENR2 0NUMBERSK6"
      then have "i modINT-1K6 i =HIDDENR1 i -XCMPLX-0K6 (i divINT-1K5 i)*XCMPLX-0K3 i"
        using int_1_def_10 sorry
      also have "... = i -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 i"
        using A1 int_1_th_47 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally show "i modINT-1K6 i =HIDDENR1 0NUMBERSK6"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

(*begin*)
mtheorem int_1_th_51:
" for k be IntegerINT-1M1 holds  for i be IntegerINT-1M1 holds k <XXREAL-0R3 i implies ( ex j be ElementSUBSET-1M1-of NATNUMBERSK1 st j =XBOOLE-0R4 i -XCMPLX-0K6 k & \<one>\<^sub>M <=XXREAL-0R1 j)"
proof-
  have " for k be IntegerINT-1M1 holds  for i be IntegerINT-1M1 holds k <XXREAL-0R3 i implies ( ex tVar10 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar10 =XBOOLE-0R4 i -XCMPLX-0K6 k & \<one>\<^sub>M <=XXREAL-0R1 tVar10)"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be IntegerINT-1M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume "k <XXREAL-0R3 i"
    then have A1: "k -XCMPLX-0K6 k <XXREAL-0R3 i -XCMPLX-0K6 k"
      using xreal_1_th_9 sorry
    then obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = i -XCMPLX-0K6 k"
      using int_1_th_3 sorry
    obtain j9 Z9 where 
      [ty]:"j9 be IntegerINT-1M1" and j9Def:"j9 = j" and
      [ty]:"Z9 be IntegerINT-1M1" and Z9Def:"Z9 = 0NUMBERSK6"
       sorry
    show " ex tVar10 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar10 =XBOOLE-0R4 i -XCMPLX-0K6 k & \<one>\<^sub>M <=XXREAL-0R1 tVar10"
    proof(rule bexI[of _ "j"],rule conjMI)
      show "j =XBOOLE-0R4 i -XCMPLX-0K6 k"
         sorry
      have "Z9 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 j9"
        using A1 int_1_th_7 sorry
      thus "\<one>\<^sub>M <=XXREAL-0R1 j"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_52:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a <XXREAL-0R3 b implies a <=XXREAL-0R1 b -XCMPLX-0K6 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be IntegerINT-1M1"
  fix b assume [ty]: "b be IntegerINT-1M1"
  assume "a <XXREAL-0R3 b"
  then have "a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 b -XCMPLX-0K6 \<one>\<^sub>M"
    using xreal_1_th_9 sorry
  then have "(a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 b -XCMPLX-0K6 \<one>\<^sub>M"
    using int_1_th_7 sorry
  thus "a <=XXREAL-0R1 b -XCMPLX-0K6 \<one>\<^sub>M"
     sorry
qed "sorry"

mtheorem int_1_th_53:
" for r be RealXREAL-0M1 holds r >=XXREAL-0R2 0NUMBERSK6 implies (([/INT-1K3 r\\] >=XXREAL-0R2 0NUMBERSK6 & [\\INT-1K2 r/] >=XXREAL-0R2 0NUMBERSK6) & [/INT-1K3 r\\] be ElementSUBSET-1M1-of NATNUMBERSK1) & [\\INT-1K2 r/] be ElementSUBSET-1M1-of NATNUMBERSK1"
proof(rule ballI,rule impI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume A1: "r >=XXREAL-0R2 0NUMBERSK6"
  have A2: "r <=XXREAL-0R1 [/INT-1K3 r\\]"
    using int_1_def_7 sorry
  have "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/]"
    using int_1_def_6 sorry
  then have "(r -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
    using xreal_1_th_6 sorry
  then have "0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ([\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
    using A1 xreal_1_th_9 sorry
  then have "[\\INT-1K2 r/] >=XXREAL-0R2 0NUMBERSK6"
    using int_1_th_8 sorry
  thus "(([/INT-1K3 r\\] >=XXREAL-0R2 0NUMBERSK6 & [\\INT-1K2 r/] >=XXREAL-0R2 0NUMBERSK6) & [/INT-1K3 r\\] be ElementSUBSET-1M1-of NATNUMBERSK1) & [\\INT-1K2 r/] be ElementSUBSET-1M1-of NATNUMBERSK1"
    using A1 A2 int_1_th_3 sorry
qed "sorry"

mtheorem int_1_th_54:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds i <=XXREAL-0R1 r implies i <=XXREAL-0R1 [\\INT-1K2 r/]"
proof(rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume "i <=XXREAL-0R1 r"
  then have A1: "i -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 r -XCMPLX-0K6 \<one>\<^sub>M"
    using xreal_1_th_9 sorry
  have "r -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/]"
    using int_1_def_6 sorry
  then have "i -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/]"
    using A1 xxreal_0_th_2 sorry
  then have "(i -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 [\\INT-1K2 r/]"
    using int_1_th_7 sorry
  thus "i <=XXREAL-0R1 [\\INT-1K2 r/]"
     sorry
qed "sorry"

mtheorem int_1_th_55:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 m divINT-1K5 n"
  using int_1_th_54 sorry

mtheorem int_1_th_56:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 i & \<one>\<^sub>M <XXREAL-0R3 j implies i divINT-1K5 j <XXREAL-0R3 i"
proof-
  have " for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 i & \<one>\<^sub>M <XXREAL-0R3 j implies (i <=XXREAL-0R1 i divINT-1K5 j implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix j assume [ty]: "j be IntegerINT-1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 i"
      and A2: "\<one>\<^sub>M <XXREAL-0R3 j"
    assume A3: "i <=XXREAL-0R1 i divINT-1K5 j"
    have "i divINT-1K5 j <=XXREAL-0R1 i /XCMPLX-0K7 j"
      using int_1_def_6 sorry
    then have "j *XCMPLX-0K3 (i divINT-1K5 j) <=XXREAL-0R1 j *XCMPLX-0K3 (i /XCMPLX-0K7 j)"
      using A2 xreal_1_th_64 sorry
    then have "j *XCMPLX-0K3 (i divINT-1K5 j) <=XXREAL-0R1 i"
      using A2 xcmplx_1_th_87 sorry
    then have "j *XCMPLX-0K3 (i divINT-1K5 j) <=XXREAL-0R1 i divINT-1K5 j"
      using A3 xxreal_0_th_2 sorry
    then have "(j *XCMPLX-0K3 (i divINT-1K5 j))*XCMPLX-0K3 (i divINT-1K5 j)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (i divINT-1K5 j)*XCMPLX-0K3 (i divINT-1K5 j)\<inverse>XCMPLX-0K5"
      using A1 A3 xreal_1_th_64 sorry
    then have "j *XCMPLX-0K3 ((i divINT-1K5 j)*XCMPLX-0K3 (i divINT-1K5 j)\<inverse>XCMPLX-0K5) <=XXREAL-0R1 (i divINT-1K5 j)*XCMPLX-0K3 (i divINT-1K5 j)\<inverse>XCMPLX-0K5"
       sorry
    then have "j *XCMPLX-0K3 \<one>\<^sub>M <=XXREAL-0R1 (i divINT-1K5 j)*XCMPLX-0K3 (i divINT-1K5 j)\<inverse>XCMPLX-0K5"
      using A1 A3 xcmplx_0_def_7 sorry
    thus " False "
      using A1 A2 A3 xcmplx_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_57:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 >=XXREAL-0R2 0NUMBERSK6 implies i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 >=XXREAL-0R2 0NUMBERSK6 implies i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    assume A1: "i2 >=XXREAL-0R2 0NUMBERSK6"
    show "i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
    proof-
      have cases: "i2 >XXREAL-0R4 0NUMBERSK6 or i2 =HIDDENR1 0NUMBERSK6"
        using A1 sorry
      have case1: "i2 >XXREAL-0R4 0NUMBERSK6 implies i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume A2: "i2 >XXREAL-0R4 0NUMBERSK6"
        have "[\\INT-1K2 i1 /XCMPLX-0K7 i2 /] <=XXREAL-0R1 i1 /XCMPLX-0K7 i2"
          using int_1_def_6 sorry
        then have "(i1 divINT-1K5 i2)*XCMPLX-0K3 i2 <=XXREAL-0R1 (i1 /XCMPLX-0K7 i2)*XCMPLX-0K3 i2"
          using A2 xreal_1_th_64 sorry
        then have "(i1 divINT-1K5 i2)*XCMPLX-0K3 i2 <=XXREAL-0R1 i1"
          using A2 xcmplx_1_th_87 sorry
        then have "i1 -XCMPLX-0K6 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 >=XXREAL-0R2 0NUMBERSK6"
          using xreal_1_th_48 sorry
        thus "i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
          using int_1_def_10 sorry
      qed
      have case2: "i2 =HIDDENR1 0NUMBERSK6 implies i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "i2 =HIDDENR1 0NUMBERSK6"
        thus "i1 modINT-1K6 i2 >=XXREAL-0R2 0NUMBERSK6"
          using int_1_def_10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_58:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 >XXREAL-0R4 0NUMBERSK6 implies i1 modINT-1K6 i2 <XXREAL-0R3 i2"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 >XXREAL-0R4 0NUMBERSK6 implies  not i1 modINT-1K6 i2 <XXREAL-0R3 i2"
  proof(rule ballI,rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    assume A1: "i2 >XXREAL-0R4 0NUMBERSK6"
    have "i1 /XCMPLX-0K7 i2 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 i1 /XCMPLX-0K7 i2 /]"
      using int_1_def_6 sorry
    then have "(i1 /XCMPLX-0K7 i2 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 i2 <XXREAL-0R3 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2"
      using A1 xreal_1_th_68 sorry
    then have "(i1 /XCMPLX-0K7 i2)*XCMPLX-0K3 i2 -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 i2 <XXREAL-0R3 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2"
       sorry
    then have "i1 -XCMPLX-0K6 i2 <XXREAL-0R3 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 -XCMPLX-0K6 0NUMBERSK6"
      using A1 xcmplx_1_th_87 sorry
    then have "i1 -XCMPLX-0K6 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 <XXREAL-0R3 i2 -XCMPLX-0K6 0NUMBERSK6"
      using xreal_1_th_17 sorry
    thus " not i1 modINT-1K6 i2 <XXREAL-0R3 i2"
      using A1 int_1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_59:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 <>HIDDENR2 0NUMBERSK6 implies i1 =HIDDENR1 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 +XCMPLX-0K2 (i1 modINT-1K6 i2)"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds i2 <>HIDDENR2 0NUMBERSK6 implies i1 =HIDDENR1 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 +XCMPLX-0K2 (i1 modINT-1K6 i2)"
  proof(rule ballI,rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    assume "i2 <>HIDDENR2 0NUMBERSK6"
    then have "(i1 divINT-1K5 i2)*XCMPLX-0K3 i2 +XCMPLX-0K2 (i1 modINT-1K6 i2) =HIDDENR1 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 +XCMPLX-0K2 (i1 -XCMPLX-0K6 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2)"
      using int_1_def_10 sorry
    also have "... = i1"
       sorry
    finally have "(i1 divINT-1K5 i2)*XCMPLX-0K3 i2 +XCMPLX-0K2 (i1 modINT-1K6 i2) =HIDDENR1 i1"
       sorry
    thus "i1 =HIDDENR1 (i1 divINT-1K5 i2)*XCMPLX-0K3 i2 +XCMPLX-0K2 (i1 modINT-1K6 i2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_60:
" for m be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds (m *XCMPLX-0K3 j,0NUMBERSK6)are-congruent-modINT-1R3 m"
   sorry

mtheorem int_1_th_61:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds i >=XXREAL-0R2 0NUMBERSK6 & j >=XXREAL-0R2 0NUMBERSK6 implies i divINT-1K5 j >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds i >=XXREAL-0R2 0NUMBERSK6 & j >=XXREAL-0R2 0NUMBERSK6 implies i divINT-1K5 j >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix j assume [ty]: "j be IntegerINT-1M1"
    assume A1: "i >=XXREAL-0R2 0NUMBERSK6"
      and A2: "j >=XXREAL-0R2 0NUMBERSK6"
    have A3: "i /XCMPLX-0K7 j -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 i /XCMPLX-0K7 j /]"
      using int_1_def_6 sorry
    have "i /XCMPLX-0K7 j -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 A2 xreal_1_th_9 sorry
    then have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 i /XCMPLX-0K7 j /]"
      using A3 xxreal_0_th_2 sorry
    thus "i divINT-1K5 j >=XXREAL-0R2 0NUMBERSK6"
      using int_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_62:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies ( for a be IntegerINT-1M1 holds a modINT-1K6 n =HIDDENR1 0NUMBERSK6 iff n dividesINT-1R1 a)"
proof-
  have " for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies ( for a be IntegerINT-1M1 holds  not (a modINT-1K6 n =HIDDENR1 0NUMBERSK6 &  not n dividesINT-1R1 a) &  not (n dividesINT-1R1 a &  not a modINT-1K6 n =HIDDENR1 0NUMBERSK6))"
  proof(rule ballI,rule impI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
    fix a assume [ty]: "a be IntegerINT-1M1"
    have A2: "n dividesINT-1R1 a implies a modINT-1K6 n =HIDDENR1 0NUMBERSK6"
    proof(rule impI)
      have A3: "a modINT-1K6 n =HIDDENR1 a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n"
        using A1 int_1_def_10 sorry
      also have "... = a -XCMPLX-0K6 ([\\INT-1K2 a /XCMPLX-0K7 n /])*XCMPLX-0K3 n"
         sorry
      finally have "a modINT-1K6 n =HIDDENR1 a -XCMPLX-0K6 ([\\INT-1K2 a /XCMPLX-0K7 n /])*XCMPLX-0K3 n"
         sorry
      assume "n dividesINT-1R1 a"
      then obtain k where
        [ty]:"k be IntegerINT-1M1" and 
        A4: "n *XCMPLX-0K3 k =HIDDENR1 a"
         sorry
      have "-XCMPLX-0K4 n <>HIDDENR2 0NUMBERSK6"
        using A1 sorry
      then have "(-XCMPLX-0K4 n)+XCMPLX-0K2 a <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 a"
        using xreal_1_th_6 sorry
      then have "((-XCMPLX-0K4 n)+XCMPLX-0K2 a)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5 <XXREAL-0R3 (n *XCMPLX-0K3 k)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5"
        using A1 A4 xreal_1_th_68 sorry
      then have "(-XCMPLX-0K4 n)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5 +XCMPLX-0K2 a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 <XXREAL-0R3 (n *XCMPLX-0K3 k)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5"
         sorry
      then have "(-XCMPLX-0K4 n)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5 +XCMPLX-0K2 a /XCMPLX-0K7 n <XXREAL-0R3 (n *XCMPLX-0K3 n \<inverse>XCMPLX-0K5)*XCMPLX-0K3 k"
        using xcmplx_0_def_9 sorry
      then have "(-XCMPLX-0K4 n)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5 +XCMPLX-0K2 a /XCMPLX-0K7 n <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 k"
        using A1 xcmplx_0_def_7 sorry
      then have "(-XCMPLX-0K4 n *XCMPLX-0K3 n \<inverse>XCMPLX-0K5)+XCMPLX-0K2 a /XCMPLX-0K7 n <XXREAL-0R3 k"
         sorry
      then have "(-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 a /XCMPLX-0K7 n <XXREAL-0R3 k"
        using A1 xcmplx_0_def_7 sorry
      then have A5: "a /XCMPLX-0K7 n -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 k"
         sorry
      have "k <=XXREAL-0R1 a /XCMPLX-0K7 n"
      proof-
        have "k >XXREAL-0R4 a /XCMPLX-0K7 n implies  not  True "
        proof(rule impI)
          assume "k >XXREAL-0R4 a /XCMPLX-0K7 n"
          then have "k *XCMPLX-0K3 n >XXREAL-0R4 (a /XCMPLX-0K7 n)*XCMPLX-0K3 n"
            using A1 xreal_1_th_68 sorry
          then have "k *XCMPLX-0K3 n >XXREAL-0R4 (a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5)*XCMPLX-0K3 n"
            using xcmplx_0_def_9 sorry
          then have "k *XCMPLX-0K3 n >XXREAL-0R4 a *XCMPLX-0K3 (n \<inverse>XCMPLX-0K5 *XCMPLX-0K3 n)"
             sorry
          then have "n *XCMPLX-0K3 k >XXREAL-0R4 a *XCMPLX-0K3 \<one>\<^sub>M"
            using A1 xcmplx_0_def_7 sorry
          thus " not  True "
            using A4 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then have "[\\INT-1K2 a /XCMPLX-0K7 n /] =HIDDENR1 k"
        using A5 int_1_def_6 sorry
      thus "a modINT-1K6 n =HIDDENR1 0NUMBERSK6"
        using A4 A3 sorry
    qed
    have "a modINT-1K6 n =HIDDENR1 0NUMBERSK6 implies n dividesINT-1R1 a"
    proof(rule impI)
      assume "a modINT-1K6 n =HIDDENR1 0NUMBERSK6"
      then have "0NUMBERSK6 =XBOOLE-0R4 a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n"
        using A1 int_1_def_10 sorry
      thus "n dividesINT-1R1 a"
         sorry
    qed
    thus " not (a modINT-1K6 n =HIDDENR1 0NUMBERSK6 &  not n dividesINT-1R1 a) &  not (n dividesINT-1R1 a &  not a modINT-1K6 n =HIDDENR1 0NUMBERSK6)"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve r, s for "RealXREAL-0M1"
mtheorem int_1_th_63:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not r /XCMPLX-0K7 s be IntegerINT-1M1 implies -XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 [\\INT-1K2 (-XCMPLX-0K4 r)/XCMPLX-0K7 s /] +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  not r /XCMPLX-0K7 s be IntegerINT-1M1 implies -XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 [\\INT-1K2 (-XCMPLX-0K4 r)/XCMPLX-0K7 s /] +XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    have "r /XCMPLX-0K7 s -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r /XCMPLX-0K7 s /]"
      using int_1_def_6 sorry
    then have "-XCMPLX-0K4 (r /XCMPLX-0K7 s -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 -XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /]"
      using xreal_1_th_24 sorry
    then have "(-XCMPLX-0K4 r /XCMPLX-0K7 s)+XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 -XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /]"
       sorry
    then have "-XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /] <=XXREAL-0R1 (-XCMPLX-0K4 r)/XCMPLX-0K7 s +XCMPLX-0K2 \<one>\<^sub>M"
      using xcmplx_1_th_187 sorry
    then have A1: "(-XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /])-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 ((-XCMPLX-0K4 r)/XCMPLX-0K7 s +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    assume " not r /XCMPLX-0K7 s be IntegerINT-1M1"
    then have "[\\INT-1K2 r /XCMPLX-0K7 s /] <XXREAL-0R3 r /XCMPLX-0K7 s"
      using int_1_th_26 sorry
    then have "-XCMPLX-0K4 r /XCMPLX-0K7 s <XXREAL-0R3 -XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /]"
      using xreal_1_th_24 sorry
    then have "(-XCMPLX-0K4 r /XCMPLX-0K7 s)-XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (-XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /])-XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then have "(-XCMPLX-0K4 r)/XCMPLX-0K7 s -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (-XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /])-XCMPLX-0K6 \<one>\<^sub>M"
      using xcmplx_1_th_187 sorry
    then have "((-XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /])-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 [\\INT-1K2 (-XCMPLX-0K4 r)/XCMPLX-0K7 s /] +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 int_1_def_6 sorry
    thus "-XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 [\\INT-1K2 (-XCMPLX-0K4 r)/XCMPLX-0K7 s /] +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_64:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r /XCMPLX-0K7 s be IntegerINT-1M1 implies -XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 [\\INT-1K2 (-XCMPLX-0K4 r)/XCMPLX-0K7 s /]"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r /XCMPLX-0K7 s be IntegerINT-1M1 implies -XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 [\\INT-1K2 (-XCMPLX-0K4 r)/XCMPLX-0K7 s /]"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume "r /XCMPLX-0K7 s be IntegerINT-1M1"
    then have A1: "[\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 r /XCMPLX-0K7 s"
      using int_1_th_25 sorry
    have A2: "-XCMPLX-0K4 r /XCMPLX-0K7 s =HIDDENR1 (-XCMPLX-0K4 r)/XCMPLX-0K7 s"
      using xcmplx_1_th_187 sorry
    then have "(-XCMPLX-0K4 r)/XCMPLX-0K7 s -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (-XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /])-XCMPLX-0K6 0NUMBERSK6"
      using A1 xreal_1_th_15 sorry
    thus "-XCMPLX-0K4 [\\INT-1K2 r /XCMPLX-0K7 s /] =HIDDENR1 [\\INT-1K2 (-XCMPLX-0K4 r)/XCMPLX-0K7 s /]"
      using A1 A2 int_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_65:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds r <=XXREAL-0R1 i implies [/INT-1K3 r\\] <=XXREAL-0R1 i"
proof-
  have " for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds r <=XXREAL-0R1 i implies [/INT-1K3 r\\] <=XXREAL-0R1 i"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "r <=XXREAL-0R1 i"
    then have A1: "r +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 i +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    have "[/INT-1K3 r\\] <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      using int_1_def_7 sorry
    then have "[/INT-1K3 r\\] <XXREAL-0R3 i +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
    then have "[/INT-1K3 r\\] <=XXREAL-0R1 (i +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using int_1_th_52 sorry
    thus "[/INT-1K3 r\\] <=XXREAL-0R1 i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem int_1_sch_7:
  fixes Mf0 Nf0 Pp1 
  assumes
[ty]: "Mf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty]: "Nf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
   A1: "Pp1(Mf0)" and
   A2: " for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 j & j <XXREAL-0R3 Nf0 implies (Pp1(j) implies Pp1(j +NAT-1K1 \<one>\<^sub>M))"
  shows " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 Nf0 implies Pp1(i)"
  proof-
    have " not ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 Nf0 implies Pp1(i)) implies  not  True "
    proof(rule impI)
      let ?Q = "\<lambda>Lamb1. (Mf0 <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 Nf0) &  not Pp1(Lamb1)"
      assume " not ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 Nf0 implies Pp1(i))"
      then have A3: " ex i be NatNAT-1M1 st ?Q(i)"
         sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A4: "?Q(k) & ( for k9 be NatNAT-1M1 holds ?Q(k9) implies k <=XXREAL-0R1 k9)"
        using nat_1_sch_5 A3 sorry
      show " not  True "
      proof-
        have cases: "k =XBOOLE-0R4 Mf0 or k <>HIDDENR2 Mf0"
           sorry
        have case1: "k =XBOOLE-0R4 Mf0 implies  not  True "
        proof(rule impI)
          assume "k =XBOOLE-0R4 Mf0"
          thus " not  True "
            using A1 A4 sorry
        qed
        have case2: "k <>HIDDENR2 Mf0 implies  not  True "
        proof(rule impI)
          assume "k <>HIDDENR2 Mf0"
          then have "Mf0 <XXREAL-0R3 k"
            using A4 xxreal_0_th_1 sorry
          then have "Mf0 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
            using nat_1_th_13 sorry
          then have A5: "(Mf0 +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 k -XCMPLX-0K6 \<one>\<^sub>M"
            using xreal_1_th_9 sorry
          then obtain k9 where 
            [ty]:"k9 be ElementSUBSET-1M1-of NATNUMBERSK1" and k9Def:"k9 = k -XCMPLX-0K6 \<one>\<^sub>M"
            using int_1_th_3 sorry
          have A6: "k9 <>HIDDENR2 k9 +NAT-1K1 \<one>\<^sub>M"
             sorry
          have "k9 <=XXREAL-0R1 k9 +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          then have A7: "k9 <XXREAL-0R3 k"
            using A6 xxreal_0_th_1 sorry
          then have A8: "k9 <XXREAL-0R3 Nf0"
            using A4 xxreal_0_th_2 sorry
          have A9: "(k -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 k +NAT-1K1 0NUMBERSK6"
             sorry
          have " not ?Q(k9)"
            using A4 A7 sorry
          thus " not  True "
            using A2 A4 A5 A9 A8 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed

theorem int_1_sch_8:
  fixes Mf0 Nf0 Pp1 
  assumes
[ty]: "Mf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty]: "Nf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
   A1: "Pp1(Mf0)" and
   A2: " for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 j & j <XXREAL-0R3 Nf0 implies (( for j9 be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 j9 & j9 <=XXREAL-0R1 j implies Pp1(j9)) implies Pp1(j +NAT-1K1 \<one>\<^sub>M))"
  shows " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 Nf0 implies Pp1(i)"
  proof-
    have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ((Mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 Nf0) &  not Pp1(i))"
    proof-
      let ?Q = "\<lambda>Lamb1.  for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 j & j <=XXREAL-0R1 Lamb1 implies Pp1(j)"
      have A3: " for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 j & j <XXREAL-0R3 Nf0 implies (?Q(j) implies ?Q(j +NAT-1K1 \<one>\<^sub>M))"
      proof-
        have " for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 j & j <XXREAL-0R3 Nf0 implies (( for jc be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 jc & jc <=XXREAL-0R1 j implies Pp1(jc)) implies ( for jc be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 jc & jc <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies Pp1(jc)))"
        proof(rule ballI,rule impMI ,rule impI,rule impI)
          fix j assume [ty]: "j be ElementSUBSET-1M1-of NATNUMBERSK1"
          assume A4: "Mf0 <=XXREAL-0R1 j"
            and A5: "j <XXREAL-0R3 Nf0"
          assume A6: "?Q(j)"
          show " for jc be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 jc & jc <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies Pp1(jc)"
          proof-
            have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies Pp1(i)"
            proof(rule ballI,rule impMI ,rule impI)
              fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
              assume A7: "Mf0 <=XXREAL-0R1 i"
                and A8: "i <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M"
              show "Pp1(i)"
              proof-
                have cases: "i =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M or i <>HIDDENR2 j +NAT-1K1 \<one>\<^sub>M"
                   sorry
                have case1: "i =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M implies Pp1(i)"
                proof(rule impI)
                  assume "i =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M"
                  thus "Pp1(i)"
                    using A2 A4 A5 A6 sorry
                qed
                have case2: "i <>HIDDENR2 j +NAT-1K1 \<one>\<^sub>M implies Pp1(i)"
                proof(rule impI)
                  assume "i <>HIDDENR2 j +NAT-1K1 \<one>\<^sub>M"
                  then have "i <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M"
                    using A8 xxreal_0_th_1 sorry
                  then have "i <=XXREAL-0R1 j"
                    using nat_1_th_13 sorry
                  thus "Pp1(i)"
                    using A6 A7 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A9: "?Q(Mf0)"
        using A1 xxreal_0_th_1 sorry
      have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds Mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 Nf0 implies ?Q(i)"
        using int_1_sch_7 A9 A3 sorry
      thus " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ((Mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 Nf0) &  not Pp1(i))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

reserve i for "IntegerINT-1M1"
reserve a, b, r, s for "RealXREAL-0M1"
mtheorem int_1_th_66:
" for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds fracINT-1K4 (r +XCMPLX-0K2 i) =XBOOLE-0R4 fracINT-1K4 r"
proof-
  have " for i be IntegerINT-1M1 holds  for r be RealXREAL-0M1 holds fracINT-1K4 (r +XCMPLX-0K2 i) =HIDDENR1 fracINT-1K4 r"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "fracINT-1K4 (r +XCMPLX-0K2 i) =HIDDENR1 (r +XCMPLX-0K2 i)-XCMPLX-0K6 [\\INT-1K2 r +XCMPLX-0K2 i /]"
       sorry
    also have "... = (r +XCMPLX-0K2 i)-XCMPLX-0K6 ([\\INT-1K2 r/] +XCMPLX-0K2 i)"
      using int_1_th_28 sorry
    also have "... = ((r -XCMPLX-0K6 [\\INT-1K2 r/])+XCMPLX-0K2 i)-XCMPLX-0K6 i"
       sorry
    also have "... = fracINT-1K4 r"
       sorry
    finally show "fracINT-1K4 (r +XCMPLX-0K2 i) =HIDDENR1 fracINT-1K4 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_67:
" for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds r <=XXREAL-0R1 a & a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies [\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/]"
proof-
  have " for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds r <=XXREAL-0R1 a implies (a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies [\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/])"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 a"
    assume "a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
    then have A2: "a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ([\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    have "[\\INT-1K2 r/] <=XXREAL-0R1 r"
      using int_1_def_6 sorry
    then have "[\\INT-1K2 r/] <=XXREAL-0R1 a"
      using A1 xxreal_0_th_2 sorry
    thus "[\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/]"
      using A2 int_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_68:
" for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds r <=XXREAL-0R1 a & a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies fracINT-1K4 r <=XXREAL-0R1 fracINT-1K4 a"
proof-
  have " for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds r <=XXREAL-0R1 a implies (a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies fracINT-1K4 r <=XXREAL-0R1 fracINT-1K4 a)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 a"
    assume "a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
    then have "[\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/]"
      using A1 int_1_th_67 sorry
    thus "fracINT-1K4 r <=XXREAL-0R1 fracINT-1K4 a"
      using A1 xreal_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_69:
" for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds r <XXREAL-0R3 a & a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies fracINT-1K4 r <XXREAL-0R3 fracINT-1K4 a"
proof-
  have " for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds r <XXREAL-0R3 a implies (a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies  not fracINT-1K4 r <XXREAL-0R3 fracINT-1K4 a)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r <XXREAL-0R3 a"
    assume "a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
    then have "[\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/]"
      using A1 int_1_th_67 sorry
    thus " not fracINT-1K4 r <XXREAL-0R3 fracINT-1K4 a"
      using A1 xreal_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_70:
" for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & a <=XXREAL-0R1 r +XCMPLX-0K2 \<one>\<^sub>M implies [\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies (a <=XXREAL-0R1 r +XCMPLX-0K2 \<one>\<^sub>M implies [\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
    assume "a <=XXREAL-0R1 r +XCMPLX-0K2 \<one>\<^sub>M"
    then have "a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (r +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then have "a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
      using int_1_th_29 xxreal_0_th_2 sorry
    thus "[\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 int_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_71:
" for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & a <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M implies fracINT-1K4 a <XXREAL-0R3 fracINT-1K4 r"
proof-
  have " for a be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies (a <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M implies  not fracINT-1K4 a <XXREAL-0R3 fracINT-1K4 r)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
    assume A2: "a <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
    then have "a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r"
      using xreal_1_th_19 sorry
    then have A3: "fracINT-1K4 a =XBOOLE-0R4 a -XCMPLX-0K6 [\\INT-1K2 a/] & (a -XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 [\\INT-1K2 r/] <XXREAL-0R3 r -XCMPLX-0K6 [\\INT-1K2 r/]"
      using xreal_1_th_14 sorry
    have "[\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 A2 int_1_th_70 sorry
    thus " not fracINT-1K4 a <XXREAL-0R3 fracINT-1K4 r"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_th_72:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (((r <=XXREAL-0R1 a & a <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M) & r <=XXREAL-0R1 b) & b <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M) & fracINT-1K4 a =XBOOLE-0R4 fracINT-1K4 b implies a =HIDDENR1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds r <=XXREAL-0R1 a & (a <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M & (r <=XXREAL-0R1 b & (b <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M & fracINT-1K4 a =XBOOLE-0R4 fracINT-1K4 b))) implies a =HIDDENR1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r <=XXREAL-0R1 a"
      and A2: "a <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      and A3: "r <=XXREAL-0R1 b"
      and A4: "b <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
      and A5: "fracINT-1K4 a =XBOOLE-0R4 fracINT-1K4 b"
    have A6: "[\\INT-1K2 r/] <=XXREAL-0R1 r"
      using int_1_def_6 sorry
    then have A7: "[\\INT-1K2 r/] <=XXREAL-0R1 a"
      using A1 xxreal_0_th_2 sorry
    have A8: "[\\INT-1K2 r/] <=XXREAL-0R1 b"
      using A3 A6 xxreal_0_th_2 sorry
    show "a =HIDDENR1 b"
    proof-
      have cases: "((a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M or a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M) or a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M) or a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      have case1: "a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies a =HIDDENR1 b"
      proof(rule impI)
        assume A9: "a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
        then have "fracINT-1K4 a >=XXREAL-0R2 fracINT-1K4 r"
          using A1 int_1_th_68 sorry
        thus "a =HIDDENR1 b"
          using A4 A5 A9 int_1_th_71 sorry
      qed
      have case2: "a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies a =HIDDENR1 b"
      proof(rule impI)
        assume A10: "a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
        then have "fracINT-1K4 a <XXREAL-0R3 fracINT-1K4 r"
          using A2 int_1_th_71 sorry
        thus "a =HIDDENR1 b"
          using A3 A5 A10 int_1_th_68 sorry
      qed
      have case3: "a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies a =HIDDENR1 b"
      proof(rule impI)
        assume A11: "a <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b <XXREAL-0R3 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
        then have "b -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ([\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        then have A12: "[\\INT-1K2 b/] =HIDDENR1 [\\INT-1K2 r/]"
          using A8 int_1_def_6 sorry
        have "a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ([\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A11 xreal_1_th_9 sorry
        then have "[\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/]"
          using A7 int_1_def_6 sorry
        thus "a =HIDDENR1 b"
          using A5 A12 sorry
      qed
      have case4: "a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M implies a =HIDDENR1 b"
      proof(rule impI)
        assume "a >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & b >=XXREAL-0R2 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
        then have "[\\INT-1K2 a/] =HIDDENR1 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M & [\\INT-1K2 b/] =HIDDENR1 [\\INT-1K2 r/] +XCMPLX-0K2 \<one>\<^sub>M"
          using A2 A4 int_1_th_70 sorry
        thus "a =HIDDENR1 b"
          using A5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_1_reduce_1:
  mlet "i be IntegerINT-1M1"
"reduce InSUBSET-1K10(i,INTINT-1K1) to i"
proof
(*reducibility*)
  show "InSUBSET-1K10(i,INTINT-1K1) =HIDDENR1 i"
    using int_1_def_2 subset_1_def_8 sorry
qed "sorry"

mdef int_1_def_11 ("dim-likeINT-1V2" 70 ) where
"attr dim-likeINT-1V2 for NumberORDINAL1M1 means
  (\<lambda>x. x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M or x be naturalORDINAL1V7)"..

mtheorem int_1_cl_11:
"cluster naturalORDINAL1V7 also-is dim-likeINT-1V2 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be naturalORDINAL1V7 implies it be dim-likeINT-1V2"
     sorry
qed "sorry"

mtheorem int_1_cl_12:
"cluster dim-likeINT-1V2 also-is integerINT-1V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be dim-likeINT-1V2 implies it be integerINT-1V1"
     sorry
qed "sorry"

mtheorem int_1_cl_13:
"cluster -XCMPLX-0K4 \<one>\<^sub>M as-term-is dim-likeINT-1V2 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies it be dim-likeINT-1V2"
     sorry
qed "sorry"

mtheorem int_1_cl_14:
"cluster dim-likeINT-1V2 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be dim-likeINT-1V2"
  proof-
    have " ex tVar11 be setHIDDENM2 st tVar11 be dim-likeINT-1V2"
    proof-
      obtain x where 
        [ty]:"x be setHIDDENM2" and xDef:"x = -XCMPLX-0K4 \<one>\<^sub>M"
        using tarski_th_1 sorry
      show " ex tVar11 be setHIDDENM2 st tVar11 be dim-likeINT-1V2"
      proof(rule bexI[of _ "x"])
        show "x be dim-likeINT-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem int_1_cl_15:
  mlet "d be dim-likeINT-1V2\<bar>objectHIDDENM1"
"cluster d +XCMPLX-0K2 \<one>\<^sub>M as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "d +XCMPLX-0K2 \<one>\<^sub>M be naturalORDINAL1V7"
  proof-
    show "d +XCMPLX-0K2 \<one>\<^sub>M be naturalORDINAL1V7"
    proof-
      have cases: "d =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M or d be naturalORDINAL1V7"
        using int_1_def_11 sorry
      have case1: "d =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies d +XCMPLX-0K2 \<one>\<^sub>M be naturalORDINAL1V7"
      proof(rule impI)
        assume "d =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
        then have "d +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
           sorry
        thus "d +XCMPLX-0K2 \<one>\<^sub>M be naturalORDINAL1V7"
           sorry
      qed
      have case2: "d be naturalORDINAL1V7 implies d +XCMPLX-0K2 \<one>\<^sub>M be naturalORDINAL1V7"
      proof(rule impI)
        assume "d be naturalORDINAL1V7"
        thus "d +XCMPLX-0K2 \<one>\<^sub>M be naturalORDINAL1V7"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem int_1_cl_16:
  mlet "k be dim-likeINT-1V2\<bar>objectHIDDENM1", "n be  non zeroORDINAL1V8\<bar>naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster k +XCMPLX-0K2 n as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "k +XCMPLX-0K2 n be naturalORDINAL1V7"
  proof-
    show "k +XCMPLX-0K2 n be naturalORDINAL1V7"
    proof-
      have cases: "k =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M or k be naturalORDINAL1V7"
        using int_1_def_11 sorry
      have case1: "k =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies k +XCMPLX-0K2 n be naturalORDINAL1V7"
      proof(rule impI)
        assume A1: "k =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
        obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A2: "n =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_6 sorry
        have "k +XCMPLX-0K2 n =XBOOLE-0R4 i"
          using A2 A1 sorry
        thus "k +XCMPLX-0K2 n be naturalORDINAL1V7"
           sorry
      qed
      have case2: "k be naturalORDINAL1V7 implies k +XCMPLX-0K2 n be naturalORDINAL1V7"
      proof(rule impI)
        assume "k be naturalORDINAL1V7"
        thus "k +XCMPLX-0K2 n be naturalORDINAL1V7"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem int_1_th_73:
" for i be IntegerINT-1M1 holds 0NUMBERSK6 =HIDDENR1 0NUMBERSK6 modINT-1K6 i"
proof(rule ballI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  show "0NUMBERSK6 =HIDDENR1 0NUMBERSK6 modINT-1K6 i"
  proof-
    have cases: "i =HIDDENR1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "i =HIDDENR1 0NUMBERSK6 implies 0NUMBERSK6 =HIDDENR1 0NUMBERSK6 modINT-1K6 i"
    proof(rule impI)
      assume "i =HIDDENR1 0NUMBERSK6"
      thus "0NUMBERSK6 =HIDDENR1 0NUMBERSK6 modINT-1K6 i"
        using int_1_def_10 sorry
    qed
    have case2: "i <>HIDDENR2 0NUMBERSK6 implies 0NUMBERSK6 =HIDDENR1 0NUMBERSK6 modINT-1K6 i"
    proof(rule impI)
      assume A1: "i <>HIDDENR2 0NUMBERSK6"
      have "0NUMBERSK6 divINT-1K5 i =HIDDENR1 0NUMBERSK6"
        using int_1_th_25 sorry
      then have "0NUMBERSK6 modINT-1K6 i =HIDDENR1 0NUMBERSK6 -XCMPLX-0K6 i *XCMPLX-0K3 (0NUMBERSK6)"
        using A1 int_1_def_10 sorry
      thus "0NUMBERSK6 =HIDDENR1 0NUMBERSK6 modINT-1K6 i"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

end
