theory int_2
  imports absvalue card_1
   "../mizar_extension/E_number"
begin
(*begin*)
abbreviation(input) INT_2K1(" |.INT-2K1  _ .|" [0]164) where
  " |.INT-2K1 a.| \<equiv>  |.COMPLEX1K10 a.|"

mtheorem int_2_add_1:
  mlet "a be IntegerINT-1M1"
"cluster  |.COMPLEX1K10 a.| as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show " |.COMPLEX1K10 a.| be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    show " |.COMPLEX1K10 a.| be ElementSUBSET-1M1-of NATNUMBERSK1"
    proof-
      have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies  |.COMPLEX1K10 a.| be ElementSUBSET-1M1-of NATNUMBERSK1"
      proof(rule impI)
        assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
        then have " |.COMPLEX1K10 a.| =COMPLEX1R1 a"
          using absvalue_def_1 sorry
        thus " |.COMPLEX1K10 a.| be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A1 int_1_th_3 sorry
      qed
      have case2: "a <XXREAL-0R3 0NUMBERSK6 implies  |.COMPLEX1K10 a.| be ElementSUBSET-1M1-of NATNUMBERSK1"
      proof(rule impI)
        assume "a <XXREAL-0R3 0NUMBERSK6"
        then have " |.COMPLEX1K10 a.| =COMPLEX1R1 -XCMPLX-0K4 a & -XCMPLX-0K4 a >XXREAL-0R4 0NUMBERSK6"
          using absvalue_def_1 xreal_1_th_58 sorry
        thus " |.COMPLEX1K10 a.| be ElementSUBSET-1M1-of NATNUMBERSK1"
          using int_1_th_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

reserve a, b, c for "IntegerINT-1M1"
mtheorem int_2_th_1:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 b & a dividesINT-1R1 b +XCMPLX-0K2 c implies a dividesINT-1R1 c"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds  not ((a dividesINT-1R1 b & a dividesINT-1R1 b +XCMPLX-0K2 c) &  not a dividesINT-1R1 c)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    fix c assume [ty]: "c be IntegerINT-1M1"
    have "( ex u be IntegerINT-1M1 st b =COMPLEX1R1 a *XCMPLX-0K3 u) implies  not (a dividesINT-1R1 b +XCMPLX-0K2 c &  not a dividesINT-1R1 c)"
    proof(rule impI)
      assume Given: " ex u be IntegerINT-1M1 st b =COMPLEX1R1 a *XCMPLX-0K3 u"
      then obtain u where
        [ty]:"u be IntegerINT-1M1" and 
        A1: "b =COMPLEX1R1 a *XCMPLX-0K3 u"
         sorry
      have "( ex t be IntegerINT-1M1 st b +XCMPLX-0K2 c =COMPLEX1R1 a *XCMPLX-0K3 t) implies a dividesINT-1R1 c"
      proof(rule impI)
        assume Given: " ex t be IntegerINT-1M1 st b +XCMPLX-0K2 c =COMPLEX1R1 a *XCMPLX-0K3 t"
        then obtain t where
          [ty]:"t be IntegerINT-1M1" and 
          A2: "b +XCMPLX-0K2 c =COMPLEX1R1 a *XCMPLX-0K3 t"
           sorry
        have "c =COMPLEX1R1 a *XCMPLX-0K3 (t -XCMPLX-0K6 u)"
          using A1 A2 sorry
        thus "a dividesINT-1R1 c"
           sorry
      qed
      thus " not (a dividesINT-1R1 b +XCMPLX-0K2 c &  not a dividesINT-1R1 c)"
        using int_1_def_3 sorry
    qed
    thus " not ((a dividesINT-1R1 b & a dividesINT-1R1 b +XCMPLX-0K2 c) &  not a dividesINT-1R1 c)"
      using int_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_2:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 b implies a dividesINT-1R1 b *XCMPLX-0K3 c"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 b implies a dividesINT-1R1 b *XCMPLX-0K3 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    fix c assume [ty]: "c be IntegerINT-1M1"
    assume "a dividesINT-1R1 b"
    then obtain l where
      [ty]:"l be IntegerINT-1M1" and 
      A1: "b =COMPLEX1R1 a *XCMPLX-0K3 l"
       sorry
    have "(a *XCMPLX-0K3 l)*XCMPLX-0K3 c =COMPLEX1R1 a *XCMPLX-0K3 (l *XCMPLX-0K3 c)"
       sorry
    thus "a dividesINT-1R1 b *XCMPLX-0K3 c"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_3:
" for a be IntegerINT-1M1 holds 0NUMBERSK6 dividesINT-1R1 a iff a =COMPLEX1R1 0NUMBERSK6"
   sorry

mlemma int_2_lm_1:
" for a be IntegerINT-1M1 holds a dividesINT-1R1 -XCMPLX-0K4 a & -XCMPLX-0K4 a dividesINT-1R1 a"
proof-
  have " for a be IntegerINT-1M1 holds a dividesINT-1R1 -XCMPLX-0K4 a & -XCMPLX-0K4 a dividesINT-1R1 a"
  proof(rule ballI,rule conjMI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    have "-XCMPLX-0K4 a =COMPLEX1R1 a *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
       sorry
    thus "a dividesINT-1R1 -XCMPLX-0K4 a"
       sorry
    have "a =COMPLEX1R1 (-XCMPLX-0K4 a)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
       sorry
    thus "-XCMPLX-0K4 a dividesINT-1R1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_2_lm_2:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 b & b dividesINT-1R1 c implies a dividesINT-1R1 c"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 b & b dividesINT-1R1 c implies a dividesINT-1R1 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    fix c assume [ty]: "c be IntegerINT-1M1"
    assume A1: "a dividesINT-1R1 b"
      and A2: "b dividesINT-1R1 c"
    obtain k where
      [ty]:"k be IntegerINT-1M1" and 
      A3: "b =COMPLEX1R1 a *XCMPLX-0K3 k"
      using A1 sorry
    obtain l where
      [ty]:"l be IntegerINT-1M1" and 
      A4: "c =COMPLEX1R1 b *XCMPLX-0K3 l"
      using A2 sorry
    have "c =COMPLEX1R1 a *XCMPLX-0K3 (k *XCMPLX-0K3 l)"
      using A3 A4 sorry
    thus "a dividesINT-1R1 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_2_lm_3:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a dividesINT-1R1 b iff a dividesINT-1R1 -XCMPLX-0K4 b"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (a dividesINT-1R1 b implies a dividesINT-1R1 -XCMPLX-0K4 b) & (a dividesINT-1R1 -XCMPLX-0K4 b implies a dividesINT-1R1 b)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    show "a dividesINT-1R1 b implies a dividesINT-1R1 -XCMPLX-0K4 b"
    proof(rule impI)
      assume A1: "a dividesINT-1R1 b"
      have "b dividesINT-1R1 -XCMPLX-0K4 b"
        using int_2_lm_1 sorry
      thus "a dividesINT-1R1 -XCMPLX-0K4 b"
        using A1 int_2_lm_2 sorry
    qed
    assume A2: "a dividesINT-1R1 -XCMPLX-0K4 b"
    have "-XCMPLX-0K4 b dividesINT-1R1 b"
      using int_2_lm_1 sorry
    thus "a dividesINT-1R1 b"
      using A2 int_2_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_2_lm_4:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a dividesINT-1R1 b iff -XCMPLX-0K4 a dividesINT-1R1 b"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (a dividesINT-1R1 b implies -XCMPLX-0K4 a dividesINT-1R1 b) & (-XCMPLX-0K4 a dividesINT-1R1 b implies a dividesINT-1R1 b)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    show "a dividesINT-1R1 b implies -XCMPLX-0K4 a dividesINT-1R1 b"
    proof(rule impI)
      assume A1: "a dividesINT-1R1 b"
      have "-XCMPLX-0K4 a dividesINT-1R1 a"
        using int_2_lm_1 sorry
      thus "-XCMPLX-0K4 a dividesINT-1R1 b"
        using A1 int_2_lm_2 sorry
    qed
    assume A2: "-XCMPLX-0K4 a dividesINT-1R1 b"
    have "a dividesINT-1R1 -XCMPLX-0K4 a"
      using int_2_lm_1 sorry
    thus "a dividesINT-1R1 b"
      using A2 int_2_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_2_lm_5:
" for a be IntegerINT-1M1 holds (a dividesINT-1R1 0NUMBERSK6 & \<one>\<^sub>M dividesINT-1R1 a) & -XCMPLX-0K4 \<one>\<^sub>M dividesINT-1R1 a"
proof-
  have " for a be IntegerINT-1M1 holds a dividesINT-1R1 0NUMBERSK6 & (\<one>\<^sub>M dividesINT-1R1 a & -XCMPLX-0K4 \<one>\<^sub>M dividesINT-1R1 a)"
  proof(rule ballI,rule conjMI,rule conjMI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    have "0NUMBERSK6 =COMPLEX1R1 a *XCMPLX-0K3 (0NUMBERSK6)"
       sorry
    thus "a dividesINT-1R1 0NUMBERSK6"
       sorry
    have "a =COMPLEX1R1 \<one>\<^sub>M *XCMPLX-0K3 a"
       sorry
    thus "\<one>\<^sub>M dividesINT-1R1 a"
       sorry
    have "a =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 a)"
       sorry
    thus "-XCMPLX-0K4 \<one>\<^sub>M dividesINT-1R1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_2_lm_6:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 b & a dividesINT-1R1 c implies a dividesINT-1R1 b modINT-1K6 c"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 b & a dividesINT-1R1 c implies a dividesINT-1R1 b modINT-1K6 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    fix c assume [ty]: "c be IntegerINT-1M1"
    assume A1: "a dividesINT-1R1 b"
      and A2: "a dividesINT-1R1 c"
    have A3: "c <>HIDDENR2 0NUMBERSK6 implies a dividesINT-1R1 b modINT-1K6 c"
    proof(rule impI)
      assume "c <>HIDDENR2 0NUMBERSK6"
      then have A4: "b =COMPLEX1R1 c *XCMPLX-0K3 (b divINT-1K5 c) +XCMPLX-0K2 (b modINT-1K6 c)"
        using int_1_th_59 sorry
      have "a dividesINT-1R1 c *XCMPLX-0K3 (b divINT-1K5 c)"
        using A2 int_2_th_2 sorry
      thus "a dividesINT-1R1 b modINT-1K6 c"
        using A1 A4 int_2_th_1 sorry
    qed
    have "c =COMPLEX1R1 0NUMBERSK6 implies a dividesINT-1R1 b modINT-1K6 c"
    proof(rule impI)
      assume "c =COMPLEX1R1 0NUMBERSK6"
      then have "b modINT-1K6 c =COMPLEX1R1 0NUMBERSK6"
        using int_1_def_10 sorry
      thus "a dividesINT-1R1 b modINT-1K6 c"
        using int_2_lm_5 sorry
    qed
    thus "a dividesINT-1R1 b modINT-1K6 c"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve i, j, k, l for "NatNAT-1M1"
mlemma int_2_lm_7:
" for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds k dividesINT-1R1 l iff ( ex t be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 t)"
proof-
  have " for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds (k dividesINT-1R1 l implies ( ex t be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 t)) & (( ex t be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 t) implies k dividesINT-1R1 l)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    show "k dividesINT-1R1 l implies ( ex t be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 t)"
    proof(rule impI)
      assume A1: "k dividesINT-1R1 l"
      show " ex t be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 t"
      proof-
        have " ex tVar1 be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 tVar1"
        proof-
          obtain t where
            [ty]:"t be IntegerINT-1M1" and 
            A2: "l =COMPLEX1R1 k *XCMPLX-0K3 t"
            using A1 sorry
          show " ex tVar1 be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 tVar1"
          proof-
            have cases: "0NUMBERSK6 <XXREAL-0R3 l or l =COMPLEX1R1 0NUMBERSK6"
               sorry
            have case1: "0NUMBERSK6 <XXREAL-0R3 l implies ( ex tVar1 be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 tVar1)"
            proof(rule impI)
              assume "0NUMBERSK6 <XXREAL-0R3 l"
              then have "0NUMBERSK6 <=XXREAL-0R1 t"
                using A2 sorry
              then have 
                [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
                using int_1_th_3 sorry
              show " ex tVar1 be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 tVar1"
              proof(rule bexI[of _ "t"])
                show "l =COMPLEX1R1 k *XCMPLX-0K3 t"
                  using A2 sorry
              qed "sorry"
            qed
            have case2: "l =COMPLEX1R1 0NUMBERSK6 implies ( ex tVar2 be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 tVar2)"
            proof(rule impI)
              assume A3: "l =COMPLEX1R1 0NUMBERSK6"
              show " ex tVar2 be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 tVar2"
              proof(rule bexI[of _ "0NUMBERSK6"])
                show "l =COMPLEX1R1 k *XCMPLX-0K3 (0NUMBERSK6)"
                  using A3 sorry
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " ?thesis "
           sorry
      qed
    qed
    assume " ex t be NatNAT-1M1 st l =COMPLEX1R1 k *XCMPLX-0K3 t"
    thus "k dividesINT-1R1 l"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_2_lm_8:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i dividesINT-1R1 j & j dividesINT-1R1 i implies i =COMPLEX1R1 j"
proof-
  have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i dividesINT-1R1 j implies (j dividesINT-1R1 i implies i =COMPLEX1R1 j)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    assume "i dividesINT-1R1 j"
    then obtain a where
      [ty]:"a be IntegerINT-1M1" and 
      A1: "j =COMPLEX1R1 i *XCMPLX-0K3 a"
       sorry
    assume "j dividesINT-1R1 i"
    then obtain b where
      [ty]:"b be IntegerINT-1M1" and 
      A2: "i =COMPLEX1R1 j *XCMPLX-0K3 b"
       sorry
    have "i <>HIDDENR2 0NUMBERSK6 implies i =COMPLEX1R1 j"
    proof(rule impI)
      have A3: "i >=XXREAL-0R2 0NUMBERSK6"
         sorry
      assume A4: "i <>HIDDENR2 0NUMBERSK6"
      have "\<one>\<^sub>M *XCMPLX-0K3 i =COMPLEX1R1 i *XCMPLX-0K3 (a *XCMPLX-0K3 b)"
        using A1 A2 sorry
      then have "a *XCMPLX-0K3 b =COMPLEX1R1 \<one>\<^sub>M"
        using A4 xcmplx_1_th_5 sorry
      then have "i =COMPLEX1R1 j *XCMPLX-0K3 \<one>\<^sub>M or i =COMPLEX1R1 j *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using A2 int_1_th_9 sorry
      thus "i =COMPLEX1R1 j"
        using A4 A3 sorry
    qed
    thus "i =COMPLEX1R1 j"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef int_2_def_1 (" _ lcmINT-2K2  _ " [132,132]132 ) where
  mlet "a be IntegerINT-1M1", "b be IntegerINT-1M1"
"func a lcmINT-2K2 b \<rightarrow> NatNAT-1M1 means
  \<lambda>it. (a dividesINT-1R1 it & b dividesINT-1R1 it) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies it dividesINT-1R1 m)"
proof-
  (*existence*)
    show " ex it be NatNAT-1M1 st (a dividesINT-1R1 it & b dividesINT-1R1 it) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies it dividesINT-1R1 m)"
    proof-
      have " ex tVar3 be NatNAT-1M1 st (a dividesINT-1R1 tVar3 & b dividesINT-1R1 tVar3) & ( for m be IntegerINT-1M1 holds  not ((a dividesINT-1R1 m & b dividesINT-1R1 m) &  not tVar3 dividesINT-1R1 m))"
      proof-
        show " ex tVar3 be NatNAT-1M1 st (a dividesINT-1R1 tVar3 & b dividesINT-1R1 tVar3) & ( for m be IntegerINT-1M1 holds  not ((a dividesINT-1R1 m & b dividesINT-1R1 m) &  not tVar3 dividesINT-1R1 m))"
        proof-
          have cases: "(a =COMPLEX1R1 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6) or a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
             sorry
          have case1: "a =COMPLEX1R1 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6 implies ( ex tVar3 be NatNAT-1M1 st (a dividesINT-1R1 tVar3 & b dividesINT-1R1 tVar3) & ( for m be IntegerINT-1M1 holds  not ((a dividesINT-1R1 m & b dividesINT-1R1 m) &  not tVar3 dividesINT-1R1 m)))"
          proof(rule impI)
            assume A1: "a =COMPLEX1R1 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6"
            show " ex tVar3 be NatNAT-1M1 st (a dividesINT-1R1 tVar3 & b dividesINT-1R1 tVar3) & ( for m be IntegerINT-1M1 holds  not ((a dividesINT-1R1 m & b dividesINT-1R1 m) &  not tVar3 dividesINT-1R1 m))"
            proof(rule bexI[of _ "0NUMBERSK6"],rule conjMI)
              show "a dividesINT-1R1 0NUMBERSK6 & b dividesINT-1R1 0NUMBERSK6"
                using int_2_lm_5 sorry
              show " for m be IntegerINT-1M1 holds  not ((a dividesINT-1R1 m & b dividesINT-1R1 m) &  not 0NUMBERSK6 dividesINT-1R1 m)"
                using A1 sorry
            qed "sorry"
          qed
          have case2: "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies ( ex tVar4 be NatNAT-1M1 st (a dividesINT-1R1 tVar4 & b dividesINT-1R1 tVar4) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies ( not tVar4 dividesINT-1R1 m implies  False )))"
          proof(rule impI)
            assume A2: "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
            let ?P = "\<lambda>Lamb1. (a dividesINT-1R1 Lamb1 & b dividesINT-1R1 Lamb1) & Lamb1 <>HIDDENR2 0NUMBERSK6"
            have "a *XCMPLX-0K3 b inHIDDENR3 INTINT-1K1"
              using int_1_def_2 sorry
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A3: "a *XCMPLX-0K3 b =COMPLEX1R1 k or a *XCMPLX-0K3 b =COMPLEX1R1 -XCMPLX-0K4 k"
              using int_1_def_1 sorry
            have "b dividesINT-1R1 a *XCMPLX-0K3 b"
               sorry
            then have A4: "b dividesINT-1R1 k"
              using A3 int_2_lm_3 sorry
            have "a dividesINT-1R1 a *XCMPLX-0K3 b"
               sorry
            then have A5: "a dividesINT-1R1 k"
              using A3 int_2_lm_3 sorry
            have "k <>HIDDENR2 0NUMBERSK6"
              using A2 A3 xcmplx_1_th_6 sorry
            then have A6: " ex k be NatNAT-1M1 st ?P(k)"
              using A5 A4 sorry
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A7: "?P(k)"and A8: " for n be NatNAT-1M1 holds ?P(n) implies k <=XXREAL-0R1 n"
              using nat_1_sch_5 A6 sorry
            show " ex tVar4 be NatNAT-1M1 st (a dividesINT-1R1 tVar4 & b dividesINT-1R1 tVar4) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies ( not tVar4 dividesINT-1R1 m implies  False ))"
            proof(rule bexI[of _ "k"],rule conjMI,rule ballI,rule impMI ,rule impI,rule impI)
              show "a dividesINT-1R1 k & b dividesINT-1R1 k"
                using A7 sorry
              fix m assume [ty]: "m be IntegerINT-1M1"
              have "m inHIDDENR3 INTINT-1K1"
                using int_1_def_2 sorry
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A9: "m =COMPLEX1R1 n or m =COMPLEX1R1 -XCMPLX-0K4 n"
                using int_1_def_1 sorry
              assume A10: "a dividesINT-1R1 m"
                and A11: "b dividesINT-1R1 m"
              have "b dividesINT-1R1 n"
                using A9 A11 int_2_lm_3 sorry
              then have A12: "b dividesINT-1R1 n modINT-1K6 k"
                using A7 int_2_lm_6 sorry
              have A13: "k >XXREAL-0R4 0NUMBERSK6"
                using A7 sorry
              have "n modINT-1K6 k inHIDDENR3 NATNUMBERSK1"
                using int_1_th_3 int_1_th_57 sorry
              then obtain i where 
                [ty]:"i be NatNAT-1M1" and iDef:"i = n modINT-1K6 k"
                 sorry
              assume A14: " not k dividesINT-1R1 m"
              have A15: "i =COMPLEX1R1 0NUMBERSK6 implies  False "
              proof(rule impI)
                assume "i =COMPLEX1R1 0NUMBERSK6"
                then have "n -XCMPLX-0K6 (n divINT-1K5 k)*XCMPLX-0K3 k =COMPLEX1R1 0NUMBERSK6"
                  using A7 int_1_def_10 sorry
                then have "k dividesINT-1R1 n"
                   sorry
                thus " False "
                  using A9 A14 int_2_lm_3 sorry
              qed
              have "a dividesINT-1R1 n"
                using A9 A10 int_2_lm_3 sorry
              then have "a dividesINT-1R1 n modINT-1K6 k"
                using A7 int_2_lm_6 sorry
              then have "k dividesINT-1R1 n"
                using A8 A13 A12 A15 int_1_th_58 sorry
              thus " False "
                using A9 A14 int_2_lm_3 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds ((a dividesINT-1R1 it1 & b dividesINT-1R1 it1) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies it1 dividesINT-1R1 m)) & ((a dividesINT-1R1 it2 & b dividesINT-1R1 it2) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies it2 dividesINT-1R1 m)) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT1 be NatNAT-1M1 holds  for IT2 be NatNAT-1M1 holds (((a dividesINT-1R1 IT1 & b dividesINT-1R1 IT1) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies IT1 dividesINT-1R1 m)) & a dividesINT-1R1 IT2) & (b dividesINT-1R1 IT2 & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies IT2 dividesINT-1R1 m)) implies IT1 =HIDDENR1 IT2"
      proof(rule ballI,rule ballI,rule impI)
        fix IT1 assume [ty]: "IT1 be NatNAT-1M1"
        fix IT2 assume [ty]: "IT2 be NatNAT-1M1"
        assume "(((a dividesINT-1R1 IT1 & b dividesINT-1R1 IT1) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies IT1 dividesINT-1R1 m)) & a dividesINT-1R1 IT2) & (b dividesINT-1R1 IT2 & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies IT2 dividesINT-1R1 m))"
        then have "IT1 dividesINT-1R1 IT2 & IT2 dividesINT-1R1 IT1"
           sorry
        thus "IT1 =HIDDENR1 IT2"
          using int_2_lm_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem INT_2K2_commutativity:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a lcmINT-2K2 b =HIDDENR1 b lcmINT-2K2 a"
proof-
  have " for it be NatNAT-1M1 holds  for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds it =HIDDENR1 a lcmINT-2K2 b implies it =HIDDENR1 b lcmINT-2K2 a"
  proof-
    have " for it be NatNAT-1M1 holds  for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (a dividesINT-1R1 it & b dividesINT-1R1 it) & ( for m be IntegerINT-1M1 holds a dividesINT-1R1 m & b dividesINT-1R1 m implies it dividesINT-1R1 m) implies (b dividesINT-1R1 it & a dividesINT-1R1 it) & ( for m be IntegerINT-1M1 holds b dividesINT-1R1 m & a dividesINT-1R1 m implies it dividesINT-1R1 m)"
       sorry
    thus " ?thesis "
      using int_2_def_1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_4:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a =COMPLEX1R1 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6 iff a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  not ( not ( not a =COMPLEX1R1 0NUMBERSK6 &  not b =COMPLEX1R1 0NUMBERSK6) &  not a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6) &  not ((a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6 &  not a =COMPLEX1R1 0NUMBERSK6) &  not b =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    have A1: "b =COMPLEX1R1 0NUMBERSK6 implies a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume "b =COMPLEX1R1 0NUMBERSK6"
      then have "0NUMBERSK6 dividesINT-1R1 a lcmINT-2K2 b"
        using int_2_def_1 sorry
      thus "a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6"
         sorry
    qed
    have A2: "a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6 implies a =COMPLEX1R1 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6"
    proof-
      have "a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6 implies  not ( not a =COMPLEX1R1 0NUMBERSK6 &  not b =COMPLEX1R1 0NUMBERSK6)"
      proof(rule impI)
        have A3: "b dividesINT-1R1 b implies b dividesINT-1R1 b *XCMPLX-0K3 a"
           sorry
        assume A4: "a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6"
        have "a dividesINT-1R1 a implies a dividesINT-1R1 a *XCMPLX-0K3 b"
           sorry
        then have "0NUMBERSK6 dividesINT-1R1 a *XCMPLX-0K3 b"
          using A4 A3 int_2_def_1 sorry
        then have "a *XCMPLX-0K3 b =COMPLEX1R1 0NUMBERSK6"
           sorry
        thus " not ( not a =COMPLEX1R1 0NUMBERSK6 &  not b =COMPLEX1R1 0NUMBERSK6)"
          using xcmplx_1_th_6 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "a =COMPLEX1R1 0NUMBERSK6 implies a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume "a =COMPLEX1R1 0NUMBERSK6"
      then have "0NUMBERSK6 dividesINT-1R1 a lcmINT-2K2 b"
        using int_2_def_1 sorry
      thus "a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6"
         sorry
    qed
    thus " not ( not ( not a =COMPLEX1R1 0NUMBERSK6 &  not b =COMPLEX1R1 0NUMBERSK6) &  not a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6) &  not ((a lcmINT-2K2 b =COMPLEX1R1 0NUMBERSK6 &  not a =COMPLEX1R1 0NUMBERSK6) &  not b =COMPLEX1R1 0NUMBERSK6)"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma int_2_lm_9:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 j & i dividesINT-1R1 j implies i <=XXREAL-0R1 j"
proof-
  have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 j & i dividesINT-1R1 j implies i <=XXREAL-0R1 j"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 j"
      and A2: "i dividesINT-1R1 j"
    obtain l where
      [ty]:"l be NatNAT-1M1" and 
      A3: "j =COMPLEX1R1 i *XCMPLX-0K3 l"
      using A2 int_2_lm_7 sorry
    have "l <>HIDDENR2 0NUMBERSK6"
      using A1 A3 sorry
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: "l =COMPLEX1R1 k +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have "i *XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +XCMPLX-0K2 i *XCMPLX-0K3 k"
       sorry
    thus "i <=XXREAL-0R1 j"
      using A3 A4 nat_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef int_2_def_2 (" _ gcdINT-2K3  _ " [132,132]132 ) where
  mlet "a be IntegerINT-1M1", "b be IntegerINT-1M1"
"func a gcdINT-2K3 b \<rightarrow> NatNAT-1M1 means
  \<lambda>it. (it dividesINT-1R1 a & it dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 it)"
proof-
  (*existence*)
    show " ex it be NatNAT-1M1 st (it dividesINT-1R1 a & it dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 it)"
    proof-
      have " ex tVar5 be NatNAT-1M1 st (tVar5 dividesINT-1R1 a & tVar5 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 tVar5)"
      proof-
        show " ex tVar5 be NatNAT-1M1 st (tVar5 dividesINT-1R1 a & tVar5 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 tVar5)"
        proof-
          have cases: "(a =COMPLEX1R1 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6) or a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
             sorry
          have case1: "a =COMPLEX1R1 0NUMBERSK6 implies ( ex tVar5 be NatNAT-1M1 st (tVar5 dividesINT-1R1 a & tVar5 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 tVar5))"
          proof(rule impI)
            assume A1: "a =COMPLEX1R1 0NUMBERSK6"
            have "b inHIDDENR3 INTINT-1K1"
              using int_1_def_2 sorry
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A2: "b =COMPLEX1R1 k or b =COMPLEX1R1 -XCMPLX-0K4 k"
              using int_1_def_1 sorry
            show " ex tVar5 be NatNAT-1M1 st (tVar5 dividesINT-1R1 a & tVar5 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 tVar5)"
            proof(rule bexI[of _ "k"],rule conjMI,rule ballI,rule impMI ,rule impI)
              show "k dividesINT-1R1 a & k dividesINT-1R1 b"
                using A1 A2 int_2_lm_4 int_2_lm_5 sorry
              fix m assume [ty]: "m be IntegerINT-1M1"
              assume "m dividesINT-1R1 a"
                and A3: "m dividesINT-1R1 b"
              show "m dividesINT-1R1 k"
                using A2 A3 int_2_lm_3 sorry
            qed "sorry"
          qed
          have case2: "b =COMPLEX1R1 0NUMBERSK6 implies ( ex tVar6 be NatNAT-1M1 st (tVar6 dividesINT-1R1 a & tVar6 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 tVar6))"
          proof(rule impI)
            assume A4: "b =COMPLEX1R1 0NUMBERSK6"
            have "a inHIDDENR3 INTINT-1K1"
              using int_1_def_2 sorry
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A5: "a =COMPLEX1R1 k or a =COMPLEX1R1 -XCMPLX-0K4 k"
              using int_1_def_1 sorry
            show " ex tVar6 be NatNAT-1M1 st (tVar6 dividesINT-1R1 a & tVar6 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 tVar6)"
            proof(rule bexI[of _ "k"],rule conjMI,rule ballI,rule impMI ,rule impI)
              show "k dividesINT-1R1 a & k dividesINT-1R1 b"
                using A4 A5 int_2_lm_4 int_2_lm_5 sorry
              fix m assume [ty]: "m be IntegerINT-1M1"
              assume A6: "m dividesINT-1R1 a"
                and "m dividesINT-1R1 b"
              show "m dividesINT-1R1 k"
                using A5 A6 int_2_lm_3 sorry
            qed "sorry"
          qed
          have case3: "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies ( ex tVar7 be NatNAT-1M1 st (tVar7 dividesINT-1R1 a & tVar7 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies ( not m dividesINT-1R1 tVar7 implies  False )))"
          proof(rule impI)
            assume A7: "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
            let ?P = "\<lambda>Lamb1. (Lamb1 dividesINT-1R1 a & Lamb1 dividesINT-1R1 b) & Lamb1 <>HIDDENR2 0NUMBERSK6"
            have A8: "a dividesINT-1R1 a *XCMPLX-0K3 b"
               sorry
            have "a *XCMPLX-0K3 b inHIDDENR3 INTINT-1K1"
              using int_1_def_2 sorry
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A9: "a *XCMPLX-0K3 b =COMPLEX1R1 k or a *XCMPLX-0K3 b =COMPLEX1R1 -XCMPLX-0K4 k"
              using int_1_def_1 sorry
            have "k <>HIDDENR2 0NUMBERSK6"
              using A7 A9 xcmplx_1_th_6 sorry
            then have A10: "k >XXREAL-0R4 0NUMBERSK6"
               sorry
            have A11: " for i be NatNAT-1M1 holds ?P(i) implies i <=XXREAL-0R1 k"
            proof-
              have " for i be NatNAT-1M1 holds (i dividesINT-1R1 a & i dividesINT-1R1 b) & i <>HIDDENR2 0NUMBERSK6 implies i <=XXREAL-0R1 k"
              proof(rule ballI,rule impI)
                fix i assume [ty]: "i be NatNAT-1M1"
                assume "?P(i)"
                then have "i dividesINT-1R1 a *XCMPLX-0K3 b"
                  using A8 int_2_lm_2 sorry
                then have "i dividesINT-1R1 k"
                  using A9 int_2_lm_3 sorry
                thus "i <=XXREAL-0R1 k"
                  using A10 int_2_lm_9 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have "\<one>\<^sub>M dividesINT-1R1 a & \<one>\<^sub>M dividesINT-1R1 b"
              using int_2_lm_5 sorry
            then have A12: " ex k be NatNAT-1M1 st ?P(k)"
               sorry
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A13: "?P(k)"and A14: " for n be NatNAT-1M1 holds ?P(n) implies n <=XXREAL-0R1 k"
              using nat_1_sch_6 A11 A12 sorry
            show " ex tVar7 be NatNAT-1M1 st (tVar7 dividesINT-1R1 a & tVar7 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies ( not m dividesINT-1R1 tVar7 implies  False ))"
            proof(rule bexI[of _ "k"],rule conjMI,rule ballI,rule impMI ,rule impI,rule impI)
              show "k dividesINT-1R1 a & k dividesINT-1R1 b"
                using A13 sorry
              fix m assume [ty]: "m be IntegerINT-1M1"
              assume A15: "m dividesINT-1R1 a"
                and A16: "m dividesINT-1R1 b"
              have "m inHIDDENR3 INTINT-1K1"
                using int_1_def_2 sorry
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A17: "m =COMPLEX1R1 n or m =COMPLEX1R1 -XCMPLX-0K4 n"
                using int_1_def_1 sorry
              let ?i = "n lcmINT-2K2 k"
              have A18: "k dividesINT-1R1 ?i"
                using int_2_def_1 sorry
              have "n lcmINT-2K2 k =COMPLEX1R1 0NUMBERSK6 implies  False "
              proof(rule impI)
                assume "?i =COMPLEX1R1 0NUMBERSK6"
                then have "n =COMPLEX1R1 0NUMBERSK6 or k =COMPLEX1R1 0NUMBERSK6"
                  using int_2_th_4 sorry
                thus " False "
                  using A7 A13 A17 A15 sorry
              qed
              then have "0NUMBERSK6 <XXREAL-0R3 ?i"
                 sorry
              then have A19: "k <=XXREAL-0R1 ?i"
                using A18 int_2_lm_9 sorry
              have "n dividesINT-1R1 b"
                using A17 A16 int_2_lm_4 sorry
              then have A20: "n lcmINT-2K2 k dividesINT-1R1 b"
                using A13 int_2_def_1 sorry
              have "n dividesINT-1R1 a"
                using A17 A15 int_2_lm_4 sorry
              then have "n lcmINT-2K2 k dividesINT-1R1 a"
                using A13 int_2_def_1 sorry
              then have "k >=XXREAL-0R2 n lcmINT-2K2 k"
                using A14 A20 sorry
              then have "k =COMPLEX1R1 ?i"
                using A19 xxreal_0_th_1 sorry
              then have A21: "n dividesINT-1R1 k"
                using int_2_def_1 sorry
              assume " not m dividesINT-1R1 k"
              thus " False "
                using A17 A21 int_2_lm_4 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds ((it1 dividesINT-1R1 a & it1 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 it1)) & ((it2 dividesINT-1R1 a & it2 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 it2)) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT1 be NatNAT-1M1 holds  for IT2 be NatNAT-1M1 holds (((IT1 dividesINT-1R1 a & IT1 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 IT1)) & IT2 dividesINT-1R1 a) & (IT2 dividesINT-1R1 b & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 IT2)) implies IT1 =HIDDENR1 IT2"
      proof(rule ballI,rule ballI,rule impI)
        fix IT1 assume [ty]: "IT1 be NatNAT-1M1"
        fix IT2 assume [ty]: "IT2 be NatNAT-1M1"
        assume "(((IT1 dividesINT-1R1 a & IT1 dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 IT1)) & IT2 dividesINT-1R1 a) & (IT2 dividesINT-1R1 b & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 IT2))"
        then have "IT1 dividesINT-1R1 IT2 & IT2 dividesINT-1R1 IT1"
           sorry
        thus "IT1 =HIDDENR1 IT2"
          using int_2_lm_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem INT_2K3_commutativity:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a gcdINT-2K3 b =HIDDENR1 b gcdINT-2K3 a"
proof-
  have " for it be NatNAT-1M1 holds  for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds it =HIDDENR1 a gcdINT-2K3 b implies it =HIDDENR1 b gcdINT-2K3 a"
  proof-
    have " for it be NatNAT-1M1 holds  for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (it dividesINT-1R1 a & it dividesINT-1R1 b) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 a & m dividesINT-1R1 b implies m dividesINT-1R1 it) implies (it dividesINT-1R1 b & it dividesINT-1R1 a) & ( for m be IntegerINT-1M1 holds m dividesINT-1R1 b & m dividesINT-1R1 a implies m dividesINT-1R1 it)"
       sorry
    thus " ?thesis "
      using int_2_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_5:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6 iff a gcdINT-2K3 b =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6 implies a gcdINT-2K3 b =COMPLEX1R1 0NUMBERSK6) & (a gcdINT-2K3 b =COMPLEX1R1 0NUMBERSK6 implies a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    have "0NUMBERSK6 dividesINT-1R1 0NUMBERSK6 gcdINT-2K3 0NUMBERSK6"
      using int_2_def_2 sorry
    thus "a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6 implies a gcdINT-2K3 b =COMPLEX1R1 0NUMBERSK6"
       sorry
    assume "a gcdINT-2K3 b =COMPLEX1R1 0NUMBERSK6"
    then have "0NUMBERSK6 dividesINT-1R1 a & 0NUMBERSK6 dividesINT-1R1 b"
      using int_2_def_2 sorry
    thus "a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve n for "NatNAT-1M1"
reserve a, b, c, d, a1, b1, a2, b2, k, l for "IntegerINT-1M1"
mtheorem int_2_th_6:
" for n be NatNAT-1M1 holds -XCMPLX-0K4 n be ElementSUBSET-1M1-of NATNUMBERSK1 iff n =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds (-XCMPLX-0K4 n be ElementSUBSET-1M1-of NATNUMBERSK1 implies n =COMPLEX1R1 0NUMBERSK6) &  not (n =COMPLEX1R1 0NUMBERSK6 &  not -XCMPLX-0K4 n be ElementSUBSET-1M1-of NATNUMBERSK1)"
  proof(rule ballI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    show "-XCMPLX-0K4 n be ElementSUBSET-1M1-of NATNUMBERSK1 implies n =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume "-XCMPLX-0K4 n be ElementSUBSET-1M1-of NATNUMBERSK1"
      then have "-XCMPLX-0K4 n >=XXREAL-0R2 0NUMBERSK6 & n +XCMPLX-0K2 (-XCMPLX-0K4 n) >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 n"
         sorry
      thus "n =COMPLEX1R1 0NUMBERSK6"
         sorry
    qed
    show " not (n =COMPLEX1R1 0NUMBERSK6 &  not -XCMPLX-0K4 n be ElementSUBSET-1M1-of NATNUMBERSK1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_cl_1:
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
"cluster -XCMPLX-0K4 n as-term-is  non naturalORDINAL1V7"
proof
(*coherence*)
  show "-XCMPLX-0K4 n be  non naturalORDINAL1V7"
  proof-
    have " not -XCMPLX-0K4 n be naturalORDINAL1V7"
    proof-
      have " not -XCMPLX-0K4 n be ElementSUBSET-1M1-of NATNUMBERSK1"
        using int_2_th_6 sorry
      thus " not -XCMPLX-0K4 n be naturalORDINAL1V7"
        using ordinal1_def_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem int_2_th_7:
" not -XCMPLX-0K4 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
   sorry

mtheorem int_2_th_8:
" for a be IntegerINT-1M1 holds a dividesINT-1R1 -XCMPLX-0K4 a & -XCMPLX-0K4 a dividesINT-1R1 a"
  using int_2_lm_1 sorry

mtheorem int_2_th_9:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 b & b dividesINT-1R1 c implies a dividesINT-1R1 c"
  using int_2_lm_2 sorry

mtheorem int_2_th_10:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (((a dividesINT-1R1 b iff a dividesINT-1R1 -XCMPLX-0K4 b) & (a dividesINT-1R1 b iff -XCMPLX-0K4 a dividesINT-1R1 b)) & (a dividesINT-1R1 b iff -XCMPLX-0K4 a dividesINT-1R1 -XCMPLX-0K4 b)) & (a dividesINT-1R1 -XCMPLX-0K4 b iff -XCMPLX-0K4 a dividesINT-1R1 b)"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (a dividesINT-1R1 b iff a dividesINT-1R1 -XCMPLX-0K4 b) & ((a dividesINT-1R1 b iff -XCMPLX-0K4 a dividesINT-1R1 b) & ((a dividesINT-1R1 b iff -XCMPLX-0K4 a dividesINT-1R1 -XCMPLX-0K4 b) & ( not (a dividesINT-1R1 -XCMPLX-0K4 b &  not -XCMPLX-0K4 a dividesINT-1R1 b) &  not (-XCMPLX-0K4 a dividesINT-1R1 b &  not a dividesINT-1R1 -XCMPLX-0K4 b))))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    have A1: "a dividesINT-1R1 b implies a dividesINT-1R1 -XCMPLX-0K4 b"
    proof(rule impI)
      assume A2: "a dividesINT-1R1 b"
      have "b dividesINT-1R1 -XCMPLX-0K4 b"
        using int_2_lm_1 sorry
      thus "a dividesINT-1R1 -XCMPLX-0K4 b"
        using A2 int_2_lm_2 sorry
    qed
    have A3: "a dividesINT-1R1 -XCMPLX-0K4 b implies a dividesINT-1R1 b"
    proof(rule impI)
      assume A4: "a dividesINT-1R1 -XCMPLX-0K4 b"
      have "-XCMPLX-0K4 b dividesINT-1R1 b"
        using int_2_lm_1 sorry
      thus "a dividesINT-1R1 b"
        using A4 int_2_lm_2 sorry
    qed
    thus "a dividesINT-1R1 b iff a dividesINT-1R1 -XCMPLX-0K4 b"
      using A1 sorry
    have A5: "-XCMPLX-0K4 a dividesINT-1R1 b implies a dividesINT-1R1 b"
    proof(rule impI)
      assume A6: "-XCMPLX-0K4 a dividesINT-1R1 b"
      have "a dividesINT-1R1 -XCMPLX-0K4 a"
        using int_2_lm_1 sorry
      thus "a dividesINT-1R1 b"
        using A6 int_2_lm_2 sorry
    qed
    have A7: "-XCMPLX-0K4 a dividesINT-1R1 -XCMPLX-0K4 b implies a dividesINT-1R1 b"
    proof(rule impI)
      assume A8: "-XCMPLX-0K4 a dividesINT-1R1 -XCMPLX-0K4 b"
      have "-XCMPLX-0K4 b dividesINT-1R1 b"
        using int_2_lm_1 sorry
      thus "a dividesINT-1R1 b"
        using A5 A8 int_2_lm_2 sorry
    qed
    have A9: "a dividesINT-1R1 b implies -XCMPLX-0K4 a dividesINT-1R1 b"
    proof(rule impI)
      assume A10: "a dividesINT-1R1 b"
      have "-XCMPLX-0K4 a dividesINT-1R1 a"
        using int_2_lm_1 sorry
      thus "-XCMPLX-0K4 a dividesINT-1R1 b"
        using A10 int_2_lm_2 sorry
    qed
    thus "a dividesINT-1R1 b iff -XCMPLX-0K4 a dividesINT-1R1 b"
      using A5 sorry
    have "a dividesINT-1R1 b implies -XCMPLX-0K4 a dividesINT-1R1 -XCMPLX-0K4 b"
    proof(rule impI)
      assume A11: "a dividesINT-1R1 b"
      have "-XCMPLX-0K4 a dividesINT-1R1 a"
        using int_2_lm_1 sorry
      thus "-XCMPLX-0K4 a dividesINT-1R1 -XCMPLX-0K4 b"
        using A1 A11 int_2_lm_2 sorry
    qed
    thus "a dividesINT-1R1 b iff -XCMPLX-0K4 a dividesINT-1R1 -XCMPLX-0K4 b"
      using A7 sorry
    show " not (a dividesINT-1R1 -XCMPLX-0K4 b &  not -XCMPLX-0K4 a dividesINT-1R1 b) &  not (-XCMPLX-0K4 a dividesINT-1R1 b &  not a dividesINT-1R1 -XCMPLX-0K4 b)"
      using A1 A3 A9 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_11:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a dividesINT-1R1 b & b dividesINT-1R1 a implies a =COMPLEX1R1 b or a =COMPLEX1R1 -XCMPLX-0K4 b"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a dividesINT-1R1 b & b dividesINT-1R1 a implies  not ( not a =COMPLEX1R1 b &  not a =COMPLEX1R1 -XCMPLX-0K4 b)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    assume A1: "a dividesINT-1R1 b"
      and A2: "b dividesINT-1R1 a"
    obtain a1 where
      [ty]:"a1 be IntegerINT-1M1" and 
      A3: "b =COMPLEX1R1 a *XCMPLX-0K3 a1"
      using A1 sorry
    obtain b1 where
      [ty]:"b1 be IntegerINT-1M1" and 
      A4: "a =COMPLEX1R1 b *XCMPLX-0K3 b1"
      using A2 sorry
    have "a <>HIDDENR2 0NUMBERSK6 implies a =COMPLEX1R1 b or a =COMPLEX1R1 -XCMPLX-0K4 b"
    proof-
      have "a <>HIDDENR2 0NUMBERSK6 implies  not ( not a =COMPLEX1R1 b &  not a =COMPLEX1R1 -XCMPLX-0K4 b)"
      proof(rule impI)
        assume A5: "a <>HIDDENR2 0NUMBERSK6"
        have "\<one>\<^sub>M *XCMPLX-0K3 a =COMPLEX1R1 a *XCMPLX-0K3 (a1 *XCMPLX-0K3 b1)"
          using A3 A4 sorry
        then have "a1 *XCMPLX-0K3 b1 =COMPLEX1R1 \<one>\<^sub>M"
          using A5 xcmplx_1_th_5 sorry
        then have "a =COMPLEX1R1 b *XCMPLX-0K3 \<one>\<^sub>M or a =COMPLEX1R1 b *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
          using A4 int_1_th_9 sorry
        thus " not ( not a =COMPLEX1R1 b &  not a =COMPLEX1R1 -XCMPLX-0K4 b)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( not a =COMPLEX1R1 b &  not a =COMPLEX1R1 -XCMPLX-0K4 b)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_12:
" for a be IntegerINT-1M1 holds (a dividesINT-1R1 0NUMBERSK6 & \<one>\<^sub>M dividesINT-1R1 a) & -XCMPLX-0K4 \<one>\<^sub>M dividesINT-1R1 a"
  using int_2_lm_5 sorry

mtheorem int_2_th_13:
" for a be IntegerINT-1M1 holds a dividesINT-1R1 \<one>\<^sub>M or a dividesINT-1R1 -XCMPLX-0K4 \<one>\<^sub>M implies a =COMPLEX1R1 \<one>\<^sub>M or a =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
  using int_1_th_9 int_1_th_10 sorry

mtheorem int_2_th_14:
" for a be IntegerINT-1M1 holds a =COMPLEX1R1 \<one>\<^sub>M or a =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M implies a dividesINT-1R1 \<one>\<^sub>M & a dividesINT-1R1 -XCMPLX-0K4 \<one>\<^sub>M"
  using int_2_lm_5 sorry

mtheorem int_2_th_15:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds (a,b)are-congruent-modINT-1R3 c iff c dividesINT-1R1 a -XCMPLX-0K6 b"
   sorry

mtheorem int_2_th_16:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a dividesINT-1R1 b iff  |.INT-2K1 a.| dividesINT-1R1  |.INT-2K1 b.|"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (a dividesINT-1R1 b implies  |.INT-2K1 a.| dividesINT-1R1  |.INT-2K1 b.|) & ( |.INT-2K1 a.| dividesINT-1R1  |.INT-2K1 b.| implies a dividesINT-1R1 b)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    show "a dividesINT-1R1 b implies  |.INT-2K1 a.| dividesINT-1R1  |.INT-2K1 b.|"
    proof(rule impI)
      assume "a dividesINT-1R1 b"
      then obtain c where
        [ty]:"c be IntegerINT-1M1" and 
        A1: "b =COMPLEX1R1 a *XCMPLX-0K3 c"
         sorry
      have " |.INT-2K1 b.| =COMPLEX1R1 ( |.INT-2K1 a.|)*NAT-1K2 ( |.INT-2K1 c.|)"
        using A1 complex1_th_65 sorry
      thus " |.INT-2K1 a.| dividesINT-1R1  |.INT-2K1 b.|"
         sorry
    qed
    assume " |.INT-2K1 a.| dividesINT-1R1  |.INT-2K1 b.|"
    then obtain m where
      [ty]:"m be IntegerINT-1M1" and 
      A2: " |.INT-2K1 b.| =COMPLEX1R1 ( |.INT-2K1 a.|)*XCMPLX-0K3 m"
       sorry
    have A3: "a >=XXREAL-0R2 0NUMBERSK6 implies a dividesINT-1R1 b"
    proof(rule impI)
      assume "a >=XXREAL-0R2 0NUMBERSK6"
      then have A4: " |.INT-2K1 b.| =COMPLEX1R1 a *XCMPLX-0K3 m"
        using A2 absvalue_def_1 sorry
      show "a dividesINT-1R1 b"
      proof-
        have cases: "b <XXREAL-0R3 0NUMBERSK6 or b >=XXREAL-0R2 0NUMBERSK6"
           sorry
        have case1: "b <XXREAL-0R3 0NUMBERSK6 implies a dividesINT-1R1 b"
        proof(rule impI)
          assume "b <XXREAL-0R3 0NUMBERSK6"
          then have "-XCMPLX-0K4 b =COMPLEX1R1 a *XCMPLX-0K3 m"
            using A4 absvalue_def_1 sorry
          then have "b =COMPLEX1R1 a *XCMPLX-0K3 (-XCMPLX-0K4 m)"
             sorry
          thus "a dividesINT-1R1 b"
             sorry
        qed
        have case2: "b >=XXREAL-0R2 0NUMBERSK6 implies a dividesINT-1R1 b"
        proof(rule impI)
          assume "b >=XXREAL-0R2 0NUMBERSK6"
          then have "b =COMPLEX1R1 a *XCMPLX-0K3 m"
            using A4 absvalue_def_1 sorry
          thus "a dividesINT-1R1 b"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have "a <XXREAL-0R3 0NUMBERSK6 implies a dividesINT-1R1 b"
    proof(rule impI)
      assume "a <XXREAL-0R3 0NUMBERSK6"
      then have A5: " |.INT-2K1 b.| =COMPLEX1R1 (-XCMPLX-0K4 a)*XCMPLX-0K3 m"
        using A2 absvalue_def_1 sorry
      show "a dividesINT-1R1 b"
      proof-
        have cases: "b <XXREAL-0R3 0NUMBERSK6 or b >=XXREAL-0R2 0NUMBERSK6"
           sorry
        have case1: "b <XXREAL-0R3 0NUMBERSK6 implies a dividesINT-1R1 b"
        proof(rule impI)
          assume "b <XXREAL-0R3 0NUMBERSK6"
          then have "-XCMPLX-0K4 b =COMPLEX1R1 -XCMPLX-0K4 a *XCMPLX-0K3 m"
            using A5 absvalue_def_1 sorry
          thus "a dividesINT-1R1 b"
             sorry
        qed
        have case2: "b >=XXREAL-0R2 0NUMBERSK6 implies a dividesINT-1R1 b"
        proof(rule impI)
          assume "b >=XXREAL-0R2 0NUMBERSK6"
          then have "b =COMPLEX1R1 a *XCMPLX-0K3 (-XCMPLX-0K4 m)"
            using A5 absvalue_def_1 sorry
          thus "a dividesINT-1R1 b"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "a dividesINT-1R1 b"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_17:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a lcmINT-2K2 b be ElementSUBSET-1M1-of NATNUMBERSK1"
  using ordinal1_def_12 sorry

mtheorem int_2_th_18:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a dividesINT-1R1 a lcmINT-2K2 b"
  using int_2_def_1 sorry

mtheorem int_2_th_19:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds a dividesINT-1R1 c & b dividesINT-1R1 c implies a lcmINT-2K2 b dividesINT-1R1 c"
  using int_2_def_1 sorry

mtheorem int_2_th_20:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a gcdINT-2K3 b be ElementSUBSET-1M1-of NATNUMBERSK1"
  using ordinal1_def_12 sorry

mtheorem int_2_th_21:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a gcdINT-2K3 b dividesINT-1R1 a"
  using int_2_def_2 sorry

mtheorem int_2_th_22:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds c dividesINT-1R1 a & c dividesINT-1R1 b implies c dividesINT-1R1 a gcdINT-2K3 b"
  using int_2_def_2 sorry

mdef int_2_def_3 ("'( _ , _ ')are-coprimeINT-2R1" [0,0]50 ) where
  mlet "a be IntegerINT-1M1", "b be IntegerINT-1M1"
"pred (a,b)are-coprimeINT-2R1 means
  a gcdINT-2K3 b =COMPLEX1R1 \<one>\<^sub>M"..

mtheorem INT_2R1_symmetry:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (a,b)are-coprimeINT-2R1 implies (b,a)are-coprimeINT-2R1"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a gcdINT-2K3 b =COMPLEX1R1 \<one>\<^sub>M implies b gcdINT-2K3 a =COMPLEX1R1 \<one>\<^sub>M"
     sorry
  thus " ?thesis "
    using int_2_def_3 sorry
qed

mtheorem int_2_th_23:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6 implies ( ex a1 be IntegerINT-1M1 st  ex b1 be IntegerINT-1M1 st (a =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 a1 & b =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 b1) & (a1,b1)are-coprimeINT-2R1)"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6 implies  not ( for a1 be IntegerINT-1M1 holds  for b1 be IntegerINT-1M1 holds  not ((a =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 a1 & b =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 b1) & (a1,b1)are-coprimeINT-2R1))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    assume "a <>HIDDENR2 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6"
    then have A1: "a gcdINT-2K3 b <>HIDDENR2 0NUMBERSK6"
      using int_2_th_5 sorry
    have "a gcdINT-2K3 b dividesINT-1R1 a"
      using int_2_def_2 sorry
    then obtain a1 where
      [ty]:"a1 be IntegerINT-1M1" and 
      A2: "a =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 a1"
       sorry
    have "a gcdINT-2K3 b dividesINT-1R1 b"
      using int_2_def_2 sorry
    then obtain b1 where
      [ty]:"b1 be IntegerINT-1M1" and 
      A3: "b =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 b1"
       sorry
    have "a1 gcdINT-2K3 b1 dividesINT-1R1 b1"
      using int_2_def_2 sorry
    then obtain b2 where
      [ty]:"b2 be IntegerINT-1M1" and 
      A4: "b1 =COMPLEX1R1 (a1 gcdINT-2K3 b1)*XCMPLX-0K3 b2"
       sorry
    have "b =COMPLEX1R1 ((a gcdINT-2K3 b)*XCMPLX-0K3 (a1 gcdINT-2K3 b1))*XCMPLX-0K3 b2"
      using A3 A4 sorry
    then have A5: "(a gcdINT-2K3 b)*XCMPLX-0K3 (a1 gcdINT-2K3 b1) dividesINT-1R1 b"
       sorry
    have "a1 gcdINT-2K3 b1 dividesINT-1R1 a1"
      using int_2_def_2 sorry
    then obtain a2 where
      [ty]:"a2 be IntegerINT-1M1" and 
      A6: "a1 =COMPLEX1R1 (a1 gcdINT-2K3 b1)*XCMPLX-0K3 a2"
       sorry
    have "a =COMPLEX1R1 ((a gcdINT-2K3 b)*XCMPLX-0K3 (a1 gcdINT-2K3 b1))*XCMPLX-0K3 a2"
      using A2 A6 sorry
    then have "(a gcdINT-2K3 b)*XCMPLX-0K3 (a1 gcdINT-2K3 b1) dividesINT-1R1 a"
       sorry
    then have "(a gcdINT-2K3 b)*XCMPLX-0K3 (a1 gcdINT-2K3 b1) dividesINT-1R1 a gcdINT-2K3 b"
      using A5 int_2_def_2 sorry
    then obtain c where
      [ty]:"c be IntegerINT-1M1" and 
      A7: "a gcdINT-2K3 b =COMPLEX1R1 ((a gcdINT-2K3 b)*XCMPLX-0K3 (a1 gcdINT-2K3 b1))*XCMPLX-0K3 c"
       sorry
    have "(a gcdINT-2K3 b)*XCMPLX-0K3 \<one>\<^sub>M =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 ((a1 gcdINT-2K3 b1)*XCMPLX-0K3 c)"
      using A7 sorry
    then have "\<one>\<^sub>M =COMPLEX1R1 (a1 gcdINT-2K3 b1)*XCMPLX-0K3 c"
      using A1 xcmplx_1_th_5 sorry
    then have "a1 gcdINT-2K3 b1 =COMPLEX1R1 \<one>\<^sub>M or a1 gcdINT-2K3 b1 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
      using int_1_th_9 sorry
    then have "(a1,b1)are-coprimeINT-2R1"
       sorry
    thus " not ( for a1 be IntegerINT-1M1 holds  for b1 be IntegerINT-1M1 holds  not ((a =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 a1 & b =COMPLEX1R1 (a gcdINT-2K3 b)*XCMPLX-0K3 b1) & (a1,b1)are-coprimeINT-2R1))"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_24:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds (a,b)are-coprimeINT-2R1 implies ((c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.| & c *XCMPLX-0K3 a gcdINT-2K3 b *XCMPLX-0K3 c =COMPLEX1R1  |.INT-2K1 c.|) & a *XCMPLX-0K3 c gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.|) & a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =COMPLEX1R1  |.INT-2K1 c.|"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds (a,b)are-coprimeINT-2R1 implies c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.| & (c *XCMPLX-0K3 a gcdINT-2K3 b *XCMPLX-0K3 c =COMPLEX1R1  |.INT-2K1 c.| & (a *XCMPLX-0K3 c gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.| & a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =COMPLEX1R1  |.INT-2K1 c.|))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    fix c assume [ty]: "c be IntegerINT-1M1"
    assume "(a,b)are-coprimeINT-2R1"
    then have A1: "a gcdINT-2K3 b =COMPLEX1R1 \<one>\<^sub>M"
       sorry
    show A2: "c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.|"
    proof-
      have "c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b dividesINT-1R1 c *XCMPLX-0K3 b"
        using int_2_def_2 sorry
      then obtain l where
        [ty]:"l be IntegerINT-1M1" and 
        A3: "c *XCMPLX-0K3 b =COMPLEX1R1 (c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b)*XCMPLX-0K3 l"
         sorry
      have "c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b dividesINT-1R1 c *XCMPLX-0K3 a"
        using int_2_def_2 sorry
      then obtain k where
        [ty]:"k be IntegerINT-1M1" and 
        A4: "c *XCMPLX-0K3 a =COMPLEX1R1 (c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b)*XCMPLX-0K3 k"
         sorry
      have "c dividesINT-1R1 c *XCMPLX-0K3 a & c dividesINT-1R1 c *XCMPLX-0K3 b"
         sorry
      then have "c dividesINT-1R1 c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b"
        using int_2_def_2 sorry
      then obtain d where
        [ty]:"d be IntegerINT-1M1" and 
        A5: "c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1 c *XCMPLX-0K3 d"
         sorry
      have A6: "c *XCMPLX-0K3 b =COMPLEX1R1 c *XCMPLX-0K3 (d *XCMPLX-0K3 l)"
        using A5 A3 sorry
      have A7: "c *XCMPLX-0K3 a =COMPLEX1R1 c *XCMPLX-0K3 (d *XCMPLX-0K3 k)"
        using A5 A4 sorry
      have A8: "c <>HIDDENR2 0NUMBERSK6 implies c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.|"
      proof(rule impI)
        assume A9: "c <>HIDDENR2 0NUMBERSK6"
        then have "b =COMPLEX1R1 d *XCMPLX-0K3 l"
          using A6 xcmplx_1_th_5 sorry
        then have A10: "d dividesINT-1R1 b"
           sorry
        have "a =COMPLEX1R1 d *XCMPLX-0K3 k"
          using A7 A9 xcmplx_1_th_5 sorry
        then have "d dividesINT-1R1 a"
           sorry
        then have "d dividesINT-1R1 \<one>\<^sub>M"
          using A1 A10 int_2_def_2 sorry
        then have "c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1 c *XCMPLX-0K3 \<one>\<^sub>M or c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1 c *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
          using A5 int_2_th_13 sorry
        then have "c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1 c *XCMPLX-0K3 \<one>\<^sub>M or c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1 (-XCMPLX-0K4 c)*XCMPLX-0K3 \<one>\<^sub>M"
           sorry
        then have A11: " |.INT-2K1 c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b .| =COMPLEX1R1  |.INT-2K1 c.|"
          using complex1_th_52 sorry
        show "c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.|"
          using A11 absvalue_def_1 sorry
      qed
      have "(0NUMBERSK6)*XCMPLX-0K3 a gcdINT-2K3 (0NUMBERSK6)*XCMPLX-0K3 b =HIDDENR1 0NUMBERSK6"
        using int_2_th_5 sorry
      also have "... =  |.INT-2K1 0NUMBERSK6 .|"
        using absvalue_th_2 sorry
      finally have "(0NUMBERSK6)*XCMPLX-0K3 a gcdINT-2K3 (0NUMBERSK6)*XCMPLX-0K3 b =HIDDENR1  |.INT-2K1 0NUMBERSK6 .|"
         sorry
      thus "c *XCMPLX-0K3 a gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.|"
        using A8 sorry
    qed
    thus "c *XCMPLX-0K3 a gcdINT-2K3 b *XCMPLX-0K3 c =COMPLEX1R1  |.INT-2K1 c.|"
       sorry
    show "a *XCMPLX-0K3 c gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 c.| & a *XCMPLX-0K3 c gcdINT-2K3 b *XCMPLX-0K3 c =COMPLEX1R1  |.INT-2K1 c.|"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_25:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds c dividesINT-1R1 a *XCMPLX-0K3 b & (a,c)are-coprimeINT-2R1 implies c dividesINT-1R1 b"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds c dividesINT-1R1 a *XCMPLX-0K3 b & (a,c)are-coprimeINT-2R1 implies c dividesINT-1R1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    fix c assume [ty]: "c be IntegerINT-1M1"
    assume A1: "c dividesINT-1R1 a *XCMPLX-0K3 b"
      and A2: "(a,c)are-coprimeINT-2R1"
    have "c dividesINT-1R1 c *XCMPLX-0K3 b"
       sorry
    then have A3: "c dividesINT-1R1 a *XCMPLX-0K3 b gcdINT-2K3 c *XCMPLX-0K3 b"
      using A1 int_2_def_2 sorry
    have A4: "a *XCMPLX-0K3 b gcdINT-2K3 c *XCMPLX-0K3 b =COMPLEX1R1  |.INT-2K1 b.|"
      using A2 int_2_th_24 sorry
    have "b <XXREAL-0R3 0NUMBERSK6 implies c dividesINT-1R1 b"
    proof(rule impI)
      assume "b <XXREAL-0R3 0NUMBERSK6"
      then have "c dividesINT-1R1 -XCMPLX-0K4 b"
        using A4 A3 absvalue_def_1 sorry
      thus "c dividesINT-1R1 b"
        using int_2_th_10 sorry
    qed
    thus "c dividesINT-1R1 b"
      using A4 A3 absvalue_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_26:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds (a,c)are-coprimeINT-2R1 & (b,c)are-coprimeINT-2R1 implies (a *XCMPLX-0K3 b,c)are-coprimeINT-2R1"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  for c be IntegerINT-1M1 holds (a,c)are-coprimeINT-2R1 & (b,c)are-coprimeINT-2R1 implies (a *XCMPLX-0K3 b,c)are-coprimeINT-2R1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    fix c assume [ty]: "c be IntegerINT-1M1"
    assume A1: "(a,c)are-coprimeINT-2R1"
      and A2: "(b,c)are-coprimeINT-2R1"
    have A3: "a gcdINT-2K3 c =COMPLEX1R1 \<one>\<^sub>M"
      using A1 sorry
    have A4: "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a dividesINT-1R1 a"
      using int_2_def_2 sorry
    have A5: "a *XCMPLX-0K3 b gcdINT-2K3 c dividesINT-1R1 c"
      using int_2_def_2 sorry
    have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a dividesINT-1R1 a *XCMPLX-0K3 b gcdINT-2K3 c"
      using int_2_def_2 sorry
    then have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a dividesINT-1R1 c"
      using A5 int_2_lm_2 sorry
    then have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a dividesINT-1R1 \<one>\<^sub>M"
      using A3 A4 int_2_def_2 sorry
    then have "(a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a =COMPLEX1R1 \<one>\<^sub>M or (a *XCMPLX-0K3 b gcdINT-2K3 c)gcdINT-2K3 a =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
      using int_2_th_13 sorry
    then have "(a,a *XCMPLX-0K3 b gcdINT-2K3 c)are-coprimeINT-2R1"
       sorry
    then have A6: "a *XCMPLX-0K3 b gcdINT-2K3 c dividesINT-1R1 b"
      using int_2_th_21 int_2_th_25 sorry
    have "b gcdINT-2K3 c =COMPLEX1R1 \<one>\<^sub>M"
      using A2 sorry
    then have "a *XCMPLX-0K3 b gcdINT-2K3 c dividesINT-1R1 \<one>\<^sub>M"
      using A5 A6 int_2_def_2 sorry
    then have "a *XCMPLX-0K3 b gcdINT-2K3 c =COMPLEX1R1 \<one>\<^sub>M or a *XCMPLX-0K3 b gcdINT-2K3 c =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
      using int_2_th_13 sorry
    thus "(a *XCMPLX-0K3 b,c)are-coprimeINT-2R1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve p, p1, q, l for "NatNAT-1M1"
mdef int_2_def_4 ("primeINT-2V1" 70 ) where
"attr primeINT-2V1 for integerINT-1V1\<bar>NumberORDINAL1M1 means
  (\<lambda>p. p >XXREAL-0R4 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n dividesINT-1R1 p implies n =COMPLEX1R1 \<one>\<^sub>M or n =COMPLEX1R1 p))"..

mtheorem int_2_cl_2:
"cluster primeINT-2V1 also-is naturalORDINAL1V7 for integerINT-1V1\<bar>NumberORDINAL1M1"
proof
(*coherence*)
  show " for it be integerINT-1V1\<bar>NumberORDINAL1M1 holds it be primeINT-2V1 implies it be naturalORDINAL1V7"
  proof-
    have " for p be integerINT-1V1\<bar>NumberORDINAL1M1 holds p be primeINT-2V1 implies p be naturalORDINAL1V7"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be integerINT-1V1\<bar>NumberORDINAL1M1"
      assume "p be primeINT-2V1"
      then have "p inHIDDENR3 NATNUMBERSK1"
        using int_1_th_3 sorry
      thus "p be naturalORDINAL1V7"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem int_2_th_27:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 b & a dividesINT-1R1 b implies a <=XXREAL-0R1 b"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 b implies (a dividesINT-1R1 b implies a <=XXREAL-0R1 b)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 b"
    assume "a dividesINT-1R1 b"
    then obtain c where
      [ty]:"c be IntegerINT-1M1" and 
      A2: "b =COMPLEX1R1 a *XCMPLX-0K3 c"
       sorry
    show "a <=XXREAL-0R1 b"
    proof-
      have cases: "a <=XXREAL-0R1 0NUMBERSK6 or a >XXREAL-0R4 0NUMBERSK6"
         sorry
      have case1: "a <=XXREAL-0R1 0NUMBERSK6 implies a <=XXREAL-0R1 b"
      proof(rule impI)
        assume "a <=XXREAL-0R1 0NUMBERSK6"
        thus "a <=XXREAL-0R1 b"
          using A1 sorry
      qed
      have case2: "a >XXREAL-0R4 0NUMBERSK6 implies a <=XXREAL-0R1 b"
      proof(rule impI)
        assume A3: "a >XXREAL-0R4 0NUMBERSK6"
        then have "c >XXREAL-0R4 0NUMBERSK6"
          using A1 A2 sorry
        then have "c >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using int_1_th_7 sorry
        thus "a <=XXREAL-0R1 b"
          using A2 A3 xreal_1_th_151 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_28:
"\<two>\<^sub>M be primeINT-2V1"
proof-
  have "\<two>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n dividesINT-1R1 \<two>\<^sub>M implies  not ( not n =COMPLEX1R1 \<one>\<^sub>M &  not n =COMPLEX1R1 \<two>\<^sub>M))"
  proof(rule conjMI,rule ballI,rule impI)
    show "\<two>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M"
       sorry
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n dividesINT-1R1 \<two>\<^sub>M"
    then have "n <=XXREAL-0R1 \<two>\<^sub>M"
      using int_2_th_27 sorry
    then have " ex VarFor1 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M) & n =COMPLEX1R1 VarFor1"
       sorry
    thus " not ( not n =COMPLEX1R1 \<one>\<^sub>M &  not n =COMPLEX1R1 \<two>\<^sub>M)"
      using A1 sorry
  qed "sorry"
  thus "\<two>\<^sub>M be primeINT-2V1"
    using int_2_def_4 sorry
qed

mtheorem int_2_th_29:
" not \<four>\<^sub>M be primeINT-2V1"
proof-
  have " ex n be NatNAT-1M1 st (n dividesINT-1R1 \<four>\<^sub>M & n <>HIDDENR2 \<one>\<^sub>M) & n <>HIDDENR2 \<four>\<^sub>M"
  proof-
    have " ex tVar8 be NatNAT-1M1 st (tVar8 dividesINT-1R1 \<four>\<^sub>M &  not tVar8 <>HIDDENR2 \<one>\<^sub>M) &  not tVar8 <>HIDDENR2 \<four>\<^sub>M"
    proof-
      show " ex tVar8 be NatNAT-1M1 st (tVar8 dividesINT-1R1 \<four>\<^sub>M &  not tVar8 <>HIDDENR2 \<one>\<^sub>M) &  not tVar8 <>HIDDENR2 \<four>\<^sub>M"
      proof(rule bexI[of _ "\<two>\<^sub>M"])
        have "\<four>\<^sub>M =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
           sorry
        thus "(\<two>\<^sub>M dividesINT-1R1 \<four>\<^sub>M &  not \<two>\<^sub>M <>HIDDENR2 \<one>\<^sub>M) &  not \<two>\<^sub>M <>HIDDENR2 \<four>\<^sub>M"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
  thus " not \<four>\<^sub>M be primeINT-2V1"
     sorry
qed

mtheorem int_2_cl_3:
"cluster primeINT-2V1 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be primeINT-2V1"
    using int_2_th_28 sorry
qed "sorry"

mtheorem int_2_cl_4:
"cluster  non zeroORDINAL1V8\<bar> non primeINT-2V1 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be  non zeroORDINAL1V8\<bar> non primeINT-2V1"
    using int_2_th_29 sorry
qed "sorry"

mtheorem int_2_th_30:
" for p be NatNAT-1M1 holds  for q be NatNAT-1M1 holds p be primeINT-2V1 & q be primeINT-2V1 implies (p,q)are-coprimeINT-2R1 or p =COMPLEX1R1 q"
proof-
  have " for p be NatNAT-1M1 holds  for q be NatNAT-1M1 holds p be primeINT-2V1 & q be primeINT-2V1 implies ( not (p,q)are-coprimeINT-2R1 implies p =COMPLEX1R1 q)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix p assume [ty]: "p be NatNAT-1M1"
    fix q assume [ty]: "q be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "q be primeINT-2V1"
    have A3: "p gcdINT-2K3 q dividesINT-1R1 q"
      using int_2_def_2 sorry
    assume " not (p,q)are-coprimeINT-2R1"
    then have A4: "p gcdINT-2K3 q <>HIDDENR2 \<one>\<^sub>M"
       sorry
    have "p gcdINT-2K3 q dividesINT-1R1 p"
      using int_2_def_2 sorry
    then have "p gcdINT-2K3 q =COMPLEX1R1 p"
      using A1 A4 sorry
    thus "p =COMPLEX1R1 q"
      using A2 A4 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_31:
" for l be NatNAT-1M1 holds l >=XXREAL-0R2 \<two>\<^sub>M implies ( ex p be ElementSUBSET-1M1-of NATNUMBERSK1 st p be primeINT-2V1 & p dividesINT-1R1 l)"
proof-
  have " for l be NatNAT-1M1 holds l >=XXREAL-0R2 \<two>\<^sub>M implies ( ex tVar10 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar10 be primeINT-2V1 & tVar10 dividesINT-1R1 l)"
  proof(rule ballI,rule impI)
    fix l assume [ty]: "l be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  ex p be NatNAT-1M1 st p be primeINT-2V1 & p dividesINT-1R1 Lamb1"
    have A1: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 \<two>\<^sub>M implies (( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies (n <XXREAL-0R3 k implies ?P(n))) implies ?P(k))"
    proof-
      have " for k be NatNAT-1M1 holds k >=XXREAL-0R2 \<two>\<^sub>M implies (( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies (n <XXREAL-0R3 k implies ( ex p be NatNAT-1M1 st p be primeINT-2V1 & p dividesINT-1R1 n))) implies ( ex p be NatNAT-1M1 st p be primeINT-2V1 & p dividesINT-1R1 k))"
      proof(rule ballI,rule impI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: "k >=XXREAL-0R2 \<two>\<^sub>M"
        assume A3: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies (n <XXREAL-0R3 k implies ( ex p be NatNAT-1M1 st p be primeINT-2V1 & p dividesINT-1R1 n))"
        have A4: "(k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A2 nat_1_th_13 sorry
        have " not k be primeINT-2V1 implies ( ex p be ElementSUBSET-1M1-of NATNUMBERSK1 st p be primeINT-2V1 & p dividesINT-1R1 k)"
        proof-
          have " not k be primeINT-2V1 implies ( ex tVar9 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar9 be primeINT-2V1 & tVar9 dividesINT-1R1 k)"
          proof(rule impI)
            assume " not k be primeINT-2V1"
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A5: "m dividesINT-1R1 k"and A6: "m <>HIDDENR2 \<one>\<^sub>M"and A7: "m <>HIDDENR2 k"
              using A4 sorry
            have "m <>HIDDENR2 0NUMBERSK6"
              using A5 A7 sorry
            then have "m >XXREAL-0R4 0NUMBERSK6"
               sorry
            then have "m >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            then have "m >XXREAL-0R4 \<one>\<^sub>M"
              using A6 xxreal_0_th_1 sorry
            then have A8: "m >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            have "k >XXREAL-0R4 0NUMBERSK6"
              using A2 sorry
            then have "m <=XXREAL-0R1 k"
              using A5 int_2_th_27 sorry
            then have "m <XXREAL-0R3 k"
              using A7 xxreal_0_th_1 sorry
            then obtain p1 where
              [ty]:"p1 be NatNAT-1M1" and 
              A9: "p1 be primeINT-2V1 & p1 dividesINT-1R1 m"
              using A3 A8 sorry
            have 
              [ty]:"p1 be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            show " ex tVar9 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar9 be primeINT-2V1 & tVar9 dividesINT-1R1 k"
            proof(rule bexI[of _ "p1"])
              show "p1 be primeINT-2V1 & p1 dividesINT-1R1 k"
                using A5 A9 int_2_lm_2 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        thus " ex p be NatNAT-1M1 st p be primeINT-2V1 & p dividesINT-1R1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 \<two>\<^sub>M implies ?P(k)"
      using nat_1_sch_9 A1 sorry
    assume "l >=XXREAL-0R2 \<two>\<^sub>M"
    then obtain p where
      [ty]:"p be NatNAT-1M1" and 
      A11: "p be primeINT-2V1 & p dividesINT-1R1 l"
      using A10 sorry
    have 
      [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    show " ex tVar10 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar10 be primeINT-2V1 & tVar10 dividesINT-1R1 l"
    proof(rule bexI[of _ "p"])
      show "p be primeINT-2V1 & p dividesINT-1R1 l"
        using A11 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem int_2_th_32:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds i >=XXREAL-0R2 0NUMBERSK6 & j >=XXREAL-0R2 0NUMBERSK6 implies  |.INT-2K1 i.| modINT-1K6  |.INT-2K1 j.| =COMPLEX1R1 i modINT-1K6 j &  |.INT-2K1 i.| divINT-1K5  |.INT-2K1 j.| =COMPLEX1R1 i divINT-1K5 j"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix j assume [ty]: "j be IntegerINT-1M1"
  assume A1: "i >=XXREAL-0R2 0NUMBERSK6"
    and A2: "j >=XXREAL-0R2 0NUMBERSK6"
  show " |.INT-2K1 i.| modINT-1K6  |.INT-2K1 j.| =COMPLEX1R1 i modINT-1K6 j &  |.INT-2K1 i.| divINT-1K5  |.INT-2K1 j.| =COMPLEX1R1 i divINT-1K5 j"
  proof-
    have cases: "j >XXREAL-0R4 0NUMBERSK6 or j =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    have case1: "j >XXREAL-0R4 0NUMBERSK6 implies  |.INT-2K1 i.| modINT-1K6  |.INT-2K1 j.| =COMPLEX1R1 i modINT-1K6 j &  |.INT-2K1 i.| divINT-1K5  |.INT-2K1 j.| =COMPLEX1R1 i divINT-1K5 j"
    proof(rule impI)
      assume A3: "j >XXREAL-0R4 0NUMBERSK6"
      have "i =COMPLEX1R1  |.INT-2K1 i.|"
        using A1 absvalue_def_1 sorry
      thus " |.INT-2K1 i.| modINT-1K6  |.INT-2K1 j.| =COMPLEX1R1 i modINT-1K6 j &  |.INT-2K1 i.| divINT-1K5  |.INT-2K1 j.| =COMPLEX1R1 i divINT-1K5 j"
        using A3 absvalue_def_1 sorry
    qed
    have case2: "j =COMPLEX1R1 0NUMBERSK6 implies  |.INT-2K1 i.| modINT-1K6  |.INT-2K1 j.| =COMPLEX1R1 i modINT-1K6 j &  |.INT-2K1 i.| divINT-1K5  |.INT-2K1 j.| =COMPLEX1R1 i divINT-1K5 j"
    proof(rule impI)
      assume A4: "j =COMPLEX1R1 0NUMBERSK6"
      have " |.INT-2K1 0NUMBERSK6 .| =COMPLEX1R1 0NUMBERSK6"
        using absvalue_def_1 sorry
      then have " |.INT-2K1 i.| modINT-1K6  |.INT-2K1 0NUMBERSK6 .| =COMPLEX1R1 0NUMBERSK6 &  |.INT-2K1 i.| divINT-1K5  |.INT-2K1 0NUMBERSK6 .| =COMPLEX1R1 0NUMBERSK6"
        using int_1_th_48 int_1_def_10 sorry
      thus " |.INT-2K1 i.| modINT-1K6  |.INT-2K1 j.| =COMPLEX1R1 i modINT-1K6 j &  |.INT-2K1 i.| divINT-1K5  |.INT-2K1 j.| =COMPLEX1R1 i divINT-1K5 j"
        using A4 int_1_th_48 int_1_def_10 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem int_2_th_33:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a lcmINT-2K2 b =COMPLEX1R1  |.INT-2K1 a.| lcmINT-2K2  |.INT-2K1 b.|"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a lcmINT-2K2 b =COMPLEX1R1  |.INT-2K1 a.| lcmINT-2K2  |.INT-2K1 b.|"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    have A1: " |.INT-2K1 b.| =COMPLEX1R1 b or  |.INT-2K1 b.| =COMPLEX1R1 -XCMPLX-0K4 b"
      using absvalue_th_1 sorry
    have A2: " |.INT-2K1 a.| =COMPLEX1R1 a or  |.INT-2K1 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
      using absvalue_th_1 sorry
    have A3: " for m be IntegerINT-1M1 holds  |.INT-2K1 a.| dividesINT-1R1 m &  |.INT-2K1 b.| dividesINT-1R1 m implies a lcmINT-2K2 b dividesINT-1R1 m"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be IntegerINT-1M1"
      assume " |.INT-2K1 a.| dividesINT-1R1 m &  |.INT-2K1 b.| dividesINT-1R1 m"
      then have "a dividesINT-1R1 m & b dividesINT-1R1 m"
        using A2 A1 int_2_th_10 sorry
      thus "a lcmINT-2K2 b dividesINT-1R1 m"
        using int_2_def_1 sorry
    qed "sorry"
    have "b dividesINT-1R1 a lcmINT-2K2 b"
      using int_2_def_1 sorry
    then have A4: " |.INT-2K1 b.| dividesINT-1R1 a lcmINT-2K2 b"
      using A1 int_2_th_10 sorry
    have "a dividesINT-1R1 a lcmINT-2K2 b"
      using int_2_def_1 sorry
    then have " |.INT-2K1 a.| dividesINT-1R1 a lcmINT-2K2 b"
      using A2 int_2_th_10 sorry
    thus "a lcmINT-2K2 b =COMPLEX1R1  |.INT-2K1 a.| lcmINT-2K2  |.INT-2K1 b.|"
      using A4 A3 int_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem int_2_th_34:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a gcdINT-2K3 b =COMPLEX1R1  |.INT-2K1 a.| gcdINT-2K3  |.INT-2K1 b.|"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a gcdINT-2K3 b =COMPLEX1R1  |.INT-2K1 a.| gcdINT-2K3  |.INT-2K1 b.|"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    have A1: " |.INT-2K1 b.| =COMPLEX1R1 b or  |.INT-2K1 b.| =COMPLEX1R1 -XCMPLX-0K4 b"
      using absvalue_th_1 sorry
    have A2: " |.INT-2K1 a.| =COMPLEX1R1 a or  |.INT-2K1 a.| =COMPLEX1R1 -XCMPLX-0K4 a"
      using absvalue_th_1 sorry
    have A3: " for m be IntegerINT-1M1 holds m dividesINT-1R1  |.INT-2K1 a.| & m dividesINT-1R1  |.INT-2K1 b.| implies m dividesINT-1R1 a gcdINT-2K3 b"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be IntegerINT-1M1"
      assume "m dividesINT-1R1  |.INT-2K1 a.| & m dividesINT-1R1  |.INT-2K1 b.|"
      then have "m dividesINT-1R1 a & m dividesINT-1R1 b"
        using A2 A1 int_2_th_10 sorry
      thus "m dividesINT-1R1 a gcdINT-2K3 b"
        using int_2_def_2 sorry
    qed "sorry"
    have "a gcdINT-2K3 b dividesINT-1R1 b"
      using int_2_def_2 sorry
    then have A4: "a gcdINT-2K3 b dividesINT-1R1  |.INT-2K1 b.|"
      using A1 int_2_th_10 sorry
    have "a gcdINT-2K3 b dividesINT-1R1 a"
      using int_2_def_2 sorry
    then have "a gcdINT-2K3 b dividesINT-1R1  |.INT-2K1 a.|"
      using A2 int_2_th_10 sorry
    thus "a gcdINT-2K3 b =COMPLEX1R1  |.INT-2K1 a.| gcdINT-2K3  |.INT-2K1 b.|"
      using A4 A3 int_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
