theory ordinal1
  imports funct_1 xregular
begin
(*begin*)
reserve X, Y, Z, X1, X2, X3, X4, X5, X6 for "setHIDDENM2"
reserve x, y for "objectHIDDENM1"
(*\$CT 4*)
mtheorem ordinal1_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y inTARSKIR2 X implies  not X c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y inTARSKIR2 X implies (X c=TARSKIR1 Y implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y inTARSKIR2 X"
    assume "X c=TARSKIR1 Y"
    then have "Y inTARSKIR2 Y"
      using A1 sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef ordinal1_def_1 ("succORDINAL1K1  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func succORDINAL1K1 X \<rightarrow> setHIDDENM2 equals
  X \\/XBOOLE-0K2 {TARSKIK1 X}"
proof-
  (*coherence*)
    show "X \\/XBOOLE-0K2 {TARSKIK1 X} be setHIDDENM2"
       sorry
qed "sorry"

mtheorem ordinal1_cl_1:
  mlet "X be setHIDDENM2"
"cluster succORDINAL1K1 X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "succORDINAL1K1 X be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem ordinal1_th_6:
" for X be setHIDDENM2 holds X inTARSKIR2 succORDINAL1K1 X"
proof-
  have " for X be setHIDDENM2 holds X inTARSKIR2 succORDINAL1K1 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "X inTARSKIR2 {TARSKIK1 X}"
      using tarski_def_1 sorry
    thus "X inTARSKIR2 succORDINAL1K1 X"
      using xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds succORDINAL1K1 X =XBOOLE-0R4 succORDINAL1K1 Y implies X =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds succORDINAL1K1 X =XBOOLE-0R4 succORDINAL1K1 Y & X <>HIDDENR2 Y implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "succORDINAL1K1 X =XBOOLE-0R4 succORDINAL1K1 Y"
      and A2: "X <>HIDDENR2 Y"
    have "Y inTARSKIR2 X \\/XBOOLE-0K2 {TARSKIK1 X}"
      using A1 ordinal1_th_6 sorry
    then have A3: "Y inTARSKIR2 X or Y inTARSKIR2 {TARSKIK1 X}"
      using xboole_0_def_3 sorry
    have "X inTARSKIR2 Y \\/XBOOLE-0K2 {TARSKIK1 Y}"
      using A1 ordinal1_th_6 sorry
    then have "X inTARSKIR2 Y or X inTARSKIR2 {TARSKIK1 Y}"
      using xboole_0_def_3 sorry
    thus " False "
      using A2 A3 tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_8:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 succORDINAL1K1 X iff x inHIDDENR3 X or x =HIDDENR1 X"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds (x inHIDDENR3 succORDINAL1K1 X implies x inHIDDENR3 X or x =HIDDENR1 X) & (x inHIDDENR3 X or x =HIDDENR1 X implies x inHIDDENR3 succORDINAL1K1 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 succORDINAL1K1 X implies x inHIDDENR3 X or x =HIDDENR1 X"
    proof-
      have "x inHIDDENR3 succORDINAL1K1 X implies  not ( not x inHIDDENR3 X &  not x =HIDDENR1 X)"
      proof(rule impI)
        assume "x inHIDDENR3 succORDINAL1K1 X"
        then have "x inHIDDENR3 X or x inHIDDENR3 {TARSKIK1 X}"
          using xboole_0_def_3 sorry
        thus " not ( not x inHIDDENR3 X &  not x =HIDDENR1 X)"
          using tarski_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "x inHIDDENR3 X or x =HIDDENR1 X"
    then have "x inHIDDENR3 X or x inHIDDENR3 {TARSKIK1 X}"
      using tarski_def_1 sorry
    thus "x inHIDDENR3 succORDINAL1K1 X"
      using xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_9:
" for X be setHIDDENM2 holds X <>HIDDENR2 succORDINAL1K1 X"
proof-
  have " for X be setHIDDENM2 holds X =XBOOLE-0R4 succORDINAL1K1 X implies  False "
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X =XBOOLE-0R4 succORDINAL1K1 X"
    have "X inTARSKIR2 succORDINAL1K1 X"
      using ordinal1_th_6 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve a, b, c for "objectHIDDENM1"
reserve X, Y, Z, x, y, z for "setHIDDENM2"
mdef ordinal1_def_2 ("epsilon-transitiveORDINAL1V1" 70 ) where
"attr epsilon-transitiveORDINAL1V1 for setHIDDENM2 means
  (\<lambda>X.  for x be setHIDDENM2 holds x inTARSKIR2 X implies x c=TARSKIR1 X)"..

mdef ordinal1_def_3 ("epsilon-connectedORDINAL1V2" 70 ) where
"attr epsilon-connectedORDINAL1V2 for setHIDDENM2 means
  (\<lambda>X.  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 X implies (x inTARSKIR2 y or x =XBOOLE-0R4 y) or y inTARSKIR2 x)"..

mlemma ordinal1_lm_1:
"{}XBOOLE-0K1 be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2"
   sorry

mtheorem ordinal1_cl_2:
"cluster epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2"
    using ordinal1_lm_1 sorry
qed "sorry"

mdef ordinal1_def_4 ("ordinalORDINAL1V3" 70 ) where
"attr ordinalORDINAL1V3 for objectHIDDENM1 means
  (\<lambda>IT. IT be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2)"..

mtheorem ordinal1_cl_3:
"cluster ordinalORDINAL1V3 also-is epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be ordinalORDINAL1V3 implies it be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2"
     sorry
qed "sorry"

mtheorem ordinal1_cl_4:
"cluster epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2 also-is ordinalORDINAL1V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2 implies it be ordinalORDINAL1V3"
     sorry
qed "sorry"

abbreviation(input) ORDINAL1M1("NumberORDINAL1M1" 70) where
  "NumberORDINAL1M1 \<equiv> objectHIDDENM1"

abbreviation(input) ORDINAL1M2("numberORDINAL1M2" 70) where
  "numberORDINAL1M2 \<equiv> setHIDDENM2"

mtheorem ordinal1_cl_5:
"cluster ordinalORDINAL1V3 for numberORDINAL1M2"
proof
(*existence*)
  show " ex it be numberORDINAL1M2 st it be ordinalORDINAL1V3"
    using ordinal1_lm_1 sorry
qed "sorry"

mtheorem ordinal1_cl_6:
"cluster ordinalORDINAL1V3 for NumberORDINAL1M1"
proof
(*existence*)
  show " ex it be NumberORDINAL1M1 st it be ordinalORDINAL1V3"
    using ordinal1_lm_1 sorry
qed "sorry"

syntax ORDINAL1M3 :: "Ty" ("OrdinalORDINAL1M3" 70)
translations "OrdinalORDINAL1M3" \<rightharpoonup> "ordinalORDINAL1V3\<bar>numberORDINAL1M2"

reserve A, B, C, D for "OrdinalORDINAL1M3"
mtheorem ordinal1_th_10:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be epsilon-transitiveORDINAL1V1\<bar>setHIDDENM2 holds A inTARSKIR2 B & B inTARSKIR2 C implies A inTARSKIR2 C"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  fix C assume [ty]: "C be epsilon-transitiveORDINAL1V1\<bar>setHIDDENM2"
  assume A1: "A inTARSKIR2 B"
    and A2: "B inTARSKIR2 C"
  have "B c=TARSKIR1 C"
    using A2 ordinal1_def_2 sorry
  thus "A inTARSKIR2 C"
    using A1 sorry
qed "sorry"

mtheorem ordinal1_th_11:
" for x be epsilon-transitiveORDINAL1V1\<bar>setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds x c<XBOOLE-0R2 A implies x inTARSKIR2 A"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be epsilon-transitiveORDINAL1V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be OrdinalORDINAL1M3"
  let ?a = "the ElementSUBSET-1M1-of A \\SUBSET-1K6 x"
  assume A1: "x c<XBOOLE-0R2 A"
  then have A2: "x c=TARSKIR1 A"
     sorry
  have "A \\SUBSET-1K6 x <>HIDDENR2 {}XBOOLE-0K1"
    using A1 xboole_1_th_37 xboole_1_th_60 sorry
  then have "?a inTARSKIR2 A \\SUBSET-1K6 x"
     sorry
  then obtain y where
    [ty]:"y be setHIDDENM2" and 
    A3: "y inTARSKIR2 A \\SUBSET-1K6 x"and A4: " not ( ex a be objectHIDDENM1 st a inHIDDENR3 A \\SUBSET-1K6 x & a inHIDDENR3 y)"
    using tarski_th_3 sorry
  have A5: " not y inTARSKIR2 x"
    using A3 xboole_0_def_5 sorry
  have " for a be objectHIDDENM1 holds a inHIDDENR3 x implies a inHIDDENR3 y"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be objectHIDDENM1"
    assume "a inHIDDENR3 x"
    then obtain z where
      [ty]:"z be setHIDDENM2" and 
      A6: "z =HIDDENR1 a"and A7: "z inTARSKIR2 x"
       sorry
    have "z c=TARSKIR1 x"
      using A7 ordinal1_def_2 sorry
    then have " not y inTARSKIR2 z"
      using A3 xboole_0_def_5 sorry
    thus "a inHIDDENR3 y"
      using A2 A3 A5 A6 A7 ordinal1_def_3 sorry
  qed "sorry"
  then have A8: "x c=TARSKIR1 y"
     sorry
  have A9: "y c=TARSKIR1 A"
    using A3 ordinal1_def_2 sorry
  have " for a be objectHIDDENM1 holds a inHIDDENR3 y implies a inHIDDENR3 x"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be objectHIDDENM1"
    assume A10: "a inHIDDENR3 y"
    then have " not a inHIDDENR3 A \\SUBSET-1K6 x"
      using A4 sorry
    thus "a inHIDDENR3 x"
      using A9 A10 xboole_0_def_5 sorry
  qed "sorry"
  then have A11: "y c=TARSKIR1 x"
     sorry
  have "y inTARSKIR2 A"
    using A3 sorry
  thus "x inTARSKIR2 A"
    using A11 A8 xboole_0_def_10 sorry
qed "sorry"

mtheorem ordinal1_th_12:
" for A be epsilon-transitiveORDINAL1V1\<bar>setHIDDENM2 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=TARSKIR1 B & B inTARSKIR2 C implies A inTARSKIR2 C"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix A assume [ty]: "A be epsilon-transitiveORDINAL1V1\<bar>setHIDDENM2"
  fix B assume [ty]: "B be OrdinalORDINAL1M3"
  fix C assume [ty]: "C be OrdinalORDINAL1M3"
  assume A1: "A c=TARSKIR1 B"
    and A2: "B inTARSKIR2 C"
  have "B c=TARSKIR1 C"
    using A2 ordinal1_def_2 sorry
  then have A3: "A c=TARSKIR1 C"
    using A1 sorry
  have "A <>HIDDENR2 C"
    using A1 A2 ordinal1_th_5 sorry
  then have "A c<XBOOLE-0R2 C"
    using A3 sorry
  thus "A inTARSKIR2 C"
    using ordinal1_th_11 sorry
qed "sorry"

mtheorem ordinal1_th_13:
" for a be objectHIDDENM1 holds  for A be OrdinalORDINAL1M3 holds a inHIDDENR3 A implies a be OrdinalORDINAL1M3"
proof-
  have " for a be objectHIDDENM1 holds  for A be OrdinalORDINAL1M3 holds a inHIDDENR3 A implies a be OrdinalORDINAL1M3"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "a inHIDDENR3 A"
    have 
      [ty]:"a be setHIDDENM2"
      using tarski_th_1 sorry
    have A2: "a c=TARSKIR1 A"
      using ordinal1_def_2 A1 sorry
    have " for y be setHIDDENM2 holds y inTARSKIR2 a implies ( not y c=TARSKIR1 a implies  False )"
    proof(rule ballI,rule impI,rule impI)
      fix y assume [ty]: "y be setHIDDENM2"
      assume A3: "y inTARSKIR2 a"
      then have A4: "y c=TARSKIR1 A"
        using A2 ordinal1_def_2 sorry
      assume " not y c=TARSKIR1 a"
      then obtain b where
        [ty]:"b be objectHIDDENM1" and 
        A5: "b inHIDDENR3 y &  not b inHIDDENR3 a"
         sorry
      have "b inHIDDENR3 y \\SUBSET-1K6 a"
        using A5 xboole_0_def_5 sorry
      then obtain z where
        [ty]:"z be setHIDDENM2" and 
        A6: "z inTARSKIR2 y \\SUBSET-1K6 a"and " not ( ex c be objectHIDDENM1 st c inHIDDENR3 y \\SUBSET-1K6 a & c inHIDDENR3 z)"
        using tarski_th_3 sorry
      have "z inTARSKIR2 y"
        using A6 sorry
      then have "(z inTARSKIR2 a or z =XBOOLE-0R4 a) or a inTARSKIR2 z"
        using A1 A4 ordinal1_def_3 sorry
      thus " False "
        using A3 A6 xboole_0_def_5 xregular_th_7 sorry
    qed "sorry"
    then have A7: "a be epsilon-transitiveORDINAL1V1"
       sorry
    have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 a & z inTARSKIR2 a implies (y inTARSKIR2 z or y =XBOOLE-0R4 z) or z inTARSKIR2 y"
      using A2 ordinal1_def_3 sorry
    then have "a be epsilon-connectedORDINAL1V2"
       sorry
    thus "a be OrdinalORDINAL1M3"
      using A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_14:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A inTARSKIR2 B or A =XBOOLE-0R4 B) or B inTARSKIR2 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not A inTARSKIR2 B & A <>HIDDENR2 B implies B inTARSKIR2 A"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: " not A inTARSKIR2 B"
      and A2: "A <>HIDDENR2 B"
    have " not A c<XBOOLE-0R2 B"
      using A1 ordinal1_th_11 sorry
    then have " not A c=TARSKIR1 B"
      using A2 sorry
    then obtain a where
      [ty]:"a be objectHIDDENM1" and 
      A3: "a inHIDDENR3 A &  not a inHIDDENR3 B"
       sorry
    have "a inHIDDENR3 A \\SUBSET-1K6 B"
      using A3 xboole_0_def_5 sorry
    then obtain X where
      [ty]:"X be setHIDDENM2" and 
      A4: "X inTARSKIR2 A \\SUBSET-1K6 B"and A5: " not ( ex a be objectHIDDENM1 st a inHIDDENR3 A \\SUBSET-1K6 B & a inHIDDENR3 X)"
      using tarski_th_3 sorry
    have A6: "X c=TARSKIR1 A"
      using A4 ordinal1_def_2 sorry
    have " for b be objectHIDDENM1 holds b inHIDDENR3 X implies b inHIDDENR3 B"
    proof(rule ballI,rule impI)
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A7: "b inHIDDENR3 X"
      then have " not b inHIDDENR3 A \\SUBSET-1K6 B"
        using A5 sorry
      thus "b inHIDDENR3 B"
        using A6 A7 xboole_0_def_5 sorry
    qed "sorry"
    then have "X c=TARSKIR1 B"
       sorry
    then have A8: "X c<XBOOLE-0R2 B or X =XBOOLE-0R4 B"
       sorry
    have " not X inTARSKIR2 B & X be OrdinalORDINAL1M3"
      using A4 ordinal1_th_13 xboole_0_def_5 sorry
    thus "B inTARSKIR2 A"
      using A4 A8 ordinal1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) ORDINAL1R1(" _ c=ORDINAL1R1  _ " [50,50]50) where
  "A c=ORDINAL1R1 B \<equiv> A c=TARSKIR1 B"

mtheorem ordinal1_def_5:
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"redefine pred A c=ORDINAL1R1 B means
   for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies C inTARSKIR2 B"
proof
(*compatibility*)
  show "A c=ORDINAL1R1 B iff ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies C inTARSKIR2 B)"
  proof-
    have "(A c=TARSKIR1 B implies ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies C inTARSKIR2 B)) & (( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies C inTARSKIR2 B) implies A c=TARSKIR1 B)"
    proof(rule conjMI,rule impI)
      show "A c=TARSKIR1 B implies ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies C inTARSKIR2 B)"
         sorry
      assume A1: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies C inTARSKIR2 B"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 B"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 A"
        then obtain C where 
          [ty]:"C be OrdinalORDINAL1M3" and CDef:"C = x"
          using ordinal1_th_13 sorry
        have "C inTARSKIR2 B"
          using A1 A2 sorry
        thus "x inHIDDENR3 B"
           sorry
      qed "sorry"
      thus "A c=TARSKIR1 B"
        using tarski_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ORDINAL1R1_connectedness:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not A c=ORDINAL1R1 B implies B c=ORDINAL1R1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies C inTARSKIR2 B) implies ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies C inTARSKIR2 A)"
  proof-
    have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds ( ex C be OrdinalORDINAL1M3 st C inTARSKIR2 A &  not C inTARSKIR2 B) implies ( for D be OrdinalORDINAL1M3 holds  not (D inTARSKIR2 B &  not D inTARSKIR2 A))"
    proof(rule ballI,rule ballI,rule impI,rule ballI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      fix B assume [ty]: "B be OrdinalORDINAL1M3"
      assume Given: " ex C be OrdinalORDINAL1M3 st C inTARSKIR2 A &  not C inTARSKIR2 B"
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A3: "C inTARSKIR2 A &  not C inTARSKIR2 B"
         sorry
      fix D assume [ty]: "D be OrdinalORDINAL1M3"
      have "(A inTARSKIR2 B or A =XBOOLE-0R4 B) or B inTARSKIR2 A"
        using ordinal1_th_14 sorry
      thus " not (D inTARSKIR2 B &  not D inTARSKIR2 A)"
        using A3 ordinal1_th_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using ordinal1_def_5 sorry
qed

mtheorem ordinal1_th_15:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A,B)are-c=-comparableXBOOLE-0R3"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A,B)are-c=-comparableXBOOLE-0R3"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "A c=ORDINAL1R1 B or B c=ORDINAL1R1 A"
       sorry
    thus "(A,B)are-c=-comparableXBOOLE-0R3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_16:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B or B inTARSKIR2 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not ( not A c=ORDINAL1R1 B &  not B inTARSKIR2 A)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "(A inTARSKIR2 B or A =XBOOLE-0R4 B) or B inTARSKIR2 A"
      using ordinal1_th_14 sorry
    thus " not ( not A c=ORDINAL1R1 B &  not B inTARSKIR2 A)"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_cl_7:
"cluster emptyXBOOLE-0V1 also-is ordinalORDINAL1V3 for numberORDINAL1M2"
proof
(*coherence*)
  show " for it be numberORDINAL1M2 holds it be emptyXBOOLE-0V1 implies it be ordinalORDINAL1V3"
    using ordinal1_lm_1 sorry
qed "sorry"

mtheorem ordinal1_th_17:
" for x be setHIDDENM2 holds x be OrdinalORDINAL1M3 implies succORDINAL1K1 x be OrdinalORDINAL1M3"
proof-
  have " for x be setHIDDENM2 holds x be OrdinalORDINAL1M3 implies succORDINAL1K1 x be OrdinalORDINAL1M3"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    have A1: " for y be setHIDDENM2 holds y inTARSKIR2 succORDINAL1K1 x implies y inTARSKIR2 x or y =XBOOLE-0R4 x"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be setHIDDENM2"
      have A2: "y inTARSKIR2 {TARSKIK1 x} implies y =XBOOLE-0R4 x"
        using tarski_def_1 sorry
      assume "y inTARSKIR2 succORDINAL1K1 x"
      thus "y inTARSKIR2 x or y =XBOOLE-0R4 x"
        using A2 xboole_0_def_3 sorry
    qed "sorry"
    assume A3: "x be OrdinalORDINAL1M3"
    have " for y be setHIDDENM2 holds y inTARSKIR2 succORDINAL1K1 x implies y c=TARSKIR1 succORDINAL1K1 x"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be setHIDDENM2"
      have A4: "y =XBOOLE-0R4 x implies y c=TARSKIR1 succORDINAL1K1 x"
        using xboole_1_th_7 sorry
      have A5: "y inTARSKIR2 x implies y c=TARSKIR1 succORDINAL1K1 x"
      proof(rule impI)
        assume "y inTARSKIR2 x"
        then have A6: "y c=TARSKIR1 x"
          using A3 ordinal1_def_2 sorry
        have "x c=TARSKIR1 x \\/XBOOLE-0K2 {TARSKIK1 x}"
          using xboole_1_th_7 sorry
        thus "y c=TARSKIR1 succORDINAL1K1 x"
          using A6 sorry
      qed
      assume "y inTARSKIR2 succORDINAL1K1 x"
      thus "y c=TARSKIR1 succORDINAL1K1 x"
        using A1 A5 A4 sorry
    qed "sorry"
    then have A7: "succORDINAL1K1 x be epsilon-transitiveORDINAL1V1"
       sorry
    have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 succORDINAL1K1 x & z inTARSKIR2 succORDINAL1K1 x implies (y inTARSKIR2 z or y =XBOOLE-0R4 z) or z inTARSKIR2 y"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix y assume [ty]: "y be setHIDDENM2"
      fix z assume [ty]: "z be setHIDDENM2"
      assume A8: "y inTARSKIR2 succORDINAL1K1 x"
        and A9: "z inTARSKIR2 succORDINAL1K1 x"
      have A10: "z inTARSKIR2 x or z =XBOOLE-0R4 x"
        using A1 A9 sorry
      have "y inTARSKIR2 x or y =XBOOLE-0R4 x"
        using A1 A8 sorry
      thus "(y inTARSKIR2 z or y =XBOOLE-0R4 z) or z inTARSKIR2 y"
        using A3 A10 ordinal1_def_3 sorry
    qed "sorry"
    then have "succORDINAL1K1 x be epsilon-connectedORDINAL1V2"
       sorry
    thus "succORDINAL1K1 x be OrdinalORDINAL1M3"
      using A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_18:
" for x be setHIDDENM2 holds x be ordinalORDINAL1V3 implies unionTARSKIK3 x be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2"
proof-
  have " for x be setHIDDENM2 holds x be ordinalORDINAL1V3 implies unionTARSKIK3 x be epsilon-transitiveORDINAL1V1 & unionTARSKIK3 x be epsilon-connectedORDINAL1V2"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    assume "x be ordinalORDINAL1V3"
    then obtain A where 
      [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
       sorry
    have "( for y be setHIDDENM2 holds y inTARSKIR2 unionTARSKIK3 x implies y c=TARSKIR1 unionTARSKIK3 x) & unionTARSKIK3 x be epsilon-connectedORDINAL1V2"
    proof(rule conjMI)
      show " for y be setHIDDENM2 holds y inTARSKIR2 unionTARSKIK3 x implies y c=TARSKIR1 unionTARSKIK3 x"
      proof-
        have " for y be setHIDDENM2 holds y inTARSKIR2 unionTARSKIK3 x implies y c=TARSKIR1 unionTARSKIK3 x"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be setHIDDENM2"
          assume "y inTARSKIR2 unionTARSKIK3 x"
          then obtain z where
            [ty]:"z be setHIDDENM2" and 
            A1: "y inTARSKIR2 z"and A2: "z inTARSKIR2 x"
            using tarski_def_4 sorry
          have "z inTARSKIR2 A"
            using A2 sorry
          then have 
            [ty]:"z be OrdinalORDINAL1M3"
            using ordinal1_th_13 sorry
          have "z c=ORDINAL1R1 A"
            using A2 ordinal1_def_2 sorry
          thus "y c=TARSKIR1 unionTARSKIK3 x"
            using A1 zfmisc_1_th_74 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 unionTARSKIK3 x & z inTARSKIR2 unionTARSKIK3 x implies  not (( not y inTARSKIR2 z &  not y =XBOOLE-0R4 z) &  not z inTARSKIR2 y)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix y assume [ty]: "y be setHIDDENM2"
        fix z assume [ty]: "z be setHIDDENM2"
        assume A3: "y inTARSKIR2 unionTARSKIK3 x"
          and A4: "z inTARSKIR2 unionTARSKIK3 x"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A5: "y inTARSKIR2 X"and A6: "X inTARSKIR2 x"
          using A3 tarski_def_4 sorry
        have A7: "X inTARSKIR2 A"
          using A6 sorry
        obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A8: "z inTARSKIR2 Y"and A9: "Y inTARSKIR2 x"
          using A4 tarski_def_4 sorry
        have 
          [ty]:"X be OrdinalORDINAL1M3" and
          [ty]:"Y be OrdinalORDINAL1M3"
          using A9 A7 ordinal1_th_13 sorry
        have "z inTARSKIR2 Y"
          using A8 sorry
        then have A10: "z be OrdinalORDINAL1M3"
          using ordinal1_th_13 sorry
        have "y inTARSKIR2 X"
          using A5 sorry
        then have "y be OrdinalORDINAL1M3"
          using ordinal1_th_13 sorry
        thus " not (( not y inTARSKIR2 z &  not y =XBOOLE-0R4 z) &  not z inTARSKIR2 y)"
          using A10 ordinal1_th_14 sorry
      qed "sorry"
      thus "unionTARSKIK3 x be epsilon-connectedORDINAL1V2"
        using ordinal1_def_3 sorry
    qed
    thus "unionTARSKIK3 x be epsilon-transitiveORDINAL1V1 & unionTARSKIK3 x be epsilon-connectedORDINAL1V2"
      using ordinal1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_cl_8:
"cluster  non emptyXBOOLE-0V1 for OrdinalORDINAL1M3"
proof
(*existence*)
  show " ex it be OrdinalORDINAL1M3 st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar1 be OrdinalORDINAL1M3 st  not tVar1 be emptyXBOOLE-0V1"
    proof-
      obtain A where 
        [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = succORDINAL1K1 ({}XBOOLE-0K1)"
        using ordinal1_th_17 sorry
      show " ex tVar1 be OrdinalORDINAL1M3 st  not tVar1 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "A"])
        show " not A be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_9:
  mlet "A be OrdinalORDINAL1M3"
"cluster succORDINAL1K1 A as-term-is  non emptyXBOOLE-0V1\<bar>ordinalORDINAL1V3"
proof
(*coherence*)
  show "succORDINAL1K1 A be  non emptyXBOOLE-0V1\<bar>ordinalORDINAL1V3"
    using ordinal1_th_17 sorry
qed "sorry"

mtheorem ordinal1_cl_10:
  mlet "A be OrdinalORDINAL1M3"
"cluster unionTARSKIK3 A as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "unionTARSKIK3 A be ordinalORDINAL1V3"
    using ordinal1_th_18 sorry
qed "sorry"

mtheorem ordinal1_th_19:
" for X be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies x be OrdinalORDINAL1M3 & x c=TARSKIR1 X) implies X be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2"
proof-
  have " for X be setHIDDENM2 holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies x be OrdinalORDINAL1M3 & x c=TARSKIR1 X) implies X be epsilon-transitiveORDINAL1V1 & X be epsilon-connectedORDINAL1V2"
  proof(rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for x be setHIDDENM2 holds x inTARSKIR2 X implies x be OrdinalORDINAL1M3 & x c=TARSKIR1 X"
    show "X be epsilon-transitiveORDINAL1V1"
      using A1 sorry
    have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 X implies  not (( not x inTARSKIR2 y &  not x =XBOOLE-0R4 y) &  not y inTARSKIR2 x)"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      fix y assume [ty]: "y be setHIDDENM2"
      assume "x inTARSKIR2 X & y inTARSKIR2 X"
      then have "x be OrdinalORDINAL1M3 & y be OrdinalORDINAL1M3"
        using A1 sorry
      thus " not (( not x inTARSKIR2 y &  not x =XBOOLE-0R4 y) &  not y inTARSKIR2 x)"
        using ordinal1_th_14 sorry
    qed "sorry"
    thus "X be epsilon-connectedORDINAL1V2"
      using ordinal1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_20:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 A & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex C be OrdinalORDINAL1M3 st C inTARSKIR2 X & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 X implies C c=ORDINAL1R1 B))"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 A & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar2 be OrdinalORDINAL1M3 st tVar2 inTARSKIR2 X & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 X implies tVar2 c=ORDINAL1R1 B))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?a = "the ElementSUBSET-1M1-of X"
    assume A1: "X c=TARSKIR1 A"
      and A2: "X <>HIDDENR2 {}XBOOLE-0K1"
    have "?a inTARSKIR2 X"
      using A2 sorry
    then obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A3: "Y inTARSKIR2 X"and A4: " not ( ex a be objectHIDDENM1 st a inHIDDENR3 X & a inHIDDENR3 Y)"
      using tarski_th_3 sorry
    have "Y be OrdinalORDINAL1M3"
      using A1 A3 ordinal1_th_13 sorry
    then obtain C where
      [ty]:"C be OrdinalORDINAL1M3" and 
      A5: "C =XBOOLE-0R4 Y"
       sorry
    show " ex tVar2 be OrdinalORDINAL1M3 st tVar2 inTARSKIR2 X & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 X implies tVar2 c=ORDINAL1R1 B)"
    proof(rule bexI[of _ "C"],rule conjMI,rule ballI,rule impI)
      show "C inTARSKIR2 X"
        using A3 A5 sorry
      fix B assume [ty]: "B be OrdinalORDINAL1M3"
      assume "B inTARSKIR2 X"
      then have " not B inTARSKIR2 C"
        using A4 A5 sorry
      then have "B =XBOOLE-0R4 C or C inTARSKIR2 B"
        using ordinal1_th_14 sorry
      thus "C c=ORDINAL1R1 B"
        using ordinal1_def_2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_21:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B iff succORDINAL1K1 A c=ORDINAL1R1 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A inTARSKIR2 B implies succORDINAL1K1 A c=ORDINAL1R1 B) & (succORDINAL1K1 A c=ORDINAL1R1 B implies A inTARSKIR2 B)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    show "A inTARSKIR2 B implies succORDINAL1K1 A c=ORDINAL1R1 B"
    proof(rule impI)
      assume A1: "A inTARSKIR2 B"
      then have " for a be objectHIDDENM1 holds a inHIDDENR3 {TARSKIK1 A} implies a inHIDDENR3 B"
        using tarski_def_1 sorry
      then have A2: "{TARSKIK1 A} c=TARSKIR1 B"
         sorry
      have "A c=ORDINAL1R1 B"
        using A1 ordinal1_def_2 sorry
      thus "succORDINAL1K1 A c=ORDINAL1R1 B"
        using A2 xboole_1_th_8 sorry
    qed
    assume A3: "succORDINAL1K1 A c=ORDINAL1R1 B"
    have "A inTARSKIR2 succORDINAL1K1 A"
      using ordinal1_th_6 sorry
    thus "A inTARSKIR2 B"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_22:
" for A be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 succORDINAL1K1 C iff A c=ORDINAL1R1 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds (A inTARSKIR2 succORDINAL1K1 C implies A c=ORDINAL1R1 C) & (A c=ORDINAL1R1 C implies ( not A inTARSKIR2 succORDINAL1K1 C implies  False ))"
  proof(rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    show "A inTARSKIR2 succORDINAL1K1 C implies A c=ORDINAL1R1 C"
    proof(rule impI)
      assume "A inTARSKIR2 succORDINAL1K1 C"
      then have "A inTARSKIR2 C or A inTARSKIR2 {TARSKIK1 C}"
        using xboole_0_def_3 sorry
      thus "A c=ORDINAL1R1 C"
        using ordinal1_def_2 tarski_def_1 sorry
    qed
    assume A1: "A c=ORDINAL1R1 C"
    assume " not A inTARSKIR2 succORDINAL1K1 C"
    then have "A =XBOOLE-0R4 succORDINAL1K1 C or succORDINAL1K1 C inTARSKIR2 A"
      using ordinal1_th_14 sorry
    then have A2: "succORDINAL1K1 C c=ORDINAL1R1 C"
      using A1 ordinal1_def_2 sorry
    have "C inTARSKIR2 succORDINAL1K1 C"
      using ordinal1_th_6 sorry
    then have "C c=ORDINAL1R1 succORDINAL1K1 C"
      using ordinal1_def_2 sorry
    then have "succORDINAL1K1 C =XBOOLE-0R4 C"
      using A2 sorry
    thus " False "
      using ordinal1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem ordinal1_sch_1:
  fixes Pp1 
  assumes
    A1: " ex A be OrdinalORDINAL1M3 st Pp1(A)"
  shows " ex A be OrdinalORDINAL1M3 st Pp1(A) & ( for B be OrdinalORDINAL1M3 holds Pp1(B) implies A c=ORDINAL1R1 B)"
  proof-
    have " ex tVar3 be OrdinalORDINAL1M3 st Pp1(tVar3) & ( for B be OrdinalORDINAL1M3 holds Pp1(B) implies ( not tVar3 c=ORDINAL1R1 B implies  False ))"
    proof-
      obtain A where
        [ty]:"A be OrdinalORDINAL1M3" and 
        A2: "Pp1(A)"
        using A1 sorry
      let ?R = "\<lambda>Lamb1.  ex B be OrdinalORDINAL1M3 st Lamb1 =HIDDENR1 B & Pp1(B)"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 succORDINAL1K1 A & ?R(x)"
        using xboole_0_sch_1 sorry
      have " for a be objectHIDDENM1 holds a inHIDDENR3 X implies a inHIDDENR3 succORDINAL1K1 A"
        using A3 sorry
      then have A4: "X c=TARSKIR1 succORDINAL1K1 A"
         sorry
      have "A inTARSKIR2 succORDINAL1K1 A"
        using ordinal1_th_6 sorry
      then have "X <>HIDDENR2 {}XBOOLE-0K1"
        using A2 A3 sorry
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A5: "C inTARSKIR2 X"and A6: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 X implies C c=ORDINAL1R1 B"
        using A4 ordinal1_th_20 sorry
      have "C inTARSKIR2 succORDINAL1K1 A"
        using A3 A5 sorry
      then have A7: "C c=ORDINAL1R1 succORDINAL1K1 A"
        using ordinal1_def_2 sorry
      show " ex tVar3 be OrdinalORDINAL1M3 st Pp1(tVar3) & ( for B be OrdinalORDINAL1M3 holds Pp1(B) implies ( not tVar3 c=ORDINAL1R1 B implies  False ))"
      proof(rule bexI[of _ "C"],rule conjMI,rule ballI,rule impI,rule impI)
        have " ex B be OrdinalORDINAL1M3 st C =XBOOLE-0R4 B & Pp1(B)"
          using A3 A5 sorry
        thus "Pp1(C)"
           sorry
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A8: "Pp1(B)"
        assume A9: " not C c=ORDINAL1R1 B"
        then have "B c<XBOOLE-0R2 C"
           sorry
        then have "B inTARSKIR2 C"
          using ordinal1_th_11 sorry
        then have "B inTARSKIR2 X"
          using A3 A8 A7 sorry
        thus " False "
          using A6 A9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

(*\$N Transfinite induction*)
theorem ordinal1_sch_2:
  fixes Pp1 
  assumes
    A1: " for A be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies Pp1(C)) implies Pp1(A)"
  shows " for A be OrdinalORDINAL1M3 holds Pp1(A)"
  proof(rule ballI)
    let ?R = "\<lambda>Lamb1.  ex B be OrdinalORDINAL1M3 st Lamb1 =HIDDENR1 B & Pp1(B)"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?Y = "succORDINAL1K1 A"
    obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Z iff x inHIDDENR3 ?Y & ?R(x)"
      using xboole_0_sch_1 sorry
    have "succORDINAL1K1 A \\SUBSET-1K6 Z <>HIDDENR2 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume "?Y \\SUBSET-1K6 Z <>HIDDENR2 {}XBOOLE-0K1"
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A3: "C inTARSKIR2 ?Y \\SUBSET-1K6 Z"and A4: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 ?Y \\SUBSET-1K6 Z implies C c=ORDINAL1R1 B"
        using ordinal1_th_20 sorry
      have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 C implies Pp1(B)"
      proof(rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A5: "B inTARSKIR2 C"
        have A6: "C c=ORDINAL1R1 ?Y"
          using A3 ordinal1_def_2 sorry
        have " not B inTARSKIR2 Z implies  False "
        proof(rule impI)
          assume " not B inTARSKIR2 Z"
          then have "B inTARSKIR2 ?Y \\SUBSET-1K6 Z"
            using A5 A6 xboole_0_def_5 sorry
          then have A7: "C c=ORDINAL1R1 B"
            using A4 sorry
          have "C <>HIDDENR2 B"
            using A5 sorry
          then have "C c<XBOOLE-0R2 B"
            using A7 sorry
          thus " False "
            using A5 ordinal1_th_11 sorry
        qed
        then have " ex B9 be OrdinalORDINAL1M3 st B =XBOOLE-0R4 B9 & Pp1(B9)"
          using A2 sorry
        thus "Pp1(B)"
           sorry
      qed "sorry"
      then have A8: "Pp1(C)"
        using A1 sorry
      have " not C inTARSKIR2 Z"
        using A3 xboole_0_def_5 sorry
      thus " False "
        using A2 A3 A8 sorry
    qed
    then have " not A inTARSKIR2 ?Y or A inTARSKIR2 Z"
      using xboole_0_def_5 sorry
    then have " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 B & Pp1(B)"
      using A2 ordinal1_th_6 sorry
    thus "Pp1(A)"
       sorry
  qed "sorry"

mtheorem ordinal1_th_23:
" for X be setHIDDENM2 holds ( for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be OrdinalORDINAL1M3) implies unionTARSKIK3 X be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2"
proof-
  have " for X be setHIDDENM2 holds ( for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be OrdinalORDINAL1M3) implies unionTARSKIK3 X be epsilon-transitiveORDINAL1V1 & unionTARSKIK3 X be epsilon-connectedORDINAL1V2"
  proof(rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be OrdinalORDINAL1M3"
    show "unionTARSKIK3 X be epsilon-transitiveORDINAL1V1"
    proof-
      have " for x be setHIDDENM2 holds x inTARSKIR2 unionTARSKIK3 X implies x c=TARSKIR1 unionTARSKIK3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 unionTARSKIK3 X"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A2: "x inTARSKIR2 Y"and A3: "Y inTARSKIR2 X"
          using tarski_def_4 sorry
        have "Y be OrdinalORDINAL1M3"
          using A1 A3 sorry
        then have A4: "x c=TARSKIR1 Y"
          using A2 ordinal1_def_2 sorry
        have " for a be objectHIDDENM1 holds a inHIDDENR3 x implies a inHIDDENR3 unionTARSKIK3 X"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 x"
          thus "a inHIDDENR3 unionTARSKIK3 X"
            using A3 A4 tarski_def_4 sorry
        qed "sorry"
        thus "x c=TARSKIR1 unionTARSKIK3 X"
          using tarski_def_3 sorry
      qed "sorry"
      thus "unionTARSKIK3 X be epsilon-transitiveORDINAL1V1"
        using ordinal1_def_2 sorry
    qed
    have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 unionTARSKIK3 X & y inTARSKIR2 unionTARSKIK3 X implies  not (( not x inTARSKIR2 y &  not x =XBOOLE-0R4 y) &  not y inTARSKIR2 x)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      fix y assume [ty]: "y be setHIDDENM2"
      assume A5: "x inTARSKIR2 unionTARSKIK3 X"
        and A6: "y inTARSKIR2 unionTARSKIK3 X"
      obtain Z where
        [ty]:"Z be setHIDDENM2" and 
        A7: "y inTARSKIR2 Z"and A8: "Z inTARSKIR2 X"
        using A6 tarski_def_4 sorry
      have "Z be OrdinalORDINAL1M3"
        using A1 A8 sorry
      then have A9: "y be OrdinalORDINAL1M3"
        using A7 ordinal1_th_13 sorry
      obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A10: "x inTARSKIR2 Y"and A11: "Y inTARSKIR2 X"
        using A5 tarski_def_4 sorry
      have "Y be OrdinalORDINAL1M3"
        using A1 A11 sorry
      then have "x be OrdinalORDINAL1M3"
        using A10 ordinal1_th_13 sorry
      thus " not (( not x inTARSKIR2 y &  not x =XBOOLE-0R4 y) &  not y inTARSKIR2 x)"
        using A9 ordinal1_th_14 sorry
    qed "sorry"
    thus "unionTARSKIK3 X be epsilon-connectedORDINAL1V2"
      using ordinal1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_24:
" for X be setHIDDENM2 holds ( for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be OrdinalORDINAL1M3) implies ( ex A be OrdinalORDINAL1M3 st X c=TARSKIR1 A)"
proof-
  have " for X be setHIDDENM2 holds ( for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be OrdinalORDINAL1M3) implies ( ex tVar4 be OrdinalORDINAL1M3 st X c=TARSKIR1 tVar4)"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be OrdinalORDINAL1M3"
    then have A2: "unionTARSKIK3 X be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2"
      using ordinal1_th_23 sorry
    then obtain A where 
      [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = succORDINAL1K1 (unionTARSKIK3 X)"
       sorry
    show " ex tVar4 be OrdinalORDINAL1M3 st X c=TARSKIR1 tVar4"
    proof(rule bexI[of _ "A"])
      have " for a be objectHIDDENM1 holds a inHIDDENR3 X implies a inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A3: "a inHIDDENR3 X"
        then obtain B where 
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = a"
          using A1 sorry
        have " for b be objectHIDDENM1 holds b inHIDDENR3 B implies b inHIDDENR3 unionTARSKIK3 X"
          using A3 tarski_def_4 sorry
        then have "B c=TARSKIR1 unionTARSKIK3 X"
           sorry
        thus "a inHIDDENR3 A"
          using A2 ordinal1_th_22 sorry
      qed "sorry"
      thus "X c=TARSKIR1 A"
        using tarski_def_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_25:
" not ( ex X be setHIDDENM2 st  for x be setHIDDENM2 holds x inTARSKIR2 X iff x be OrdinalORDINAL1M3)"
proof-
  have "( ex X be setHIDDENM2 st  for x be setHIDDENM2 holds x inTARSKIR2 X iff x be OrdinalORDINAL1M3) implies  False "
  proof(rule impI)
    assume Given: " ex X be setHIDDENM2 st  for x be setHIDDENM2 holds x inTARSKIR2 X iff x be OrdinalORDINAL1M3"
    then obtain X where
      [ty]:"X be setHIDDENM2" and 
      A1: " for x be setHIDDENM2 holds x inTARSKIR2 X iff x be OrdinalORDINAL1M3"
       sorry
    have A2: "X be epsilon-transitiveORDINAL1V1"
    proof-
      have " for x be setHIDDENM2 holds x inTARSKIR2 X implies x c=TARSKIR1 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 X"
        then have A3: "x be OrdinalORDINAL1M3"
          using A1 sorry
        show "x c=TARSKIR1 X"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 x implies a inHIDDENR3 X"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 x"
            then have "a be OrdinalORDINAL1M3"
              using A3 ordinal1_th_13 sorry
            thus "a inHIDDENR3 X"
              using A1 sorry
          qed "sorry"
          thus "x c=TARSKIR1 X"
            using tarski_def_3 sorry
        qed
      qed "sorry"
      thus "X be epsilon-transitiveORDINAL1V1"
        using ordinal1_def_2 sorry
    qed
    have "X be epsilon-connectedORDINAL1V2"
    proof-
      have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 X implies  not (( not x inTARSKIR2 y &  not x =XBOOLE-0R4 y) &  not y inTARSKIR2 x)"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        fix y assume [ty]: "y be setHIDDENM2"
        assume "x inTARSKIR2 X & y inTARSKIR2 X"
        then have "x be OrdinalORDINAL1M3 & y be OrdinalORDINAL1M3"
          using A1 sorry
        thus " not (( not x inTARSKIR2 y &  not x =XBOOLE-0R4 y) &  not y inTARSKIR2 x)"
          using ordinal1_th_14 sorry
      qed "sorry"
      thus "X be epsilon-connectedORDINAL1V2"
        using ordinal1_def_3 sorry
    qed
    then have "X inTARSKIR2 X"
      using A1 A2 sorry
    thus " False "
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_26:
" not ( ex X be setHIDDENM2 st  for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X)"
proof-
  have "( ex X be setHIDDENM2 st  for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X) implies  False "
  proof(rule impI)
    let ?P = "\<lambda>Lamb1. Lamb1 be OrdinalORDINAL1M3"
    assume Given: " ex X be setHIDDENM2 st  for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X"
    then obtain X where
      [ty]:"X be setHIDDENM2" and 
      A1: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X"
       sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A2: " for a be objectHIDDENM1 holds a inHIDDENR3 Y iff a inHIDDENR3 X & ?P(a)"
      using xboole_0_sch_1 sorry
    have " for x be setHIDDENM2 holds x be OrdinalORDINAL1M3 implies x inTARSKIR2 Y"
      using A1 A2 sorry
    then have " for x be setHIDDENM2 holds x inTARSKIR2 Y iff x be OrdinalORDINAL1M3"
      using A2 sorry
    thus " False "
      using ordinal1_th_25 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_27:
" for X be setHIDDENM2 holds  ex A be OrdinalORDINAL1M3 st  not A inTARSKIR2 X & ( for B be OrdinalORDINAL1M3 holds  not B inTARSKIR2 X implies A c=ORDINAL1R1 B)"
proof-
  have " for X be setHIDDENM2 holds  ex tVar5 be OrdinalORDINAL1M3 st  not tVar5 inTARSKIR2 X & ( for C be OrdinalORDINAL1M3 holds  not C inTARSKIR2 X implies ( not tVar5 c=ORDINAL1R1 C implies  False ))"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  not Lamb1 inHIDDENR3 X"
    obtain B where
      [ty]:"B be OrdinalORDINAL1M3" and 
      A1: " not B inTARSKIR2 X"
      using ordinal1_th_26 sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A2: " for a be objectHIDDENM1 holds a inHIDDENR3 Y iff a inHIDDENR3 succORDINAL1K1 B & ?P(a)"
      using xboole_0_sch_1 sorry
    have " for a be objectHIDDENM1 holds a inHIDDENR3 Y implies a inHIDDENR3 succORDINAL1K1 B"
      using A2 sorry
    then have A3: "Y c=TARSKIR1 succORDINAL1K1 B"
       sorry
    have "B inTARSKIR2 succORDINAL1K1 B"
      using ordinal1_th_6 sorry
    then have "Y <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A2 sorry
    then obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A4: "A inTARSKIR2 Y"and A5: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 Y implies A c=ORDINAL1R1 B"
      using A3 ordinal1_th_20 sorry
    have "A inTARSKIR2 succORDINAL1K1 B"
      using A2 A4 sorry
    then have A6: "A c=ORDINAL1R1 succORDINAL1K1 B"
      using ordinal1_def_2 sorry
    show " ex tVar5 be OrdinalORDINAL1M3 st  not tVar5 inTARSKIR2 X & ( for C be OrdinalORDINAL1M3 holds  not C inTARSKIR2 X implies ( not tVar5 c=ORDINAL1R1 C implies  False ))"
    proof(rule bexI[of _ "A"],rule conjMI,rule ballI,rule impI,rule impI)
      show " not A inTARSKIR2 X"
        using A2 A4 sorry
      fix C assume [ty]: "C be OrdinalORDINAL1M3"
      assume A7: " not C inTARSKIR2 X"
      assume A8: " not A c=ORDINAL1R1 C"
      then have " not A inTARSKIR2 C"
        using ordinal1_def_2 sorry
      then have "C inTARSKIR2 A"
        using A8 ordinal1_th_14 sorry
      then have "C inTARSKIR2 Y"
        using A2 A7 A6 sorry
      thus " False "
        using A5 A8 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef ordinal1_def_6 ("limit-ordinalORDINAL1V4" 70 ) where
"attr limit-ordinalORDINAL1V4 for setHIDDENM2 means
  (\<lambda>A. A =XBOOLE-0R4 unionTARSKIK3 A)"..

mtheorem ordinal1_th_28:
" for A be OrdinalORDINAL1M3 holds A be limit-ordinalORDINAL1V4 iff ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies succORDINAL1K1 C inTARSKIR2 A)"
proof-
  have " for A be OrdinalORDINAL1M3 holds (A be limit-ordinalORDINAL1V4 implies ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies succORDINAL1K1 C inTARSKIR2 A)) & (( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies succORDINAL1K1 C inTARSKIR2 A) implies A be limit-ordinalORDINAL1V4)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "A be limit-ordinalORDINAL1V4 implies ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies succORDINAL1K1 C inTARSKIR2 A)"
    proof(rule impI,rule ballI,rule impI)
      assume "A be limit-ordinalORDINAL1V4"
      then have A1: "A =XBOOLE-0R4 unionTARSKIK3 A"
         sorry
      fix C assume [ty]: "C be OrdinalORDINAL1M3"
      assume "C inTARSKIR2 A"
      then obtain z where
        [ty]:"z be setHIDDENM2" and 
        A2: "C inTARSKIR2 z"and A3: "z inTARSKIR2 A"
        using A1 tarski_def_4 sorry
      have " for b be objectHIDDENM1 holds b inHIDDENR3 {TARSKIK1 C} implies b inHIDDENR3 z"
        using A2 tarski_def_1 sorry
      then have A4: "{TARSKIK1 C} c=TARSKIR1 z"
         sorry
      have A5: "z be OrdinalORDINAL1M3"
        using A3 ordinal1_th_13 sorry
      then have "C c=TARSKIR1 z"
        using A2 ordinal1_def_2 sorry
      then have "succORDINAL1K1 C c=TARSKIR1 z"
        using A4 xboole_1_th_8 sorry
      then have "succORDINAL1K1 C =XBOOLE-0R4 z or succORDINAL1K1 C c<XBOOLE-0R2 z"
         sorry
      then have A6: "succORDINAL1K1 C =XBOOLE-0R4 z or succORDINAL1K1 C inTARSKIR2 z"
        using A5 ordinal1_th_11 sorry
      have "z c=TARSKIR1 A"
        using A3 ordinal1_def_2 sorry
      thus "succORDINAL1K1 C inTARSKIR2 A"
        using A3 A6 sorry
    qed "sorry"
    assume A7: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies succORDINAL1K1 C inTARSKIR2 A"
    have " for a be objectHIDDENM1 holds a inHIDDENR3 A implies a inHIDDENR3 unionTARSKIK3 A"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      obtain aa where 
        [ty]:"aa be setHIDDENM2" and aaDef:"aa = a"
        using tarski_th_1 sorry
      assume A8: "a inHIDDENR3 A"
      then have "a be OrdinalORDINAL1M3"
        using ordinal1_th_13 sorry
      then have A9: "succORDINAL1K1 aa inTARSKIR2 A"
        using A7 A8 sorry
      have "a inHIDDENR3 succORDINAL1K1 aa"
        using ordinal1_th_6 sorry
      thus "a inHIDDENR3 unionTARSKIK3 A"
        using A9 tarski_def_4 sorry
    qed "sorry"
    then have A10: "A c=ORDINAL1R1 unionTARSKIK3 A"
       sorry
    have " for a be objectHIDDENM1 holds a inHIDDENR3 unionTARSKIK3 A implies a inHIDDENR3 A"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume "a inHIDDENR3 unionTARSKIK3 A"
      then obtain z where
        [ty]:"z be setHIDDENM2" and 
        A11: "a inHIDDENR3 z"and A12: "z inTARSKIR2 A"
        using tarski_def_4 sorry
      have "z c=TARSKIR1 A"
        using A12 ordinal1_def_2 sorry
      thus "a inHIDDENR3 A"
        using A11 sorry
    qed "sorry"
    then have "unionTARSKIK3 A c=ORDINAL1R1 A"
       sorry
    then have "A =XBOOLE-0R4 unionTARSKIK3 A"
      using A10 sorry
    thus "A be limit-ordinalORDINAL1V4"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_th_29:
" for A be OrdinalORDINAL1M3 holds  not A be limit-ordinalORDINAL1V4 iff ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B)"
proof-
  have " for A be OrdinalORDINAL1M3 holds ( not A be limit-ordinalORDINAL1V4 implies ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B)) & (( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies  not A be limit-ordinalORDINAL1V4)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show " not A be limit-ordinalORDINAL1V4 implies ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B)"
    proof-
      have " not A be limit-ordinalORDINAL1V4 implies ( ex tVar6 be OrdinalORDINAL1M3 st A <>HIDDENR2 succORDINAL1K1 tVar6 implies  False )"
      proof(rule impI)
        assume " not A be limit-ordinalORDINAL1V4"
        then obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A1: "B inTARSKIR2 A"and A2: " not succORDINAL1K1 B inTARSKIR2 A"
          using ordinal1_th_28 sorry
        show " ex tVar6 be OrdinalORDINAL1M3 st A <>HIDDENR2 succORDINAL1K1 tVar6 implies  False "
        proof(rule bexI[of _ "B"],rule impI)
          assume A3: "A <>HIDDENR2 succORDINAL1K1 B"
          have "succORDINAL1K1 B c=ORDINAL1R1 A"
            using A1 ordinal1_th_21 sorry
          then have "succORDINAL1K1 B c<XBOOLE-0R2 A"
            using A3 sorry
          thus " False "
            using A2 ordinal1_th_11 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
    then obtain B where
      [ty]:"B be OrdinalORDINAL1M3" and 
      A4: "A =XBOOLE-0R4 succORDINAL1K1 B"
       sorry
    have "B inTARSKIR2 A &  not succORDINAL1K1 B inTARSKIR2 A"
      using A4 ordinal1_th_6 sorry
    thus " not A be limit-ordinalORDINAL1V4"
      using ordinal1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve F, G for "FunctionFUNCT-1M1"
mdef ordinal1_def_7 ("Sequence-likeORDINAL1V5" 70 ) where
"attr Sequence-likeORDINAL1V5 for setHIDDENM2 means
  (\<lambda>IT. proj1XTUPLE-0K12 IT be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2)"..

mtheorem ordinal1_cl_11:
"cluster emptyXBOOLE-0V1 also-is Sequence-likeORDINAL1V5 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

syntax ORDINAL1M4 :: "Ty" ("SequenceORDINAL1M4" 70)
translations "SequenceORDINAL1M4" \<rightharpoonup> "Sequence-likeORDINAL1V5\<bar>FunctionFUNCT-1M1"

mtheorem ordinal1_cl_12:
  mlet "Z be setHIDDENM2"
"cluster Z -valuedRELAT-1V5 for SequenceORDINAL1M4"
proof
(*existence*)
  show " ex it be SequenceORDINAL1M4 st it be Z -valuedRELAT-1V5"
  proof-
    have " ex tVar7 be SequenceORDINAL1M4 st tVar7 be Z -valuedRELAT-1V5"
    proof-
      obtain L where 
        [ty]:"L be SequenceORDINAL1M4" and LDef:"L = {}XBOOLE-0K1"
         sorry
      show " ex tVar7 be SequenceORDINAL1M4 st tVar7 be Z -valuedRELAT-1V5"
      proof(rule bexI[of _ "L"])
        have "rngFUNCT-1K2 L c=TARSKIR1 Z"
        proof-
          show "rngFUNCT-1K2 L c=TARSKIR1 Z"
             sorry
        qed
        thus "L be Z -valuedRELAT-1V5"
          using relat_1_def_19 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax ORDINAL1M5 :: " Set \<Rightarrow> Ty" ("SequenceORDINAL1M5-of  _ " [70]70)
translations "SequenceORDINAL1M5-of Z" \<rightharpoonup> "Z -valuedRELAT-1V5\<bar>SequenceORDINAL1M4"

mtheorem ordinal1_th_30:
" for Z be setHIDDENM2 holds {}XBOOLE-0K1 be SequenceORDINAL1M5-of Z"
proof-
  have " for Z be setHIDDENM2 holds {}XBOOLE-0K1 be SequenceORDINAL1M5-of Z"
  proof(rule ballI)
    fix Z assume [ty]: "Z be setHIDDENM2"
    obtain L where 
      [ty]:"L be SequenceORDINAL1M4" and LDef:"L = {}XBOOLE-0K1"
       sorry
    have "rngFUNCT-1K2 L c=TARSKIR1 Z"
       sorry
    thus "{}XBOOLE-0K1 be SequenceORDINAL1M5-of Z"
      using relat_1_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve L, L1 for "SequenceORDINAL1M4"
mtheorem ordinal1_th_31:
" for F be FunctionFUNCT-1M1 holds domRELAT-1K1 F be OrdinalORDINAL1M3 implies F be SequenceORDINAL1M5-of rngFUNCT-1K2 F"
  using ordinal1_def_7 relat_1_def_19 sorry

mtheorem ordinal1_cl_13:
  mlet "L be SequenceORDINAL1M4"
"cluster domRELAT-1K1 L as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "domRELAT-1K1 L be ordinalORDINAL1V3"
    using ordinal1_def_7 sorry
qed "sorry"

mtheorem ordinal1_th_32:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies ( for L be SequenceORDINAL1M5-of X holds L be SequenceORDINAL1M5-of Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies ( for L be SequenceORDINAL1M5-of X holds L be SequenceORDINAL1M5-of Y)"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    fix L assume [ty]: "L be SequenceORDINAL1M5-of X"
    have "rngFUNCT-1K2 L c=TARSKIR1 X"
      using relat_1_def_19 sorry
    then have "rngFUNCT-1K2 L c=TARSKIR1 Y"
      using A1 sorry
    thus "L be SequenceORDINAL1M5-of Y"
      using relat_1_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_cl_14:
  mlet "L be SequenceORDINAL1M4", "A be OrdinalORDINAL1M3"
"cluster L  |RELAT-1K8 A as-term-is rngFUNCT-1K2 L -valuedRELAT-1V5\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "L  |RELAT-1K8 A be rngFUNCT-1K2 L -valuedRELAT-1V5\<bar>Sequence-likeORDINAL1V5"
  proof-
    have "L  |RELAT-1K8 A be rngFUNCT-1K2 L -valuedRELAT-1V5 & L  |RELAT-1K8 A be Sequence-likeORDINAL1V5"
    proof-
      have A1: "rngFUNCT-1K2 (L  |RELAT-1K8 A) c=TARSKIR1 rngFUNCT-1K2 L"
        using relat_1_th_70 sorry
      have "A c=ORDINAL1R1 domRELAT-1K1 L implies domRELAT-1K1 (L  |RELAT-1K8 A) =XBOOLE-0R4 A"
        using relat_1_th_62 sorry
      thus "L  |RELAT-1K8 A be rngFUNCT-1K2 L -valuedRELAT-1V5 & L  |RELAT-1K8 A be Sequence-likeORDINAL1V5"
        using A1 relat_1_th_68 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_th_33:
" for X be setHIDDENM2 holds  for L be SequenceORDINAL1M5-of X holds  for A be OrdinalORDINAL1M3 holds L  |RELAT-1K8 A be SequenceORDINAL1M5-of X"
   sorry

mdef ordinal1_def_8 ("c=-linearORDINAL1V6" 70 ) where
"attr c=-linearORDINAL1V6 for setHIDDENM2 means
  (\<lambda>IT.  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 IT & y inTARSKIR2 IT implies (x,y)are-c=-comparableXBOOLE-0R3)"..

mtheorem ordinal1_th_34:
" for X be setHIDDENM2 holds ( for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be SequenceORDINAL1M4) & X be c=-linearORDINAL1V6 implies unionTARSKIK3 X be SequenceORDINAL1M4"
proof-
  have " for X be setHIDDENM2 holds ( for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be SequenceORDINAL1M4) & X be c=-linearORDINAL1V6 implies unionTARSKIK3 X be SequenceORDINAL1M4"
  proof(rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for a be objectHIDDENM1 holds a inHIDDENR3 X implies a be SequenceORDINAL1M4"
      and A2: "X be c=-linearORDINAL1V6"
    have "unionTARSKIK3 X be Relation-likeRELAT-1V1\<bar>Function-likeFUNCT-1V1"
    proof-
      have "unionTARSKIK3 X be Relation-likeRELAT-1V1 & unionTARSKIK3 X be Function-likeFUNCT-1V1"
      proof-
        have "( for a be objectHIDDENM1 holds a inHIDDENR3 unionTARSKIK3 X implies ( ex b be objectHIDDENM1 st  ex c be objectHIDDENM1 st [TARSKIK4 b,c ] =HIDDENR1 a)) & unionTARSKIK3 X be Function-likeFUNCT-1V1"
        proof(rule conjMI)
          show " for a be objectHIDDENM1 holds a inHIDDENR3 unionTARSKIK3 X implies ( ex b be objectHIDDENM1 st  ex c be objectHIDDENM1 st [TARSKIK4 b,c ] =HIDDENR1 a)"
          proof-
            have " for a be objectHIDDENM1 holds a inHIDDENR3 unionTARSKIK3 X implies  not ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not [TARSKIK4 b,c ] =HIDDENR1 a)"
            proof(rule ballI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              assume "a inHIDDENR3 unionTARSKIK3 X"
              then obtain x where
                [ty]:"x be setHIDDENM2" and 
                A3: "a inHIDDENR3 x"and A4: "x inTARSKIR2 X"
                using tarski_def_4 sorry
              have 
                [ty]:"x be SequenceORDINAL1M4"
                using A1 A4 sorry
              have " for a be objectHIDDENM1 holds a inHIDDENR3 x implies ( ex b be objectHIDDENM1 st  ex c be objectHIDDENM1 st [TARSKIK4 b,c ] =HIDDENR1 a)"
                using relat_1_def_1 sorry
              thus " not ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not [TARSKIK4 b,c ] =HIDDENR1 a)"
                using A3 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 unionTARSKIK3 X & [TARSKIK4 a,c ] inHIDDENR3 unionTARSKIK3 X implies b =HIDDENR1 c"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            fix b assume [ty]: "b be objectHIDDENM1"
            fix c assume [ty]: "c be objectHIDDENM1"
            assume A5: "[TARSKIK4 a,b ] inHIDDENR3 unionTARSKIK3 X"
              and A6: "[TARSKIK4 a,c ] inHIDDENR3 unionTARSKIK3 X"
            obtain y where
              [ty]:"y be setHIDDENM2" and 
              A7: "[TARSKIK4 a,c ] inHIDDENR3 y"and A8: "y inTARSKIR2 X"
              using A6 tarski_def_4 sorry
            have 
              [ty]:"y be SequenceORDINAL1M4"
              using A1 A8 sorry
            obtain x where
              [ty]:"x be setHIDDENM2" and 
              A9: "[TARSKIK4 a,b ] inHIDDENR3 x"and A10: "x inTARSKIR2 X"
              using A5 tarski_def_4 sorry
            have 
              [ty]:"x be SequenceORDINAL1M4"
              using A1 A10 sorry
            have "(x,y)are-c=-comparableXBOOLE-0R3"
              using A2 A10 A8 sorry
            then have "x c=RELAT-1R2 y or y c=RELAT-1R2 x"
               sorry
            thus "b =HIDDENR1 c"
              using A9 A7 funct_1_def_1 sorry
          qed "sorry"
          thus "unionTARSKIK3 X be Function-likeFUNCT-1V1"
            using funct_1_def_1 sorry
        qed
        thus "unionTARSKIK3 X be Relation-likeRELAT-1V1 & unionTARSKIK3 X be Function-likeFUNCT-1V1"
          using relat_1_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain F where 
      [ty]:"F be FunctionFUNCT-1M1" and FDef:"F = unionTARSKIK3 X"
       sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inHIDDENR3 X & ( for L be SequenceORDINAL1M4 holds L =HIDDENR1 Lamb1 implies domRELAT-1K1 L =HIDDENR1 Lamb2)"
    have A11: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds ?P(a,b) & ?P(a,c) implies b =HIDDENR1 c"
    proof-
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds a inHIDDENR3 X & (( for L be SequenceORDINAL1M4 holds L =HIDDENR1 a implies domRELAT-1K1 L =HIDDENR1 b) & (a inHIDDENR3 X & ( for L be SequenceORDINAL1M4 holds L =HIDDENR1 a implies domRELAT-1K1 L =HIDDENR1 c))) implies b =HIDDENR1 c"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A12: "a inHIDDENR3 X"
          and A13: " for L be SequenceORDINAL1M4 holds L =HIDDENR1 a implies domRELAT-1K1 L =HIDDENR1 b"
          and "a inHIDDENR3 X"
          and A14: " for L be SequenceORDINAL1M4 holds L =HIDDENR1 a implies domRELAT-1K1 L =HIDDENR1 c"
        have 
          [ty]:"a be SequenceORDINAL1M4"
          using A1 A12 sorry
        have "domRELAT-1K1 a =HIDDENR1 b"
          using A13 sorry
        thus "b =HIDDENR1 c"
          using A14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain G where
      [ty]:"G be FunctionFUNCT-1M1" and 
      A15: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 G iff a inHIDDENR3 X & ?P(a,b)"
      using funct_1_sch_1 A11 sorry
    have A16: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 G implies b be OrdinalORDINAL1M3"
    proof(rule ballI,rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A17: "[TARSKIK4 a,b ] inHIDDENR3 G"
      then have "a inHIDDENR3 X"
        using A15 sorry
      then have 
        [ty]:"a be SequenceORDINAL1M4"
        using A1 sorry
      have "domRELAT-1K1 a =HIDDENR1 b"
        using A15 A17 sorry
      thus "b be OrdinalORDINAL1M3"
         sorry
    qed "sorry"
    have " for a be objectHIDDENM1 holds a inHIDDENR3 rngFUNCT-1K2 G implies a be OrdinalORDINAL1M3"
    proof-
      have " for a be objectHIDDENM1 holds a inHIDDENR3 rngFUNCT-1K2 G implies a be OrdinalORDINAL1M3"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 rngFUNCT-1K2 G"
        then obtain b where
          [ty]:"b be objectHIDDENM1" and 
          A18: "b inHIDDENR3 domRELAT-1K1 G & a =HIDDENR1 G .FUNCT-1K1 b"
          using funct_1_def_3 sorry
        have "[TARSKIK4 b,a ] inHIDDENR3 G"
          using A18 funct_1_th_1 sorry
        thus "a be OrdinalORDINAL1M3"
          using A16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A19: "rngFUNCT-1K2 G c=TARSKIR1 A"
      using ordinal1_th_24 sorry
    let ?P = "\<lambda>Lamb1.  for B be OrdinalORDINAL1M3 holds B inTARSKIR2 rngFUNCT-1K2 G implies B c=ORDINAL1R1 Lamb1"
    have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 rngFUNCT-1K2 G implies B c=ORDINAL1R1 A"
      using A19 ordinal1_def_2 sorry
    then have A20: " ex A be OrdinalORDINAL1M3 st ?P(A)"
       sorry
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A21: "?P(A) & ( for C be OrdinalORDINAL1M3 holds ?P(C) implies A c=ORDINAL1R1 C)"
      using ordinal1_sch_1 A20 sorry
    have "domRELAT-1K1 F =XBOOLE-0R4 A"
    proof-
      have "( for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 F implies a inHIDDENR3 A) & A c=TARSKIR1 domRELAT-1K1 F"
      proof(rule conjMI)
        show " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 F implies a inHIDDENR3 A"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 domRELAT-1K1 F"
          then obtain b where
            [ty]:"b be objectHIDDENM1" and 
            A22: "[TARSKIK4 a,b ] inHIDDENR3 F"
            using xtuple_0_def_12 sorry
          obtain x where
            [ty]:"x be setHIDDENM2" and 
            A23: "[TARSKIK4 a,b ] inHIDDENR3 x"and A24: "x inTARSKIR2 X"
            using A22 tarski_def_4 sorry
          have 
            [ty]:"x be SequenceORDINAL1M4"
            using A1 A24 sorry
          have " for L be SequenceORDINAL1M4 holds L =FUNCT-1R1 x implies domRELAT-1K1 L =XBOOLE-0R4 domRELAT-1K1 x"
             sorry
          then have "[TARSKIK4 x,domRELAT-1K1 x ] inHIDDENR3 G"
            using A15 A24 sorry
          then have "x inTARSKIR2 domRELAT-1K1 G & domRELAT-1K1 x =XBOOLE-0R4 G .FUNCT-1K1 x"
            using funct_1_th_1 sorry
          then have "domRELAT-1K1 x inTARSKIR2 rngFUNCT-1K2 G"
            using funct_1_def_3 sorry
          then have A25: "domRELAT-1K1 x c=ORDINAL1R1 A"
            using A21 sorry
          have "a inHIDDENR3 domRELAT-1K1 x"
            using A23 xtuple_0_def_12 sorry
          thus "a inHIDDENR3 A"
            using A25 sorry
        qed "sorry"
        have " for a be objectHIDDENM1 holds a inHIDDENR3 A implies a inHIDDENR3 domRELAT-1K1 F"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume A26: "a inHIDDENR3 A"
          then obtain a9 where 
            [ty]:"a9 be OrdinalORDINAL1M3" and a9Def:"a9 = a"
            using ordinal1_th_13 sorry
          have "( for L be SequenceORDINAL1M4 holds L inTARSKIR2 X implies  not a9 inTARSKIR2 domRELAT-1K1 L) implies  False "
          proof(rule impI)
            assume A27: " for L be SequenceORDINAL1M4 holds L inTARSKIR2 X implies  not a9 inTARSKIR2 domRELAT-1K1 L"
            have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 rngFUNCT-1K2 G implies B c=ORDINAL1R1 a9"
            proof(rule ballI,rule impI)
              fix B assume [ty]: "B be OrdinalORDINAL1M3"
              assume "B inTARSKIR2 rngFUNCT-1K2 G"
              then obtain c where
                [ty]:"c be objectHIDDENM1" and 
                A28: "c inHIDDENR3 domRELAT-1K1 G & B =XBOOLE-0R4 G .FUNCT-1K1 c"
                using funct_1_def_3 sorry
              have A29: "[TARSKIK4 c,B ] inHIDDENR3 G"
                using A28 funct_1_th_1 sorry
              then have "c inHIDDENR3 X"
                using A15 sorry
              then have 
                [ty]:"c be SequenceORDINAL1M4"
                using A1 sorry
              have "c inTARSKIR2 X & domRELAT-1K1 c =XBOOLE-0R4 B"
                using A15 A29 sorry
              thus "B c=ORDINAL1R1 a9"
                using A27 ordinal1_th_16 sorry
            qed "sorry"
            then have A30: "A c=ORDINAL1R1 a9"
              using A21 sorry
            have "a9 c=ORDINAL1R1 A"
              using A26 ordinal1_def_2 sorry
            then have A: "A =HIDDENR1 a"
              using A30 xboole_0_def_10 sorry
            obtain aa where 
              [ty]:"aa be setHIDDENM2" and aaDef:"aa = a"
              using tarski_th_1 sorry
            have " not aa inTARSKIR2 aa"
               sorry
            thus " False "
              using A A26 sorry
          qed
          then obtain L where
            [ty]:"L be SequenceORDINAL1M4" and 
            A31: "L inTARSKIR2 X & a inHIDDENR3 domRELAT-1K1 L"
             sorry
          have "L c=RELAT-1R2 F & ( ex b be objectHIDDENM1 st [TARSKIK4 a,b ] inHIDDENR3 L)"
            using A31 xtuple_0_def_12 zfmisc_1_th_74 sorry
          thus "a inHIDDENR3 domRELAT-1K1 F"
            using xtuple_0_def_12 sorry
        qed "sorry"
        thus "A c=TARSKIR1 domRELAT-1K1 F"
          using tarski_def_3 sorry
      qed
      thus "domRELAT-1K1 F =XBOOLE-0R4 A"
        using tarski_def_3 xboole_0_def_10 sorry
    qed
    thus "unionTARSKIK3 X be SequenceORDINAL1M4"
      using ordinal1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem ordinal1_sch_3:
  fixes Af0 Hf1 L1f0 L2f0 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1. x1 be SequenceORDINAL1M4 \<Longrightarrow> Hf1(x1) be setHIDDENM2" and
  [ty]: "L1f0 be SequenceORDINAL1M4" and
  [ty]: "L2f0 be SequenceORDINAL1M4" and
   A1: "domRELAT-1K1 L1f0 =XBOOLE-0R4 Af0 & ( for B be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds B inTARSKIR2 Af0 & L =FUNCT-1R1 L1f0  |RELAT-1K8 B implies L1f0 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L))" and
   A2: "domRELAT-1K1 L2f0 =XBOOLE-0R4 Af0 & ( for B be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds B inTARSKIR2 Af0 & L =FUNCT-1R1 L2f0  |RELAT-1K8 B implies L2f0 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L))"
  shows "L1f0 =FUNCT-1R1 L2f0"
  proof-
    have "L1f0 <>HIDDENR2 L2f0 implies  False "
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. L1f0 .FUNCT-1K1 Lamb1 <>HIDDENR2 L2f0 .FUNCT-1K1 Lamb1"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Af0 & ?P(x)"
        using xboole_0_sch_1 sorry
      have " for b be objectHIDDENM1 holds b inHIDDENR3 X implies b inHIDDENR3 Af0"
        using A3 sorry
      then have A4: "X c=TARSKIR1 Af0"
         sorry
      assume "L1f0 <>HIDDENR2 L2f0"
      then have " ex a be objectHIDDENM1 st a inHIDDENR3 Af0 & L1f0 .FUNCT-1K1 a <>HIDDENR2 L2f0 .FUNCT-1K1 a"
        using A1 A2 sorry
      then have "X <>HIDDENR2 {}XBOOLE-0K1"
        using A3 sorry
      then obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A5: "B inTARSKIR2 X"and A6: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 X implies B c=ORDINAL1R1 C"
        using A4 ordinal1_th_20 sorry
      have A7: "B inTARSKIR2 Af0"
        using A3 A5 sorry
      then have A8: "B c=ORDINAL1R1 Af0"
        using ordinal1_def_2 sorry
      then have A9: "domRELAT-1K1 (L1f0  |RELAT-1K8 B) =XBOOLE-0R4 B"
        using A1 relat_1_th_62 sorry
      have A10: "domRELAT-1K1 (L2f0  |RELAT-1K8 B) =XBOOLE-0R4 B"
        using A2 A8 relat_1_th_62 sorry
      have A11: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies L1f0 .FUNCT-1K1 C =XBOOLE-0R4 L2f0 .FUNCT-1K1 C"
      proof(rule ballI,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A12: "C inTARSKIR2 B"
        then have " not C inTARSKIR2 X"
          using A6 ordinal1_th_5 sorry
        thus "L1f0 .FUNCT-1K1 C =XBOOLE-0R4 L2f0 .FUNCT-1K1 C"
          using A3 A8 A12 sorry
      qed "sorry"
      have " for a be objectHIDDENM1 holds a inHIDDENR3 B implies (L1f0  |RELAT-1K8 B).FUNCT-1K1 a =XBOOLE-0R4 (L2f0  |RELAT-1K8 B).FUNCT-1K1 a"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A13: "a inHIDDENR3 B"
        then obtain a9 where 
          [ty]:"a9 be OrdinalORDINAL1M3" and a9Def:"a9 = a"
          using ordinal1_th_13 sorry
        have "L1f0 .FUNCT-1K1 a9 =XBOOLE-0R4 L2f0 .FUNCT-1K1 a9 & (L1f0  |RELAT-1K8 B).FUNCT-1K1 a =XBOOLE-0R4 L1f0 .FUNCT-1K1 a"
          using A11 A9 A13 funct_1_th_47 sorry
        thus "(L1f0  |RELAT-1K8 B).FUNCT-1K1 a =XBOOLE-0R4 (L2f0  |RELAT-1K8 B).FUNCT-1K1 a"
          using A10 A13 funct_1_th_47 sorry
      qed "sorry"
      then have A14: "L1f0  |RELAT-1K8 B =FUNCT-1R1 L2f0  |RELAT-1K8 B"
        using A9 A10 sorry
      have "L1f0 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L1f0  |RELAT-1K8 B) & L2f0 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L2f0  |RELAT-1K8 B)"
        using A1 A2 A7 sorry
      thus " False "
        using A3 A5 A14 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem ordinal1_sch_4:
  fixes Af0 Hf1 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1. x1 be SequenceORDINAL1M4 \<Longrightarrow> Hf1(x1) be setHIDDENM2"
  shows " ex L be SequenceORDINAL1M4 st domRELAT-1K1 L =XBOOLE-0R4 Af0 & ( for B be OrdinalORDINAL1M3 holds  for L1 be SequenceORDINAL1M4 holds B inTARSKIR2 Af0 & L1 =FUNCT-1R1 L  |RELAT-1K8 B implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L1))"
  proof-
    have " ex tVar11 be SequenceORDINAL1M4 st domRELAT-1K1 tVar11 =XBOOLE-0R4 Af0 & ( for B be OrdinalORDINAL1M3 holds  for L1 be SequenceORDINAL1M4 holds B inTARSKIR2 Af0 & L1 =FUNCT-1R1 tVar11  |RELAT-1K8 B implies tVar11 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L1))"
    proof-
      let ?S = "\<lambda>Lamb1.  ex L be SequenceORDINAL1M4 st domRELAT-1K1 L =XBOOLE-0R4 Lamb1 & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 Lamb1 implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B))"
      have A1: " for B be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?S(C)) implies ?S(B)"
      proof-
        have " for B be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ( ex L be SequenceORDINAL1M4 st domRELAT-1K1 L =XBOOLE-0R4 C & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies L .FUNCT-1K1 D =XBOOLE-0R4 Hf1(L  |RELAT-1K8 D)))) implies ( ex tVar10 be SequenceORDINAL1M4 st domRELAT-1K1 tVar10 =XBOOLE-0R4 B & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies tVar10 .FUNCT-1K1 D =XBOOLE-0R4 Hf1(tVar10  |RELAT-1K8 D)))"
        proof(rule ballI,rule impI)
          let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 be OrdinalORDINAL1M3 & Lamb2 be SequenceORDINAL1M4) & ( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 Lamb1 & L =HIDDENR1 Lamb2 implies domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B)))"
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          assume A2: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ( ex L be SequenceORDINAL1M4 st domRELAT-1K1 L =XBOOLE-0R4 C & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies L .FUNCT-1K1 D =XBOOLE-0R4 Hf1(L  |RELAT-1K8 D)))"
          have A3: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds ?P(a,b) & ?P(a,c) implies b =HIDDENR1 c"
          proof-
            have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds a be OrdinalORDINAL1M3 & (b be SequenceORDINAL1M4 & (( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 a & L =HIDDENR1 b implies domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B))) & (a be OrdinalORDINAL1M3 & (c be SequenceORDINAL1M4 & ( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 a & L =HIDDENR1 c implies domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B))))))) implies b =HIDDENR1 c"
            proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              fix b assume [ty]: "b be objectHIDDENM1"
              fix c assume [ty]: "c be objectHIDDENM1"
              assume A4: "a be OrdinalORDINAL1M3"
                and A5: "b be SequenceORDINAL1M4"
                and A6: " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 a & L =HIDDENR1 b implies domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B))"
                and "a be OrdinalORDINAL1M3"
                and A7: "c be SequenceORDINAL1M4"
                and A8: " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 a & L =HIDDENR1 c implies domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B))"
              have 
                [ty]:"c be SequenceORDINAL1M4"
                using A7 sorry
              have 
                [ty]:"a be OrdinalORDINAL1M3"
                using A4 sorry
              have A9: "domRELAT-1K1 c =XBOOLE-0R4 a & ( for B be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds B inTARSKIR2 a & L =FUNCT-1R1 c  |RELAT-1K8 B implies c .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L))"
                using A8 sorry
              have 
                [ty]:"b be SequenceORDINAL1M4"
                using A5 sorry
              have A10: "domRELAT-1K1 b =XBOOLE-0R4 a & ( for B be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds B inTARSKIR2 a & L =FUNCT-1R1 b  |RELAT-1K8 B implies b .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L))"
                using A6 sorry
              have "b =FUNCT-1R1 c"
                using ordinal1_sch_3 A10 A9 sorry
              thus "b =HIDDENR1 c"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain G where
            [ty]:"G be FunctionFUNCT-1M1" and 
            A11: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 G iff a inHIDDENR3 B & ?P(a,b)"
            using funct_1_sch_1 A3 sorry
          let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex L be SequenceORDINAL1M4 st L =XBOOLE-0R4 G .FUNCT-1K1 Lamb1 & Lamb2 =HIDDENR1 Hf1(L)"
          have A12: "domRELAT-1K1 G =XBOOLE-0R4 B"
          proof-
            have "( for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 G implies a inHIDDENR3 B) & B c=TARSKIR1 domRELAT-1K1 G"
            proof(rule conjMI)
              show " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 G implies a inHIDDENR3 B"
              proof(rule ballI,rule impI)
                fix a assume [ty]: "a be objectHIDDENM1"
                assume "a inHIDDENR3 domRELAT-1K1 G"
                then have " ex b be objectHIDDENM1 st [TARSKIK4 a,b ] inHIDDENR3 G"
                  using xtuple_0_def_12 sorry
                thus "a inHIDDENR3 B"
                  using A11 sorry
              qed "sorry"
              have " for a be objectHIDDENM1 holds a inHIDDENR3 B implies a inHIDDENR3 domRELAT-1K1 G"
              proof(rule ballI,rule impI)
                fix a assume [ty]: "a be objectHIDDENM1"
                assume A13: "a inHIDDENR3 B"
                then obtain a9 where 
                  [ty]:"a9 be OrdinalORDINAL1M3" and a9Def:"a9 = a"
                  using ordinal1_th_13 sorry
                obtain L where
                  [ty]:"L be SequenceORDINAL1M4" and 
                  A14: "domRELAT-1K1 L =XBOOLE-0R4 a9 & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 a9 implies L .FUNCT-1K1 D =XBOOLE-0R4 Hf1(L  |RELAT-1K8 D))"
                  using A2 A13 sorry
                have " for A be OrdinalORDINAL1M3 holds  for K be SequenceORDINAL1M4 holds A =XBOOLE-0R4 a9 & K =FUNCT-1R1 L implies domRELAT-1K1 K =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies K .FUNCT-1K1 B =XBOOLE-0R4 Hf1(K  |RELAT-1K8 B))"
                  using A14 sorry
                then have "[TARSKIK4 a9,L ] inHIDDENR3 G"
                  using A11 A13 sorry
                thus "a inHIDDENR3 domRELAT-1K1 G"
                  using xtuple_0_def_12 sorry
              qed "sorry"
              thus "B c=TARSKIR1 domRELAT-1K1 G"
                using tarski_def_3 sorry
            qed
            thus "domRELAT-1K1 G =XBOOLE-0R4 B"
              using tarski_def_3 xboole_0_def_10 sorry
          qed
          have A15: " for a be objectHIDDENM1 holds a inHIDDENR3 B implies ( ex b be objectHIDDENM1 st ?R(a,b))"
          proof-
            have " for a be objectHIDDENM1 holds a inHIDDENR3 B implies ( ex tVar8 be objectHIDDENM1 st  ex tVar9 be SequenceORDINAL1M4 st tVar9 =XBOOLE-0R4 G .FUNCT-1K1 a & Hf1(tVar9) =HIDDENR1 Hf1(tVar9))"
            proof(rule ballI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              assume "a inHIDDENR3 B"
              then obtain c where
                [ty]:"c be objectHIDDENM1" and 
                A16: "[TARSKIK4 a,c ] inHIDDENR3 G"
                using A12 xtuple_0_def_12 sorry
              obtain L where 
                [ty]:"L be SequenceORDINAL1M4" and LDef:"L = c"
                using A11 A16 sorry
              show " ex tVar8 be objectHIDDENM1 st  ex tVar9 be SequenceORDINAL1M4 st tVar9 =XBOOLE-0R4 G .FUNCT-1K1 a & Hf1(tVar9) =HIDDENR1 Hf1(tVar9)"
              proof(rule bexI[of _ "Hf1(L)"])
                show " ex tVar9 be SequenceORDINAL1M4 st tVar9 =XBOOLE-0R4 G .FUNCT-1K1 a & Hf1(tVar9) =HIDDENR1 Hf1(tVar9)"
                proof(rule bexI[of _ "L"],rule conjMI)
                  show "L =XBOOLE-0R4 G .FUNCT-1K1 a"
                    using A16 funct_1_th_1 sorry
                  show "Hf1(L) =HIDDENR1 Hf1(L)"
                     sorry
                qed "sorry"
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A17: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds (a inHIDDENR3 B & ?R(a,b)) & ?R(a,c) implies b =HIDDENR1 c"
             sorry
          obtain F where
            [ty]:"F be FunctionFUNCT-1M1" and 
            A18: "domRELAT-1K1 F =XBOOLE-0R4 B & ( for a be objectHIDDENM1 holds a inHIDDENR3 B implies ?R(a,F .FUNCT-1K1 a))"
            using funct_1_sch_2 A17 A15 sorry
          obtain L where 
            [ty]:"L be SequenceORDINAL1M4" and LDef:"L = F"
            using A18 ordinal1_def_7 sorry
          show " ex tVar10 be SequenceORDINAL1M4 st domRELAT-1K1 tVar10 =XBOOLE-0R4 B & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies tVar10 .FUNCT-1K1 D =XBOOLE-0R4 Hf1(tVar10  |RELAT-1K8 D))"
          proof(rule bexI[of _ "L"],rule conjMI,rule ballI,rule impI)
            show "domRELAT-1K1 L =XBOOLE-0R4 B"
              using A18 sorry
            fix D assume [ty]: "D be OrdinalORDINAL1M3"
            assume A19: "D inTARSKIR2 B"
            then obtain K where
              [ty]:"K be SequenceORDINAL1M4" and 
              A20: "K =XBOOLE-0R4 G .FUNCT-1K1 D"and A21: "F .FUNCT-1K1 D =XBOOLE-0R4 Hf1(K)"
              using A18 sorry
            have A22: "[TARSKIK4 D,K ] inHIDDENR3 G"
              using A12 A19 A20 funct_1_th_1 sorry
            then have A23: "domRELAT-1K1 K =XBOOLE-0R4 D"
              using A11 sorry
            have A24: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 D implies G .FUNCT-1K1 C =XBOOLE-0R4 K  |RELAT-1K8 C"
            proof(rule ballI,rule impI)
              fix C assume [ty]: "C be OrdinalORDINAL1M3"
              assume A25: "C inTARSKIR2 D"
              have A26: " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =XBOOLE-0R4 C & L =FUNCT-1R1 K  |RELAT-1K8 C implies domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B))"
              proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
                fix A assume [ty]: "A be OrdinalORDINAL1M3"
                fix L assume [ty]: "L be SequenceORDINAL1M4"
                assume A27: "A =XBOOLE-0R4 C"
                  and A28: "L =FUNCT-1R1 K  |RELAT-1K8 C"
                have A29: "C c=ORDINAL1R1 D"
                  using A25 ordinal1_def_2 sorry
                thus A30: "domRELAT-1K1 L =XBOOLE-0R4 A"
                  using A23 A27 A28 relat_1_th_62 sorry
                fix B assume [ty]: "B be OrdinalORDINAL1M3"
                assume A31: "B inTARSKIR2 A"
                then have "B c=ORDINAL1R1 A"
                  using ordinal1_def_2 sorry
                then have A32: "K  |RELAT-1K8 B =FUNCT-1R1 L  |RELAT-1K8 B"
                  using A27 A28 funct_1_th_51 sorry
                have "K .FUNCT-1K1 B =XBOOLE-0R4 Hf1(K  |RELAT-1K8 B)"
                  using A11 A22 A27 A29 A31 sorry
                thus "L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B)"
                  using A28 A30 A31 A32 funct_1_th_47 sorry
              qed "sorry"
              have "C inTARSKIR2 B"
                using A19 A25 ordinal1_th_10 sorry
              then have "[TARSKIK4 C,K  |RELAT-1K8 C ] inHIDDENR3 G"
                using A11 A26 sorry
              thus "G .FUNCT-1K1 C =XBOOLE-0R4 K  |RELAT-1K8 C"
                using funct_1_th_1 sorry
            qed "sorry"
            have A33: " for a be objectHIDDENM1 holds a inHIDDENR3 D implies (L  |RELAT-1K8 D).FUNCT-1K1 a =XBOOLE-0R4 K .FUNCT-1K1 a"
            proof(rule ballI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              assume A34: "a inHIDDENR3 D"
              then obtain A where 
                [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = a"
                using ordinal1_th_13 sorry
              have A35: "G .FUNCT-1K1 A =XBOOLE-0R4 K  |RELAT-1K8 A & (L  |RELAT-1K8 D).FUNCT-1K1 A =XBOOLE-0R4 L .FUNCT-1K1 A"
                using A24 A34 funct_1_th_49 sorry
              have " ex J be SequenceORDINAL1M4 st J =XBOOLE-0R4 G .FUNCT-1K1 A & F .FUNCT-1K1 A =XBOOLE-0R4 Hf1(J)"
                using A18 A19 A34 ordinal1_th_10 sorry
              thus "(L  |RELAT-1K8 D).FUNCT-1K1 a =XBOOLE-0R4 K .FUNCT-1K1 a"
                using A11 A22 A34 A35 sorry
            qed "sorry"
            have "D c=ORDINAL1R1 domRELAT-1K1 L"
              using A18 A19 ordinal1_def_2 sorry
            then have "domRELAT-1K1 (L  |RELAT-1K8 D) =XBOOLE-0R4 D"
              using relat_1_th_62 sorry
            thus "L .FUNCT-1K1 D =XBOOLE-0R4 Hf1(L  |RELAT-1K8 D)"
              using A21 A23 A33 funct_1_th_2 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for A be OrdinalORDINAL1M3 holds ?S(A)"
        using ordinal1_sch_2 A1 sorry
      then obtain L where
        [ty]:"L be SequenceORDINAL1M4" and 
        A36: "domRELAT-1K1 L =XBOOLE-0R4 Af0"and A37: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 Af0 implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B)"
         sorry
      show " ex tVar11 be SequenceORDINAL1M4 st domRELAT-1K1 tVar11 =XBOOLE-0R4 Af0 & ( for B be OrdinalORDINAL1M3 holds  for L1 be SequenceORDINAL1M4 holds B inTARSKIR2 Af0 & L1 =FUNCT-1R1 tVar11  |RELAT-1K8 B implies tVar11 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L1))"
      proof(rule bexI[of _ "L"],rule conjMI,rule ballI,rule ballI,rule impI)
        show "domRELAT-1K1 L =XBOOLE-0R4 Af0"
          using A36 sorry
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        fix L1 assume [ty]: "L1 be SequenceORDINAL1M4"
        assume "B inTARSKIR2 Af0 & L1 =FUNCT-1R1 L  |RELAT-1K8 B"
        thus "L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L1)"
          using A37 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem ordinal1_sch_5:
  fixes Lf0 Ff1 Hf1 
  assumes
[ty]: "Lf0 be SequenceORDINAL1M4" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be SequenceORDINAL1M4 \<Longrightarrow> Hf1(x1) be setHIDDENM2" and
   A1: " for A be OrdinalORDINAL1M3 holds  for a be objectHIDDENM1 holds a =HIDDENR1 Ff1(A) iff ( ex L be SequenceORDINAL1M4 st (a =HIDDENR1 Hf1(L) & domRELAT-1K1 L =XBOOLE-0R4 A) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B)))" and
   A2: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 Lf0 implies Lf0 .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
  shows " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 domRELAT-1K1 Lf0 implies Lf0 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(Lf0  |RELAT-1K8 B)"
  proof-
    have " for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 domRELAT-1K1 Lf0 &  not Lf0 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(Lf0  |RELAT-1K8 B))"
    proof-
      obtain L where
        [ty]:"L be SequenceORDINAL1M4" and 
        "Ff1(domRELAT-1K1 Lf0) =XBOOLE-0R4 Hf1(L)"and A3: "domRELAT-1K1 L =XBOOLE-0R4 domRELAT-1K1 Lf0"and A4: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 domRELAT-1K1 Lf0 implies L .FUNCT-1K1 B =XBOOLE-0R4 Hf1(L  |RELAT-1K8 B)"
        using A1 sorry
      have " for b be objectHIDDENM1 holds b inHIDDENR3 domRELAT-1K1 L implies Lf0 .FUNCT-1K1 b =XBOOLE-0R4 L .FUNCT-1K1 b"
      proof(rule ballI,rule impI)
        fix b assume [ty]: "b be objectHIDDENM1"
        assume A5: "b inHIDDENR3 domRELAT-1K1 L"
        then obtain B where 
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = b"
          using ordinal1_th_13 sorry
        have " ex K be setHIDDENM2 st Hf1(L  |RELAT-1K8 B) =XBOOLE-0R4 Hf1(K) & (domRELAT-1K1 K =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies K .FUNCT-1K1 C =XBOOLE-0R4 Hf1(K  |RELAT-1K8 C)))"
        proof-
          obtain K where 
            [ty]:"K be setHIDDENM2" and KDef:"K = L  |RELAT-1K8 B"
             sorry
          show " ex K be setHIDDENM2 st Hf1(L  |RELAT-1K8 B) =XBOOLE-0R4 Hf1(K) & (domRELAT-1K1 K =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies K .FUNCT-1K1 C =XBOOLE-0R4 Hf1(K  |RELAT-1K8 C)))"
          proof(rule bexI[of _ "K"],rule conjMI,rule conjMI,rule ballI,rule impI)
            show "Hf1(L  |RELAT-1K8 B) =XBOOLE-0R4 Hf1(K)"
               sorry
            have A6: "B c=ORDINAL1R1 domRELAT-1K1 L"
              using A5 ordinal1_def_2 sorry
            thus "domRELAT-1K1 K =XBOOLE-0R4 B"
              using relat_1_th_62 sorry
            fix C assume [ty]: "C be OrdinalORDINAL1M3"
            assume A7: "C inTARSKIR2 B"
            then have "C c=ORDINAL1R1 B"
              using ordinal1_def_2 sorry
            then have A8: "L  |RELAT-1K8 C =FUNCT-1R1 K  |RELAT-1K8 C"
              using funct_1_th_51 sorry
            have "K .FUNCT-1K1 C =XBOOLE-0R4 L .FUNCT-1K1 C"
              using A7 funct_1_th_49 sorry
            thus "K .FUNCT-1K1 C =XBOOLE-0R4 Hf1(K  |RELAT-1K8 C)"
              using A3 A4 A6 A7 A8 sorry
          qed "sorry"
        qed
        then have "Ff1(B) =HIDDENR1 Hf1(L  |RELAT-1K8 B)"
          using A1 sorry
        also have "... = L .FUNCT-1K1 B"
          using A3 A4 A5 sorry
        finally have "Ff1(B) =HIDDENR1 L .FUNCT-1K1 B"
           sorry
        thus "Lf0 .FUNCT-1K1 b =XBOOLE-0R4 L .FUNCT-1K1 b"
          using A2 A3 A5 sorry
      qed "sorry"
      then have "Lf0 =FUNCT-1R1 L"
        using A3 sorry
      thus " for B be OrdinalORDINAL1M3 holds  not (B inTARSKIR2 domRELAT-1K1 Lf0 &  not Lf0 .FUNCT-1K1 B =XBOOLE-0R4 Hf1(Lf0  |RELAT-1K8 B))"
        using A4 sorry
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem ordinal1_th_35:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A c<XBOOLE-0R2 B or A =XBOOLE-0R4 B) or B c<XBOOLE-0R2 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds ( not A c<XBOOLE-0R2 B &  not A =XBOOLE-0R4 B) &  not B c<XBOOLE-0R2 A implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: " not A c<XBOOLE-0R2 B &  not A =XBOOLE-0R4 B"
      and A2: " not B c<XBOOLE-0R2 A"
    have " not A c=ORDINAL1R1 B"
      using A1 sorry
    thus " False "
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef ordinal1_def_9 ("OnORDINAL1K2  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func OnORDINAL1K2 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X & x be OrdinalORDINAL1M3"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X & x be OrdinalORDINAL1M3"
    proof-
      have " ex Y be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 X & x be OrdinalORDINAL1M3"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 be OrdinalORDINAL1M3"
        show " ex Y be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 X & x be OrdinalORDINAL1M3"
          using xboole_0_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x inHIDDENR3 X & x be OrdinalORDINAL1M3) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x inHIDDENR3 X & x be OrdinalORDINAL1M3) implies it1 =HIDDENR1 it2"
    proof-
      have " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 X & x be OrdinalORDINAL1M3) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Z iff x inHIDDENR3 X & x be OrdinalORDINAL1M3) implies Y =XBOOLE-0R4 Z"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 X & Lamb1 be OrdinalORDINAL1M3"
        fix Y assume [ty]: "Y be setHIDDENM2"
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff ?P(x)"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Z iff ?P(x)"
        show "Y =XBOOLE-0R4 Z"
          using xboole_0_sch_2 A1 A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef ordinal1_def_10 ("LimORDINAL1K3  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func LimORDINAL1K3 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)"
    proof-
      have " ex Y be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)"
      proof-
        let ?P = "\<lambda>Lamb1.  ex A be OrdinalORDINAL1M3 st Lamb1 =HIDDENR1 A & A be limit-ordinalORDINAL1V4"
        show " ex Y be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)"
          using xboole_0_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)) implies it1 =HIDDENR1 it2"
    proof-
      have " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Z iff x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)) implies Y =XBOOLE-0R4 Z"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st Lamb1 =HIDDENR1 A & A be limit-ordinalORDINAL1V4)"
        fix Y assume [ty]: "Y be setHIDDENM2"
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume A3: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff ?P(x)"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Z iff ?P(x)"
        show "Y =XBOOLE-0R4 Z"
          using xboole_0_sch_2 A3 A4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

(*\$N Generalized Axiom of Infinity*)
mtheorem ordinal1_th_36:
" for D be OrdinalORDINAL1M3 holds  ex A be OrdinalORDINAL1M3 st D inTARSKIR2 A & A be limit-ordinalORDINAL1V4"
proof-
  have " for D be OrdinalORDINAL1M3 holds  ex tVar13 be OrdinalORDINAL1M3 st D inTARSKIR2 tVar13 & tVar13 be limit-ordinalORDINAL1V4"
  proof(rule ballI)
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    obtain Field where
      [ty]:"Field be setHIDDENM2" and 
      A1: "D inTARSKIR2 Field"and A2: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Field & Y c=TARSKIR1 X implies Y inTARSKIR2 Field"and A3: " for X be setHIDDENM2 holds X inTARSKIR2 Field implies boolSETFAM-1K9 X inTARSKIR2 Field"and " for X be setHIDDENM2 holds X c=TARSKIR1 Field implies (X,Field)are-equipotentTARSKIR3 or X inTARSKIR2 Field"
      using zfmisc_1_th_112 sorry
    have " for X be setHIDDENM2 holds X inTARSKIR2 OnORDINAL1K2 Field implies X be OrdinalORDINAL1M3 & X c=TARSKIR1 OnORDINAL1K2 Field"
    proof(rule ballI,rule impI,rule conjMI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume A4: "X inTARSKIR2 OnORDINAL1K2 Field"
      then obtain A where 
        [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = X"
        using ordinal1_def_9 sorry
      have A5: "A inTARSKIR2 Field"
        using A4 ordinal1_def_9 sorry
      show "X be OrdinalORDINAL1M3"
        using A4 ordinal1_def_9 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 OnORDINAL1K2 Field"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A6: "y inHIDDENR3 X"
        then have "y inHIDDENR3 A"
           sorry
        then obtain B where 
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = y"
          using ordinal1_th_13 sorry
        have "B c=ORDINAL1R1 A"
          using A6 ordinal1_def_2 sorry
        then have "B inTARSKIR2 Field"
          using A2 A5 sorry
        thus "y inHIDDENR3 OnORDINAL1K2 Field"
          using ordinal1_def_9 sorry
      qed "sorry"
      thus "X c=TARSKIR1 OnORDINAL1K2 Field"
        using tarski_def_3 sorry
    qed "sorry"
    then obtain ON where 
      [ty]:"ON be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2" and ONDef:"ON = OnORDINAL1K2 Field"
      using ordinal1_th_19 sorry
    show " ex tVar13 be OrdinalORDINAL1M3 st D inTARSKIR2 tVar13 & tVar13 be limit-ordinalORDINAL1V4"
    proof(rule bexI[of _ "ON"],rule conjMI)
      show "D inTARSKIR2 ON"
        using A1 ordinal1_def_9 sorry
      have " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 ON implies succORDINAL1K1 A inTARSKIR2 ON"
      proof-
        have " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 ON implies succORDINAL1K1 A inTARSKIR2 ON"
        proof(rule ballI,rule impI)
          fix A assume [ty]: "A be OrdinalORDINAL1M3"
          have A7: "succORDINAL1K1 A c=TARSKIR1 boolSETFAM-1K9 A"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 succORDINAL1K1 A implies x inHIDDENR3 boolSETFAM-1K9 A"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              obtain xx where 
                [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
                using tarski_th_1 sorry
              assume "x inHIDDENR3 succORDINAL1K1 A"
              then have "x inHIDDENR3 A or x =HIDDENR1 A"
                using ordinal1_th_8 sorry
              then have "xx c=TARSKIR1 A"
                using ordinal1_def_2 sorry
              thus "x inHIDDENR3 boolSETFAM-1K9 A"
                 sorry
            qed "sorry"
            thus "succORDINAL1K1 A c=TARSKIR1 boolSETFAM-1K9 A"
              using tarski_def_3 sorry
          qed
          assume "A inTARSKIR2 ON"
          then have "A inTARSKIR2 Field"
            using ordinal1_def_9 sorry
          then have "boolSETFAM-1K9 A inTARSKIR2 Field"
            using A3 sorry
          then have "succORDINAL1K1 A inTARSKIR2 Field"
            using A2 A7 sorry
          thus "succORDINAL1K1 A inTARSKIR2 ON"
            using ordinal1_def_9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "ON be limit-ordinalORDINAL1V4"
        using ordinal1_th_28 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef ordinal1_def_11 ("omegaORDINAL1K4" 228 ) where
"func omegaORDINAL1K4 \<rightarrow> setHIDDENM2 means
  \<lambda>it. (({}XBOOLE-0K1 inTARSKIR2 it & it be limit-ordinalORDINAL1V4) & it be ordinalORDINAL1V3) & ( for A be OrdinalORDINAL1M3 holds {}XBOOLE-0K1 inTARSKIR2 A & A be limit-ordinalORDINAL1V4 implies it c=TARSKIR1 A)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st (({}XBOOLE-0K1 inTARSKIR2 it & it be limit-ordinalORDINAL1V4) & it be ordinalORDINAL1V3) & ( for A be OrdinalORDINAL1M3 holds {}XBOOLE-0K1 inTARSKIR2 A & A be limit-ordinalORDINAL1V4 implies it c=TARSKIR1 A)"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  not ((({}XBOOLE-0K1 inTARSKIR2 VarFor1 & VarFor1 be limit-ordinalORDINAL1V4) & VarFor1 be ordinalORDINAL1V3) & ( for A be OrdinalORDINAL1M3 holds  not (({}XBOOLE-0K1 inTARSKIR2 A & A be limit-ordinalORDINAL1V4) &  not VarFor1 c=TARSKIR1 A))))"
      proof-
        let ?P = "\<lambda>Lamb1. {}XBOOLE-0K1 inTARSKIR2 Lamb1 & Lamb1 be limit-ordinalORDINAL1V4"
        have A1: " ex A be OrdinalORDINAL1M3 st ?P(A)"
          using ordinal1_th_36 sorry
        have " ex C be OrdinalORDINAL1M3 st ?P(C) & ( for A be OrdinalORDINAL1M3 holds ?P(A) implies C c=ORDINAL1R1 A)"
          using ordinal1_sch_1 A1 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  not ((({}XBOOLE-0K1 inTARSKIR2 VarFor1 & VarFor1 be limit-ordinalORDINAL1V4) & VarFor1 be ordinalORDINAL1V3) & ( for A be OrdinalORDINAL1M3 holds  not (({}XBOOLE-0K1 inTARSKIR2 A & A be limit-ordinalORDINAL1V4) &  not VarFor1 c=TARSKIR1 A))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ((({}XBOOLE-0K1 inTARSKIR2 it1 & it1 be limit-ordinalORDINAL1V4) & it1 be ordinalORDINAL1V3) & ( for A be OrdinalORDINAL1M3 holds {}XBOOLE-0K1 inTARSKIR2 A & A be limit-ordinalORDINAL1V4 implies it1 c=TARSKIR1 A)) & ((({}XBOOLE-0K1 inTARSKIR2 it2 & it2 be limit-ordinalORDINAL1V4) & it2 be ordinalORDINAL1V3) & ( for A be OrdinalORDINAL1M3 holds {}XBOOLE-0K1 inTARSKIR2 A & A be limit-ordinalORDINAL1V4 implies it2 c=TARSKIR1 A)) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem ordinal1_cl_15:
"cluster omegaORDINAL1K4 as-term-is  non emptyXBOOLE-0V1\<bar>ordinalORDINAL1V3"
proof
(*coherence*)
  show "omegaORDINAL1K4 be  non emptyXBOOLE-0V1\<bar>ordinalORDINAL1V3"
    using ordinal1_def_11 sorry
qed "sorry"

mdef ordinal1_def_12 ("naturalORDINAL1V7" 70 ) where
"attr naturalORDINAL1V7 for objectHIDDENM1 means
  (\<lambda>A. A inHIDDENR3 omegaORDINAL1K4)"..

mtheorem ordinal1_cl_16:
"cluster naturalORDINAL1V7 for NumberORDINAL1M1"
proof
(*existence*)
  show " ex it be NumberORDINAL1M1 st it be naturalORDINAL1V7"
  proof-
    have " ex tVar14 be NumberORDINAL1M1 st tVar14 be naturalORDINAL1V7"
    proof-
      show " ex tVar14 be NumberORDINAL1M1 st tVar14 be naturalORDINAL1V7"
      proof(rule bexI[of _ "the ElementSUBSET-1M1-of omegaORDINAL1K4"])
        show "the ElementSUBSET-1M1-of omegaORDINAL1K4 be naturalORDINAL1V7"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_17:
"cluster naturalORDINAL1V7 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be naturalORDINAL1V7"
  proof-
    have " ex tVar15 be setHIDDENM2 st tVar15 be naturalORDINAL1V7"
    proof-
      show " ex tVar15 be setHIDDENM2 st tVar15 be naturalORDINAL1V7"
      proof(rule bexI[of _ "the ElementSUBSET-1M1-of omegaORDINAL1K4"])
        show "the ElementSUBSET-1M1-of omegaORDINAL1K4 be naturalORDINAL1V7"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax ORDINAL1M6 :: "Ty" ("NatORDINAL1M6" 70)
translations "NatORDINAL1M6" \<rightharpoonup> "naturalORDINAL1V7\<bar>setHIDDENM2"

mtheorem ordinal1_sethood_1:
"cluster sethood of NatORDINAL1M6"
proof
(*sethood*)
  show " ex cover be setHIDDENM2 st  for it be NatORDINAL1M6 holds it inHIDDENR3 cover"
  proof-
    have " ex tVar16 be setHIDDENM2 st  for y be NatORDINAL1M6 holds y inTARSKIR2 tVar16"
    proof-
      show " ex tVar16 be setHIDDENM2 st  for y be NatORDINAL1M6 holds y inTARSKIR2 tVar16"
      proof(rule bexI[of _ "omegaORDINAL1K4"],rule ballI)
        fix y assume [ty]: "y be NatORDINAL1M6"
        show "y inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_12 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_18:
  mlet "A be OrdinalORDINAL1M3"
"cluster note-that ordinalORDINAL1V3 for ElementSUBSET-1M1-of A"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of A holds it be ordinalORDINAL1V3"
  proof-
    have " for x be ElementSUBSET-1M1-of A holds x be ordinalORDINAL1V3"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of A"
      have "A be emptyXBOOLE-0V1 or A be  non emptyXBOOLE-0V1"
         sorry
      thus "x be ordinalORDINAL1V3"
        using ordinal1_th_13 subset_1_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_19:
"cluster naturalORDINAL1V7 also-is ordinalORDINAL1V3 for numberORDINAL1M2"
proof
(*coherence*)
  show " for it be numberORDINAL1M2 holds it be naturalORDINAL1V7 implies it be ordinalORDINAL1V3"
     sorry
qed "sorry"

theorem ordinal1_sch_6:
  fixes Df0 Pp2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: " for d be ElementSUBSET-1M1-of Df0 holds  ex A be OrdinalORDINAL1M3 st Pp2(d,A)"
  shows " ex F be FunctionFUNCT-1M1 st domRELAT-1K1 F =XBOOLE-0R4 Df0 & ( for d be ElementSUBSET-1M1-of Df0 holds  ex A be OrdinalORDINAL1M3 st (A =XBOOLE-0R4 F .FUNCT-1K1 d & Pp2(d,A)) & ( for B be OrdinalORDINAL1M3 holds Pp2(d,B) implies A c=ORDINAL1R1 B))"
  proof-
    have " ex tVar19 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar19 =XBOOLE-0R4 Df0 & ( for d be ElementSUBSET-1M1-of Df0 holds  not ( for A be OrdinalORDINAL1M3 holds  not ((A =XBOOLE-0R4 tVar19 .FUNCT-1K1 d & Pp2(d,A)) & ( for B be OrdinalORDINAL1M3 holds  not (Pp2(d,B) &  not A c=ORDINAL1R1 B)))))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be OrdinalORDINAL1M3 st (A =HIDDENR1 Lamb2 & Pp2(Lamb1,A)) & ( for B be OrdinalORDINAL1M3 holds Pp2(Lamb1,B) implies A c=ORDINAL1R1 B)"
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Df0 implies ( ex y be objectHIDDENM1 st ?Q(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Df0 implies ( ex tVar17 be objectHIDDENM1 st  ex tVar18 be OrdinalORDINAL1M3 st (tVar18 =HIDDENR1 tVar17 & Pp2(x,tVar18)) & ( for B be OrdinalORDINAL1M3 holds  not (Pp2(x,B) &  not tVar18 c=ORDINAL1R1 B)))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 Df0"
          then obtain d where 
            [ty]:"d be ElementSUBSET-1M1-of Df0" and dDef:"d = x"
             sorry
          let ?Q = "\<lambda>Lamb1. Pp2(d,Lamb1)"
          have A3: " ex A be OrdinalORDINAL1M3 st ?Q(A)"
            using A1 sorry
          obtain A where
            [ty]:"A be OrdinalORDINAL1M3" and 
            A4: "?Q(A) & ( for B be OrdinalORDINAL1M3 holds ?Q(B) implies A c=ORDINAL1R1 B)"
            using ordinal1_sch_1 A3 sorry
          obtain y where 
            [ty]:"y be setHIDDENM2" and yDef:"y = A"
             sorry
          show " ex tVar17 be objectHIDDENM1 st  ex tVar18 be OrdinalORDINAL1M3 st (tVar18 =HIDDENR1 tVar17 & Pp2(x,tVar18)) & ( for B be OrdinalORDINAL1M3 holds  not (Pp2(x,B) &  not tVar18 c=ORDINAL1R1 B))"
          proof(rule bexI[of _ "y"])
            show " ex tVar18 be OrdinalORDINAL1M3 st (tVar18 =HIDDENR1 y & Pp2(x,tVar18)) & ( for B be OrdinalORDINAL1M3 holds  not (Pp2(x,B) &  not tVar18 c=ORDINAL1R1 B))"
            proof(rule bexI[of _ "A"])
              show "(A =HIDDENR1 y & Pp2(x,A)) & ( for B be OrdinalORDINAL1M3 holds  not (Pp2(x,B) &  not A c=ORDINAL1R1 B))"
                using A4 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (x inHIDDENR3 Df0 & ?Q(x,y)) & ?Q(x,z) implies y =HIDDENR1 z"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 Df0 implies (( ex A1 be OrdinalORDINAL1M3 st A1 =HIDDENR1 y & (Pp2(x,A1) & ( for B be OrdinalORDINAL1M3 holds Pp2(x,B) implies A1 c=ORDINAL1R1 B))) implies (( ex A2 be OrdinalORDINAL1M3 st A2 =HIDDENR1 z & (Pp2(x,A2) & ( for B be OrdinalORDINAL1M3 holds Pp2(x,B) implies A2 c=ORDINAL1R1 B))) implies y =HIDDENR1 z))"
        proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "x inHIDDENR3 Df0"
          assume Given: " ex A1 be OrdinalORDINAL1M3 st A1 =HIDDENR1 y & (Pp2(x,A1) & ( for B be OrdinalORDINAL1M3 holds Pp2(x,B) implies A1 c=ORDINAL1R1 B))"
          then obtain A1 where
            [ty]:"A1 be OrdinalORDINAL1M3" and 
            A6: "A1 =HIDDENR1 y"and A7: "Pp2(x,A1) & ( for B be OrdinalORDINAL1M3 holds Pp2(x,B) implies A1 c=ORDINAL1R1 B)"
             sorry
          assume Given: " ex A2 be OrdinalORDINAL1M3 st A2 =HIDDENR1 z & (Pp2(x,A2) & ( for B be OrdinalORDINAL1M3 holds Pp2(x,B) implies A2 c=ORDINAL1R1 B))"
          then obtain A2 where
            [ty]:"A2 be OrdinalORDINAL1M3" and 
            A8: "A2 =HIDDENR1 z"and A9: "Pp2(x,A2) & ( for B be OrdinalORDINAL1M3 holds Pp2(x,B) implies A2 c=ORDINAL1R1 B)"
             sorry
          have "A1 c=ORDINAL1R1 A2 & A2 c=ORDINAL1R1 A1"
            using A7 A9 sorry
          thus "y =HIDDENR1 z"
            using A6 A8 xboole_0_def_10 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain F where
        [ty]:"F be FunctionFUNCT-1M1" and 
        A10: "domRELAT-1K1 F =XBOOLE-0R4 Df0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Df0 implies ?Q(x,F .FUNCT-1K1 x))"
        using funct_1_sch_2 A5 A2 sorry
      show " ex tVar19 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar19 =XBOOLE-0R4 Df0 & ( for d be ElementSUBSET-1M1-of Df0 holds  not ( for A be OrdinalORDINAL1M3 holds  not ((A =XBOOLE-0R4 tVar19 .FUNCT-1K1 d & Pp2(d,A)) & ( for B be OrdinalORDINAL1M3 holds  not (Pp2(d,B) &  not A c=ORDINAL1R1 B)))))"
      proof(rule bexI[of _ "F"],rule conjMI,rule ballI)
        show "domRELAT-1K1 F =XBOOLE-0R4 Df0"
          using A10 sorry
        fix d assume [ty]: "d be ElementSUBSET-1M1-of Df0"
        show " not ( for A be OrdinalORDINAL1M3 holds  not ((A =XBOOLE-0R4 F .FUNCT-1K1 d & Pp2(d,A)) & ( for B be OrdinalORDINAL1M3 holds  not (Pp2(d,B) &  not A c=ORDINAL1R1 B))))"
          using A10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem ordinal1_th_37:
" for X be setHIDDENM2 holds succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X} =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X} =XBOOLE-0R4 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X} c=TARSKIR1 X & X c=TARSKIR1 succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X}"
    proof(rule conjMI)
      show "succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X} c=TARSKIR1 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X} implies x inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A1: "x inHIDDENR3 succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X}"
          then have A2: " not x inHIDDENR3 {TARSKIK1 X}"
            using xboole_0_def_5 sorry
          have "x inHIDDENR3 X or x =HIDDENR1 X"
            using A1 ordinal1_th_8 sorry
          thus "x inHIDDENR3 X"
            using A2 tarski_def_1 sorry
        qed "sorry"
        thus "succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X} c=TARSKIR1 X"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 X"
        then obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
           sorry
        have " not xx inTARSKIR2 xx"
           sorry
        then have "x <>HIDDENR2 X"
          using A3 sorry
        then have A4: " not x inHIDDENR3 {TARSKIK1 X}"
          using tarski_def_1 sorry
        have "x inHIDDENR3 succORDINAL1K1 X"
          using A3 ordinal1_th_8 sorry
        thus "x inHIDDENR3 succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X}"
          using A4 xboole_0_def_5 sorry
      qed "sorry"
      thus "X c=TARSKIR1 succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X}"
        using tarski_def_3 sorry
    qed
    thus "succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X} =XBOOLE-0R4 X"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal1_cl_20:
"cluster emptyXBOOLE-0V1 also-is naturalORDINAL1V7 for numberORDINAL1M2"
proof
(*coherence*)
  show " for it be numberORDINAL1M2 holds it be emptyXBOOLE-0V1 implies it be naturalORDINAL1V7"
    using ordinal1_def_11 sorry
qed "sorry"

mtheorem ordinal1_cl_21:
"cluster note-that naturalORDINAL1V7 for ElementSUBSET-1M1-of omegaORDINAL1K4"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of omegaORDINAL1K4 holds it be naturalORDINAL1V7"
     sorry
qed "sorry"

mtheorem ordinal1_cl_22:
"cluster  non emptyXBOOLE-0V1\<bar>naturalORDINAL1V7 for numberORDINAL1M2"
proof
(*existence*)
  show " ex it be numberORDINAL1M2 st it be  non emptyXBOOLE-0V1\<bar>naturalORDINAL1V7"
  proof-
    have " ex tVar20 be numberORDINAL1M2 st tVar20 be  non emptyXBOOLE-0V1 & tVar20 be naturalORDINAL1V7"
    proof-
      show " ex tVar20 be numberORDINAL1M2 st tVar20 be  non emptyXBOOLE-0V1 & tVar20 be naturalORDINAL1V7"
      proof(rule bexI[of _ "succORDINAL1K1 ({}XBOOLE-0K1)"],rule conjMI)
        show "succORDINAL1K1 ({}XBOOLE-0K1) be  non emptyXBOOLE-0V1"
           sorry
        have Cut1532: "omegaORDINAL1K4 be limit-ordinalORDINAL1V4 & {}XBOOLE-0K1 inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_11 sorry
        have "succORDINAL1K1 ({}XBOOLE-0K1) inTARSKIR2 omegaORDINAL1K4"
        proof-
          show "succORDINAL1K1 ({}XBOOLE-0K1) inTARSKIR2 omegaORDINAL1K4"
            using ordinal1_th_28 Cut1532 sorry
        qed
        thus "succORDINAL1K1 ({}XBOOLE-0K1) be naturalORDINAL1V7"
          using ordinal1_def_12 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_23:
  mlet "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
"cluster succORDINAL1K1 a as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "succORDINAL1K1 a be naturalORDINAL1V7"
  proof-
    have Cut1544: "omegaORDINAL1K4 be limit-ordinalORDINAL1V4 & a inTARSKIR2 omegaORDINAL1K4"
      using ordinal1_def_11 ordinal1_def_12 sorry
    have "succORDINAL1K1 a inTARSKIR2 omegaORDINAL1K4"
    proof-
      show "succORDINAL1K1 a inTARSKIR2 omegaORDINAL1K4"
        using ordinal1_th_28 Cut1544 sorry
    qed
    thus "succORDINAL1K1 a be naturalORDINAL1V7"
      using ordinal1_def_12 sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_24:
"cluster emptyXBOOLE-0V1 also-is c=-linearORDINAL1V6 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be c=-linearORDINAL1V6"
     sorry
qed "sorry"

mtheorem ordinal1_cl_25:
  mlet "X be c=-linearORDINAL1V6\<bar>setHIDDENM2"
"cluster note-that c=-linearORDINAL1V6 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be c=-linearORDINAL1V6"
    using ordinal1_def_8 sorry
qed "sorry"

(*\$CT*)
mdef ordinal1_def_13 ("0ORDINAL1K5" 164 ) where
"func 0ORDINAL1K5 \<rightarrow> numberORDINAL1M2 equals
  {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "{}XBOOLE-0K1 be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem ordinal1_cl_26:
"cluster 0ORDINAL1K5 as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "0ORDINAL1K5 be naturalORDINAL1V7"
     sorry
qed "sorry"

mdef ordinal1_def_14 ("zeroORDINAL1V8" 70 ) where
"attr zeroORDINAL1V8 for NumberORDINAL1M1 means
  (\<lambda>x. x =HIDDENR1 0ORDINAL1K5)"..

mtheorem ordinal1_cl_27:
"cluster 0ORDINAL1K5 as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show "0ORDINAL1K5 be zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem ordinal1_cl_28:
"cluster zeroORDINAL1V8 for NumberORDINAL1M1"
proof
(*existence*)
  show " ex it be NumberORDINAL1M1 st it be zeroORDINAL1V8"
  proof-
    have " ex tVar21 be NumberORDINAL1M1 st tVar21 be zeroORDINAL1V8"
    proof-
      show " ex tVar21 be NumberORDINAL1M1 st tVar21 be zeroORDINAL1V8"
      proof(rule bexI[of _ "0ORDINAL1K5"])
        have "0ORDINAL1K5 =XBOOLE-0R4 0ORDINAL1K5"
        proof-
          show "0ORDINAL1K5 =XBOOLE-0R4 0ORDINAL1K5"
             sorry
        qed
        thus "0ORDINAL1K5 be zeroORDINAL1V8"
          using ordinal1_def_14 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_29:
"cluster zeroORDINAL1V8 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be zeroORDINAL1V8"
  proof-
    have " ex tVar22 be setHIDDENM2 st tVar22 be zeroORDINAL1V8"
    proof-
      show " ex tVar22 be setHIDDENM2 st tVar22 be zeroORDINAL1V8"
      proof(rule bexI[of _ "0ORDINAL1K5"])
        have "0ORDINAL1K5 =XBOOLE-0R4 0ORDINAL1K5"
        proof-
          show "0ORDINAL1K5 =XBOOLE-0R4 0ORDINAL1K5"
             sorry
        qed
        thus "0ORDINAL1K5 be zeroORDINAL1V8"
          using ordinal1_def_14 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_30:
"cluster zeroORDINAL1V8 also-is naturalORDINAL1V7 for NumberORDINAL1M1"
proof
(*coherence*)
  show " for it be NumberORDINAL1M1 holds it be zeroORDINAL1V8 implies it be naturalORDINAL1V7"
     sorry
qed "sorry"

mtheorem ordinal1_cl_31:
"cluster  non zeroORDINAL1V8 for NumberORDINAL1M1"
proof
(*existence*)
  show " ex it be NumberORDINAL1M1 st it be  non zeroORDINAL1V8"
  proof-
    have " ex tVar23 be NumberORDINAL1M1 st  not tVar23 be zeroORDINAL1V8"
    proof-
      show " ex tVar23 be NumberORDINAL1M1 st  not tVar23 be zeroORDINAL1V8"
      proof(rule bexI[of _ "{TARSKIK1 0ORDINAL1K5 }"])
        have "{TARSKIK1 0ORDINAL1K5 } <>HIDDENR2 0ORDINAL1K5"
        proof-
          show "{TARSKIK1 0ORDINAL1K5 } <>HIDDENR2 0ORDINAL1K5"
             sorry
        qed
        thus " not {TARSKIK1 0ORDINAL1K5 } be zeroORDINAL1V8"
          using ordinal1_def_14 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_32:
"cluster zeroORDINAL1V8 also-is trivialSUBSET-1V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be zeroORDINAL1V8 implies it be trivialSUBSET-1V2"
     sorry
qed "sorry"

mtheorem ordinal1_cl_33:
"cluster  non trivialSUBSET-1V2 also-is  non zeroORDINAL1V8 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be  non trivialSUBSET-1V2 implies it be  non zeroORDINAL1V8"
     sorry
qed "sorry"

mdef ordinal1_def_15 ("non-zeroORDINAL1V9" 70 ) where
"attr non-zeroORDINAL1V9 for RelationRELAT-1M1 means
  (\<lambda>R.  not 0ORDINAL1K5 inTARSKIR2 rngRELAT-1K2 R)"..

mdef ordinal1_def_16 ("with-zeroORDINAL1V10" 70 ) where
"attr with-zeroORDINAL1V10 for setHIDDENM2 means
  (\<lambda>X. 0ORDINAL1K5 inTARSKIR2 X)"..

syntax ORDINAL1V11 :: "Ty" ("without-zeroORDINAL1V11" 70)
translations "without-zeroORDINAL1V11" \<rightharpoonup> " non with-zeroORDINAL1V10"

mtheorem ordinal1_cl_34:
"cluster emptyXBOOLE-0V1 also-is without-zeroORDINAL1V11 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be without-zeroORDINAL1V11"
     sorry
qed "sorry"

mtheorem ordinal1_cl_35:
"cluster emptyXBOOLE-0V1 also-is non-zeroORDINAL1V9 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be non-zeroORDINAL1V9"
     sorry
qed "sorry"

mtheorem ordinal1_cl_36:
"cluster without-zeroORDINAL1V11\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be without-zeroORDINAL1V11\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar24 be setHIDDENM2 st  not tVar24 be without-zeroORDINAL1V11 &  not tVar24 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar24 be setHIDDENM2 st  not tVar24 be without-zeroORDINAL1V11 &  not tVar24 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "{TARSKIK1 {TARSKIK1 0ORDINAL1K5 } }"])
        have " not 0ORDINAL1K5 inTARSKIR2 {TARSKIK1 {TARSKIK1 0ORDINAL1K5 } } &  not {TARSKIK1 {TARSKIK1 0ORDINAL1K5 } } be emptyXBOOLE-0V1"
        proof(rule conjMI)
          show " not 0ORDINAL1K5 inTARSKIR2 {TARSKIK1 {TARSKIK1 0ORDINAL1K5 } }"
            using tarski_def_1 sorry
          show " not {TARSKIK1 {TARSKIK1 0ORDINAL1K5 } } be emptyXBOOLE-0V1"
             sorry
        qed
        thus " not {TARSKIK1 {TARSKIK1 0ORDINAL1K5 } } be without-zeroORDINAL1V11 &  not {TARSKIK1 {TARSKIK1 0ORDINAL1K5 } } be emptyXBOOLE-0V1"
          using ordinal1_def_16 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_37:
  mlet "X be without-zeroORDINAL1V11\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that  non zeroORDINAL1V8 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be  non zeroORDINAL1V8"
    using ordinal1_def_16 sorry
qed "sorry"

mtheorem ordinal1_cl_38:
"cluster non-zeroORDINAL1V9 for RelationRELAT-1M1"
proof
(*existence*)
  show " ex it be RelationRELAT-1M1 st it be non-zeroORDINAL1V9"
  proof-
    have " ex tVar25 be RelationRELAT-1M1 st tVar25 be non-zeroORDINAL1V9"
    proof-
      show " ex tVar25 be RelationRELAT-1M1 st tVar25 be non-zeroORDINAL1V9"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        have " not 0ORDINAL1K5 inTARSKIR2 rngFUNCT-1K2 ({}XBOOLE-0K1)"
        proof-
          show " not 0ORDINAL1K5 inTARSKIR2 rngFUNCT-1K2 ({}XBOOLE-0K1)"
             sorry
        qed
        thus "{}XBOOLE-0K1 be non-zeroORDINAL1V9"
          using ordinal1_def_15 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_39:
"cluster  non non-zeroORDINAL1V9 for RelationRELAT-1M1"
proof
(*existence*)
  show " ex it be RelationRELAT-1M1 st it be  non non-zeroORDINAL1V9"
  proof-
    have " ex R be setHIDDENM2 st  not R be non-zeroORDINAL1V9"
    proof-
      obtain R where 
        [ty]:"R be setHIDDENM2" and RDef:"R = {TARSKIK1 [TARSKIK4 0ORDINAL1K5,0ORDINAL1K5 ] }"
         sorry
      show " ex R be setHIDDENM2 st  not R be non-zeroORDINAL1V9"
      proof(rule bexI[of _ "R"])
        have Cut1668: "[TARSKIK4 0ORDINAL1K5,0ORDINAL1K5 ] inHIDDENR3 R"
          using tarski_def_1 sorry
        have "0ORDINAL1K5 inTARSKIR2 rngFUNCT-1K2 R"
        proof-
          show "0ORDINAL1K5 inTARSKIR2 rngFUNCT-1K2 R"
            using xtuple_0_def_13 Cut1668 sorry
        qed
        thus " not R be non-zeroORDINAL1V9"
          using ordinal1_def_15 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_40:
  mlet "R be non-zeroORDINAL1V9\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is without-zeroORDINAL1V11"
proof
(*coherence*)
  show "rngRELAT-1K2 R be without-zeroORDINAL1V11"
    using ordinal1_def_15 sorry
qed "sorry"

mtheorem ordinal1_cl_41:
  mlet "R be  non non-zeroORDINAL1V9\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is with-zeroORDINAL1V10"
proof
(*coherence*)
  show "rngRELAT-1K2 R be with-zeroORDINAL1V10"
    using ordinal1_def_15 sorry
qed "sorry"

mtheorem ordinal1_cl_42:
  mlet "R be non-zeroORDINAL1V9\<bar>RelationRELAT-1M1", "S be RelationRELAT-1M1"
"cluster S *RELAT-1K6 R as-term-is non-zeroORDINAL1V9"
proof
(*coherence*)
  show "S *RELAT-1K6 R be non-zeroORDINAL1V9"
  proof-
    have Cut1687: "rngRELAT-1K2 (S *RELAT-1K6 R) c=TARSKIR1 rngRELAT-1K2 R"
      using relat_1_th_26 sorry
    have " not 0ORDINAL1K5 inTARSKIR2 rngRELAT-1K2 (S *RELAT-1K6 R)"
    proof-
      show " not 0ORDINAL1K5 inTARSKIR2 rngRELAT-1K2 (S *RELAT-1K6 R)"
        using Cut1687 sorry
    qed
    thus "S *RELAT-1K6 R be non-zeroORDINAL1V9"
      using ordinal1_def_15 sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_43:
"cluster without-zeroORDINAL1V11 also-is with-non-empty-elementsSETFAM-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be without-zeroORDINAL1V11 implies it be with-non-empty-elementsSETFAM-1V1"
  proof-
    have " for X be setHIDDENM2 holds X be without-zeroORDINAL1V11 implies X be with-non-empty-elementsSETFAM-1V1"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume Cut1698: "X be without-zeroORDINAL1V11"
      have " not {}XBOOLE-0K1 inTARSKIR2 X"
      proof-
        show " not {}XBOOLE-0K1 inTARSKIR2 X"
          using Cut1698 sorry
      qed
      thus "X be with-non-empty-elementsSETFAM-1V1"
        using setfam_1_def_8 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_44:
"cluster with-zeroORDINAL1V10 also-is  non with-non-empty-elementsSETFAM-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be with-zeroORDINAL1V10 implies it be  non with-non-empty-elementsSETFAM-1V1"
  proof-
    have " for X be setHIDDENM2 holds X be with-zeroORDINAL1V10 implies  not X be with-non-empty-elementsSETFAM-1V1"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume Cut1704: "X be with-zeroORDINAL1V10"
      have "{}XBOOLE-0K1 inTARSKIR2 X"
      proof-
        show "{}XBOOLE-0K1 inTARSKIR2 X"
          using Cut1704 sorry
      qed
      thus " not X be with-non-empty-elementsSETFAM-1V1"
        using setfam_1_def_8 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem ordinal1_cl_45:
"cluster with-non-empty-elementsSETFAM-1V1 also-is without-zeroORDINAL1V11 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be with-non-empty-elementsSETFAM-1V1 implies it be without-zeroORDINAL1V11"
     sorry
qed "sorry"

mtheorem ordinal1_cl_46:
"cluster  non with-non-empty-elementsSETFAM-1V1 also-is with-zeroORDINAL1V10 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be  non with-non-empty-elementsSETFAM-1V1 implies it be with-zeroORDINAL1V10"
     sorry
qed "sorry"

mdef ordinal1_def_17 ("SegmORDINAL1K6  _ " [164]164 ) where
  mlet "o be objectHIDDENM1"
"func SegmORDINAL1K6 o \<rightarrow> setHIDDENM2 equals
  o"
proof-
  (*coherence*)
    show "o be setHIDDENM2"
      using tarski_th_1 sorry
qed "sorry"

mtheorem ordinal1_cl_47:
  mlet "n be OrdinalORDINAL1M3"
"cluster SegmORDINAL1K6 n as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "SegmORDINAL1K6 n be ordinalORDINAL1V3"
     sorry
qed "sorry"

mtheorem ordinal1_cl_48:
  mlet "n be zeroORDINAL1V8\<bar>OrdinalORDINAL1M3"
"cluster SegmORDINAL1K6 n as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SegmORDINAL1K6 n be emptyXBOOLE-0V1"
    using ordinal1_def_14 sorry
qed "sorry"

end
