theory sin_cos2
  imports sin_cos
   "../mizar_extension/E_number"
begin
(*begin*)
reserve p, q, r, th, th1 for "RealXREAL-0M1"
reserve n for "NatNAT-1M1"
mtheorem sin_cos2_th_1:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds p >=XXREAL-0R2 0NUMBERSK6 & r >=XXREAL-0R2 0NUMBERSK6 implies p +XCMPLX-0K2 r >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (p *XCMPLX-0K3 r)"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds p >=XXREAL-0R2 0NUMBERSK6 & r >=XXREAL-0R2 0NUMBERSK6 implies p +XCMPLX-0K2 r >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (p *XCMPLX-0K3 r)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "p >=XXREAL-0R2 0NUMBERSK6"
      and A2: "r >=XXREAL-0R2 0NUMBERSK6"
    have A3: "(sqrtSQUARE-1K3 p -XCMPLX-0K6 sqrtSQUARE-1K3 r)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have "(sqrtSQUARE-1K3 p -XCMPLX-0K6 sqrtSQUARE-1K3 r)^2SQUARE-1K1 =HIDDENR1 ((sqrtSQUARE-1K3 p)^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 p)*XCMPLX-0K3 sqrtSQUARE-1K3 r)+XCMPLX-0K2 (sqrtSQUARE-1K3 r)^2SQUARE-1K1"
       sorry
    also have "... = (p -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 p)*XCMPLX-0K3 sqrtSQUARE-1K3 r)+XCMPLX-0K2 (sqrtSQUARE-1K3 r)^2SQUARE-1K1"
      using A1 square_1_def_2 sorry
    also have "... = (p -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 p)*XCMPLX-0K3 sqrtSQUARE-1K3 r)+XCMPLX-0K2 r"
      using A2 square_1_def_2 sorry
    also have "... = (p +XCMPLX-0K2 r)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 p)*XCMPLX-0K3 sqrtSQUARE-1K3 r"
       sorry
    finally have "(sqrtSQUARE-1K3 p -XCMPLX-0K6 sqrtSQUARE-1K3 r)^2SQUARE-1K1 =HIDDENR1 (p +XCMPLX-0K2 r)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 p)*XCMPLX-0K3 sqrtSQUARE-1K3 r"
       sorry
    then have "0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 p)*XCMPLX-0K3 sqrtSQUARE-1K3 r <=XXREAL-0R1 p +XCMPLX-0K2 r"
      using A3 xreal_1_th_19 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 p *XCMPLX-0K3 sqrtSQUARE-1K3 r) <=XXREAL-0R1 p +XCMPLX-0K2 r"
       sorry
    thus "p +XCMPLX-0K2 r >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (p *XCMPLX-0K3 r)"
      using A1 A2 square_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_2:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be increasingVALUED-0V9"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(sinSIN-COSK17,th)"
  proof-
    have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies  not 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(sinSIN-COSK17,th)"
    proof(rule ballI,rule impI)
      fix th assume [ty]: "th be RealXREAL-0M1"
      assume "th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      then have "(cosSIN-COSK19).FUNCT-1K1 th >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_80 sorry
      thus " not 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(sinSIN-COSK17,th)"
        using sin_cos_th_68 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be increasingVALUED-0V9"
    using fdiff_1_th_26 rolle_th_9 sin_cos_th_24 sin_cos_th_68 sorry
qed

mlemma sin_cos2_lm_1:
" for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies 0NUMBERSK6 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 th"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies  not 0NUMBERSK6 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 th"
  proof(rule ballI,rule impI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume A1: "th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
    then have "th <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_1_th_4 sorry
    then have "-XCMPLX-0K4 th >XXREAL-0R4 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_24 sorry
    then have A2: "(-XCMPLX-0K4 th)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_6 sorry
    have "0NUMBERSK6 <XXREAL-0R3 th"
      using A1 xxreal_1_th_4 sorry
    then have "0NUMBERSK6 -XCMPLX-0K6 th <XXREAL-0R3 0NUMBERSK6"
       sorry
    then have "(-XCMPLX-0K4 th)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_6 sorry
    then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using A2 xxreal_1_th_4 sorry
    then have "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_th_80 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 th"
      using sin_cos_th_78 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_3:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be decreasingVALUED-0V10"
proof-
  have " for th1 be RealXREAL-0M1 holds th1 inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies 0NUMBERSK6 >XXREAL-0R4 diffFDIFF-1K1(sinSIN-COSK17,th1)"
  proof-
    have " for th1 be RealXREAL-0M1 holds th1 inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies  not 0NUMBERSK6 >XXREAL-0R4 diffFDIFF-1K1(sinSIN-COSK17,th1)"
    proof(rule ballI,rule impI)
      fix th1 assume [ty]: "th1 be RealXREAL-0M1"
      assume A1: "th1 inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
      then have "th1 <XXREAL-0R3 PISIN-COSK29"
        using xxreal_1_th_4 sorry
      then have A2: "th1 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_9 sorry
      have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 th1"
        using A1 xxreal_1_th_4 sorry
      then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 th1 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_9 sorry
      then have "th1 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        using A2 xxreal_1_th_4 sorry
      then have "(sinSIN-COSK17).FUNCT-1K1 (th1 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
        using sin_cos2_lm_1 sorry
      then have A3: "0NUMBERSK6 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 (th1 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) <XXREAL-0R3 0NUMBERSK6"
         sorry
      have "diffFDIFF-1K1(sinSIN-COSK17,th1) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (th1 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M))"
        using sin_cos_th_68 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (th1 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
        using sin_cos_th_78 sorry
      finally have "diffFDIFF-1K1(sinSIN-COSK17,th1) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (th1 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus " not 0NUMBERSK6 >XXREAL-0R4 diffFDIFF-1K1(sinSIN-COSK17,th1)"
        using A3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be decreasingVALUED-0V10"
    using fdiff_1_th_26 rolle_th_10 sin_cos_th_24 sin_cos_th_68 sorry
qed

mtheorem sin_cos2_th_4:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be decreasingVALUED-0V10"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies diffFDIFF-1K1(cosSIN-COSK19,th) <XXREAL-0R3 0NUMBERSK6"
  proof-
    have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies  not diffFDIFF-1K1(cosSIN-COSK19,th) <XXREAL-0R3 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix th assume [ty]: "th be RealXREAL-0M1"
      assume "th inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      then have "0NUMBERSK6 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 th"
        using sin_cos2_lm_1 sorry
      then have "diffFDIFF-1K1(cosSIN-COSK19,th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th & 0NUMBERSK6 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th <XXREAL-0R3 0NUMBERSK6"
        using sin_cos_th_67 sorry
      thus " not diffFDIFF-1K1(cosSIN-COSK19,th) <XXREAL-0R3 0NUMBERSK6"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be decreasingVALUED-0V10"
    using fdiff_1_th_26 rolle_th_10 sin_cos_th_24 sin_cos_th_67 sorry
qed

mtheorem sin_cos2_th_5:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be decreasingVALUED-0V10"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies diffFDIFF-1K1(cosSIN-COSK19,th) <XXREAL-0R3 0NUMBERSK6"
  proof-
    have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies  not diffFDIFF-1K1(cosSIN-COSK19,th) <XXREAL-0R3 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix th assume [ty]: "th be RealXREAL-0M1"
      assume A1: "th inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
      then have "th <XXREAL-0R3 PISIN-COSK29"
        using xxreal_1_th_4 sorry
      then have A2: "th -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_9 sorry
      have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 th"
        using A1 xxreal_1_th_4 sorry
      then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 th -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_9 sorry
      then have "th -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        using A2 xxreal_1_th_4 sorry
      then have "(cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_80 sorry
      then have A3: "0NUMBERSK6 -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) <XXREAL-0R3 0NUMBERSK6"
         sorry
      have "diffFDIFF-1K1(cosSIN-COSK19,th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (th -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M))"
        using sin_cos_th_67 sorry
      also have "... = -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
        using sin_cos_th_78 sorry
      finally have "diffFDIFF-1K1(cosSIN-COSK19,th) =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus " not diffFDIFF-1K1(cosSIN-COSK19,th) <XXREAL-0R3 0NUMBERSK6"
        using A3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[) be decreasingVALUED-0V10"
    using fdiff_1_th_26 rolle_th_10 sin_cos_th_24 sin_cos_th_67 sorry
qed

mtheorem sin_cos2_th_6:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be decreasingVALUED-0V10"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies diffFDIFF-1K1(sinSIN-COSK17,th) <XXREAL-0R3 0NUMBERSK6"
  proof-
    have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies  not diffFDIFF-1K1(sinSIN-COSK17,th) <XXREAL-0R3 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix th assume [ty]: "th be RealXREAL-0M1"
      assume A1: "th inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      have "th <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using A1 xxreal_1_th_4 sorry
      then have A2: "th -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 PISIN-COSK29"
        using xreal_1_th_9 sorry
      have "PISIN-COSK29 <XXREAL-0R3 th"
        using A1 xxreal_1_th_4 sorry
      then have "PISIN-COSK29 -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 th -XCMPLX-0K6 PISIN-COSK29"
        using xreal_1_th_9 sorry
      then have "th -XCMPLX-0K6 PISIN-COSK29 inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        using A2 xxreal_1_th_4 sorry
      then have "(cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29) >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_80 sorry
      then have A3: "0NUMBERSK6 -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29) <XXREAL-0R3 0NUMBERSK6"
         sorry
      have "diffFDIFF-1K1(sinSIN-COSK17,th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (th -XCMPLX-0K6 PISIN-COSK29))"
        using sin_cos_th_68 sorry
      also have "... = -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29)"
        using sin_cos_th_78 sorry
      finally have "diffFDIFF-1K1(sinSIN-COSK17,th) =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29)"
         sorry
      thus " not diffFDIFF-1K1(sinSIN-COSK17,th) <XXREAL-0R3 0NUMBERSK6"
        using A3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be decreasingVALUED-0V10"
    using fdiff_1_th_26 rolle_th_10 sin_cos_th_24 sin_cos_th_68 sorry
qed

mtheorem sin_cos2_th_7:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies diffFDIFF-1K1(sinSIN-COSK17,th) >XXREAL-0R4 0NUMBERSK6"
  proof-
    have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies  not diffFDIFF-1K1(sinSIN-COSK17,th) >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix th assume [ty]: "th be RealXREAL-0M1"
      assume A1: "th inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      have "th <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using A1 xxreal_1_th_4 sorry
      then have A2: "th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using xreal_1_th_9 sorry
      have A3: "diffFDIFF-1K1(sinSIN-COSK17,th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))))"
        using sin_cos_th_68 sorry
      also have "... = -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))"
        using sin_cos_th_78 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)))"
        using sin_cos_th_78 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
         sorry
      finally have "diffFDIFF-1K1(sinSIN-COSK17,th) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
         sorry
      have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 th"
        using A1 xxreal_1_th_4 sorry
      then have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using xreal_1_th_9 sorry
      then have "th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        using A2 xxreal_1_th_4 sorry
      thus " not diffFDIFF-1K1(sinSIN-COSK17,th) >XXREAL-0R4 0NUMBERSK6"
        using A3 sin_cos2_lm_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
    using fdiff_1_th_26 rolle_th_9 sin_cos_th_24 sin_cos_th_68 sorry
qed

mtheorem sin_cos2_th_8:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies diffFDIFF-1K1(cosSIN-COSK19,th) >XXREAL-0R4 0NUMBERSK6"
  proof-
    have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies  not diffFDIFF-1K1(cosSIN-COSK19,th) >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix th assume [ty]: "th be RealXREAL-0M1"
      assume A1: "th inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      have "th <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using A1 xxreal_1_th_4 sorry
      then have A2: "th -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 PISIN-COSK29"
        using xreal_1_th_9 sorry
      have A3: "diffFDIFF-1K1(cosSIN-COSK19,th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (th -XCMPLX-0K6 PISIN-COSK29))"
        using sin_cos_th_67 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29))"
        using sin_cos_th_78 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29)"
         sorry
      finally have "diffFDIFF-1K1(cosSIN-COSK19,th) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29)"
         sorry
      have "PISIN-COSK29 <XXREAL-0R3 th"
        using A1 xxreal_1_th_4 sorry
      then have "PISIN-COSK29 -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 th -XCMPLX-0K6 PISIN-COSK29"
        using xreal_1_th_9 sorry
      then have "th -XCMPLX-0K6 PISIN-COSK29 inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        using A2 xxreal_1_th_4 sorry
      thus " not diffFDIFF-1K1(cosSIN-COSK19,th) >XXREAL-0R4 0NUMBERSK6"
        using A3 sin_cos2_lm_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
    using fdiff_1_th_26 rolle_th_9 sin_cos_th_24 sin_cos_th_67 sorry
qed

mtheorem sin_cos2_th_9:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
proof-
  have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies diffFDIFF-1K1(cosSIN-COSK19,th) >XXREAL-0R4 0NUMBERSK6"
  proof-
    have " for th be RealXREAL-0M1 holds th inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies  not diffFDIFF-1K1(cosSIN-COSK19,th) >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix th assume [ty]: "th be RealXREAL-0M1"
      assume A1: "th inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      have "th <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using A1 xxreal_1_th_4 sorry
      then have A2: "th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using xreal_1_th_9 sorry
      have A3: "diffFDIFF-1K1(cosSIN-COSK19,th) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))))"
        using sin_cos_th_67 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))))"
        using sin_cos_th_78 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
        using sin_cos_th_78 sorry
      finally have "diffFDIFF-1K1(cosSIN-COSK19,th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
         sorry
      have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 th"
        using A1 xxreal_1_th_4 sorry
      then have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using xreal_1_th_9 sorry
      then have "th -XCMPLX-0K6 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        using A2 xxreal_1_th_4 sorry
      thus " not diffFDIFF-1K1(cosSIN-COSK19,th) >XXREAL-0R4 0NUMBERSK6"
        using A3 sin_cos_th_80 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingVALUED-0V9"
    using fdiff_1_th_26 rolle_th_9 sin_cos_th_24 sin_cos_th_67 sorry
qed

mtheorem sin_cos2_th_10:
" for th be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
proof-
  have " for th be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
  proof(rule ballI,rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    let ?X = "\<lambda>Lamb1.  for th be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1 +XCMPLX-0K2 th)"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for th be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)) implies ( for th be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th))"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A2: " for th be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
        have " for th be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th)"
        proof(rule ballI)
          fix th assume [ty]: "th be RealXREAL-0M1"
          have "(sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
             sorry
          also have "... = (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
            using sin_cos_th_78 sorry
          also have "... = (sinSIN-COSK17).FUNCT-1K1 th"
            using A2 sorry
          finally have "(sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 th"
             sorry
          thus "(sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th)"
             sorry
        qed "sorry"
        thus " for th be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A1 sorry
    thus "(sinSIN-COSK17).FUNCT-1K1 th =XBOOLE-0R4 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_11:
" for th be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
proof-
  have " for th be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
  proof(rule ballI,rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    let ?X = "\<lambda>Lamb1.  for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 Lamb1 +XCMPLX-0K2 th)"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)) implies ( for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th))"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A2: " for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
        have " for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th)"
        proof(rule ballI)
          fix th assume [ty]: "th be RealXREAL-0M1"
          have "(cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
             sorry
          also have "... = (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
            using sin_cos_th_78 sorry
          also have "... = (cosSIN-COSK19).FUNCT-1K1 th"
            using A2 sorry
          finally have "(cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th"
             sorry
          thus "(cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th)"
             sorry
        qed "sorry"
        thus " for th be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 th)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A1 sorry
    thus "(cosSIN-COSK19).FUNCT-1K1 th =XBOOLE-0R4 (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 n +XCMPLX-0K2 th)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef sin_cos2_def_1 ("sinhSIN-COS2K1" 164 ) where
"func sinhSIN-COS2K1 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
    proof-
      have " ex tVar1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10(((exp-RSIN-COSK23).FUNCT-1K1 Lamb1 -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 Lamb1))/XCMPLX-0K7 \<two>\<^sub>M,REALNUMBERSK2)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =XBOOLE-0R4 ?U(d)"
          using funct_2_sch_4 sorry
        show " ex tVar1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
        proof(rule bexI[of _ "f"],rule ballI)
          fix d assume [ty]: "d be RealXREAL-0M1"
          have "d inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have "f .FUNCT-1K1 d =XBOOLE-0R4 ?U(d)"
            using A1 sorry
          thus "f .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) implies (( for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) implies f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A2: " for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
        assume A3: " for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =XBOOLE-0R4 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
          proof(rule ballI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            have "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d -REAL-1K5 (exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-REAL-1K1 d))/XCMPLX-0K7 \<two>\<^sub>M"
              using A2 sorry
            also have "... = f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
              using A3 sorry
            finally show "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos2_def_2 ("sinhSIN-COS2K2  _ " [164]164 ) where
  mlet "d be objectHIDDENM1"
"func sinhSIN-COS2K2 d \<rightarrow> numberORDINAL1M2 equals
  (sinhSIN-COS2K1).FUNCT-1K1 d"
proof-
  (*coherence*)
    show "(sinhSIN-COS2K1).FUNCT-1K1 d be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos2_cl_1:
  mlet "d be objectHIDDENM1"
"cluster sinhSIN-COS2K2 d as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "sinhSIN-COS2K2 d be realXREAL-0V1"
     sorry
qed "sorry"

mdef sin_cos2_def_3 ("coshSIN-COS2K3" 164 ) where
"func coshSIN-COS2K3 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
    proof-
      have " ex tVar2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10(((exp-RSIN-COSK23).FUNCT-1K1 Lamb1 +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 Lamb1))/XCMPLX-0K7 \<two>\<^sub>M,REALNUMBERSK2)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =XBOOLE-0R4 ?U(d)"
          using funct_2_sch_4 sorry
        show " ex tVar2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
        proof(rule bexI[of _ "f"],rule ballI)
          fix d assume [ty]: "d be RealXREAL-0M1"
          have "d inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have "f .FUNCT-1K1 d =XBOOLE-0R4 ?U(d)"
            using A1 sorry
          thus "f .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) implies (( for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M) implies f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A2: " for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
        assume A3: " for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 \<two>\<^sub>M"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =XBOOLE-0R4 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
          proof(rule ballI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            have "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d +REAL-1K3 (exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-REAL-1K1 d))/XCMPLX-0K7 \<two>\<^sub>M"
              using A2 sorry
            also have "... = f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
              using A3 sorry
            finally show "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos2_def_4 ("coshSIN-COS2K4  _ " [164]164 ) where
  mlet "d be objectHIDDENM1"
"func coshSIN-COS2K4 d \<rightarrow> numberORDINAL1M2 equals
  (coshSIN-COS2K3).FUNCT-1K1 d"
proof-
  (*coherence*)
    show "(coshSIN-COS2K3).FUNCT-1K1 d be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos2_cl_2:
  mlet "d be objectHIDDENM1"
"cluster coshSIN-COS2K4 d as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "coshSIN-COS2K4 d be realXREAL-0V1"
     sorry
qed "sorry"

mdef sin_cos2_def_5 ("tanhSIN-COS2K5" 164 ) where
"func tanhSIN-COS2K5 \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds it .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
    proof-
      have " ex tVar3 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar3 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10(((exp-RSIN-COSK23).FUNCT-1K1 Lamb1 -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 Lamb1))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 Lamb1 +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 Lamb1)),REALNUMBERSK2)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =XBOOLE-0R4 ?U(d)"
          using funct_2_sch_4 sorry
        show " ex tVar3 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar3 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
        proof(rule bexI[of _ "f"],rule ballI)
          fix d assume [ty]: "d be RealXREAL-0M1"
          have "d inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have "f .FUNCT-1K1 d =XBOOLE-0R4 ?U(d)"
            using A1 sorry
          thus "f .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds it1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))) & ( for d be RealXREAL-0M1 holds it2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))) implies (( for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))) implies f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A2: " for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
        assume A3: " for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =XBOOLE-0R4 ((exp-RSIN-COSK23).FUNCT-1K1 d -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 d +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 d))"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =XBOOLE-0R4 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
          proof(rule ballI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            have "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d -REAL-1K5 (exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-REAL-1K1 d))/REAL-1K6 ((exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d +REAL-1K3 (exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-REAL-1K1 d))"
              using A2 sorry
            also have "... = f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
              using A3 sorry
            finally show "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef sin_cos2_def_6 ("tanhSIN-COS2K6  _ " [164]164 ) where
  mlet "d be objectHIDDENM1"
"func tanhSIN-COS2K6 d \<rightarrow> numberORDINAL1M2 equals
  (tanhSIN-COS2K5).FUNCT-1K1 d"
proof-
  (*coherence*)
    show "(tanhSIN-COS2K5).FUNCT-1K1 d be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem sin_cos2_cl_3:
  mlet "d be objectHIDDENM1"
"cluster tanhSIN-COS2K6 d as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "tanhSIN-COS2K6 d be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem sin_cos2_th_12:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
proof-
  have " for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    have "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =HIDDENR1 exp-RSIN-COSK24 (p +XCMPLX-0K2 q)"
      using sin_cos_def_23 sorry
    also have "... = (exp-RSIN-COSK24 p)*XCMPLX-0K3 (exp-RSIN-COSK24 q)"
      using sin_cos_th_50 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK24 q)"
      using sin_cos_def_23 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
      using sin_cos_def_23 sorry
    finally have "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
       sorry
    thus "(exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 q) =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 q"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_13:
"(exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
  using sin_cos_th_51 sin_cos_def_23 sorry

mtheorem sin_cos2_th_14:
" for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M & (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M & (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "(sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p"
      using sin_cos2_def_1 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_1 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sin_cos2_th_13 sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p =HIDDENR1 ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    have "(coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p"
      using sin_cos2_def_3 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_3 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sin_cos2_th_13 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    thus "((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 \<one>\<^sub>M & (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_2:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
      using sin_cos2_def_3 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 r +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
      using sin_cos2_def_3 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 r +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
      using sin_cos2_def_1 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 r +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_1 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 r) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r)))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 r) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 r) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 r)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 r) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 (p +XCMPLX-0K2 r)))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r)"
      using sin_cos2_def_3 sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r)"
       sorry
    thus "(coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_3:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
      using sin_cos2_def_1 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 r +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
      using sin_cos2_def_3 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 r +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
      using sin_cos2_def_3 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 r +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 r -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_1 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 r) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r)))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 r) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 r)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 r) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 r))))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 r) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 (p +XCMPLX-0K2 r)))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r)"
      using sin_cos2_def_1 sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r)"
       sorry
    thus "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_15:
" for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p <>HIDDENR2 0NUMBERSK6 & (coshSIN-COS2K3).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6) & (coshSIN-COS2K3).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for p be RealXREAL-0M1 holds ( not (coshSIN-COS2K3).FUNCT-1K1 p <>HIDDENR2 0NUMBERSK6 &  not (coshSIN-COS2K3).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6) & (coshSIN-COS2K3).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "(exp-RSIN-COSK23).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6 & (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_th_54 sorry
    then have A1: "((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_139 sorry
    have "(coshSIN-COS2K3).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos2_def_3 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_51 sin_cos_def_23 sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "( not (coshSIN-COS2K3).FUNCT-1K1 p <>HIDDENR2 0NUMBERSK6 &  not (coshSIN-COS2K3).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6) & (coshSIN-COS2K3).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 sin_cos2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_16:
"(sinhSIN-COS2K1).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
proof-
  have "(sinhSIN-COS2K1).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M"
    using sin_cos2_def_1 sorry
  also have "... = 0NUMBERSK6"
     sorry
  finally have "(sinhSIN-COS2K1).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
     sorry
  thus "(sinhSIN-COS2K1).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
     sorry
qed

mtheorem sin_cos2_th_17:
" for p be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "(sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p"
      using sin_cos2_def_1 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_3 sorry
    also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))"
      using xcmplx_1_th_55 sorry
    also have "... = (tanhSIN-COS2K5).FUNCT-1K1 p"
      using sin_cos2_def_5 sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 (tanhSIN-COS2K5).FUNCT-1K1 p"
       sorry
    thus "(tanhSIN-COS2K5).FUNCT-1K1 p =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_4:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for a1 be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 & q <>HIDDENR2 0NUMBERSK6 implies (p *XCMPLX-0K3 q +XCMPLX-0K2 r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q +XCMPLX-0K2 p *XCMPLX-0K3 a1) =XBOOLE-0R4 (p /XCMPLX-0K7 r +XCMPLX-0K2 a1 /XCMPLX-0K7 q)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 r)*XCMPLX-0K3 (a1 /XCMPLX-0K7 q))"
proof-
  have " for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for a1 be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 & q <>HIDDENR2 0NUMBERSK6 implies (p *XCMPLX-0K3 q +XCMPLX-0K2 r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q +XCMPLX-0K2 p *XCMPLX-0K3 a1) =XBOOLE-0R4 (p /XCMPLX-0K7 r +XCMPLX-0K2 a1 /XCMPLX-0K7 q)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 r)*XCMPLX-0K3 (a1 /XCMPLX-0K7 q))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix a1 assume [ty]: "a1 be RealXREAL-0M1"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
      and A2: "q <>HIDDENR2 0NUMBERSK6"
    have "(p *XCMPLX-0K3 q +XCMPLX-0K2 r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q +XCMPLX-0K2 p *XCMPLX-0K3 a1) =HIDDENR1 ((p *XCMPLX-0K3 q +XCMPLX-0K2 r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))/XCMPLX-0K7 ((r *XCMPLX-0K3 q +XCMPLX-0K2 p *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))"
      using A1 A2 xcmplx_1_th_6 xcmplx_1_th_55 sorry
    also have "... = ((p *XCMPLX-0K3 q)/XCMPLX-0K7 (r *XCMPLX-0K3 q) +XCMPLX-0K2 (r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))/XCMPLX-0K7 ((r *XCMPLX-0K3 q +XCMPLX-0K2 p *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))"
      using xcmplx_1_th_62 sorry
    also have "... = ((p *XCMPLX-0K3 q)/XCMPLX-0K7 (r *XCMPLX-0K3 q) +XCMPLX-0K2 (r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))/XCMPLX-0K7 ((r *XCMPLX-0K3 q)/XCMPLX-0K7 (r *XCMPLX-0K3 q) +XCMPLX-0K2 (p *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))"
      using xcmplx_1_th_62 sorry
    also have "... = (p /XCMPLX-0K7 r +XCMPLX-0K2 (a1 *XCMPLX-0K3 r)/XCMPLX-0K7 (q *XCMPLX-0K3 r))/XCMPLX-0K7 ((r *XCMPLX-0K3 q)/XCMPLX-0K7 (r *XCMPLX-0K3 q) +XCMPLX-0K2 (p *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))"
      using A2 xcmplx_1_th_91 sorry
    also have "... = (p /XCMPLX-0K7 r +XCMPLX-0K2 a1 /XCMPLX-0K7 q)/XCMPLX-0K7 ((r *XCMPLX-0K3 q)/XCMPLX-0K7 (r *XCMPLX-0K3 q) +XCMPLX-0K2 (p *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))"
      using A1 xcmplx_1_th_91 sorry
    also have "... = (p /XCMPLX-0K7 r +XCMPLX-0K2 a1 /XCMPLX-0K7 q)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (p *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q))"
      using A1 A2 xcmplx_1_th_6 xcmplx_1_th_60 sorry
    also have "... = (p /XCMPLX-0K7 r +XCMPLX-0K2 a1 /XCMPLX-0K7 q)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 r)*XCMPLX-0K3 (a1 /XCMPLX-0K7 q))"
      using xcmplx_1_th_76 sorry
    finally have "(p *XCMPLX-0K3 q +XCMPLX-0K2 r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q +XCMPLX-0K2 p *XCMPLX-0K3 a1) =HIDDENR1 (p /XCMPLX-0K7 r +XCMPLX-0K2 a1 /XCMPLX-0K7 q)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 r)*XCMPLX-0K3 (a1 /XCMPLX-0K7 q))"
       sorry
    thus "(p *XCMPLX-0K3 q +XCMPLX-0K2 r *XCMPLX-0K3 a1)/XCMPLX-0K7 (r *XCMPLX-0K3 q +XCMPLX-0K2 p *XCMPLX-0K3 a1) =XBOOLE-0R4 (p /XCMPLX-0K7 r +XCMPLX-0K2 a1 /XCMPLX-0K7 q)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (p /XCMPLX-0K7 r)*XCMPLX-0K3 (a1 /XCMPLX-0K7 q))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_5:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "(coshSIN-COS2K3).FUNCT-1K1 r <>HIDDENR2 0NUMBERSK6 & (coshSIN-COS2K3).FUNCT-1K1 p <>HIDDENR2 0NUMBERSK6"
      using sin_cos2_th_15 sorry
    have "(tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 r) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r)"
      using sin_cos2_th_17 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)/XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r)"
      using sin_cos2_lm_3 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)"
      using sin_cos2_lm_2 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r))"
      using A1 sin_cos2_lm_4 sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r))"
      using sin_cos2_th_17 sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r))"
      using sin_cos2_th_17 sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r))"
      using sin_cos2_th_17 sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
      using sin_cos2_th_17 sorry
    finally have "(tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 r) =HIDDENR1 ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
       sorry
    thus "(tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_18:
" for p be RealXREAL-0M1 holds ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) -XCMPLX-0K6 \<one>\<^sub>M) & ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M)"
proof-
  have " for p be RealXREAL-0M1 holds ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) -XCMPLX-0K6 \<one>\<^sub>M) & ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M)"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p"
      using sin_cos2_def_3 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_3 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos_th_51 sin_cos_def_23 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_3 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    finally have "((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    have "((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p"
      using sin_cos2_def_1 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_1 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = ((((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) +XCMPLX-0K2 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p))))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos2_th_12 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (0NUMBERSK6)))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<four>\<^sub>M"
       sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p))/XCMPLX-0K7 \<four>\<^sub>M"
      using sin_cos_th_51 sin_cos_def_23 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_3 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    finally have "((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    thus "((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) -XCMPLX-0K6 \<one>\<^sub>M) & ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 =XBOOLE-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_6:
" for p be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p & (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M"
proof-
  have " for p be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p & (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "\<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M))"
      using sin_cos2_th_18 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    finally have "\<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    have "(\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p"
      using sin_cos2_def_1 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_def_3 sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))^2SQUARE-1K1)"
       sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))"
      using sin_cos2_th_12 sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)))"
      using sin_cos2_th_12 sorry
    also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p)"
      using sin_cos2_def_1 sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p)"
       sorry
    thus "(sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p & (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_19:
" for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 p) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p & (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 p) & (tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (tanhSIN-COS2K5).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 p) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p & (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 p) & (tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (tanhSIN-COS2K5).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "(coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos2_def_3 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 p"
      using sin_cos2_def_3 sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
       sorry
    have A2: "(sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 (-XCMPLX-0K4 p)))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos2_def_1 sorry
    also have "... = -XCMPLX-0K4 ((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = -XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 p"
      using sin_cos2_def_1 sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 p"
       sorry
    then have "(tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 p)/XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 p)"
      using sin_cos2_th_17 sorry
    also have "... = -XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p"
      using A1 xcmplx_1_th_187 sorry
    also have "... = -XCMPLX-0K4 (tanhSIN-COS2K5).FUNCT-1K1 p"
      using sin_cos2_th_17 sorry
    finally have "(tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (tanhSIN-COS2K5).FUNCT-1K1 p"
       sorry
    thus "((coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 p) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p & (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 p) & (tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 (tanhSIN-COS2K5).FUNCT-1K1 p"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_7:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 r) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 r))"
       sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 r) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 r)"
      using sin_cos2_lm_2 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 r)"
      using sin_cos2_th_19 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 r)"
      using sin_cos2_th_19 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 r) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
    thus "(coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_20:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r & (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
  using sin_cos2_lm_2 sin_cos2_lm_7 sorry

mlemma sin_cos2_lm_8:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 r))"
       sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 r) +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 r)"
      using sin_cos2_lm_3 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 r)"
      using sin_cos2_th_19 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 r)"
      using sin_cos2_th_19 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
    thus "(sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_21:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r & (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r"
  using sin_cos2_lm_3 sin_cos2_lm_8 sorry

mlemma sin_cos2_lm_9:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "(tanhSIN-COS2K5).FUNCT-1K1 (p -XCMPLX-0K6 r) =HIDDENR1 (tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 r))"
       sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 r))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 r))"
      using sin_cos2_lm_5 sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (-XCMPLX-0K4 (tanhSIN-COS2K5).FUNCT-1K1 r))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 (-XCMPLX-0K4 r))"
      using sin_cos2_th_19 sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (-XCMPLX-0K4 (tanhSIN-COS2K5).FUNCT-1K1 r))"
      using sin_cos2_th_19 sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
       sorry
    finally have "(tanhSIN-COS2K5).FUNCT-1K1 (p -XCMPLX-0K6 r) =HIDDENR1 ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
       sorry
    thus "(tanhSIN-COS2K5).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_22:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r) & (tanhSIN-COS2K5).FUNCT-1K1 (p -XCMPLX-0K6 r) =XBOOLE-0R4 ((tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 r)"
  using sin_cos2_lm_5 sin_cos2_lm_9 sorry

mtheorem sin_cos2_th_23:
" for p be RealXREAL-0M1 holds ((sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p & (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) & (tanhSIN-COS2K5).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 p)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((tanhSIN-COS2K5).FUNCT-1K1 p)^2SQUARE-1K1)"
proof-
  have " for p be RealXREAL-0M1 holds ((sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p & (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) & (tanhSIN-COS2K5).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 p)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((tanhSIN-COS2K5).FUNCT-1K1 p)^2SQUARE-1K1)"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "(tanhSIN-COS2K5).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =HIDDENR1 (tanhSIN-COS2K5).FUNCT-1K1 (p +XCMPLX-0K2 p)"
       sorry
    also have "... = ((tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 p *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 p)"
      using sin_cos2_lm_5 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 p)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((tanhSIN-COS2K5).FUNCT-1K1 p)^2SQUARE-1K1)"
       sorry
    finally have "(tanhSIN-COS2K5).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 p)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((tanhSIN-COS2K5).FUNCT-1K1 p)^2SQUARE-1K1)"
       sorry
    thus "((sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p & (coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) & (tanhSIN-COS2K5).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 p) =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (tanhSIN-COS2K5).FUNCT-1K1 p)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((tanhSIN-COS2K5).FUNCT-1K1 p)^2SQUARE-1K1)"
      using sin_cos2_lm_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_24:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) & (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1) & ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1"
proof-
  have " for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) & (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1) & ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    have A1: "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 q))"
      using sin_cos2_lm_3 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 q) +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q))"
      using sin_cos2_lm_3 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q))"
      using sin_cos2_th_19 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 q))"
      using sin_cos2_th_19 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
       sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
       sorry
    then have A2: "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 (-XCMPLX-0K4 (((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1)) +XCMPLX-0K2 (((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1))"
       sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1)"
      using sin_cos2_th_14 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M"
      using sin_cos2_th_14 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1"
       sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1"
       sorry
    have "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 (((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1) +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1)-XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
      using A1 sorry
    also have "... = (((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1)-XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
      using sin_cos2_th_14 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 (-XCMPLX-0K4 (((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1))"
       sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using sin_cos2_th_14 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1"
       sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1"
       sorry
    thus "(((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) & (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 q) =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1) & ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_25:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) & (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1) & ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1"
proof-
  have " for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) & (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1) & ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    have A1: "(coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 q))"
      using sin_cos2_lm_2 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 q) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q))"
      using sin_cos2_lm_2 sorry
    also have "... = ((((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 q)) +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q)))+XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 q)))+XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q))"
       sorry
    also have "... = ((((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q) +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p))+XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (-XCMPLX-0K4 q)))+XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)"
      using sin_cos2_th_19 sorry
    also have "... = ((((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q))+XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q))+XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)"
      using sin_cos2_th_19 sorry
    also have "... = ((((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 +XCMPLX-0K2 ((-XCMPLX-0K4 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q))+XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q))+XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 (-XCMPLX-0K4 q) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)"
      using sin_cos2_th_19 sorry
    also have "... = (((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6)+XCMPLX-0K2 (((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)*XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 q)"
      using sin_cos2_th_19 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1"
       sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1"
       sorry
    then have A2: "(coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 (((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1) +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1)+XCMPLX-0K2 (-XCMPLX-0K4 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1)"
       sorry
    also have "... = (((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1)+XCMPLX-0K2 (-XCMPLX-0K4 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1)"
      using sin_cos2_th_14 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1)"
       sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M"
      using sin_cos2_th_14 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1"
       sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1"
       sorry
    have "(coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1) +XCMPLX-0K2 (((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1))"
      using A1 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1)"
      using sin_cos2_th_14 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1)"
       sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M"
      using sin_cos2_th_14 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1"
       sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1"
       sorry
    thus "(((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) & (coshSIN-COS2K3).FUNCT-1K1 (p +XCMPLX-0K2 q) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p -XCMPLX-0K6 q) =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1) & ((sinhSIN-COS2K1).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 q)^2SQUARE-1K1 =XBOOLE-0R4 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 +XCMPLX-0K2 ((sinhSIN-COS2K1).FUNCT-1K1 q)^2SQUARE-1K1"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_26:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) & (sinhSIN-COS2K1).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) & (sinhSIN-COS2K1).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "(\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_lm_8 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))"
      using sin_cos2_lm_2 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1))-XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1))-XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1))"
      using sin_cos2_th_14 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1) +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos2_th_14 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (p /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_lm_6 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (r /XCMPLX-0K7 \<two>\<^sub>M))"
      using sin_cos2_lm_6 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
    have "(\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_lm_3 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))"
      using sin_cos2_lm_7 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1))-XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1))-XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1))"
      using sin_cos2_th_14 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 -XCMPLX-0K6 ((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))"
      using sin_cos2_th_14 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (p /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos2_lm_6 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (r /XCMPLX-0K7 \<two>\<^sub>M))"
      using sin_cos2_lm_6 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r"
       sorry
    thus "(sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) & (sinhSIN-COS2K1).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_27:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) & (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) & (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "(\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)"
      using sin_cos2_th_24 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (p /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M) -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)"
      using sin_cos2_th_18 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (r /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M))"
      using sin_cos2_th_18 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 r"
       sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 r"
       sorry
    have "(\<two>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)"
      using sin_cos2_th_25 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (p /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 (r /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)"
      using sin_cos2_th_18 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (r /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M))"
      using sin_cos2_th_18 sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p"
       sorry
    finally have "(\<two>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p"
       sorry
    thus "(coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M) & (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 r =XBOOLE-0R4 (\<two>\<^sub>M *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_28:
" for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) & (tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
proof-
  have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) & (tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "(sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) =HIDDENR1 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r -XCMPLX-0K6 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
      using sin_cos2_lm_8 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
      using xcmplx_1_th_120 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
      using sin_cos2_th_15 xcmplx_1_th_91 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r"
      using sin_cos2_th_15 xcmplx_1_th_91 sorry
    also have "... = (tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r"
      using sin_cos2_th_17 sorry
    also have "... = (tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r"
      using sin_cos2_th_17 sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) =HIDDENR1 (tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r"
       sorry
    have "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) =HIDDENR1 ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
      using sin_cos2_lm_3 sorry
    also have "... = ((sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
      using xcmplx_1_th_62 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 r)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
      using sin_cos2_th_15 xcmplx_1_th_91 sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r"
      using sin_cos2_th_15 xcmplx_1_th_91 sorry
    also have "... = (tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 r /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 r"
      using sin_cos2_th_17 sorry
    also have "... = (tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r"
      using sin_cos2_th_17 sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) =HIDDENR1 (tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r"
       sorry
    thus "(tanhSIN-COS2K5).FUNCT-1K1 p +XCMPLX-0K2 (tanhSIN-COS2K5).FUNCT-1K1 r =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p +XCMPLX-0K2 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r) & (tanhSIN-COS2K5).FUNCT-1K1 p -XCMPLX-0K6 (tanhSIN-COS2K5).FUNCT-1K1 r =XBOOLE-0R4 (sinhSIN-COS2K1).FUNCT-1K1 (p -XCMPLX-0K6 r) /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 r)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_29:
" for p be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 n =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p)"
proof-
  have " for p be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 n =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?X = "\<lambda>Lamb1.  for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 Lamb1 =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (Lamb1 *XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (Lamb1 *XCMPLX-0K3 p)"
    have A1: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 n =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p)) implies ( for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p))"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A2: " for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 n =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p)"
        have " for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p)"
        proof(rule ballI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          have A3: "(coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p"
            using sin_cos2_def_3 sorry
          also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p"
            using sin_cos2_def_3 sorry
          also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p"
            using sin_cos2_def_1 sorry
          also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)"
            using sin_cos2_def_1 sorry
          also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) /XCMPLX-0K7 \<two>\<^sub>M))"
             sorry
          also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (p *XCMPLX-0K3 n +XCMPLX-0K2 p *XCMPLX-0K3 \<one>\<^sub>M) /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M))"
            using sin_cos2_th_12 sorry
          also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)) /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 n *XCMPLX-0K3 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)) /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M))"
            using sin_cos2_th_12 sorry
          also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 (p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M"
             sorry
          also have "... = (coshSIN-COS2K3).FUNCT-1K1 (p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
            using sin_cos2_def_3 sorry
          finally have "(coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 (p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
             sorry
          have A4: "(coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p"
            using sin_cos2_def_3 sorry
          also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p"
            using sin_cos2_def_1 sorry
          also have "... = (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p"
            using sin_cos2_def_1 sorry
          also have "... = (((((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) /XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p /XCMPLX-0K7 \<two>\<^sub>M))-XCMPLX-0K6 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p) /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) /XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p))/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M)"
            using sin_cos2_def_3 sorry
          also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 p)/XCMPLX-0K7 \<four>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M))"
             sorry
          also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p +XCMPLX-0K2 p) /XCMPLX-0K7 \<four>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 ((exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 n *XCMPLX-0K3 p) *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<four>\<^sub>M)"
            using sin_cos2_th_12 sorry
          also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 (n *XCMPLX-0K3 p +XCMPLX-0K2 p) /XCMPLX-0K7 \<four>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 n *XCMPLX-0K3 p)+XCMPLX-0K2 (-XCMPLX-0K4 p)) /XCMPLX-0K7 \<four>\<^sub>M)"
            using sin_cos2_th_12 sorry
          also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 (p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M"
             sorry
          also have "... = (sinhSIN-COS2K1).FUNCT-1K1 (p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
            using sin_cos2_def_1 sorry
          finally have "(coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p) *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 (p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
             sorry
          have "((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 n *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p)"
            using newton_th_6 sorry
          also have "... = ((coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p))*XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p)"
            using A2 sorry
          also have "... = (sinhSIN-COS2K1).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p) +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p)"
            using A3 A4 sorry
          finally have "((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p) +XCMPLX-0K2 (coshSIN-COS2K3).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p)"
             sorry
          thus "((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p)"
             sorry
        qed "sorry"
        thus " for p be RealXREAL-0M1 holds ((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 p)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?X(0NUMBERSK6)"
      using sin_cos2_th_15 sin_cos2_th_16 newton_th_4 sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A5 A1 sorry
    thus "((coshSIN-COS2K3).FUNCT-1K1 p +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 p) |^NEWTONK1 n =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-1K1 (n *XCMPLX-0K3 p) +XCMPLX-0K2 (sinhSIN-COS2K1).FUNCT-1K1 (n *XCMPLX-0K3 p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_30:
"(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinhSIN-COS2K1) =XBOOLE-0R4 REALNUMBERSK2 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) =XBOOLE-0R4 REALNUMBERSK2) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanhSIN-COS2K5) =XBOOLE-0R4 REALNUMBERSK2"
  using funct_2_def_1 sorry

mlemma sin_cos2_lm_10:
" for d be RealXREAL-0M1 holds (comprealBINOP-2K7).FUNCT-1K1 d =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d"
proof-
  have " for d be RealXREAL-0M1 holds (comprealBINOP-2K7).FUNCT-1K1 d =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d"
  proof(rule ballI)
    fix d assume [ty]: "d be RealXREAL-0M1"
    have "(comprealBINOP-2K7).FUNCT-1K1 d =HIDDENR1 -XCMPLX-0K4 d"
      using binop_2_def_7 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d"
       sorry
    finally show "(comprealBINOP-2K7).FUNCT-1K1 d =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_11:
"domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (comprealBINOP-2K7) =XBOOLE-0R4 REALNUMBERSK2"
  using funct_2_def_1 sorry

mlemma sin_cos2_lm_12:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies ( for p be RealXREAL-0M1 holds f is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(f,p) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)"
proof(rule ballI,rule impI,rule ballI)
  obtain f2 where 
    [ty]:"f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and f2Def:"f2 = REALNUMBERSK2 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
     sorry
  let ?U = "\<lambda>Lamb1. InSUBSET-1K10(-XCMPLX-0K4 Lamb1,REALNUMBERSK2)"
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume A1: "f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
  fix p assume [ty]: "p be RealXREAL-0M1"
  obtain f1 where
    [ty]:"f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
    A2: " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 ?U(p)"
    using funct_2_sch_4 sorry
  have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 =XBOOLE-0R4 REALNUMBERSK2"
    using funcop_1_th_13 sorry
  have " for hy1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1 holds hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be convergentSEQ-2V5 & limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix hy1 assume [ty]: "hy1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
    have A4: " for n be NatNAT-1M1 holds (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =XBOOLE-0R4 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> hy1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A3 sorry
      have A6: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
      then have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
        using A6 A5 funct_2_th_108 sorry
      also have "... = (hy1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *XCMPLX-0K3 (0NUMBERSK6)"
        using funcop_1_th_7 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 0NUMBERSK6"
         sorry
      thus "(hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =XBOOLE-0R4 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
         sorry
    qed "sorry"
    then have A7: "hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be constantFUNCT-1V5"
      using valued_0_def_18 sorry
    have " for n be NatNAT-1M1 holds limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =HIDDENR1 0NUMBERSK6"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =HIDDENR1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A7 seq_4_th_26 sorry
      also have "... = 0NUMBERSK6"
        using A4 sorry
      finally have "limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =HIDDENR1 0NUMBERSK6"
         sorry
      thus "limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =HIDDENR1 0NUMBERSK6"
         sorry
    qed "sorry"
    thus "hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1 be convergentSEQ-2V5 & limSEQ-2K1 (hy1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> hy1) =HIDDENR1 0NUMBERSK6"
      using A7 sorry
  qed "sorry"
  then have A8: "f2 be RestFuncFDIFF-1M1"
    using fdiff_1_def_2 sorry
  have A9: " ex N be NeighbourhoodRCOMP-1M1-of p st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (comprealBINOP-2K7) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 N implies (comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =XBOOLE-0R4 f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p))"
  proof-
    have " ex tVar4 be NeighbourhoodRCOMP-1M1-of p st (tVar4 be NeighbourhoodRCOMP-1M1-of p & tVar4 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (comprealBINOP-2K7)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 tVar4 &  not (comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =XBOOLE-0R4 f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
    proof-
      show " ex tVar4 be NeighbourhoodRCOMP-1M1-of p st (tVar4 be NeighbourhoodRCOMP-1M1-of p & tVar4 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (comprealBINOP-2K7)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 tVar4 &  not (comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =XBOOLE-0R4 f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
      proof(rule bexI[of _ "].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .["])
        have " for r be RealXREAL-0M1 holds r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ implies (comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =XBOOLE-0R4 f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p)"
        proof-
          have " for r be RealXREAL-0M1 holds  not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =XBOOLE-0R4 f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p))"
          proof(rule ballI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            have A10: " for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =XBOOLE-0R4 0NUMBERSK6"
              using xreal_0_def_1 funcop_1_th_7 sorry
            have A11: " for p be RealXREAL-0M1 holds f1 .FUNCT-1K1 p =HIDDENR1 -XCMPLX-0K4 p"
            proof(rule ballI)
              fix p assume [ty]: "p be RealXREAL-0M1"
              have "p inHIDDENR3 REALNUMBERSK2"
                using xreal_0_def_1 sorry
              then have "f1 .FUNCT-1K1 p =XBOOLE-0R4 ?U(p)"
                using A2 sorry
              thus "f1 .FUNCT-1K1 p =HIDDENR1 -XCMPLX-0K4 p"
                 sorry
            qed "sorry"
            have "(comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p"
              using sin_cos2_lm_10 sorry
            also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 r -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p)+XCMPLX-0K2 0NUMBERSK6"
              using sin_cos2_lm_10 sorry
            also have "... = (-XCMPLX-0K4 (r -XCMPLX-0K6 p))+XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p)"
              using A10 sorry
            also have "... = f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p)"
              using A11 sorry
            finally have "(comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =HIDDENR1 f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p)"
               sorry
            thus " not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =XBOOLE-0R4 f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "(].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ be NeighbourhoodRCOMP-1M1-of p & ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (comprealBINOP-2K7)) & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 \<one>\<^sub>M,p +XCMPLX-0K2 \<one>\<^sub>M .[ &  not (comprealBINOP-2K7).FUNCT-1K1 r -XCMPLX-0K6 (comprealBINOP-2K7).FUNCT-1K1 p =XBOOLE-0R4 f1 .FUNCT-1K1 (r -XCMPLX-0K6 p) +XCMPLX-0K2 f2 .FUNCT-1K1 (r -XCMPLX-0K6 p)))"
          using sin_cos2_lm_11 rcomp_1_def_6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
  obtain pp where 
    [ty]:"pp be RealXREAL-0M1" and ppDef:"pp = p"
     sorry
  have A12: "\<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
    using xreal_0_def_1 sorry
  have " for p be RealXREAL-0M1 holds f1 .FUNCT-1K1 p =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    obtain pp where 
      [ty]:"pp be ElementSUBSET-1M1-of REALNUMBERSK2" and ppDef:"pp = p"
      using xreal_0_def_1 sorry
    have "f1 .FUNCT-1K1 p =XBOOLE-0R4 ?U(pp)"
      using A2 sorry
    thus "f1 .FUNCT-1K1 p =XBOOLE-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p"
       sorry
  qed "sorry"
  then have A13: "f1 be LinearFuncFDIFF-1M2"
    using fdiff_1_def_3 sorry
  then have "f is-differentiable-inFDIFF-1R1 pp"
    using A1 A8 A9 fdiff_1_def_4 sorry
  then have "diffFDIFF-1K1(f,pp) =HIDDENR1 f1 .FUNCT-1K1 \<one>\<^sub>M"
    using A1 A13 A8 A9 fdiff_1_def_5 sorry
  also have "... = ?U(\<one>\<^sub>M)"
    using A2 A12 sorry
  finally have "diffFDIFF-1K1(f,pp) =HIDDENR1 ?U(\<one>\<^sub>M)"
     sorry
  thus "f is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(f,p) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    using A1 A13 A8 A9 fdiff_1_def_4 sorry
qed "sorry"

mlemma sin_cos2_lm_13:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p)"
proof-
  have " for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p)"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
    have A2: "p be RealXREAL-0M1 & exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 p"
      using sin_cos_th_65 sorry
    have A3: "f is-differentiable-inFDIFF-1R1 p"
      using A1 sin_cos2_lm_12 sorry
    then have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (diffFDIFF-1K1(exp-RSIN-COSK23,f .FUNCT-1K1 p))*XCMPLX-0K3 (diffFDIFF-1K1(f,p))"
      using A2 fdiff_2_th_13 sorry
    also have "... = (diffFDIFF-1K1(exp-RSIN-COSK23,f .FUNCT-1K1 p))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A1 sin_cos2_lm_12 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using sin_cos_th_65 sorry
    finally have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
       sorry
    thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p)"
      using A2 A3 fdiff_2_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_14:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p) =XBOOLE-0R4 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p) =XBOOLE-0R4 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A1: "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    assume A2: "f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
    then have "(exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p)"
      using sin_cos2_lm_10 sorry
    also have "... = ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 p"
      using A2 A1 funct_2_th_15 sorry
    finally have "(exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p) =HIDDENR1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 p"
       sorry
    thus "(exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p) =XBOOLE-0R4 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_15:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p & exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p) & diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) & diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
proof-
  have " for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies ((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p & exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p) & diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) & diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A1: "p be RealXREAL-0M1 & exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 p"
      using sin_cos_th_65 sorry
    assume A2: "f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
    then have A3: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p"
      using sin_cos2_lm_13 sorry
    then have A4: "diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,p) +XCMPLX-0K2 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p)"
      using A1 fdiff_1_th_13 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p)"
      using sin_cos_th_65 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p)"
      using A2 sin_cos2_lm_13 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p)"
      using A2 sin_cos2_lm_10 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
       sorry
    finally have "diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
       sorry
    have "diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 diffFDIFF-1K1(exp-RSIN-COSK23,p) -XCMPLX-0K6 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p)"
      using A1 A3 fdiff_1_th_14 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p)"
      using sin_cos_th_65 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 p)"
      using A2 sin_cos2_lm_13 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p)"
      using A2 sin_cos2_lm_10 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
       sorry
    finally have "diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
       sorry
    thus "((exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p & exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p) & diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) & diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
      using A1 A3 A4 fdiff_1_th_13 fdiff_1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_16:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),p) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p))"
proof-
  have " for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),p) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p))"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
    then have "p be RealXREAL-0M1 & exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 p"
      using sin_cos2_lm_15 sorry
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),p) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,p))"
      using fdiff_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_17:
" for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (sinhSIN-COS2K1).FUNCT-1K1 p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (sinhSIN-COS2K1).FUNCT-1K1 p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    fix ff assume [ty]: "ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A2: "ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) =XBOOLE-0R4 REALNUMBERSK2"
      using A2 funct_2_def_1 valued_1_th_12 sorry
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)) =XBOOLE-0R4 REALNUMBERSK2"
      using A2 funct_2_def_1 sorry
    have "(sinhSIN-COS2K1).FUNCT-1K1 p =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos2_def_1 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff).FUNCT-1K1 p)"
      using A2 sin_cos2_lm_14 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff).FUNCT-1K1 p"
      using A1 A3 sin_cos_th_47 valued_1_th_13 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
      using A1 A4 valued_1_def_5 sorry
    finally have "(sinhSIN-COS2K1).FUNCT-1K1 p =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
       sorry
    thus "(sinhSIN-COS2K1).FUNCT-1K1 p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_18:
" for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies sinhSIN-COS2K1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)"
proof(rule ballI,rule impI)
  fix ff assume [ty]: "ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume "ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
  then have A1: "REALNUMBERSK2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)) & ( for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 REALNUMBERSK2 implies (sinhSIN-COS2K1).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p)"
    using sin_cos2_lm_17 funct_2_def_1 sorry
  have "REALNUMBERSK2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinhSIN-COS2K1)"
    using funct_2_def_1 sorry
  thus "sinhSIN-COS2K1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)"
    using A1 partfun1_th_5 sorry
qed "sorry"

mtheorem sin_cos2_th_31:
" for p be RealXREAL-0M1 holds sinhSIN-COS2K1 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds sinhSIN-COS2K1 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    let ?ff = "comprealBINOP-2K7"
    have A1: "sinhSIN-COS2K1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?ff)"
      using sin_cos2_lm_18 sorry
    have "diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?ff),p)"
      using sin_cos2_lm_18 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?ff,p))"
      using sin_cos2_lm_16 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))"
      using sin_cos2_lm_15 sorry
    also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (coshSIN-COS2K3).FUNCT-1K1 p"
      using sin_cos2_def_3 sorry
    finally have "diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
       sorry
    thus "sinhSIN-COS2K1 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
      using A1 sin_cos2_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_19:
" for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff),p) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff,p))"
proof-
  have " for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff),p) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff,p))"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix ff assume [ty]: "ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
    then have "p be RealXREAL-0M1 & exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff is-differentiable-inFDIFF-1R1 p"
      using sin_cos2_lm_15 sorry
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff),p) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff,p))"
      using fdiff_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_20:
" for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (coshSIN-COS2K3).FUNCT-1K1 p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds  for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies (coshSIN-COS2K3).FUNCT-1K1 p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "p inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    fix ff assume [ty]: "ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A2: "ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff) =XBOOLE-0R4 REALNUMBERSK2"
      using A2 funct_2_def_1 valued_1_def_1 sorry
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)) =XBOOLE-0R4 REALNUMBERSK2"
      using A2 funct_2_def_1 sorry
    have "(coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos2_def_3 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 p))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff).FUNCT-1K1 p)"
      using A2 sin_cos2_lm_14 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff).FUNCT-1K1 p"
      using A1 A3 sin_cos_th_47 valued_1_def_1 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
      using A1 A4 valued_1_def_5 sorry
    finally have "(coshSIN-COS2K3).FUNCT-1K1 p =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
       sorry
    thus "(coshSIN-COS2K3).FUNCT-1K1 p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_21:
" for ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7 implies coshSIN-COS2K3 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)"
proof(rule ballI,rule impI)
  fix ff assume [ty]: "ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume "ff =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> comprealBINOP-2K7"
  then have A1: "REALNUMBERSK2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)) & ( for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 REALNUMBERSK2 implies (coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)).FUNCT-1K1 p)"
    using sin_cos2_lm_20 funct_2_def_1 sorry
  have "REALNUMBERSK2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)"
    using funct_2_def_1 sorry
  thus "coshSIN-COS2K3 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)"
    using A1 partfun1_th_5 sorry
qed "sorry"

mtheorem sin_cos2_th_32:
" for p be RealXREAL-0M1 holds coshSIN-COS2K3 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds coshSIN-COS2K3 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    obtain ff where 
      [ty]:"ff be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and ffDef:"ff = comprealBINOP-2K7"
       sorry
    have A1: "coshSIN-COS2K3 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff)"
      using sin_cos2_lm_21 sorry
    have "diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 diffFDIFF-1K1((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff),p)"
      using sin_cos2_lm_21 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ff,p))"
      using sin_cos2_lm_19 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))"
      using sin_cos2_lm_15 sorry
    also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p"
      using sin_cos2_def_1 sorry
    finally have "diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
       sorry
    thus "coshSIN-COS2K3 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
      using A1 sin_cos2_lm_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_22:
" for p be RealXREAL-0M1 holds (sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3),p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
proof-
  have " for p be RealXREAL-0M1 holds (sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3),p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "p be RealXREAL-0M1 & (coshSIN-COS2K3).FUNCT-1K1 p <>HIDDENR2 0NUMBERSK6"
      using sin_cos2_th_15 sorry
    have A2: "sinhSIN-COS2K1 is-differentiable-inFDIFF-1R1 p & coshSIN-COS2K3 is-differentiable-inFDIFF-1R1 p"
      using sin_cos2_th_31 sin_cos2_th_32 sorry
    then have "diffFDIFF-1K1((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3),p) =HIDDENR1 ((diffFDIFF-1K1(sinhSIN-COS2K1,p))*XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (diffFDIFF-1K1(coshSIN-COS2K3,p))*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
      using A1 fdiff_2_th_14 sorry
    also have "... = ((coshSIN-COS2K3).FUNCT-1K1 p *XCMPLX-0K3 (coshSIN-COS2K3).FUNCT-1K1 p -XCMPLX-0K6 (diffFDIFF-1K1(coshSIN-COS2K3,p))*XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
      using sin_cos2_th_31 sorry
    also have "... = (((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1 -XCMPLX-0K6 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 (sinhSIN-COS2K1).FUNCT-1K1 p)/XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
      using sin_cos2_th_32 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
      using sin_cos2_th_14 sorry
    finally have "diffFDIFF-1K1((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3),p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
       sorry
    thus "(sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3),p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
      using A1 A2 fdiff_2_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_23:
"tanhSIN-COS2K5 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)"
proof-
  have " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)"
  proof-
    have "0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) implies  False "
    proof(rule impI)
      assume "0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)"
      then have " ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st p inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) & 0NUMBERSK6 =XBOOLE-0R4 (coshSIN-COS2K3).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p"
        using partfun1_th_3 sorry
      thus " False "
        using sin_cos2_th_15 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  then have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinhSIN-COS2K1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }) & (coshSIN-COS2K3)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
    using funct_1_th_72 rfunct_1_def_1 sorry
  have " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 REALNUMBERSK2 implies (tanhSIN-COS2K5).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 ((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)).FUNCT-1K1 p"
  proof-
    have " for p be RealXREAL-0M1 holds  not (((p be setHIDDENM2 & p be ElementSUBSET-1M1-of REALNUMBERSK2) & p inTARSKIR2 REALNUMBERSK2) &  not (tanhSIN-COS2K5).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 ((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)).FUNCT-1K1 p)"
    proof(rule ballI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      have "p inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      then have "((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)).FUNCT-1K1 p =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p *XCMPLX-0K3 ((coshSIN-COS2K3).FUNCT-1K1 p)\<inverse>XCMPLX-0K5"
        using A1 sin_cos2_th_30 rfunct_1_def_1 sorry
      also have "... = (sinhSIN-COS2K1).FUNCT-1K1 p /XCMPLX-0K7 (coshSIN-COS2K3).FUNCT-1K1 p"
        using xcmplx_0_def_9 sorry
      also have "... = (tanhSIN-COS2K5).FUNCT-1K1 p"
        using sin_cos2_th_17 sorry
      finally have "((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)).FUNCT-1K1 p =HIDDENR1 (tanhSIN-COS2K5).FUNCT-1K1 p"
         sorry
      thus " not (((p be setHIDDENM2 & p be ElementSUBSET-1M1-of REALNUMBERSK2) & p inTARSKIR2 REALNUMBERSK2) &  not (tanhSIN-COS2K5).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 ((sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)).FUNCT-1K1 p)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "tanhSIN-COS2K5 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinhSIN-COS2K1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)"
    using A1 sin_cos2_th_30 partfun1_th_5 sorry
qed

mtheorem sin_cos2_th_33:
" for p be RealXREAL-0M1 holds tanhSIN-COS2K5 is-differentiable-inFDIFF-1R1 p & diffFDIFF-1K1(tanhSIN-COS2K5,p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
  using sin_cos2_lm_22 sin_cos2_lm_23 sorry

mtheorem sin_cos2_th_34:
" for p be RealXREAL-0M1 holds sinhSIN-COS2K1 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds sinhSIN-COS2K1 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 & REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinhSIN-COS2K1)"
      using funct_2_def_1 sorry
    have " for p be RealXREAL-0M1 holds p inHIDDENR3 REALNUMBERSK2 implies sinhSIN-COS2K1 is-differentiable-inFDIFF-1R1 p"
      using sin_cos2_th_31 sorry
    thus "sinhSIN-COS2K1 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(sinhSIN-COS2K1,p) =HIDDENR1 (coshSIN-COS2K3).FUNCT-1K1 p"
      using A1 sin_cos2_th_31 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_35:
" for p be RealXREAL-0M1 holds coshSIN-COS2K3 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
proof-
  have " for p be RealXREAL-0M1 holds coshSIN-COS2K3 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 & REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (coshSIN-COS2K3)"
      using funct_2_def_1 sorry
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 REALNUMBERSK2 implies coshSIN-COS2K3 is-differentiable-inFDIFF-1R1 r"
      using sin_cos2_th_32 sorry
    thus "coshSIN-COS2K3 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(coshSIN-COS2K3,p) =HIDDENR1 (sinhSIN-COS2K1).FUNCT-1K1 p"
      using A1 sin_cos2_th_32 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_36:
" for p be RealXREAL-0M1 holds tanhSIN-COS2K5 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(tanhSIN-COS2K5,p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
proof-
  have " for p be RealXREAL-0M1 holds tanhSIN-COS2K5 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(tanhSIN-COS2K5,p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 & ( for p be RealXREAL-0M1 holds p inHIDDENR3 REALNUMBERSK2 implies tanhSIN-COS2K5 is-differentiable-inFDIFF-1R1 p)"
      using sin_cos2_lm_22 sin_cos2_lm_23 sorry
    thus "tanhSIN-COS2K5 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & diffFDIFF-1K1(tanhSIN-COS2K5,p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((coshSIN-COS2K3).FUNCT-1K1 p)^2SQUARE-1K1"
      using sin_cos2_lm_22 sin_cos2_lm_23 sin_cos2_th_30 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma sin_cos2_lm_24:
" for p be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >=XXREAL-0R2 \<two>\<^sub>M"
proof-
  have " for p be RealXREAL-0M1 holds (exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >=XXREAL-0R2 \<two>\<^sub>M"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "(exp-RSIN-COSK23).FUNCT-1K1 p >=XXREAL-0R2 0NUMBERSK6 & (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >=XXREAL-0R2 0NUMBERSK6"
      using sin_cos_th_54 sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((exp-RSIN-COSK23).FUNCT-1K1 (p +XCMPLX-0K2 (-XCMPLX-0K4 p)))"
      using sin_cos2_th_12 sorry
    also have "... = \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using sin_cos_th_51 sin_cos_def_23 square_1_th_18 sorry
    finally have "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((exp-RSIN-COSK23).FUNCT-1K1 p *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) =HIDDENR1 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
       sorry
    thus "(exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >=XXREAL-0R2 \<two>\<^sub>M"
      using A1 sin_cos2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_37:
" for p be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 p >=XXREAL-0R2 \<one>\<^sub>M"
proof-
  have " for p be RealXREAL-0M1 holds (coshSIN-COS2K3).FUNCT-1K1 p >=XXREAL-0R2 \<one>\<^sub>M"
  proof(rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have "((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 \<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos2_lm_24 xreal_1_th_72 sorry
    thus "(coshSIN-COS2K3).FUNCT-1K1 p >=XXREAL-0R2 \<one>\<^sub>M"
      using sin_cos2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos2_th_38:
" for p be RealXREAL-0M1 holds sinhSIN-COS2K1 is-continuous-inFCONT-1R1 p"
  using sin_cos2_th_31 fdiff_1_th_24 sorry

mtheorem sin_cos2_th_39:
" for p be RealXREAL-0M1 holds coshSIN-COS2K3 is-continuous-inFCONT-1R1 p"
  using sin_cos2_th_32 fdiff_1_th_24 sorry

mtheorem sin_cos2_th_40:
" for p be RealXREAL-0M1 holds tanhSIN-COS2K5 is-continuous-inFCONT-1R1 p"
  using sin_cos2_lm_22 sin_cos2_lm_23 fdiff_1_th_24 sorry

mtheorem sin_cos2_th_41:
"(sinhSIN-COS2K1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
  using sin_cos2_th_34 fdiff_1_th_25 sorry

mtheorem sin_cos2_th_42:
"(coshSIN-COS2K3) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
  using sin_cos2_th_35 fdiff_1_th_25 sorry

mtheorem sin_cos2_th_43:
"(tanhSIN-COS2K5) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
  using sin_cos2_th_36 fdiff_1_th_25 sorry

mtheorem sin_cos2_th_44:
" for p be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p <XXREAL-0R3 \<one>\<^sub>M & (tanhSIN-COS2K5).FUNCT-1K1 p >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for p be RealXREAL-0M1 holds (tanhSIN-COS2K5).FUNCT-1K1 p <XXREAL-0R3 \<one>\<^sub>M & ((tanhSIN-COS2K5).FUNCT-1K1 p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  False )"
  proof(rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    have A1: "(exp-RSIN-COSK23).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6 & (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_th_54 sorry
    show "(tanhSIN-COS2K5).FUNCT-1K1 p <XXREAL-0R3 \<one>\<^sub>M"
    proof-
      have "(tanhSIN-COS2K5).FUNCT-1K1 p >=XXREAL-0R2 \<one>\<^sub>M implies  False "
      proof(rule impI)
        assume "(tanhSIN-COS2K5).FUNCT-1K1 p >=XXREAL-0R2 \<one>\<^sub>M"
        then have A2: "((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) >=XXREAL-0R2 \<one>\<^sub>M"
          using sin_cos2_def_5 sorry
        have "(exp-RSIN-COSK23).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6 & (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 sorry
        then have A3: "(((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)))*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) =XBOOLE-0R4 (exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
          using xcmplx_1_th_87 sorry
        have "(exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >=XXREAL-0R2 \<two>\<^sub>M"
          using sin_cos2_lm_24 sorry
        then have "(((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)))*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) >=XXREAL-0R2 \<one>\<^sub>M *XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))"
          using A2 xreal_1_th_64 sorry
        then have "((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p >=XXREAL-0R2 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))-XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 p"
          using A3 xreal_1_th_9 sorry
        then have A4: "(-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >=XXREAL-0R2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
          using xreal_1_th_6 sorry
        have "(exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_54 sorry
        thus " False "
          using A4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "(tanhSIN-COS2K5).FUNCT-1K1 p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    then have A5: "((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
      using sin_cos2_def_5 sorry
    have "(exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) >=XXREAL-0R2 \<two>\<^sub>M"
      using sin_cos2_lm_24 sorry
    then have "(((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)))*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)) <=XXREAL-0R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))"
      using A5 xreal_1_th_64 sorry
    then have "(exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) <=XXREAL-0R1 -XCMPLX-0K4 ((exp-RSIN-COSK23).FUNCT-1K1 p +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))"
      using A1 xcmplx_1_th_87 sorry
    then have A6: "((exp-RSIN-COSK23).FUNCT-1K1 p -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p) <=XXREAL-0R1 ((-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 p)+XCMPLX-0K2 (-XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)))+XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 (-XCMPLX-0K4 p)"
      using xreal_1_th_6 sorry
    have "(exp-RSIN-COSK23).FUNCT-1K1 p >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_th_54 sorry
    thus " False "
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
