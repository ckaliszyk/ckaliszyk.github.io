theory fdiff_7
  imports power sin_cos6 fdiff_4
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, r, a, b for "RealXREAL-0M1"
reserve n for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve Z for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2, f3 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem fdiff_7_th_1:
" for x be RealXREAL-0M1 holds x #ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 x ^2SQUARE-1K1"
proof-
  have " for x be RealXREAL-0M1 holds x #ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 x ^2SQUARE-1K1"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "x #ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 x  |^NEWTONK1 \<two>\<^sub>M"
      using prepower_th_36 sorry
    also have "... = x ^2SQUARE-1K1"
      using newton_th_81 sorry
    finally have "x #ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 x ^2SQUARE-1K1"
       sorry
    thus "x #ZPREPOWERK3 \<two>\<^sub>M =HIDDENR1 x ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_2:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 sqrtSQUARE-1K3 x"
proof-
  have " for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 sqrtSQUARE-1K3 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "x >XXREAL-0R4 0NUMBERSK6"
    then have A2: "x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using prepower_th_81 sorry
    have "x =HIDDENR1 x #RPREPOWERK6 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M)"
      using A1 prepower_th_72 sorry
    also have "... = (x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))#RPREPOWERK6 \<two>\<^sub>M"
      using A1 prepower_th_91 sorry
    also have "... = (x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))#QPREPOWERK4 \<two>\<^sub>M"
      using A1 prepower_th_74 prepower_th_81 sorry
    also have "... = (x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))to-powerPOWERK2 \<two>\<^sub>M"
      using A1 power_th_44 prepower_th_81 sorry
    also have "... = (x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
      using power_th_46 sorry
    finally have "x =HIDDENR1 (x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
       sorry
    thus "x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 sqrtSQUARE-1K3 x"
      using A1 A2 square_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_3:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 x"
proof-
  have " for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "x >XXREAL-0R4 0NUMBERSK6"
    then have "x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x #RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using prepower_th_76 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 x"
      using A1 fdiff_7_th_2 sorry
    finally show "x #RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_7_lm_1:
" for x be RealXREAL-0M1 holds \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
proof-
  have " for x be RealXREAL-0M1 holds \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "(cosSIN-COSK20 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 (x /XCMPLX-0K7 \<two>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos5_th_21 sorry
    also have "... = (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(cosSIN-COSK20 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_def_19 sorry
    also have "... = \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
      using sin_cos_def_19 sorry
    finally have "\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
       sorry
    thus "\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_7_lm_2:
" for x be RealXREAL-0M1 holds \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
proof-
  have " for x be RealXREAL-0M1 holds \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "(sinSIN-COSK18 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 (\<two>\<^sub>M *XCMPLX-0K3 (x /XCMPLX-0K7 \<two>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos5_th_20 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    finally have "(sinSIN-COSK18 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 cosSIN-COSK20 x)/XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_def_17 sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
      using sin_cos_def_19 sorry
    finally have "\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
       sorry
    thus "\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_4:
" for r be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for r be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      and A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))"
    have A3: "arcsinSIN-COS6K1 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_26 sin_cos6_th_83 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A1 xxreal_1_th_4 sorry
      have "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r *XCMPLX-0K3 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))"
        using A2 A3 A4 fdiff_1_th_20 sorry
      also have "... = r *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A5 sin_cos6_th_83 sorry
      also have "... = r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      finally have "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A2 A3 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_5:
" for r be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for r be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      and A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))"
    have A3: "arccosSIN-COS6K3 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_26 sin_cos6_th_106 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A1 xxreal_1_th_4 sorry
      have "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 r *XCMPLX-0K3 (diffFDIFF-1K1(arccosSIN-COS6K3,x))"
        using A2 A3 A4 fdiff_1_th_20 sorry
      also have "... = r *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A5 sin_cos6_th_106 sorry
      also have "... = -XCMPLX-0K4 r *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
         sorry
      also have "... = -XCMPLX-0K4 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      finally have "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 r /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A2 A3 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_6:
" for x be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M implies (arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for x be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x & (f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-inFDIFF-1R1 x"
      and A2: "f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have "f .FUNCT-1K1 x inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using A2 sorry
    then have A3: "arcsinSIN-COS6K1 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
      using fdiff_1_th_9 sin_cos6_th_83 sorry
    then have "diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(arcsinSIN-COS6K1,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
      using A1 fdiff_2_th_13 sorry
    also have "... = (diffFDIFF-1K1(f,x))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1))"
      using A2 sin_cos6_th_83 sorry
    also have "... = (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
      using xcmplx_1_th_99 sorry
    finally have "diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
       sorry
    thus "(arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
      using A1 A3 fdiff_2_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_7:
" for x be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M implies (arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for x be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x & (f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-inFDIFF-1R1 x"
      and A2: "f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have "f .FUNCT-1K1 x inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      using A2 sorry
    then have A3: "arccosSIN-COS6K3 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
      using fdiff_1_th_9 sin_cos6_th_106 sorry
    then have "diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(arccosSIN-COS6K3,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
      using A1 fdiff_2_th_13 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
      using A2 sin_cos6_th_106 sorry
    also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1))"
       sorry
    also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
      using xcmplx_1_th_99 sorry
    finally have "diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
       sorry
    thus "(arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
      using A1 A3 fdiff_2_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_8:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (arcsinSIN-COS6K1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) & (Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (arcsinSIN-COS6K1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (arcsinSIN-COS6K1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "arcsinSIN-COS6K1 is-differentiable-inFDIFF-1R1 x & (arcsinSIN-COS6K1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 fdiff_1_th_9 sin_cos6_th_83 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A5: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have A7: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 xxreal_1_th_4 sorry
      have "arcsinSIN-COS6K1 is-differentiable-inFDIFF-1R1 x & (arcsinSIN-COS6K1).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 A6 fdiff_1_th_9 sin_cos6_th_83 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1),x) =HIDDENR1 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))/XCMPLX-0K7 (arcsinSIN-COS6K1).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))/XCMPLX-0K7 (arcsinSIN-COS6K1).FUNCT-1K1 x"
        using A7 sin_cos6_th_83 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x)"
        using A5 A6 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x)))"
      using A1 A4 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_9:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (arccosSIN-COS6K3).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) & (Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (arccosSIN-COS6K3).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (arccosSIN-COS6K3).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "arccosSIN-COS6K3 is-differentiable-inFDIFF-1R1 x & (arccosSIN-COS6K3).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 fdiff_1_th_9 sin_cos6_th_106 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A5: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have A7: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 xxreal_1_th_4 sorry
      have "arccosSIN-COS6K3 is-differentiable-inFDIFF-1R1 x & (arccosSIN-COS6K3).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A3 A6 fdiff_1_th_9 sin_cos6_th_106 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3),x) =HIDDENR1 (diffFDIFF-1K1(arccosSIN-COS6K3,x))/XCMPLX-0K7 (arccosSIN-COS6K3).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))/XCMPLX-0K7 (arccosSIN-COS6K3).FUNCT-1K1 x"
        using A7 sin_cos6_th_106 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))/XCMPLX-0K7 (arccosSIN-COS6K3).FUNCT-1K1 x"
        using xcmplx_1_th_187 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x)"
        using A5 A6 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1) *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x)))"
      using A1 A4 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_10:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "arcsinSIN-COS6K1 is-differentiable-inFDIFF-1R1 x"
        using A2 fdiff_1_th_9 sin_cos6_th_83 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A4: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have A6: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 xxreal_1_th_4 sorry
      have A7: "arcsinSIN-COS6K1 is-differentiable-inFDIFF-1R1 x"
        using A2 A5 fdiff_1_th_9 sin_cos6_th_83 sorry
      have "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1),x)"
        using A4 A5 fdiff_1_def_7 sorry
      also have "... = (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))"
        using A7 taylor_1_th_3 sorry
      also have "... = (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A6 sin_cos6_th_83 sorry
      also have "... = (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      finally have "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_11:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "arccosSIN-COS6K3 is-differentiable-inFDIFF-1R1 x"
        using A2 fdiff_1_th_9 sin_cos6_th_106 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A4: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have A6: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 xxreal_1_th_4 sorry
      have A7: "arccosSIN-COS6K3 is-differentiable-inFDIFF-1R1 x"
        using A2 A5 fdiff_1_th_9 sin_cos6_th_106 sorry
      have "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3),x)"
        using A4 A5 fdiff_1_def_7 sorry
      also have "... = (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(arccosSIN-COS6K3,x))"
        using A7 taylor_1_th_3 sorry
      also have "... = (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A6 sin_cos6_th_106 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
         sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      finally have "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_12:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))"
      using A1 valued_1_def_5 sorry
    then have A4: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_7_th_10 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1),x))"
        using A1 A4 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A5 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A2 A3 A5 fdiff_7_th_10 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 ((arcsinSIN-COS6K1).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_74 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using prepower_th_35 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_13:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (arccosSIN-COS6K3).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (arccosSIN-COS6K3).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))"
      using A1 valued_1_def_5 sorry
    then have A4: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_7_th_11 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (arccosSIN-COS6K3).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3),x))"
        using A1 A4 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A5 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A2 A3 A5 fdiff_7_th_11 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
         sorry
      also have "... = -XCMPLX-0K4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 ((arccosSIN-COS6K3).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_74 sorry
      also have "... = -XCMPLX-0K4 (arccosSIN-COS6K3).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using prepower_th_35 sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (arccosSIN-COS6K3).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (arccosSIN-COS6K3).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (arccosSIN-COS6K3).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_14:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using tarski_def_3 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
      using A2 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A2 A5 A7 fdiff_1_th_9 sorry
      thus "(arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_7_th_6 sorry
    qed "sorry"
    then have A9: "(arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A2 A5 A10 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
        using A11 fdiff_7_th_6 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
        using A5 A10 fdiff_1_def_7 sorry
      also have "... = a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
        using A4 A3 A10 fdiff_1_th_23 sorry
      also have "... = a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)"
        using A2 A10 sorry
      finally have "diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)"
         sorry
      thus "(((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_15:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using tarski_def_3 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
      using A2 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A2 A5 A7 fdiff_1_th_9 sorry
      thus "(arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_7_th_7 sorry
    qed "sorry"
    then have A9: "(arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 sorry
      have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A2 A5 A10 fdiff_1_th_9 sorry
      then have "diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
        using A11 fdiff_7_th_7 sorry
      also have "... = -XCMPLX-0K4 (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
        using A5 A10 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (f .FUNCT-1K1 x)^2SQUARE-1K1)"
        using A4 A3 A10 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)"
        using A2 A10 sorry
      finally have "diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)"
         sorry
      thus "(((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)^2SQUARE-1K1)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_16:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using xboole_1_th_18 sorry
    then have A5: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: "arcsinSIN-COS6K1 is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_26 sin_cos6_th_83 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 xxreal_1_th_4 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)) +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))"
        using A1 A5 A6 A7 fdiff_1_th_21 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x *XCMPLX-0K3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))"
        using A5 A7 fdiff_1_def_7 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))"
        using A4 A3 A7 fdiff_1_th_23 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A8 sin_cos6_th_83 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A7 funct_1_th_18 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A5 A6 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_17:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using xboole_1_th_18 sorry
    then have A5: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: "arccosSIN-COS6K3 is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_26 sin_cos6_th_106 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 xxreal_1_th_4 sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)) +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arccosSIN-COS6K3,x))"
        using A1 A5 A6 A7 fdiff_1_th_21 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arccosSIN-COS6K3,x))"
        using A5 A7 fdiff_1_def_7 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arccosSIN-COS6K3,x))"
        using A4 A3 A7 fdiff_1_th_23 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A8 sin_cos6_th_106 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A7 funct_1_th_18 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
         sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A5 A6 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_18:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) & (Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b)) implies f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using xboole_1_th_18 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: "arcsinSIN-COS6K1 is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_26 sin_cos6_th_83 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 xxreal_1_th_4 sorry
      have "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f,x)) +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))"
        using A1 A5 A6 A7 fdiff_1_th_21 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))"
        using A5 A7 fdiff_1_def_7 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arcsinSIN-COS6K1,x))"
        using A3 A4 A7 fdiff_1_th_23 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A8 sin_cos6_th_83 sorry
      also have "... = a *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A3 A7 sorry
      also have "... = a *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      finally have "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A5 A6 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_19:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) & (Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b)) implies f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using xboole_1_th_18 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: "arccosSIN-COS6K3 is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_26 sin_cos6_th_106 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 \<one>\<^sub>M"
        using A2 xxreal_1_th_4 sorry
      have "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f,x)) +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arccosSIN-COS6K3,x))"
        using A1 A5 A6 A7 fdiff_1_th_21 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arccosSIN-COS6K3,x))"
        using A5 A7 fdiff_1_def_7 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(arccosSIN-COS6K3,x))"
        using A3 A4 A7 fdiff_1_th_23 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A8 sin_cos6_th_106 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x *XCMPLX-0K3 a -XCMPLX-0K6 f .FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
         sorry
      also have "... = a *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))"
        using A3 A7 sorry
      also have "... = a *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      finally have "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 (arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)))"
      using A1 A5 A6 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_20:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6 & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M)"
      using A1 A2 valued_1_def_5 sorry
    then have A4: "(arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_7_th_14 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A4 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A5 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)^2SQUARE-1K1))"
        using A3 A5 fdiff_7_th_14 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
        using xcmplx_1_th_74 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_21:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6 & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M)"
      using A1 A2 valued_1_def_5 sorry
    then have A4: "(arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using fdiff_7_th_15 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A4 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A4 A5 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<two>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)^2SQUARE-1K1))"
        using A3 A5 fdiff_7_th_15 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1))"
         sorry
      also have "... = -XCMPLX-0K4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
        using xcmplx_1_th_74 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 x)^2SQUARE-1K1)))"
      using A1 A4 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_22:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6))) implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A2 tarski_def_3 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x"
      using A4 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 A5 fdiff_4_th_12 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A4 A7 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A9: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A4 A7 fdiff_1_th_9 sorry
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 A2 A10 funct_1_th_11 sorry
      then have A12: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using valued_1_th_13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A4 A10 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A3 taylor_1_def_1 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have "((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A9 A10 fdiff_1_def_7 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A11 taylor_1_th_22 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 x)"
        using A2 A3 A5 A6 A10 fdiff_4_th_12 sorry
      also have "... = -XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A2 A12 sorry
      finally have "((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A8 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_23:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[) & f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & (f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6)))) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      and A3: "f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      and A4: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6"
    have A6: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_1 sorry
    then have A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    have A8: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))"
      using A6 xboole_1_th_18 sorry
    then have A9: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_7_th_16 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A5 sorry
    then have A11: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A3 A4 A7 fdiff_7_th_22 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A13: "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A3 A7 funct_1_th_11 sorry
      then have A14: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using valued_1_th_13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A5 A13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A4 taylor_1_def_1 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have "f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A5 A13 sorry
      then have A15: "\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using A3 A14 fdiff_7_th_1 sorry
      have "(\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using fdiff_7_th_1 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using A15 fdiff_7_th_3 sorry
      finally have "(\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A16: "x inHIDDENR3 Z"
      then have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1),x) +XCMPLX-0K2 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A9 A11 fdiff_1_th_18 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A9 A16 fdiff_1_def_7 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1))`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A16 fdiff_1_def_7 sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))+XCMPLX-0K2 ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A2 A8 A16 fdiff_7_th_16 sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))+XCMPLX-0K2 (-XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A3 A4 A10 A7 A16 fdiff_7_th_22 sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))-XCMPLX-0K6 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 x +XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))-XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using A12 A16 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 x"
         sorry
      finally show "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arcsinSIN-COS6K1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 x))"
      using A1 A9 A11 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_24:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[) & f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .[ & (f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6)))) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "Z c=TARSKIR1 ].RCOMP-1K2 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .["
      and A3: "f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      and A4: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & x <>HIDDENR2 0NUMBERSK6"
    have A6: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_th_12 sorry
    then have A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    have A8: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))"
      using A6 xboole_1_th_18 sorry
    then have A9: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_7_th_17 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A5 sorry
    then have A11: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A3 A4 A7 fdiff_7_th_22 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A13: "x inHIDDENR3 Z"
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A3 A7 funct_1_th_11 sorry
      then have A14: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using valued_1_th_13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A5 A13 sorry
      also have "... = \<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A4 taylor_1_def_1 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have "f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A5 A13 sorry
      then have A15: "\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using A3 A14 fdiff_7_th_1 sorry
      have "(\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using fdiff_7_th_1 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using A15 fdiff_7_th_3 sorry
      finally have "(\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
         sorry
      thus "x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A16: "x inHIDDENR3 Z"
      then have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3),x) -XCMPLX-0K6 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A9 A11 fdiff_1_th_19 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A9 A16 fdiff_1_def_7 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3))`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A16 fdiff_1_def_7 sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))-XCMPLX-0K6 ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A2 A8 A16 fdiff_7_th_17 sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))-XCMPLX-0K6 (-XCMPLX-0K4 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A3 A4 A10 A7 A16 fdiff_7_th_22 sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))+XCMPLX-0K2 x *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 x -XCMPLX-0K6 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1))+XCMPLX-0K2 x /XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)"
        using A12 A16 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 x"
         sorry
      finally show "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (arccosSIN-COS6K3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 x))"
      using A1 A9 A11 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_25:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using xboole_1_th_18 sorry
    have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A3 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a"
        using A2 sorry
      thus "f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
        using xcmplx_1_th_99 sorry
    qed "sorry"
    then have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6 & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
      using A2 sorry
    then have A7: "(arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_7_th_14 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    then have A9: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)^2SQUARE-1K1)"
        using A6 A5 fdiff_7_th_14 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using xcmplx_1_th_78 sorry
      finally have "(((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
      thus "(((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      then have A12: "((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (f .FUNCT-1K1 x)"
        using A5 funct_1_th_12 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a)"
        using A2 A11 sorry
      finally have "((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a)"
         sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)) +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A9 A7 A11 fdiff_1_th_21 sorry
      also have "... = ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A9 A11 fdiff_1_def_7 sorry
      also have "... = ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A4 A8 A11 fdiff_1_th_23 sorry
      also have "... = ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A11 fdiff_1_def_7 sorry
      also have "... = ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 funct_1_th_18 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))"
        using A10 A11 A12 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using xcmplx_1_th_99 sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))))"
      using A1 A9 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_26:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using xboole_1_th_18 sorry
    have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A3 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a"
        using A2 sorry
      thus "f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
        using xcmplx_1_th_99 sorry
    qed "sorry"
    then have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6 & f .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
      using A2 sorry
    then have A7: "(arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_7_th_15 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    then have A9: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_23 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 a)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6)^2SQUARE-1K1)"
        using A6 A5 fdiff_7_th_15 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 a)/XCMPLX-0K7 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)"
        using xcmplx_1_th_99 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using xcmplx_1_th_78 sorry
      finally have "(((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
      thus "(((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A11: "x inHIDDENR3 Z"
      then have A12: "((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (f .FUNCT-1K1 x)"
        using A5 funct_1_th_12 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a)"
        using A2 A11 sorry
      finally have "((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a)"
         sorry
      have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)) +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A1 A9 A7 A11 fdiff_1_th_21 sorry
      also have "... = ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A9 A11 fdiff_1_def_7 sorry
      also have "... = ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
        using A4 A8 A11 fdiff_1_th_23 sorry
      also have "... = ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x *XCMPLX-0K3 (((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A11 fdiff_1_def_7 sorry
      also have "... = ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x +XCMPLX-0K2 x *XCMPLX-0K3 (((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 funct_1_th_18 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))"
        using A10 A11 A12 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))"
         sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using xcmplx_1_th_99 sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))))"
      using A1 A9 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_27:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6))) implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      and A3: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 funct_1_th_11 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A2 tarski_def_3 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x"
      using A4 sorry
    then have A7: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 A5 fdiff_4_th_12 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A4 A7 fdiff_1_th_9 sorry
      thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_22 sorry
    qed "sorry"
    then have A9: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f is-differentiable-inFDIFF-1R1 x & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A4 A7 fdiff_1_th_9 sorry
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 A2 A10 funct_1_th_11 sorry
      then have A12: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using valued_1_th_13 sorry
      also have "... = a ^2SQUARE-1K1 -XCMPLX-0K6 f2 .FUNCT-1K1 x"
        using A4 A10 sorry
      also have "... = a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A3 taylor_1_def_1 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M"
         sorry
      have "((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A9 A10 fdiff_1_def_7 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A11 taylor_1_th_22 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (0NUMBERSK6 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M))*XCMPLX-0K3 x)"
        using A2 A3 A5 A6 A10 fdiff_4_th_12 sorry
      also have "... = -XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A2 A12 sorry
      finally have "((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
    qed "sorry"
    thus "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A8 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_28:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((((f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a) & f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & x <>HIDDENR2 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ((f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((((f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a) & f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & x <>HIDDENR2 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((((f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a) & f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & x <>HIDDENR2 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_1 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A3 sorry
    then have A7: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A2 A5 fdiff_7_th_27 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a & f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
      using A3 sorry
    have A9: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3))"
      using A4 xboole_1_th_18 sorry
    then have A10: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) is-differentiable-onFDIFF-1R2 Z"
      using A8 fdiff_7_th_25 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have A13: "f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a"
        using A3 sorry
      have "f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A3 A12 sorry
      then have A14: "\<one>\<^sub>M -XCMPLX-0K6 f3 .FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_10 sorry
      have "f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A3 A12 sorry
      then have "\<one>\<^sub>M +XCMPLX-0K2 f3 .FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using xreal_1_th_6 sorry
      then have A15: "(\<one>\<^sub>M +XCMPLX-0K2 f3 .FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 f3 .FUNCT-1K1 x) >XXREAL-0R4 0NUMBERSK6"
        using A14 xreal_1_th_129 sorry
      have A16: "a >XXREAL-0R4 0NUMBERSK6"
        using A3 A12 sorry
      then have A17: "a ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using square_1_th_12 sorry
      have "\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a ^2SQUARE-1K1 *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using A16 square_1_th_22 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using A17 A13 A15 square_1_th_29 sorry
      also have "... = (a ^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 (x /XCMPLX-0K7 a))^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A17 A13 A15 fdiff_7_th_3 xreal_1_th_129 sorry
      also have "... = (a ^2SQUARE-1K1 -XCMPLX-0K6 ((x *XCMPLX-0K3 a)/XCMPLX-0K7 a)^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using xcmplx_1_th_74 sorry
      also have "... = (a ^2SQUARE-1K1 -XCMPLX-0K6 (x *XCMPLX-0K3 (a /XCMPLX-0K7 a))^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using xcmplx_1_th_74 sorry
      also have "... = (a ^2SQUARE-1K1 -XCMPLX-0K6 (x *XCMPLX-0K3 \<one>\<^sub>M)^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A16 xcmplx_1_th_60 sorry
      also have "... = (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using fdiff_7_th_1 sorry
      finally have "\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)) =HIDDENR1 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A18: "x inHIDDENR3 Z"
      then have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3),x) +XCMPLX-0K2 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A10 A7 fdiff_1_th_18 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3))`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A10 A18 fdiff_1_def_7 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3))`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A18 fdiff_1_def_7 sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))+XCMPLX-0K2 ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A8 A18 fdiff_7_th_25 sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))+XCMPLX-0K2 (-XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A2 A5 A6 A18 fdiff_7_th_27 sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))-XCMPLX-0K6 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))-XCMPLX-0K6 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))"
        using A11 A18 sorry
      also have "... = ((arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a) +XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))-XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using xcmplx_1_th_99 sorry
      also have "... = (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arcsinSIN-COS6K1)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arcsinSIN-COS6K1).FUNCT-1K1 (x /XCMPLX-0K7 a)))"
      using A1 A10 A7 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_29:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((((f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a) & f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & x <>HIDDENR2 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a))"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ((f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((((f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a) & f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & x <>HIDDENR2 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6)) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f3 assume [ty]: "f3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: "f =FUNCT-1R1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((((f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6) & f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a) & f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M) & x <>HIDDENR2 0NUMBERSK6) & a >XXREAL-0R4 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_th_12 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a ^2SQUARE-1K1 & f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A3 sorry
    then have A7: "#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A2 A5 fdiff_7_th_27 sorry
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a & f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M) & f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
      using A3 sorry
    have A9: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3))"
      using A4 xboole_1_th_18 sorry
    then have A10: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) is-differentiable-onFDIFF-1R2 Z"
      using A8 fdiff_7_th_26 sorry
    have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have A13: "f3 .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 a"
        using A3 sorry
      have "f3 .FUNCT-1K1 x <XXREAL-0R3 \<one>\<^sub>M"
        using A3 A12 sorry
      then have A14: "\<one>\<^sub>M -XCMPLX-0K6 f3 .FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_10 sorry
      have "f3 .FUNCT-1K1 x >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
        using A3 A12 sorry
      then have "\<one>\<^sub>M +XCMPLX-0K2 f3 .FUNCT-1K1 x >XXREAL-0R4 \<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
        using xreal_1_th_6 sorry
      then have A15: "(\<one>\<^sub>M +XCMPLX-0K2 f3 .FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 f3 .FUNCT-1K1 x) >XXREAL-0R4 0NUMBERSK6"
        using A14 xreal_1_th_129 sorry
      have A16: "a >XXREAL-0R4 0NUMBERSK6"
        using A3 A12 sorry
      then have A17: "a ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using square_1_th_12 sorry
      have "\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a ^2SQUARE-1K1 *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using A16 square_1_th_22 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using A17 A13 A15 square_1_th_29 sorry
      also have "... = (a ^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 (x /XCMPLX-0K7 a))^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A17 A13 A15 fdiff_7_th_3 xreal_1_th_129 sorry
      also have "... = (a ^2SQUARE-1K1 -XCMPLX-0K6 ((x *XCMPLX-0K3 a)/XCMPLX-0K7 a)^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using xcmplx_1_th_74 sorry
      also have "... = (a ^2SQUARE-1K1 -XCMPLX-0K6 (x *XCMPLX-0K3 (a /XCMPLX-0K7 a))^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using xcmplx_1_th_74 sorry
      also have "... = (a ^2SQUARE-1K1 -XCMPLX-0K6 (x *XCMPLX-0K3 \<one>\<^sub>M)^2SQUARE-1K1)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using A16 xcmplx_1_th_60 sorry
      also have "... = (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
        using fdiff_7_th_1 sorry
      finally have "\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)) =HIDDENR1 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      thus "(a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
         sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A18: "x inHIDDENR3 Z"
      then have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3),x) -XCMPLX-0K6 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A1 A10 A7 fdiff_1_th_19 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3))`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
        using A10 A18 fdiff_1_def_7 sorry
      also have "... = ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3))`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A7 A18 fdiff_1_def_7 sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))-XCMPLX-0K6 ((#RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A8 A18 fdiff_7_th_26 sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))-XCMPLX-0K6 (-XCMPLX-0K4 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
        using A2 A5 A6 A18 fdiff_7_th_27 sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))+XCMPLX-0K2 x *XCMPLX-0K3 (a ^2SQUARE-1K1 -XCMPLX-0K6 x #ZPREPOWERK3 \<two>\<^sub>M)#RPREPOWERK6 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))+XCMPLX-0K2 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))"
        using A11 A18 sorry
      also have "... = ((arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a) -XCMPLX-0K6 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1)))+XCMPLX-0K2 x /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M -XCMPLX-0K6 (x /XCMPLX-0K7 a)^2SQUARE-1K1))"
        using xcmplx_1_th_99 sorry
      also have "... = (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a)"
         sorry
      finally have "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a)"
         sorry
      thus "((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a)"
         sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((arccosSIN-COS6K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f3) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #RTAYLOR-1K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (arccosSIN-COS6K3).FUNCT-1K1 (x /XCMPLX-0K7 a)))"
      using A1 A10 A7 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_30:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) & n >XXREAL-0R4 0NUMBERSK6) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) & (n >XXREAL-0R4 0NUMBERSK6 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)) implies (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
      and A2: "n >XXREAL-0R4 0NUMBERSK6"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A1 valued_1_def_5 sorry
    have A5: "(sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_4_th_40 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_1_th_9 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A6: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A4 funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using tarski_def_3 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "(sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_1_th_9 sorry
      have A10: "((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A7 A8 rfunct_1_def_2 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
        using xcmplx_1_th_215 sorry
      finally have "((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      have "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A1 A6 A8 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)))"
        using A9 taylor_1_th_3 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A5 A8 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
        using A3 A8 fdiff_4_th_40 sorry
      also have "... = -XCMPLX-0K4 (((\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 n)*XCMPLX-0K3 (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
         sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A2 xcmplx_1_th_106 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using A10 fdiff_7_th_1 sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))"
        using prepower_th_42 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))"
         sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M)"
        using xcmplx_1_th_99 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))"
        using xcmplx_1_th_78 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M +XCMPLX-0K2 (n -XCMPLX-0K6 \<one>\<^sub>M))"
        using A3 A8 prepower_th_44 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      finally have "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      thus "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)))"
      using A1 A6 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_31:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) & n >XXREAL-0R4 0NUMBERSK6) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) & (n >XXREAL-0R4 0NUMBERSK6 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)) implies (\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))"
      and A2: "n >XXREAL-0R4 0NUMBERSK6"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A1 valued_1_def_5 sorry
    have A5: "(cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_4_th_39 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_1_th_9 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A6: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A4 funct_1_th_11 sorry
    then have A7: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using tarski_def_3 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "(cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_1_th_9 sorry
      have A10: "((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A7 A8 rfunct_1_def_2 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using xcmplx_1_th_215 sorry
      finally have "((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      have "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x))"
        using A1 A6 A8 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)))"
        using A9 taylor_1_th_3 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x)"
        using A5 A8 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 ((n *XCMPLX-0K3 (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
        using A3 A8 fdiff_4_th_39 sorry
      also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 n)*XCMPLX-0K3 (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
         sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A2 xcmplx_1_th_106 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using A10 fdiff_7_th_1 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using prepower_th_42 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M)"
        using xcmplx_1_th_99 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))"
        using xcmplx_1_th_78 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M +XCMPLX-0K2 (n -XCMPLX-0K6 \<one>\<^sub>M))"
        using A3 A8 prepower_th_44 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      finally have "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 n)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +XCMPLX-0K2 \<one>\<^sub>M)))"
      using A1 A6 fdiff_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_7_lm_3:
"right-open-halflineLIMFUNC1K4 (0NUMBERSK6) =HIDDENR1 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
  using xxreal_1_th_230 sorry

mtheorem fdiff_7_th_32:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A4: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A2 taylor_1_th_18 sorry
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_2_th_13 sorry
    qed "sorry"
    then have A5: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A6: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      assume A7: "x inHIDDENR3 Z"
      then have "x >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      then have A8: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using fdiff_7_lm_3 sorry
      have "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A2 A7 taylor_1_th_18 sorry
      then have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 (diffFDIFF-1K1(sinSIN-COSK17,(lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A6 fdiff_2_th_13 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A8 taylor_1_th_18 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x"
        using xcmplx_1_th_99 sorry
      finally have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x"
         sorry
      thus "(((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x"
        using A5 A7 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_33:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6) implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have A4: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A2 taylor_1_th_18 sorry
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_2_th_13 sorry
    qed "sorry"
    then have A5: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A6: "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using sin_cos_th_63 sorry
      assume A7: "x inHIDDENR3 Z"
      then have "x >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      then have A8: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using fdiff_7_lm_3 sorry
      have "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A2 A7 taylor_1_th_18 sorry
      then have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 (diffFDIFF-1K1(cosSIN-COSK19,(lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A6 fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using sin_cos_th_63 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
        using A8 taylor_1_th_18 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))/XCMPLX-0K7 x"
        using xcmplx_1_th_99 sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x"
        using xcmplx_1_th_187 sorry
      finally have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x"
         sorry
      thus "(((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x"
        using A5 A7 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) /XCMPLX-0K7 x))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_34:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & sinSIN-COSK17 is-differentiable-inFDIFF-1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_64 sin_cos_th_65 sorry
      thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using fdiff_2_th_13 sorry
    qed "sorry"
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
    then have A3: "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & sinSIN-COSK17 is-differentiable-inFDIFF-1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_64 sin_cos_th_65 sorry
      then have A4: "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (diffFDIFF-1K1(sinSIN-COSK17,(exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x))"
        using fdiff_2_th_13 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x))"
        using sin_cos_th_64 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)"
        using sin_cos_th_65 sorry
      finally have "diffFDIFF-1K1((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      assume "x inHIDDENR3 Z"
      thus "(((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A3 A4 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)))"
      using A2 A1 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_35:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & cosSIN-COSK19 is-differentiable-inFDIFF-1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_63 sin_cos_th_65 sorry
      thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using fdiff_2_th_13 sorry
    qed "sorry"
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
    then have A3: "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & cosSIN-COSK19 is-differentiable-inFDIFF-1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_63 sin_cos_th_65 sorry
      then have A4: "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (diffFDIFF-1K1(cosSIN-COSK19,(exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x))"
        using fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x))"
        using sin_cos_th_63 sorry
      also have "... = (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      finally have "diffFDIFF-1K1((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      assume "x inHIDDENR3 Z"
      thus "(((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A3 A4 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cosSIN-COSK19)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x)))"
      using A2 A1 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_36:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x & exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_63 sin_cos_th_65 sorry
      thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using fdiff_2_th_13 sorry
    qed "sorry"
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
    then have A3: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x & exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_63 sin_cos_th_65 sorry
      then have A4: "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 (diffFDIFF-1K1(exp-RSIN-COSK23,(cosSIN-COSK19).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using fdiff_2_th_13 sorry
      also have "... = (diffFDIFF-1K1(exp-RSIN-COSK23,(cosSIN-COSK19).FUNCT-1K1 x))*XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_65 sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      assume "x inHIDDENR3 Z"
      thus "(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
        using A3 A4 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cosSIN-COSK19).FUNCT-1K1 x) *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A2 A1 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_37:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x & exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (sinSIN-COSK17).FUNCT-1K1 x"
        using sin_cos_th_64 sin_cos_th_65 sorry
      thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using fdiff_2_th_13 sorry
    qed "sorry"
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
    then have A3: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x & exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (sinSIN-COSK17).FUNCT-1K1 x"
        using sin_cos_th_64 sin_cos_th_65 sorry
      then have A4: "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 (diffFDIFF-1K1(exp-RSIN-COSK23,(sinSIN-COSK17).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using fdiff_2_th_13 sorry
      also have "... = (diffFDIFF-1K1(exp-RSIN-COSK23,(sinSIN-COSK17).FUNCT-1K1 x))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      assume "x inHIDDENR3 Z"
      thus "(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using A3 A4 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((sinSIN-COSK17).FUNCT-1K1 x) *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
      using A2 A1 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_38:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) implies sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) implies sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z & cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sin_cos_th_68 sorry
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(sinSIN-COSK17,x) +XCMPLX-0K2 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A2 A1 fdiff_1_th_18 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally show "((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A2 A1 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_39:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) implies sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) implies sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z & cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 sin_cos_th_68 sorry
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(sinSIN-COSK17,x) -XCMPLX-0K6 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using A2 A1 fdiff_1_th_19 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(cosSIN-COSK19,x)"
        using sin_cos_th_64 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally show "((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A2 A1 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_40:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))"
    then have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      using valued_1_def_4 sorry
    then have A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using xboole_1_th_18 sorry
    then have A3: "sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_7_th_39 sorry
    have A4: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x))"
        using A1 A3 A4 fdiff_1_th_21 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x))"
        using A2 A5 valued_1_th_13 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x))"
        using taylor_1_th_16 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A3 A5 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A2 A5 fdiff_7_th_39 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      finally have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      thus "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
      using A1 A3 A4 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_41:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))"
    then have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      using valued_1_def_4 sorry
    then have A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using xboole_1_th_18 sorry
    then have A3: "sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_7_th_38 sorry
    have A4: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 taylor_1_th_16 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      obtain xx where 
        [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x"
        using xreal_0_def_1 sorry
      assume A5: "x inHIDDENR3 Z"
      then have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 xx *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x))"
        using A1 A3 A4 fdiff_1_th_21 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 xx +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 xx)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x))"
        using valued_1_th_1 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x))"
        using taylor_1_th_16 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A3 A5 fdiff_1_def_7 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A2 A5 fdiff_7_th_38 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      finally have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      thus "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
      using A1 A3 A4 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_42:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
    then have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using xboole_1_th_18 sorry
    then have A2: "sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_7_th_38 sorry
    have A3: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
      using fdiff_1_th_26 sin_cos_th_54 taylor_1_th_16 sorry
    then have A4: "(sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_2_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      obtain xx where 
        [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x"
        using xreal_0_def_1 sorry
      have A5: "(sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 xx =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 xx +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 xx"
        using valued_1_th_1 sorry
      have A6: "(exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using sin_cos_th_54 sorry
      assume A7: "x inHIDDENR3 Z"
      then have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using A2 fdiff_1_th_9 sin_cos_th_65 sorry
      then have "diffFDIFF-1K1((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 ((diffFDIFF-1K1(sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A6 fdiff_2_th_14 sorry
      also have "... = (((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A2 A7 fdiff_1_def_7 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A1 A7 fdiff_7_th_38 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A5 sin_cos_th_65 sorry
      also have "... = ((-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))"
        using xcmplx_1_th_74 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A6 xcmplx_1_th_60 sorry
      also have "... = (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using xcmplx_1_th_99 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using xcmplx_1_th_187 sorry
      finally have "diffFDIFF-1K1((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      thus "(((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A4 A7 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x))"
      using A2 A3 fdiff_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_43:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
    then have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)"
      using xboole_1_th_18 sorry
    then have A2: "sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_7_th_39 sorry
    have A3: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6)"
      using fdiff_1_th_26 sin_cos_th_54 taylor_1_th_16 sorry
    then have A4: "(sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_2_th_21 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A5: "(exp-RSIN-COSK23).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using sin_cos_th_54 sorry
      assume A6: "x inHIDDENR3 Z"
      then have A7: "(sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x"
        using A1 valued_1_th_13 sorry
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
        using A2 A6 fdiff_1_th_9 sin_cos_th_65 sorry
      then have "diffFDIFF-1K1((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 ((diffFDIFF-1K1(sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19,x))*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A5 fdiff_2_th_14 sorry
      also have "... = (((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)`|FDIFF-1K2 Z).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A2 A6 fdiff_1_def_7 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(exp-RSIN-COSK23,x))*XCMPLX-0K3 (sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A1 A6 fdiff_7_th_39 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x))/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 sin_cos_th_65 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x)"
         sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x))"
        using xcmplx_1_th_74 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x)"
        using A5 xcmplx_1_th_60 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using xcmplx_1_th_99 sorry
      finally have "diffFDIFF-1K1((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
         sorry
      thus "(((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using A4 A6 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((sinSIN-COSK17 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (exp-RSIN-COSK23).FUNCT-1K1 x))"
      using A2 A3 fdiff_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_44:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: "sinSIN-COSK17 is-differentiable-onFDIFF-1R2 Z & exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_68 taylor_1_th_16 sorry
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using A2 A1 fdiff_1_th_21 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(sinSIN-COSK17,x))"
        using taylor_1_th_16 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x"
        using sin_cos_th_64 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      finally show "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)))"
      using A2 A1 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_45:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: "cosSIN-COSK19 is-differentiable-onFDIFF-1R2 Z & exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using fdiff_1_th_26 sin_cos_th_67 taylor_1_th_16 sorry
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using A2 A1 fdiff_1_th_21 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cosSIN-COSK19,x))"
        using taylor_1_th_16 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)"
        using sin_cos_th_63 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      finally show "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)))"
      using A2 A1 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_46:
" for x be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
proof-
  have " for x be RealXREAL-0M1 holds (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A2: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x & cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
      using sin_cos_th_63 sin_cos_th_64 sorry
    then have "diffFDIFF-1K1((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 ((diffFDIFF-1K1(sinSIN-COSK17,x))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(cosSIN-COSK19,x))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
      using A1 fdiff_2_th_14 sorry
    also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(cosSIN-COSK19,x))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
      using sin_cos_th_64 sorry
    also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
      using sin_cos_th_63 sorry
    also have "... = ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
       sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
      using sin_cos_th_28 sorry
    finally have "diffFDIFF-1K1((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
       sorry
    thus "(sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
      using A2 A1 fdiff_2_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_47:
" for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
proof-
  have " for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have A2: "sinSIN-COSK17 is-differentiable-inFDIFF-1R1 x & cosSIN-COSK19 is-differentiable-inFDIFF-1R1 x"
      using sin_cos_th_63 sin_cos_th_64 sorry
    then have "diffFDIFF-1K1((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 ((diffFDIFF-1K1(cosSIN-COSK19,x))*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(sinSIN-COSK17,x))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
      using A1 fdiff_2_th_14 sorry
    also have "... = ((-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (diffFDIFF-1K1(sinSIN-COSK17,x))*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
      using sin_cos_th_63 sorry
    also have "... = ((-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)-XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
      using sin_cos_th_64 sorry
    also have "... = (-XCMPLX-0K4 (((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
       sorry
    also have "... = -XCMPLX-0K4 (((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
      using xcmplx_1_th_187 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
      using sin_cos_th_28 sorry
    finally have "diffFDIFF-1K1((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
       sorry
    thus "(cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
      using A2 A1 fdiff_2_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_48:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
      using tarski_def_3 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have "(sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
      thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A5: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have A7: "((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A3 rfunct_1_def_1 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using xcmplx_1_th_99 sorry
      finally have "((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
         sorry
      have A8: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 A6 sorry
      then have A9: "(sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
      have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)),x)"
        using A5 A6 fdiff_1_def_7 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),x))"
        using A9 taylor_1_th_3 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A8 fdiff_7_th_46 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using xcmplx_1_th_99 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 prepower_th_35 sorry
      also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using xcmplx_1_th_74 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using fdiff_7_th_1 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using prepower_th_35 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M)"
        using A2 A6 prepower_th_44 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M"
         sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M"
         sorry
      thus "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M))"
      using A1 A4 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_49:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using A1 funct_1_th_11 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
      using tarski_def_3 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have "(cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_47 sorry
      thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A5: "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A6: "x inHIDDENR3 Z"
      then have A7: "((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A3 rfunct_1_def_1 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)"
        using xcmplx_1_th_215 sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
        using xcmplx_1_th_99 sorry
      finally have "((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
         sorry
      have A8: "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 A6 sorry
      then have A9: "(cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_47 sorry
      have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)),x)"
        using A5 A6 fdiff_1_def_7 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),x))"
        using A9 taylor_1_th_3 sorry
      also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A8 fdiff_7_th_47 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x)#ZPREPOWERK3 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
         sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using xcmplx_1_th_99 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using A7 prepower_th_35 sorry
      also have "... = -XCMPLX-0K4 ((\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using xcmplx_1_th_74 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using fdiff_7_th_1 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<one>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using prepower_th_35 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M)"
        using A2 A6 prepower_th_44 sorry
      also have "... = -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M"
         sorry
      finally have "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M"
         sorry
      thus "((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 \<two>\<^sub>M *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17)))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (\<two>\<^sub>M *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<three>\<^sub>M))"
      using A1 A4 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_50:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M & (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6) implies ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M & (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6) implies ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M & (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M"
        using A2 sorry
      thus "f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
    qed "sorry"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using tarski_def_3 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have A8: "(sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using fdiff_7_th_46 sorry
      have "f is-differentiable-inFDIFF-1R1 x"
        using A5 A7 fdiff_1_th_9 sorry
      thus "((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_2_th_13 sorry
    qed "sorry"
    then have A9: "((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_1_th_9 sorry
      have A12: "(cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A2 A10 sorry
      then have "(sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19) is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using fdiff_7_th_46 sorry
      then have "diffFDIFF-1K1(((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19),f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A11 fdiff_2_th_13 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A12 fdiff_7_th_46 sorry
      also have "... = (diffFDIFF-1K1(f,x))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x))^2SQUARE-1K1"
        using xcmplx_1_th_99 sorry
      also have "... = (diffFDIFF-1K1(f,x))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
        using A2 A10 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
        using A5 A10 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
        using A3 A4 A10 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
        using fdiff_7_lm_1 sorry
      finally have "diffFDIFF-1K1(((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      thus "((((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 x)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_7_th_51:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6) implies ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6) implies ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M & (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "f .FUNCT-1K1 x =HIDDENR1 x /XCMPLX-0K7 \<two>\<^sub>M"
        using A2 sorry
      thus "f .FUNCT-1K1 x =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
         sorry
    qed "sorry"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 funct_1_th_11 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using tarski_def_3 sorry
    then have A5: "f is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_23 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have A8: "(cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using fdiff_7_th_47 sorry
      have "f is-differentiable-inFDIFF-1R1 x"
        using A5 A7 fdiff_1_th_9 sorry
      thus "((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_2_th_13 sorry
    qed "sorry"
    then have A9: "((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f is-differentiable-inFDIFF-1R1 x"
        using A5 fdiff_1_th_9 sorry
      have A12: "(sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A2 A10 sorry
      then have "(cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17) is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using fdiff_7_th_47 sorry
      then have "diffFDIFF-1K1(((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17),f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A11 fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A12 fdiff_7_th_47 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
         sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x))^2SQUARE-1K1"
        using xcmplx_1_th_99 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
        using A2 A10 sorry
      also have "... = -XCMPLX-0K4 (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
        using A5 A10 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1"
        using A3 A4 A10 fdiff_1_th_23 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (x /XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
        using fdiff_7_lm_2 sorry
      finally have "diffFDIFF-1K1(((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      thus "((((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 x)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
