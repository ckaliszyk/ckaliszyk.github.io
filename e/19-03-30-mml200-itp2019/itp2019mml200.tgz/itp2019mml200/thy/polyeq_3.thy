theory polyeq_3
  imports polyeq_1 comptrig
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d, a9, b9, c9, d9, y, x1, u, v for "RealXREAL-0M1"
reserve s, t, h, z, z1, z2, z3, s1, s2, s3 for "ComplexXCMPLX-0M1"
abbreviation(input) POLYEQ_3K1(" _ ^2POLYEQ-3K1" [354]354) where
  "z ^2POLYEQ-3K1 \<equiv> z ^2SQUARE-1K1"

mtheorem polyeq_3_def_1:
  mlet "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
"redefine func z ^2POLYEQ-3K1 \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  ((ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it =HIDDENR1 z ^2POLYEQ-3K1 iff it =HIDDENR1 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof-
    have " for VarFor1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 z ^2SQUARE-1K1 &  not VarFor1 =HIDDENR1 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not (VarFor1 =HIDDENR1 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z))*XCMPLX-0K3 (<i>COMPLEX1K8) &  not VarFor1 =HIDDENR1 z ^2SQUARE-1K1)"
    proof-
      have "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
        using complex1_th_13 sorry
      thus " for VarFor1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 z ^2SQUARE-1K1 &  not VarFor1 =HIDDENR1 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not (VarFor1 =HIDDENR1 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 -XCMPLX-0K6 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 z))*XCMPLX-0K3 (<i>COMPLEX1K8) &  not VarFor1 =HIDDENR1 z ^2SQUARE-1K1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem polyeq_3_add_1:
  mlet "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
"cluster z ^2SQUARE-1K1 as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "z ^2SQUARE-1K1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

(*\$CD*)
abbreviation(input) POLYEQ_3K2("PolynomPOLYEQ-3K2'( _ , _ , _ , _ ')" [0,0,0,0]164) where
  "PolynomPOLYEQ-3K2(a,b,c,z) \<equiv> PolynomPOLYEQ-1K2(a,b,c,z)"

mtheorem polyeq_3_add_2:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1", "z be ComplexXCMPLX-0M1"
"cluster PolynomPOLYEQ-1K2(a,b,c,z) as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "PolynomPOLYEQ-1K2(a,b,c,z) be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem polyeq_3_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 implies (PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 implies  not (( not z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: "a =COMPLEX1R1 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    let ?y = "ImCOMPLEX1K4 z"
    have A2: "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    let ?x = "ReCOMPLEX1K3 z"
    assume A3: "a <>HIDDENR2 0NUMBERSK6"
      and A4: "deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
    assume "PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6"
    then have "((a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    then have "0NUMBERSK6 =HIDDENR1 (((ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -REAL-1K5 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
      using complex1_th_82 sorry
    also have "... = (((a *XCMPLX-0K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
      using A1 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
      using complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
      using A1 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
      using complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
      using A1 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
      using complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
      using A1 complex1_th_12 sorry
    finally have "0NUMBERSK6 =HIDDENR1 (((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c"
       sorry
    then have A5: "(((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (0NUMBERSK6 +XCMPLX-0K2 a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (b +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_13 sorry
    then have A6: "((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) +XCMPLX-0K2 b *XCMPLX-0K3 ?x)+XCMPLX-0K2 c)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 b *XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have A7: "((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 ?x +XCMPLX-0K2 b)*XCMPLX-0K3 ?y =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_4 complex1_th_12 sorry
    show " not (( not z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
    proof-
      have cases: "?y =COMPLEX1R1 0NUMBERSK6 or (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 ?x +XCMPLX-0K2 b =COMPLEX1R1 0NUMBERSK6"
        using A7 sorry
      have case1: "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies  not (( not z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
      proof(rule impI)
        assume A8: "?y =COMPLEX1R1 0NUMBERSK6"
        then have "PolynomPOLYEQ-3K2(a,b,c,?x) =COMPLEX1R1 0NUMBERSK6"
          using A5 sorry
        then have "ReCOMPLEX1K3 z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 or ReCOMPLEX1K3 z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
          using A3 A4 A8 polyeq_1_th_5 sorry
        then have "z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using complex1_th_13 sorry
        thus " not (( not z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
           sorry
      qed
      have case2: "(\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 ReCOMPLEX1K3 z +XCMPLX-0K2 b =COMPLEX1R1 0NUMBERSK6 implies  not (( not z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
      proof(rule impI)
        assume "(\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 ?x +XCMPLX-0K2 b =COMPLEX1R1 0NUMBERSK6"
        then have A9: "?x =COMPLEX1R1 (-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using A3 xcmplx_1_th_89 sorry
        then have "(a *XCMPLX-0K3 ((b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) +XCMPLX-0K2 b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
          using A6 complex1_th_4 complex1_th_12 sorry
        then have "(b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1 =COMPLEX1R1 (-XCMPLX-0K4 (b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 c))/XCMPLX-0K7 a -XCMPLX-0K6 0NUMBERSK6"
          using A3 xcmplx_1_th_89 sorry
        then have "(b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (-XCMPLX-0K4 (b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 c))/XCMPLX-0K7 a =COMPLEX1R1 ?y ^2SQUARE-1K1 -XCMPLX-0K6 0NUMBERSK6"
           sorry
        then have "?y ^2SQUARE-1K1 =COMPLEX1R1 ((b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)-XCMPLX-0K6 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
           sorry
        then have "?y ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =HIDDENR1 ((b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)-XCMPLX-0K6 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
          using xcmplx_1_th_76 sorry
        also have "... = ((b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 ((b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
           sorry
        finally have "?y ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =HIDDENR1 ((b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 ((b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
           sorry
        then have A10: "?y ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =HIDDENR1 (b ^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 (b ^2SQUARE-1K1 *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 a \<inverse>XCMPLX-0K5))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
          using A3 xcmplx_1_th_87 sorry
        also have "... = (b ^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 (b ^2SQUARE-1K1 *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
          using xcmplx_1_th_204 sorry
        also have "... = (b ^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
           sorry
        finally have "?y ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =HIDDENR1 (b ^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
           sorry
        let ?t = "(b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
        have "?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5 =COMPLEX1R1 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1))"
           sorry
        then have "?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5 =COMPLEX1R1 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<one>\<^sub>M"
          using A3 xcmplx_1_th_106 sorry
        then have "(?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5"
           sorry
        then have "(?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 b ^2SQUARE-1K1 *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)"
           sorry
        then have "(?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 \<two>\<^sub>M))\<inverse>XCMPLX-0K5"
          using xcmplx_1_th_204 sorry
        then have "((?t *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =COMPLEX1R1 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
           sorry
        then have "?t *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
          using A3 xcmplx_1_th_87 sorry
        then have A11: "?t /XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 b ^2SQUARE-1K1"
          using A3 xcmplx_1_th_87 sorry
        let ?t = "(c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
        have "?t =COMPLEX1R1 (((c /XCMPLX-0K7 a)*XCMPLX-0K3 a)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)"
           sorry
        then have A12: "?t =COMPLEX1R1 (c *XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using A3 xcmplx_1_th_87 sorry
        have "-XCMPLX-0K4 deltaQUIN-1K1(a,b,c) <=XXREAL-0R1 0NUMBERSK6"
          using A4 sorry
        then have "(?y *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
          using A10 A11 A12 xreal_1_th_63 sorry
        then have "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
          using A3 sorry
        then have "z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using A9 complex1_th_13 sorry
        thus " not (( not z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6 implies  not ((PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 &  not z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
    have A3: "a =COMPLEX1R1 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    have " for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    proof(rule ballI,rule impI)
      let ?t2 = "((-XCMPLX-0K4 b ^2SQUARE-1K1)+XCMPLX-0K2 (c *XCMPLX-0K3 a)*XCMPLX-0K3 \<four>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M"
      fix z assume [ty]: "z be ComplexXCMPLX-0M1"
      let ?x = "ReCOMPLEX1K3 z"
      let ?y = "ImCOMPLEX1K4 z"
      have A4: "z =COMPLEX1R1 ?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)"
        using complex1_th_13 sorry
      assume "PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6"
      then have "((a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using A4 sorry
      then have "(((ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -REAL-1K5 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_82 sorry
      then have "(((a *XCMPLX-0K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using A3 complex1_th_12 sorry
      then have "(((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_12 sorry
      then have "(((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using A3 complex1_th_12 sorry
      then have "(((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_12 sorry
      then have "(((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using A3 complex1_th_12 sorry
      then have "(((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_12 sorry
      then have "(((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using A3 complex1_th_12 sorry
      then have "(((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y))+XCMPLX-0K2 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 (b +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_13 sorry
      then have A5: "((a *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) +XCMPLX-0K2 b *XCMPLX-0K3 ?x)+XCMPLX-0K2 c)+XCMPLX-0K2 (a *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y) +XCMPLX-0K2 b *XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6"
         sorry
      then have "(a *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 ?x))*XCMPLX-0K3 ?y +XCMPLX-0K2 b *XCMPLX-0K3 ?y =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_4 complex1_th_12 sorry
      then have A6: "((a *XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y =COMPLEX1R1 (-XCMPLX-0K4 b)*XCMPLX-0K3 ?y"
         sorry
      let ?t = "(b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
      let ?t1 = "(?x *XCMPLX-0K3 a +XCMPLX-0K2 b /XCMPLX-0K7 \<two>\<^sub>M)^2SQUARE-1K1"
      have "0NUMBERSK6 -XCMPLX-0K6 deltaQUIN-1K1(a,b,c) >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      then have A7: "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 ?t1 +XCMPLX-0K2 ?t2"
        using xreal_1_th_8 xreal_1_th_63 sorry
      have "((-XCMPLX-0K4 a *XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((b *XCMPLX-0K3 ?x +XCMPLX-0K2 a *XCMPLX-0K3 ?x ^2SQUARE-1K1)+XCMPLX-0K2 c))+XCMPLX-0K2 a *XCMPLX-0K3 ?y ^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 a *XCMPLX-0K3 ?y ^2SQUARE-1K1"
        using A5 complex1_th_4 complex1_th_12 sorry
      then have "((a *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 a +XCMPLX-0K2 (b *XCMPLX-0K3 ?x)*XCMPLX-0K3 a)+XCMPLX-0K2 c *XCMPLX-0K3 a =COMPLEX1R1 (a *XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 a"
        using xcmplx_1_th_9 sorry
      then have "?y <>HIDDENR2 0NUMBERSK6"
        using A7 sorry
      then have "a *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 ?x) =COMPLEX1R1 -XCMPLX-0K4 b"
        using A6 xcmplx_1_th_5 sorry
      then have "\<two>\<^sub>M *XCMPLX-0K3 ?x =COMPLEX1R1 (-XCMPLX-0K4 b)/XCMPLX-0K7 a"
        using A1 xcmplx_1_th_89 sorry
      then have "?x =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 ((-XCMPLX-0K4 b)/XCMPLX-0K7 \<two>\<^sub>M)"
         sorry
      then have A8: "?x =COMPLEX1R1 (-XCMPLX-0K4 b)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
        using xcmplx_1_th_103 sorry
      then have "(a *XCMPLX-0K3 ((b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1) +XCMPLX-0K2 b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using A5 complex1_th_4 complex1_th_12 sorry
      then have "(b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1 =COMPLEX1R1 (-XCMPLX-0K4 (b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 c))/XCMPLX-0K7 a -XCMPLX-0K6 0NUMBERSK6"
        using A1 xcmplx_1_th_89 sorry
      then have "(b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 -XCMPLX-0K6 (-XCMPLX-0K4 (b *XCMPLX-0K3 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 c))/XCMPLX-0K7 a =COMPLEX1R1 ?y ^2SQUARE-1K1 -XCMPLX-0K6 0NUMBERSK6"
         sorry
      then have "?y ^2SQUARE-1K1 =COMPLEX1R1 ((b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)-XCMPLX-0K6 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
         sorry
      then have "?y ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =HIDDENR1 ((b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)-XCMPLX-0K6 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
        using xcmplx_1_th_76 sorry
      also have "... = ((b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 ((b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
         sorry
      finally have "?y ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =HIDDENR1 ((b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 ((b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
         sorry
      then have A9: "?y ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =HIDDENR1 (b ^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 (b ^2SQUARE-1K1 *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 a \<inverse>XCMPLX-0K5))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
        using A1 xcmplx_1_th_87 sorry
      also have "... = (b ^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 (b ^2SQUARE-1K1 *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 a)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
        using xcmplx_1_th_204 sorry
      also have "... = (b ^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
         sorry
      finally have "?y ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =HIDDENR1 (b ^2SQUARE-1K1 +XCMPLX-0K2 (c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)-XCMPLX-0K6 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
         sorry
      have "?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5 =COMPLEX1R1 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1))"
         sorry
      then have "?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5 =COMPLEX1R1 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))\<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<one>\<^sub>M"
        using A1 xcmplx_1_th_106 sorry
      then have "(?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 (b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5"
         sorry
      then have "(?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 b ^2SQUARE-1K1 *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)"
         sorry
      then have "(?t *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 \<inverse>XCMPLX-0K5)*XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 \<two>\<^sub>M))\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_204 sorry
      then have "((?t *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1 =COMPLEX1R1 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
         sorry
      then have "?t *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 (b ^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
        using A1 xcmplx_1_th_87 sorry
      then have A10: "?t /XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 b ^2SQUARE-1K1"
        using A1 xcmplx_1_th_87 sorry
      let ?t = "(c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)^2SQUARE-1K1"
      have "?t =COMPLEX1R1 (((c /XCMPLX-0K7 a)*XCMPLX-0K3 a)*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)"
         sorry
      then have "?t =COMPLEX1R1 (c *XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a)"
        using A1 xcmplx_1_th_87 sorry
      then have "(?y *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 =COMPLEX1R1 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)))^2SQUARE-1K1"
        using A2 A9 A10 square_1_def_2 sorry
      then have "(?y *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)))*XCMPLX-0K3 (?y *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c))) =COMPLEX1R1 0NUMBERSK6"
         sorry
      then have "?y *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) =COMPLEX1R1 0NUMBERSK6 or ?y *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) =COMPLEX1R1 0NUMBERSK6"
         sorry
      then have "?y =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or (?y *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) =COMPLEX1R1 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
        using A1 xcmplx_1_th_89 sorry
      then have "ReCOMPLEX1K3 z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & ImCOMPLEX1K4 z =COMPLEX1R1 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or ReCOMPLEX1K3 z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & ImCOMPLEX1K4 z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
        using A1 A8 xcmplx_1_th_89 sorry
      thus "z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        using complex1_th_13 sorry
    qed "sorry"
    thus " not ((PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 &  not z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_3:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds b <>HIDDENR2 0NUMBERSK6 & ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(0NUMBERSK6,b,c,z) =COMPLEX1R1 0NUMBERSK6) implies z =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 b"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds b <>HIDDENR2 0NUMBERSK6 implies (( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(0NUMBERSK6,b,c,z) =COMPLEX1R1 0NUMBERSK6) implies z =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: "0NUMBERSK6 =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    assume A2: "b <>HIDDENR2 0NUMBERSK6"
    assume A3: " for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(0NUMBERSK6,b,c,z) =COMPLEX1R1 0NUMBERSK6"
    have " for z1 be ComplexXCMPLX-0M1 holds z1 =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 b"
    proof(rule ballI)
      fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
      have "PolynomPOLYEQ-3K2(0NUMBERSK6,b,c,z1) =COMPLEX1R1 0NUMBERSK6"
        using A3 sorry
      then have "b *XCMPLX-0K3 (ReCOMPLEX1K3 z1 +XCMPLX-0K2 ImCOMPLEX1K4 z1 *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_13 sorry
      then have A4: "((b *XCMPLX-0K3 ReCOMPLEX1K3 z1 -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 c)+XCMPLX-0K2 (b *XCMPLX-0K3 ImCOMPLEX1K4 z1 +XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
         sorry
      then have "(b *XCMPLX-0K3 ReCOMPLEX1K3 z1 -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 c =COMPLEX1R1 ReCOMPLEX1K3 (0NUMBERSK6)"
        using complex1_th_12 sorry
      then have "(b *XCMPLX-0K3 ReCOMPLEX1K3 z1 -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 c =COMPLEX1R1 0NUMBERSK6"
        using A1 complex1_th_12 sorry
      then have A5: "ReCOMPLEX1K3 z1 =COMPLEX1R1 (-XCMPLX-0K4 c)/XCMPLX-0K7 b"
        using A2 xcmplx_1_th_89 sorry
      have "b *XCMPLX-0K3 ImCOMPLEX1K4 z1 =COMPLEX1R1 ImCOMPLEX1K4 (0NUMBERSK6)"
        using A4 complex1_th_12 sorry
      then have "ImCOMPLEX1K4 z1 =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 complex1_th_12 sorry
      then have "z1 =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 b)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
        using A5 complex1_th_13 sorry
      thus "z1 =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 b"
         sorry
    qed "sorry"
    thus "z =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(a,b,c,z) =XBOOLE-0R4 QuardPOLYEQ-1K3(a,z1,z2,z)) implies b /XCMPLX-0K7 a =COMPLEX1R1 -XCMPLX-0K4 (z1 +XCMPLX-0K2 z2) & c /XCMPLX-0K7 a =COMPLEX1R1 z1 *XCMPLX-0K3 z2"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies (( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(a,b,c,z) =XBOOLE-0R4 QuardPOLYEQ-1K3(a,z1,z2,z)) implies b /XCMPLX-0K7 a =COMPLEX1R1 -XCMPLX-0K4 (z1 +XCMPLX-0K2 z2) & c /XCMPLX-0K7 a =COMPLEX1R1 z1 *XCMPLX-0K3 z2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    assume A2: " for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K2(a,b,c,z) =XBOOLE-0R4 QuardPOLYEQ-1K3(a,z1,z2,z)"
    then have A3: "PolynomPOLYEQ-3K2(a,b,c,0NUMBERSK6) =XBOOLE-0R4 QuardPOLYEQ-1K3(a,z1,z2,0NUMBERSK6)"
       sorry
    have "QuardPOLYEQ-1K3(a,z1,z2,\<one>\<^sub>M) =HIDDENR1 PolynomPOLYEQ-3K2(a,b,c,\<one>\<^sub>M)"
      using A2 sorry
    also have "... = (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
       sorry
    finally have "QuardPOLYEQ-1K3(a,z1,z2,\<one>\<^sub>M) =HIDDENR1 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
       sorry
    then have "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 (a +XCMPLX-0K2 a *XCMPLX-0K3 (-XCMPLX-0K4 (z1 +XCMPLX-0K2 z2)))+XCMPLX-0K2 c"
      using A3 sorry
    thus "b /XCMPLX-0K7 a =COMPLEX1R1 -XCMPLX-0K4 (z1 +XCMPLX-0K2 z2) & c /XCMPLX-0K7 a =COMPLEX1R1 z1 *XCMPLX-0K3 z2"
      using A1 A3 xcmplx_1_th_203 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef polyeq_3_def_3 (" _ ^3POLYEQ-3K3" [354]354 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z ^3POLYEQ-3K3 \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  z ^2SQUARE-1K1 *XCMPLX-0K3 z"
proof-
  (*coherence*)
    show "z ^2SQUARE-1K1 *XCMPLX-0K3 z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

mlemma polyeq_3_lm_1:
" for z be ComplexXCMPLX-0M1 holds z  |^NEWTONK1 \<two>\<^sub>M =COMPLEX1R1 z *XCMPLX-0K3 z"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have "z  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 z"
    using newton_th_6 sorry
  also have "... = z *XCMPLX-0K3 z"
     sorry
  finally have "z  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z *XCMPLX-0K3 z"
     sorry
  thus "z  |^NEWTONK1 \<two>\<^sub>M =COMPLEX1R1 z *XCMPLX-0K3 z"
     sorry
qed "sorry"

abbreviation(input) POLYEQ_3K4("PolynomPOLYEQ-3K4'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164) where
  "PolynomPOLYEQ-3K4(a,b,c,d,z) \<equiv> PolynomPOLYEQ-1K4(a,b,c,d,z)"

mtheorem polyeq_3_def_4:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "z be ComplexXCMPLX-0M1"
"redefine func PolynomPOLYEQ-3K4(a,b,c,d,z) \<rightarrow> setHIDDENM2 equals
  ((a *XCMPLX-0K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 PolynomPOLYEQ-3K4(a,b,c,d,z) iff it =HIDDENR1 ((a *XCMPLX-0K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
  proof-
    have " for x be setHIDDENM2 holds  not (x =HIDDENR1 PolynomPOLYEQ-1K4(a,b,c,d,z) &  not x =HIDDENR1 ((a *XCMPLX-0K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d) &  not (x =HIDDENR1 ((a *XCMPLX-0K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d &  not x =HIDDENR1 PolynomPOLYEQ-1K4(a,b,c,d,z))"
    proof(rule ballI)
      fix x assume [ty]: "x be setHIDDENM2"
      have "PolynomPOLYEQ-1K4(a,b,c,d,z) =HIDDENR1 ((a *XCMPLX-0K3 z  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
         sorry
      also have "... = ((a *XCMPLX-0K3 (z  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
        using newton_th_6 sorry
      finally have "PolynomPOLYEQ-1K4(a,b,c,d,z) =HIDDENR1 ((a *XCMPLX-0K3 (z  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 z) +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
         sorry
      thus " not (x =HIDDENR1 PolynomPOLYEQ-1K4(a,b,c,d,z) &  not x =HIDDENR1 ((a *XCMPLX-0K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d) &  not (x =HIDDENR1 ((a *XCMPLX-0K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d &  not x =HIDDENR1 PolynomPOLYEQ-1K4(a,b,c,d,z))"
        using polyeq_3_lm_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem polyeq_3_th_5:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z ^3POLYEQ-3K3 =COMPLEX1R1 ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1 & ImCOMPLEX1K4 z ^3POLYEQ-3K3 =COMPLEX1R1 (-XCMPLX-0K4 ImCOMPLEX1K4 z  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z ^3POLYEQ-3K3 =COMPLEX1R1 ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1 & ImCOMPLEX1K4 z ^3POLYEQ-3K3 =COMPLEX1R1 (-XCMPLX-0K4 ImCOMPLEX1K4 z  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?x = "ReCOMPLEX1K3 z"
    let ?y = "ImCOMPLEX1K4 z"
    have "ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 z"
      using complex1_th_13 sorry
    then have "z ^3POLYEQ-3K3 =HIDDENR1 (ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) -REAL-1K5 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_82 sorry
    also have "... = ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ?x -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ?x -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ?y)+XCMPLX-0K2 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ?x -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ?y)+XCMPLX-0K2 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ?y +XCMPLX-0K2 ReCOMPLEX1K3 (?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = (((?x ^2SQUARE-1K1 *XCMPLX-0K3 ?x -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?x)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 ?x)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ?y)+XCMPLX-0K2 (((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 ?y +XCMPLX-0K2 ?x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_12 sorry
    also have "... = (((?x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?x -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?x)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ?y)+XCMPLX-0K2 ((?x ^2SQUARE-1K1 *XCMPLX-0K3 ?y -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?y)+XCMPLX-0K2 ?x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    also have "... = ((?x  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?x -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?x)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ?y)+XCMPLX-0K2 ((?x ^2SQUARE-1K1 *XCMPLX-0K3 ?y -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?y)+XCMPLX-0K2 ?x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using newton_th_6 sorry
    also have "... = ((?x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?x)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ?y)+XCMPLX-0K2 ((?x ^2SQUARE-1K1 *XCMPLX-0K3 ?y -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?y)+XCMPLX-0K2 ?x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using newton_th_6 sorry
    also have "... = ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?x)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ?y)+XCMPLX-0K2 ((?x ^2SQUARE-1K1 *XCMPLX-0K3 ?y -XCMPLX-0K6 (?y  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ?y)*XCMPLX-0K3 ?y)+XCMPLX-0K2 ?x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    also have "... = ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?x)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y))*XCMPLX-0K3 ?y)+XCMPLX-0K2 ((?x ^2SQUARE-1K1 *XCMPLX-0K3 ?y -XCMPLX-0K6 ?y  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 ?x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using newton_th_6 sorry
    also have "... = ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 ?y ^2SQUARE-1K1 *XCMPLX-0K3 ?x)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 (?y *REAL-1K4 ?y)))+XCMPLX-0K2 ((?x ^2SQUARE-1K1 *XCMPLX-0K3 ?y -XCMPLX-0K6 ?y  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ?x *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (?x *REAL-1K4 ?y)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using newton_th_6 sorry
    also have "... = (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "z ^3POLYEQ-3K3 =HIDDENR1 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "ReCOMPLEX1K3 z ^3POLYEQ-3K3 =COMPLEX1R1 ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1 & ImCOMPLEX1K4 z ^3POLYEQ-3K3 =COMPLEX1R1 (-XCMPLX-0K4 ImCOMPLEX1K4 z  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 z"
      using complex1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for a9 be RealXREAL-0M1 holds  for b9 be RealXREAL-0M1 holds  for c9 be RealXREAL-0M1 holds  for d9 be RealXREAL-0M1 holds ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K4(a,b,c,d,z) =COMPLEX1R1 PolynomPOLYEQ-3K4(a9,b9,c9,d9,z)) implies ((a =COMPLEX1R1 a9 & b =COMPLEX1R1 b9) & c =COMPLEX1R1 c9) & d =COMPLEX1R1 d9"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for a9 be RealXREAL-0M1 holds  for b9 be RealXREAL-0M1 holds  for c9 be RealXREAL-0M1 holds  for d9 be RealXREAL-0M1 holds ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K4(a,b,c,d,z) =COMPLEX1R1 PolynomPOLYEQ-3K4(a9,b9,c9,d9,z)) implies ((a =COMPLEX1R1 a9 & b =COMPLEX1R1 b9) & c =COMPLEX1R1 c9) & d =COMPLEX1R1 d9"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    fix a9 assume [ty]: "a9 be RealXREAL-0M1"
    fix b9 assume [ty]: "b9 be RealXREAL-0M1"
    fix c9 assume [ty]: "c9 be RealXREAL-0M1"
    fix d9 assume [ty]: "d9 be RealXREAL-0M1"
    assume A1: " for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-3K4(a,b,c,d,z) =COMPLEX1R1 PolynomPOLYEQ-3K4(a9,b9,c9,d9,z)"
    then have A2: "PolynomPOLYEQ-3K4(a,b,c,d,0NUMBERSK6) =COMPLEX1R1 PolynomPOLYEQ-3K4(a9,b9,c9,d9,0NUMBERSK6)"
       sorry
    show "((a =COMPLEX1R1 a9 & b =COMPLEX1R1 b9) & c =COMPLEX1R1 c9) & d =COMPLEX1R1 d9"
    proof-
      have "a =COMPLEX1R1 a9 & (b =COMPLEX1R1 b9 & (c =COMPLEX1R1 c9 & d =COMPLEX1R1 d9))"
      proof(rule conjMI,rule conjMI,rule conjMI)
        have A3: "PolynomPOLYEQ-3K4(a,b,c,d,\<one>\<^sub>M) =COMPLEX1R1 PolynomPOLYEQ-3K4(a9,b9,c9,d9,\<one>\<^sub>M) & PolynomPOLYEQ-3K4(a,b,c,d,-XCMPLX-0K4 \<one>\<^sub>M) =COMPLEX1R1 PolynomPOLYEQ-3K4(a9,b9,c9,d9,-XCMPLX-0K4 \<one>\<^sub>M)"
          using A1 sorry
        have A4: "PolynomPOLYEQ-3K4(a,b,c,d,\<two>\<^sub>M) =COMPLEX1R1 PolynomPOLYEQ-3K4(a9,b9,c9,d9,\<two>\<^sub>M)"
          using A1 sorry
        thus "a =COMPLEX1R1 a9"
          using A2 A3 sorry
        show "b =COMPLEX1R1 b9"
          using A2 A3 sorry
        show "c =COMPLEX1R1 c9"
          using A2 A3 A4 sorry
        show "d =COMPLEX1R1 d9"
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_7:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-3K4(0NUMBERSK6,b,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 ((-XCMPLX-0K4 c)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b) or z =COMPLEX1R1 ((-XCMPLX-0K4 c)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b)) or z =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b)"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-3K4(0NUMBERSK6,b,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies  not (( not z =COMPLEX1R1 ((-XCMPLX-0K4 c)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 c)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b)) &  not z =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) >=XXREAL-0R2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-3K4(0NUMBERSK6,b,c,d,z) =COMPLEX1R1 0NUMBERSK6"
    have "PolynomPOLYEQ-3K2(b,c,d,z) =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    thus " not (( not z =COMPLEX1R1 ((-XCMPLX-0K4 c)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 c)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(b,c,d)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b)) &  not z =COMPLEX1R1 -XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))"
      using A1 polyeq_3_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_8:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-3K4(0NUMBERSK6,b,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(b,c,d)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(b,c,d)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-3K4(0NUMBERSK6,b,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies  not ( not z =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(b,c,d)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(b,c,d)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (<i>COMPLEX1K8))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "b <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(b,c,d) <XXREAL-0R3 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-3K4(0NUMBERSK6,b,c,d,z) =COMPLEX1R1 0NUMBERSK6"
    have "PolynomPOLYEQ-3K2(b,c,d,z) =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    thus " not ( not z =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(b,c,d)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(b,c,d)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using A1 polyeq_3_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_9:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <=XXREAL-0R1 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 sqrtSQUARE-1K3 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <=XXREAL-0R1 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies  not (( not z =COMPLEX1R1 sqrtSQUARE-1K3 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6 & (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <=XXREAL-0R1 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6"
    have "(a *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 c)*XCMPLX-0K3 z =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    then have "PolynomPOLYEQ-3K2(a,0NUMBERSK6,c,z) =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have "((z =COMPLEX1R1 ((-XCMPLX-0K4 0NUMBERSK6)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,0NUMBERSK6,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or z =COMPLEX1R1 ((-XCMPLX-0K4 0NUMBERSK6)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,0NUMBERSK6,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 0NUMBERSK6) or z =COMPLEX1R1 (0NUMBERSK6)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using A1 polyeq_3_th_1 sorry
    thus " not (( not z =COMPLEX1R1 sqrtSQUARE-1K3 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,b,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies ((z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,b,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies  not ((( not z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-3K4(a,b,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6"
    have "((a *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c)*XCMPLX-0K3 z =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    then have "PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
       sorry
    thus " not ((( not z =COMPLEX1R1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 -XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not z =COMPLEX1R1 0NUMBERSK6)"
      using A1 polyeq_3_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,b,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,b,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies  not (( not z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) <XXREAL-0R3 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-3K4(a,b,c,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6"
    have "((a *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 z)+XCMPLX-0K2 c)*XCMPLX-0K3 z =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    then have "PolynomPOLYEQ-3K2(a,b,c,z) =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
       sorry
    thus " not (( not z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (-XCMPLX-0K4 deltaQUIN-1K1(a,b,c)) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 0NUMBERSK6)"
      using A1 polyeq_3_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_12:
" for a be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y ^2SQUARE-1K1 =COMPLEX1R1 a implies y =COMPLEX1R1 sqrtSQUARE-1K3 a or y =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds y ^2SQUARE-1K1 =COMPLEX1R1 a implies  not ( not y =COMPLEX1R1 sqrtSQUARE-1K3 a &  not y =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 a)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "y ^2SQUARE-1K1 =COMPLEX1R1 a"
    then have A2: "a >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have "PolynomPOLYEQ-3K2(\<one>\<^sub>M,0NUMBERSK6,-XCMPLX-0K4 a,y) =COMPLEX1R1 0NUMBERSK6"
      using A1 sorry
    then have "y =COMPLEX1R1 ((-XCMPLX-0K4 0NUMBERSK6)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,0NUMBERSK6,-XCMPLX-0K4 a)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M) or y =COMPLEX1R1 ((-XCMPLX-0K4 0NUMBERSK6)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,0NUMBERSK6,-XCMPLX-0K4 a)))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)"
      using A2 polyeq_1_th_5 sorry
    then have "y =COMPLEX1R1 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 a) /XCMPLX-0K7 \<two>\<^sub>M or y =COMPLEX1R1 (0NUMBERSK6 -XCMPLX-0K6 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    then have "y =COMPLEX1R1 (sqrtSQUARE-1K3 a *XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M or y =COMPLEX1R1 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 a)/XCMPLX-0K7 \<two>\<^sub>M"
      using A2 square_1_th_20 square_1_th_29 sorry
    thus " not ( not y =COMPLEX1R1 sqrtSQUARE-1K3 a &  not y =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_13:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 c /XCMPLX-0K7 a =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) or z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M))) or z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))"
proof-
  have " for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies (ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 c /XCMPLX-0K7 a =COMPLEX1R1 0NUMBERSK6 implies  not (( not z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) &  not z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M))) &  not z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    let ?y = "ImCOMPLEX1K4 z"
    let ?x = "ReCOMPLEX1K3 z"
    assume A2: "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
      and A3: "PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,d,z) =COMPLEX1R1 0NUMBERSK6"
    have A4: "a =COMPLEX1R1 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    have "0NUMBERSK6 =HIDDENR1 ((a *XCMPLX-0K3 (ReCOMPLEX1K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 ImCOMPLEX1K4 z ^3POLYEQ-3K3 *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using A3 complex1_th_13 sorry
    also have "... = ((a *XCMPLX-0K3 ((ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 ImCOMPLEX1K4 z ^3POLYEQ-3K3 *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using polyeq_3_th_5 sorry
    also have "... = (a *XCMPLX-0K3 ((ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ImCOMPLEX1K4 z  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using polyeq_3_th_5 sorry
    also have "... = ((a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_13 sorry
    also have "... = (((ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -REAL-1K5 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_82 sorry
    also have "... = (((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = (((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = (((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = (((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A4 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A4 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A4 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A4 complex1_th_12 sorry
    also have "... = ((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 0NUMBERSK6) +XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d)+XCMPLX-0K2 (a *XCMPLX-0K3 (-XCMPLX-0K4 0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A2 newton_th_11 sorry
    also have "... = (a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
       sorry
    finally have "0NUMBERSK6 =HIDDENR1 (a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
       sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d) =COMPLEX1R1 a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (0NUMBERSK6)"
       sorry
    then have "(?x  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 (a /XCMPLX-0K7 a) +XCMPLX-0K2 (a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c)*XCMPLX-0K3 ?x)+XCMPLX-0K2 a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 d =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have A5: "PolynomPOLYEQ-3K4(\<one>\<^sub>M,0NUMBERSK6,c /XCMPLX-0K7 a,d /XCMPLX-0K7 a,?x) =COMPLEX1R1 0NUMBERSK6"
      using A1 xcmplx_1_th_88 sorry
    have A6: "(d /XCMPLX-0K7 a)^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 a ^2SQUARE-1K1)"
      using xcmplx_1_th_76 sorry
    also have "... = d ^2SQUARE-1K1 /XCMPLX-0K7 (a ^2SQUARE-1K1 *XCMPLX-0K3 \<four>\<^sub>M)"
      using xcmplx_1_th_103 sorry
    finally have "(d /XCMPLX-0K7 a)^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M =HIDDENR1 d ^2SQUARE-1K1 /XCMPLX-0K7 (a ^2SQUARE-1K1 *XCMPLX-0K3 \<four>\<^sub>M)"
       sorry
    fix u assume [ty]: "u be RealXREAL-0M1"
    fix v assume [ty]: "v be RealXREAL-0M1"
    assume A7: "ReCOMPLEX1K3 z =COMPLEX1R1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 c /XCMPLX-0K7 a =COMPLEX1R1 0NUMBERSK6"
    have A8: "-XCMPLX-0K4 (d /XCMPLX-0K7 a)/XCMPLX-0K7 \<two>\<^sub>M =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (d /XCMPLX-0K7 a)"
       sorry
    also have "... = -XCMPLX-0K4 d /XCMPLX-0K7 (a *XCMPLX-0K3 \<two>\<^sub>M)"
      using xcmplx_1_th_103 sorry
    finally have "-XCMPLX-0K4 (d /XCMPLX-0K7 a)/XCMPLX-0K7 \<two>\<^sub>M =HIDDENR1 -XCMPLX-0K4 d /XCMPLX-0K7 (a *XCMPLX-0K3 \<two>\<^sub>M)"
       sorry
    have A9: "(c /XCMPLX-0K7 a)/XCMPLX-0K7 \<three>\<^sub>M =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (c /XCMPLX-0K7 a)"
       sorry
    also have "... = c /XCMPLX-0K7 (a *XCMPLX-0K3 \<three>\<^sub>M)"
      using xcmplx_1_th_103 sorry
    finally have "(c /XCMPLX-0K7 a)/XCMPLX-0K7 \<three>\<^sub>M =HIDDENR1 c /XCMPLX-0K7 (a *XCMPLX-0K3 \<three>\<^sub>M)"
       sorry
    have "z =HIDDENR1 ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    also have "... = ?x"
      using A2 sorry
    finally have "z =HIDDENR1 ?x"
       sorry
    thus " not (( not z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) &  not z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M))) &  not z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))-XCMPLX-0K6 sqrtSQUARE-1K3 (d ^2SQUARE-1K1 /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) +XCMPLX-0K2 (c /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))"
      using A7 A5 A8 A6 A9 polyeq_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_14:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & ImCOMPLEX1K4 z <>HIDDENR2 0NUMBERSK6) & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) =COMPLEX1R1 0NUMBERSK6 implies ((((z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8))"
proof-
  have " for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies (ImCOMPLEX1K4 z <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,d,z) =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds ReCOMPLEX1K3 z =COMPLEX1R1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) =COMPLEX1R1 0NUMBERSK6 implies  not ((((( not z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    let ?y = "ImCOMPLEX1K4 z"
    let ?x = "ReCOMPLEX1K3 z"
    assume A2: "ImCOMPLEX1K4 z <>HIDDENR2 0NUMBERSK6"
      and A3: "PolynomPOLYEQ-3K4(a,0NUMBERSK6,c,d,z) =COMPLEX1R1 0NUMBERSK6"
    have A4: "a =COMPLEX1R1 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    have A5: "0NUMBERSK6 =HIDDENR1 ((a *XCMPLX-0K3 (ReCOMPLEX1K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 ImCOMPLEX1K4 z ^3POLYEQ-3K3 *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using A3 complex1_th_13 sorry
    also have "... = (a *XCMPLX-0K3 ((ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 ImCOMPLEX1K4 z ^3POLYEQ-3K3 *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using polyeq_3_th_5 sorry
    also have "... = (a *XCMPLX-0K3 ((ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ImCOMPLEX1K4 z  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using polyeq_3_th_5 sorry
    also have "... = ((a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_13 sorry
    also have "... = (((ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -REAL-1K5 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_82 sorry
    also have "... = (((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = (((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = (((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = (((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A4 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A4 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A4 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)*XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A4 complex1_th_12 sorry
    also have "... = ((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) +XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d)+XCMPLX-0K2 ((a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 c *XCMPLX-0K3 ?y)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "0NUMBERSK6 =HIDDENR1 ((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) +XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d)+XCMPLX-0K2 ((a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 c *XCMPLX-0K3 ?y)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    then have "a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 c *XCMPLX-0K3 ?y =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_4 complex1_th_12 sorry
    then have "a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 ?y)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 c *XCMPLX-0K3 ?y =COMPLEX1R1 0NUMBERSK6"
      using newton_th_6 sorry
    then have "((a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1) +XCMPLX-0K2 c)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 ?y =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have "a *XCMPLX-0K3 ?y  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 a *XCMPLX-0K3 ?y  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (a *XCMPLX-0K3 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1) +XCMPLX-0K2 c)) =COMPLEX1R1 a *XCMPLX-0K3 ?y  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 0NUMBERSK6"
      using A2 xcmplx_1_th_6 sorry
    then have "?y  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (a *XCMPLX-0K3 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1) +XCMPLX-0K2 c)/XCMPLX-0K7 a"
      using A1 xcmplx_1_th_89 sorry
    then have "?y  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ?y =COMPLEX1R1 (a *XCMPLX-0K3 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1) +XCMPLX-0K2 c)/XCMPLX-0K7 a"
      using newton_th_6 sorry
    then have A6: "?y ^2SQUARE-1K1 =COMPLEX1R1 (((\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 a)/XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 (0NUMBERSK6)/XCMPLX-0K7 a"
       sorry
    then have A7: "z =COMPLEX1R1 ?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8) & ?y ^2SQUARE-1K1 =COMPLEX1R1 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A1 complex1_th_13 xcmplx_1_th_89 sorry
    let ?q = "-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a)"
    let ?pp = "c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a)"
    fix u assume [ty]: "u be RealXREAL-0M1"
    fix v assume [ty]: "v be RealXREAL-0M1"
    let ?m = "\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?pp /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M))"
    let ?n = "\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?pp /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M))"
    have A8: "(c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))"
       sorry
    also have "... = c /XCMPLX-0K7 ((a *XCMPLX-0K3 \<four>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M)"
      using xcmplx_1_th_103 sorry
    also have "... = c /XCMPLX-0K7 (a *XCMPLX-0K3 (\<four>\<^sub>M *NAT-1K2 \<three>\<^sub>M))"
       sorry
    finally have "(c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M =HIDDENR1 c /XCMPLX-0K7 (a *XCMPLX-0K3 (\<four>\<^sub>M *NAT-1K2 \<three>\<^sub>M))"
       sorry
    have "-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))"
       sorry
    then have A9: "-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 d /XCMPLX-0K7 ((a *XCMPLX-0K3 \<eight>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M)"
      using xcmplx_1_th_103 sorry
    have "(a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 c *XCMPLX-0K3 ?y)+XCMPLX-0K2 0NUMBERSK6 =COMPLEX1R1 0NUMBERSK6"
      using A5 complex1_th_4 complex1_th_12 sorry
    then have "(a *XCMPLX-0K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))+XCMPLX-0K2 0NUMBERSK6) +XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d =COMPLEX1R1 0NUMBERSK6"
      using A1 A5 A6 xcmplx_1_th_89 sorry
    then have "0NUMBERSK6 =HIDDENR1 ((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 (\<nine>\<^sub>M *XCMPLX-0K3 (?x *XCMPLX-0K3 ?x ^2SQUARE-1K1) +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 (c /XCMPLX-0K7 a)))+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
       sorry
    also have "... = ((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 (\<nine>\<^sub>M *XCMPLX-0K3 ((?x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?x) +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 (c /XCMPLX-0K7 a)))+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
       sorry
    also have "... = ((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 (\<nine>\<^sub>M *XCMPLX-0K3 (?x  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?x) +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 (c /XCMPLX-0K7 a)))+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
      using newton_th_6 sorry
    also have "... = ((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 ((\<nine>\<^sub>M *XCMPLX-0K3 ?x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 (c /XCMPLX-0K7 a))+XCMPLX-0K2 0NUMBERSK6))+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
      using newton_th_6 sorry
    also have "... = ((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 (\<nine>\<^sub>M *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M) +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 (c *XCMPLX-0K3 (a /XCMPLX-0K7 a))))+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
       sorry
    also have "... = ((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (a *XCMPLX-0K3 (\<nine>\<^sub>M *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M) +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 c))+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
      using A1 xcmplx_1_th_88 sorry
    also have "... = ((-XCMPLX-0K4 \<eight>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
       sorry
    finally have "0NUMBERSK6 =HIDDENR1 ((-XCMPLX-0K4 \<eight>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 ?x)+XCMPLX-0K2 d"
       sorry
    then have "(-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (0NUMBERSK6) =COMPLEX1R1 ((\<eight>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 ?x)+XCMPLX-0K2 (-XCMPLX-0K4 d)"
       sorry
    then have "0NUMBERSK6 =COMPLEX1R1 (?x  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 ((\<eight>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a)) +XCMPLX-0K2 (\<eight>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 ?x))+XCMPLX-0K2 (\<eight>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (-XCMPLX-0K4 d)"
       sorry
    then have "0NUMBERSK6 =COMPLEX1R1 ((\<one>\<^sub>M *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 ?x ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 c)/XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 ?x)+XCMPLX-0K2 (\<eight>\<^sub>M *XCMPLX-0K3 a)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (-XCMPLX-0K4 d)"
      using A1 xcmplx_1_th_88 sorry
    then have "0NUMBERSK6 =COMPLEX1R1 ((\<one>\<^sub>M *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 ?x ^2SQUARE-1K1)+XCMPLX-0K2 (((\<two>\<^sub>M /XCMPLX-0K7 \<eight>\<^sub>M)*XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ?x)+XCMPLX-0K2 (-XCMPLX-0K4 d)/XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a)"
      using xcmplx_1_th_83 sorry
    then have "0NUMBERSK6 =COMPLEX1R1 ((\<one>\<^sub>M *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 ?x ^2SQUARE-1K1)+XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (c /XCMPLX-0K7 \<four>\<^sub>M))*XCMPLX-0K3 ?x)+XCMPLX-0K2 (-XCMPLX-0K4 d)/XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a)"
       sorry
    then have A10: "PolynomPOLYEQ-3K4(\<one>\<^sub>M,0NUMBERSK6,c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a),-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a),?x) =COMPLEX1R1 0NUMBERSK6"
      using xcmplx_1_th_103 sorry
    assume "ReCOMPLEX1K3 z =COMPLEX1R1 u +XCMPLX-0K2 v & (\<three>\<^sub>M *XCMPLX-0K3 v)*XCMPLX-0K3 u +XCMPLX-0K2 c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a) =COMPLEX1R1 0NUMBERSK6"
    then have A11: "(?x =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?pp /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?pp /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) or ?x =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?pp /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?pp /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M))) or ?x =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?pp /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?pp /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M))"
      using A10 polyeq_1_th_19 sorry
    have A12: "(?x =COMPLEX1R1 ?m +XCMPLX-0K2 ?n & (z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8)) or ?x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ?m & (ReCOMPLEX1K3 z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) implies z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8))) or ?x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ?n & (ReCOMPLEX1K3 z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) implies z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8))"
    proof-
      show "(?x =COMPLEX1R1 ?m +XCMPLX-0K2 ?n & (z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8)) or ?x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ?m & (ReCOMPLEX1K3 z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) implies z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8))) or ?x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ?n & (ReCOMPLEX1K3 z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) implies z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      proof-
        have cases: "(?x =COMPLEX1R1 ?m +XCMPLX-0K2 ?n or ?x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ?m) or ?x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ?n"
          using A11 sorry
        have case1: "ReCOMPLEX1K3 z =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) implies z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        proof(rule impI)
          assume "?x =COMPLEX1R1 ?m +XCMPLX-0K2 ?n"
          thus "z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
            using A7 polyeq_3_th_12 sorry
        qed
        have case2: "ReCOMPLEX1K3 z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) implies z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        proof(rule impI)
          assume "?x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ?m"
          thus "z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
            using A7 polyeq_3_th_12 sorry
        qed
        have case3: "ReCOMPLEX1K3 z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) implies z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        proof(rule impI)
          assume "?x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ?n"
          thus "z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 (-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 ((-XCMPLX-0K4 d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ((c /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 a))/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a))*XCMPLX-0K3 (<i>COMPLEX1K8)"
            using A7 polyeq_3_th_12 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    have "?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M =COMPLEX1R1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (d /XCMPLX-0K7 (\<eight>\<^sub>M *XCMPLX-0K3 a)))^2SQUARE-1K1"
       sorry
    thus " not ((((( not z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a) -XCMPLX-0K6 sqrtSQUARE-1K3 ((d /XCMPLX-0K7 (\<one>\<six>\<^sub>M *XCMPLX-0K3 a))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 (\<one>\<two>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)))^2SQUARE-1K1 +XCMPLX-0K2 c /XCMPLX-0K7 a) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using A9 A12 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_15:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(a,b,c,d,z) =COMPLEX1R1 0NUMBERSK6) & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds  for x1 be RealXREAL-0M1 holds (x1 =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a) & ReCOMPLEX1K3 z =COMPLEX1R1 (u +XCMPLX-0K2 v)-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) & (\<three>\<^sub>M *XCMPLX-0K3 u)*XCMPLX-0K3 v +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) =COMPLEX1R1 0NUMBERSK6 implies (z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies (PolynomPOLYEQ-3K4(a,b,c,d,z) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ( for u be RealXREAL-0M1 holds  for v be RealXREAL-0M1 holds  for x1 be RealXREAL-0M1 holds (x1 =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a) & ReCOMPLEX1K3 z =COMPLEX1R1 (u +XCMPLX-0K2 v)-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) & (\<three>\<^sub>M *XCMPLX-0K3 u)*XCMPLX-0K3 v +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) =COMPLEX1R1 0NUMBERSK6 implies  not (( not z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    let ?p = "((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)"
    let ?b9 = "c /XCMPLX-0K7 a"
    have A2: "a =COMPLEX1R1 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    let ?q = "\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)"
    let ?c9 = "d /XCMPLX-0K7 a"
    let ?a9 = "b /XCMPLX-0K7 a"
    let ?y = "ImCOMPLEX1K4 z"
    let ?x = "ReCOMPLEX1K3 z"
    assume A3: "PolynomPOLYEQ-3K4(a,b,c,d,z) =COMPLEX1R1 0NUMBERSK6"
      and A4: "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
    have A5: "z =COMPLEX1R1 ?x +XCMPLX-0K2 ?y *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    have "0NUMBERSK6 =HIDDENR1 ((a *XCMPLX-0K3 (ReCOMPLEX1K3 z ^3POLYEQ-3K3 +XCMPLX-0K2 ImCOMPLEX1K4 z ^3POLYEQ-3K3 *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using A3 complex1_th_13 sorry
    also have "... = ((a *XCMPLX-0K3 ((ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 ImCOMPLEX1K4 z ^3POLYEQ-3K3 *XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using polyeq_3_th_5 sorry
    also have "... = ((a *XCMPLX-0K3 ((ReCOMPLEX1K3 z  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ReCOMPLEX1K3 z)*XCMPLX-0K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ImCOMPLEX1K4 z  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1)*XCMPLX-0K3 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 z)+XCMPLX-0K2 d"
      using polyeq_3_th_5 sorry
    also have "... = (((a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_13 sorry
    also have "... = ((((ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -REAL-1K5 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_82 sorry
    also have "... = ((((ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +REAL-1K3 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *REAL-1K4 ImCOMPLEX1K4 a)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A2 complex1_th_12 sorry
    also have "... = ((((ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) +XCMPLX-0K2 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) *XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A2 complex1_th_12 sorry
    also have "... = ((((ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 ((?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y) +XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = ((((ReCOMPLEX1K3 a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using complex1_th_12 sorry
    also have "... = ((((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) -XCMPLX-0K6 0NUMBERSK6)+XCMPLX-0K2 (ReCOMPLEX1K3 a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 (ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A2 complex1_th_12 sorry
    also have "... = (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) +XCMPLX-0K2 (a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (c *XCMPLX-0K3 ?x +XCMPLX-0K2 (c *XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
      using A2 A5 complex1_th_12 sorry
    finally have "0NUMBERSK6 =HIDDENR1 (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y ^2SQUARE-1K1) +XCMPLX-0K2 (a *XCMPLX-0K3 ((-XCMPLX-0K4 ?y  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 ?x ^2SQUARE-1K1)*XCMPLX-0K3 ?y))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 b *XCMPLX-0K3 ((?x ^2SQUARE-1K1 -XCMPLX-0K6 ?y ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 (c *XCMPLX-0K3 ?x +XCMPLX-0K2 (c *XCMPLX-0K3 ?y)*XCMPLX-0K3 (<i>COMPLEX1K8)))+XCMPLX-0K2 d"
       sorry
    then have "0NUMBERSK6 =HIDDENR1 (((a *XCMPLX-0K3 (?x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 ?x)*XCMPLX-0K3 (0NUMBERSK6)) +XCMPLX-0K2 b *XCMPLX-0K3 (?x ^2SQUARE-1K1 -XCMPLX-0K6 0NUMBERSK6))+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d)+XCMPLX-0K2 ((a *XCMPLX-0K3 ((-XCMPLX-0K4 (0NUMBERSK6) |^NEWTONK11 \<three>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6) +XCMPLX-0K2 b *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A4 sorry
    also have "... = (((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 ?x ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d)+XCMPLX-0K2 (a *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using newton_th_11 sorry
    finally have "0NUMBERSK6 =HIDDENR1 (((a *XCMPLX-0K3 ?x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 ?x ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 ?x)+XCMPLX-0K2 d)+XCMPLX-0K2 (a *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    then have A6: "PolynomPOLYEQ-3K4(a,b,c,d,?x) =COMPLEX1R1 0NUMBERSK6"
       sorry
    have A7: "?c9 =COMPLEX1R1 d /XCMPLX-0K7 a"
       sorry
    have "?p /XCMPLX-0K7 \<three>\<^sub>M =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))"
       sorry
    then have A8: "?p /XCMPLX-0K7 \<three>\<^sub>M =COMPLEX1R1 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 ((a ^2SQUARE-1K1 *XCMPLX-0K3 \<three>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M)"
      using xcmplx_1_th_103 sorry
    have A9: "-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M =HIDDENR1 -XCMPLX-0K4 ((b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)))"
       sorry
    also have "... = -XCMPLX-0K4 ((b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 ((a ^2SQUARE-1K1 *XCMPLX-0K3 \<three>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M))"
      using xcmplx_1_th_103 sorry
    also have "... = (-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)"
       sorry
    finally have "-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M =HIDDENR1 (-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)"
       sorry
    fix u assume [ty]: "u be RealXREAL-0M1"
    fix v assume [ty]: "v be RealXREAL-0M1"
    fix x1 assume [ty]: "x1 be RealXREAL-0M1"
    assume A10: "x1 =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a) & ReCOMPLEX1K3 z =COMPLEX1R1 (u +XCMPLX-0K2 v)-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)"
      and A11: "(\<three>\<^sub>M *XCMPLX-0K3 u)*XCMPLX-0K3 v +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1) =COMPLEX1R1 0NUMBERSK6"
    have "?a9 =COMPLEX1R1 b /XCMPLX-0K7 a & ?b9 =COMPLEX1R1 c /XCMPLX-0K7 a"
       sorry
    then have "PolynomPOLYEQ-3K4(\<one>\<^sub>M,0NUMBERSK6,?p,?q,x1) =COMPLEX1R1 0NUMBERSK6"
      using A1 A10 A6 A7 polyeq_1_th_16 sorry
    then have "(x1 =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) or x1 =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M))) or x1 =COMPLEX1R1 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 ((-XCMPLX-0K4 ?q /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 sqrtSQUARE-1K3 (?q ^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (?p /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 \<three>\<^sub>M))"
      using A10 A11 polyeq_1_th_19 sorry
    thus " not (( not z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 ((\<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)) +XCMPLX-0K2 \<three>\<^sub>M -rootPOWERK1 (((-XCMPLX-0K4 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<six>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))-XCMPLX-0K6 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 (b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d -XCMPLX-0K6 b *XCMPLX-0K3 c)/XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))^2SQUARE-1K1 /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c -XCMPLX-0K6 b ^2SQUARE-1K1)/XCMPLX-0K7 (\<nine>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)) |^NEWTONK1 \<three>\<^sub>M)))-XCMPLX-0K6 b /XCMPLX-0K7 (\<three>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using A4 A10 A8 A9 complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_16:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K1(z1,z2,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K1(z1,z2,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume "z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K1(z1,z2,z) =COMPLEX1R1 0NUMBERSK6"
    then have "z =COMPLEX1R1 (-XCMPLX-0K4 z2)*XCMPLX-0K3 z1 \<inverse>XCMPLX-0K5"
      using xcmplx_1_th_203 sorry
    thus "z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem polyeq_3_th_17:
" for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds  for s1 be ComplexXCMPLX-0M1 holds  for s2 be ComplexXCMPLX-0M1 holds  for s3 be ComplexXCMPLX-0M1 holds ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 PolynomPOLYEQ-1K2(s1,s2,s3,z)) implies (z1 =COMPLEX1R1 s1 & z2 =COMPLEX1R1 s2) & z3 =COMPLEX1R1 s3"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds  for s1 be ComplexXCMPLX-0M1 holds  for s2 be ComplexXCMPLX-0M1 holds  for s3 be ComplexXCMPLX-0M1 holds ( for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 PolynomPOLYEQ-1K2(s1,s2,s3,z)) implies (z1 =COMPLEX1R1 s1 & z2 =COMPLEX1R1 s2) & z3 =COMPLEX1R1 s3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    fix z3 assume [ty]: "z3 be ComplexXCMPLX-0M1"
    fix s1 assume [ty]: "s1 be ComplexXCMPLX-0M1"
    fix s2 assume [ty]: "s2 be ComplexXCMPLX-0M1"
    fix s3 assume [ty]: "s3 be ComplexXCMPLX-0M1"
    assume A1: " for z be ComplexXCMPLX-0M1 holds PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 PolynomPOLYEQ-1K2(s1,s2,s3,z)"
    then have A2: "PolynomPOLYEQ-1K2(z1,z2,z3,-XCMPLX-0K4 1rCOMPLEX1K7) =COMPLEX1R1 PolynomPOLYEQ-1K2(s1,s2,s3,-XCMPLX-0K4 1rCOMPLEX1K7)"
       sorry
    have "PolynomPOLYEQ-1K2(z1,z2,z3,0cCOMPLEX1K6) =COMPLEX1R1 PolynomPOLYEQ-1K2(s1,s2,s3,0cCOMPLEX1K6) & PolynomPOLYEQ-1K2(z1,z2,z3,1rCOMPLEX1K7) =COMPLEX1R1 PolynomPOLYEQ-1K2(s1,s2,s3,1rCOMPLEX1K7)"
      using A1 sorry
    thus "(z1 =COMPLEX1R1 s1 & z2 =COMPLEX1R1 s2) & z3 =COMPLEX1R1 s3"
      using A2 complex1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_18:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((-XCMPLX-0K4 a)+XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 & (a +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((-XCMPLX-0K4 a)+XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 & (a +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have A1: "b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have A2: "a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A3: "sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 0NUMBERSK6"
      using A1 square_1_def_2 sorry
    have "a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 a ^2SQUARE-1K1"
      using A1 xreal_1_th_7 sorry
    then have A4: "sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 sqrtSQUARE-1K3 a ^2SQUARE-1K1"
      using A2 square_1_th_26 sorry
    show "((-XCMPLX-0K4 a)+XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 & (a +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
    proof-
      have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies ((-XCMPLX-0K4 a)+XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 & (a +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume A5: "a >=XXREAL-0R2 0NUMBERSK6"
        then have "sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 a"
          using A4 square_1_th_22 sorry
        then have "sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) -XCMPLX-0K6 a >=XXREAL-0R2 a -XCMPLX-0K6 a"
          using xreal_1_th_9 sorry
        thus "((-XCMPLX-0K4 a)+XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 & (a +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
          using A3 A5 sorry
      qed
      have case2: "a <XXREAL-0R3 0NUMBERSK6 implies ((-XCMPLX-0K4 a)+XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 & (a +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume A6: "a <XXREAL-0R3 0NUMBERSK6"
        then have "sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 -XCMPLX-0K4 a"
          using A4 square_1_th_23 sorry
        then have "sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) -XCMPLX-0K6 (-XCMPLX-0K4 a) >=XXREAL-0R2 (-XCMPLX-0K4 a)-XCMPLX-0K6 (-XCMPLX-0K4 a)"
          using xreal_1_th_9 sorry
        thus "((-XCMPLX-0K4 a)+XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 & (a +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
          using A3 A6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_19:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s & ImCOMPLEX1K4 s >=XXREAL-0R2 0NUMBERSK6 implies z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s implies (ImCOMPLEX1K4 s >=XXREAL-0R2 0NUMBERSK6 implies  not ( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)))"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix s assume [ty]: "s be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?a = "ReCOMPLEX1K3 s"
    let ?b = "ImCOMPLEX1K4 s"
    let ?u = "ReCOMPLEX1K3 z"
    let ?v = "ImCOMPLEX1K4 z"
    have A1: "z =COMPLEX1R1 ?u +XCMPLX-0K2 ?v *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    assume "z ^2SQUARE-1K1 =COMPLEX1R1 s"
    then have A2: "(?u ^2SQUARE-1K1 -XCMPLX-0K6 ?v ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?u)*XCMPLX-0K3 ?v)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 ?a +XCMPLX-0K2 ?b *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 complex1_th_13 sorry
    assume "ImCOMPLEX1K4 s >=XXREAL-0R2 0NUMBERSK6"
    then have A3: "?u <=XXREAL-0R1 0NUMBERSK6 & ?v <=XXREAL-0R1 0NUMBERSK6 or ?u >=XXREAL-0R2 0NUMBERSK6 & ?v >=XXREAL-0R2 0NUMBERSK6"
      using A2 complex1_th_77 sorry
    have A4: "?u ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & ?v ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have A5: "?u ^2SQUARE-1K1 -XCMPLX-0K6 ?v ^2SQUARE-1K1 =COMPLEX1R1 ?a"
      using A2 complex1_th_77 sorry
    then have "(?u ^2SQUARE-1K1 +XCMPLX-0K2 ?v ^2SQUARE-1K1)^2SQUARE-1K1 =COMPLEX1R1 ?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1"
      using A2 sorry
    then have "?u ^2SQUARE-1K1 +XCMPLX-0K2 ?v ^2SQUARE-1K1 =COMPLEX1R1 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1)"
      using A4 square_1_th_22 sorry
    then have "-REAL-1K1 ?u =COMPLEX1R1 sqrtSQUARE-1K3 ((?a +XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) & -REAL-1K1 ?v =COMPLEX1R1 sqrtSQUARE-1K3 (((-REAL-1K1 ?a)+XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) or ?u =COMPLEX1R1 sqrtSQUARE-1K3 ((?a +XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) & ?v =COMPLEX1R1 sqrtSQUARE-1K3 (((-REAL-1K1 ?a)+XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M)"
      using A5 A3 square_1_th_22 square_1_th_23 sorry
    thus " not ( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_20:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (z ^2SQUARE-1K1 =COMPLEX1R1 s & ImCOMPLEX1K4 s =COMPLEX1R1 0NUMBERSK6) & ReCOMPLEX1K3 s >XXREAL-0R4 0NUMBERSK6 implies z =COMPLEX1R1 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s) or z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s)"
proof-
  have " for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s implies (ImCOMPLEX1K4 s =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 s >XXREAL-0R4 0NUMBERSK6 implies  not ( not z =COMPLEX1R1 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s) &  not z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s)))"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix s assume [ty]: "s be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z ^2SQUARE-1K1 =COMPLEX1R1 s"
    assume A2: "ImCOMPLEX1K4 s =COMPLEX1R1 0NUMBERSK6"
      and A3: "ReCOMPLEX1K3 s >XXREAL-0R4 0NUMBERSK6"
    have "z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 A2 polyeq_3_th_19 sorry
    then have "z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +REAL-1K3 ReCOMPLEX1K3 s)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using A3 square_1_th_22 sorry
    then have "z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +REAL-1K3 ReCOMPLEX1K3 s)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+REAL-1K3 ReCOMPLEX1K3 s)/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +REAL-1K3 ReCOMPLEX1K3 s)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using A3 square_1_th_22 sorry
    then have "z =COMPLEX1R1 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s) +XCMPLX-0K2 sqrtSQUARE-1K3 ((0NUMBERSK6 +XCMPLX-0K2 (ReCOMPLEX1K3 s -REAL-1K5 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((0NUMBERSK6 +XCMPLX-0K2 (ReCOMPLEX1K3 s -REAL-1K5 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using A3 square_1_th_22 sorry
    thus " not ( not z =COMPLEX1R1 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s) &  not z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (ReCOMPLEX1K3 s))"
      using square_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_21:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (z ^2SQUARE-1K1 =COMPLEX1R1 s & ImCOMPLEX1K4 s =COMPLEX1R1 0NUMBERSK6) & ReCOMPLEX1K3 s <XXREAL-0R3 0NUMBERSK6 implies z =COMPLEX1R1 sqrtSQUARE-1K3 (-REAL-1K1 ReCOMPLEX1K3 s) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (-REAL-1K1 ReCOMPLEX1K3 s) *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s implies (ImCOMPLEX1K4 s =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 s <XXREAL-0R3 0NUMBERSK6 implies  not ( not z =COMPLEX1R1 sqrtSQUARE-1K3 (-REAL-1K1 ReCOMPLEX1K3 s) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (-REAL-1K1 ReCOMPLEX1K3 s) *XCMPLX-0K3 (<i>COMPLEX1K8)))"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix s assume [ty]: "s be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z ^2SQUARE-1K1 =COMPLEX1R1 s"
    assume A2: "ImCOMPLEX1K4 s =COMPLEX1R1 0NUMBERSK6"
      and A3: "ReCOMPLEX1K3 s <XXREAL-0R3 0NUMBERSK6"
    have "z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 A2 polyeq_3_th_19 sorry
    then have "z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A3 square_1_th_23 sorry
    then have "z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A3 square_1_th_23 sorry
    then have "z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 s))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A3 square_1_th_23 sorry
    thus " not ( not z =COMPLEX1R1 sqrtSQUARE-1K3 (-REAL-1K1 ReCOMPLEX1K3 s) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 -XCMPLX-0K4 sqrtSQUARE-1K3 (-REAL-1K1 ReCOMPLEX1K3 s) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using square_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_22:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s & ImCOMPLEX1K4 s <XXREAL-0R3 0NUMBERSK6 implies z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s implies (ImCOMPLEX1K4 s <XXREAL-0R3 0NUMBERSK6 implies  not ( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)))"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix s assume [ty]: "s be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z ^2SQUARE-1K1 =COMPLEX1R1 s"
    let ?v = "ImCOMPLEX1K4 z"
    let ?u = "ReCOMPLEX1K3 z"
    let ?b = "ImCOMPLEX1K4 s"
    let ?a = "ReCOMPLEX1K3 s"
    have "z =COMPLEX1R1 ?u +XCMPLX-0K2 ?v *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    then have A2: "s =COMPLEX1R1 ?a +XCMPLX-0K2 ?b *XCMPLX-0K3 (<i>COMPLEX1K8) & z ^2SQUARE-1K1 =COMPLEX1R1 (?u ^2SQUARE-1K1 -XCMPLX-0K6 ?v ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?u)*XCMPLX-0K3 ?v)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    assume "ImCOMPLEX1K4 s <XXREAL-0R3 0NUMBERSK6"
    then have "\<two>\<^sub>M *XCMPLX-0K3 (?u *REAL-1K4 ?v) <XXREAL-0R3 0NUMBERSK6"
      using A1 A2 complex1_th_77 sorry
    then have "?u *REAL-1K4 ?v <XXREAL-0R3 0NUMBERSK6"
       sorry
    then have A3: "?u <XXREAL-0R3 0NUMBERSK6 & ?v >XXREAL-0R4 0NUMBERSK6 or ?u >XXREAL-0R4 0NUMBERSK6 & ?v <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_133 sorry
    have A4: "?u ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & ?v ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have A5: "?u ^2SQUARE-1K1 -XCMPLX-0K6 ?v ^2SQUARE-1K1 =COMPLEX1R1 ?a"
      using A1 A2 complex1_th_77 sorry
    then have "sqrtSQUARE-1K3 (?u ^2SQUARE-1K1 +XCMPLX-0K2 ?v ^2SQUARE-1K1)^2SQUARE-1K1 =COMPLEX1R1 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1)"
      using A1 A2 sorry
    then have "?u ^2SQUARE-1K1 +XCMPLX-0K2 ?v ^2SQUARE-1K1 =COMPLEX1R1 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1)"
      using A4 square_1_th_22 sorry
    then have "-REAL-1K1 ?u =COMPLEX1R1 sqrtSQUARE-1K3 ((?a +XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) & ?v =COMPLEX1R1 sqrtSQUARE-1K3 (((-REAL-1K1 ?a)+XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) or ?u =COMPLEX1R1 sqrtSQUARE-1K3 ((?a +XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) & -REAL-1K1 ?v =COMPLEX1R1 sqrtSQUARE-1K3 (((-REAL-1K1 ?a)+XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M)"
      using A5 A3 square_1_th_22 square_1_th_23 sorry
    thus " not ( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_23:
" for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s implies ((z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for s be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z ^2SQUARE-1K1 =COMPLEX1R1 s implies  not ((( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
  proof(rule ballI,rule ballI,rule impI)
    fix s assume [ty]: "s be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?a = "ReCOMPLEX1K3 s"
    let ?b = "ImCOMPLEX1K4 s"
    let ?u = "ReCOMPLEX1K3 z"
    let ?v = "ImCOMPLEX1K4 z"
    have A1: "?u ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & ?v ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have "z =COMPLEX1R1 ?u +XCMPLX-0K2 ?v *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    then have A2: "s =COMPLEX1R1 ?a +XCMPLX-0K2 ?b *XCMPLX-0K3 (<i>COMPLEX1K8) & z ^2SQUARE-1K1 =COMPLEX1R1 (?u ^2SQUARE-1K1 -XCMPLX-0K6 ?v ^2SQUARE-1K1)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 ?u)*XCMPLX-0K3 ?v)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    assume A3: "z ^2SQUARE-1K1 =COMPLEX1R1 s"
    then have A4: "?u ^2SQUARE-1K1 -XCMPLX-0K6 ?v ^2SQUARE-1K1 =COMPLEX1R1 ?a"
      using A2 complex1_th_77 sorry
    then have "sqrtSQUARE-1K3 (?u ^2SQUARE-1K1 +XCMPLX-0K2 ?v ^2SQUARE-1K1)^2SQUARE-1K1 =COMPLEX1R1 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1)"
      using A3 A2 sorry
    then have A5: "?u ^2SQUARE-1K1 +XCMPLX-0K2 ?v ^2SQUARE-1K1 =COMPLEX1R1 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1)"
      using A1 square_1_th_22 sorry
    show " not ((( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
    proof-
      have cases: "?b >=XXREAL-0R2 0NUMBERSK6 or ?b <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "ImCOMPLEX1K4 s >=XXREAL-0R2 0NUMBERSK6 implies  not ((( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      proof(rule impI)
        assume "?b >=XXREAL-0R2 0NUMBERSK6"
        then have "?u <=XXREAL-0R1 0NUMBERSK6 & ?v <=XXREAL-0R1 0NUMBERSK6 or ?u >=XXREAL-0R2 0NUMBERSK6 & ?v >=XXREAL-0R2 0NUMBERSK6"
          using A3 A2 complex1_th_77 sorry
        then have "-REAL-1K1 ?u =COMPLEX1R1 sqrtSQUARE-1K3 ((?a +XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) & -REAL-1K1 ?v =COMPLEX1R1 sqrtSQUARE-1K3 (((-REAL-1K1 ?a)+XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) or ?u =COMPLEX1R1 sqrtSQUARE-1K3 ((?a +XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) & ?v =COMPLEX1R1 sqrtSQUARE-1K3 (((-REAL-1K1 ?a)+XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M)"
          using A4 A5 square_1_th_22 square_1_th_23 sorry
        thus " not ((( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
          using complex1_th_13 sorry
      qed
      have case2: "ImCOMPLEX1K4 s <XXREAL-0R3 0NUMBERSK6 implies  not ((( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      proof(rule impI)
        assume "?b <XXREAL-0R3 0NUMBERSK6"
        then have "\<two>\<^sub>M *XCMPLX-0K3 (?u *REAL-1K4 ?v) <XXREAL-0R3 0NUMBERSK6"
          using A3 A2 complex1_th_77 sorry
        then have "?u *REAL-1K4 ?v <XXREAL-0R3 0NUMBERSK6"
           sorry
        then have "?u <XXREAL-0R3 0NUMBERSK6 & ?v >XXREAL-0R4 0NUMBERSK6 or ?u >XXREAL-0R4 0NUMBERSK6 & ?v <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_133 sorry
        then have "-REAL-1K1 ?u =COMPLEX1R1 sqrtSQUARE-1K3 ((?a +XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) & ?v =COMPLEX1R1 sqrtSQUARE-1K3 (((-REAL-1K1 ?a)+XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) or ?u =COMPLEX1R1 sqrtSQUARE-1K3 ((?a +XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) & -REAL-1K1 ?v =COMPLEX1R1 sqrtSQUARE-1K3 (((-REAL-1K1 ?a)+XCMPLX-0K2 sqrtSQUARE-1K3 (?a ^2SQUARE-1K1 +XCMPLX-0K2 ?b ^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M)"
          using A4 A5 square_1_th_22 square_1_th_23 sorry
        thus " not ((( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
          using complex1_th_13 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_24:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,z2,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1 or z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,z2,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies  not ( not z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1 &  not z =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume A1: "z1 <>HIDDENR2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-1K2(z1,z2,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6"
    have "0NUMBERSK6 =COMPLEX1R1 (z1 *XCMPLX-0K3 z +XCMPLX-0K2 z2)*XCMPLX-0K3 z"
      using A2 sorry
    then have "PolynomPOLYEQ-1K1(z1,z2,z) =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
       sorry
    thus " not ( not z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1 &  not z =COMPLEX1R1 0NUMBERSK6)"
      using A1 polyeq_3_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_25:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,0NUMBERSK6,z3,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds s =COMPLEX1R1 -XCMPLX-0K4 z3 /XCMPLX-0K7 z1 implies ((z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,0NUMBERSK6,z3,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds s =COMPLEX1R1 -XCMPLX-0K4 z3 /XCMPLX-0K7 z1 implies  not ((( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z3 assume [ty]: "z3 be ComplexXCMPLX-0M1"
    assume "z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,0NUMBERSK6,z3,z) =COMPLEX1R1 0NUMBERSK6"
    then have A1: "z ^2SQUARE-1K1 =COMPLEX1R1 (-XCMPLX-0K4 z3)/XCMPLX-0K7 z1"
      using xcmplx_1_th_89 sorry
    fix s assume [ty]: "s be ComplexXCMPLX-0M1"
    assume "s =COMPLEX1R1 -XCMPLX-0K4 z3 /XCMPLX-0K7 z1"
    thus " not ((( not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using A1 polyeq_3_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_26:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 0NUMBERSK6 implies ( for h be ComplexXCMPLX-0M1 holds  for t be ComplexXCMPLX-0M1 holds h =COMPLEX1R1 (z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1 & t =COMPLEX1R1 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1) implies ((z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t or z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 0NUMBERSK6 implies ( for h be ComplexXCMPLX-0M1 holds  for t be ComplexXCMPLX-0M1 holds h =COMPLEX1R1 (z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1 & t =COMPLEX1R1 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1) implies  not ((( not z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t &  not z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    fix z3 assume [ty]: "z3 be ComplexXCMPLX-0M1"
    assume A1: "z1 <>HIDDENR2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 0NUMBERSK6"
    have "((z1 *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 z2 *XCMPLX-0K3 z)+XCMPLX-0K2 z3)/XCMPLX-0K7 z1 =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    then have "((z ^2SQUARE-1K1 *XCMPLX-0K3 z1)/XCMPLX-0K7 z1 +XCMPLX-0K2 (z2 *XCMPLX-0K3 z)/XCMPLX-0K7 z1)+XCMPLX-0K2 z3 /XCMPLX-0K7 z1 =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have "(z ^2SQUARE-1K1 +XCMPLX-0K2 (z2 /XCMPLX-0K7 z1)*XCMPLX-0K3 z)+XCMPLX-0K2 z3 /XCMPLX-0K7 z1 =COMPLEX1R1 0NUMBERSK6"
      using A1 xcmplx_1_th_89 sorry
    then have "(z ^2SQUARE-1K1 +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 z2)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))*XCMPLX-0K3 z)+XCMPLX-0K2 z3 /XCMPLX-0K7 z1 =COMPLEX1R1 0NUMBERSK6"
      using xcmplx_1_th_91 sorry
    then have A3: "(z +XCMPLX-0K2 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 ((z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1) =COMPLEX1R1 0NUMBERSK6"
       sorry
    fix h assume [ty]: "h be ComplexXCMPLX-0M1"
    fix t assume [ty]: "t be ComplexXCMPLX-0M1"
    assume "h =COMPLEX1R1 (z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1 & t =COMPLEX1R1 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1)"
    then have "(((z +XCMPLX-0K2 t)-XCMPLX-0K6 t =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t or (z +XCMPLX-0K2 t)-XCMPLX-0K6 t =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or (z +XCMPLX-0K2 t)-XCMPLX-0K6 t =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or (z +XCMPLX-0K2 t)-XCMPLX-0K6 t =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t"
      using A3 polyeq_3_th_23 sorry
    thus " not ((( not z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t &  not z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_27:
" for z be ComplexXCMPLX-0M1 holds (z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (z *XCMPLX-0K3 z)*XCMPLX-0K3 z & z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 z ^2SQUARE-1K1 *XCMPLX-0K3 z) & z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 z ^3POLYEQ-3K3"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (z *XCMPLX-0K3 z)*XCMPLX-0K3 z & z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 z ^2SQUARE-1K1 *XCMPLX-0K3 z) & z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 z ^3POLYEQ-3K3"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z  |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 z  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = z  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z"
      using newton_th_6 sorry
    also have "... = (z  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 z"
      using newton_th_6 sorry
    also have "... = (z *XCMPLX-0K3 z)*XCMPLX-0K3 z"
       sorry
    finally have "z  |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (z *XCMPLX-0K3 z)*XCMPLX-0K3 z"
       sorry
    thus "(z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (z *XCMPLX-0K3 z)*XCMPLX-0K3 z & z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 z ^2SQUARE-1K1 *XCMPLX-0K3 z) & z  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 z ^3POLYEQ-3K3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_28:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,z2,0NUMBERSK6,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1 or z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,z2,0NUMBERSK6,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies  not ( not z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1 &  not z =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume A1: "z1 <>HIDDENR2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-3K4(z1,z2,0NUMBERSK6,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6"
    have "0NUMBERSK6 =COMPLEX1R1 (z1 *XCMPLX-0K3 z +XCMPLX-0K2 z2)*XCMPLX-0K3 z ^2SQUARE-1K1"
      using A2 sorry
    then have "PolynomPOLYEQ-1K1(z1,z2,z) =COMPLEX1R1 0NUMBERSK6 or (\<one>\<^sub>M *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 z)+XCMPLX-0K2 0NUMBERSK6 =COMPLEX1R1 0NUMBERSK6"
       sorry
    thus " not ( not z =COMPLEX1R1 -XCMPLX-0K4 z2 /XCMPLX-0K7 z1 &  not z =COMPLEX1R1 0NUMBERSK6)"
      using A1 polyeq_3_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_29:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,0NUMBERSK6,z3,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds s =COMPLEX1R1 -XCMPLX-0K4 z3 /XCMPLX-0K7 z1 implies (((z =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) or z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,0NUMBERSK6,z3,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds s =COMPLEX1R1 -XCMPLX-0K4 z3 /XCMPLX-0K7 z1 implies  not (((( not z =COMPLEX1R1 0NUMBERSK6 &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z3 assume [ty]: "z3 be ComplexXCMPLX-0M1"
    assume A1: "z1 <>HIDDENR2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-3K4(z1,0NUMBERSK6,z3,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6"
    fix s assume [ty]: "s be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 =COMPLEX1R1 (z1 *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 z3)*XCMPLX-0K3 z"
      using A2 sorry
    then have A3: "PolynomPOLYEQ-1K2(z1,0NUMBERSK6,z3,z) =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
       sorry
    assume "s =COMPLEX1R1 -XCMPLX-0K4 z3 /XCMPLX-0K7 z1"
    thus " not (((( not z =COMPLEX1R1 0NUMBERSK6 &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8)) &  not z =COMPLEX1R1 (-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 s)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 s)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 s)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))"
      using A1 A3 polyeq_3_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_30:
" for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,z2,z3,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds  for h be ComplexXCMPLX-0M1 holds  for t be ComplexXCMPLX-0M1 holds h =COMPLEX1R1 (z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1 & t =COMPLEX1R1 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1) implies (((z =COMPLEX1R1 0NUMBERSK6 or z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) or z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds  for z3 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-3K4(z1,z2,z3,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6 implies ( for s be ComplexXCMPLX-0M1 holds  for h be ComplexXCMPLX-0M1 holds  for t be ComplexXCMPLX-0M1 holds h =COMPLEX1R1 (z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1 & t =COMPLEX1R1 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1) implies  not (((( not z =COMPLEX1R1 0NUMBERSK6 &  not z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    fix z3 assume [ty]: "z3 be ComplexXCMPLX-0M1"
    assume A1: "z1 <>HIDDENR2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-3K4(z1,z2,z3,0NUMBERSK6,z) =COMPLEX1R1 0NUMBERSK6"
    fix s assume [ty]: "s be ComplexXCMPLX-0M1"
    fix h assume [ty]: "h be ComplexXCMPLX-0M1"
    fix t assume [ty]: "t be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 =COMPLEX1R1 (PolynomPOLYEQ-1K2(z1,z2,z3,z))*XCMPLX-0K3 z"
      using A2 sorry
    then have A3: "z =COMPLEX1R1 0NUMBERSK6 or PolynomPOLYEQ-1K2(z1,z2,z3,z) =COMPLEX1R1 0NUMBERSK6"
       sorry
    assume "h =COMPLEX1R1 (z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1))^2SQUARE-1K1 -XCMPLX-0K6 z3 /XCMPLX-0K7 z1 & t =COMPLEX1R1 z2 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z1)"
    thus " not (((( not z =COMPLEX1R1 0NUMBERSK6 &  not z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 (sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (-XCMPLX-0K4 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t) &  not z =COMPLEX1R1 ((-XCMPLX-0K4 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h +XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((-REAL-1K1 ReCOMPLEX1K3 h)+XCMPLX-0K2 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 h)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 h)^2SQUARE-1K1))/XCMPLX-0K7 \<two>\<^sub>M) *XCMPLX-0K3 (<i>COMPLEX1K8))-XCMPLX-0K6 t)"
      using A1 A3 polyeq_3_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma polyeq_3_lm_2:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (0NUMBERSK6) |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  assume "n >XXREAL-0R4 0NUMBERSK6"
  then have "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
    using nat_1_th_13 sorry
  thus "(0NUMBERSK6) |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
    using newton_th_11 sorry
qed "sorry"

mtheorem polyeq_3_th_31:
" for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  let ?P = "\<lambda>Lamb1. (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 Lamb1 =COMPLEX1R1 cosSIN-COSK20 (Lamb1 *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (Lamb1 *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  have A1: " for n be NatNAT-1M1 holds (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8) implies (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 cosSIN-COSK20 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "?P(n)"
    then have "(cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using newton_th_6 sorry
    also have "... = ((cosSIN-COSK20 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (cosSIN-COSK20 x) -XCMPLX-0K6 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (sinSIN-COSK18 x))+XCMPLX-0K2 ((cosSIN-COSK20 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (sinSIN-COSK18 x) +XCMPLX-0K2 (cosSIN-COSK20 x)*XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 x)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    also have "... = cosSIN-COSK20 (n *XCMPLX-0K3 x +XCMPLX-0K2 x) +XCMPLX-0K2 ((cosSIN-COSK20 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (sinSIN-COSK18 x) +XCMPLX-0K2 (cosSIN-COSK20 x)*XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 x)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_75 sorry
    also have "... = cosSIN-COSK20 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_75 sorry
    finally have "(cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 cosSIN-COSK20 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "(cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 cosSIN-COSK20 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  have A2: "?P(0NUMBERSK6)"
    using newton_th_4 sin_cos_th_31 sorry
  show " for n be NatNAT-1M1 holds (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using nat_1_sch_2 A2 A1 sorry
qed "sorry"

mtheorem polyeq_3_th_32:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds z  |^NEWTONK1 n =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "z  |^NEWTONK1 n =HIDDENR1 ((( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))+XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (cosSIN-COSK20 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
      using comptrig_th_62 sorry
    also have "... = (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8))) |^NEWTONK1 n"
       sorry
    also have "... = ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
      using newton_th_7 sorry
    finally have "z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
       sorry
    then have "z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using polyeq_3_th_31 sorry
    also have "... = ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally show "z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_33:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for x be RealXREAL-0M1 holds n <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for x be RealXREAL-0M1 holds n <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
    have "(cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 cosSIN-COSK20 (n *XCMPLX-0K3 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using polyeq_3_th_31 sorry
    also have "... = cosSIN-COSK20 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 xcmplx_1_th_87 sorry
    also have "... = cosSIN-COSK20 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK18 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 xcmplx_1_th_87 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK18 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_10 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_11 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_17 sorry
    also have "... = cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_19 sorry
    finally show "(cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_34:
" for z be ComplexXCMPLX-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <>HIDDENR2 0NUMBERSK6 implies z =COMPLEX1R1 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <>HIDDENR2 0NUMBERSK6 implies (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
    then have A2: "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    show "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
    proof-
      have cases: "z <>HIDDENR2 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "z <>HIDDENR2 0NUMBERSK6 implies (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
      proof(rule impI)
        assume "z <>HIDDENR2 0NUMBERSK6"
        then have A3: " |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6"
          using complex1_th_47 sorry
        have "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8))) |^NEWTONK1 n"
           sorry
        also have "... = n -rootPOWERK1 ( |.COMPLEX1K10 z.|)  |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
          using newton_th_7 sorry
        also have "... = n -rootPOWERK1 ( |.COMPLEX1K10 z.|)  |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8))"
          using A1 polyeq_3_th_33 sorry
        also have "... = ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8))"
          using A1 A3 comptrig_th_4 sorry
        also have "... = (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))+XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
        also have "... = z"
          using comptrig_th_62 sorry
        finally show "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
           sorry
      qed
      have case2: "z =COMPLEX1R1 0NUMBERSK6 implies (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
      proof(rule impI)
        assume A4: "z =COMPLEX1R1 0NUMBERSK6"
        then have "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 ((0NUMBERSK6)*XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
          using A2 complex1_th_44 power_th_5 sorry
        also have "... = (((0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
          using A2 power_th_5 sorry
        also have "... = z"
          using A1 A4 polyeq_3_lm_2 sorry
        finally show "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_3_th_35:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,z)"
proof(rule ballI,rule ballI,rule ballI)
  fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
  fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
  have "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 z"
    using polyeq_3_th_34 sorry
  thus "n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,z)"
    using comptrig_def_2 sorry
qed "sorry"

mtheorem polyeq_3_th_36:
" for z be ComplexXCMPLX-0M1 holds  for v be CRootCOMPTRIGM1-of(\<one>\<^sub>M,z) holds v =COMPLEX1R1 z"
proof(rule ballI,rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  fix v assume [ty]: "v be CRootCOMPTRIGM1-of(\<one>\<^sub>M,z)"
  have "v  |^NEWTONK1 \<one>\<^sub>M =COMPLEX1R1 z"
    using comptrig_def_2 sorry
  thus "v =COMPLEX1R1 z"
     sorry
qed "sorry"

mtheorem polyeq_3_th_37:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for v be CRootCOMPTRIGM1-of(n,0NUMBERSK6) holds v =COMPLEX1R1 0NUMBERSK6"
proof(rule ballI,rule ballI)
  fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
  fix v assume [ty]: "v be CRootCOMPTRIGM1-of(n,0NUMBERSK6)"
  let ?P = "\<lambda>Lamb1. v  |^NEWTONK1 Lamb1 =COMPLEX1R1 0NUMBERSK6"
  have A1: " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds k <>HIDDENR2 \<one>\<^sub>M & v  |^NEWTONK1 k =COMPLEX1R1 0NUMBERSK6 implies ( ex t be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st t <XXREAL-0R3 k & v  |^NEWTONK1 t =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    assume A2: "k <>HIDDENR2 \<one>\<^sub>M"
      and A3: "?P(k)"
    obtain t where
      [ty]:"t be NatNAT-1M1" and 
      A4: "k =COMPLEX1R1 t +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have "t <>HIDDENR2 0NUMBERSK6"
      using A2 A4 sorry
    then have 
      [ty]:"t be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
       sorry
    show " ex t be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st t <XXREAL-0R3 k & v  |^NEWTONK1 t =COMPLEX1R1 0NUMBERSK6"
    proof(rule bexI[of _ "t"],rule conjMI)
      show "t <XXREAL-0R3 k"
        using A4 nat_1_th_13 sorry
      have "v  |^NEWTONK1 k =COMPLEX1R1 v  |^NEWTONK1 t *XCMPLX-0K3 v"
        using A4 newton_th_6 sorry
      then have "v  |^NEWTONK1 t =COMPLEX1R1 0NUMBERSK6 or v =COMPLEX1R1 0NUMBERSK6"
        using A3 sorry
      thus "v  |^NEWTONK1 t =COMPLEX1R1 0NUMBERSK6"
        using polyeq_3_lm_2 sorry
    qed "sorry"
  qed "sorry"
  have A5: " ex n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st ?P(n)"
  proof-
    have " ex tVar2 be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st v  |^NEWTONK1 tVar2 =COMPLEX1R1 0NUMBERSK6"
    proof-
      show " ex tVar2 be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st v  |^NEWTONK1 tVar2 =COMPLEX1R1 0NUMBERSK6"
      proof(rule bexI[of _ "n"])
        show "v  |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
          using comptrig_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
  have "?P(\<one>\<^sub>M)"
    using comptrig_sch_1 A5 A1 sorry
  thus "v =COMPLEX1R1 0NUMBERSK6"
     sorry
qed "sorry"

mtheorem polyeq_3_th_38:
" for n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for z be ComplexXCMPLX-0M1 holds  for v be CRootCOMPTRIGM1-of(n,z) holds v =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 0NUMBERSK6"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  fix v assume [ty]: "v be CRootCOMPTRIGM1-of(n,z)"
  assume "v =COMPLEX1R1 0NUMBERSK6"
  then have "(0NUMBERSK6) |^NEWTONK11 n =COMPLEX1R1 z"
    using comptrig_def_2 sorry
  thus "z =COMPLEX1R1 0NUMBERSK6"
    using polyeq_3_lm_2 sorry
qed "sorry"

mtheorem polyeq_3_th_39:
" for n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds cosSIN-COSK20 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,\<one>\<^sub>M)"
proof(rule ballI,rule ballI)
  fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
  fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
  have "(cosSIN-COSK20 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 cosSIN-COSK20 (n *XCMPLX-0K3 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using polyeq_3_th_31 sorry
  also have "... = cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_1_th_87 sorry
  also have "... = cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k +XCMPLX-0K2 0NUMBERSK6) +XCMPLX-0K2 (sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k +XCMPLX-0K2 0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_1_th_87 sorry
  also have "... = (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k +XCMPLX-0K2 0NUMBERSK6) +XCMPLX-0K2 (sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k +XCMPLX-0K2 0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using sin_cos_def_19 sorry
  also have "... = (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k +XCMPLX-0K2 0NUMBERSK6) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k +XCMPLX-0K2 0NUMBERSK6) *XCMPLX-0K3 (<i>COMPLEX1K8)"
    using sin_cos_def_17 sorry
  also have "... = (cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k +XCMPLX-0K2 0NUMBERSK6) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (<i>COMPLEX1K8)"
    using sin_cos2_th_10 sorry
  also have "... = \<one>\<^sub>M"
    using sin_cos_th_30 sin_cos2_th_11 sorry
  finally have "(cosSIN-COSK20 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 \<one>\<^sub>M"
     sorry
  thus "cosSIN-COSK20 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,\<one>\<^sub>M)"
    using comptrig_def_2 sorry
qed "sorry"

mtheorem polyeq_3_th_40:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for s be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((s <>HIDDENR2 0NUMBERSK6 & z <>HIDDENR2 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M) & s  |^NEWTONK1 n =COMPLEX1R1 z  |^NEWTONK1 n implies  |.COMPLEX1K10 s.| =COMPLEX1R1  |.COMPLEX1K10 z.|"
proof-
  have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for s be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s <>HIDDENR2 0NUMBERSK6 & (z <>HIDDENR2 0NUMBERSK6 & (n >=XXREAL-0R2 \<one>\<^sub>M & s  |^NEWTONK1 n =COMPLEX1R1 z  |^NEWTONK1 n)) implies  |.COMPLEX1K10 s.| =COMPLEX1R1  |.COMPLEX1K10 z.|"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix s assume [ty]: "s be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "s <>HIDDENR2 0NUMBERSK6"
      and A2: "z <>HIDDENR2 0NUMBERSK6"
      and A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "s  |^NEWTONK1 n =COMPLEX1R1 z  |^NEWTONK1 n"
    have "z  |^NEWTONK1 n =HIDDENR1 (( |.COMPLEX1K10 s.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 s)) +XCMPLX-0K2 (( |.COMPLEX1K10 s.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 s)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
      using A4 comptrig_th_62 sorry
    also have "... = (( |.COMPLEX1K10 s.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 s) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 s))*XCMPLX-0K3 (<i>COMPLEX1K8))) |^NEWTONK1 n"
       sorry
    also have "... = ( |.COMPLEX1K10 s.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 s) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 s))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
      using newton_th_7 sorry
    also have "... = ( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s)) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s)))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using polyeq_3_th_31 sorry
    also have "... = ( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))) +XCMPLX-0K2 (( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))) +XCMPLX-0K2 (( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    then have A5: "( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))) +XCMPLX-0K2 (( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))))*XCMPLX-0K3 (<i>COMPLEX1K8) =HIDDENR1 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
      using comptrig_th_62 sorry
    also have "... = (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8))) |^NEWTONK1 n"
       sorry
    also have "... = ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
      using newton_th_7 sorry
    also have "... = ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using polyeq_3_th_31 sorry
    also have "... = ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    finally have "( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))) +XCMPLX-0K2 (( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))))*XCMPLX-0K3 (<i>COMPLEX1K8) =HIDDENR1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    then have "( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))) =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)))"
      using complex1_th_77 sorry
    then have "(( |.COMPLEX1K10 s.|)to-powerPOWERK2 n)^2SQUARE-1K1 *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s)))^2SQUARE-1K1 +XCMPLX-0K2 (( |.COMPLEX1K10 s.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s))))^2SQUARE-1K1 =COMPLEX1R1 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))^2SQUARE-1K1 +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))^2SQUARE-1K1"
      using A5 square_1_th_9 sorry
    then have "(( |.COMPLEX1K10 s.|)to-powerPOWERK2 n)^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s)))^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s)))^2SQUARE-1K1) =COMPLEX1R1 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n)^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)))^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)))^2SQUARE-1K1)"
       sorry
    then have "(( |.COMPLEX1K10 s.|)to-powerPOWERK2 n)^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s)))^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 s)))^2SQUARE-1K1) =COMPLEX1R1 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M"
      using sin_cos_th_29 sorry
    then have A6: "(( |.COMPLEX1K10 s.|)to-powerPOWERK2 n)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M =COMPLEX1R1 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n)^2SQUARE-1K1"
      using sin_cos_th_29 sorry
    have A7: " |.COMPLEX1K10 s.| >XXREAL-0R4 0NUMBERSK6"
      using A1 complex1_th_47 sorry
    then have "( |.COMPLEX1K10 s.|)to-powerPOWERK2 n >XXREAL-0R4 0NUMBERSK6"
      using power_th_34 sorry
    then have A8: "( |.COMPLEX1K10 s.|)to-powerPOWERK2 n =COMPLEX1R1 sqrtSQUARE-1K3 (( |.COMPLEX1K10 z.|)to-powerPOWERK2 n)^2SQUARE-1K1"
      using A6 square_1_th_22 sorry
    have A9: " |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6"
      using A2 complex1_th_47 sorry
    then have "( |.COMPLEX1K10 z.|)to-powerPOWERK2 n >XXREAL-0R4 0NUMBERSK6"
      using power_th_34 sorry
    then have "( |.COMPLEX1K10 s.|) |^NEWTONK1 n =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n"
      using A8 square_1_th_22 sorry
    then have " |.COMPLEX1K10 s.| =COMPLEX1R1 n -rootPOWERK1 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n)"
      using A3 A7 power_th_4 sorry
    thus " |.COMPLEX1K10 s.| =COMPLEX1R1  |.COMPLEX1K10 z.|"
      using A3 A9 power_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
