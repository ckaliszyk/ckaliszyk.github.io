theory rfunct_2
  imports partfun2 rcomp_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, X, Y for "setHIDDENM2"
reserve g, r, r1, r2, p, p1, p2 for "RealXREAL-0M1"
reserve R for "SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve seq, seq1, seq2, seq3 for "Real-SequenceSEQ-1M1"
reserve Ns for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
reserve n for "NatNAT-1M1"
reserve W for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem rfunct_2_th_1:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 iff ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n)"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for seq3 be Real-SequenceSEQ-1M1 holds (seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 implies ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n)) & (( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n) implies seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Real-SequenceSEQ-1M1"
    show "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 implies ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n)"
    proof-
      have "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3 implies ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n)"
      proof(rule impI)
        assume A1: "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
        have " for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3).FUNCT-1K1 n"
            using A1 seq_1_th_7 sorry
          then have "seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n +XCMPLX-0K2 (-XCMPLX-0K4 seq3 .FUNCT-1K1 n)"
            using seq_1_th_10 sorry
          thus "seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n"
             sorry
        qed "sorry"
        thus " for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: " for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n"
    have " for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =HIDDENR1 seq2 .FUNCT-1K1 n +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq1 .FUNCT-1K1 n =HIDDENR1 seq2 .FUNCT-1K1 n -XCMPLX-0K6 seq3 .FUNCT-1K1 n"
        using A2 sorry
      also have "... = seq2 .FUNCT-1K1 n +XCMPLX-0K2 (-XCMPLX-0K4 seq3 .FUNCT-1K1 n)"
         sorry
      also have "... = seq2 .FUNCT-1K1 n +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3).FUNCT-1K1 n"
        using seq_1_th_10 sorry
      finally show "seq1 .FUNCT-1K1 n =HIDDENR1 seq2 .FUNCT-1K1 n +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq3).FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq3"
      using seq_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_2:
" for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds ((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns & (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns) & (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
proof-
  have " for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns & ((seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns & (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n) +REAL-1K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using seq_1_th_7 sorry
      also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "((seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n) -REAL-1K5 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using rfunct_2_th_1 sorry
      also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using rfunct_2_th_1 sorry
      finally show "((seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n) *REAL-1K4 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using seq_1_th_8 sorry
      also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = ((seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "((seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_3:
" for p be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
proof-
  have " for p be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = p *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using seq_1_th_9 sorry
      also have "... = p *XCMPLX-0K3 (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      finally show "((p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> p (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_4:
" for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns & absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =HIDDENR1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns & absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
       sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
      using rfunct_2_th_3 sorry
    also have "... = -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
       sorry
    finally show "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =HIDDENR1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... =  |.COMPLEX1K10 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n).|"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|"
        using funct_2_th_15 sorry
      also have "... = absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_12 sorry
      finally show "(absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_5:
" for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using valued_1_th_10 sorry
      also have "... = (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n))\<inverse>REAL-1K2"
        using funct_2_th_15 sorry
      also have "... = seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using valued_1_th_10 sorry
      also have "... = (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      finally show "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_6:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =HIDDENR1 (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have "(seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =HIDDENR1 (seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns"
       sorry
    also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
      using rfunct_2_th_2 sorry
    also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using rfunct_2_th_5 sorry
    also have "... = (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
       sorry
    finally show "(seq1 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =HIDDENR1 (seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_7:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6) implies limSEQ-2K1 seq <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6) implies limSEQ-2K1 seq <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6"
    let ?seq1 = "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
    have A3: " for n be NatNAT-1M1 holds -XCMPLX-0K4 0NUMBERSK6 <=XXREAL-0R1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "?seq1 .FUNCT-1K1 n =COMPLEX1R1 -XCMPLX-0K4 seq .FUNCT-1K1 n & seq .FUNCT-1K1 n <=XXREAL-0R1 0NUMBERSK6"
        using A2 seq_1_th_10 sorry
      thus "-XCMPLX-0K4 0NUMBERSK6 <=XXREAL-0R1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 n"
        using xreal_1_th_24 sorry
    qed "sorry"
    have "?seq1 be convergentSEQ-2V5"
      using A1 seq_2_th_9 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 limSEQ-2K1 ?seq1"
      using A3 seq_2_th_17 sorry
    then have "-XCMPLX-0K4 0NUMBERSK6 <=XXREAL-0R1 -XCMPLX-0K4 limSEQ-2K1 seq"
      using A1 seq_2_th_10 sorry
    thus "limSEQ-2K1 seq <=XXREAL-0R1 0NUMBERSK6"
      using xreal_1_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_8:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(W)\<^esub> domRELSET-1K1\<^bsub>(W)\<^esub> h2 implies ((h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & (h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) & (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
proof-
  have " for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(W)\<^esub> domRELSET-1K1\<^bsub>(W)\<^esub> h2 implies (h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & ((h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    have A1: "domRELSET-1K1\<^bsub>(W)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(W)\<^esub> domRELSET-1K1\<^bsub>(W)\<^esub> h2 c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h1"
      using xboole_1_th_17 sorry
    have A2: "domRELSET-1K1\<^bsub>(W)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(W)\<^esub> domRELSET-1K1\<^bsub>(W)\<^esub> h2 c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h2"
      using xboole_1_th_17 sorry
    assume A3: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(W)\<^esub> domRELSET-1K1\<^bsub>(W)\<^esub> h2"
    then have A4: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
      using valued_1_def_1 sorry
    have " for n be NatNAT-1M1 holds (h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n +XCMPLX-0K2 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A5: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have A6: "seq .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(W)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 (h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A4 funct_2_th_108 A5 sorry
      also have "... = h1 .FUNCT-1K1 (seq .FUNCT-1K1 n) +XCMPLX-0K2 h2 .FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A4 A6 valued_1_def_1 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n +XCMPLX-0K2 h2 .FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A3 A1 funct_2_th_108 xboole_1_th_1 A5 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n +XCMPLX-0K2 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
        using A3 A2 funct_2_th_108 xboole_1_th_1 A5 sorry
      finally show "(h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n +XCMPLX-0K2 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "(h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using seq_1_th_7 sorry
    have A7: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
      using A3 valued_1_th_12 sorry
    have " for n be NatNAT-1M1 holds (h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n -XCMPLX-0K6 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A8: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have A9: "seq .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(W)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 (h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A7 funct_2_th_108 A8 sorry
      also have "... = h1 .FUNCT-1K1 (seq .FUNCT-1K1 n) -XCMPLX-0K6 h2 .FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A7 A9 valued_1_th_13 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n -XCMPLX-0K6 h2 .FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A3 A1 funct_2_th_108 xboole_1_th_1 A8 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n -XCMPLX-0K6 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
        using A3 A2 funct_2_th_108 xboole_1_th_1 A8 sorry
      finally show "(h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n -XCMPLX-0K6 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "(h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using rfunct_2_th_1 sorry
    have A10: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
      using A3 valued_1_def_4 sorry
    have " for n be NatNAT-1M1 holds (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n *XCMPLX-0K3 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A11: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "(h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A10 funct_2_th_108 A11 sorry
      also have "... = h1 .FUNCT-1K1 (seq .FUNCT-1K1 n) *XCMPLX-0K3 h2 .FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using valued_1_th_5 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n *XCMPLX-0K3 h2 .FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A3 A1 funct_2_th_108 xboole_1_th_1 A11 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n *XCMPLX-0K3 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
        using A3 A2 funct_2_th_108 xboole_1_th_1 A11 sorry
      finally show "(h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n *XCMPLX-0K3 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "(h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using seq_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_9:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds  for r be RealXREAL-0M1 holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h implies (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
proof-
  have " for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds  for r be RealXREAL-0M1 holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h implies (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h"
    then have A2: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)"
      using valued_1_def_5 sorry
    have " for n be NatNAT-1M1 holds (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 r *XCMPLX-0K3 h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A3: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have A4: "seq .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(W)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A2 funct_2_th_108 A3 sorry
      also have "... = r *XCMPLX-0K3 h .FUNCT-1K1 (seq .FUNCT-1K1 n)"
        using A2 A4 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
        using A1 funct_2_th_108 A3 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =HIDDENR1 r *XCMPLX-0K3 h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using seq_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_10:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
proof-
  have " for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =HIDDENR1 (-VALUED-1K34\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    assume A1: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h"
    then have A2: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h"
      using valued_1_def_11 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 h .FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n).|"
        using A1 funct_2_th_108 sorry
      also have "... = absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n)"
        using valued_1_th_18 sorry
      also have "... = absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A2 funct_2_th_108 sorry
      finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using funct_2_th_63 sorry
    have "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
       sorry
    also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using A1 rfunct_2_th_9 sorry
    also have "... = (-VALUED-1K34\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
       sorry
    finally show "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =HIDDENR1 (-VALUED-1K34\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_11:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) implies h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq be non-zeroORDINAL1V9"
proof-
  have " for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) implies h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq be non-zeroORDINAL1V9"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    assume A1: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)"
    then have A2: "domRELSET-1K1\<^bsub>(W)\<^esub> h \\SUBSET-1K7\<^bsub>(W)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h & rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h \\SUBSET-1K7\<^bsub>(W)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
      using rfunct_1_def_2 xboole_1_th_36 sorry
    have "( ex n be NatNAT-1M1 st h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
    proof(rule impI)
      assume Given: " ex n be NatNAT-1M1 st h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A3: "h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
         sorry
      have A4: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "seq .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(W)\<^esub> seq"
        using valued_0_th_28 sorry
      then have "seq .FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)"
        using A1 sorry
      then have "seq .FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> h \\SUBSET-1K7\<^bsub>(W)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have "seq .FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> h &  not seq .FUNCT-1K1 n inTARSKIR2 h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
        using xboole_0_def_5 sorry
      then have A5: " not h .FUNCT-1K1 (seq .FUNCT-1K1 n) inTARSKIR2 {SEQ-4K1 0NUMBERSK6 }"
        using funct_1_def_7 sorry
      have "h .FUNCT-1K1 (seq .FUNCT-1K1 n) =COMPLEX1R1 0NUMBERSK6"
        using A2 A3 funct_2_th_108 xboole_1_th_1 A4 sorry
      thus " False "
        using A5 tarski_def_1 sorry
    qed
    thus "h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq be non-zeroORDINAL1V9"
      using seq_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_12:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) implies (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
proof-
  have " for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) implies (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    assume A1: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)"
    then have A2: "domRELSET-1K1\<^bsub>(W)\<^esub> h \\SUBSET-1K7\<^bsub>(W)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h & rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h \\SUBSET-1K7\<^bsub>(W)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
      using rfunct_1_def_2 xboole_1_th_36 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A3: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(W)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>).FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n)"
        using A1 funct_2_th_108 sorry
      also have "... = (h .FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n))\<inverse>XCMPLX-0K5"
        using A1 A3 rfunct_1_def_2 sorry
      also have "... = (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using A2 funct_2_th_108 xboole_1_th_1 sorry
      also have "... = (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "(h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_13:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds h1 be totalPARTFUN1V1\<^bsub>(W)\<^esub> & h2 be totalPARTFUN1V1\<^bsub>(W)\<^esub> implies ((h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & (h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) & (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
proof-
  have " for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds h1 be totalPARTFUN1V1\<^bsub>(W)\<^esub> & h2 be totalPARTFUN1V1\<^bsub>(W)\<^esub> implies (h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & ((h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq & (h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    assume "h1 be totalPARTFUN1V1\<^bsub>(W)\<^esub> & h2 be totalPARTFUN1V1\<^bsub>(W)\<^esub>"
    then have "domRELSET-1K1\<^bsub>(W)\<^esub> (h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) =XBOOLE-0R4 W"
      using partfun1_def_2 sorry
    then have "domRELSET-1K1\<^bsub>(W)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(W)\<^esub> domRELSET-1K1\<^bsub>(W)\<^esub> h2 =XBOOLE-0R4 W"
      using valued_1_def_1 sorry
    then have A1: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(W)\<^esub> domRELSET-1K1\<^bsub>(W)\<^esub> h2"
       sorry
    thus "(h1 +VALUED-1K3\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using rfunct_2_th_8 sorry
    show "(h1 -VALUED-1K49\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using A1 rfunct_2_th_8 sorry
    show "(h1 (#)VALUED-1K21\<^bsub>(W,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using A1 rfunct_2_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_14:
" for r be RealXREAL-0M1 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds h be totalPARTFUN1V1\<^bsub>(W)\<^esub> implies (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
proof-
  have " for r be RealXREAL-0M1 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds h be totalPARTFUN1V1\<^bsub>(W)\<^esub> implies (r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    assume "h be totalPARTFUN1V1\<^bsub>(W)\<^esub>"
    then have "domRELSET-1K1\<^bsub>(W)\<^esub> h =XBOOLE-0R4 W"
      using partfun1_def_2 sorry
    then have "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> h"
       sorry
    thus "(r (#)VALUED-1K28\<^bsub>(W,REALNUMBERSK2)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using rfunct_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_15:
" for X be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X) implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
proof-
  have " for X be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X) implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    assume A1: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
    have A2: "domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(W)\<^esub> h /\\SUBSET-1K8\<^bsub>(W)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(W)\<^esub> absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h /\\SUBSET-1K8\<^bsub>(W)\<^esub> X"
      using valued_1_def_11 sorry
    also have "... = domRELSET-1K1\<^bsub>(W)\<^esub> (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
      using relat_1_th_61 sorry
    finally have "domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(W)\<^esub> (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A3: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(W)\<^esub> seq"
        using valued_0_th_28 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
        using A1 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> h /\\SUBSET-1K8\<^bsub>(W)\<^esub> X"
        using relat_1_th_61 sorry
      then have A4: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n).|"
        using A1 funct_2_th_108 sorry
      also have "... =  |.COMPLEX1K10 h .FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n).|"
        using A1 A3 funct_1_th_47 sorry
      also have "... = absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h .FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n)"
        using valued_1_th_18 sorry
      also have "... = (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n)"
        using A4 funct_1_th_49 sorry
      also have "... = (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A1 A2 funct_2_th_108 sorry
      finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(W,REALNUMBERSK2)\<^esub> h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_16:
" for X be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X) & h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies ((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  for seq be sequenceNAT-1M2-of W holds rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X) & h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies ((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    fix seq assume [ty]: "seq be sequenceNAT-1M2-of W"
    assume A1: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
      and A2: "h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(W)\<^esub> seq implies x inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> ((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(W)\<^esub> seq"
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
        using A1 sorry
      then have A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> h /\\SUBSET-1K8\<^bsub>(W)\<^esub> X"
        using relat_1_th_61 sorry
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> h \\SUBSET-1K7\<^bsub>(W)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
        using A2 xboole_0_def_4 sorry
      then have A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)"
        using rfunct_1_def_2 sorry
      have "x inHIDDENR3 X"
        using A3 xboole_0_def_4 sorry
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) /\\SUBSET-1K8\<^bsub>(W)\<^esub> X"
        using A4 xboole_0_def_4 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> ((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
        using relat_1_th_61 sorry
    qed "sorry"
    then have A5: "rngRELSET-1K2\<^bsub>(W)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(W)\<^esub> ((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
      using tarski_def_3 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A6: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(W)\<^esub> seq"
        using valued_0_th_28 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)"
        using A1 sorry
      then have A7: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> h /\\SUBSET-1K8\<^bsub>(W)\<^esub> X"
        using relat_1_th_61 sorry
      then have A8: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> h \\SUBSET-1K7\<^bsub>(W)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(W,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
        using A2 A7 xboole_0_def_4 sorry
      then have A9: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(W)\<^esub> (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>)"
        using rfunct_1_def_2 sorry
      have "((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n)"
        using A5 funct_2_th_108 sorry
      also have "... = (h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>).FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n)"
        using A8 funct_1_th_49 sorry
      also have "... = (h .FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n))\<inverse>XCMPLX-0K5"
        using A9 rfunct_1_def_2 sorry
      also have "... = ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,W)\<^esub> n))\<inverse>XCMPLX-0K5"
        using A1 A6 funct_1_th_47 sorry
      also have "... = ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using A1 funct_2_th_108 sorry
      also have "... = ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "((h ^RFUNCT-1K6\<^bsub>(W,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,W)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_cl_1:
  mlet "Z be setHIDDENM2", "f be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1"
"cluster f  |RELAT-1K8 Z as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f  |RELAT-1K8 Z be one-to-oneFUNCT-1V2"
    using funct_1_th_52 sorry
qed "sorry"

mtheorem rfunct_2_th_17:
" for X be setHIDDENM2 holds  for h be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1 holds (h  |RELAT-1K8 X)\<inverse>FUNCT-1K4 =FUNCT-1R1 h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X)"
proof-
  have " for X be setHIDDENM2 holds  for h be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1 holds (h  |RELAT-1K8 X)\<inverse>FUNCT-1K4 =FUNCT-1R1 h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix h assume [ty]: "h be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1"
    obtain hX where 
      [ty]:"hX be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1" and hXDef:"hX = h  |RELAT-1K8 X"
       sorry
    have " for r be objectHIDDENM1 holds (r inHIDDENR3 domRELAT-1K1 ((h  |RELAT-1K8 X)\<inverse>FUNCT-1K4) implies r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X))) & (r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X)) implies r inHIDDENR3 domRELAT-1K1 ((h  |RELAT-1K8 X)\<inverse>FUNCT-1K4))"
    proof(rule ballI,rule conjMI,rule impI)
      fix r assume [ty]: "r be objectHIDDENM1"
      show "r inHIDDENR3 domRELAT-1K1 ((h  |RELAT-1K8 X)\<inverse>FUNCT-1K4) implies r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X))"
      proof(rule impI)
        assume "r inHIDDENR3 domRELAT-1K1 ((h  |RELAT-1K8 X)\<inverse>FUNCT-1K4)"
        then have "r inHIDDENR3 rngFUNCT-1K2 hX"
          using funct_1_th_33 sorry
        then obtain g where
          [ty]:"g be objectHIDDENM1" and 
          A1: "g inHIDDENR3 domRELAT-1K1 (h  |RELAT-1K8 X)"and A2: "(h  |RELAT-1K8 X).FUNCT-1K1 g =HIDDENR1 r"
          using funct_1_def_3 sorry
        have A3: "h .FUNCT-1K1 g =HIDDENR1 r"
          using A1 A2 funct_1_th_47 sorry
        have A4: "g inHIDDENR3 domRELAT-1K1 h /\\XBOOLE-0K3 X"
          using A1 relat_1_th_61 sorry
        then have "g inHIDDENR3 domRELAT-1K1 h"
          using xboole_0_def_4 sorry
        then have "r inHIDDENR3 rngFUNCT-1K2 h"
          using A3 funct_1_def_3 sorry
        then have A5: "r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4)"
          using funct_1_th_33 sorry
        have "g inHIDDENR3 domRELAT-1K1 h & g inHIDDENR3 X"
          using A4 xboole_0_def_4 sorry
        then have "r inHIDDENR3 h .:FUNCT-1K5 X"
          using A3 funct_1_def_6 sorry
        then have "r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4) /\\XBOOLE-0K3 h .:FUNCT-1K5 X"
          using A5 xboole_0_def_4 sorry
        thus "r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X))"
          using relat_1_th_61 sorry
      qed
      assume "r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X))"
      then have "r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4) /\\XBOOLE-0K3 h .:FUNCT-1K5 X"
        using relat_1_th_61 sorry
      then have "r inHIDDENR3 h .:FUNCT-1K5 X"
        using xboole_0_def_4 sorry
      then obtain t where
        [ty]:"t be objectHIDDENM1" and 
        A6: "t inHIDDENR3 domRELAT-1K1 h"and A7: "t inHIDDENR3 X"and A8: "h .FUNCT-1K1 t =HIDDENR1 r"
        using funct_1_def_6 sorry
      have "t inHIDDENR3 domRELAT-1K1 h /\\XBOOLE-0K3 X"
        using A6 A7 xboole_0_def_4 sorry
      then have A9: "t inHIDDENR3 domRELAT-1K1 (h  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "(h  |RELAT-1K8 X).FUNCT-1K1 t =HIDDENR1 r"
        using A7 A8 funct_1_th_49 sorry
      then have "r inHIDDENR3 rngFUNCT-1K2 hX"
        using A9 funct_1_def_3 sorry
      thus "r inHIDDENR3 domRELAT-1K1 ((h  |RELAT-1K8 X)\<inverse>FUNCT-1K4)"
        using funct_1_th_33 sorry
    qed "sorry"
    then have A10: "domRELAT-1K1 (hX \<inverse>FUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X))"
      using tarski_th_2 sorry
    have "( ex r be objectHIDDENM1 st r inHIDDENR3 domRELAT-1K1 ((h  |RELAT-1K8 X)\<inverse>FUNCT-1K4) & (h  |RELAT-1K8 X)\<inverse>FUNCT-1K4 .FUNCT-1K1 r <>HIDDENR2 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X)).FUNCT-1K1 r) implies  False "
    proof(rule impI)
      assume Given: " ex r be objectHIDDENM1 st r inHIDDENR3 domRELAT-1K1 ((h  |RELAT-1K8 X)\<inverse>FUNCT-1K4) & (h  |RELAT-1K8 X)\<inverse>FUNCT-1K4 .FUNCT-1K1 r <>HIDDENR2 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X)).FUNCT-1K1 r"
      then obtain r where
        [ty]:"r be objectHIDDENM1" and 
        A11: "r inHIDDENR3 domRELAT-1K1 ((h  |RELAT-1K8 X)\<inverse>FUNCT-1K4)"and A12: "(h  |RELAT-1K8 X)\<inverse>FUNCT-1K4 .FUNCT-1K1 r <>HIDDENR2 (h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X)).FUNCT-1K1 r"
         sorry
      have "r inHIDDENR3 domRELAT-1K1 (h \<inverse>FUNCT-1K4) /\\XBOOLE-0K3 h .:FUNCT-1K5 X"
        using A10 A11 relat_1_th_61 sorry
      then have "r inHIDDENR3 h .:FUNCT-1K5 X"
        using xboole_0_def_4 sorry
      then obtain t where
        [ty]:"t be objectHIDDENM1" and 
        "t inHIDDENR3 domRELAT-1K1 h"and "t inHIDDENR3 X"and A13: "h .FUNCT-1K1 t =HIDDENR1 r"
        using funct_1_def_6 sorry
      have "r inHIDDENR3 rngFUNCT-1K2 hX"
        using A11 funct_1_th_33 sorry
      then obtain g where
        [ty]:"g be objectHIDDENM1" and 
        A14: "g inHIDDENR3 domRELAT-1K1 (h  |RELAT-1K8 X)"and A15: "(h  |RELAT-1K8 X).FUNCT-1K1 g =HIDDENR1 r"
        using funct_1_def_3 sorry
      have A16: "h .FUNCT-1K1 g =HIDDENR1 r"
        using A14 A15 funct_1_th_47 sorry
      have "g inHIDDENR3 domRELAT-1K1 h /\\XBOOLE-0K3 X"
        using A14 relat_1_th_61 sorry
      then have A17: "g inHIDDENR3 domRELAT-1K1 h"
        using xboole_0_def_4 sorry
      have "hX \<inverse>FUNCT-1K4 .FUNCT-1K1 r <>HIDDENR2 h \<inverse>FUNCT-1K4 .FUNCT-1K1 r"
        using A10 A11 A12 funct_1_th_47 sorry
      then have "g <>HIDDENR2 h \<inverse>FUNCT-1K4 .FUNCT-1K1 (h .FUNCT-1K1 t)"
        using A14 A15 A13 funct_1_th_34 sorry
      thus " False "
        using A13 A17 A16 funct_1_th_34 sorry
    qed
    thus "(h  |RELAT-1K8 X)\<inverse>FUNCT-1K4 =FUNCT-1R1 h \<inverse>FUNCT-1K4  |RELAT-1K8 (h .:FUNCT-1K5 X)"
      using A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_18:
" for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h be real-boundedXXREAL-2V5 & upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h) implies h be constantFUNCT-1V5"
proof-
  have " for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h be real-boundedXXREAL-2V5 & upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h) implies ( not h be constantFUNCT-1V5 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    assume A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h be real-boundedXXREAL-2V5 & upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h)"
    assume " not h be constantFUNCT-1V5"
    then obtain x1 x2 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
      A2: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> h & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(W)\<^esub> h"and A3: "h .FUNCT-1K1 x1 <>HIDDENR2 h .FUNCT-1K1 x2"
       sorry
    have "h .FUNCT-1K1 x1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h & h .FUNCT-1K1 x2 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> h"
      using A2 funct_1_def_3 sorry
    thus " False "
      using A1 A3 seq_4_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_19:
" for Y be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y be real-boundedXXREAL-2V5 & upper-boundSEQ-4K2 (h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y) =COMPLEX1R1 lower-boundSEQ-4K3 (h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y) implies h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
proof-
  have " for Y be setHIDDENM2 holds  for W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2) holds  not ((h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y be real-boundedXXREAL-2V5 & upper-boundSEQ-4K2 (h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y) =COMPLEX1R1 lower-boundSEQ-4K3 (h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y)) &  not h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix W assume [ty]: "W be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(W,REALNUMBERSK2)"
    have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y"
      using relat_1_th_115 sorry
    thus " not ((h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y be real-boundedXXREAL-2V5 & upper-boundSEQ-4K2 (h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y) =COMPLEX1R1 lower-boundSEQ-4K3 (h .:RELSET-1K7\<^bsub>(W,REALNUMBERSK2)\<^esub> Y)) &  not h  |PARTFUN1K2\<^bsub>(W,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)"
      using rfunct_2_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve e1, e2 for "ExtRealXXREAL-0M1"
reserve h, h1, h2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
abbreviation(input) RFUNCT_2V1("increasingRFUNCT-2V1" 70) where
  "increasingRFUNCT-2V1 \<equiv> increasingVALUED-0V9"

mtheorem rfunct_2_def_1:
  mlet "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"redefine attr increasingRFUNCT-2V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2)"
proof
(*compatibility*)
  show " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be increasingRFUNCT-2V1 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2)"
  proof(rule ballI)
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h be increasingRFUNCT-2V1 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2)"
       sorry
  qed "sorry"
qed "sorry"

abbreviation(input) RFUNCT_2V2("decreasingRFUNCT-2V2" 70) where
  "decreasingRFUNCT-2V2 \<equiv> decreasingVALUED-0V10"

mtheorem rfunct_2_def_2:
  mlet "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"redefine attr decreasingRFUNCT-2V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
proof
(*compatibility*)
  show " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be decreasingRFUNCT-2V2 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
  proof(rule ballI)
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h be decreasingRFUNCT-2V2 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
       sorry
  qed "sorry"
qed "sorry"

abbreviation(input) RFUNCT_2V3("non-decreasingRFUNCT-2V3" 70) where
  "non-decreasingRFUNCT-2V3 \<equiv> non-decreasingVALUED-0V11"

mtheorem rfunct_2_def_3:
  mlet "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"redefine attr non-decreasingRFUNCT-2V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
proof
(*compatibility*)
  show " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be non-decreasingRFUNCT-2V3 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
  proof(rule ballI)
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h be non-decreasingRFUNCT-2V3 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
    proof-
      have "(h be non-decreasingVALUED-0V11 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2) implies h be non-decreasingVALUED-0V11)"
      proof(rule conjMI,rule impI)
        show "h be non-decreasingVALUED-0V11 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
           sorry
        assume A1: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
        have " for e1 be ExtRealXXREAL-0M1 holds  for e2 be ExtRealXXREAL-0M1 holds e1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies (e1 <=XXREAL-0R1 e2 implies h .FUNCT-1K1 e1 <=XXREAL-0R1 h .FUNCT-1K1 e2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix e1 assume [ty]: "e1 be ExtRealXXREAL-0M1"
          fix e2 assume [ty]: "e2 be ExtRealXXREAL-0M1"
          assume A2: "e1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          assume "e1 <=XXREAL-0R1 e2"
          then have "e1 <XXREAL-0R3 e2 or e1 =HIDDENR1 e2"
            using xxreal_0_th_1 sorry
          thus "h .FUNCT-1K1 e1 <=XXREAL-0R1 h .FUNCT-1K1 e2"
            using A1 A2 sorry
        qed "sorry"
        thus "h be non-decreasingVALUED-0V11"
          using valued_0_def_15 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) RFUNCT_2V4("non-increasingRFUNCT-2V4" 70) where
  "non-increasingRFUNCT-2V4 \<equiv> non-increasingVALUED-0V12"

mtheorem rfunct_2_def_4:
  mlet "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"redefine attr non-increasingRFUNCT-2V4 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
proof
(*compatibility*)
  show " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be non-increasingRFUNCT-2V4 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
  proof(rule ballI)
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h be non-increasingRFUNCT-2V4 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
    proof-
      have "(h be non-increasingVALUED-0V12 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 >=XXREAL-0R2 h .FUNCT-1K1 r2)) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 >=XXREAL-0R2 h .FUNCT-1K1 r2) implies h be non-increasingVALUED-0V12)"
      proof(rule conjMI,rule impI)
        show "h be non-increasingVALUED-0V12 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 >=XXREAL-0R2 h .FUNCT-1K1 r2)"
           sorry
        assume A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 >=XXREAL-0R2 h .FUNCT-1K1 r2"
        have " for e1 be ExtRealXXREAL-0M1 holds  for e2 be ExtRealXXREAL-0M1 holds e1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies (e1 <=XXREAL-0R1 e2 implies h .FUNCT-1K1 e2 <=XXREAL-0R1 h .FUNCT-1K1 e1)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix e1 assume [ty]: "e1 be ExtRealXXREAL-0M1"
          fix e2 assume [ty]: "e2 be ExtRealXXREAL-0M1"
          assume A4: "e1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          assume "e1 <=XXREAL-0R1 e2"
          then have "e1 <XXREAL-0R3 e2 or e1 =HIDDENR1 e2"
            using xxreal_0_th_1 sorry
          thus "h .FUNCT-1K1 e2 <=XXREAL-0R1 h .FUNCT-1K1 e1"
            using A3 A4 sorry
        qed "sorry"
        thus "h be non-increasingVALUED-0V12"
          using valued_0_def_16 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem rfunct_2_th_20:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2)"
proof-
  have " for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 >XXREAL-0R4 h .FUNCT-1K1 r1)) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 >XXREAL-0R4 h .FUNCT-1K1 r1) implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 >XXREAL-0R4 h .FUNCT-1K1 r1)"
    proof-
      have "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r1 <XXREAL-0R3 r2) implies  not h .FUNCT-1K1 r2 >XXREAL-0R4 h .FUNCT-1K1 r1)"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A2: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          and A3: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          and A4: "r1 <XXREAL-0R3 r2"
        have A5: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using A3 relat_1_th_61 sorry
        then have A6: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
          using funct_1_th_47 sorry
        have A7: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using A2 relat_1_th_61 sorry
        then have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1"
          using funct_1_th_47 sorry
        thus " not h .FUNCT-1K1 r2 >XXREAL-0R4 h .FUNCT-1K1 r1"
          using A1 A4 A7 A5 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 >XXREAL-0R4 h .FUNCT-1K1 r1"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & r1 <XXREAL-0R3 r2 implies  not (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A9: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
        and A10: "r1 <XXREAL-0R3 r2"
      have A11: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
        using A9 funct_1_th_47 sorry
      have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A9 relat_1_th_61 sorry
      thus " not (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2"
        using A8 A10 A11 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
      using rfunct_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_21:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
proof-
  have " for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1) implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
    proof-
      have "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r1 <XXREAL-0R3 r2) implies  not h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1)"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A2: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          and A3: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          and A4: "r1 <XXREAL-0R3 r2"
        have A5: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using A3 relat_1_th_61 sorry
        then have A6: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
          using funct_1_th_47 sorry
        have A7: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using A2 relat_1_th_61 sorry
        then have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1"
          using funct_1_th_47 sorry
        thus " not h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1"
          using A1 A4 A7 A5 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & r1 <XXREAL-0R3 r2 implies  not (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A9: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
        and A10: "r1 <XXREAL-0R3 r2"
      have A11: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
        using A9 funct_1_th_47 sorry
      have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A9 relat_1_th_61 sorry
      thus " not (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1"
        using A8 A10 A11 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
      using rfunct_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_22:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
proof-
  have " for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2) implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
    proof-
      have "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r1 <XXREAL-0R3 r2) implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A2: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          and A3: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          and A4: "r1 <XXREAL-0R3 r2"
        have A5: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using A3 relat_1_th_61 sorry
        then have A6: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
          using funct_1_th_47 sorry
        have A7: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using A2 relat_1_th_61 sorry
        then have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1"
          using funct_1_th_47 sorry
        thus "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
          using A1 A4 A7 A5 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & r1 <XXREAL-0R3 r2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A9: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
        and A10: "r1 <XXREAL-0R3 r2"
      have A11: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
        using A9 funct_1_th_47 sorry
      have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A9 relat_1_th_61 sorry
      thus "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2"
        using A8 A10 A11 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
      using rfunct_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_23:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
proof-
  have " for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1) implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
    proof-
      have "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r1 <XXREAL-0R3 r2) implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A2: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          and A3: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          and A4: "r1 <XXREAL-0R3 r2"
        have A5: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using A3 relat_1_th_61 sorry
        then have A6: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
          using funct_1_th_47 sorry
        have A7: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using A2 relat_1_th_61 sorry
        then have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1"
          using funct_1_th_47 sorry
        thus "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
          using A1 A4 A7 A5 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & r1 <XXREAL-0R3 r2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A9: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
        and A10: "r1 <XXREAL-0R3 r2"
      have A11: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
        using A9 funct_1_th_47 sorry
      have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A9 relat_1_th_61 sorry
      thus "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1"
        using A8 A10 A11 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
      using rfunct_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rfunct_2_def_5 ("monotoneRFUNCT-2V5" 70 ) where
"attr monotoneRFUNCT-2V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>h. h be non-decreasingRFUNCT-2V3 or h be non-increasingRFUNCT-2V4)"..

mtheorem rfunct_2_cl_2:
"cluster non-decreasingRFUNCT-2V3 also-is monotoneRFUNCT-2V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be non-decreasingRFUNCT-2V3 implies it be monotoneRFUNCT-2V5"
     sorry
qed "sorry"

mtheorem rfunct_2_cl_3:
"cluster non-increasingRFUNCT-2V4 also-is monotoneRFUNCT-2V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be non-increasingRFUNCT-2V4 implies it be monotoneRFUNCT-2V5"
     sorry
qed "sorry"

mtheorem rfunct_2_cl_4:
"cluster  non monotoneRFUNCT-2V5 also-is  non non-decreasingRFUNCT-2V3\<bar> non non-increasingRFUNCT-2V4 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be  non monotoneRFUNCT-2V5 implies it be  non non-decreasingRFUNCT-2V3\<bar> non non-increasingRFUNCT-2V4"
     sorry
qed "sorry"

mtheorem rfunct_2_th_24:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
proof-
  have " for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2) implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2)"
    proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A2: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and A3: "r1 <=XXREAL-0R1 r2"
      have "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
      proof-
        show "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
        proof-
          have cases: "r1 <XXREAL-0R3 r2 or r1 =COMPLEX1R1 r2"
            using A3 xxreal_0_th_1 sorry
          have case1: "r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
          proof(rule impI)
            assume "r1 <XXREAL-0R3 r2"
            thus "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
              using A1 A2 rfunct_2_th_22 sorry
          qed
          have case2: "r1 =COMPLEX1R1 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
          proof(rule impI)
            assume "r1 =COMPLEX1R1 r2"
            thus "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
         sorry
    qed "sorry"
    assume A4: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & r1 <XXREAL-0R3 r2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A5: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
        and A6: "r1 <XXREAL-0R3 r2"
      have A7: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
        using A5 funct_1_th_47 sorry
      have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A5 relat_1_th_61 sorry
      thus "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2"
        using A4 A6 A7 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
      using rfunct_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_25:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
proof-
  have " for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1) implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1)"
    proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A2: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and A3: "r1 <=XXREAL-0R1 r2"
      have "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
      proof-
        show "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
        proof-
          have cases: "r1 <XXREAL-0R3 r2 or r1 =COMPLEX1R1 r2"
            using A3 xxreal_0_th_1 sorry
          have case1: "r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
          proof(rule impI)
            assume "r1 <XXREAL-0R3 r2"
            thus "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
              using A1 A2 rfunct_2_th_23 sorry
          qed
          have case2: "r1 =COMPLEX1R1 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
          proof(rule impI)
            assume "r1 =COMPLEX1R1 r2"
            thus "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
         sorry
    qed "sorry"
    assume A4: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <=XXREAL-0R1 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & r1 <XXREAL-0R3 r2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A5: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
        and A6: "r1 <XXREAL-0R3 r2"
      have A7: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1 =COMPLEX1R1 h .FUNCT-1K1 r1 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 =COMPLEX1R1 h .FUNCT-1K1 r2"
        using A5 funct_1_th_47 sorry
      have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A5 relat_1_th_61 sorry
      thus "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r2 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 r1"
        using A4 A6 A7 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
      using rfunct_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_cl_5:
"cluster non-decreasingRFUNCT-2V3\<bar>non-increasingRFUNCT-2V4 also-is constantFUNCT-1V5 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be non-decreasingRFUNCT-2V3\<bar>non-increasingRFUNCT-2V4 implies it be constantFUNCT-1V5"
  proof-
    have " for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h be non-decreasingRFUNCT-2V3\<bar>non-increasingRFUNCT-2V4 implies h be constantFUNCT-1V5"
    proof(rule ballI,rule impI)
      fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
      assume A1: "h be non-decreasingRFUNCT-2V3\<bar>non-increasingRFUNCT-2V4"
      have " for r1 be objectHIDDENM1 holds  for r2 be objectHIDDENM1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies h .FUNCT-1K1 r1 =HIDDENR1 h .FUNCT-1K1 r2"
      proof(rule ballI,rule ballI,rule impI)
        fix r1 assume [ty]: "r1 be objectHIDDENM1"
        fix r2 assume [ty]: "r2 be objectHIDDENM1"
        assume A2: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        then have 
          [ty]:"r1 be RealXREAL-0M1" and
          [ty]:"r2 be RealXREAL-0M1"
           sorry
        have "(r1 <XXREAL-0R3 r2 or r1 =COMPLEX1R1 r2) or r2 <XXREAL-0R3 r1"
          using xxreal_0_th_1 sorry
        then have "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2 & h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
          using A1 A2 sorry
        thus "h .FUNCT-1K1 r1 =HIDDENR1 h .FUNCT-1K1 r2"
          using xxreal_0_th_1 sorry
      qed "sorry"
      thus "h be constantFUNCT-1V5"
        using funct_1_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_2_cl_6:
"cluster constantFUNCT-1V5 also-is non-increasingRFUNCT-2V4\<bar>non-decreasingRFUNCT-2V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be constantFUNCT-1V5 implies it be non-increasingRFUNCT-2V4\<bar>non-decreasingRFUNCT-2V3"
     sorry
qed "sorry"

mtheorem rfunct_2_cl_7:
"cluster trivialZFMISC-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be trivialZFMISC-1V1"
  proof-
    have " ex tVar1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar1 be trivialZFMISC-1V1"
    proof-
      obtain f where 
        [ty]:"f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and fDef:"f = {}XBOOLE-0K1"
        using relset_1_th_12 sorry
      show " ex tVar1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar1 be trivialZFMISC-1V1"
      proof(rule bexI[of _ "f"])
        show "f be trivialZFMISC-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_2_cl_8:
  mlet "h be increasingRFUNCT-2V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is increasingRFUNCT-2V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be increasingRFUNCT-2V1"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be increasingVALUED-0V9)"
    proof-
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies (r1 <XXREAL-0R3 r2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A1: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        then have A2: "h .FUNCT-1K1 r1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 & h .FUNCT-1K1 r2 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
          using funct_1_th_47 sorry
        assume A3: "r1 <XXREAL-0R3 r2"
        have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A1 relat_1_th_57 sorry
        thus "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
          using A2 A3 rfunct_2_def_1 sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be increasingVALUED-0V9)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_2_cl_9:
  mlet "h be decreasingRFUNCT-2V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is decreasingRFUNCT-2V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be decreasingRFUNCT-2V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be decreasingVALUED-0V10)"
    proof-
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies (r1 <XXREAL-0R3 r2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 >XXREAL-0R4 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A1: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        then have A2: "h .FUNCT-1K1 r1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 & h .FUNCT-1K1 r2 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
          using funct_1_th_47 sorry
        assume A3: "r1 <XXREAL-0R3 r2"
        have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A1 relat_1_th_57 sorry
        thus "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 >XXREAL-0R4 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
          using A2 A3 rfunct_2_def_2 sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be decreasingVALUED-0V10)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_2_cl_10:
  mlet "h be non-decreasingRFUNCT-2V3\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is non-decreasingRFUNCT-2V3 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be non-decreasingRFUNCT-2V3"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be non-decreasingVALUED-0V11)"
    proof-
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies (r1 <XXREAL-0R3 r2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A1: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        then have A2: "h .FUNCT-1K1 r1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 & h .FUNCT-1K1 r2 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
          using funct_1_th_47 sorry
        assume A3: "r1 <XXREAL-0R3 r2"
        have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A1 relat_1_th_57 sorry
        thus "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
          using A2 A3 rfunct_2_def_3 sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be non-decreasingVALUED-0V11)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_2_th_26:
" for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Y missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies (((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be monotoneRFUNCT-2V5"
proof-
  have " for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (Y missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h &  not ((((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be monotoneRFUNCT-2V5))"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have "Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 {}XBOOLE-0K1 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be monotoneRFUNCT-2V5)))"
    proof(rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
      assume A1: "Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 {}XBOOLE-0K1"
      then have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2"
         sorry
      thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
        using rfunct_2_th_20 sorry
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1"
        using A1 sorry
      thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
        using rfunct_2_th_21 sorry
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
        using A1 sorry
      thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
        using rfunct_2_th_22 sorry
      have A2: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
        using A1 sorry
      thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
        using rfunct_2_th_23 sorry
      show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be monotoneRFUNCT-2V5"
        using A2 rfunct_2_th_23 sorry
    qed
    thus " not (Y missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h &  not ((((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4) & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be monotoneRFUNCT-2V5))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_27:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Y /\\XBOOLE-0K3 X) be constantFUNCT-1V5"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Y /\\XBOOLE-0K3 X) be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Y /\\XBOOLE-0K3 X) be constantFUNCT-1V5"
    proof-
      have cases: "(Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 {}XBOOLE-0K1 or (Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "(Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 {}XBOOLE-0K1 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Y /\\XBOOLE-0K3 X) be constantFUNCT-1V5"
      proof(rule impI)
        assume "(Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "Y /\\XBOOLE-0K3 X missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
           sorry
        thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Y /\\XBOOLE-0K3 X) be constantFUNCT-1V5"
          using partfun2_th_39 sorry
      qed
      have case2: "(Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h <>HIDDENR2 {}XBOOLE-0K1 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Y /\\XBOOLE-0K3 X) be constantFUNCT-1V5"
      proof(rule impI)
        assume A2: "(Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h <>HIDDENR2 {}XBOOLE-0K1"
        let ?x = "the ElementSUBSET-1M1-of (Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        have "?x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A2 xboole_0_def_4 sorry
        then obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" and xDef:"x = ?x"
           sorry
        have " ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 (Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies h .FUNCT-1K1 p =COMPLEX1R1 r1"
        proof-
          obtain r1 where 
            [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and r1Def:"r1 = h .FUNCT-1K1 x"
            using xreal_0_def_1 sorry
          show " ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 (Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies h .FUNCT-1K1 p =COMPLEX1R1 r1"
          proof(rule bexI[of _ "r1"])
            have " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 (Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies h .FUNCT-1K1 p =COMPLEX1R1 h .FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be ElementSUBSET-1M1-of REALNUMBERSK2"
              assume A3: "p inTARSKIR2 (Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
              then have A4: "p inTARSKIR2 Y /\\XBOOLE-0K3 X"
                using xboole_0_def_4 sorry
              have A5: "p inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
                using A3 xboole_0_def_4 sorry
              have "p inTARSKIR2 X"
                using A4 xboole_0_def_4 sorry
              then have A6: "p inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
                using A5 xboole_0_def_4 sorry
              have A7: "x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
                using A2 xboole_0_def_4 sorry
              have A8: "x inTARSKIR2 Y /\\XBOOLE-0K3 X"
                using A2 xboole_0_def_4 sorry
              then have "x inTARSKIR2 Y"
                using xboole_0_def_4 sorry
              then have A9: "x inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
                using A7 xboole_0_def_4 sorry
              have "x inTARSKIR2 X"
                using A8 xboole_0_def_4 sorry
              then have A10: "x inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
                using A7 xboole_0_def_4 sorry
              have "p inTARSKIR2 Y"
                using A4 xboole_0_def_4 sorry
              then have A11: "p inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
                using A5 xboole_0_def_4 sorry
              show "h .FUNCT-1K1 p =COMPLEX1R1 h .FUNCT-1K1 x"
              proof-
                have cases: "x <=XXREAL-0R1 p or p <=XXREAL-0R1 x"
                   sorry
                have case1: "x <=XXREAL-0R1 p implies h .FUNCT-1K1 p =COMPLEX1R1 h .FUNCT-1K1 x"
                proof(rule impI)
                  assume "x <=XXREAL-0R1 p"
                  then have "h .FUNCT-1K1 x <=XXREAL-0R1 h .FUNCT-1K1 p & h .FUNCT-1K1 p <=XXREAL-0R1 h .FUNCT-1K1 x"
                    using A1 A11 A6 A9 A10 rfunct_2_th_24 rfunct_2_th_25 sorry
                  thus "h .FUNCT-1K1 p =COMPLEX1R1 h .FUNCT-1K1 x"
                    using xxreal_0_th_1 sorry
                qed
                have case2: "p <=XXREAL-0R1 x implies h .FUNCT-1K1 p =COMPLEX1R1 h .FUNCT-1K1 x"
                proof(rule impI)
                  assume "p <=XXREAL-0R1 x"
                  then have "h .FUNCT-1K1 p <=XXREAL-0R1 h .FUNCT-1K1 x & h .FUNCT-1K1 x <=XXREAL-0R1 h .FUNCT-1K1 p"
                    using A1 A11 A6 A9 A10 rfunct_2_th_24 rfunct_2_th_25 sorry
                  thus "h .FUNCT-1K1 p =COMPLEX1R1 h .FUNCT-1K1 x"
                    using xxreal_0_th_1 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 (Y /\\XBOOLE-0K3 X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h implies h .FUNCT-1K1 p =COMPLEX1R1 r1"
               sorry
          qed "sorry"
        qed
        thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Y /\\XBOOLE-0K3 X) be constantFUNCT-1V5"
          using partfun2_th_57 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_28:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 Y"
      and A2: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impI)
      have A3: "X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A1 xboole_1_th_26 sorry
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume "(r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2"
      thus "h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2"
        using A2 A3 rfunct_2_th_20 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
      using rfunct_2_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_29:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 Y"
      and A2: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 >XXREAL-0R4 h .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impI)
      have A3: "X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A1 xboole_1_th_26 sorry
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume "(r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2"
      thus "h .FUNCT-1K1 r1 >XXREAL-0R4 h .FUNCT-1K1 r2"
        using A2 A3 rfunct_2_th_21 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
      using rfunct_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_30:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 Y"
      and A2: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impI)
      have A3: "X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A1 xboole_1_th_26 sorry
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume "(r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2"
      thus "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
        using A2 A3 rfunct_2_th_22 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
      using rfunct_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_31:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 Y & h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 Y"
      and A2: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds (r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2 implies h .FUNCT-1K1 r1 >=XXREAL-0R2 h .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impI)
      have A3: "X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h c=TARSKIR1 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A1 xboole_1_th_26 sorry
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume "(r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2"
      thus "h .FUNCT-1K1 r1 >=XXREAL-0R2 h .FUNCT-1K1 r2"
        using A2 A3 rfunct_2_th_23 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_32:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & 0NUMBERSK6 <XXREAL-0R3 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1) & (r =COMPLEX1R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & r <XXREAL-0R3 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2)"
proof-
  have " for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & 0NUMBERSK6 <XXREAL-0R3 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1) & ((r =COMPLEX1R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & r <XXREAL-0R3 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 & 0NUMBERSK6 <XXREAL-0R3 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
    proof(rule impMI ,rule impI)
      assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
        and A2: "0NUMBERSK6 <XXREAL-0R3 r"
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A3: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          and A4: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          and A5: "r1 <XXREAL-0R3 r2"
        have A6: "r2 inHIDDENR3 Y"
          using A4 xboole_0_def_4 sorry
        have A7: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using A4 xboole_0_def_4 sorry
        then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using valued_1_def_5 sorry
        then have A8: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A6 xboole_0_def_4 sorry
        have A9: "r1 inHIDDENR3 Y"
          using A3 xboole_0_def_4 sorry
        have A10: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using A3 xboole_0_def_4 sorry
        then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using valued_1_def_5 sorry
        then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A9 xboole_0_def_4 sorry
        then have "h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2"
          using A1 A5 A8 rfunct_2_th_20 sorry
        then have "r *XCMPLX-0K3 h .FUNCT-1K1 r1 <XXREAL-0R3 r *XCMPLX-0K3 h .FUNCT-1K1 r2"
          using A2 xreal_1_th_68 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <XXREAL-0R3 r *XCMPLX-0K3 h .FUNCT-1K1 r2"
          using A10 valued_1_def_5 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2"
          using A7 valued_1_def_5 sorry
      qed "sorry"
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
        using rfunct_2_th_20 sorry
    qed
    show "r =COMPLEX1R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
    proof(rule impI)
      assume A11: "r =COMPLEX1R1 0NUMBERSK6"
      have A12: "0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds r1 inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 =COMPLEX1R1 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
        assume "r1 inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        then have A13: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using xboole_0_def_4 sorry
        have "r *XCMPLX-0K3 h .FUNCT-1K1 r1 =COMPLEX1R1 0NUMBERSK6"
          using A11 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 =COMPLEX1R1 0NUMBERSK6"
          using A13 valued_1_def_5 sorry
      qed "sorry"
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
        using partfun2_th_57 A12 sorry
    qed
    assume A14: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
      and A15: "r <XXREAL-0R3 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A16: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        and A17: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        and A18: "r1 <XXREAL-0R3 r2"
      have A19: "r2 inHIDDENR3 Y"
        using A17 xboole_0_def_4 sorry
      have A20: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A17 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using valued_1_def_5 sorry
      then have A21: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A19 xboole_0_def_4 sorry
      have A22: "r1 inHIDDENR3 Y"
        using A16 xboole_0_def_4 sorry
      have A23: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A16 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using valued_1_def_5 sorry
      then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A22 xboole_0_def_4 sorry
      then have "h .FUNCT-1K1 r1 <XXREAL-0R3 h .FUNCT-1K1 r2"
        using A14 A18 A21 rfunct_2_th_20 sorry
      then have "r *XCMPLX-0K3 h .FUNCT-1K1 r2 <XXREAL-0R3 r *XCMPLX-0K3 h .FUNCT-1K1 r1"
        using A15 xreal_1_th_69 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <XXREAL-0R3 r *XCMPLX-0K3 h .FUNCT-1K1 r1"
        using A20 valued_1_def_5 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1"
        using A23 valued_1_def_5 sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
      using rfunct_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_33:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 & 0NUMBERSK6 <XXREAL-0R3 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 & r <XXREAL-0R3 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1)"
proof-
  have " for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 & 0NUMBERSK6 <XXREAL-0R3 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 & r <XXREAL-0R3 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 & 0NUMBERSK6 <XXREAL-0R3 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
    proof(rule impMI ,rule impI)
      assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
        and A2: "0NUMBERSK6 <XXREAL-0R3 r"
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A3: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          and A4: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          and A5: "r1 <XXREAL-0R3 r2"
        have A6: "r2 inHIDDENR3 Y"
          using A4 xboole_0_def_4 sorry
        have A7: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using A4 xboole_0_def_4 sorry
        then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using valued_1_def_5 sorry
        then have A8: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A6 xboole_0_def_4 sorry
        have A9: "r1 inHIDDENR3 Y"
          using A3 xboole_0_def_4 sorry
        have A10: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using A3 xboole_0_def_4 sorry
        then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using valued_1_def_5 sorry
        then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A9 xboole_0_def_4 sorry
        then have "h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1"
          using A1 A5 A8 rfunct_2_th_21 sorry
        then have "r *XCMPLX-0K3 h .FUNCT-1K1 r2 <XXREAL-0R3 r *XCMPLX-0K3 h .FUNCT-1K1 r1"
          using A2 xreal_1_th_68 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <XXREAL-0R3 r *XCMPLX-0K3 h .FUNCT-1K1 r1"
          using A7 valued_1_def_5 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1"
          using A10 valued_1_def_5 sorry
      qed "sorry"
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
        using rfunct_2_th_21 sorry
    qed
    assume A11: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
      and A12: "r <XXREAL-0R3 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A13: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        and A14: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        and A15: "r1 <XXREAL-0R3 r2"
      have A16: "r2 inHIDDENR3 Y"
        using A14 xboole_0_def_4 sorry
      have A17: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A14 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using valued_1_def_5 sorry
      then have A18: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A16 xboole_0_def_4 sorry
      have A19: "r1 inHIDDENR3 Y"
        using A13 xboole_0_def_4 sorry
      have A20: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A13 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using valued_1_def_5 sorry
      then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A19 xboole_0_def_4 sorry
      then have "h .FUNCT-1K1 r2 <XXREAL-0R3 h .FUNCT-1K1 r1"
        using A11 A15 A18 rfunct_2_th_21 sorry
      then have "r *XCMPLX-0K3 h .FUNCT-1K1 r1 <XXREAL-0R3 r *XCMPLX-0K3 h .FUNCT-1K1 r2"
        using A12 xreal_1_th_69 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <XXREAL-0R3 r *XCMPLX-0K3 h .FUNCT-1K1 r2"
        using A20 valued_1_def_5 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2"
        using A17 valued_1_def_5 sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
      using rfunct_2_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_34:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4)"
proof-
  have " for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
    proof(rule impMI ,rule impI)
      assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
        and A2: "0NUMBERSK6 <=XXREAL-0R1 r"
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A3: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          and A4: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          and A5: "r1 <XXREAL-0R3 r2"
        have A6: "r2 inHIDDENR3 Y"
          using A4 xboole_0_def_4 sorry
        have A7: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using A4 xboole_0_def_4 sorry
        then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using valued_1_def_5 sorry
        then have A8: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A6 xboole_0_def_4 sorry
        have A9: "r1 inHIDDENR3 Y"
          using A3 xboole_0_def_4 sorry
        have A10: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using A3 xboole_0_def_4 sorry
        then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using valued_1_def_5 sorry
        then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A9 xboole_0_def_4 sorry
        then have "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
          using A1 A5 A8 rfunct_2_th_22 sorry
        then have "r *XCMPLX-0K3 h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2 *XCMPLX-0K3 r"
          using A2 xreal_1_th_64 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <=XXREAL-0R1 r *XCMPLX-0K3 h .FUNCT-1K1 r2"
          using A10 valued_1_def_5 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2"
          using A7 valued_1_def_5 sorry
      qed "sorry"
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
        using rfunct_2_th_22 sorry
    qed
    assume A11: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
      and A12: "r <=XXREAL-0R1 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A13: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        and A14: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        and A15: "r1 <XXREAL-0R3 r2"
      have A16: "r2 inHIDDENR3 Y"
        using A14 xboole_0_def_4 sorry
      have A17: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A14 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using valued_1_def_5 sorry
      then have A18: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A16 xboole_0_def_4 sorry
      have A19: "r1 inHIDDENR3 Y"
        using A13 xboole_0_def_4 sorry
      have A20: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A13 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using valued_1_def_5 sorry
      then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A19 xboole_0_def_4 sorry
      then have "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
        using A11 A15 A18 rfunct_2_th_22 sorry
      then have "r *XCMPLX-0K3 h .FUNCT-1K1 r2 <=XXREAL-0R1 r *XCMPLX-0K3 h .FUNCT-1K1 r1"
        using A12 xreal_1_th_65 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <=XXREAL-0R1 r *XCMPLX-0K3 h .FUNCT-1K1 r1"
        using A17 valued_1_def_5 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1"
        using A20 valued_1_def_5 sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_35:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3)"
proof-
  have " for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
    proof(rule impMI ,rule impI)
      assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
        and A2: "0NUMBERSK6 <=XXREAL-0R1 r"
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A3: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          and A4: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          and A5: "r1 <XXREAL-0R3 r2"
        have A6: "r2 inHIDDENR3 Y"
          using A4 xboole_0_def_4 sorry
        have A7: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using A4 xboole_0_def_4 sorry
        then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using valued_1_def_5 sorry
        then have A8: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A6 xboole_0_def_4 sorry
        have A9: "r1 inHIDDENR3 Y"
          using A3 xboole_0_def_4 sorry
        have A10: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
          using A3 xboole_0_def_4 sorry
        then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using valued_1_def_5 sorry
        then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
          using A9 xboole_0_def_4 sorry
        then have "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
          using A1 A5 A8 rfunct_2_th_23 sorry
        then have "r *XCMPLX-0K3 h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1 *XCMPLX-0K3 r"
          using A2 xreal_1_th_64 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <=XXREAL-0R1 r *XCMPLX-0K3 h .FUNCT-1K1 r1"
          using A7 valued_1_def_5 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2 <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1"
          using A10 valued_1_def_5 sorry
      qed "sorry"
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
        using rfunct_2_th_23 sorry
    qed
    assume A11: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
      and A12: "r <=XXREAL-0R1 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & (r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) & r1 <XXREAL-0R3 r2) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A13: "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        and A14: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        and A15: "r1 <XXREAL-0R3 r2"
      have A16: "r2 inHIDDENR3 Y"
        using A14 xboole_0_def_4 sorry
      have A17: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A14 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using valued_1_def_5 sorry
      then have A18: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A16 xboole_0_def_4 sorry
      have A19: "r1 inHIDDENR3 Y"
        using A13 xboole_0_def_4 sorry
      have A20: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
        using A13 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using valued_1_def_5 sorry
      then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        using A19 xboole_0_def_4 sorry
      then have "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
        using A11 A15 A18 rfunct_2_th_23 sorry
      then have "r *XCMPLX-0K3 h .FUNCT-1K1 r1 <=XXREAL-0R1 r *XCMPLX-0K3 h .FUNCT-1K1 r2"
        using A12 xreal_1_th_65 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <=XXREAL-0R1 r *XCMPLX-0K3 h .FUNCT-1K1 r2"
        using A20 valued_1_def_5 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r1 <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 r2"
        using A17 valued_1_def_5 sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
      using rfunct_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_36:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds r inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) implies r inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds r inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) implies r inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "r inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
    then have "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
      using xboole_0_def_4 sorry
    then have "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
      using valued_1_def_1 sorry
    then have A2: "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
      using xboole_0_def_4 sorry
    have "r inHIDDENR3 X /\\XBOOLE-0K3 Y"
      using A1 xboole_0_def_4 sorry
    then have "r inHIDDENR3 X & r inHIDDENR3 Y"
      using xboole_0_def_4 sorry
    thus "r inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
      using A2 xboole_0_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_37:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2)) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3)) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-increasingRFUNCT-2V4)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1) & ((h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2) & ((h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-increasingRFUNCT-2V4)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1"
    proof(rule impMI ,rule impI)
      assume A1: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
        and A2: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be increasingRFUNCT-2V1"
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A3: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          and A4: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          and A5: "r1 <XXREAL-0R3 r2"
        have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2 & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
          using A3 A4 rfunct_2_th_36 sorry
        then have A6: "h2 .FUNCT-1K1 r1 <XXREAL-0R3 h2 .FUNCT-1K1 r2"
          using A2 A5 rfunct_2_th_20 sorry
        have A7: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          using A3 xboole_0_def_4 sorry
        have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
          using A3 A4 rfunct_2_th_36 sorry
        then have "h1 .FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2"
          using A1 A5 rfunct_2_th_20 sorry
        then have "h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
          using A6 xreal_1_th_8 sorry
        then have A8: "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
          using A7 valued_1_def_1 sorry
        have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          using A4 xboole_0_def_4 sorry
        thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
          using A8 valued_1_def_1 sorry
      qed "sorry"
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1"
        using rfunct_2_th_20 sorry
    qed
    show "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2"
    proof(rule impMI ,rule impI)
      assume A9: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
        and A10: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be decreasingRFUNCT-2V2"
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A11: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          and A12: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          and A13: "r1 <XXREAL-0R3 r2"
        have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2 & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
          using A11 A12 rfunct_2_th_36 sorry
        then have A14: "h2 .FUNCT-1K1 r2 <XXREAL-0R3 h2 .FUNCT-1K1 r1"
          using A10 A13 rfunct_2_th_21 sorry
        have A15: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          using A12 xboole_0_def_4 sorry
        have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
          using A11 A12 rfunct_2_th_36 sorry
        then have "h1 .FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1"
          using A9 A13 rfunct_2_th_21 sorry
        then have "h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
          using A14 xreal_1_th_8 sorry
        then have A16: "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
          using A15 valued_1_def_1 sorry
        have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          using A11 xboole_0_def_4 sorry
        thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
          using A16 valued_1_def_1 sorry
      qed "sorry"
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2"
        using rfunct_2_th_21 sorry
    qed
    show "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3"
    proof(rule impMI ,rule impI)
      assume A17: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
        and A18: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <=XXREAL-0R1 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A19: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          and A20: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          and A21: "r1 <XXREAL-0R3 r2"
        have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2 & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
          using A19 A20 rfunct_2_th_36 sorry
        then have A22: "h2 .FUNCT-1K1 r1 <=XXREAL-0R1 h2 .FUNCT-1K1 r2"
          using A18 A21 rfunct_2_th_22 sorry
        have A23: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          using A19 xboole_0_def_4 sorry
        have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
          using A19 A20 rfunct_2_th_36 sorry
        then have "h1 .FUNCT-1K1 r1 <=XXREAL-0R1 h1 .FUNCT-1K1 r2"
          using A17 A21 rfunct_2_th_22 sorry
        then have "h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1 <=XXREAL-0R1 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
          using A22 xreal_1_th_7 sorry
        then have A24: "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <=XXREAL-0R1 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
          using A23 valued_1_def_1 sorry
        have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          using A20 xboole_0_def_4 sorry
        thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <=XXREAL-0R1 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
          using A24 valued_1_def_1 sorry
      qed "sorry"
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3"
        using rfunct_2_th_22 sorry
    qed
    assume A25: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
      and A26: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <=XXREAL-0R1 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A27: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A28: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A29: "r1 <XXREAL-0R3 r2"
      have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2 & r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A27 A28 rfunct_2_th_36 sorry
      then have A30: "h2 .FUNCT-1K1 r2 <=XXREAL-0R1 h2 .FUNCT-1K1 r1"
        using A26 A29 rfunct_2_th_23 sorry
      have A31: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A28 xboole_0_def_4 sorry
      have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A27 A28 rfunct_2_th_36 sorry
      then have "h1 .FUNCT-1K1 r2 <=XXREAL-0R1 h1 .FUNCT-1K1 r1"
        using A25 A29 rfunct_2_th_23 sorry
      then have "h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2 <=XXREAL-0R1 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
        using A30 xreal_1_th_7 sorry
      then have A32: "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <=XXREAL-0R1 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
        using A31 valued_1_def_1 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A27 xboole_0_def_4 sorry
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <=XXREAL-0R1 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
        using A32 valued_1_def_1 sorry
    qed "sorry"
    thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-increasingRFUNCT-2V4"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_38:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1) & (h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1"
    proof(rule impMI ,rule impI)
      assume A1: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
        and A2: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
      obtain r where
        [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A3: " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2 implies h2 .FUNCT-1K1 p =COMPLEX1R1 r"
        using A2 partfun2_th_57 sorry
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A4: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          and A5: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          and A6: "r1 <XXREAL-0R3 r2"
        have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
          using A4 A5 rfunct_2_th_36 sorry
        then have "h1 .FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2"
          using A1 A6 rfunct_2_th_20 sorry
        then have A7: "h1 .FUNCT-1K1 r1 +XCMPLX-0K2 r <XXREAL-0R3 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 r"
          using xreal_1_th_6 sorry
        have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
          using A4 rfunct_2_th_36 sorry
        then have A8: "h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 r"
          using A3 A7 sorry
        have A9: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          using A4 xboole_0_def_4 sorry
        have "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
          using A5 rfunct_2_th_36 sorry
        then have "h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
          using A3 A8 sorry
        then have A10: "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
          using A9 valued_1_def_1 sorry
        have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
          using A5 xboole_0_def_4 sorry
        thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
          using A10 valued_1_def_1 sorry
      qed "sorry"
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1"
        using rfunct_2_th_20 sorry
    qed
    assume A11: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
      and A12: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
    obtain r where
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A13: " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2 implies h2 .FUNCT-1K1 p =COMPLEX1R1 r"
      using A12 partfun2_th_57 sorry
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A14: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A15: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A16: "r1 <XXREAL-0R3 r2"
      have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 & r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A14 A15 rfunct_2_th_36 sorry
      then have "h1 .FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1"
        using A11 A16 rfunct_2_th_21 sorry
      then have A17: "h1 .FUNCT-1K1 r2 +XCMPLX-0K2 r <XXREAL-0R3 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 r"
        using xreal_1_th_6 sorry
      have "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A15 rfunct_2_th_36 sorry
      then have A18: "h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 r"
        using A13 A17 sorry
      have A19: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A15 xboole_0_def_4 sorry
      have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A14 rfunct_2_th_36 sorry
      then have "h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
        using A13 A18 sorry
      then have A20: "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
        using A19 valued_1_def_1 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A14 xboole_0_def_4 sorry
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
        using A20 valued_1_def_1 sorry
    qed "sorry"
    thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2"
      using rfunct_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_39:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
      and A2: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-decreasingRFUNCT-2V3"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A4: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A5: "r1 <XXREAL-0R3 r2"
      have A6: "r2 inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A4 xboole_0_def_4 sorry
      then have A7: "r2 inHIDDENR3 Y"
        using xboole_0_def_4 sorry
      have A8: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A4 xboole_0_def_4 sorry
      then have A9: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using valued_1_def_1 sorry
      then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using xboole_0_def_4 sorry
      then have A10: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A7 xboole_0_def_4 sorry
      have A11: "r1 inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A3 xboole_0_def_4 sorry
      then have A12: "r1 inHIDDENR3 Y"
        using xboole_0_def_4 sorry
      have A13: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A3 xboole_0_def_4 sorry
      then have A14: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using valued_1_def_1 sorry
      then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A12 xboole_0_def_4 sorry
      then have A15: "h2 .FUNCT-1K1 r1 <=XXREAL-0R1 h2 .FUNCT-1K1 r2"
        using A2 A5 A10 rfunct_2_th_22 sorry
      have A16: "r2 inHIDDENR3 X"
        using A6 xboole_0_def_4 sorry
      have A17: "r1 inHIDDENR3 X"
        using A11 xboole_0_def_4 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A9 xboole_0_def_4 sorry
      then have A18: "r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A16 xboole_0_def_4 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A14 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A17 xboole_0_def_4 sorry
      then have "h1 .FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2"
        using A1 A5 A18 rfunct_2_th_20 sorry
      then have "h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
        using A15 xreal_1_th_8 sorry
      then have "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
        using A13 valued_1_def_1 sorry
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
        using A8 valued_1_def_1 sorry
    qed "sorry"
    thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be increasingRFUNCT-2V1"
      using rfunct_2_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-increasingRFUNCT-2V4"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-increasingRFUNCT-2V4"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
      and A2: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <=XXREAL-0R1 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A4: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A5: "r1 <XXREAL-0R3 r2"
      have A6: "r2 inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A4 xboole_0_def_4 sorry
      then have A7: "r2 inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have A8: "r2 inHIDDENR3 Y"
        using A6 xboole_0_def_4 sorry
      have A9: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A4 xboole_0_def_4 sorry
      then have A10: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using valued_1_def_1 sorry
      then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using xboole_0_def_4 sorry
      then have A11: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A8 xboole_0_def_4 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A10 xboole_0_def_4 sorry
      then have A12: "r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A7 xboole_0_def_4 sorry
      have A13: "r1 inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A3 xboole_0_def_4 sorry
      then have A14: "r1 inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have A15: "r1 inHIDDENR3 Y"
        using A13 xboole_0_def_4 sorry
      have A16: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A3 xboole_0_def_4 sorry
      then have A17: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using valued_1_def_1 sorry
      then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A15 xboole_0_def_4 sorry
      then have A18: "h2 .FUNCT-1K1 r2 =COMPLEX1R1 h2 .FUNCT-1K1 r1"
        using A2 A11 partfun2_th_58 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A17 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A14 xboole_0_def_4 sorry
      then have "h1 .FUNCT-1K1 r2 <=XXREAL-0R1 h1 .FUNCT-1K1 r1"
        using A1 A5 A12 rfunct_2_th_23 sorry
      then have "h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2 <=XXREAL-0R1 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
        using A18 xreal_1_th_6 sorry
      then have "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <=XXREAL-0R1 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
        using A9 valued_1_def_1 sorry
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <=XXREAL-0R1 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
        using A16 valued_1_def_1 sorry
    qed "sorry"
    thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-increasingRFUNCT-2V4"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
      and A2: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be non-increasingRFUNCT-2V4"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A4: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A5: "r1 <XXREAL-0R3 r2"
      have A6: "r2 inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A4 xboole_0_def_4 sorry
      then have A7: "r2 inHIDDENR3 Y"
        using xboole_0_def_4 sorry
      have A8: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A4 xboole_0_def_4 sorry
      then have A9: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using valued_1_def_1 sorry
      then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using xboole_0_def_4 sorry
      then have A10: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A7 xboole_0_def_4 sorry
      have A11: "r1 inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A3 xboole_0_def_4 sorry
      then have A12: "r1 inHIDDENR3 Y"
        using xboole_0_def_4 sorry
      have A13: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A3 xboole_0_def_4 sorry
      then have A14: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using valued_1_def_1 sorry
      then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A12 xboole_0_def_4 sorry
      then have A15: "h2 .FUNCT-1K1 r2 <=XXREAL-0R1 h2 .FUNCT-1K1 r1"
        using A2 A5 A10 rfunct_2_th_23 sorry
      have A16: "r2 inHIDDENR3 X"
        using A6 xboole_0_def_4 sorry
      have A17: "r1 inHIDDENR3 X"
        using A11 xboole_0_def_4 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A9 xboole_0_def_4 sorry
      then have A18: "r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A16 xboole_0_def_4 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A14 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A17 xboole_0_def_4 sorry
      then have "h1 .FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1"
        using A1 A5 A18 rfunct_2_th_21 sorry
      then have "h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
        using A15 xreal_1_th_8 sorry
      then have "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1"
        using A8 valued_1_def_1 sorry
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2 <XXREAL-0R3 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1"
        using A13 valued_1_def_1 sorry
    qed "sorry"
    thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be decreasingRFUNCT-2V2"
      using rfunct_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_42:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 & h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "h1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
      and A2: "h2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & (r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) & r1 <XXREAL-0R3 r2) implies (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <=XXREAL-0R1 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A4: "r2 inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        and A5: "r1 <XXREAL-0R3 r2"
      have A6: "r2 inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A4 xboole_0_def_4 sorry
      then have A7: "r2 inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have A8: "r2 inHIDDENR3 Y"
        using A6 xboole_0_def_4 sorry
      have A9: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A4 xboole_0_def_4 sorry
      then have A10: "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using valued_1_def_1 sorry
      then have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using xboole_0_def_4 sorry
      then have A11: "r2 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A8 xboole_0_def_4 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A10 xboole_0_def_4 sorry
      then have A12: "r2 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A7 xboole_0_def_4 sorry
      have A13: "r1 inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using A3 xboole_0_def_4 sorry
      then have A14: "r1 inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have A15: "r1 inHIDDENR3 Y"
        using A13 xboole_0_def_4 sorry
      have A16: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2)"
        using A3 xboole_0_def_4 sorry
      then have A17: "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using valued_1_def_1 sorry
      then have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 Y /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h2"
        using A15 xboole_0_def_4 sorry
      then have A18: "h2 .FUNCT-1K1 r2 =COMPLEX1R1 h2 .FUNCT-1K1 r1"
        using A2 A11 partfun2_th_58 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A17 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h1"
        using A14 xboole_0_def_4 sorry
      then have "h1 .FUNCT-1K1 r1 <=XXREAL-0R1 h1 .FUNCT-1K1 r2"
        using A1 A5 A12 rfunct_2_th_22 sorry
      then have "h1 .FUNCT-1K1 r1 +XCMPLX-0K2 h2 .FUNCT-1K1 r1 <=XXREAL-0R1 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
        using A18 xreal_1_th_6 sorry
      then have "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <=XXREAL-0R1 h1 .FUNCT-1K1 r2 +XCMPLX-0K2 h2 .FUNCT-1K1 r2"
        using A16 valued_1_def_1 sorry
      thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r1 <=XXREAL-0R1 (h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2).FUNCT-1K1 r2"
        using A9 valued_1_def_1 sorry
    qed "sorry"
    thus "(h1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be non-decreasingRFUNCT-2V3"
      using rfunct_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_43:
" for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-increasingRFUNCT-2V4"
proof-
  have " for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-increasingRFUNCT-2V4"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & (r2 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r1 <XXREAL-0R3 r2) implies h .FUNCT-1K1 r1 >=XXREAL-0R2 h .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A1: "r1 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and A2: "r2 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and "r1 <XXREAL-0R3 r2"
      have "r1 inHIDDENR3 {TARSKIK1 x}"
        using A1 xboole_0_def_4 sorry
      then have A3: "r1 =HIDDENR1 x"
        using tarski_def_1 sorry
      have "r2 inHIDDENR3 {TARSKIK1 x}"
        using A2 xboole_0_def_4 sorry
      thus "h .FUNCT-1K1 r1 >=XXREAL-0R2 h .FUNCT-1K1 r2"
        using A3 tarski_def_1 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-increasingRFUNCT-2V4"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_44:
" for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be decreasingRFUNCT-2V2"
proof-
  have " for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be decreasingRFUNCT-2V2"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & (r2 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r1 <XXREAL-0R3 r2) implies h .FUNCT-1K1 r1 >XXREAL-0R4 h .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A1: "r1 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and A2: "r2 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and A3: "r1 <XXREAL-0R3 r2"
      have "r1 inHIDDENR3 {TARSKIK1 x}"
        using A1 xboole_0_def_4 sorry
      then have A4: "r1 =HIDDENR1 x"
        using tarski_def_1 sorry
      have "r2 inHIDDENR3 {TARSKIK1 x}"
        using A2 xboole_0_def_4 sorry
      thus "h .FUNCT-1K1 r1 >XXREAL-0R4 h .FUNCT-1K1 r2"
        using A3 A4 tarski_def_1 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be decreasingRFUNCT-2V2"
      using rfunct_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_45:
" for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-decreasingRFUNCT-2V3"
proof-
  have " for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-decreasingRFUNCT-2V3"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & (r2 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r1 <XXREAL-0R3 r2) implies h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A1: "r1 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and A2: "r2 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and "r1 <XXREAL-0R3 r2"
      have "r1 inHIDDENR3 {TARSKIK1 x}"
        using A1 xboole_0_def_4 sorry
      then have A3: "r1 =HIDDENR1 x"
        using tarski_def_1 sorry
      have "r2 inHIDDENR3 {TARSKIK1 x}"
        using A2 xboole_0_def_4 sorry
      thus "h .FUNCT-1K1 r1 <=XXREAL-0R1 h .FUNCT-1K1 r2"
        using A3 tarski_def_1 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-decreasingRFUNCT-2V3"
      using rfunct_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_46:
" for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-increasingRFUNCT-2V4"
proof-
  have " for x be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-increasingRFUNCT-2V4"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & (r2 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & r1 <XXREAL-0R3 r2) implies h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A1: "r1 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and A2: "r2 inHIDDENR3 {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
        and "r1 <XXREAL-0R3 r2"
      have "r1 inHIDDENR3 {TARSKIK1 x}"
        using A1 xboole_0_def_4 sorry
      then have A3: "r1 =HIDDENR1 x"
        using tarski_def_1 sorry
      have "r2 inHIDDENR3 {TARSKIK1 x}"
        using A2 xboole_0_def_4 sorry
      thus "h .FUNCT-1K1 r2 <=XXREAL-0R1 h .FUNCT-1K1 r1"
        using A3 tarski_def_1 sorry
    qed "sorry"
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 x} be non-increasingRFUNCT-2V4"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_47:
" for R be SubsetSUBSET-1M2-of REALNUMBERSK2 holds idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be increasingRFUNCT-2V1"
proof-
  have " for R be SubsetSUBSET-1M2-of REALNUMBERSK2 holds idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be increasingRFUNCT-2V1"
  proof(rule ballI)
    fix R assume [ty]: "R be SubsetSUBSET-1M2-of REALNUMBERSK2"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 R /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R) & (r2 inHIDDENR3 R /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R) & r1 <XXREAL-0R3 r2) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R .FUNCT-1K1 r1 <XXREAL-0R3 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A1: "r1 inHIDDENR3 R /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R)"
        and A2: "r2 inHIDDENR3 R /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R)"
        and A3: "r1 <XXREAL-0R3 r2"
      have "r1 inHIDDENR3 R"
        using A1 xboole_0_def_4 sorry
      then have A4: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R .FUNCT-1K1 r1 =COMPLEX1R1 r1"
        using funct_1_th_18 sorry
      have "r2 inHIDDENR3 R"
        using A2 xboole_0_def_4 sorry
      thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R .FUNCT-1K1 r1 <XXREAL-0R3 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R .FUNCT-1K1 r2"
        using A3 A4 funct_1_th_18 sorry
    qed "sorry"
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> R  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> R be increasingRFUNCT-2V1"
      using rfunct_2_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_48:
" for X be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
  using rfunct_2_th_32 sorry

mtheorem rfunct_2_th_49:
" for X be setHIDDENM2 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
  using rfunct_2_th_34 sorry

mtheorem rfunct_2_th_50:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
    have "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
    proof-
      show "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
      proof-
        have cases: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
          using A1 sorry
        have case1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
        proof(rule impI)
          assume A2: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1"
          have " for p1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for p2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds p1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) & (p2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p2) implies p1 =COMPLEX1R1 p2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of REALNUMBERSK2"
            fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A3: "p1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
              and A4: "p2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
              and A5: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p2"
            have A6: "p1 inTARSKIR2 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & p2 inTARSKIR2 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
              using A3 A4 relat_1_th_61 sorry
            have A7: "h .FUNCT-1K1 p1 =HIDDENR1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p2"
              using A3 A5 funct_1_th_47 sorry
            also have "... = h .FUNCT-1K1 p2"
              using A4 funct_1_th_47 sorry
            finally have "h .FUNCT-1K1 p1 =HIDDENR1 h .FUNCT-1K1 p2"
               sorry
            show "p1 =COMPLEX1R1 p2"
            proof-
              have "p1 <>HIDDENR2 p2 implies  False "
              proof(rule impI)
                assume A8: "p1 <>HIDDENR2 p2"
                have " False "
                proof-
                  show " False "
                  proof-
                    have cases: "p1 <XXREAL-0R3 p2 or p2 <XXREAL-0R3 p1"
                      using A8 xxreal_0_th_1 sorry
                    have case1: "p1 <XXREAL-0R3 p2 implies  False "
                    proof(rule impI)
                      assume "p1 <XXREAL-0R3 p2"
                      thus " False "
                        using A2 A7 A6 rfunct_2_th_20 sorry
                    qed
                    have case2: "p2 <XXREAL-0R3 p1 implies  False "
                    proof(rule impI)
                      assume "p2 <XXREAL-0R3 p1"
                      thus " False "
                        using A2 A7 A6 rfunct_2_th_20 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus " False "
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
          qed "sorry"
          thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
             sorry
        qed
        have case2: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
        proof(rule impI)
          assume A9: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
          have " for p1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for p2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds p1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) & (p2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p2) implies p1 =COMPLEX1R1 p2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix p1 assume [ty]: "p1 be ElementSUBSET-1M1-of REALNUMBERSK2"
            fix p2 assume [ty]: "p2 be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A10: "p1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
              and A11: "p2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
              and A12: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p2"
            have A13: "p1 inTARSKIR2 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h & p2 inTARSKIR2 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
              using A10 A11 relat_1_th_61 sorry
            have A14: "h .FUNCT-1K1 p1 =HIDDENR1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 p2"
              using A10 A12 funct_1_th_47 sorry
            also have "... = h .FUNCT-1K1 p2"
              using A11 funct_1_th_47 sorry
            finally have "h .FUNCT-1K1 p1 =HIDDENR1 h .FUNCT-1K1 p2"
               sorry
            show "p1 =COMPLEX1R1 p2"
            proof-
              have "p1 <>HIDDENR2 p2 implies  False "
              proof(rule impI)
                assume A15: "p1 <>HIDDENR2 p2"
                have " False "
                proof-
                  show " False "
                  proof-
                    have cases: "p1 <XXREAL-0R3 p2 or p2 <XXREAL-0R3 p1"
                      using A15 xxreal_0_th_1 sorry
                    have case1: "p1 <XXREAL-0R3 p2 implies  False "
                    proof(rule impI)
                      assume "p1 <XXREAL-0R3 p2"
                      thus " False "
                        using A9 A14 A13 rfunct_2_th_21 sorry
                    qed
                    have case2: "p2 <XXREAL-0R3 p1 implies  False "
                    proof(rule impI)
                      assume "p2 <XXREAL-0R3 p1"
                      thus " False "
                        using A9 A14 A13 rfunct_2_th_21 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus " False "
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
          qed "sorry"
          thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be one-to-oneFUNCT-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_51:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be increasingRFUNCT-2V1"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 &  not (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be increasingRFUNCT-2V1 implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix h assume [ty]: "h be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1"
      and A2: " not (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be increasingRFUNCT-2V1"
    obtain y1 y2 where
      [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" and 
      A3: "y1 inHIDDENR3 h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"and A4: "y2 inHIDDENR3 h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"and A5: "y1 <XXREAL-0R3 y2"and A6: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 >=XXREAL-0R2 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2"
      using A2 rfunct_2_th_20 sorry
    obtain yy1 yy2 where 
      [ty]:"yy1 be RealXREAL-0M1" and yy1Def:"yy1 = y1" and
      [ty]:"yy2 be RealXREAL-0M1" and yy2Def:"yy2 = y2"
       sorry
    have "y1 inHIDDENR3 h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
      using A3 xboole_0_def_4 sorry
    then have A7: "yy1 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
      using relat_1_th_115 sorry
    have "y2 inHIDDENR3 h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
      using A4 xboole_0_def_4 sorry
    then have A8: "yy2 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
      using relat_1_th_115 sorry
    have A9: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1"
      using A1 sorry
    show " False "
    proof-
      have cases: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 or (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 <>HIDDENR2 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2"
         sorry
      have case1: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 implies  False "
      proof(rule impI)
        assume "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2"
        then have "y1 =HIDDENR1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2)"
          using A7 funct_1_th_35 sorry
        also have "... = y2"
          using A8 funct_1_th_35 sorry
        finally have "y1 =HIDDENR1 y2"
           sorry
        thus " False "
          using A5 sorry
      qed
      have case2: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 <>HIDDENR2 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 implies  False "
      proof(rule impI)
        assume A10: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 <>HIDDENR2 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2"
        have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
          using relat_1_th_72 sorry
        also have "... = ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
          using relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =HIDDENR1 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
           sorry
        have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 yy2 inTARSKIR2 REALNUMBERSK2 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 yy1 inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have A12: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 yy2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 yy1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
          using A7 A8 partfun2_th_60 sorry
        have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1"
          using A6 A10 xxreal_0_th_1 sorry
        then have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2) <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1)"
          using A9 A12 A11 rfunct_2_th_20 sorry
        then have "y2 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1)"
          using A8 funct_1_th_35 sorry
        thus " False "
          using A5 A7 funct_1_th_35 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_2_th_52:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be decreasingRFUNCT-2V2"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for h be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 &  not (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be decreasingRFUNCT-2V2 implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix h assume [ty]: "h be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
      and A2: " not (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be decreasingRFUNCT-2V2"
    obtain y1 y2 where
      [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" and 
      A3: "y1 inHIDDENR3 h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"and A4: "y2 inHIDDENR3 h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"and A5: "y1 <XXREAL-0R3 y2"and A6: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 >=XXREAL-0R2 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1"
      using A2 rfunct_2_th_21 sorry
    have "y1 inHIDDENR3 h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
      using A3 xboole_0_def_4 sorry
    then have A7: "y1 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
      using relat_1_th_115 sorry
    have "y2 inHIDDENR3 h .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
      using A4 xboole_0_def_4 sorry
    then have A8: "y2 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
      using relat_1_th_115 sorry
    have A9: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
      using A1 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 or (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 <>HIDDENR2 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2"
           sorry
        have case1: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 implies  False "
        proof(rule impI)
          assume "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 =COMPLEX1R1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2"
          then have "y1 =HIDDENR1 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2)"
            using A7 funct_1_th_35 sorry
          also have "... = y2"
            using A8 funct_1_th_35 sorry
          finally have "y1 =HIDDENR1 y2"
             sorry
          thus " False "
            using A5 sorry
        qed
        have case2: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 <>HIDDENR2 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 implies  False "
        proof(rule impI)
          assume A10: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 <>HIDDENR2 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2"
          have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using relat_1_th_72 sorry
          also have "... = ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using relat_1_th_61 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =HIDDENR1 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
             sorry
          have "(((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 inTARSKIR2 REALNUMBERSK2 & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 inTARSKIR2 REALNUMBERSK2) & y1 inHIDDENR3 REALNUMBERSK2) & y2 inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have A12: "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) & (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using A7 A8 partfun2_th_60 sorry
          have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2 >XXREAL-0R4 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1"
            using A6 A10 xxreal_0_th_1 sorry
          then have "(h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y2) <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1)"
            using A9 A12 A11 rfunct_2_th_21 sorry
          then have "y2 <XXREAL-0R3 (h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])).FUNCT-1K1 ((h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y1)"
            using A8 funct_1_th_35 sorry
          thus " False "
            using A5 A7 funct_1_th_35 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
