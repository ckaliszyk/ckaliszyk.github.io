theory funct_6
  imports binop_1 card_3
begin
(*begin*)
reserve x, y, y1, y2, z, a, b for "objectHIDDENM1"
reserve X, Y, Z, V1, V2 for "setHIDDENM2"
reserve f, g, h, h9, f1, f2 for "FunctionFUNCT-1M1"
reserve P for "PermutationFUNCT-2M2-of X"
mtheorem funct_6_th_1:
" for f be FunctionFUNCT-1M1 holds productCARD-3K4 f c=TARSKIR1 FuncsFUNCT-2K1(domRELAT-1K1 f,UnionCARD-3K3 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds productCARD-3K4 f c=TARSKIR1 FuncsFUNCT-2K1(domRELAT-1K1 f,UnionCARD-3K3 f)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 f implies x inHIDDENR3 FuncsFUNCT-2K1(domRELAT-1K1 f,UnionCARD-3K3 f)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 productCARD-3K4 f"
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A1: "x =HIDDENR1 g"and A2: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using card_3_def_5 sorry
      have "rngFUNCT-1K2 g c=TARSKIR1 UnionCARD-3K3 f"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 UnionCARD-3K3 f"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          have A4: "UnionCARD-3K3 f =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 f)"
            using card_3_def_4 sorry
          assume "y inHIDDENR3 rngFUNCT-1K2 g"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A5: "z inHIDDENR3 domRELAT-1K1 g & y =HIDDENR1 g .FUNCT-1K1 z"
            using funct_1_def_3 sorry
          have "y inHIDDENR3 f .FUNCT-1K1 z & f .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
            using A2 A3 A5 funct_1_def_3 sorry
          thus "y inHIDDENR3 UnionCARD-3K3 f"
            using A4 tarski_def_4 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 g c=TARSKIR1 UnionCARD-3K3 f"
          using tarski_def_3 sorry
      qed
      thus "x inHIDDENR3 FuncsFUNCT-2K1(domRELAT-1K1 f,UnionCARD-3K3 f)"
        using A1 A2 funct_2_def_2 sorry
    qed "sorry"
    thus "productCARD-3K4 f c=TARSKIR1 FuncsFUNCT-2K1(domRELAT-1K1 f,UnionCARD-3K3 f)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem funct_6_th_2:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f) implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ])"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f) implies  not ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not x =HIDDENR1 [TARSKIK4 y,z ])"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
    have " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st domRELAT-1K1 (~FUNCT-4K2 f) c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
      using funct_4_th_44 sorry
    thus " not ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not x =HIDDENR1 [TARSKIK4 y,z ])"
      using A1 relat_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_3:
" for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ~FUNCT-4K4\<^bsub>(X,Y,{TARSKIK1 z})\<^esub> ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =BINOP-1R13\<^bsub>(Y,X,{TARSKIK1 z})\<^esub> [:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z"
proof-
  have " for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ~FUNCT-4K4\<^bsub>(X,Y,{TARSKIK1 z})\<^esub> ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =BINOP-1R13\<^bsub>(Y,X,{TARSKIK1 z})\<^esub> [:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "domRELAT-1K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =RELAT-1R1 [:ZFMISC-1K2 X,Y :]"
      using funcop_1_th_13 sorry
    then have A2: "domRELAT-1K1 (~FUNCT-4K4\<^bsub>(X,Y,{TARSKIK1 z})\<^esub> ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z)) =RELAT-1R1 [:ZFMISC-1K2 Y,X :]"
      using funct_4_th_46 sorry
    have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 Y,X :] implies ~FUNCT-4K4\<^bsub>(X,Y,{TARSKIK1 z})\<^esub> ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .FUNCT-1K1 x =XBOOLE-0R4 ([:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
      then obtain y1 y2 where
        [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
        A5: "x =HIDDENR1 [TARSKIK4 y2,y1 ]"and A6: "[TARSKIK4 y1,y2 ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using A1 A2 funct_4_def_2 sorry
      have A7: "([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z).BINOP-1K1(y1,y2) =HIDDENR1 z"
        using A6 funcop_1_th_7 sorry
      have "([:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z).BINOP-1K1(y2,y1) =HIDDENR1 z"
        using A4 A5 funcop_1_th_7 sorry
      then have "~FUNCT-4K4\<^bsub>(X,Y,{TARSKIK1 z})\<^esub> ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .BINOP-1K1(y2,y1) =XBOOLE-0R4 ([:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z).BINOP-1K1(y2,y1)"
        using A1 A6 A7 funct_4_def_2 sorry
      thus "~FUNCT-4K4\<^bsub>(X,Y,{TARSKIK1 z})\<^esub> ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .FUNCT-1K1 x =XBOOLE-0R4 ([:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z).FUNCT-1K1 x"
        using A5 sorry
    qed "sorry"
    have "domRELAT-1K1 ([:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z) =RELAT-1R1 [:ZFMISC-1K2 Y,X :]"
      using funcop_1_th_13 sorry
    thus "~FUNCT-4K4\<^bsub>(X,Y,{TARSKIK1 z})\<^esub> ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =BINOP-1R13\<^bsub>(Y,X,{TARSKIK1 z})\<^esub> [:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_4:
" for f be FunctionFUNCT-1M1 holds curryFUNCT-5K1 f =FUNCT-1R1 curry'FUNCT-5K3 (~FUNCT-4K2 f) & uncurryFUNCT-5K2 f =FUNCT-1R1 ~FUNCT-4K2 (uncurry'FUNCT-5K4 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds curryFUNCT-5K1 f =FUNCT-1R1 curry'FUNCT-5K3 (~FUNCT-4K2 f) & uncurryFUNCT-5K2 f =FUNCT-1R1 ~FUNCT-4K2 (uncurry'FUNCT-5K4 f)"
  proof(rule ballI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f))) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 f)))"
      using funct_5_def_1 sorry
    have A2: "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using funct_5_def_1 sorry
    have A3: "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f))) =XBOOLE-0R4 domRELAT-1K1 (curryFUNCT-5K1 f)"
    proof-
      have "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f))) c=TARSKIR1 domRELAT-1K1 (curryFUNCT-5K1 f) & domRELAT-1K1 (curryFUNCT-5K1 f) c=TARSKIR1 domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f)))"
      proof(rule conjMI)
        show "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f))) c=TARSKIR1 domRELAT-1K1 (curryFUNCT-5K1 f)"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f))) implies x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f)))"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A4: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 f))"
              using A1 xtuple_0_def_12 sorry
            have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
              using A4 funct_4_th_42 sorry
            then have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
              using funct_4_th_42 sorry
            thus "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
              using A2 xtuple_0_def_12 sorry
          qed "sorry"
          thus "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f))) c=TARSKIR1 domRELAT-1K1 (curryFUNCT-5K1 f)"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f) implies x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f)))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A5: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
            using A2 xtuple_0_def_12 sorry
          have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
            using A5 funct_4_th_42 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 f))"
            using funct_4_th_42 sorry
          thus "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f)))"
            using A1 xtuple_0_def_12 sorry
        qed "sorry"
        thus "domRELAT-1K1 (curryFUNCT-5K1 f) c=TARSKIR1 domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f)))"
          using tarski_def_3 sorry
      qed
      thus "domRELAT-1K1 (curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f))) =XBOOLE-0R4 domRELAT-1K1 (curryFUNCT-5K1 f)"
        using xboole_0_def_10 sorry
    qed
    have A6: "curry'FUNCT-5K3 (~FUNCT-4K2 f) =FUNCT-1R1 curryFUNCT-5K1 (~FUNCT-4K2 (~FUNCT-4K2 f))"
      using funct_5_def_3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f) implies curryFUNCT-5K1 f .FUNCT-1K1 x =FUNCT-1R1 curry'FUNCT-5K3 (~FUNCT-4K2 f) .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 domRELAT-1K1 (curryFUNCT-5K1 f)"
      obtain g h where 
        [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = curryFUNCT-5K1 f .FUNCT-1K1 x" and
        [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = curry'FUNCT-5K3 (~FUNCT-4K2 f) .FUNCT-1K1 x"
         sorry
      have A8: "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))"
        using A7 funct_5_th_31 sorry
      have A9: "domRELAT-1K1 h =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)),{TARSKIK1 x} :]))"
        using A6 A3 A7 funct_5_th_34 sorry
      have A10: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h"
      proof-
        have "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 h & domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 g"
        proof(rule conjMI)
          show "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 h"
          proof-
            have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 g implies a inHIDDENR3 domRELAT-1K1 h"
            proof(rule ballI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              assume "a inHIDDENR3 domRELAT-1K1 g"
              then obtain b where
                [ty]:"b be objectHIDDENM1" and 
                A11: "[TARSKIK4 b,a ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])"
                using A8 xtuple_0_def_13 sorry
              have "[TARSKIK4 b,a ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]"
                using A11 xboole_0_def_4 sorry
              then have A12: "[TARSKIK4 a,b ] inHIDDENR3 [:ZFMISC-1K2 proj2XTUPLE-0K13 (domRELAT-1K1 f),{TARSKIK1 x} :]"
                using zfmisc_1_th_88 sorry
              have "[TARSKIK4 b,a ] inHIDDENR3 domRELAT-1K1 f"
                using A11 xboole_0_def_4 sorry
              then have A13: "[TARSKIK4 a,b ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
                using funct_4_th_42 sorry
              have "proj2XTUPLE-0K13 (domRELAT-1K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
                using funct_5_th_17 sorry
              then have "[TARSKIK4 a,b ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)),{TARSKIK1 x} :])"
                using A13 A12 xboole_0_def_4 sorry
              thus "a inHIDDENR3 domRELAT-1K1 h"
                using A9 xtuple_0_def_12 sorry
            qed "sorry"
            thus "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 h"
              using tarski_def_3 sorry
          qed
          have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 h implies a inHIDDENR3 domRELAT-1K1 g"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 domRELAT-1K1 h"
            then obtain b where
              [ty]:"b be objectHIDDENM1" and 
              A14: "[TARSKIK4 a,b ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)),{TARSKIK1 x} :])"
              using A9 xtuple_0_def_12 sorry
            have "[TARSKIK4 a,b ] inHIDDENR3 [:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)),{TARSKIK1 x} :]"
              using A14 xboole_0_def_4 sorry
            then have A15: "[TARSKIK4 b,a ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f)) :]"
              using zfmisc_1_th_88 sorry
            have "[TARSKIK4 a,b ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 f)"
              using A14 xboole_0_def_4 sorry
            then have A16: "[TARSKIK4 b,a ] inHIDDENR3 domRELAT-1K1 f"
              using funct_4_th_42 sorry
            have "proj2XTUPLE-0K13 (domRELAT-1K1 f) =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 (~FUNCT-4K2 f))"
              using funct_5_th_17 sorry
            then have "[TARSKIK4 b,a ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])"
              using A16 A15 xboole_0_def_4 sorry
            thus "a inHIDDENR3 domRELAT-1K1 g"
              using A8 xtuple_0_def_13 sorry
          qed "sorry"
          thus "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 g"
            using tarski_def_3 sorry
        qed
        thus "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h"
          using xboole_0_def_10 sorry
      qed
      have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 a =XBOOLE-0R4 h .FUNCT-1K1 a"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A17: "a inHIDDENR3 domRELAT-1K1 g"
        then have A18: "[TARSKIK4 x,a ] inHIDDENR3 domRELAT-1K1 f & g .FUNCT-1K1 a =XBOOLE-0R4 f .BINOP-1K1(x,a)"
          using A7 funct_5_th_31 sorry
        have "h .FUNCT-1K1 a =XBOOLE-0R4 ~FUNCT-4K2 f .BINOP-1K1(a,x)"
          using A6 A3 A7 A10 A17 funct_5_th_34 sorry
        thus "g .FUNCT-1K1 a =XBOOLE-0R4 h .FUNCT-1K1 a"
          using A18 funct_4_def_2 sorry
      qed "sorry"
      thus "curryFUNCT-5K1 f .FUNCT-1K1 x =FUNCT-1R1 curry'FUNCT-5K3 (~FUNCT-4K2 f) .FUNCT-1K1 x"
        using A10 sorry
    qed "sorry"
    thus "curryFUNCT-5K1 f =FUNCT-1R1 curry'FUNCT-5K3 (~FUNCT-4K2 f)"
      using A6 A3 sorry
    have A19: "domRELAT-1K1 (uncurryFUNCT-5K2 f) =XBOOLE-0R4 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)))"
    proof-
      have "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f))) & domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f))) c=TARSKIR1 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
      proof(rule conjMI)
        show "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)))"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) implies a inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)))"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A20: "a inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
            then obtain x g y where
              [ty]:"x be objectHIDDENM1" "g be FunctionFUNCT-1M1" "y be objectHIDDENM1" and 
              A21: "a =HIDDENR1 [TARSKIK4 x,y ]"and "x inHIDDENR3 domRELAT-1K1 f"and "g =XBOOLE-0R4 f .FUNCT-1K1 x"and "y inHIDDENR3 domRELAT-1K1 g"
              using funct_5_def_2 sorry
            have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (uncurryFUNCT-5K2 f))"
              using A20 A21 funct_4_th_42 sorry
            thus "a inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)))"
              using A21 funct_4_th_42 sorry
          qed "sorry"
          thus "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)))"
            using tarski_def_3 sorry
        qed
        have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f))) implies a inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)))"
          then have " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st a =HIDDENR1 [TARSKIK4 y,x ] & [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (uncurryFUNCT-5K2 f))"
            using funct_4_def_2 sorry
          thus "a inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
            using funct_4_th_42 sorry
        qed "sorry"
        thus "domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f))) c=TARSKIR1 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
          using tarski_def_3 sorry
      qed
      thus "domRELAT-1K1 (uncurryFUNCT-5K2 f) =XBOOLE-0R4 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)))"
        using xboole_0_def_10 sorry
    qed
    have A22: " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f))) implies uncurryFUNCT-5K2 f .FUNCT-1K1 a =XBOOLE-0R4 ~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)) .FUNCT-1K1 a"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume "a inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)))"
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A23: "a =HIDDENR1 [TARSKIK4 y,x ]"and A24: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (~FUNCT-4K2 (uncurryFUNCT-5K2 f))"
        using funct_4_def_2 sorry
      have "~FUNCT-4K2 (uncurryFUNCT-5K2 f) .BINOP-1K1(x,y) =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(y,x) & ~FUNCT-4K2 (uncurryFUNCT-5K2 f) .BINOP-1K1(x,y) =XBOOLE-0R4 ~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)) .BINOP-1K1(y,x)"
        using A24 funct_4_th_43 funct_4_def_2 sorry
      thus "uncurryFUNCT-5K2 f .FUNCT-1K1 a =XBOOLE-0R4 ~FUNCT-4K2 (~FUNCT-4K2 (uncurryFUNCT-5K2 f)) .FUNCT-1K1 a"
        using A23 sorry
    qed "sorry"
    have "uncurry'FUNCT-5K4 f =FUNCT-1R1 ~FUNCT-4K2 (uncurryFUNCT-5K2 f)"
      using funct_5_def_4 sorry
    thus "uncurryFUNCT-5K2 f =FUNCT-1R1 ~FUNCT-4K2 (uncurry'FUNCT-5K4 f)"
      using A19 A22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_5:
" for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies curryFUNCT-5K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =FUNCT-1R1 X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z) & curry'FUNCT-5K3 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =FUNCT-1R1 Y -->FUNCOP-1K7 (X -->FUNCOP-1K7 z)"
proof-
  have " for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies curryFUNCT-5K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =FUNCT-1R1 X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z) & curry'FUNCT-5K3 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =FUNCT-1R1 Y -->FUNCOP-1K7 (X -->FUNCOP-1K7 z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
    have A2: "domRELAT-1K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =RELAT-1R1 [:ZFMISC-1K2 X,Y :]"
      using funcop_1_th_13 sorry
    have A3: "domRELAT-1K1 (X -->FUNCOP-1K7 z) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies curry'FUNCT-5K3 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .FUNCT-1K1 x =FUNCT-1R1 (Y -->FUNCOP-1K7 (X -->FUNCOP-1K7 z)).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 Y"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A6: "curry'FUNCT-5K3 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .FUNCT-1K1 x =FUNCT-1R1 f & domRELAT-1K1 f =XBOOLE-0R4 X"and "rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z)"and A7: " for y be objectHIDDENM1 holds y inHIDDENR3 X implies f .FUNCT-1K1 y =XBOOLE-0R4 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z).BINOP-1K1(y,x)"
        using A1 A2 funct_5_th_32 sorry
      have A8: " for y be objectHIDDENM1 holds y inHIDDENR3 X implies f .FUNCT-1K1 y =XBOOLE-0R4 (X -->FUNCOP-1K7 z).FUNCT-1K1 y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A9: "y inHIDDENR3 X"
        then have A10: "f .FUNCT-1K1 y =XBOOLE-0R4 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z).BINOP-1K1(y,x)"
          using A7 sorry
        have "(X -->FUNCOP-1K7 z).FUNCT-1K1 y =HIDDENR1 z & [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using A5 A9 funcop_1_th_7 zfmisc_1_th_87 sorry
        thus "f .FUNCT-1K1 y =XBOOLE-0R4 (X -->FUNCOP-1K7 z).FUNCT-1K1 y"
          using A10 funcop_1_th_7 sorry
      qed "sorry"
      have "(Y -->FUNCOP-1K7 (X -->FUNCOP-1K7 z)).FUNCT-1K1 x =FUNCT-1R1 X -->FUNCOP-1K7 z"
        using A5 funcop_1_th_7 sorry
      thus "curry'FUNCT-5K3 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .FUNCT-1K1 x =FUNCT-1R1 (Y -->FUNCOP-1K7 (X -->FUNCOP-1K7 z)).FUNCT-1K1 x"
        using A3 A6 A8 sorry
    qed "sorry"
    have A11: "domRELAT-1K1 (Y -->FUNCOP-1K7 z) =XBOOLE-0R4 Y"
      using funcop_1_th_13 sorry
    have A12: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies curryFUNCT-5K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .FUNCT-1K1 x =FUNCT-1R1 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A13: "x inHIDDENR3 X"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A14: "curryFUNCT-5K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .FUNCT-1K1 x =FUNCT-1R1 f & domRELAT-1K1 f =XBOOLE-0R4 Y"and "rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z)"and A15: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies f .FUNCT-1K1 y =XBOOLE-0R4 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z).BINOP-1K1(x,y)"
        using A1 A2 funct_5_th_29 sorry
      have A16: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies f .FUNCT-1K1 y =XBOOLE-0R4 (Y -->FUNCOP-1K7 z).FUNCT-1K1 y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A17: "y inHIDDENR3 Y"
        then have A18: "f .FUNCT-1K1 y =XBOOLE-0R4 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z).BINOP-1K1(x,y)"
          using A15 sorry
        have "(Y -->FUNCOP-1K7 z).FUNCT-1K1 y =HIDDENR1 z & [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
          using A13 A17 funcop_1_th_7 zfmisc_1_th_87 sorry
        thus "f .FUNCT-1K1 y =XBOOLE-0R4 (Y -->FUNCOP-1K7 z).FUNCT-1K1 y"
          using A18 funcop_1_th_7 sorry
      qed "sorry"
      have "(X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)).FUNCT-1K1 x =FUNCT-1R1 Y -->FUNCOP-1K7 z"
        using A13 funcop_1_th_7 sorry
      thus "curryFUNCT-5K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) .FUNCT-1K1 x =FUNCT-1R1 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)).FUNCT-1K1 x"
        using A11 A14 A16 sorry
    qed "sorry"
    have "domRELAT-1K1 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) =XBOOLE-0R4 X & domRELAT-1K1 (curryFUNCT-5K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z)) =XBOOLE-0R4 X"
      using A1 A2 funcop_1_th_13 funct_5_th_24 sorry
    thus "curryFUNCT-5K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =FUNCT-1R1 X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)"
      using A12 sorry
    have "domRELAT-1K1 (Y -->FUNCOP-1K7 (X -->FUNCOP-1K7 z)) =XBOOLE-0R4 Y & domRELAT-1K1 (curry'FUNCT-5K3 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z)) =XBOOLE-0R4 Y"
      using A1 A2 funcop_1_th_13 funct_5_th_24 sorry
    thus "curry'FUNCT-5K3 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =FUNCT-1R1 Y -->FUNCOP-1K7 (X -->FUNCOP-1K7 z)"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_6:
" for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds uncurryFUNCT-5K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) =FUNCT-1R1 [:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z & uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) =FUNCT-1R1 [:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z"
proof-
  have " for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds uncurryFUNCT-5K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) =FUNCT-1R1 [:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z & uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) =FUNCT-1R1 [:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "domRELAT-1K1 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    have A2: "domRELAT-1K1 (Y -->FUNCOP-1K7 z) =XBOOLE-0R4 Y"
      using funcop_1_th_13 sorry
    have "rngFUNCT-1K2 (Y -->FUNCOP-1K7 z) c=TARSKIR1 {TARSKIK1 z}"
      using funcop_1_th_13 sorry
    then have "Y -->FUNCOP-1K7 z inTARSKIR2 FuncsFUNCT-2K9(Y,{TARSKIK1 z})"
      using A2 funct_2_def_2 sorry
    then have "rngFUNCT-1K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) c=TARSKIR1 {TARSKIK1 Y -->FUNCOP-1K7 z } & {TARSKIK1 Y -->FUNCOP-1K7 z } c=TARSKIR1 FuncsFUNCT-2K9(Y,{TARSKIK1 z})"
      using funcop_1_th_13 zfmisc_1_th_31 sorry
    then have "rngFUNCT-1K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) c=TARSKIR1 FuncsFUNCT-2K9(Y,{TARSKIK1 z})"
       sorry
    then have A3: "domRELAT-1K1 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z))) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      using A1 funct_5_th_26 sorry
    have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies uncurryFUNCT-5K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) .FUNCT-1K1 x =XBOOLE-0R4 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
      then obtain y1 g y2 where
        [ty]:"y1 be objectHIDDENM1" "g be FunctionFUNCT-1M1" "y2 be objectHIDDENM1" and 
        A6: "x =HIDDENR1 [TARSKIK4 y1,y2 ]"and A7: "y1 inHIDDENR3 X & g =FUNCT-1R1 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)).FUNCT-1K1 y1"and A8: "y2 inHIDDENR3 domRELAT-1K1 g"
        using A1 A3 funct_5_def_2 sorry
      have A9: "g =FUNCT-1R1 Y -->FUNCOP-1K7 z"
        using A7 funcop_1_th_7 sorry
      then have "(Y -->FUNCOP-1K7 z).FUNCT-1K1 y2 =HIDDENR1 z"
        using A2 A8 funcop_1_th_7 sorry
      then have "z =HIDDENR1 uncurryFUNCT-5K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) .BINOP-1K1(y1,y2)"
        using A1 A7 A8 A9 funct_5_th_38 sorry
      thus "uncurryFUNCT-5K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) .FUNCT-1K1 x =XBOOLE-0R4 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z).FUNCT-1K1 x"
        using A5 A6 funcop_1_th_7 sorry
    qed "sorry"
    have "domRELAT-1K1 ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z) =RELAT-1R1 [:ZFMISC-1K2 X,Y :]"
      using funcop_1_th_13 sorry
    thus "uncurryFUNCT-5K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) =FUNCT-1R1 [:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z"
      using A3 A4 sorry
    then have "~FUNCT-4K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z))) =FUNCT-1R1 [:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z"
      using funct_6_th_3 sorry
    thus "uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 (Y -->FUNCOP-1K7 z)) =FUNCT-1R1 [:ZFMISC-1K2 Y,X :] -->FUNCOP-1K7 z"
      using funct_5_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_7:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 f .FUNCT-1K1 x implies rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 f) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 f .FUNCT-1K1 x implies rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 f) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f & g =XBOOLE-0R4 f .FUNCT-1K1 x"
    show "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 g"
        then have " ex z be objectHIDDENM1 st z inHIDDENR3 domRELAT-1K1 g & y =HIDDENR1 g .FUNCT-1K1 z"
          using funct_1_def_3 sorry
        thus "y inHIDDENR3 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"
          using A1 funct_5_th_38 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 f)"
        using tarski_def_3 sorry
    qed
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 g"
      then have " ex z be objectHIDDENM1 st z inHIDDENR3 domRELAT-1K1 g & y =HIDDENR1 g .FUNCT-1K1 z"
        using funct_1_def_3 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
        using A1 funct_5_th_39 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_8:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds ((domRELAT-1K1 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 [:ZFMISC-1K2 X,domRELAT-1K1 f :] & rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f) & domRELAT-1K1 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,X :]) & rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds ((domRELAT-1K1 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 [:ZFMISC-1K2 X,domRELAT-1K1 f :] & rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f) & domRELAT-1K1 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,X :]) & rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "f inTARSKIR2 FuncsFUNCT-2K1(domRELAT-1K1 f,rngFUNCT-1K2 f)"
      using funct_2_def_2 sorry
    then have "rngFUNCT-1K2 (X -->FUNCOP-1K7 f) c=TARSKIR1 {TARSKIK1 f} & {TARSKIK1 f} c=TARSKIR1 FuncsFUNCT-2K1(domRELAT-1K1 f,rngFUNCT-1K2 f)"
      using funcop_1_th_13 zfmisc_1_th_31 sorry
    then have "domRELAT-1K1 (X -->FUNCOP-1K7 f) =XBOOLE-0R4 X & rngFUNCT-1K2 (X -->FUNCOP-1K7 f) c=TARSKIR1 FuncsFUNCT-2K1(domRELAT-1K1 f,rngFUNCT-1K2 f)"
      using funcop_1_th_13 sorry
    thus "((domRELAT-1K1 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 [:ZFMISC-1K2 X,domRELAT-1K1 f :] & rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f) & domRELAT-1K1 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,X :]) & rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f"
      using funct_5_th_26 funct_5_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_9:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 rngFUNCT-1K2 f & rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 rngFUNCT-1K2 f"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 rngFUNCT-1K2 f & rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    let ?x = "the ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    then have Cut342: "domRELAT-1K1 (X -->FUNCOP-1K7 f) =XBOOLE-0R4 X & (X -->FUNCOP-1K7 f).FUNCT-1K1 ?x =FUNCT-1R1 f"
      using funcop_1_th_7 funcop_1_th_13 sorry
    have "((rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f & rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f))) & rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f) & rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f))"
    proof-
      show "((rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f & rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f))) & rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) c=TARSKIR1 rngFUNCT-1K2 f) & rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f))"
        using A1 funct_6_th_7 funct_6_th_8 Cut342 sorry
    qed
    thus "rngFUNCT-1K2 (uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 rngFUNCT-1K2 f & rngFUNCT-1K2 (uncurry'FUNCT-5K4 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 rngFUNCT-1K2 f"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 & f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) implies curryFUNCT-5K1 f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) & curry'FUNCT-5K3 f inTARSKIR2 FuncsFUNCT-2K1(Y,FuncsFUNCT-2K1(X,Z))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies (f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) implies curryFUNCT-5K1 f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) & curry'FUNCT-5K3 f inTARSKIR2 FuncsFUNCT-2K1(Y,FuncsFUNCT-2K1(X,Z)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
    assume "f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)"
    then have A2: " ex g be FunctionFUNCT-1M1 st (f =FUNCT-1R1 g & domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]) & rngFUNCT-1K2 g c=TARSKIR1 Z"
      using funct_2_def_2 sorry
    then have "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f) & FuncsFUNCT-2K1(Y,rngFUNCT-1K2 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,Z)"
      using funct_5_th_35 funct_5_th_56 sorry
    then have A3: "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 FuncsFUNCT-2K1(Y,Z)"
       sorry
    have "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f) & FuncsFUNCT-2K1(X,rngFUNCT-1K2 f) c=TARSKIR1 FuncsFUNCT-2K1(X,Z)"
      using A2 funct_5_th_35 funct_5_th_56 sorry
    then have A4: "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 FuncsFUNCT-2K1(X,Z)"
       sorry
    have "domRELAT-1K1 (curryFUNCT-5K1 f) =XBOOLE-0R4 X & domRELAT-1K1 (curry'FUNCT-5K3 f) =XBOOLE-0R4 Y"
      using A1 A2 funct_5_th_24 sorry
    thus "curryFUNCT-5K1 f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) & curry'FUNCT-5K3 f inTARSKIR2 FuncsFUNCT-2K1(Y,FuncsFUNCT-2K1(X,Z))"
      using A3 A4 funct_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) implies uncurryFUNCT-5K2 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) & uncurry'FUNCT-5K4 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 Y,X :],Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) implies uncurryFUNCT-5K2 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) & uncurry'FUNCT-5K4 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 Y,X :],Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
    then have A1: " ex g be FunctionFUNCT-1M1 st (f =FUNCT-1R1 g & domRELAT-1K1 g =XBOOLE-0R4 X) & rngFUNCT-1K2 g c=TARSKIR1 FuncsFUNCT-2K1(Y,Z)"
      using funct_2_def_2 sorry
    then have A2: "domRELAT-1K1 (uncurryFUNCT-5K2 f) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & domRELAT-1K1 (uncurry'FUNCT-5K4 f) =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :]"
      using funct_5_th_26 sorry
    have "rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Z & rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 Z"
      using A1 funct_5_th_41 sorry
    thus "uncurryFUNCT-5K2 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) & uncurry'FUNCT-5K4 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 Y,X :],Z)"
      using A2 funct_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_12:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (curryFUNCT-5K1 f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) or curry'FUNCT-5K3 f inTARSKIR2 FuncsFUNCT-2K1(Y,FuncsFUNCT-2K1(X,Z))) & domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 V1,V2 :] implies f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds curryFUNCT-5K1 f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) or curry'FUNCT-5K3 f inTARSKIR2 FuncsFUNCT-2K1(Y,FuncsFUNCT-2K1(X,Z)) implies (domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 V1,V2 :] implies f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix V1 assume [ty]: "V1 be setHIDDENM2"
    fix V2 assume [ty]: "V2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "curryFUNCT-5K1 f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z)) or curry'FUNCT-5K3 f inTARSKIR2 FuncsFUNCT-2K1(Y,FuncsFUNCT-2K1(X,Z))"
    then have A1: "uncurryFUNCT-5K2 (curryFUNCT-5K1 f) inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) or uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)"
      using funct_6_th_11 sorry
    assume "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 V1,V2 :]"
    thus "f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z)"
      using A1 funct_5_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_13:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds ((uncurryFUNCT-5K2 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) or uncurry'FUNCT-5K4 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 Y,X :],Z)) & rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(V1,V2)) & domRELAT-1K1 f =XBOOLE-0R4 X implies f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (uncurryFUNCT-5K2 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) or uncurry'FUNCT-5K4 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 Y,X :],Z)) & (rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(V1,V2) & domRELAT-1K1 f =XBOOLE-0R4 X) implies f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix V1 assume [ty]: "V1 be setHIDDENM2"
    fix V2 assume [ty]: "V2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "uncurryFUNCT-5K2 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 X,Y :],Z) or uncurry'FUNCT-5K4 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 Y,X :],Z)"
      and A2: "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(V1,V2)"
      and A3: "domRELAT-1K1 f =XBOOLE-0R4 X"
    have A4: "uncurry'FUNCT-5K4 f =FUNCT-1R1 ~FUNCT-4K2 (uncurryFUNCT-5K2 f)"
      using funct_5_def_4 sorry
    have A5: "( ex g be FunctionFUNCT-1M1 st (uncurryFUNCT-5K2 f =FUNCT-1R1 g & domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]) & rngFUNCT-1K2 g c=TARSKIR1 Z) or ( ex g be FunctionFUNCT-1M1 st (uncurry'FUNCT-5K4 f =FUNCT-1R1 g & domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :]) & rngFUNCT-1K2 g c=TARSKIR1 Z)"
      using A1 funct_2_def_2 sorry
    then have A6: "domRELAT-1K1 (uncurry'FUNCT-5K4 f) =XBOOLE-0R4 [:ZFMISC-1K2 Y,X :]"
      using A4 funct_4_th_46 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(Y,Z)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 FuncsFUNCT-2K1(Y,Z)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A7: "y inHIDDENR3 rngFUNCT-1K2 f"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A8: "x inHIDDENR3 domRELAT-1K1 f"and A9: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have " ex g be FunctionFUNCT-1M1 st (y =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 V1) & rngFUNCT-1K2 g c=TARSKIR1 V2"
          using A2 A7 partfun1_def_3 sorry
        then obtain h where 
          [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = y"
           sorry
        have A10: "domRELAT-1K1 h =XBOOLE-0R4 Y"
        proof-
          have "domRELAT-1K1 h c=TARSKIR1 Y & Y c=TARSKIR1 domRELAT-1K1 h"
          proof(rule conjMI)
            show "domRELAT-1K1 h c=TARSKIR1 Y"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 h implies z inHIDDENR3 Y"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 domRELAT-1K1 h"
                then have "[TARSKIK4 z,x ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f)"
                  using A8 A9 funct_5_th_39 sorry
                thus "z inHIDDENR3 Y"
                  using A6 zfmisc_1_th_87 sorry
              qed "sorry"
              thus "domRELAT-1K1 h c=TARSKIR1 Y"
                using tarski_def_3 sorry
            qed
            have " for z be objectHIDDENM1 holds z inHIDDENR3 Y implies z inHIDDENR3 domRELAT-1K1 h"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 Y"
              then have "[TARSKIK4 z,x ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
                using A3 A8 zfmisc_1_th_87 sorry
              then have "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
                using A4 A6 funct_4_th_42 sorry
              then obtain y1 f1 y2 where
                [ty]:"y1 be objectHIDDENM1" "f1 be FunctionFUNCT-1M1" "y2 be objectHIDDENM1" and 
                A11: "[TARSKIK4 x,z ] =HIDDENR1 [TARSKIK4 y1,y2 ]"and "y1 inHIDDENR3 domRELAT-1K1 f"and A12: "f1 =XBOOLE-0R4 f .FUNCT-1K1 y1 & y2 inHIDDENR3 domRELAT-1K1 f1"
                using funct_5_def_2 sorry
              have "x =HIDDENR1 y1"
                using A11 xtuple_0_th_1 sorry
              thus "z inHIDDENR3 domRELAT-1K1 h"
                using A9 A11 A12 xtuple_0_th_1 sorry
            qed "sorry"
            thus "Y c=TARSKIR1 domRELAT-1K1 h"
              using tarski_def_3 sorry
          qed
          thus "domRELAT-1K1 h =XBOOLE-0R4 Y"
            using xboole_0_def_10 sorry
        qed
        have "rngFUNCT-1K2 h c=TARSKIR1 Z"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 h implies z inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 rngFUNCT-1K2 h"
            then have " ex y1 be objectHIDDENM1 st y1 inHIDDENR3 domRELAT-1K1 h & z =HIDDENR1 h .FUNCT-1K1 y1"
              using funct_1_def_3 sorry
            then have "z inHIDDENR3 rngFUNCT-1K2 (uncurryFUNCT-5K2 f) & z inHIDDENR3 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
              using A8 A9 funct_5_th_38 funct_5_th_39 sorry
            thus "z inHIDDENR3 Z"
              using A5 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 h c=TARSKIR1 Z"
            using tarski_def_3 sorry
        qed
        thus "y inHIDDENR3 FuncsFUNCT-2K1(Y,Z)"
          using A10 funct_2_def_2 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(Y,Z)"
        using tarski_def_3 sorry
    qed
    thus "f inTARSKIR2 FuncsFUNCT-2K1(X,FuncsFUNCT-2K1(Y,Z))"
      using A3 funct_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_14:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) implies curryFUNCT-5K1 f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z)) & curry'FUNCT-5K3 f inTARSKIR2 PFuncsPARTFUN1K4(Y,PFuncsPARTFUN1K4(X,Z))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) implies curryFUNCT-5K1 f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z)) & curry'FUNCT-5K3 f inTARSKIR2 PFuncsPARTFUN1K4(Y,PFuncsPARTFUN1K4(X,Z))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z)"
    then have A1: " ex g be FunctionFUNCT-1M1 st (f =FUNCT-1R1 g & domRELAT-1K1 g c=TARSKIR1 [:ZFMISC-1K2 X,Y :]) & rngFUNCT-1K2 g c=TARSKIR1 Z"
      using partfun1_def_3 sorry
    then have "proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 X & proj1XTUPLE-0K12 (domRELAT-1K1 f) c=TARSKIR1 proj1XTUPLE-0K12 ([:ZFMISC-1K2 X,Y :])"
      using funct_5_th_10 xtuple_0_th_8 sorry
    then have "proj1XTUPLE-0K12 (domRELAT-1K1 f) c=TARSKIR1 X"
       sorry
    then have A2: "PFuncsPARTFUN1K4(proj1XTUPLE-0K12 (domRELAT-1K1 f),rngFUNCT-1K2 f) c=TARSKIR1 PFuncsPARTFUN1K4(X,Z)"
      using A1 partfun1_th_50 sorry
    have "proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :]) c=TARSKIR1 Y & proj2XTUPLE-0K13 (domRELAT-1K1 f) c=TARSKIR1 proj2XTUPLE-0K13 ([:ZFMISC-1K2 X,Y :])"
      using A1 funct_5_th_10 xtuple_0_th_9 sorry
    then have "proj2XTUPLE-0K13 (domRELAT-1K1 f) c=TARSKIR1 Y"
       sorry
    then have "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj2XTUPLE-0K13 (domRELAT-1K1 f),rngFUNCT-1K2 f) & PFuncsPARTFUN1K4(proj2XTUPLE-0K13 (domRELAT-1K1 f),rngFUNCT-1K2 f) c=TARSKIR1 PFuncsPARTFUN1K4(Y,Z)"
      using A1 funct_5_th_36 partfun1_th_50 sorry
    then have A3: "rngFUNCT-1K2 (curryFUNCT-5K1 f) c=TARSKIR1 PFuncsPARTFUN1K4(Y,Z)"
       sorry
    have "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 PFuncsPARTFUN1K4(proj1XTUPLE-0K12 (domRELAT-1K1 f),rngFUNCT-1K2 f)"
      using funct_5_th_36 sorry
    then have A4: "rngFUNCT-1K2 (curry'FUNCT-5K3 f) c=TARSKIR1 PFuncsPARTFUN1K4(X,Z)"
      using A2 sorry
    have "domRELAT-1K1 (curryFUNCT-5K1 f) c=TARSKIR1 X & domRELAT-1K1 (curry'FUNCT-5K3 f) c=TARSKIR1 Y"
      using A1 funct_5_th_25 sorry
    thus "curryFUNCT-5K1 f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z)) & curry'FUNCT-5K3 f inTARSKIR2 PFuncsPARTFUN1K4(Y,PFuncsPARTFUN1K4(X,Z))"
      using A3 A4 partfun1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_15:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z)) implies uncurryFUNCT-5K2 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) & uncurry'FUNCT-5K4 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 Y,X :],Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z)) implies uncurryFUNCT-5K2 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) & uncurry'FUNCT-5K4 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 Y,X :],Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z))"
    then have A1: " ex g be FunctionFUNCT-1M1 st (f =FUNCT-1R1 g & domRELAT-1K1 g c=TARSKIR1 X) & rngFUNCT-1K2 g c=TARSKIR1 PFuncsPARTFUN1K4(Y,Z)"
      using partfun1_def_3 sorry
    then have "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 [:ZFMISC-1K2 domRELAT-1K1 f,Y :] & [:ZFMISC-1K2 domRELAT-1K1 f,Y :] c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
      using funct_5_th_37 zfmisc_1_th_96 sorry
    then have A2: "domRELAT-1K1 (uncurryFUNCT-5K2 f) c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
       sorry
    have "domRELAT-1K1 (uncurry'FUNCT-5K4 f) c=TARSKIR1 [:ZFMISC-1K2 Y,domRELAT-1K1 f :] & [:ZFMISC-1K2 Y,domRELAT-1K1 f :] c=RELAT-1R2 [:ZFMISC-1K2 Y,X :]"
      using A1 funct_5_th_37 zfmisc_1_th_96 sorry
    then have A3: "domRELAT-1K1 (uncurry'FUNCT-5K4 f) c=TARSKIR1 [:ZFMISC-1K2 Y,X :]"
       sorry
    have "rngFUNCT-1K2 (uncurryFUNCT-5K2 f) c=TARSKIR1 Z & rngFUNCT-1K2 (uncurry'FUNCT-5K4 f) c=TARSKIR1 Z"
      using A1 funct_5_th_40 sorry
    thus "uncurryFUNCT-5K2 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) & uncurry'FUNCT-5K4 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 Y,X :],Z)"
      using A2 A3 partfun1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (curryFUNCT-5K1 f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z)) or curry'FUNCT-5K3 f inTARSKIR2 PFuncsPARTFUN1K4(Y,PFuncsPARTFUN1K4(X,Z))) & domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 V1,V2 :] implies f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds curryFUNCT-5K1 f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z)) or curry'FUNCT-5K3 f inTARSKIR2 PFuncsPARTFUN1K4(Y,PFuncsPARTFUN1K4(X,Z)) implies (domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 V1,V2 :] implies f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix V1 assume [ty]: "V1 be setHIDDENM2"
    fix V2 assume [ty]: "V2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "curryFUNCT-5K1 f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z)) or curry'FUNCT-5K3 f inTARSKIR2 PFuncsPARTFUN1K4(Y,PFuncsPARTFUN1K4(X,Z))"
    then have A1: "uncurryFUNCT-5K2 (curryFUNCT-5K1 f) inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) or uncurry'FUNCT-5K4 (curry'FUNCT-5K3 f) inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z)"
      using funct_6_th_15 sorry
    assume "domRELAT-1K1 f c=TARSKIR1 [:ZFMISC-1K2 V1,V2 :]"
    thus "f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z)"
      using A1 funct_5_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_17:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds ((uncurryFUNCT-5K2 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) or uncurry'FUNCT-5K4 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 Y,X :],Z)) & rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(V1,V2)) & domRELAT-1K1 f c=TARSKIR1 X implies f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V1 be setHIDDENM2 holds  for V2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (uncurryFUNCT-5K2 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) or uncurry'FUNCT-5K4 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 Y,X :],Z)) & (rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(V1,V2) & domRELAT-1K1 f c=TARSKIR1 X) implies f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix V1 assume [ty]: "V1 be setHIDDENM2"
    fix V2 assume [ty]: "V2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "uncurryFUNCT-5K2 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 X,Y :],Z) or uncurry'FUNCT-5K4 f inTARSKIR2 PFuncsPARTFUN1K4([:ZFMISC-1K2 Y,X :],Z)"
      and A2: "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(V1,V2)"
      and A3: "domRELAT-1K1 f c=TARSKIR1 X"
    have A4: "( ex g be FunctionFUNCT-1M1 st (uncurryFUNCT-5K2 f =FUNCT-1R1 g & domRELAT-1K1 g c=TARSKIR1 [:ZFMISC-1K2 X,Y :]) & rngFUNCT-1K2 g c=TARSKIR1 Z) or ( ex g be FunctionFUNCT-1M1 st (uncurry'FUNCT-5K4 f =FUNCT-1R1 g & domRELAT-1K1 g c=TARSKIR1 [:ZFMISC-1K2 Y,X :]) & rngFUNCT-1K2 g c=TARSKIR1 Z)"
      using A1 partfun1_def_3 sorry
    have "uncurry'FUNCT-5K4 f =FUNCT-1R1 ~FUNCT-4K2 (uncurryFUNCT-5K2 f)"
      using funct_5_def_4 sorry
    then have A5: "domRELAT-1K1 (uncurry'FUNCT-5K4 f) c=TARSKIR1 [:ZFMISC-1K2 Y,X :]"
      using A4 funct_4_th_45 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(Y,Z)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 PFuncsPARTFUN1K4(Y,Z)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A6: "y inHIDDENR3 rngFUNCT-1K2 f"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A7: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have " ex g be FunctionFUNCT-1M1 st (y =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 V1) & rngFUNCT-1K2 g c=TARSKIR1 V2"
          using A2 A6 partfun1_def_3 sorry
        then obtain h where 
          [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = y"
           sorry
        have A8: "rngFUNCT-1K2 h c=TARSKIR1 Z"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 h implies z inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 rngFUNCT-1K2 h"
            then have " ex y1 be objectHIDDENM1 st y1 inHIDDENR3 domRELAT-1K1 h & z =HIDDENR1 h .FUNCT-1K1 y1"
              using funct_1_def_3 sorry
            then have "z inHIDDENR3 rngFUNCT-1K2 (uncurryFUNCT-5K2 f) & z inHIDDENR3 rngFUNCT-1K2 (uncurry'FUNCT-5K4 f)"
              using A7 funct_5_th_38 funct_5_th_39 sorry
            thus "z inHIDDENR3 Z"
              using A4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 h c=TARSKIR1 Z"
            using tarski_def_3 sorry
        qed
        have "domRELAT-1K1 h c=TARSKIR1 Y"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 h implies z inHIDDENR3 Y"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 domRELAT-1K1 h"
            then have "[TARSKIK4 z,x ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f)"
              using A7 funct_5_th_39 sorry
            thus "z inHIDDENR3 Y"
              using A5 zfmisc_1_th_87 sorry
          qed "sorry"
          thus "domRELAT-1K1 h c=TARSKIR1 Y"
            using tarski_def_3 sorry
        qed
        thus "y inHIDDENR3 PFuncsPARTFUN1K4(Y,Z)"
          using A8 partfun1_def_3 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(Y,Z)"
        using tarski_def_3 sorry
    qed
    thus "f inTARSKIR2 PFuncsPARTFUN1K4(X,PFuncsPARTFUN1K4(Y,Z))"
      using A3 partfun1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
(*\$CD*)
(*\$CT 4*)
mdef funct_6_def_2 ("domsFUNCT-6K1  _ " [228]228 ) where
  mlet "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
"func domsFUNCT-6K1 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x))"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x)))))"
      proof-
        let ?F = "\<lambda>Lamb1. proj1XTUPLE-0K12 (f .FUNCT-1K1 Lamb1)"
        have " ex F be FunctionFUNCT-1M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies F .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x)))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it1 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it2 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x)) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f2 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x)))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x)"
          and A3: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f2 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 f"
          then have "f1 .FUNCT-1K1 x =XBOOLE-0R4 proj1XTUPLE-0K12 (f .FUNCT-1K1 x)"
            using A2 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A4 A5 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef funct_6_def_3 ("rngsFUNCT-6K2  _ " [228]228 ) where
  mlet "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
"func rngsFUNCT-6K2 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x))"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x)))))"
      proof-
        let ?F = "\<lambda>Lamb1. proj2XTUPLE-0K13 (f .FUNCT-1K1 Lamb1)"
        have " ex F be FunctionFUNCT-1M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies F .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x)))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it1 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it2 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x)) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f2 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x)))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A6: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x)"
          and A8: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f2 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A10: "x inHIDDENR3 domRELAT-1K1 f"
          then have "f1 .FUNCT-1K1 x =XBOOLE-0R4 proj2XTUPLE-0K13 (f .FUNCT-1K1 x)"
            using A7 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A9 A10 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A6 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef funct_6_def_4 ("meetFUNCT-6K3  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func meetFUNCT-6K3 f \<rightarrow> setHIDDENM2 equals
  meetSETFAM-1K1 (rngFUNCT-1K2 f)"
proof-
  (*coherence*)
    show "meetSETFAM-1K1 (rngFUNCT-1K2 f) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funct_6_th_22:
" for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 x implies ((x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) & domsFUNCT-6K1 f .FUNCT-1K1 x =XBOOLE-0R4 domRELAT-1K1 g) & x inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f)) & rngsFUNCT-6K2 f .FUNCT-1K1 x =XBOOLE-0R4 rngFUNCT-1K2 g"
  using funct_6_def_2 funct_6_def_3 sorry

mtheorem funct_6_th_23:
"domsFUNCT-6K1 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1 & rngsFUNCT-6K2 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
  using funct_6_def_2 funct_6_def_3 relat_1_th_38 sorry

mtheorem funct_6_th_24:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domsFUNCT-6K1 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 domRELAT-1K1 f & rngsFUNCT-6K2 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 rngFUNCT-1K2 f"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domsFUNCT-6K1 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 domRELAT-1K1 f & rngsFUNCT-6K2 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (X -->FUNCOP-1K7 domRELAT-1K1 f) =XBOOLE-0R4 X & domRELAT-1K1 (domsFUNCT-6K1 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 domRELAT-1K1 (X -->FUNCOP-1K7 f)"
      using funct_6_def_2 funcop_1_th_13 sorry
    have A2: "domRELAT-1K1 (X -->FUNCOP-1K7 f) =XBOOLE-0R4 X & (X -->FUNCOP-1K7 f)\<inverse>FUNCT-1K6 (rngFUNCT-1K2 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 domRELAT-1K1 (X -->FUNCOP-1K7 f)"
      using funcop_1_th_13 relat_1_th_134 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies domsFUNCT-6K1 (X -->FUNCOP-1K7 f) .FUNCT-1K1 x =XBOOLE-0R4 (X -->FUNCOP-1K7 domRELAT-1K1 f).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 X"
      then have "(X -->FUNCOP-1K7 f).FUNCT-1K1 x =FUNCT-1R1 f & (X -->FUNCOP-1K7 domRELAT-1K1 f).FUNCT-1K1 x =XBOOLE-0R4 domRELAT-1K1 f"
        using funcop_1_th_7 sorry
      thus "domsFUNCT-6K1 (X -->FUNCOP-1K7 f) .FUNCT-1K1 x =XBOOLE-0R4 (X -->FUNCOP-1K7 domRELAT-1K1 f).FUNCT-1K1 x"
        using A2 A3 funct_6_def_2 sorry
    qed "sorry"
    thus "domsFUNCT-6K1 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 domRELAT-1K1 f"
      using A1 A2 sorry
    have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies rngsFUNCT-6K2 (X -->FUNCOP-1K7 f) .FUNCT-1K1 x =XBOOLE-0R4 (X -->FUNCOP-1K7 rngFUNCT-1K2 f).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 X"
      then have "(X -->FUNCOP-1K7 f).FUNCT-1K1 x =FUNCT-1R1 f & (X -->FUNCOP-1K7 rngFUNCT-1K2 f).FUNCT-1K1 x =XBOOLE-0R4 rngFUNCT-1K2 f"
        using funcop_1_th_7 sorry
      thus "rngsFUNCT-6K2 (X -->FUNCOP-1K7 f) .FUNCT-1K1 x =XBOOLE-0R4 (X -->FUNCOP-1K7 rngFUNCT-1K2 f).FUNCT-1K1 x"
        using A2 A5 funct_6_def_3 sorry
    qed "sorry"
    have "domRELAT-1K1 (X -->FUNCOP-1K7 rngFUNCT-1K2 f) =XBOOLE-0R4 X & domRELAT-1K1 (rngsFUNCT-6K2 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 domRELAT-1K1 (X -->FUNCOP-1K7 f)"
      using funct_6_def_3 funcop_1_th_13 sorry
    thus "rngsFUNCT-6K2 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 rngFUNCT-1K2 f"
      using A2 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_25:
" for f be FunctionFUNCT-1M1 holds f <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 meetFUNCT-6K3 f iff ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 f .FUNCT-1K1 y))"
proof-
  have " for f be FunctionFUNCT-1M1 holds f <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be objectHIDDENM1 holds (x inHIDDENR3 meetFUNCT-6K3 f implies ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 f .FUNCT-1K1 y)) & (( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 f .FUNCT-1K1 y) implies x inHIDDENR3 meetFUNCT-6K3 f))"
  proof(rule ballI,rule impI,rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f <>HIDDENR2 {}XBOOLE-0K1"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 meetFUNCT-6K3 f implies ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 f .FUNCT-1K1 y)"
    proof(rule impI,rule ballI,rule impI)
      assume A2: "x inHIDDENR3 meetFUNCT-6K3 f"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 domRELAT-1K1 f"
      then have "f .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 f"
        using funct_1_def_3 sorry
      then have "meetFUNCT-6K3 f c=TARSKIR1 f .FUNCT-1K1 y"
        using setfam_1_th_3 sorry
      thus "x inHIDDENR3 f .FUNCT-1K1 y"
        using A2 sorry
    qed "sorry"
    assume A3: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 f .FUNCT-1K1 y"
    have " for z be setHIDDENM2 holds z inTARSKIR2 rngFUNCT-1K2 f implies x inHIDDENR3 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be setHIDDENM2"
      assume "z inTARSKIR2 rngFUNCT-1K2 f"
      then have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 f & z =XBOOLE-0R4 f .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      thus "x inHIDDENR3 z"
        using A3 sorry
    qed "sorry"
    thus "x inHIDDENR3 meetFUNCT-6K3 f"
      using A1 setfam_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_26:
" for Y be setHIDDENM2 holds UnionCARD-3K3 ({}XBOOLE-0K1 -->FUNCOP-1K7 Y) =XBOOLE-0R4 {}XBOOLE-0K1 & meetFUNCT-6K3 ({}XBOOLE-0K1 -->FUNCOP-1K7 Y) =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for Y be setHIDDENM2 holds UnionCARD-3K3 ({}XBOOLE-0K1 -->FUNCOP-1K7 Y) =XBOOLE-0R4 {}XBOOLE-0K1 & meetFUNCT-6K3 ({}XBOOLE-0K1 -->FUNCOP-1K7 Y) =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "unionTARSKIK3 (rngFUNCT-1K2 ({}XBOOLE-0K1 -->FUNCOP-1K7 Y)) =XBOOLE-0R4 {}XBOOLE-0K1"
      using zfmisc_1_th_2 sorry
    thus "UnionCARD-3K3 ({}XBOOLE-0K1 -->FUNCOP-1K7 Y) =XBOOLE-0R4 {}XBOOLE-0K1 & meetFUNCT-6K3 ({}XBOOLE-0K1 -->FUNCOP-1K7 Y) =XBOOLE-0R4 {}XBOOLE-0K1"
      using card_3_def_4 setfam_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_27:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies UnionCARD-3K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y & meetFUNCT-6K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies UnionCARD-3K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y & meetFUNCT-6K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "rngFUNCT-1K2 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 {TARSKIK1 Y}"
      using funcop_1_th_8 sorry
    then have "unionTARSKIK3 (rngFUNCT-1K2 (X -->FUNCOP-1K7 Y)) =XBOOLE-0R4 Y"
      using zfmisc_1_th_25 sorry
    thus "UnionCARD-3K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y & meetFUNCT-6K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y"
      using A1 card_3_def_4 setfam_1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_6_def_5 (" _ ..FUNCT-6K4'( _ , _ ')" [200,0,0]200 ) where
  mlet "f be FunctionFUNCT-1M1", "x be objectHIDDENM1", "y be objectHIDDENM1"
"func f ..FUNCT-6K4(x,y) \<rightarrow> setHIDDENM2 equals
  uncurryFUNCT-5K2 f .BINOP-1K1(x,y)"
proof-
  (*coherence*)
    show "uncurryFUNCT-5K2 f .BINOP-1K1(x,y) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funct_6_th_28:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 X & y inHIDDENR3 domRELAT-1K1 f implies (X -->FUNCOP-1K7 f)..FUNCT-6K4(x,y) =XBOOLE-0R4 f .FUNCT-1K1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 domRELAT-1K1 f) &  not (X -->FUNCOP-1K7 f)..FUNCT-6K4(x,y) =XBOOLE-0R4 f .FUNCT-1K1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "x inHIDDENR3 X implies (X -->FUNCOP-1K7 f).FUNCT-1K1 x =FUNCT-1R1 f"
      using funcop_1_th_7 sorry
    have "domRELAT-1K1 (X -->FUNCOP-1K7 f) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    thus " not ((x inHIDDENR3 X & y inHIDDENR3 domRELAT-1K1 f) &  not (X -->FUNCOP-1K7 f)..FUNCT-6K4(x,y) =XBOOLE-0R4 f .FUNCT-1K1 y)"
      using A1 funct_5_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef funct_6_def_6 ("<:FUNCT-6K5  _ :>" [0]164 ) where
  mlet "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
"func <:FUNCT-6K5 f:> \<rightarrow> FunctionFUNCT-1M1 equals
  curryFUNCT-5K1 (uncurry'FUNCT-5K4 f  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :]))"
proof-
  (*coherence*)
    show "curryFUNCT-5K1 (uncurry'FUNCT-5K4 f  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :])) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem funct_6_th_29:
" for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (<:FUNCT-6K5 f:>) =XBOOLE-0R4 meetFUNCT-6K3 (domsFUNCT-6K1 f) & rngFUNCT-1K2 (<:FUNCT-6K5 f:>) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f)"
proof(rule ballI)
  fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
  let ?f9 = "uncurry'FUNCT-5K4 f  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :])"
  have Cut733: "domRELAT-1K1 (uncurry'FUNCT-5K4 f  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :])) c=TARSKIR1 [:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :]"
    using relat_1_th_58 sorry
  have "domRELAT-1K1 (<:FUNCT-6K5 f:>) c=TARSKIR1 meetFUNCT-6K3 (domsFUNCT-6K1 f) & (meetFUNCT-6K3 (domsFUNCT-6K1 f) c=TARSKIR1 domRELAT-1K1 (<:FUNCT-6K5 f:>) & rngFUNCT-1K2 (<:FUNCT-6K5 f:>) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f))"
  proof(rule conjMI,rule conjMI)
    show A1: "domRELAT-1K1 (<:FUNCT-6K5 f:>) c=TARSKIR1 meetFUNCT-6K3 (domsFUNCT-6K1 f)"
      using funct_5_th_25 Cut733 sorry
    have A2: "domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_2 sorry
    show "meetFUNCT-6K3 (domsFUNCT-6K1 f) c=TARSKIR1 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
    proof-
      let ?y = "the ElementSUBSET-1M1-of rngFUNCT-1K2 (domsFUNCT-6K1 f)"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 meetFUNCT-6K3 (domsFUNCT-6K1 f) implies x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 meetFUNCT-6K3 (domsFUNCT-6K1 f)"
        then have A4: "rngFUNCT-1K2 (domsFUNCT-6K1 f) <>HIDDENR2 {}XBOOLE-0K1"
          using setfam_1_def_1 sorry
        then have A5: "x inHIDDENR3 ?y"
          using A3 setfam_1_def_1 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A6: "z inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f)"and A7: "?y =XBOOLE-0R4 domsFUNCT-6K1 f .FUNCT-1K1 z"
          using A4 funct_1_def_3 sorry
        obtain g where 
          [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = f .FUNCT-1K1 z"
           sorry
        have A8: "z inHIDDENR3 domRELAT-1K1 f"
          using A2 A6 sorry
        then have "?y =XBOOLE-0R4 domRELAT-1K1 g"
          using A7 funct_6_th_22 sorry
        then have A9: "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f)"
          using A8 A5 funct_5_th_39 sorry
        have "[TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :]"
          using A3 A8 zfmisc_1_th_87 sorry
        then have "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :])"
          using A9 xboole_0_def_4 sorry
        then have "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :]))"
          using relat_1_th_61 sorry
        then have "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 (uncurry'FUNCT-5K4 f  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :])))"
          using xtuple_0_def_12 sorry
        thus "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
          using funct_5_def_1 sorry
      qed "sorry"
      thus "meetFUNCT-6K3 (domsFUNCT-6K1 f) c=TARSKIR1 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
        using tarski_def_3 sorry
    qed
    have A10: "domRELAT-1K1 (rngsFUNCT-6K2 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_3 sorry
    show "rngFUNCT-1K2 (<:FUNCT-6K5 f:>) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (<:FUNCT-6K5 f:>) implies y inHIDDENR3 productCARD-3K4 (rngsFUNCT-6K2 f)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        have A11: "domRELAT-1K1 ?f9 =XBOOLE-0R4 domRELAT-1K1 (uncurry'FUNCT-5K4 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :])"
          using relat_1_th_61 sorry
        have A12: "uncurry'FUNCT-5K4 f =FUNCT-1R1 ~FUNCT-4K2 (uncurryFUNCT-5K2 f)"
          using funct_5_def_4 sorry
        assume "y inHIDDENR3 rngFUNCT-1K2 (<:FUNCT-6K5 f:>)"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A13: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"and A14: "y =HIDDENR1 (<:FUNCT-6K5 f:>).FUNCT-1K1 x"
          using funct_1_def_3 sorry
        obtain g where 
          [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = y"
          using A14 sorry
        have A15: "domRELAT-1K1 g =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 ?f9 /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 ?f9) :]))"
          using A13 A14 funct_5_th_31 sorry
        have A16: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (rngsFUNCT-6K2 f)"
        proof-
          have "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 (rngsFUNCT-6K2 f) & domRELAT-1K1 (rngsFUNCT-6K2 f) c=TARSKIR1 domRELAT-1K1 g"
          proof(rule conjMI)
            show "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 (rngsFUNCT-6K2 f)"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 g implies z inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f)"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 domRELAT-1K1 g"
                then have "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 ?f9"
                  using A13 A14 funct_5_th_31 sorry
                then have "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f)"
                  using A11 xboole_0_def_4 sorry
                then have "[TARSKIK4 z,x ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
                  using A12 funct_4_th_42 sorry
                then obtain y1 h y2 where
                  [ty]:"y1 be objectHIDDENM1" "h be FunctionFUNCT-1M1" "y2 be objectHIDDENM1" and 
                  A17: "[TARSKIK4 z,x ] =HIDDENR1 [TARSKIK4 y1,y2 ]"and A18: "y1 inHIDDENR3 domRELAT-1K1 f"and "h =FUNCT-1R1 f .FUNCT-1K1 y1"and "y2 inHIDDENR3 domRELAT-1K1 h"
                  using funct_5_def_2 sorry
                have A19: "z =HIDDENR1 y1"
                  using A17 xtuple_0_th_1 sorry
                show "z inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f)"
                  using A10 A18 A19 sorry
              qed "sorry"
              thus "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 (rngsFUNCT-6K2 f)"
                using tarski_def_3 sorry
            qed
            have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f) implies z inHIDDENR3 domRELAT-1K1 g"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              have A20: "x inHIDDENR3 {TARSKIK1 x}"
                using tarski_def_1 sorry
              assume A21: "z inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f)"
              obtain h where 
                [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = f .FUNCT-1K1 z"
                 sorry
              have A22: "z inHIDDENR3 domRELAT-1K1 f"
                using A10 A21 sorry
              then have "domRELAT-1K1 h =XBOOLE-0R4 domsFUNCT-6K1 f .FUNCT-1K1 z"
                using funct_6_th_22 sorry
              then have "domRELAT-1K1 h inTARSKIR2 rngFUNCT-1K2 (domsFUNCT-6K1 f)"
                using A2 A10 A21 funct_1_def_3 sorry
              then have "x inHIDDENR3 domRELAT-1K1 h"
                using A1 A13 setfam_1_def_1 sorry
              then have "[TARSKIK4 z,x ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f)"
                using A22 funct_5_def_2 sorry
              then have A23: "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f)"
                using A12 funct_4_th_42 sorry
              have "[TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :]"
                using A1 A13 A22 zfmisc_1_th_87 sorry
              then have A24: "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 ?f9"
                using A11 A23 xboole_0_def_4 sorry
              then have "z inHIDDENR3 proj2XTUPLE-0K13 (domRELAT-1K1 ?f9)"
                using xtuple_0_def_13 sorry
              then have "[TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 ?f9) :]"
                using A20 zfmisc_1_th_87 sorry
              then have "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 ?f9 /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 ?f9) :])"
                using A24 xboole_0_def_4 sorry
              thus "z inHIDDENR3 domRELAT-1K1 g"
                using A15 xtuple_0_def_13 sorry
            qed "sorry"
            thus "domRELAT-1K1 (rngsFUNCT-6K2 f) c=TARSKIR1 domRELAT-1K1 g"
              using tarski_def_3 sorry
          qed
          thus "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (rngsFUNCT-6K2 f)"
            using xboole_0_def_10 sorry
        qed
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f) implies g .FUNCT-1K1 z inTARSKIR2 rngsFUNCT-6K2 f .FUNCT-1K1 z"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A25: "z inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f)"
          obtain h where 
            [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = f .FUNCT-1K1 z"
             sorry
          have A26: "z inHIDDENR3 domRELAT-1K1 f"
            using A10 A25 sorry
          then have "domRELAT-1K1 h =XBOOLE-0R4 domsFUNCT-6K1 f .FUNCT-1K1 z"
            using funct_6_th_22 sorry
          then have "domRELAT-1K1 h inTARSKIR2 rngFUNCT-1K2 (domsFUNCT-6K1 f)"
            using A2 A10 A25 funct_1_def_3 sorry
          then have A27: "x inHIDDENR3 domRELAT-1K1 h"
            using A1 A13 setfam_1_def_1 sorry
          then have A28: "h .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 h"
            using funct_1_def_3 sorry
          have "g .FUNCT-1K1 z =XBOOLE-0R4 ?f9 .BINOP-1K1(x,z) & [TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 ?f9"
            using A13 A14 A16 A25 funct_5_th_31 sorry
          then have "uncurry'FUNCT-5K4 f .BINOP-1K1(x,z) =XBOOLE-0R4 g .FUNCT-1K1 z"
            using funct_1_th_47 sorry
          then have "g .FUNCT-1K1 z =XBOOLE-0R4 h .FUNCT-1K1 x"
            using A26 A27 funct_5_th_39 sorry
          thus "g .FUNCT-1K1 z inTARSKIR2 rngsFUNCT-6K2 f .FUNCT-1K1 z"
            using A26 A28 funct_6_th_22 sorry
        qed "sorry"
        thus "y inHIDDENR3 productCARD-3K4 (rngsFUNCT-6K2 f)"
          using A16 card_3_def_5 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (<:FUNCT-6K5 f:>) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f)"
        using tarski_def_3 sorry
    qed
  qed
  thus "domRELAT-1K1 (<:FUNCT-6K5 f:>) =XBOOLE-0R4 meetFUNCT-6K3 (domsFUNCT-6K1 f) & rngFUNCT-1K2 (<:FUNCT-6K5 f:>) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f)"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem funct_6_cl_1:
  mlet "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
"cluster <:FUNCT-6K5 f:> as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "<:FUNCT-6K5 f:> be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

(*\$CT*)
mtheorem funct_6_th_31:
" for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>) & g =FUNCT-1R1 (<:FUNCT-6K5 f:>).FUNCT-1K1 x implies domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) & g .FUNCT-1K1 y =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(y,x))"
proof-
  have " for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>) & g =FUNCT-1R1 (<:FUNCT-6K5 f:>).FUNCT-1K1 x implies domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) & g .FUNCT-1K1 y =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(y,x))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
    have A1: "rngFUNCT-1K2 (<:FUNCT-6K5 f:>) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f) & domRELAT-1K1 (rngsFUNCT-6K2 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_3 funct_6_th_29 sorry
    assume A2: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>) & g =FUNCT-1R1 (<:FUNCT-6K5 f:>).FUNCT-1K1 x"
    then have "g inTARSKIR2 rngFUNCT-1K2 (<:FUNCT-6K5 f:>)"
      using funct_1_def_3 sorry
    thus "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 card_3_th_9 sorry
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A3: "y inHIDDENR3 domRELAT-1K1 g"
    have A4: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :]))"
      using A2 A3 funct_5_th_31 sorry
    then have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f) /\\XBOOLE-0K3 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :])"
      using relat_1_th_61 sorry
    then have A5: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 f)"
      using xboole_0_def_4 sorry
    have "g .FUNCT-1K1 y =XBOOLE-0R4 (uncurry'FUNCT-5K4 f  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 f),domRELAT-1K1 f :])).BINOP-1K1(x,y)"
      using A2 A3 funct_5_th_31 sorry
    then have A6: "g .FUNCT-1K1 y =XBOOLE-0R4 uncurry'FUNCT-5K4 f .BINOP-1K1(x,y)"
      using A4 funct_1_th_47 sorry
    have "~FUNCT-4K2 (uncurryFUNCT-5K2 f) =FUNCT-1R1 uncurry'FUNCT-5K4 f"
      using funct_5_def_4 sorry
    thus "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 f) & g .FUNCT-1K1 y =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(y,x)"
      using A6 A5 funct_4_th_42 funct_4_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_32:
" for x be objectHIDDENM1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>) implies ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies x inHIDDENR3 domRELAT-1K1 g)"
proof-
  have " for x be objectHIDDENM1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>) implies ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies x inHIDDENR3 domRELAT-1K1 g)"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "g inTARSKIR2 rngFUNCT-1K2 f"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A2: "y inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 y"
      using funct_1_def_3 sorry
    have "y inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) & domsFUNCT-6K1 f .FUNCT-1K1 y =XBOOLE-0R4 domRELAT-1K1 g"
      using A2 funct_6_th_22 sorry
    then have "domRELAT-1K1 g inTARSKIR2 rngFUNCT-1K2 (domsFUNCT-6K1 f)"
      using funct_1_def_3 sorry
    then have A3: "meetSETFAM-1K1 (rngFUNCT-1K2 (domsFUNCT-6K1 f)) c=TARSKIR1 domRELAT-1K1 g"
      using setfam_1_th_3 sorry
    have "meetFUNCT-6K3 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
      using funct_6_th_29 sorry
    thus "x inHIDDENR3 domRELAT-1K1 g"
      using A1 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_33:
" for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies x inHIDDENR3 domRELAT-1K1 g) implies x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
proof-
  have " for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies x inHIDDENR3 domRELAT-1K1 g) implies x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
    assume A1: "g inTARSKIR2 rngFUNCT-1K2 f"
      and A2: " for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies x inHIDDENR3 domRELAT-1K1 g"
    have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 y"
      using A1 funct_1_def_3 sorry
    then have A3: "domsFUNCT-6K1 f <>HIDDENR2 {}XBOOLE-0K1"
      using funct_6_th_22 sorry
    have A4: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies x inHIDDENR3 domsFUNCT-6K1 f .FUNCT-1K1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f)"
      then have A5: "y inHIDDENR3 domRELAT-1K1 f"
        using funct_6_def_2 sorry
      obtain g where 
        [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = f .FUNCT-1K1 y"
         sorry
      have A6: "y inHIDDENR3 domRELAT-1K1 f"
        using A5 sorry
      then have "g inTARSKIR2 rngFUNCT-1K2 f"
        using funct_1_def_3 sorry
      then have "x inHIDDENR3 domRELAT-1K1 g"
        using A2 sorry
      thus "x inHIDDENR3 domsFUNCT-6K1 f .FUNCT-1K1 y"
        using A6 funct_6_th_22 sorry
    qed "sorry"
    have "domRELAT-1K1 (<:FUNCT-6K5 f:>) =XBOOLE-0R4 meetFUNCT-6K3 (domsFUNCT-6K1 f)"
      using funct_6_th_29 sorry
    thus "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
      using A3 A4 funct_6_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_34:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds ((x inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 x) & y inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)) & h =FUNCT-1R1 (<:FUNCT-6K5 f:>).FUNCT-1K1 y implies g .FUNCT-1K1 y =XBOOLE-0R4 h .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 x) & (y inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>) & h =FUNCT-1R1 (<:FUNCT-6K5 f:>).FUNCT-1K1 y) implies g .FUNCT-1K1 y =XBOOLE-0R4 h .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 x"
      and A2: "y inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
      and A3: "h =FUNCT-1R1 (<:FUNCT-6K5 f:>).FUNCT-1K1 y"
    have "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
      using A2 A3 funct_6_th_31 sorry
    then have "x inHIDDENR3 domRELAT-1K1 h"
      using A1 sorry
    then have A4: "h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,y)"
      using A2 A3 funct_6_th_31 sorry
    have "g inTARSKIR2 rngFUNCT-1K2 f"
      using A1 funct_1_def_3 sorry
    then have "y inHIDDENR3 domRELAT-1K1 g"
      using A2 funct_6_th_32 sorry
    thus "g .FUNCT-1K1 y =XBOOLE-0R4 h .FUNCT-1K1 x"
      using A1 A4 funct_5_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_35:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x be FunctionFUNCT-1M1) & y inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>) implies f ..FUNCT-6K4(x,y) =XBOOLE-0R4 (<:FUNCT-6K5 f:>)..FUNCT-6K4(y,x)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & (f .FUNCT-1K1 x be FunctionFUNCT-1M1 & y inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)) implies f ..FUNCT-6K4(x,y) =HIDDENR1 (<:FUNCT-6K5 f:>)..FUNCT-6K4(y,x)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
      and "f .FUNCT-1K1 x be FunctionFUNCT-1M1"
      and A2: "y inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 f:>)"
    obtain g h where 
      [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = f .FUNCT-1K1 x" and
      [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = (<:FUNCT-6K5 f:>).FUNCT-1K1 y"
       sorry
    have A3: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
      using A2 funct_6_th_31 sorry
    have A4: "g inTARSKIR2 rngFUNCT-1K2 f"
      using A1 funct_1_def_3 sorry
    have A5: "x inHIDDENR3 domRELAT-1K1 h"
      using A1 A3 sorry
    have "y inHIDDENR3 domRELAT-1K1 g"
      using A2 A4 funct_6_th_32 sorry
    then have "f ..FUNCT-6K4(x,y) =HIDDENR1 g .FUNCT-1K1 y"
      using A1 funct_5_th_38 sorry
    also have "... = h .FUNCT-1K1 x"
      using A1 A2 funct_6_th_34 sorry
    also have "... = (<:FUNCT-6K5 f:>)..FUNCT-6K4(y,x)"
      using A2 A5 funct_5_th_38 sorry
    finally show "f ..FUNCT-6K4(x,y) =HIDDENR1 (<:FUNCT-6K5 f:>)..FUNCT-6K4(y,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_6_def_7 ("FregeFUNCT-6K6  _ " [164]164 ) where
  mlet "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
"func FregeFUNCT-6K6 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex h be FunctionFUNCT-1M1 st (it .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x))))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex h be FunctionFUNCT-1M1 st (it .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x))))"
    proof-
      have " ex tVar4 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar4 =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies  not ( for h be FunctionFUNCT-1M1 holds  not ((tVar4 .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 h &  not h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x))))))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st  ex h be FunctionFUNCT-1M1 st ((Lamb1 =HIDDENR1 g & Lamb2 =HIDDENR1 h) & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,g .FUNCT-1K1 z))"
        have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex y be objectHIDDENM1 st ?P(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex tVar1 be objectHIDDENM1 st  ex tVar2 be FunctionFUNCT-1M1 st  ex tVar3 be FunctionFUNCT-1M1 st ((x =HIDDENR1 tVar2 & tVar1 =HIDDENR1 tVar3) & domRELAT-1K1 tVar3 =XBOOLE-0R4 domRELAT-1K1 f) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 domRELAT-1K1 tVar3 &  not tVar3 .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,tVar2 .FUNCT-1K1 z))))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 productCARD-3K4 (domsFUNCT-6K1 f)"
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A2: "x =HIDDENR1 g"and "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (domsFUNCT-6K1 f)"and " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies g .FUNCT-1K1 x inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 x"
              using card_3_def_5 sorry
            let ?F = "\<lambda>Lamb1. uncurryFUNCT-5K2 f .FUNCT-1K1 [TARSKIK4 Lamb1,g .FUNCT-1K1 Lamb1 ]"
            obtain h where
              [ty]:"h be FunctionFUNCT-1M1" and 
              A3: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies h .FUNCT-1K1 z =XBOOLE-0R4 ?F(z))"
              using funct_1_sch_3 sorry
            obtain y where 
              [ty]:"y be setHIDDENM2" and yDef:"y = h"
               sorry
            show " ex tVar1 be objectHIDDENM1 st  ex tVar2 be FunctionFUNCT-1M1 st  ex tVar3 be FunctionFUNCT-1M1 st ((x =HIDDENR1 tVar2 & tVar1 =HIDDENR1 tVar3) & domRELAT-1K1 tVar3 =XBOOLE-0R4 domRELAT-1K1 f) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 domRELAT-1K1 tVar3 &  not tVar3 .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,tVar2 .FUNCT-1K1 z)))"
            proof(rule bexI[of _ "y"])
              show " ex tVar2 be FunctionFUNCT-1M1 st  ex tVar3 be FunctionFUNCT-1M1 st ((x =HIDDENR1 tVar2 & y =HIDDENR1 tVar3) & domRELAT-1K1 tVar3 =XBOOLE-0R4 domRELAT-1K1 f) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 domRELAT-1K1 tVar3 &  not tVar3 .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,tVar2 .FUNCT-1K1 z)))"
              proof(rule bexI[of _ "g"])
                show " ex tVar3 be FunctionFUNCT-1M1 st ((x =HIDDENR1 g & y =HIDDENR1 tVar3) & domRELAT-1K1 tVar3 =XBOOLE-0R4 domRELAT-1K1 f) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 domRELAT-1K1 tVar3 &  not tVar3 .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,g .FUNCT-1K1 z)))"
                proof(rule bexI[of _ "h"])
                  show "((x =HIDDENR1 g & y =HIDDENR1 h) & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 domRELAT-1K1 h &  not h .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,g .FUNCT-1K1 z)))"
                    using A2 A3 sorry
                qed "sorry"
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain F where
          [ty]:"F be FunctionFUNCT-1M1" and 
          A4: "domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (domsFUNCT-6K1 f) implies ?P(x,F .FUNCT-1K1 x))"
          using classes1_sch_1 A1 sorry
        show " ex tVar4 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar4 =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies  not ( for h be FunctionFUNCT-1M1 holds  not ((tVar4 .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 h &  not h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x))))))"
        proof(rule bexI[of _ "F"],rule conjMI,rule ballI,rule impI)
          show "domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f)"
            using A4 sorry
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume "g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f)"
          then have " ex g1 be FunctionFUNCT-1M1 st  ex h be FunctionFUNCT-1M1 st ((g =FUNCT-1R1 g1 & F .FUNCT-1K1 g =XBOOLE-0R4 h) & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,g1 .FUNCT-1K1 z))"
            using A4 sorry
          thus " not ( for h be FunctionFUNCT-1M1 holds  not ((F .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 h &  not h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x)))))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex h be FunctionFUNCT-1M1 st (it1 .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x))))) & (domRELAT-1K1 it2 =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex h be FunctionFUNCT-1M1 st (it2 .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x))))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & (( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex h be FunctionFUNCT-1M1 st (f1 .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x)))) & (domRELAT-1K1 f2 =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex h be FunctionFUNCT-1M1 st (f2 .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x)))))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A5: "domRELAT-1K1 f1 =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f)"
          and A6: " for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex h be FunctionFUNCT-1M1 st (f1 .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x)))"
          and A7: "domRELAT-1K1 f2 =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f)"
          and A8: " for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) implies ( ex h be FunctionFUNCT-1M1 st (f2 .FUNCT-1K1 g =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x)))"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (domsFUNCT-6K1 f) implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A9: "x inHIDDENR3 productCARD-3K4 (domsFUNCT-6K1 f)"
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A10: "x =HIDDENR1 g"and "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (domsFUNCT-6K1 f)"and " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies g .FUNCT-1K1 x inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 x"
            using card_3_def_5 sorry
          obtain h2 where
            [ty]:"h2 be FunctionFUNCT-1M1" and 
            A11: "f2 .FUNCT-1K1 g =XBOOLE-0R4 h2"and A12: "domRELAT-1K1 h2 =XBOOLE-0R4 domRELAT-1K1 f"and A13: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 h2 implies h2 .FUNCT-1K1 y =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(y,g .FUNCT-1K1 y)"
            using A8 A9 A10 sorry
          obtain h1 where
            [ty]:"h1 be FunctionFUNCT-1M1" and 
            A14: "f1 .FUNCT-1K1 g =XBOOLE-0R4 h1"and A15: "domRELAT-1K1 h1 =XBOOLE-0R4 domRELAT-1K1 f"and A16: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 h1 implies h1 .FUNCT-1K1 y =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(y,g .FUNCT-1K1 y)"
            using A6 A9 A10 sorry
          have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies h1 .FUNCT-1K1 z =XBOOLE-0R4 h2 .FUNCT-1K1 z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A17: "z inHIDDENR3 domRELAT-1K1 f"
            then have "h1 .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,g .FUNCT-1K1 z)"
              using A15 A16 sorry
            thus "h1 .FUNCT-1K1 z =XBOOLE-0R4 h2 .FUNCT-1K1 z"
              using A12 A13 A17 sorry
          qed "sorry"
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A10 A14 A15 A11 A12 funct_1_th_2 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A5 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_6_th_36:
" for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) & x inHIDDENR3 domRELAT-1K1 g implies (FregeFUNCT-6K6 f)..FUNCT-6K4(g,x) =XBOOLE-0R4 f ..FUNCT-6K4(x,g .FUNCT-1K1 x)"
proof-
  have " for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) & x inHIDDENR3 domRELAT-1K1 g implies (FregeFUNCT-6K6 f)..FUNCT-6K4(g,x) =HIDDENR1 f ..FUNCT-6K4(x,g .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
    assume A1: "g inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f)"
      and A2: "x inHIDDENR3 domRELAT-1K1 g"
    have A3: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (domsFUNCT-6K1 f)"
      using A1 card_3_th_9 sorry
    have A4: "domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_2 sorry
    obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A5: "(FregeFUNCT-6K6 f).FUNCT-1K1 g =XBOOLE-0R4 h"and A6: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g .FUNCT-1K1 x)"
      using A1 funct_6_def_7 sorry
    have "domRELAT-1K1 (FregeFUNCT-6K6 f) =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f)"
      using funct_6_def_7 sorry
    then have "(FregeFUNCT-6K6 f)..FUNCT-6K4(g,x) =HIDDENR1 h .FUNCT-1K1 x"
      using A1 A2 A5 A6 A3 A4 funct_5_th_38 sorry
    also have "... = f ..FUNCT-6K4(x,g .FUNCT-1K1 x)"
      using A2 A6 A7 A3 A4 sorry
    finally show "(FregeFUNCT-6K6 f)..FUNCT-6K4(g,x) =HIDDENR1 f ..FUNCT-6K4(x,g .FUNCT-1K1 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma funct_6_lm_1:
" for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds rngFUNCT-1K2 (FregeFUNCT-6K6 f) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f)"
proof(rule ballI)
  fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (FregeFUNCT-6K6 f) implies x inHIDDENR3 productCARD-3K4 (rngsFUNCT-6K2 f)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A1: "y inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f)"and A2: "x =HIDDENR1 (FregeFUNCT-6K6 f).FUNCT-1K1 y"
      using funct_1_def_3 sorry
    have A3: "domRELAT-1K1 (FregeFUNCT-6K6 f) =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f)"
      using funct_6_def_7 sorry
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A4: "y =HIDDENR1 g"and "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (domsFUNCT-6K1 f)"and A5: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies g .FUNCT-1K1 z inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 z"
      using A1 card_3_def_5 sorry
    obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A6: "(FregeFUNCT-6K6 f).FUNCT-1K1 g =XBOOLE-0R4 h"and A7: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"and A8: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,g .FUNCT-1K1 z)"
      using A1 A3 A4 funct_6_def_7 sorry
    have A9: "domRELAT-1K1 (rngsFUNCT-6K2 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_3 sorry
    have A10: "domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_2 sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f) implies h .FUNCT-1K1 z inTARSKIR2 rngsFUNCT-6K2 f .FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A11: "z inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f)"
      obtain t where 
        [ty]:"t be FunctionFUNCT-1M1" and tDef:"t = f .FUNCT-1K1 z"
         sorry
      have A12: "g .FUNCT-1K1 z inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 z"
        using A5 A9 A10 A11 sorry
      have A13: "z inHIDDENR3 domRELAT-1K1 f"
        using A9 A11 sorry
      then have A14: "rngsFUNCT-6K2 f .FUNCT-1K1 z =XBOOLE-0R4 rngFUNCT-1K2 t"
        using funct_6_th_22 sorry
      have A15: "domsFUNCT-6K1 f .FUNCT-1K1 z =XBOOLE-0R4 domRELAT-1K1 t"
        using A13 funct_6_th_22 sorry
      then have A16: "t .FUNCT-1K1 (g .FUNCT-1K1 z) inTARSKIR2 rngFUNCT-1K2 t"
        using A12 funct_1_def_3 sorry
      have "t .FUNCT-1K1 (g .FUNCT-1K1 z) =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,g .FUNCT-1K1 z)"
        using A13 A12 A15 funct_5_th_38 sorry
      thus "h .FUNCT-1K1 z inTARSKIR2 rngsFUNCT-6K2 f .FUNCT-1K1 z"
        using A7 A8 A9 A11 A14 A16 sorry
    qed "sorry"
    thus "x inHIDDENR3 productCARD-3K4 (rngsFUNCT-6K2 f)"
      using A2 A4 A6 A7 A9 card_3_def_5 sorry
  qed "sorry"
  thus "rngFUNCT-1K2 (FregeFUNCT-6K6 f) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_6_th_37:
" for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for h9 be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds ((x inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 x) & h inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f)) & h9 =XBOOLE-0R4 (FregeFUNCT-6K6 f).FUNCT-1K1 h implies (h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g & h9 .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (h .FUNCT-1K1 x)) & h9 inTARSKIR2 productCARD-3K4 (rngsFUNCT-6K2 f)"
proof-
  have " for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for h9 be FunctionFUNCT-1M1 holds  for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 x) & (h inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f) & h9 =XBOOLE-0R4 (FregeFUNCT-6K6 f).FUNCT-1K1 h) implies h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g & (h9 .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 (h .FUNCT-1K1 x) & h9 inTARSKIR2 productCARD-3K4 (rngsFUNCT-6K2 f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix h9 assume [ty]: "h9 be FunctionFUNCT-1M1"
    fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 x"
      and A2: "h inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f)"
      and A3: "h9 =XBOOLE-0R4 (FregeFUNCT-6K6 f).FUNCT-1K1 h"
    have A4: "x inHIDDENR3 domRELAT-1K1 f"
      using A1 sorry
    have A5: "domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_2 sorry
    have "( ex f2 be FunctionFUNCT-1M1 st (h =FUNCT-1R1 f2 & domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 (domsFUNCT-6K1 f)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies f2 .FUNCT-1K1 x inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 x)) & domsFUNCT-6K1 f .FUNCT-1K1 x =XBOOLE-0R4 domRELAT-1K1 g"
      using A1 A2 funct_6_th_22 card_3_def_5 sorry
    thus A6: "h .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
      using A5 A4 sorry
    have " ex f1 be FunctionFUNCT-1M1 st ((FregeFUNCT-6K6 f).FUNCT-1K1 h =XBOOLE-0R4 f1 & domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,h .FUNCT-1K1 x))"
      using A2 funct_6_def_7 sorry
    then have "h9 .FUNCT-1K1 x =HIDDENR1 uncurryFUNCT-5K2 f .BINOP-1K1(x,h .FUNCT-1K1 x)"
      using A3 A4 sorry
    also have "... = g .FUNCT-1K1 (h .FUNCT-1K1 x)"
      using A1 A6 funct_5_th_38 sorry
    finally show "h9 .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 (h .FUNCT-1K1 x)"
       sorry
    have A7: "rngFUNCT-1K2 (FregeFUNCT-6K6 f) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 f)"
      using funct_6_lm_1 sorry
    have "domRELAT-1K1 (FregeFUNCT-6K6 f) =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f)"
      using funct_6_def_7 sorry
    then have "h9 inTARSKIR2 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
      using A2 A3 funct_1_def_3 sorry
    thus "h9 inTARSKIR2 productCARD-3K4 (rngsFUNCT-6K2 f)"
      using A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma funct_6_lm_2:
" for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds productCARD-3K4 (rngsFUNCT-6K2 f) c=TARSKIR1 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
proof(rule ballI)
  fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (rngsFUNCT-6K2 f) implies x inHIDDENR3 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?F = "\<lambda>Lamb1. domsFUNCT-6K1 f .FUNCT-1K1 Lamb1"
    assume "x inHIDDENR3 productCARD-3K4 (rngsFUNCT-6K2 f)"
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A1: "x =HIDDENR1 g"and A2: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (rngsFUNCT-6K2 f)"and A3: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (rngsFUNCT-6K2 f) implies g .FUNCT-1K1 y inTARSKIR2 rngsFUNCT-6K2 f .FUNCT-1K1 y"
      using card_3_def_5 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex f1 be FunctionFUNCT-1M1 st f1 =FUNCT-1R1 f .FUNCT-1K1 Lamb1 & f1 .FUNCT-1K1 Lamb2 =XBOOLE-0R4 g .FUNCT-1K1 Lamb1"
    obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A4: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds y inHIDDENR3 h .FUNCT-1K1 x iff y inHIDDENR3 ?F(x) & ?P(x,y)))"
      using card_3_sch_2 sorry
    have A5: "productCARD-3K4 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 (FregeFUNCT-6K6 f)"
      using funct_6_def_7 sorry
    have A6: "domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_2 sorry
    have A7: "domRELAT-1K1 (rngsFUNCT-6K2 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_3 sorry
    have A8: " for X be setHIDDENM2 holds X inTARSKIR2 rngFUNCT-1K2 h implies X <>HIDDENR2 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X inTARSKIR2 rngFUNCT-1K2 h"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A9: "x inHIDDENR3 domRELAT-1K1 h"and A10: "X =XBOOLE-0R4 h .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      obtain fx where 
        [ty]:"fx be FunctionFUNCT-1M1" and fxDef:"fx = f .FUNCT-1K1 x"
         sorry
      have A11: "x inHIDDENR3 domRELAT-1K1 f"
        using A4 A9 sorry
      then have A12: "rngsFUNCT-6K2 f .FUNCT-1K1 x =XBOOLE-0R4 rngFUNCT-1K2 fx"
        using funct_6_th_22 sorry
      have "g .FUNCT-1K1 x inTARSKIR2 rngsFUNCT-6K2 f .FUNCT-1K1 x"
        using A3 A7 A4 A9 sorry
      then have A13: " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 fx & g .FUNCT-1K1 x =XBOOLE-0R4 fx .FUNCT-1K1 y"
        using A12 funct_1_def_3 sorry
      have "domsFUNCT-6K1 f .FUNCT-1K1 x =XBOOLE-0R4 domRELAT-1K1 fx"
        using A11 funct_6_th_22 sorry
      thus "X <>HIDDENR2 {}XBOOLE-0K1"
        using A4 A9 A10 A13 sorry
    qed "sorry"
    have A14: "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1 implies x inHIDDENR3 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
    proof(rule impI)
      assume "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
      then obtain D where 
        [ty]:"D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and DDef:"D = rngFUNCT-1K2 h"
        using A4 relat_1_th_42 sorry
      obtain Ch where
        [ty]:"Ch be FunctionFUNCT-1M1" and 
        A15: "domRELAT-1K1 Ch =XBOOLE-0R4 D"and A16: " for x be setHIDDENM2 holds x inTARSKIR2 D implies Ch .FUNCT-1K1 x inTARSKIR2 x"
        using A8 funct_1_th_111 sorry
      have A17: "domRELAT-1K1 (Ch *FUNCT-1K3 h) =XBOOLE-0R4 domRELAT-1K1 h"
        using A15 relat_1_th_27 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies (Ch *FUNCT-1K3 h).FUNCT-1K1 y inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A18: "y inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f)"
        then have "(Ch *FUNCT-1K3 h).FUNCT-1K1 y =XBOOLE-0R4 Ch .FUNCT-1K1 (h .FUNCT-1K1 y) & h .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 h"
          using A6 A4 A17 funct_1_th_12 funct_1_def_3 sorry
        then have "(Ch *FUNCT-1K3 h).FUNCT-1K1 y inTARSKIR2 h .FUNCT-1K1 y"
          using A16 sorry
        thus "(Ch *FUNCT-1K3 h).FUNCT-1K1 y inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 y"
          using A6 A4 A18 sorry
      qed "sorry"
      then have A19: "Ch *FUNCT-1K3 h inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f)"
        using A6 A4 A17 card_3_def_5 sorry
      then obtain h1 where
        [ty]:"h1 be FunctionFUNCT-1M1" and 
        A20: "(FregeFUNCT-6K6 f).FUNCT-1K1 (Ch *FUNCT-1K3 h) =XBOOLE-0R4 h1"and A21: "domRELAT-1K1 h1 =XBOOLE-0R4 domRELAT-1K1 f"and A22: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h1 implies h1 .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,(Ch *FUNCT-1K3 h).FUNCT-1K1 x)"
        using funct_6_def_7 sorry
      have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies h1 .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A23: "z inHIDDENR3 domRELAT-1K1 f"
        then have A24: "h1 .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(z,(Ch *FUNCT-1K3 h).FUNCT-1K1 z)"
          using A21 A22 sorry
        have "(Ch *FUNCT-1K3 h).FUNCT-1K1 z =XBOOLE-0R4 Ch .FUNCT-1K1 (h .FUNCT-1K1 z) & h .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 h"
          using A4 A17 A23 funct_1_th_12 funct_1_def_3 sorry
        then have A25: "(Ch *FUNCT-1K3 h).FUNCT-1K1 z inTARSKIR2 h .FUNCT-1K1 z"
          using A16 sorry
        then obtain f1 where
          [ty]:"f1 be FunctionFUNCT-1M1" and 
          A26: "f1 =FUNCT-1R1 f .FUNCT-1K1 z"and A27: "f1 .FUNCT-1K1 ((Ch *FUNCT-1K3 h).FUNCT-1K1 z) =XBOOLE-0R4 g .FUNCT-1K1 z"
          using A4 A23 sorry
        have A28: "(Ch *FUNCT-1K3 h).FUNCT-1K1 z inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 z"
          using A4 A23 A25 sorry
        have A29: "z inHIDDENR3 domRELAT-1K1 f"
          using A23 sorry
        then have "domsFUNCT-6K1 f .FUNCT-1K1 z =XBOOLE-0R4 domRELAT-1K1 f1"
          using A26 funct_6_th_22 sorry
        thus "h1 .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z"
          using A29 A24 A26 A27 A28 funct_5_th_38 sorry
      qed "sorry"
      then have "x =HIDDENR1 h1"
        using A1 A2 A7 A21 funct_1_th_2 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
        using A5 A19 A20 funct_1_def_3 sorry
    qed
    have "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies x inHIDDENR3 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
    proof(rule impI)
      assume A30: "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
      then have A31: "g =FUNCT-1R1 {}XBOOLE-0K1"
        using A2 funct_6_def_3 sorry
      have "domRELAT-1K1 (FregeFUNCT-6K6 f) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
        using A6 A5 A30 card_3_th_10 relat_1_th_41 sorry
      then have A32: "{}XBOOLE-0K1 inTARSKIR2 domRELAT-1K1 (FregeFUNCT-6K6 f)"
        using tarski_def_1 sorry
      then obtain h where
        [ty]:"h be FunctionFUNCT-1M1" and 
        A33: "(FregeFUNCT-6K6 f).FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 h"and A34: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"and " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,{}XBOOLE-0K1 .FUNCT-1K1 x)"
        using A5 funct_6_def_7 sorry
      have "h =FUNCT-1R1 {}XBOOLE-0K1"
        using A30 A34 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
        using A1 A31 A32 A33 funct_1_def_3 sorry
    qed
    thus "x inHIDDENR3 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
      using A14 sorry
  qed "sorry"
  thus "productCARD-3K4 (rngsFUNCT-6K2 f) c=TARSKIR1 rngFUNCT-1K2 (FregeFUNCT-6K6 f)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem funct_6_th_38:
" for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds rngFUNCT-1K2 (FregeFUNCT-6K6 f) =XBOOLE-0R4 productCARD-3K4 (rngsFUNCT-6K2 f)"
  using funct_6_lm_1 funct_6_lm_2 sorry

mtheorem funct_6_th_39:
" for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies (FregeFUNCT-6K6 f be one-to-oneFUNCT-1V2 iff ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies g be one-to-oneFUNCT-1V2))"
proof-
  have " for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies (FregeFUNCT-6K6 f be one-to-oneFUNCT-1V2 implies ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies g be one-to-oneFUNCT-1V2)) & (( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies g be one-to-oneFUNCT-1V2) implies FregeFUNCT-6K6 f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule impI,rule conjMI,rule impI)
    fix f assume [ty]: "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
    let ?h0 = "the ElementSUBSET-1M1-of productCARD-3K4 (domsFUNCT-6K1 f)"
    have A1: "domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_2 sorry
    assume A2: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
    have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 (domsFUNCT-6K1 f) implies  False "
    proof(rule impI)
      assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 (domsFUNCT-6K1 f)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A3: "x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f)"and A4: "{}XBOOLE-0K1 =XBOOLE-0R4 domsFUNCT-6K1 f .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have A5: "x inHIDDENR3 domRELAT-1K1 f"
        using A3 funct_6_def_2 sorry
      obtain g where 
        [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = f .FUNCT-1K1 x"
         sorry
      have A6: "x inHIDDENR3 domRELAT-1K1 f"
        using A5 sorry
      then have A7: "g inTARSKIR2 rngFUNCT-1K2 f"
        using funct_1_def_3 sorry
      have "{}XBOOLE-0K1 =XBOOLE-0R4 domRELAT-1K1 g"
        using A4 A6 funct_6_th_22 sorry
      thus " False "
        using A2 A7 relat_1_th_41 sorry
    qed
    then have "productCARD-3K4 (domsFUNCT-6K1 f) <>HIDDENR2 {}XBOOLE-0K1"
      using card_3_th_26 sorry
    then obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      "?h0 =FUNCT-1R1 h"and "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 (domsFUNCT-6K1 f)"and A8: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies h .FUNCT-1K1 x inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 x"
      using card_3_def_5 sorry
    have A9: "domRELAT-1K1 (FregeFUNCT-6K6 f) =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 f)"
      using funct_6_def_7 sorry
    show "FregeFUNCT-6K6 f be one-to-oneFUNCT-1V2 implies ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies g be one-to-oneFUNCT-1V2)"
    proof-
      have " not (FregeFUNCT-6K6 f be one-to-oneFUNCT-1V2 &  not ( for g be FunctionFUNCT-1M1 holds  not (g inTARSKIR2 rngFUNCT-1K2 f &  not g be one-to-oneFUNCT-1V2)))"
      proof-
        let ?G = "\<lambda>Lamb1. h .FUNCT-1K1 Lamb1"
        have "( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f) & y inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f)) & (FregeFUNCT-6K6 f).FUNCT-1K1 x =XBOOLE-0R4 (FregeFUNCT-6K6 f).FUNCT-1K1 y implies x =HIDDENR1 y) implies ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies g be one-to-oneFUNCT-1V2)"
        proof(rule impI,rule ballI,rule impI)
          assume A10: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f) & y inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f)) & (FregeFUNCT-6K6 f).FUNCT-1K1 x =XBOOLE-0R4 (FregeFUNCT-6K6 f).FUNCT-1K1 y implies x =HIDDENR1 y"
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume "g inTARSKIR2 rngFUNCT-1K2 f"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A11: "z inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 f .FUNCT-1K1 z"
            using funct_1_def_3 sorry
          let ?P = "\<lambda>Lamb1. Lamb1 =HIDDENR1 z"
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g & (y inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y) implies x =HIDDENR1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            let ?F = "\<lambda>Lamb1. x"
            obtain h1 where
              [ty]:"h1 be FunctionFUNCT-1M1" and 
              A12: "domRELAT-1K1 h1 =XBOOLE-0R4 domRELAT-1K1 f & ( for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 f implies (?P(a) implies h1 .FUNCT-1K1 a =HIDDENR1 ?F(a)) & ( not ?P(a) implies h1 .FUNCT-1K1 a =XBOOLE-0R4 ?G(a)))"
              using partfun1_sch_1 sorry
            assume A13: "x inHIDDENR3 domRELAT-1K1 g"
              and A14: "y inHIDDENR3 domRELAT-1K1 g"
              and A15: "g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
            have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies h1 .FUNCT-1K1 a inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 a"
            proof(rule ballI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              assume A16: "a inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f)"
              then have A17: "a <>HIDDENR2 z implies h1 .FUNCT-1K1 a =XBOOLE-0R4 h .FUNCT-1K1 a"
                using A1 A12 sorry
              have "a =HIDDENR1 z implies h1 .FUNCT-1K1 a =HIDDENR1 x"
                using A1 A12 A16 sorry
              thus "h1 .FUNCT-1K1 a inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 a"
                using A8 A11 A13 A16 A17 funct_6_th_22 sorry
            qed "sorry"
            then have A18: "h1 inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f)"
              using A1 A12 card_3_def_5 sorry
            then obtain g1 where
              [ty]:"g1 be FunctionFUNCT-1M1" and 
              A19: "(FregeFUNCT-6K6 f).FUNCT-1K1 h1 =XBOOLE-0R4 g1"and A20: "domRELAT-1K1 g1 =XBOOLE-0R4 domRELAT-1K1 f"and A21: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g1 implies g1 .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,h1 .FUNCT-1K1 x)"
              using funct_6_def_7 sorry
            let ?P = "\<lambda>Lamb1. Lamb1 =HIDDENR1 z"
            let ?G = "\<lambda>Lamb1. h .FUNCT-1K1 Lamb1"
            let ?F = "\<lambda>Lamb1. y"
            obtain h2 where
              [ty]:"h2 be FunctionFUNCT-1M1" and 
              A22: "domRELAT-1K1 h2 =XBOOLE-0R4 domRELAT-1K1 f & ( for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 f implies (?P(a) implies h2 .FUNCT-1K1 a =HIDDENR1 ?F(a)) & ( not ?P(a) implies h2 .FUNCT-1K1 a =XBOOLE-0R4 ?G(a)))"
              using partfun1_sch_1 sorry
            have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies h2 .FUNCT-1K1 a inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 a"
            proof(rule ballI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              assume A23: "a inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f)"
              then have A24: "a <>HIDDENR2 z implies h2 .FUNCT-1K1 a =XBOOLE-0R4 h .FUNCT-1K1 a"
                using A1 A22 sorry
              have "a =HIDDENR1 z implies h2 .FUNCT-1K1 a =HIDDENR1 y"
                using A1 A22 A23 sorry
              thus "h2 .FUNCT-1K1 a inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 a"
                using A8 A11 A14 A23 A24 funct_6_th_22 sorry
            qed "sorry"
            then have A25: "h2 inTARSKIR2 productCARD-3K4 (domsFUNCT-6K1 f)"
              using A1 A22 card_3_def_5 sorry
            then obtain g2 where
              [ty]:"g2 be FunctionFUNCT-1M1" and 
              A26: "(FregeFUNCT-6K6 f).FUNCT-1K1 h2 =XBOOLE-0R4 g2"and A27: "domRELAT-1K1 g2 =XBOOLE-0R4 domRELAT-1K1 f"and A28: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g2 implies g2 .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,h2 .FUNCT-1K1 x)"
              using funct_6_def_7 sorry
            have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 f implies g1 .FUNCT-1K1 a =XBOOLE-0R4 g2 .FUNCT-1K1 a"
            proof(rule ballI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              assume A29: "a inHIDDENR3 domRELAT-1K1 f"
              then have A30: "g2 .FUNCT-1K1 a =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(a,h2 .FUNCT-1K1 a)"
                using A27 A28 sorry
              have A31: "g1 .FUNCT-1K1 a =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(a,h1 .FUNCT-1K1 a)"
                using A20 A21 A29 sorry
              show "g1 .FUNCT-1K1 a =XBOOLE-0R4 g2 .FUNCT-1K1 a"
              proof-
                have cases: "a <>HIDDENR2 z or a =HIDDENR1 z"
                   sorry
                have case1: "a <>HIDDENR2 z implies g1 .FUNCT-1K1 a =XBOOLE-0R4 g2 .FUNCT-1K1 a"
                proof(rule impI)
                  assume A32: "a <>HIDDENR2 z"
                  then have "h1 .FUNCT-1K1 a =XBOOLE-0R4 h .FUNCT-1K1 a"
                    using A12 A29 sorry
                  thus "g1 .FUNCT-1K1 a =XBOOLE-0R4 g2 .FUNCT-1K1 a"
                    using A22 A29 A30 A31 A32 sorry
                qed
                have case2: "a =HIDDENR1 z implies g1 .FUNCT-1K1 a =XBOOLE-0R4 g2 .FUNCT-1K1 a"
                proof(rule impI)
                  assume A33: "a =HIDDENR1 z"
                  then have "h1 .FUNCT-1K1 a =HIDDENR1 x"
                    using A12 A29 sorry
                  then have A34: "g1 .FUNCT-1K1 a =XBOOLE-0R4 g .FUNCT-1K1 x"
                    using A11 A13 A31 A33 funct_5_th_38 sorry
                  have "h2 .FUNCT-1K1 a =HIDDENR1 y"
                    using A22 A29 A33 sorry
                  thus "g1 .FUNCT-1K1 a =XBOOLE-0R4 g2 .FUNCT-1K1 a"
                    using A11 A14 A15 A30 A33 A34 funct_5_th_38 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            then have "g1 =FUNCT-1R1 g2"
              using A20 A27 sorry
            then have A35: "h1 =FUNCT-1R1 h2"
              using A9 A10 A18 A19 A25 A26 sorry
            have A36: "z inHIDDENR3 domRELAT-1K1 f"
              using A11 sorry
            then have "h1 .FUNCT-1K1 z =HIDDENR1 x"
              using A12 sorry
            thus "x =HIDDENR1 y"
              using A36 A22 A35 sorry
          qed "sorry"
          thus "g be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed "sorry"
        thus " not (FregeFUNCT-6K6 f be one-to-oneFUNCT-1V2 &  not ( for g be FunctionFUNCT-1M1 holds  not (g inTARSKIR2 rngFUNCT-1K2 f &  not g be one-to-oneFUNCT-1V2)))"
          using funct_1_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A37: " for g be FunctionFUNCT-1M1 holds g inTARSKIR2 rngFUNCT-1K2 f implies g be one-to-oneFUNCT-1V2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f) & (y inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f) & (FregeFUNCT-6K6 f).FUNCT-1K1 x =XBOOLE-0R4 (FregeFUNCT-6K6 f).FUNCT-1K1 y) implies x =HIDDENR1 y"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A38: "x inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f)"
        and A39: "y inHIDDENR3 domRELAT-1K1 (FregeFUNCT-6K6 f)"
        and A40: "(FregeFUNCT-6K6 f).FUNCT-1K1 x =XBOOLE-0R4 (FregeFUNCT-6K6 f).FUNCT-1K1 y"
      obtain g2 where
        [ty]:"g2 be FunctionFUNCT-1M1" and 
        A41: "y =HIDDENR1 g2"and A42: "domRELAT-1K1 g2 =XBOOLE-0R4 domRELAT-1K1 (domsFUNCT-6K1 f)"and A43: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies g2 .FUNCT-1K1 x inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 x"
        using A9 A39 card_3_def_5 sorry
      obtain g1 where
        [ty]:"g1 be FunctionFUNCT-1M1" and 
        A44: "x =HIDDENR1 g1"and A45: "domRELAT-1K1 g1 =XBOOLE-0R4 domRELAT-1K1 (domsFUNCT-6K1 f)"and A46: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies g1 .FUNCT-1K1 x inTARSKIR2 domsFUNCT-6K1 f .FUNCT-1K1 x"
        using A9 A38 card_3_def_5 sorry
      obtain h2 where
        [ty]:"h2 be FunctionFUNCT-1M1" and 
        A47: "(FregeFUNCT-6K6 f).FUNCT-1K1 g2 =XBOOLE-0R4 h2"and A48: "domRELAT-1K1 h2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h2 implies h2 .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g2 .FUNCT-1K1 x))"
        using A9 A39 A41 funct_6_def_7 sorry
      obtain h1 where
        [ty]:"h1 be FunctionFUNCT-1M1" and 
        A49: "(FregeFUNCT-6K6 f).FUNCT-1K1 g1 =XBOOLE-0R4 h1"and A50: "domRELAT-1K1 h1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h1 implies h1 .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(x,g1 .FUNCT-1K1 x))"
        using A9 A38 A44 funct_6_def_7 sorry
      have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 f implies g1 .FUNCT-1K1 a =XBOOLE-0R4 g2 .FUNCT-1K1 a"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A51: "a inHIDDENR3 domRELAT-1K1 f"
        obtain g where 
          [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = f .FUNCT-1K1 a"
           sorry
        have A52: "a inHIDDENR3 domRELAT-1K1 f"
          using A51 sorry
        then have A53: "domRELAT-1K1 g =XBOOLE-0R4 domsFUNCT-6K1 f .FUNCT-1K1 a"
          using funct_6_th_22 sorry
        then have A54: "g2 .FUNCT-1K1 a inTARSKIR2 domRELAT-1K1 g"
          using A1 A43 A51 sorry
        have A55: "g1 .FUNCT-1K1 a inTARSKIR2 domRELAT-1K1 g"
          using A1 A46 A51 A53 sorry
        have "h2 .FUNCT-1K1 a =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(a,g2 .FUNCT-1K1 a)"
          using A48 A51 sorry
        then have A56: "h2 .FUNCT-1K1 a =XBOOLE-0R4 g .FUNCT-1K1 (g2 .FUNCT-1K1 a)"
          using A52 A54 funct_5_th_38 sorry
        have "g inTARSKIR2 rngFUNCT-1K2 f"
          using A52 funct_1_def_3 sorry
        then have A57: "g be one-to-oneFUNCT-1V2"
          using A37 sorry
        have "h1 .FUNCT-1K1 a =XBOOLE-0R4 uncurryFUNCT-5K2 f .BINOP-1K1(a,g1 .FUNCT-1K1 a)"
          using A50 A51 sorry
        then have "h1 .FUNCT-1K1 a =XBOOLE-0R4 g .FUNCT-1K1 (g1 .FUNCT-1K1 a)"
          using A52 A55 funct_5_th_38 sorry
        thus "g1 .FUNCT-1K1 a =XBOOLE-0R4 g2 .FUNCT-1K1 a"
          using A40 A44 A41 A49 A47 A55 A54 A56 A57 sorry
      qed "sorry"
      thus "x =HIDDENR1 y"
        using A1 A44 A45 A41 A42 funct_1_th_2 sorry
    qed "sorry"
    thus "FregeFUNCT-6K6 f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem funct_6_th_40:
"<:FUNCT-6K5 {}XBOOLE-0K1:> =FUNCT-1R1 {}XBOOLE-0K1 & FregeFUNCT-6K6 {}XBOOLE-0K1 =FUNCT-1R1 {}XBOOLE-0K1 .-->FUNCOP-1K17 {}XBOOLE-0K1"
proof(rule conjMI)
  have A1: "domRELAT-1K1 (domsFUNCT-6K1 ({}XBOOLE-0K1)) =XBOOLE-0R4 ({}XBOOLE-0K1)\<inverse>FUNCT-1K6 ({}XBOOLE-0K1)"
    using funct_6_def_2 relat_1_th_38 sorry
  then have A2: "productCARD-3K4 (domsFUNCT-6K1 ({}XBOOLE-0K1)) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
    using card_3_th_10 relat_1_th_41 sorry
  have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies (FregeFUNCT-6K6 {}XBOOLE-0K1).FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A4: "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
    then have A5: "x =HIDDENR1 {}XBOOLE-0K1"
      using tarski_def_1 sorry
    then have " ex h be FunctionFUNCT-1M1 st ((FregeFUNCT-6K6 {}XBOOLE-0K1).FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 ({}XBOOLE-0K1)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 ({}XBOOLE-0K1) .BINOP-1K1(x,{}XBOOLE-0K1 .FUNCT-1K1 x))"
      using A2 A4 funct_6_def_7 sorry
    thus "(FregeFUNCT-6K6 {}XBOOLE-0K1).FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1"
      using A5 sorry
  qed "sorry"
  have A6: "meetSETFAM-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
    using setfam_1_def_1 sorry
  have "rngFUNCT-1K2 (domsFUNCT-6K1 ({}XBOOLE-0K1)) =XBOOLE-0R4 {}XBOOLE-0K1"
    using A1 relat_1_th_38 relat_1_th_41 sorry
  then have "domRELAT-1K1 (<:FUNCT-6K5 {}XBOOLE-0K1:>) =XBOOLE-0R4 {}XBOOLE-0K1"
    using A6 funct_6_th_29 sorry
  thus "<:FUNCT-6K5 {}XBOOLE-0K1:> =FUNCT-1R1 {}XBOOLE-0K1"
     sorry
  have "domRELAT-1K1 (FregeFUNCT-6K6 {}XBOOLE-0K1) =XBOOLE-0R4 productCARD-3K4 (domsFUNCT-6K1 ({}XBOOLE-0K1))"
    using funct_6_def_7 sorry
  thus "FregeFUNCT-6K6 {}XBOOLE-0K1 =FUNCT-1R1 {}XBOOLE-0K1 .-->FUNCOP-1K17 {}XBOOLE-0K1"
    using A2 A3 funcop_1_th_11 sorry
qed

mtheorem funct_6_th_41:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies domRELAT-1K1 (<:FUNCT-6K5 X -->FUNCOP-1K7 f :>) =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (<:FUNCT-6K5 X -->FUNCOP-1K7 f :>).FUNCT-1K1 x =FUNCT-1R1 X -->FUNCOP-1K7 f .FUNCT-1K1 x)"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies domRELAT-1K1 (<:FUNCT-6K5 X -->FUNCOP-1K7 f :>) =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (<:FUNCT-6K5 X -->FUNCOP-1K7 f :>).FUNCT-1K1 x =FUNCT-1R1 X -->FUNCOP-1K7 f .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    have A2: "domRELAT-1K1 (<:FUNCT-6K5 X -->FUNCOP-1K7 f :>) =HIDDENR1 meetFUNCT-6K3 (domsFUNCT-6K1 (X -->FUNCOP-1K7 f))"
      using funct_6_th_29 sorry
    also have "... = meetFUNCT-6K3 (X -->FUNCOP-1K7 domRELAT-1K1 f)"
      using funct_6_th_24 sorry
    also have "... = domRELAT-1K1 f"
      using A1 funct_6_th_27 sorry
    finally show "domRELAT-1K1 (<:FUNCT-6K5 X -->FUNCOP-1K7 f :>) =HIDDENR1 domRELAT-1K1 f"
       sorry
    have A3: "rngFUNCT-1K2 (<:FUNCT-6K5 X -->FUNCOP-1K7 f :>) c=TARSKIR1 productCARD-3K4 (rngsFUNCT-6K2 (X -->FUNCOP-1K7 f)) & rngsFUNCT-6K2 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 rngFUNCT-1K2 f"
      using funct_6_th_24 funct_6_th_29 sorry
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A4: "x inHIDDENR3 domRELAT-1K1 f"
    then have "(<:FUNCT-6K5 X -->FUNCOP-1K7 f :>).FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (<:FUNCT-6K5 X -->FUNCOP-1K7 f :>)"
      using A2 funct_1_def_3 sorry
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A5: "(<:FUNCT-6K5 X -->FUNCOP-1K7 f :>).FUNCT-1K1 x =FUNCT-1R1 g"and A6: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (X -->FUNCOP-1K7 rngFUNCT-1K2 f)"and " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (X -->FUNCOP-1K7 rngFUNCT-1K2 f) implies g .FUNCT-1K1 y inTARSKIR2 (X -->FUNCOP-1K7 rngFUNCT-1K2 f).FUNCT-1K1 y"
      using A3 card_3_def_5 sorry
    have A7: "domRELAT-1K1 g =XBOOLE-0R4 X"
      using A6 funcop_1_th_13 sorry
    have A8: "domRELAT-1K1 (X -->FUNCOP-1K7 f) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    have A9: " for y be objectHIDDENM1 holds y inHIDDENR3 X implies g .FUNCT-1K1 y =XBOOLE-0R4 (X -->FUNCOP-1K7 f .FUNCT-1K1 x).FUNCT-1K1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A10: "y inHIDDENR3 X"
      then have "g .FUNCT-1K1 y =XBOOLE-0R4 uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f) .BINOP-1K1(y,x) & (X -->FUNCOP-1K7 f).FUNCT-1K1 y =FUNCT-1R1 f"
        using A2 A4 A5 A7 funct_6_th_31 funcop_1_th_7 sorry
      then have "g .FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A4 A8 A10 funct_5_th_38 sorry
      thus "g .FUNCT-1K1 y =XBOOLE-0R4 (X -->FUNCOP-1K7 f .FUNCT-1K1 x).FUNCT-1K1 y"
        using A10 funcop_1_th_7 sorry
    qed "sorry"
    have "domRELAT-1K1 (X -->FUNCOP-1K7 f .FUNCT-1K1 x) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    thus "(<:FUNCT-6K5 X -->FUNCOP-1K7 f :>).FUNCT-1K1 x =FUNCT-1R1 X -->FUNCOP-1K7 f .FUNCT-1K1 x"
      using A5 A7 A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_42:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (domRELAT-1K1 (FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 FuncsFUNCT-2K1(X,domRELAT-1K1 f) & rngFUNCT-1K2 (FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FuncsFUNCT-2K1(X,domRELAT-1K1 f) implies (FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)).FUNCT-1K1 g =XBOOLE-0R4 f *FUNCT-1K3 g)"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (domRELAT-1K1 (FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 FuncsFUNCT-2K1(X,domRELAT-1K1 f) & rngFUNCT-1K2 (FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)) & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 FuncsFUNCT-2K1(X,domRELAT-1K1 f) implies (FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)).FUNCT-1K1 g =XBOOLE-0R4 f *FUNCT-1K3 g)"
  proof(rule ballI,rule ballI,rule conjMI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "productCARD-3K4 (X -->FUNCOP-1K7 domRELAT-1K1 f) =XBOOLE-0R4 FuncsFUNCT-2K1(X,domRELAT-1K1 f)"
      using card_3_th_11 sorry
    have A2: "domsFUNCT-6K1 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 domRELAT-1K1 f"
      using funct_6_th_24 sorry
    have "rngsFUNCT-6K2 (X -->FUNCOP-1K7 f) =FUNCT-1R1 X -->FUNCOP-1K7 rngFUNCT-1K2 f & productCARD-3K4 (X -->FUNCOP-1K7 rngFUNCT-1K2 f) =XBOOLE-0R4 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
      using funct_6_th_24 card_3_th_11 sorry
    thus "domRELAT-1K1 (FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 FuncsFUNCT-2K1(X,domRELAT-1K1 f) & rngFUNCT-1K2 (FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)) =XBOOLE-0R4 FuncsFUNCT-2K1(X,rngFUNCT-1K2 f)"
      using A2 A1 funct_6_def_7 funct_6_th_38 sorry
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A3: "g inTARSKIR2 FuncsFUNCT-2K1(X,domRELAT-1K1 f)"
    then obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A4: "(FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)).FUNCT-1K1 g =XBOOLE-0R4 h"and A5: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 (X -->FUNCOP-1K7 f)"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f) .BINOP-1K1(x,g .FUNCT-1K1 x)"
      using A2 A1 funct_6_def_7 sorry
    have "domRELAT-1K1 (X -->FUNCOP-1K7 domRELAT-1K1 f) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    then have A7: "domRELAT-1K1 h =XBOOLE-0R4 X"
      using A2 A5 funct_6_def_2 sorry
    have A8: " ex g9 be FunctionFUNCT-1M1 st (g =FUNCT-1R1 g9 & domRELAT-1K1 g9 =XBOOLE-0R4 X) & rngFUNCT-1K2 g9 c=TARSKIR1 domRELAT-1K1 f"
      using A3 funct_2_def_2 sorry
    then have A9: "domRELAT-1K1 (f *FUNCT-1K3 g) =XBOOLE-0R4 X"
      using relat_1_th_27 sorry
    have A10: "domRELAT-1K1 (X -->FUNCOP-1K7 f) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (f *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A11: "x inHIDDENR3 X"
      then have A12: "h .FUNCT-1K1 x =XBOOLE-0R4 uncurryFUNCT-5K2 (X -->FUNCOP-1K7 f) .BINOP-1K1(x,g .FUNCT-1K1 x) & (X -->FUNCOP-1K7 f).FUNCT-1K1 x =FUNCT-1R1 f"
        using A6 A7 funcop_1_th_7 sorry
      have "g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g & (f *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (g .FUNCT-1K1 x)"
        using A8 A9 A11 funct_1_th_12 funct_1_def_3 sorry
      thus "(f *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
        using A8 A10 A11 A12 funct_5_th_38 sorry
    qed "sorry"
    thus "(FregeFUNCT-6K6 (X -->FUNCOP-1K7 f)).FUNCT-1K1 g =XBOOLE-0R4 f *FUNCT-1K3 g"
      using A4 A7 A9 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_43:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (f .FUNCT-1K1 x,g .FUNCT-1K1 x)are-equipotentWELLORD2R2) implies (productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & (domRELAT-1K1 g =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies (f .FUNCT-1K1 x,g .FUNCT-1K1 x)are-equipotentWELLORD2R2)) implies (productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 X"
      and A2: "domRELAT-1K1 g =XBOOLE-0R4 X"
      and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (f .FUNCT-1K1 x,g .FUNCT-1K1 x)are-equipotentWELLORD2R2"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex f1 be FunctionFUNCT-1M1 st ((Lamb2 =HIDDENR1 f1 & f1 be one-to-oneFUNCT-1V2) & domRELAT-1K1 f1 =XBOOLE-0R4 f .FUNCT-1K1 Lamb1) & rngFUNCT-1K2 f1 =XBOOLE-0R4 g .FUNCT-1K1 Lamb1"
    have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies  not ( for y be objectHIDDENM1 holds  not ( ex f1 be FunctionFUNCT-1M1 st ((y =HIDDENR1 f1 & f1 be one-to-oneFUNCT-1V2) & domRELAT-1K1 f1 =XBOOLE-0R4 f .FUNCT-1K1 x) & rngFUNCT-1K2 f1 =XBOOLE-0R4 g .FUNCT-1K1 x))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then have "(f .FUNCT-1K1 x,g .FUNCT-1K1 x)are-equipotentWELLORD2R2"
          using A3 sorry
        then have " ex h be FunctionFUNCT-1M1 st (h be one-to-oneFUNCT-1V2 & domRELAT-1K1 h =XBOOLE-0R4 f .FUNCT-1K1 x) & rngFUNCT-1K2 h =XBOOLE-0R4 g .FUNCT-1K1 x"
           sorry
        thus " not ( for y be objectHIDDENM1 holds  not ( ex f1 be FunctionFUNCT-1M1 st ((y =HIDDENR1 f1 & f1 be one-to-oneFUNCT-1V2) & domRELAT-1K1 f1 =XBOOLE-0R4 f .FUNCT-1K1 x) & rngFUNCT-1K2 f1 =XBOOLE-0R4 g .FUNCT-1K1 x))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A5: "domRELAT-1K1 h =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ?P(x,h .FUNCT-1K1 x))"
      using classes1_sch_1 A4 sorry
    have "h be Function-yieldingFUNCOP-1V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x be FunctionFUNCT-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 h"
        then have "?P(x,h .FUNCT-1K1 x)"
          using A5 sorry
        thus "h .FUNCT-1K1 x be FunctionFUNCT-1M1"
           sorry
      qed "sorry"
      thus "h be Function-yieldingFUNCOP-1V1"
        using funcop_1_def_6 sorry
    qed
    then have 
      [ty]:"h be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
       sorry
    have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies rngsFUNCT-6K2 h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 X"
      then have " ex f1 be FunctionFUNCT-1M1 st ((h .FUNCT-1K1 x =FUNCT-1R1 f1 & f1 be one-to-oneFUNCT-1V2) & domRELAT-1K1 f1 =XBOOLE-0R4 f .FUNCT-1K1 x) & rngFUNCT-1K2 f1 =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A5 sorry
      thus "rngsFUNCT-6K2 h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A5 A7 funct_6_th_22 sorry
    qed "sorry"
    have A8: "domRELAT-1K1 h =XBOOLE-0R4 X"
      using A5 sorry
    then have "domRELAT-1K1 (rngsFUNCT-6K2 h) =XBOOLE-0R4 X"
      using funct_6_def_3 sorry
    then have A9: "rngsFUNCT-6K2 h =FUNCT-1R1 g"
      using A2 A6 sorry
    have A10: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies domsFUNCT-6K1 h .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A11: "x inHIDDENR3 X"
      then have " ex f1 be FunctionFUNCT-1M1 st ((h .FUNCT-1K1 x =FUNCT-1R1 f1 & f1 be one-to-oneFUNCT-1V2) & domRELAT-1K1 f1 =XBOOLE-0R4 f .FUNCT-1K1 x) & rngFUNCT-1K2 f1 =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A5 sorry
      thus "domsFUNCT-6K1 h .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A5 A11 funct_6_th_22 sorry
    qed "sorry"
    have "domRELAT-1K1 (domsFUNCT-6K1 h) =XBOOLE-0R4 X"
      using A8 funct_6_def_2 sorry
    then have A12: "domsFUNCT-6K1 h =FUNCT-1R1 f"
      using A1 A10 sorry
    have "(productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
    proof-
      show "(productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
      proof-
        have cases: "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 h or  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 h"
           sorry
        have case1: "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 h implies (productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
        proof(rule impI)
          assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 h"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A13: "x inHIDDENR3 X"and A14: "{}XBOOLE-0K1 =FUNCT-1R1 h .FUNCT-1K1 x"
            using A5 funct_1_def_3 sorry
          have A15: " ex f1 be FunctionFUNCT-1M1 st (({}XBOOLE-0K1 =FUNCT-1R1 f1 & f1 be one-to-oneFUNCT-1V2) & domRELAT-1K1 f1 =XBOOLE-0R4 f .FUNCT-1K1 x) & rngFUNCT-1K2 f1 =XBOOLE-0R4 g .FUNCT-1K1 x"
            using A5 A13 A14 sorry
          then have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
            using A1 A13 funct_1_def_3 sorry
          then have A16: "productCARD-3K4 f =XBOOLE-0R4 {}XBOOLE-0K1"
            using card_3_th_26 sorry
          have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 g"
            using A2 A13 A15 funct_1_def_3 relat_1_th_38 sorry
          thus "(productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
            using A16 card_3_th_26 sorry
        qed
        have case2: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 h implies (productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
        proof(rule impI)
          assume A17: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 h"
          have A18: " for f1 be FunctionFUNCT-1M1 holds f1 inTARSKIR2 rngFUNCT-1K2 h implies f1 be one-to-oneFUNCT-1V2"
          proof(rule ballI,rule impI)
            fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
            assume "f1 inTARSKIR2 rngFUNCT-1K2 h"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A19: "x inHIDDENR3 X"and A20: "f1 =FUNCT-1R1 h .FUNCT-1K1 x"
              using A5 funct_1_def_3 sorry
            have " ex f1 be FunctionFUNCT-1M1 st ((h .FUNCT-1K1 x =FUNCT-1R1 f1 & f1 be one-to-oneFUNCT-1V2) & domRELAT-1K1 f1 =XBOOLE-0R4 f .FUNCT-1K1 x) & rngFUNCT-1K2 f1 =XBOOLE-0R4 g .FUNCT-1K1 x"
              using A5 A19 sorry
            thus "f1 be one-to-oneFUNCT-1V2"
              using A20 sorry
          qed "sorry"
          show "(productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
          proof-
            have "(FregeFUNCT-6K6 h be one-to-oneFUNCT-1V2 & domRELAT-1K1 (FregeFUNCT-6K6 h) =HIDDENR1 productCARD-3K4 f) & rngRELAT-1K2 (FregeFUNCT-6K6 h) =HIDDENR1 productCARD-3K4 g"
            proof-
              show "(FregeFUNCT-6K6 h be one-to-oneFUNCT-1V2 & domRELAT-1K1 (FregeFUNCT-6K6 h) =HIDDENR1 productCARD-3K4 f) & rngRELAT-1K2 (FregeFUNCT-6K6 h) =HIDDENR1 productCARD-3K4 g"
                using A12 A9 A17 A18 funct_6_def_7 funct_6_th_38 funct_6_th_39 sorry
            qed
            thus "(productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
              using bexI[of _ "FregeFUNCT-6K6 h"] wellord2_def_4 sorry
          qed
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_44:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 h & domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 h) & h be one-to-oneFUNCT-1V2) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies (f .FUNCT-1K1 x,g .FUNCT-1K1 (h .FUNCT-1K1 x))are-equipotentWELLORD2R2) implies (productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 h & (domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 h & (h be one-to-oneFUNCT-1V2 & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies (f .FUNCT-1K1 x,g .FUNCT-1K1 (h .FUNCT-1K1 x))are-equipotentWELLORD2R2))) implies (productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    let ?X = "domRELAT-1K1 f"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 h"
      and A2: "domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 h"
      and A3: "h be one-to-oneFUNCT-1V2"
      and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies (f .FUNCT-1K1 x,g .FUNCT-1K1 (h .FUNCT-1K1 x))are-equipotentWELLORD2R2"
    have A5: "h *FUNCT-1K3 h \<inverse>FUNCT-1K4 =FUNCT-1R1 idPARTFUN1K6 (domRELAT-1K1 g)"
      using A2 A3 funct_1_th_39 sorry
    have A6: "domRELAT-1K1 (g *FUNCT-1K3 h) =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 A2 relat_1_th_27 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x,(g *FUNCT-1K3 h).FUNCT-1K1 x)are-equipotentWELLORD2R2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 domRELAT-1K1 f"
      then have "(f .FUNCT-1K1 x,g .FUNCT-1K1 (h .FUNCT-1K1 x))are-equipotentWELLORD2R2"
        using A1 A4 sorry
      thus "(f .FUNCT-1K1 x,(g *FUNCT-1K3 h).FUNCT-1K1 x)are-equipotentWELLORD2R2"
        using A6 A7 funct_1_th_12 sorry
    qed "sorry"
    then have A8: "(productCARD-3K4 f,productCARD-3K4 (g *FUNCT-1K3 h))are-equipotentWELLORD2R2"
      using A6 funct_6_th_43 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex f1 be FunctionFUNCT-1M1 st Lamb1 =HIDDENR1 f1 & Lamb2 =HIDDENR1 f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4"
    have A9: " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (g *FUNCT-1K3 h) implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (g *FUNCT-1K3 h) implies  not ( for y be objectHIDDENM1 holds  not ( ex f1 be FunctionFUNCT-1M1 st x =HIDDENR1 f1 & y =HIDDENR1 f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 (g *FUNCT-1K3 h)"
        then have " ex f1 be FunctionFUNCT-1M1 st (x =HIDDENR1 f1 & domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 (g *FUNCT-1K3 h)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 h) implies f1 .FUNCT-1K1 y inTARSKIR2 (g *FUNCT-1K3 h).FUNCT-1K1 y)"
          using card_3_def_5 sorry
        then obtain f1 where
          [ty]:"f1 be FunctionFUNCT-1M1" and 
          A10: "x =HIDDENR1 f1"
           sorry
        have "f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4 =FUNCT-1R1 f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4"
           sorry
        thus " not ( for y be objectHIDDENM1 holds  not ( ex f1 be FunctionFUNCT-1M1 st x =HIDDENR1 f1 & y =HIDDENR1 f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4))"
          using A10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain F where
      [ty]:"F be FunctionFUNCT-1M1" and 
      A11: "domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 (g *FUNCT-1K3 h) & ( for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (g *FUNCT-1K3 h) implies ?P(x,F .FUNCT-1K1 x))"
      using classes1_sch_1 A9 sorry
    have A12: "rngFUNCT-1K2 (h \<inverse>FUNCT-1K4) =XBOOLE-0R4 ?X"
      using A1 A3 funct_1_th_33 sorry
    have A13: "F be one-to-oneFUNCT-1V2"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F & (y inHIDDENR3 domRELAT-1K1 F & F .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 y) implies x =HIDDENR1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A14: "x inHIDDENR3 domRELAT-1K1 F"
          and A15: "y inHIDDENR3 domRELAT-1K1 F"
          and A16: "F .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 y"
        obtain g2 where
          [ty]:"g2 be FunctionFUNCT-1M1" and 
          A17: "y =HIDDENR1 g2"and A18: "F .FUNCT-1K1 y =XBOOLE-0R4 g2 *FUNCT-1K3 h \<inverse>FUNCT-1K4"
          using A11 A15 sorry
        have A19: "domRELAT-1K1 g2 =XBOOLE-0R4 ?X"
          using A6 A11 A15 A17 card_3_th_9 sorry
        obtain g1 where
          [ty]:"g1 be FunctionFUNCT-1M1" and 
          A20: "x =HIDDENR1 g1"and A21: "F .FUNCT-1K1 x =XBOOLE-0R4 g1 *FUNCT-1K3 h \<inverse>FUNCT-1K4"
          using A11 A14 sorry
        have "domRELAT-1K1 g1 =XBOOLE-0R4 ?X"
          using A6 A11 A14 A20 card_3_th_9 sorry
        thus "x =HIDDENR1 y"
          using A12 A16 A20 A21 A17 A18 A19 funct_1_th_86 sorry
      qed "sorry"
      thus "F be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    have A22: "(g *FUNCT-1K3 h)*FUNCT-1K3 h \<inverse>FUNCT-1K4 =FUNCT-1R1 g *FUNCT-1K3 (h *FUNCT-1K3 h \<inverse>FUNCT-1K4) & g *FUNCT-1K3 idPARTFUN1K6 (domRELAT-1K1 g) =FUNCT-1R1 g"
      using relat_1_th_36 relat_1_th_52 sorry
    have A23: "productCARD-3K4 g c=TARSKIR1 rngFUNCT-1K2 F"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 g implies x inHIDDENR3 rngFUNCT-1K2 F"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 g"
        then obtain f1 where
          [ty]:"f1 be FunctionFUNCT-1M1" and 
          A24: "x =HIDDENR1 f1"and A25: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 g"and A26: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 g implies f1 .FUNCT-1K1 z inTARSKIR2 g .FUNCT-1K1 z"
          using card_3_def_5 sorry
        have A27: "domRELAT-1K1 (f1 *FUNCT-1K3 h) =XBOOLE-0R4 ?X"
          using A1 A2 A25 relat_1_th_27 sorry
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies (f1 *FUNCT-1K3 h).FUNCT-1K1 z inTARSKIR2 (g *FUNCT-1K3 h).FUNCT-1K1 z"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A28: "z inHIDDENR3 ?X"
          then have A29: "h .FUNCT-1K1 z inTARSKIR2 domRELAT-1K1 g"
            using A1 A2 funct_1_def_3 sorry
          have A30: "h \<inverse>FUNCT-1K4 .FUNCT-1K1 (h .FUNCT-1K1 z) =HIDDENR1 z"
            using A1 A3 A28 funct_1_th_34 sorry
          have "(f1 *FUNCT-1K3 h).FUNCT-1K1 z =XBOOLE-0R4 f1 .FUNCT-1K1 (h .FUNCT-1K1 z)"
            using A27 A28 funct_1_th_12 sorry
          then have "(f1 *FUNCT-1K3 h).FUNCT-1K1 z inTARSKIR2 ((g *FUNCT-1K3 h)*FUNCT-1K3 h \<inverse>FUNCT-1K4).FUNCT-1K1 (h .FUNCT-1K1 z)"
            using A5 A22 A26 A29 sorry
          thus "(f1 *FUNCT-1K3 h).FUNCT-1K1 z inTARSKIR2 (g *FUNCT-1K3 h).FUNCT-1K1 z"
            using A5 A22 A29 A30 funct_1_th_12 sorry
        qed "sorry"
        then have A31: "f1 *FUNCT-1K3 h inTARSKIR2 productCARD-3K4 (g *FUNCT-1K3 h)"
          using A6 A27 card_3_def_5 sorry
        then have " ex f2 be FunctionFUNCT-1M1 st f1 *FUNCT-1K3 h =FUNCT-1R1 f2 & F .FUNCT-1K1 (f1 *FUNCT-1K3 h) =XBOOLE-0R4 f2 *FUNCT-1K3 h \<inverse>FUNCT-1K4"
          using A11 sorry
        then have "F .FUNCT-1K1 (f1 *FUNCT-1K3 h) =HIDDENR1 f1 *FUNCT-1K3 idPARTFUN1K6 (domRELAT-1K1 g)"
          using A5 relat_1_th_36 sorry
        also have "... = x"
          using A24 A25 relat_1_th_51 sorry
        finally have "F .FUNCT-1K1 (f1 *FUNCT-1K3 h) =HIDDENR1 x"
           sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 F"
          using A11 A31 funct_1_def_3 sorry
      qed "sorry"
      thus "productCARD-3K4 g c=TARSKIR1 rngFUNCT-1K2 F"
        using tarski_def_3 sorry
    qed
    have A32: "domRELAT-1K1 (h \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 h"
      using A3 funct_1_th_33 sorry
    have "rngFUNCT-1K2 F c=TARSKIR1 productCARD-3K4 g"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies x inHIDDENR3 productCARD-3K4 g"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 F"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A33: "y inHIDDENR3 domRELAT-1K1 F"and A34: "x =HIDDENR1 F .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        obtain f1 where
          [ty]:"f1 be FunctionFUNCT-1M1" and 
          A35: "y =HIDDENR1 f1"and A36: "domRELAT-1K1 f1 =XBOOLE-0R4 ?X"and A37: " for z be objectHIDDENM1 holds z inHIDDENR3 ?X implies f1 .FUNCT-1K1 z inTARSKIR2 (g *FUNCT-1K3 h).FUNCT-1K1 z"
          using A6 A11 A33 card_3_def_5 sorry
        have A38: "domRELAT-1K1 (f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 g"
          using A2 A12 A32 A36 relat_1_th_27 sorry
        have A39: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 g implies (f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4).FUNCT-1K1 z inTARSKIR2 g .FUNCT-1K1 z"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A40: "z inHIDDENR3 domRELAT-1K1 g"
          then have A41: "h \<inverse>FUNCT-1K4 .FUNCT-1K1 z inTARSKIR2 ?X"
            using A2 A12 A32 funct_1_def_3 sorry
          have "g .FUNCT-1K1 z =XBOOLE-0R4 (g *FUNCT-1K3 h).FUNCT-1K1 (h \<inverse>FUNCT-1K4 .FUNCT-1K1 z) & (f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4).FUNCT-1K1 z =XBOOLE-0R4 f1 .FUNCT-1K1 (h \<inverse>FUNCT-1K4 .FUNCT-1K1 z)"
            using A5 A22 A38 A40 funct_1_th_12 sorry
          thus "(f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4).FUNCT-1K1 z inTARSKIR2 g .FUNCT-1K1 z"
            using A37 A41 sorry
        qed "sorry"
        have " ex f1 be FunctionFUNCT-1M1 st y =HIDDENR1 f1 & F .FUNCT-1K1 y =XBOOLE-0R4 f1 *FUNCT-1K3 h \<inverse>FUNCT-1K4"
          using A11 A33 sorry
        thus "x inHIDDENR3 productCARD-3K4 g"
          using A34 A35 A38 A39 card_3_def_5 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 F c=TARSKIR1 productCARD-3K4 g"
        using tarski_def_3 sorry
    qed
    then have "rngFUNCT-1K2 F =XBOOLE-0R4 productCARD-3K4 g"
      using A23 sorry
    then have "(productCARD-3K4 (g *FUNCT-1K3 h),productCARD-3K4 g)are-equipotentWELLORD2R2"
      using A11 A13 sorry
    thus "(productCARD-3K4 f,productCARD-3K4 g)are-equipotentWELLORD2R2"
      using A8 wellord2_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_45:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for P be PermutationFUNCT-2M2-of X holds domRELAT-1K1 f =XBOOLE-0R4 X implies (productCARD-3K4 f,productCARD-3K4 (f *FUNCT-1K3 P))are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for P be PermutationFUNCT-2M2-of X holds domRELAT-1K1 f =XBOOLE-0R4 X implies (productCARD-3K4 f,productCARD-3K4 (f *FUNCT-1K3 P))are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix P assume [ty]: "P be PermutationFUNCT-2M2-of X"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 X"
    have A2: "rngFUNCT-1K2 P =XBOOLE-0R4 X"
      using funct_2_def_3 sorry
    have "domRELAT-1K1 P =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    then have A3: "domRELAT-1K1 (f *FUNCT-1K3 P) =XBOOLE-0R4 X"
      using A1 A2 relat_1_th_27 sorry
    have A4: "rngFUNCT-1K2 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub>) =XBOOLE-0R4 X"
      using funct_2_def_3 sorry
    have A5: "domRELAT-1K1 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub>) =XBOOLE-0R4 X"
      using funct_2_th_52 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub>) implies (f .FUNCT-1K1 x,(f *FUNCT-1K3 P).FUNCT-1K1 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> .FUNCT-1K1 x))are-equipotentWELLORD2R2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 domRELAT-1K1 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub>)"
      then have "P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> .FUNCT-1K1 x inTARSKIR2 X"
        using A4 funct_1_def_3 sorry
      then have "(f *FUNCT-1K3 P).FUNCT-1K1 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> .FUNCT-1K1 x) =HIDDENR1 f .FUNCT-1K1 (P .FUNCT-1K1 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> .FUNCT-1K1 x))"
        using A3 funct_1_th_12 sorry
      also have "... = f .FUNCT-1K1 x"
        using A5 A2 A6 funct_1_th_35 sorry
      finally have "(f *FUNCT-1K3 P).FUNCT-1K1 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> .FUNCT-1K1 x) =HIDDENR1 f .FUNCT-1K1 x"
         sorry
      thus "(f .FUNCT-1K1 x,(f *FUNCT-1K3 P).FUNCT-1K1 (P \<inverse>FUNCT-2K2\<^bsub>(X)\<^esub> .FUNCT-1K1 x))are-equipotentWELLORD2R2"
         sorry
    qed "sorry"
    thus "(productCARD-3K4 f,productCARD-3K4 (f *FUNCT-1K3 P))are-equipotentWELLORD2R2"
      using A1 A5 A4 A3 funct_6_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef funct_6_def_8 ("FuncsFUNCT-6K7'( _ , _ ')" [0,0]228 ) where
  mlet "f be FunctionFUNCT-1M1", "X be setHIDDENM2"
"func FuncsFUNCT-6K7(f,X) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X))"
    proof-
      have " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not tVar6 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X)))"
      proof-
        let ?F = "\<lambda>Lamb1. FuncsFUNCT-2K1(f .FUNCT-1K1 Lamb1,X)"
        obtain F where
          [ty]:"F be FunctionFUNCT-1M1" and 
          A1: "domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies F .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
          using funct_1_sch_3 sorry
        show " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not tVar6 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X)))"
        proof(rule bexI[of _ "F"])
          show "domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not F .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X)))"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X))) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it2 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X)) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f2 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X)))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A2: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X)"
          and A4: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f2 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A6: "x inHIDDENR3 domRELAT-1K1 f"
          then have "f1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 x,X)"
            using A3 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A5 A6 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A2 A4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem funct_6_th_46:
" for f be FunctionFUNCT-1M1 holds  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies FuncsFUNCT-6K7(f,{}XBOOLE-0K1) =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1"
proof-
  have " for f be FunctionFUNCT-1M1 holds  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies FuncsFUNCT-6K7(f,{}XBOOLE-0K1) =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1).FUNCT-1K1 x =HIDDENR1 FuncsFUNCT-2K1(f .FUNCT-1K1 x,{}XBOOLE-0K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domRELAT-1K1 f"
      then have A4: "f .FUNCT-1K1 x <>HIDDENR2 {}XBOOLE-0K1"
        using A1 funct_1_def_3 sorry
      have "(domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1).FUNCT-1K1 x =HIDDENR1 {}XBOOLE-0K1"
        using A3 funcop_1_th_7 sorry
      also have "... = FuncsFUNCT-2K1(f .FUNCT-1K1 x,{}XBOOLE-0K1)"
        using A4 sorry
      finally show "(domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1).FUNCT-1K1 x =HIDDENR1 FuncsFUNCT-2K1(f .FUNCT-1K1 x,{}XBOOLE-0K1)"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1) =XBOOLE-0R4 domRELAT-1K1 f"
      using funcop_1_th_13 sorry
    thus "FuncsFUNCT-6K7(f,{}XBOOLE-0K1) =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1"
      using A2 funct_6_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_47:
" for X be setHIDDENM2 holds FuncsFUNCT-6K7({}XBOOLE-0K1,X) =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds FuncsFUNCT-6K7({}XBOOLE-0K1,X) =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "domRELAT-1K1 (FuncsFUNCT-6K7({}XBOOLE-0K1,X)) =XBOOLE-0R4 domRELAT-1K1 ({}XBOOLE-0K1)"
      using funct_6_def_8 sorry
    thus "FuncsFUNCT-6K7({}XBOOLE-0K1,X) =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_48:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds FuncsFUNCT-6K7(X -->FUNCOP-1K7 Y,Z) =FUNCT-1R1 X -->FUNCOP-1K7 FuncsFUNCT-2K1(Y,Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds FuncsFUNCT-6K7(X -->FUNCOP-1K7 Y,Z) =FUNCT-1R1 X -->FUNCOP-1K7 FuncsFUNCT-2K1(Y,Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have A1: "X =XBOOLE-0R4 domRELAT-1K1 (X -->FUNCOP-1K7 Y)"
      using funcop_1_th_13 sorry
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies FuncsFUNCT-6K7(X -->FUNCOP-1K7 Y,Z) .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(Y,Z)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 X"
      then have "FuncsFUNCT-6K7(X -->FUNCOP-1K7 Y,Z) .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1((X -->FUNCOP-1K7 Y).FUNCT-1K1 x,Z)"
        using A1 funct_6_def_8 sorry
      thus "FuncsFUNCT-6K7(X -->FUNCOP-1K7 Y,Z) .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(Y,Z)"
        using A3 funcop_1_th_7 sorry
    qed "sorry"
    have "domRELAT-1K1 (FuncsFUNCT-6K7(X -->FUNCOP-1K7 Y,Z)) =XBOOLE-0R4 domRELAT-1K1 (X -->FUNCOP-1K7 Y)"
      using funct_6_def_8 sorry
    thus "FuncsFUNCT-6K7(X -->FUNCOP-1K7 Y,Z) =FUNCT-1R1 X -->FUNCOP-1K7 FuncsFUNCT-2K1(Y,Z)"
      using A1 A2 funcop_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma funct_6_lm_3:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f & g =FUNCT-1R1 curryFUNCT-5K1 f .FUNCT-1K1 x) & z inHIDDENR3 domRELAT-1K1 g implies [TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f implies (g =FUNCT-1R1 curryFUNCT-5K1 f .FUNCT-1K1 x & z inHIDDENR3 domRELAT-1K1 g implies [TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    assume "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 f"
    then have "x inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 f)"
      using xtuple_0_def_12 sorry
    then have A1: " ex g9 be FunctionFUNCT-1M1 st (curryFUNCT-5K1 f .FUNCT-1K1 x =FUNCT-1R1 g9 & domRELAT-1K1 g9 =XBOOLE-0R4 proj2XTUPLE-0K13 (domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]))) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g9 implies g9 .FUNCT-1K1 y =XBOOLE-0R4 f .BINOP-1K1(x,y))"
      using funct_5_def_1 sorry
    assume "g =FUNCT-1R1 curryFUNCT-5K1 f .FUNCT-1K1 x & z inHIDDENR3 domRELAT-1K1 g"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A2: "[TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 ([:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :])"
      using A1 xtuple_0_def_13 sorry
    have "[TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},proj2XTUPLE-0K13 (domRELAT-1K1 f) :]"
      using A2 xboole_0_def_4 sorry
    then have A3: "y inHIDDENR3 {TARSKIK1 x}"
      using zfmisc_1_th_87 sorry
    have "[TARSKIK4 y,z ] inHIDDENR3 domRELAT-1K1 f"
      using A2 xboole_0_def_4 sorry
    thus "[TARSKIK4 x,z ] inHIDDENR3 domRELAT-1K1 f"
      using A3 tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_49:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X),productCARD-3K4 (FuncsFUNCT-6K7(f,X)))are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X),productCARD-3K4 (FuncsFUNCT-6K7(f,X)))are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st  ex h be FunctionFUNCT-1M1 st ((Lamb1 =HIDDENR1 g & Lamb2 =HIDDENR1 h) & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies h .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies h .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 g .FUNCT-1K1 y))"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X) implies ( ex z be objectHIDDENM1 st ?P(x,z))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X) implies ( ex z be FunctionFUNCT-1M1 st  ex tVar8 be FunctionFUNCT-1M1 st  ex tVar9 be FunctionFUNCT-1M1 st ((x =HIDDENR1 tVar8 & z =FUNCT-1R1 tVar9) & domRELAT-1K1 tVar9 =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies tVar9 .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies tVar9 .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 tVar8 .FUNCT-1K1 y)))"
      proof(rule ballI,rule impI)
        let ?P = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1 =XBOOLE-0R4 {}XBOOLE-0K1"
        let ?F = "\<lambda>Lamb1. {}XBOOLE-0K1"
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X)"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A2: "x =HIDDENR1 g"and "domRELAT-1K1 g =XBOOLE-0R4 UnionCARD-3K3 disjoinCARD-3K2 f"and "rngFUNCT-1K2 g c=TARSKIR1 X"
          using funct_2_def_2 sorry
        let ?G = "\<lambda>Lamb1. curry'FUNCT-5K3 g .FUNCT-1K1 Lamb1"
        obtain h where
          [ty]:"h be FunctionFUNCT-1M1" and 
          A3: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (?P(y) implies h .FUNCT-1K1 y =XBOOLE-0R4 ?F(y)) & ( not ?P(y) implies h .FUNCT-1K1 y =XBOOLE-0R4 ?G(y)))"
          using partfun1_sch_1 sorry
        obtain z where 
          [ty]:"z be FunctionFUNCT-1M1" and zDef:"z = h"
           sorry
        show " ex z be FunctionFUNCT-1M1 st  ex tVar8 be FunctionFUNCT-1M1 st  ex tVar9 be FunctionFUNCT-1M1 st ((x =HIDDENR1 tVar8 & z =FUNCT-1R1 tVar9) & domRELAT-1K1 tVar9 =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies tVar9 .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies tVar9 .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 tVar8 .FUNCT-1K1 y))"
        proof(rule bexI[of _ "z"])
          show " ex tVar8 be FunctionFUNCT-1M1 st  ex tVar9 be FunctionFUNCT-1M1 st ((x =HIDDENR1 tVar8 & z =FUNCT-1R1 tVar9) & domRELAT-1K1 tVar9 =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies tVar9 .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies tVar9 .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 tVar8 .FUNCT-1K1 y))"
          proof(rule bexI[of _ "g"])
            show " ex tVar9 be FunctionFUNCT-1M1 st ((x =HIDDENR1 g & z =FUNCT-1R1 tVar9) & domRELAT-1K1 tVar9 =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies tVar9 .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies tVar9 .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 g .FUNCT-1K1 y))"
            proof(rule bexI[of _ "h"])
              show "((x =HIDDENR1 g & z =FUNCT-1R1 h) & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies h .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies h .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 g .FUNCT-1K1 y))"
                using A2 A3 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain F where
      [ty]:"F be FunctionFUNCT-1M1" and 
      A4: "domRELAT-1K1 F =XBOOLE-0R4 FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X) & ( for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X) implies ?P(x,F .FUNCT-1K1 x))"
      using classes1_sch_1 A1 sorry
    have "F be one-to-oneFUNCT-1V2 & (domRELAT-1K1 F =XBOOLE-0R4 FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X) & rngRELAT-1K2 F =HIDDENR1 productCARD-3K4 (FuncsFUNCT-6K7(f,X)))"
    proof(rule conjMI,rule conjMI)
      show "F be one-to-oneFUNCT-1V2"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F & (y inHIDDENR3 domRELAT-1K1 F & F .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 y) implies x =HIDDENR1 y"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 F"
            and A6: "y inHIDDENR3 domRELAT-1K1 F"
            and A7: "F .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 y"
          have A8: " ex f2 be FunctionFUNCT-1M1 st (y =HIDDENR1 f2 & domRELAT-1K1 f2 =XBOOLE-0R4 UnionCARD-3K3 disjoinCARD-3K2 f) & rngFUNCT-1K2 f2 c=TARSKIR1 X"
            using A4 A6 funct_2_def_2 sorry
          obtain g1 h1 where
            [ty]:"g1 be FunctionFUNCT-1M1" "h1 be FunctionFUNCT-1M1" and 
            A9: "x =HIDDENR1 g1"and A10: "F .FUNCT-1K1 x =XBOOLE-0R4 h1"and "domRELAT-1K1 h1 =XBOOLE-0R4 domRELAT-1K1 f"and A11: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies h1 .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies h1 .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 g1 .FUNCT-1K1 y)"
            using A4 A5 sorry
          obtain g2 h2 where
            [ty]:"g2 be FunctionFUNCT-1M1" "h2 be FunctionFUNCT-1M1" and 
            A12: "y =HIDDENR1 g2"and A13: "F .FUNCT-1K1 y =XBOOLE-0R4 h2"and "domRELAT-1K1 h2 =XBOOLE-0R4 domRELAT-1K1 f"and A14: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies h2 .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies h2 .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 g2 .FUNCT-1K1 y)"
            using A4 A6 sorry
          have A15: " ex f1 be FunctionFUNCT-1M1 st (x =HIDDENR1 f1 & domRELAT-1K1 f1 =XBOOLE-0R4 UnionCARD-3K3 disjoinCARD-3K2 f) & rngFUNCT-1K2 f1 c=TARSKIR1 X"
            using A4 A5 funct_2_def_2 sorry
          have " for z be objectHIDDENM1 holds z inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f implies g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A16: "z inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f"
            then have A17: "z =HIDDENR1 [TARSKIK4 z `1XTUPLE-0K1,z `2XTUPLE-0K2 ]"
              using card_3_th_22 sorry
            have A18: "z `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f & z `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 z `2XTUPLE-0K2"
              using A16 card_3_th_22 sorry
            then have A19: "h2 .FUNCT-1K1 z `2XTUPLE-0K2 =XBOOLE-0R4 curry'FUNCT-5K3 g2 .FUNCT-1K1 z `2XTUPLE-0K2"
              using A14 sorry
            then obtain g91 g92 where 
              [ty]:"g91 be FunctionFUNCT-1M1" and g91Def:"g91 = h1 .FUNCT-1K1 z `2XTUPLE-0K2" and
              [ty]:"g92 be FunctionFUNCT-1M1" and g92Def:"g92 = h2 .FUNCT-1K1 z `2XTUPLE-0K2"
              using A7 A10 A13 sorry
            have A20: "g2 .BINOP-1K1(z `1XTUPLE-0K1,z `2XTUPLE-0K2) =XBOOLE-0R4 g92 .FUNCT-1K1 z `1XTUPLE-0K1"
              using A8 A12 A16 A17 A19 funct_5_th_22 sorry
            have "h1 .FUNCT-1K1 z `2XTUPLE-0K2 =XBOOLE-0R4 curry'FUNCT-5K3 g1 .FUNCT-1K1 z `2XTUPLE-0K2"
              using A11 A18 sorry
            then have "g1 .BINOP-1K1(z `1XTUPLE-0K1,z `2XTUPLE-0K2) =XBOOLE-0R4 g91 .FUNCT-1K1 z `1XTUPLE-0K1"
              using A15 A9 A16 A17 funct_5_th_22 sorry
            thus "g1 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z"
              using A7 A10 A13 A17 A20 sorry
          qed "sorry"
          thus "x =HIDDENR1 y"
            using A15 A8 A9 A12 funct_1_th_2 sorry
        qed "sorry"
        thus "F be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      show "domRELAT-1K1 F =XBOOLE-0R4 FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X)"
        using A4 sorry
      have "rngFUNCT-1K2 F c=TARSKIR1 productCARD-3K4 (FuncsFUNCT-6K7(f,X)) & productCARD-3K4 (FuncsFUNCT-6K7(f,X)) c=TARSKIR1 rngRELAT-1K2 F"
      proof(rule conjMI)
        show "rngFUNCT-1K2 F c=TARSKIR1 productCARD-3K4 (FuncsFUNCT-6K7(f,X))"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 F implies y inHIDDENR3 productCARD-3K4 (FuncsFUNCT-6K7(f,X))"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 F"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A21: "x inHIDDENR3 domRELAT-1K1 F"and A22: "y =HIDDENR1 F .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            obtain g h where
              [ty]:"g be FunctionFUNCT-1M1" "h be FunctionFUNCT-1M1" and 
              A23: "x =HIDDENR1 g"and A24: "F .FUNCT-1K1 x =XBOOLE-0R4 h"and A25: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"and A26: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies h .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies h .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 g .FUNCT-1K1 y)"
              using A4 A21 sorry
            have A27: " ex f1 be FunctionFUNCT-1M1 st (x =HIDDENR1 f1 & domRELAT-1K1 f1 =XBOOLE-0R4 UnionCARD-3K3 disjoinCARD-3K2 f) & rngFUNCT-1K2 f1 c=TARSKIR1 X"
              using A4 A21 funct_2_def_2 sorry
            have A28: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (FuncsFUNCT-6K7(f,X)) implies h .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 domRELAT-1K1 (FuncsFUNCT-6K7(f,X))"
              then have A29: "z inHIDDENR3 domRELAT-1K1 f"
                using funct_6_def_8 sorry
              then have A30: "FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 z,X)"
                using funct_6_def_8 sorry
              have A31: "f .FUNCT-1K1 z <>HIDDENR2 {}XBOOLE-0K1 implies h .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z"
              proof(rule impI)
                let ?a = "the ElementSUBSET-1M1-of f .FUNCT-1K1 z"
                assume A32: "f .FUNCT-1K1 z <>HIDDENR2 {}XBOOLE-0K1"
                have "[TARSKIK4 ?a,z ] `1XTUPLE-0K1 =HIDDENR1 ?a & [TARSKIK4 ?a,z ] `2XTUPLE-0K2 =HIDDENR1 z"
                   sorry
                then have A33: "[TARSKIK4 ?a,z ] inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f"
                  using A29 A32 card_3_th_22 sorry
                obtain k where 
                  [ty]:"k be FunctionFUNCT-1M1" and kDef:"k = curry'FUNCT-5K3 g .FUNCT-1K1 z"
                   sorry
                have A34: "z inHIDDENR3 domRELAT-1K1 (curry'FUNCT-5K3 g)"
                  using A23 A27 A33 funct_5_th_21 sorry
                then have "rngFUNCT-1K2 k c=TARSKIR1 rngFUNCT-1K2 g"
                  using funct_5_th_34 sorry
                then have A35: "rngFUNCT-1K2 k c=TARSKIR1 X"
                  using A23 A27 sorry
                have A36: "domRELAT-1K1 k =XBOOLE-0R4 proj1XTUPLE-0K12 (domRELAT-1K1 g /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 g),{TARSKIK1 z} :]))"
                  using A34 funct_5_th_34 sorry
                have A37: "domRELAT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 z"
                proof-
                  have "domRELAT-1K1 k c=TARSKIR1 f .FUNCT-1K1 z & f .FUNCT-1K1 z c=TARSKIR1 domRELAT-1K1 k"
                  proof(rule conjMI)
                    show "domRELAT-1K1 k c=TARSKIR1 f .FUNCT-1K1 z"
                    proof-
                      have " for b be objectHIDDENM1 holds b inHIDDENR3 domRELAT-1K1 k implies b inHIDDENR3 f .FUNCT-1K1 z"
                      proof(rule ballI,rule impI)
                        fix b assume [ty]: "b be objectHIDDENM1"
                        assume "b inHIDDENR3 domRELAT-1K1 k"
                        then obtain c where
                          [ty]:"c be objectHIDDENM1" and 
                          A38: "[TARSKIK4 b,c ] inHIDDENR3 domRELAT-1K1 g /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 g),{TARSKIK1 z} :])"
                          using A36 xtuple_0_def_12 sorry
                        have "[TARSKIK4 b,c ] inHIDDENR3 [:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 g),{TARSKIK1 z} :]"
                          using A38 xboole_0_def_4 sorry
                        then have A39: "c inHIDDENR3 {TARSKIK1 z}"
                          using zfmisc_1_th_87 sorry
                        have A40: "[TARSKIK4 b,c ] `1XTUPLE-0K1 =HIDDENR1 b & [TARSKIK4 b,c ] `2XTUPLE-0K2 =HIDDENR1 c"
                           sorry
                        have "[TARSKIK4 b,c ] inHIDDENR3 domRELAT-1K1 g"
                          using A38 xboole_0_def_4 sorry
                        then have "b inHIDDENR3 f .FUNCT-1K1 c"
                          using A23 A27 A40 card_3_th_22 sorry
                        thus "b inHIDDENR3 f .FUNCT-1K1 z"
                          using A39 tarski_def_1 sorry
                      qed "sorry"
                      thus "domRELAT-1K1 k c=TARSKIR1 f .FUNCT-1K1 z"
                        using tarski_def_3 sorry
                    qed
                    have " for b be objectHIDDENM1 holds b inHIDDENR3 f .FUNCT-1K1 z implies b inHIDDENR3 domRELAT-1K1 k"
                    proof(rule ballI,rule impI)
                      fix b assume [ty]: "b be objectHIDDENM1"
                      assume A41: "b inHIDDENR3 f .FUNCT-1K1 z"
                      have A42: "z inHIDDENR3 {TARSKIK1 z}"
                        using tarski_def_1 sorry
                      have "[TARSKIK4 b,z ] `1XTUPLE-0K1 =HIDDENR1 b & [TARSKIK4 b,z ] `2XTUPLE-0K2 =HIDDENR1 z"
                         sorry
                      then have A43: "[TARSKIK4 b,z ] inHIDDENR3 domRELAT-1K1 g"
                        using A23 A27 A29 A41 card_3_th_22 sorry
                      then have "b inHIDDENR3 proj1XTUPLE-0K12 (domRELAT-1K1 g)"
                        using xtuple_0_def_12 sorry
                      then have "[TARSKIK4 b,z ] inHIDDENR3 [:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 g),{TARSKIK1 z} :]"
                        using A42 zfmisc_1_th_87 sorry
                      then have "[TARSKIK4 b,z ] inHIDDENR3 domRELAT-1K1 g /\\XBOOLE-0K3 ([:ZFMISC-1K2 proj1XTUPLE-0K12 (domRELAT-1K1 g),{TARSKIK1 z} :])"
                        using A43 xboole_0_def_4 sorry
                      thus "b inHIDDENR3 domRELAT-1K1 k"
                        using A36 xtuple_0_def_12 sorry
                    qed "sorry"
                    thus "f .FUNCT-1K1 z c=TARSKIR1 domRELAT-1K1 k"
                      using tarski_def_3 sorry
                  qed
                  thus "domRELAT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 z"
                    using xboole_0_def_10 sorry
                qed
                have "h .FUNCT-1K1 z =XBOOLE-0R4 k"
                  using A26 A29 A32 sorry
                thus "h .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z"
                  using A30 A35 A37 funct_2_def_2 sorry
              qed
              have "f .FUNCT-1K1 z =XBOOLE-0R4 {}XBOOLE-0K1 implies h .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z"
              proof(rule impI)
                assume "f .FUNCT-1K1 z =XBOOLE-0R4 {}XBOOLE-0K1"
                then have "h .FUNCT-1K1 z =XBOOLE-0R4 {}XBOOLE-0K1 & FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
                  using A26 A29 A30 funct_5_th_57 sorry
                thus "h .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z"
                  using tarski_def_1 sorry
              qed
              thus "h .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z"
                using A31 sorry
            qed "sorry"
            have "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 (FuncsFUNCT-6K7(f,X))"
              using A25 funct_6_def_8 sorry
            thus "y inHIDDENR3 productCARD-3K4 (FuncsFUNCT-6K7(f,X))"
              using A22 A24 A28 card_3_def_5 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 F c=TARSKIR1 productCARD-3K4 (FuncsFUNCT-6K7(f,X))"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (FuncsFUNCT-6K7(f,X)) implies x inHIDDENR3 rngRELAT-1K2 F"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 productCARD-3K4 (FuncsFUNCT-6K7(f,X))"
          then obtain s where
            [ty]:"s be FunctionFUNCT-1M1" and 
            A44: "x =HIDDENR1 s"and A45: "domRELAT-1K1 s =XBOOLE-0R4 domRELAT-1K1 (FuncsFUNCT-6K7(f,X))"and A46: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (FuncsFUNCT-6K7(f,X)) implies s .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z"
            using card_3_def_5 sorry
          have A47: "domRELAT-1K1 s =XBOOLE-0R4 domRELAT-1K1 f"
            using A45 funct_6_def_8 sorry
          have A48: "uncurry'FUNCT-5K4 s =FUNCT-1R1 ~FUNCT-4K2 (uncurryFUNCT-5K2 s)"
            using funct_5_def_4 sorry
          have A49: "domRELAT-1K1 (uncurry'FUNCT-5K4 s) =XBOOLE-0R4 UnionCARD-3K3 disjoinCARD-3K2 f"
          proof-
            have "domRELAT-1K1 (uncurry'FUNCT-5K4 s) c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 f & UnionCARD-3K3 disjoinCARD-3K2 f c=TARSKIR1 domRELAT-1K1 (uncurry'FUNCT-5K4 s)"
            proof(rule conjMI)
              show "domRELAT-1K1 (uncurry'FUNCT-5K4 s) c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 f"
              proof-
                have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 s) implies z inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f"
                proof(rule ballI,rule impI)
                  fix z assume [ty]: "z be objectHIDDENM1"
                  assume A50: "z inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 s)"
                  then obtain z1 z2 where
                    [ty]:"z1 be objectHIDDENM1" "z2 be objectHIDDENM1" and 
                    A51: "z =HIDDENR1 [TARSKIK4 z1,z2 ]"
                    using A48 funct_6_th_2 sorry
                  have A52: "z `1XTUPLE-0K1 =HIDDENR1 z1 & z `2XTUPLE-0K2 =HIDDENR1 z2"
                    using A51 sorry
                  have "[TARSKIK4 z2,z1 ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 s)"
                    using A48 A50 A51 funct_4_th_42 sorry
                  then obtain a u b where
                    [ty]:"a be objectHIDDENM1" "u be FunctionFUNCT-1M1" "b be objectHIDDENM1" and 
                    A53: "[TARSKIK4 z2,z1 ] =HIDDENR1 [TARSKIK4 a,b ]"and A54: "a inHIDDENR3 domRELAT-1K1 s"and A55: "u =XBOOLE-0R4 s .FUNCT-1K1 a"and A56: "b inHIDDENR3 domRELAT-1K1 u"
                    using funct_5_def_2 sorry
                  have A57: "[TARSKIK4 a,b ] `1XTUPLE-0K1 =HIDDENR1 a & [TARSKIK4 z2,z1 ] `1XTUPLE-0K1 =HIDDENR1 z2"
                     sorry
                  have "u inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 a & FuncsFUNCT-6K7(f,X) .FUNCT-1K1 a =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 a,X)"
                    using A45 A46 A47 A54 A55 funct_6_def_8 sorry
                  then have A58: " ex j be FunctionFUNCT-1M1 st (u =FUNCT-1R1 j & domRELAT-1K1 j =XBOOLE-0R4 f .FUNCT-1K1 z2) & rngFUNCT-1K2 j c=TARSKIR1 X"
                    using A53 A57 funct_2_def_2 sorry
                  have "[TARSKIK4 a,b ] `2XTUPLE-0K2 =HIDDENR1 b & [TARSKIK4 z2,z1 ] `2XTUPLE-0K2 =HIDDENR1 z1"
                     sorry
                  thus "z inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f"
                    using A47 A51 A53 A54 A56 A52 A57 A58 card_3_th_22 sorry
                qed "sorry"
                thus "domRELAT-1K1 (uncurry'FUNCT-5K4 s) c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 f"
                  using tarski_def_3 sorry
              qed
              have " for z be objectHIDDENM1 holds z inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f implies z inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 s)"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume A59: "z inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f"
                then have A60: "z `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 z `2XTUPLE-0K2 & z =HIDDENR1 [TARSKIK4 z `1XTUPLE-0K1,z `2XTUPLE-0K2 ]"
                  using card_3_th_22 sorry
                have A61: "z `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f"
                  using A59 card_3_th_22 sorry
                then have "s .FUNCT-1K1 z `2XTUPLE-0K2 inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z `2XTUPLE-0K2 & FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z `2XTUPLE-0K2 =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 z `2XTUPLE-0K2,X)"
                  using A45 A46 A47 funct_6_def_8 sorry
                then have " ex j be FunctionFUNCT-1M1 st (s .FUNCT-1K1 z `2XTUPLE-0K2 =XBOOLE-0R4 j & domRELAT-1K1 j =XBOOLE-0R4 f .FUNCT-1K1 z `2XTUPLE-0K2) & rngFUNCT-1K2 j c=TARSKIR1 X"
                  using funct_2_def_2 sorry
                thus "z inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 s)"
                  using A47 A61 A60 funct_5_th_39 sorry
              qed "sorry"
              thus "UnionCARD-3K3 disjoinCARD-3K2 f c=TARSKIR1 domRELAT-1K1 (uncurry'FUNCT-5K4 s)"
                using tarski_def_3 sorry
            qed
            thus "domRELAT-1K1 (uncurry'FUNCT-5K4 s) =XBOOLE-0R4 UnionCARD-3K3 disjoinCARD-3K2 f"
              using xboole_0_def_10 sorry
          qed
          have "rngFUNCT-1K2 (uncurry'FUNCT-5K4 s) c=TARSKIR1 X"
          proof-
            have " for d be objectHIDDENM1 holds d inHIDDENR3 rngFUNCT-1K2 (uncurry'FUNCT-5K4 s) implies d inHIDDENR3 X"
            proof(rule ballI,rule impI)
              fix d assume [ty]: "d be objectHIDDENM1"
              assume "d inHIDDENR3 rngFUNCT-1K2 (uncurry'FUNCT-5K4 s)"
              then obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A62: "z inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 s)"and A63: "d =HIDDENR1 uncurry'FUNCT-5K4 s .FUNCT-1K1 z"
                using funct_1_def_3 sorry
              obtain z1 z2 where
                [ty]:"z1 be objectHIDDENM1" "z2 be objectHIDDENM1" and 
                A64: "z =HIDDENR1 [TARSKIK4 z1,z2 ]"
                using A48 A62 funct_6_th_2 sorry
              have "[TARSKIK4 z2,z1 ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 s)"
                using A48 A62 A64 funct_4_th_42 sorry
              then obtain a u b where
                [ty]:"a be objectHIDDENM1" "u be FunctionFUNCT-1M1" "b be objectHIDDENM1" and 
                A65: "[TARSKIK4 z2,z1 ] =HIDDENR1 [TARSKIK4 a,b ]"and A66: "a inHIDDENR3 domRELAT-1K1 s & u =XBOOLE-0R4 s .FUNCT-1K1 a"and A67: "b inHIDDENR3 domRELAT-1K1 u"
                using funct_5_def_2 sorry
              have A68: "[TARSKIK4 a,b ] `1XTUPLE-0K1 =HIDDENR1 a & [TARSKIK4 z2,z1 ] `1XTUPLE-0K1 =HIDDENR1 z2"
                 sorry
              have "u inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 a & FuncsFUNCT-6K7(f,X) .FUNCT-1K1 a =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 a,X)"
                using A45 A46 A47 A66 funct_6_def_8 sorry
              then have A69: " ex j be FunctionFUNCT-1M1 st (u =FUNCT-1R1 j & domRELAT-1K1 j =XBOOLE-0R4 f .FUNCT-1K1 z2) & rngFUNCT-1K2 j c=TARSKIR1 X"
                using A65 A68 funct_2_def_2 sorry
              have A70: "[TARSKIK4 a,b ] `2XTUPLE-0K2 =HIDDENR1 b & [TARSKIK4 z2,z1 ] `2XTUPLE-0K2 =HIDDENR1 z1"
                 sorry
              have "uncurry'FUNCT-5K4 s .BINOP-1K1(b,a) =XBOOLE-0R4 u .FUNCT-1K1 b"
                using A66 A67 funct_5_th_39 sorry
              then have "d inHIDDENR3 rngFUNCT-1K2 u"
                using A63 A64 A65 A67 A68 A70 funct_1_def_3 sorry
              thus "d inHIDDENR3 X"
                using A69 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 (uncurry'FUNCT-5K4 s) c=TARSKIR1 X"
              using tarski_def_3 sorry
          qed
          then have A71: "uncurry'FUNCT-5K4 s inTARSKIR2 domRELAT-1K1 F"
            using A4 A49 funct_2_def_2 sorry
          then obtain g h where
            [ty]:"g be FunctionFUNCT-1M1" "h be FunctionFUNCT-1M1" and 
            A72: "uncurry'FUNCT-5K4 s =FUNCT-1R1 g"and A73: "F .FUNCT-1K1 uncurry'FUNCT-5K4 s =XBOOLE-0R4 h"and A74: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"and A75: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1 implies h .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1) & (f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies h .FUNCT-1K1 y =XBOOLE-0R4 curry'FUNCT-5K3 g .FUNCT-1K1 y)"
            using A4 sorry
          have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies s .FUNCT-1K1 z =XBOOLE-0R4 h .FUNCT-1K1 z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A76: "z inHIDDENR3 domRELAT-1K1 f"
            then have "s .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z & FuncsFUNCT-6K7(f,X) .FUNCT-1K1 z =XBOOLE-0R4 FuncsFUNCT-2K1(f .FUNCT-1K1 z,X)"
              using A45 A46 A47 funct_6_def_8 sorry
            then obtain v where
              [ty]:"v be FunctionFUNCT-1M1" and 
              A77: "s .FUNCT-1K1 z =XBOOLE-0R4 v"and A78: "domRELAT-1K1 v =XBOOLE-0R4 f .FUNCT-1K1 z"and "rngFUNCT-1K2 v c=TARSKIR1 X"
              using funct_2_def_2 sorry
            have A79: "f .FUNCT-1K1 z <>HIDDENR2 {}XBOOLE-0K1 implies s .FUNCT-1K1 z =XBOOLE-0R4 h .FUNCT-1K1 z"
            proof(rule impI)
              let ?a = "the ElementSUBSET-1M1-of f .FUNCT-1K1 z"
              assume A80: "f .FUNCT-1K1 z <>HIDDENR2 {}XBOOLE-0K1"
              then have A81: "[TARSKIK4 ?a,z ] inHIDDENR3 domRELAT-1K1 (uncurry'FUNCT-5K4 s)"
                using A47 A76 A77 A78 funct_5_th_39 sorry
              obtain j where 
                [ty]:"j be FunctionFUNCT-1M1" and jDef:"j = curry'FUNCT-5K3 (uncurry'FUNCT-5K4 s) .FUNCT-1K1 z"
                 sorry
              have A82: "j =FUNCT-1R1 curryFUNCT-5K1 (~FUNCT-4K2 (uncurry'FUNCT-5K4 s)) .FUNCT-1K1 z"
                using funct_5_def_3 sorry
              have A83: "~FUNCT-4K2 (uncurry'FUNCT-5K4 s) =FUNCT-1R1 uncurryFUNCT-5K2 s"
                using funct_6_th_4 sorry
              then have A84: "[TARSKIK4 z,?a ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 s)"
                using A81 funct_4_th_42 sorry
              have A85: "domRELAT-1K1 j =XBOOLE-0R4 domRELAT-1K1 v"
              proof-
                have "domRELAT-1K1 j c=TARSKIR1 domRELAT-1K1 v & domRELAT-1K1 v c=TARSKIR1 domRELAT-1K1 j"
                proof(rule conjMI)
                  show "domRELAT-1K1 j c=TARSKIR1 domRELAT-1K1 v"
                  proof-
                    have " for b be objectHIDDENM1 holds b inHIDDENR3 domRELAT-1K1 j implies b inHIDDENR3 domRELAT-1K1 v"
                    proof(rule ballI,rule impI)
                      fix b assume [ty]: "b be objectHIDDENM1"
                      assume "b inHIDDENR3 domRELAT-1K1 j"
                      then have "[TARSKIK4 z,b ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 s)"
                        using A82 A83 A84 funct_6_lm_3 sorry
                      then obtain a1 g1 a2 where
                        [ty]:"a1 be objectHIDDENM1" "g1 be FunctionFUNCT-1M1" "a2 be objectHIDDENM1" and 
                        A86: "[TARSKIK4 z,b ] =HIDDENR1 [TARSKIK4 a1,a2 ]"and "a1 inHIDDENR3 domRELAT-1K1 s"and A87: "g1 =XBOOLE-0R4 s .FUNCT-1K1 a1 & a2 inHIDDENR3 domRELAT-1K1 g1"
                        using funct_5_def_2 sorry
                      have "z =HIDDENR1 a1"
                        using A86 xtuple_0_th_1 sorry
                      thus "b inHIDDENR3 domRELAT-1K1 v"
                        using A77 A86 A87 xtuple_0_th_1 sorry
                    qed "sorry"
                    thus "domRELAT-1K1 j c=TARSKIR1 domRELAT-1K1 v"
                      using tarski_def_3 sorry
                  qed
                  have " for b be objectHIDDENM1 holds b inHIDDENR3 domRELAT-1K1 v implies b inHIDDENR3 domRELAT-1K1 j"
                  proof(rule ballI,rule impI)
                    fix b assume [ty]: "b be objectHIDDENM1"
                    assume "b inHIDDENR3 domRELAT-1K1 v"
                    then have "[TARSKIK4 z,b ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 s)"
                      using A47 A76 A77 funct_5_th_38 sorry
                    thus "b inHIDDENR3 domRELAT-1K1 j"
                      using A82 A83 funct_5_th_20 sorry
                  qed "sorry"
                  thus "domRELAT-1K1 v c=TARSKIR1 domRELAT-1K1 j"
                    using tarski_def_3 sorry
                qed
                thus "domRELAT-1K1 j =XBOOLE-0R4 domRELAT-1K1 v"
                  using xboole_0_def_10 sorry
              qed
              have " for b be objectHIDDENM1 holds b inHIDDENR3 f .FUNCT-1K1 z implies j .FUNCT-1K1 b =XBOOLE-0R4 v .FUNCT-1K1 b"
              proof(rule ballI,rule impI)
                fix b assume [ty]: "b be objectHIDDENM1"
                assume "b inHIDDENR3 f .FUNCT-1K1 z"
                then have A88: "[TARSKIK4 z,b ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 s)"
                  using A78 A82 A83 A84 A85 funct_6_lm_3 sorry
                then obtain a1 g1 a2 where
                  [ty]:"a1 be objectHIDDENM1" "g1 be FunctionFUNCT-1M1" "a2 be objectHIDDENM1" and 
                  A89: "[TARSKIK4 z,b ] =HIDDENR1 [TARSKIK4 a1,a2 ]"and A90: "(a1 inHIDDENR3 domRELAT-1K1 s & g1 =XBOOLE-0R4 s .FUNCT-1K1 a1) & a2 inHIDDENR3 domRELAT-1K1 g1"
                  using funct_5_def_2 sorry
                have A91: "j .FUNCT-1K1 b =XBOOLE-0R4 uncurryFUNCT-5K2 s .BINOP-1K1(z,b)"
                  using A82 A83 A88 funct_5_th_20 sorry
                have "z =HIDDENR1 a1 & b =HIDDENR1 a2"
                  using A89 xtuple_0_th_1 sorry
                thus "j .FUNCT-1K1 b =XBOOLE-0R4 v .FUNCT-1K1 b"
                  using A77 A90 A91 funct_5_th_38 sorry
              qed "sorry"
              then have "v =FUNCT-1R1 j"
                using A78 A85 sorry
              thus "s .FUNCT-1K1 z =XBOOLE-0R4 h .FUNCT-1K1 z"
                using A72 A75 A76 A77 A80 sorry
            qed
            have "f .FUNCT-1K1 z =XBOOLE-0R4 {}XBOOLE-0K1 implies s .FUNCT-1K1 z =XBOOLE-0R4 {}XBOOLE-0K1 & h .FUNCT-1K1 z =XBOOLE-0R4 {}XBOOLE-0K1"
              using A75 A76 A77 A78 sorry
            thus "s .FUNCT-1K1 z =XBOOLE-0R4 h .FUNCT-1K1 z"
              using A79 sorry
          qed "sorry"
          then have "h =FUNCT-1R1 s"
            using A47 A74 sorry
          thus "x inHIDDENR3 rngRELAT-1K2 F"
            using A44 A71 A73 funct_1_def_3 sorry
        qed "sorry"
        thus "productCARD-3K4 (FuncsFUNCT-6K7(f,X)) c=TARSKIR1 rngRELAT-1K2 F"
          using tarski_def_3 sorry
      qed
      thus "rngRELAT-1K2 F =HIDDENR1 productCARD-3K4 (FuncsFUNCT-6K7(f,X))"
        using xboole_0_def_10 sorry
    qed
    thus "(FuncsFUNCT-2K1(UnionCARD-3K3 disjoinCARD-3K2 f,X),productCARD-3K4 (FuncsFUNCT-6K7(f,X)))are-equipotentWELLORD2R2"
      using bexI[of _ "F"] wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_6_def_9 ("FuncsFUNCT-6K8'( _ , _ ')" [0,0]228 ) where
  mlet "X be setHIDDENM2", "f be FunctionFUNCT-1M1"
"func FuncsFUNCT-6K8(X,f) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x))"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x)))))"
      proof-
        let ?F = "\<lambda>Lamb1. FuncsFUNCT-2K1(X,f .FUNCT-1K1 Lamb1)"
        have " ex F be FunctionFUNCT-1M1 st domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies F .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x)))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it2 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x)) & (domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f2 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x)))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x)"
          and A3: "domRELAT-1K1 f2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f2 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 f"
          then have "f1 .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x)"
            using A2 sorry
          thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
            using A4 A5 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma funct_6_lm_4:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f <>HIDDENR2 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 implies (productCARD-3K4 (FuncsFUNCT-6K8(X,f)),FuncsFUNCT-2K1(X,productCARD-3K4 f))are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f <>HIDDENR2 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 implies (productCARD-3K4 (FuncsFUNCT-6K8(X,f)),FuncsFUNCT-2K1(X,productCARD-3K4 f))are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 st Lamb1 =HIDDENR1 g & Lamb2 =HIDDENR1 <:FUNCT-6K5 g:>"
    assume A1: "f <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X <>HIDDENR2 {}XBOOLE-0K1"
    have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (FuncsFUNCT-6K8(X,f)) implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (FuncsFUNCT-6K8(X,f)) implies ( ex tVar11 be objectHIDDENM1 st  ex tVar12 be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 st x =HIDDENR1 tVar12 & tVar11 =HIDDENR1 <:FUNCT-6K5 tVar12:>)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 (FuncsFUNCT-6K8(X,f))"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A4: "(x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (FuncsFUNCT-6K8(X,f))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (FuncsFUNCT-6K8(X,f)) implies g .FUNCT-1K1 x inTARSKIR2 FuncsFUNCT-6K8(X,f) .FUNCT-1K1 x)"
          using card_3_def_5 sorry
        have "g be Function-yieldingFUNCOP-1V1"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x be FunctionFUNCT-1M1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 g"
            then have A6: "g .FUNCT-1K1 x inTARSKIR2 FuncsFUNCT-6K8(X,f) .FUNCT-1K1 x"
              using A4 sorry
            have "x inHIDDENR3 domRELAT-1K1 f"
              using A5 A4 funct_6_def_9 sorry
            then have "g .FUNCT-1K1 x inTARSKIR2 FuncsFUNCT-2K1(X,f .FUNCT-1K1 x)"
              using A6 funct_6_def_9 sorry
            thus "g .FUNCT-1K1 x be FunctionFUNCT-1M1"
               sorry
          qed "sorry"
          thus "g be Function-yieldingFUNCOP-1V1"
            using funcop_1_def_6 sorry
        qed
        then obtain g where 
          [ty]:"g be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1" and gDef:"g = x"
          using A4 sorry
        obtain y where 
          [ty]:"y be setHIDDENM2" and yDef:"y = <:FUNCT-6K5 g:>"
           sorry
        show " ex tVar11 be objectHIDDENM1 st  ex tVar12 be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 st x =HIDDENR1 tVar12 & tVar11 =HIDDENR1 <:FUNCT-6K5 tVar12:>"
        proof(rule bexI[of _ "y"])
          show " ex tVar12 be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 st x =HIDDENR1 tVar12 & y =HIDDENR1 <:FUNCT-6K5 tVar12:>"
          proof(rule bexI[of _ "g"])
            show "x =HIDDENR1 g & y =HIDDENR1 <:FUNCT-6K5 g:>"
               sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain F where
      [ty]:"F be FunctionFUNCT-1M1" and 
      A7: "domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 (FuncsFUNCT-6K8(X,f)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (FuncsFUNCT-6K8(X,f)) implies ?P(x,F .FUNCT-1K1 x))"
      using classes1_sch_1 A3 sorry
    have A8: " for g be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 (FuncsFUNCT-6K8(X,f)) implies (domRELAT-1K1 (<:FUNCT-6K5 g:>) =XBOOLE-0R4 X & rngFUNCT-1K2 g =XBOOLE-0R4 rngFUNCT-1K2 g) & rngFUNCT-1K2 (<:FUNCT-6K5 g:>) c=TARSKIR1 productCARD-3K4 f"
    proof(rule ballI,rule impI,rule conjMI)
      fix g assume [ty]: "g be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
      have A9: "domRELAT-1K1 (FuncsFUNCT-6K8(X,f)) =XBOOLE-0R4 domRELAT-1K1 f"
        using funct_6_def_9 sorry
      assume A10: "g inTARSKIR2 productCARD-3K4 (FuncsFUNCT-6K8(X,f))"
      then have A11: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (FuncsFUNCT-6K8(X,f))"
        using card_3_th_9 sorry
      have A12: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies (domRELAT-1K1 f -->FUNCOP-1K7 X).FUNCT-1K1 z =XBOOLE-0R4 proj1XTUPLE-0K12 (g .FUNCT-1K1 z)"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A13: "z inHIDDENR3 domRELAT-1K1 f"
        then have "g .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z & FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 z)"
          using A10 A9 funct_6_def_9 card_3_th_9 sorry
        then have " ex h be FunctionFUNCT-1M1 st (g .FUNCT-1K1 z =FUNCT-1R1 h & domRELAT-1K1 h =XBOOLE-0R4 X) & rngFUNCT-1K2 h c=TARSKIR1 f .FUNCT-1K1 z"
          using funct_2_def_2 sorry
        thus "(domRELAT-1K1 f -->FUNCOP-1K7 X).FUNCT-1K1 z =XBOOLE-0R4 proj1XTUPLE-0K12 (g .FUNCT-1K1 z)"
          using A13 funcop_1_th_7 sorry
      qed "sorry"
      have "domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K7 X) =XBOOLE-0R4 domRELAT-1K1 f"
        using funcop_1_th_13 sorry
      then have "domsFUNCT-6K1 g =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 X"
        using A11 A9 A12 funct_6_def_2 sorry
      then have "meetFUNCT-6K3 (domsFUNCT-6K1 g) =XBOOLE-0R4 X"
        using A1 funct_6_th_27 sorry
      thus A14: "domRELAT-1K1 (<:FUNCT-6K5 g:>) =XBOOLE-0R4 X & rngFUNCT-1K2 g =XBOOLE-0R4 rngFUNCT-1K2 g"
        using funct_6_th_29 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (<:FUNCT-6K5 g:>) implies y inHIDDENR3 productCARD-3K4 f"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 (<:FUNCT-6K5 g:>)"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A15: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-6K5 g:>)"and A16: "y =HIDDENR1 (<:FUNCT-6K5 g:>).FUNCT-1K1 x"
          using funct_1_def_3 sorry
        obtain h where 
          [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = y"
          using A16 sorry
        have A17: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
          using A11 A9 A15 A16 funct_6_th_31 sorry
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies h .FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A18: "z inHIDDENR3 domRELAT-1K1 f"
          then have A19: "uncurryFUNCT-5K2 g .BINOP-1K1(z,x) =XBOOLE-0R4 h .FUNCT-1K1 z"
            using A15 A16 A17 funct_6_th_31 sorry
          have "g .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z & FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 z)"
            using A10 A9 A18 funct_6_def_9 card_3_th_9 sorry
          then obtain j where
            [ty]:"j be FunctionFUNCT-1M1" and 
            A20: "g .FUNCT-1K1 z =FUNCT-1R1 j"and A21: "domRELAT-1K1 j =XBOOLE-0R4 X"and A22: "rngFUNCT-1K2 j c=TARSKIR1 f .FUNCT-1K1 z"
            using funct_2_def_2 sorry
          have A23: "j .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 j"
            using A14 A15 A21 funct_1_def_3 sorry
          have "uncurryFUNCT-5K2 g .BINOP-1K1(z,x) =XBOOLE-0R4 j .FUNCT-1K1 x"
            using A11 A9 A14 A15 A18 A20 A21 funct_5_th_38 sorry
          thus "h .FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
            using A22 A19 A23 sorry
        qed "sorry"
        thus "y inHIDDENR3 productCARD-3K4 f"
          using A17 card_3_def_5 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (<:FUNCT-6K5 g:>) c=TARSKIR1 productCARD-3K4 f"
        using tarski_def_3 sorry
    qed "sorry"
    have "F be one-to-oneFUNCT-1V2 & (domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 (FuncsFUNCT-6K8(X,f)) & rngRELAT-1K2 F =HIDDENR1 FuncsFUNCT-2K1(X,productCARD-3K4 f))"
    proof(rule conjMI,rule conjMI)
      show "F be one-to-oneFUNCT-1V2"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F & (y inHIDDENR3 domRELAT-1K1 F & (F .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 y & x <>HIDDENR2 y)) implies  not  True "
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A24: "x inHIDDENR3 domRELAT-1K1 F"
            and A25: "y inHIDDENR3 domRELAT-1K1 F"
            and A26: "F .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 y"
            and A27: "x <>HIDDENR2 y"
          obtain gy where
            [ty]:"gy be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1" and 
            A28: "y =HIDDENR1 gy"and A29: "F .FUNCT-1K1 y =XBOOLE-0R4 <:FUNCT-6K5 gy:>"
            using A7 A25 sorry
          obtain gx where
            [ty]:"gx be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1" and 
            A30: "x =HIDDENR1 gx"and A31: "F .FUNCT-1K1 x =XBOOLE-0R4 <:FUNCT-6K5 gx:>"
            using A7 A24 sorry
          have A32: "domRELAT-1K1 gx =XBOOLE-0R4 domRELAT-1K1 (FuncsFUNCT-6K8(X,f))"
            using A7 A24 A30 card_3_th_9 sorry
          have A33: "domRELAT-1K1 (FuncsFUNCT-6K8(X,f)) =XBOOLE-0R4 domRELAT-1K1 f"
            using funct_6_def_9 sorry
          have A34: "domRELAT-1K1 gy =XBOOLE-0R4 domRELAT-1K1 (FuncsFUNCT-6K8(X,f))"
            using A7 A25 A28 card_3_th_9 sorry
          have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies gx .FUNCT-1K1 z =FUNCT-1R1 gy .FUNCT-1K1 z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A35: "z inHIDDENR3 domRELAT-1K1 f"
            then have A36: "FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z =XBOOLE-0R4 FuncsFUNCT-2K1(X,f .FUNCT-1K1 z)"
              using funct_6_def_9 sorry
            have "gy .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z"
              using A7 A25 A28 A33 A35 card_3_th_9 sorry
            then obtain hy where
              [ty]:"hy be FunctionFUNCT-1M1" and 
              A37: "gy .FUNCT-1K1 z =FUNCT-1R1 hy & domRELAT-1K1 hy =XBOOLE-0R4 X"and "rngFUNCT-1K2 hy c=TARSKIR1 f .FUNCT-1K1 z"
              using A36 funct_2_def_2 sorry
            have "gx .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z"
              using A7 A24 A30 A33 A35 card_3_th_9 sorry
            then obtain hx where
              [ty]:"hx be FunctionFUNCT-1M1" and 
              A38: "gx .FUNCT-1K1 z =FUNCT-1R1 hx & domRELAT-1K1 hx =XBOOLE-0R4 X"and "rngFUNCT-1K2 hx c=TARSKIR1 f .FUNCT-1K1 z"
              using A36 funct_2_def_2 sorry
            have A39: "domRELAT-1K1 (<:FUNCT-6K5 gx:>) =XBOOLE-0R4 X"
              using A7 A8 A24 A30 sorry
            have " for b be objectHIDDENM1 holds b inHIDDENR3 X implies hx .FUNCT-1K1 b =XBOOLE-0R4 hy .FUNCT-1K1 b"
            proof(rule ballI,rule impI)
              fix b assume [ty]: "b be objectHIDDENM1"
              assume A40: "b inHIDDENR3 X"
              obtain fx where 
                [ty]:"fx be FunctionFUNCT-1M1" and fxDef:"fx = (<:FUNCT-6K5 gx:>).FUNCT-1K1 b"
                 sorry
              have A41: "uncurryFUNCT-5K2 gx .BINOP-1K1(z,b) =XBOOLE-0R4 hx .FUNCT-1K1 b & uncurryFUNCT-5K2 gy .BINOP-1K1(z,b) =XBOOLE-0R4 hy .FUNCT-1K1 b"
                using A32 A34 A33 A35 A38 A37 A40 funct_5_th_38 sorry
              have A42: "domRELAT-1K1 fx =XBOOLE-0R4 domRELAT-1K1 gx"
                using A39 A40 funct_6_th_31 sorry
              then have "fx .FUNCT-1K1 z =XBOOLE-0R4 uncurryFUNCT-5K2 gx .BINOP-1K1(z,b)"
                using A32 A33 A35 A39 A40 funct_6_th_31 sorry
              thus "hx .FUNCT-1K1 b =XBOOLE-0R4 hy .FUNCT-1K1 b"
                using A26 A31 A29 A32 A33 A35 A39 A40 A42 A41 funct_6_th_31 sorry
            qed "sorry"
            thus "gx .FUNCT-1K1 z =FUNCT-1R1 gy .FUNCT-1K1 z"
              using A38 A37 sorry
          qed "sorry"
          thus " not  True "
            using A27 A30 A28 A32 A34 A33 funct_1_th_2 sorry
        qed "sorry"
        thus "F be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      show "domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 (FuncsFUNCT-6K8(X,f))"
        using A7 sorry
      have "rngFUNCT-1K2 F c=TARSKIR1 FuncsFUNCT-2K1(X,productCARD-3K4 f) & FuncsFUNCT-2K1(X,productCARD-3K4 f) c=TARSKIR1 rngRELAT-1K2 F"
      proof(rule conjMI)
        show "rngFUNCT-1K2 F c=TARSKIR1 FuncsFUNCT-2K1(X,productCARD-3K4 f)"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 F implies y inHIDDENR3 FuncsFUNCT-2K1(X,productCARD-3K4 f)"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 F"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A43: "x inHIDDENR3 domRELAT-1K1 F"and A44: "y =HIDDENR1 F .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            obtain g where
              [ty]:"g be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1" and 
              A45: "x =HIDDENR1 g"and A46: "y =HIDDENR1 <:FUNCT-6K5 g:>"
              using A7 A43 A44 sorry
            have "domRELAT-1K1 (<:FUNCT-6K5 g:>) =XBOOLE-0R4 X & rngFUNCT-1K2 (<:FUNCT-6K5 g:>) c=TARSKIR1 productCARD-3K4 f"
              using A7 A8 A43 A45 sorry
            thus "y inHIDDENR3 FuncsFUNCT-2K1(X,productCARD-3K4 f)"
              using A46 funct_2_def_2 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 F c=TARSKIR1 FuncsFUNCT-2K1(X,productCARD-3K4 f)"
            using tarski_def_3 sorry
        qed
        have " for y be objectHIDDENM1 holds y inHIDDENR3 FuncsFUNCT-2K1(X,productCARD-3K4 f) implies y inHIDDENR3 rngRELAT-1K2 F"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 FuncsFUNCT-2K1(X,productCARD-3K4 f)"
          then obtain h where
            [ty]:"h be FunctionFUNCT-1M1" and 
            A47: "y =HIDDENR1 h"and A48: "domRELAT-1K1 h =XBOOLE-0R4 X"and A49: "rngFUNCT-1K2 h c=TARSKIR1 productCARD-3K4 f"
            using funct_2_def_2 sorry
          have "h be Function-yieldingFUNCOP-1V1"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x be setHIDDENM2"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 domRELAT-1K1 h"
              then have "h .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 h"
                using funct_1_th_3 sorry
              then have "h .FUNCT-1K1 x be ElementSUBSET-1M1-of productCARD-3K4 f"
                using A49 sorry
              thus "h .FUNCT-1K1 x be setHIDDENM2"
                 sorry
            qed "sorry"
            thus "h be Function-yieldingFUNCOP-1V1"
              using funcop_1_def_6 sorry
          qed
          then have 
            [ty]:"h be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
             sorry
          let ?g = "<:FUNCT-6K5 h:>"
          have A50: " for z be objectHIDDENM1 holds z inHIDDENR3 X implies (X -->FUNCOP-1K7 domRELAT-1K1 f).FUNCT-1K1 z =HIDDENR1 domsFUNCT-6K1 h .FUNCT-1K1 z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A51: "z inHIDDENR3 X"
            then have "h .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 h"
              using A48 funct_1_def_3 sorry
            then have A52: " ex j be FunctionFUNCT-1M1 st (h .FUNCT-1K1 z =FUNCT-1R1 j & domRELAT-1K1 j =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies j .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
              using A49 card_3_def_5 sorry
            have "(X -->FUNCOP-1K7 domRELAT-1K1 f).FUNCT-1K1 z =HIDDENR1 domRELAT-1K1 f"
              using A51 funcop_1_th_7 sorry
            also have "... = domsFUNCT-6K1 h .FUNCT-1K1 z"
              using A48 A51 A52 funct_6_th_22 sorry
            finally show "(X -->FUNCOP-1K7 domRELAT-1K1 f).FUNCT-1K1 z =HIDDENR1 domsFUNCT-6K1 h .FUNCT-1K1 z"
               sorry
          qed "sorry"
          have A53: "meetFUNCT-6K3 (domsFUNCT-6K1 h) =XBOOLE-0R4 domRELAT-1K1 ?g"
            using funct_6_th_29 sorry
          have "domRELAT-1K1 (domsFUNCT-6K1 h) =XBOOLE-0R4 domRELAT-1K1 h & domRELAT-1K1 (domRELAT-1K1 h -->FUNCOP-1K7 domRELAT-1K1 f) =XBOOLE-0R4 domRELAT-1K1 h"
            using funct_6_def_2 funcop_1_th_13 sorry
          then have "X -->FUNCOP-1K7 domRELAT-1K1 f =FUNCT-1R1 domsFUNCT-6K1 h"
            using A48 A50 sorry
          then have A54: "domRELAT-1K1 ?g =XBOOLE-0R4 domRELAT-1K1 f"
            using A2 A53 funct_6_th_27 sorry
          have A55: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies (<:FUNCT-6K5 h:>).FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A56: "z inHIDDENR3 domRELAT-1K1 f"
            obtain i where 
              [ty]:"i be FunctionFUNCT-1M1" and iDef:"i = ?g .FUNCT-1K1 z"
               sorry
            have A57: "domRELAT-1K1 i =XBOOLE-0R4 X"
              using A48 A54 A56 funct_6_th_31 sorry
            have "rngFUNCT-1K2 i c=TARSKIR1 f .FUNCT-1K1 z"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 i implies x inHIDDENR3 f .FUNCT-1K1 z"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 i"
                then obtain a where
                  [ty]:"a be objectHIDDENM1" and 
                  A58: "a inHIDDENR3 domRELAT-1K1 i"and A59: "x =HIDDENR1 i .FUNCT-1K1 a"
                  using funct_1_def_3 sorry
                have "h .FUNCT-1K1 a inTARSKIR2 rngFUNCT-1K2 h"
                  using A48 A57 A58 funct_1_def_3 sorry
                then obtain j where
                  [ty]:"j be FunctionFUNCT-1M1" and 
                  A60: "h .FUNCT-1K1 a =FUNCT-1R1 j & domRELAT-1K1 j =XBOOLE-0R4 domRELAT-1K1 f"and A61: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies j .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
                  using A49 card_3_def_5 sorry
                have "i .FUNCT-1K1 a =HIDDENR1 uncurryFUNCT-5K2 h .BINOP-1K1(a,z)"
                  using A54 A56 A58 funct_6_th_31 sorry
                also have "... = j .FUNCT-1K1 z"
                  using A48 A56 A57 A58 A60 funct_5_th_38 sorry
                finally have "i .FUNCT-1K1 a =HIDDENR1 j .FUNCT-1K1 z"
                   sorry
                thus "x inHIDDENR3 f .FUNCT-1K1 z"
                  using A56 A59 A61 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 i c=TARSKIR1 f .FUNCT-1K1 z"
                using tarski_def_3 sorry
            qed
            then have "?g .FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-2K1(X,f .FUNCT-1K1 z)"
              using A57 funct_2_def_2 sorry
            thus "(<:FUNCT-6K5 h:>).FUNCT-1K1 z inTARSKIR2 FuncsFUNCT-6K8(X,f) .FUNCT-1K1 z"
              using A56 funct_6_def_9 sorry
          qed "sorry"
          have A62: "meetFUNCT-6K3 (domsFUNCT-6K1 ?g) =XBOOLE-0R4 domRELAT-1K1 (<:FUNCT-6K5 ?g:>)"
            using funct_6_th_29 sorry
          have "productCARD-3K4 f c=TARSKIR1 FuncsFUNCT-2K1(domRELAT-1K1 f,UnionCARD-3K3 f)"
            using funct_6_th_1 sorry
          then have A63: "rngFUNCT-1K2 h c=TARSKIR1 FuncsFUNCT-2K1(domRELAT-1K1 f,UnionCARD-3K3 f)"
            using A49 sorry
          then have A64: "domRELAT-1K1 (uncurryFUNCT-5K2 h) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 h,domRELAT-1K1 f :]"
            using funct_5_th_26 sorry
          have "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (FuncsFUNCT-6K8(X,f))"
            using funct_6_def_9 sorry
          then have A65: "?g inTARSKIR2 productCARD-3K4 (FuncsFUNCT-6K8(X,f))"
            using A54 A55 card_3_def_5 sorry
          then have A66: " ex g9 be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 st ?g =FUNCT-1R1 g9 & F .FUNCT-1K1 ?g =XBOOLE-0R4 <:FUNCT-6K5 g9:>"
            using A7 sorry
          have "domRELAT-1K1 (uncurry'FUNCT-5K4 h) =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 f,domRELAT-1K1 h :]"
            using A63 funct_5_th_26 sorry
          then have A67: "uncurry'FUNCT-5K4 h  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 h),domRELAT-1K1 h :]) =FUNCT-1R1 uncurry'FUNCT-5K4 h"
            using A53 A54 sorry
          have A68: "uncurry'FUNCT-5K4 h =FUNCT-1R1 ~FUNCT-4K2 (uncurryFUNCT-5K2 h) & curryFUNCT-5K1 (~FUNCT-4K2 (uncurryFUNCT-5K2 h)) =FUNCT-1R1 curry'FUNCT-5K3 (uncurryFUNCT-5K2 h)"
            using funct_5_def_3 funct_5_def_4 sorry
          have "domRELAT-1K1 (<:FUNCT-6K5 ?g:>) =XBOOLE-0R4 X"
            using A8 A65 sorry
          then have A69: "uncurryFUNCT-5K2 h  |RELAT-1K8 ([:ZFMISC-1K2 meetFUNCT-6K3 (domsFUNCT-6K1 ?g),domRELAT-1K1 ?g :]) =FUNCT-1R1 uncurryFUNCT-5K2 h"
            using A48 A54 A64 A62 sorry
          have "uncurry'FUNCT-5K4 (curry'FUNCT-5K3 (uncurryFUNCT-5K2 h)) =FUNCT-1R1 uncurryFUNCT-5K2 h"
            using A64 funct_5_th_49 sorry
          then have "<:FUNCT-6K5 ?g:> =FUNCT-1R1 h"
            using A1 A63 A67 A69 A68 funct_5_th_48 sorry
          thus "y inHIDDENR3 rngRELAT-1K2 F"
            using A7 A47 A65 A66 funct_1_def_3 sorry
        qed "sorry"
        thus "FuncsFUNCT-2K1(X,productCARD-3K4 f) c=TARSKIR1 rngRELAT-1K2 F"
          using tarski_def_3 sorry
      qed
      thus "rngRELAT-1K2 F =HIDDENR1 FuncsFUNCT-2K1(X,productCARD-3K4 f)"
        using xboole_0_def_10 sorry
    qed
    thus "(productCARD-3K4 (FuncsFUNCT-6K8(X,f)),FuncsFUNCT-2K1(X,productCARD-3K4 f))are-equipotentWELLORD2R2"
      using bexI[of _ "F"] wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_50:
" for f be FunctionFUNCT-1M1 holds FuncsFUNCT-6K8({}XBOOLE-0K1,f) =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for f be FunctionFUNCT-1M1 holds FuncsFUNCT-6K8({}XBOOLE-0K1,f) =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies FuncsFUNCT-6K8({}XBOOLE-0K1,f) .FUNCT-1K1 x =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 f"
      then have "FuncsFUNCT-6K8({}XBOOLE-0K1,f) .FUNCT-1K1 x =HIDDENR1 FuncsFUNCT-2K1({}XBOOLE-0K1,f .FUNCT-1K1 x)"
        using funct_6_def_9 sorry
      also have "... = {TARSKIK1 {}XBOOLE-0K1 }"
        using funct_5_th_57 sorry
      finally show "FuncsFUNCT-6K8({}XBOOLE-0K1,f) .FUNCT-1K1 x =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (FuncsFUNCT-6K8({}XBOOLE-0K1,f)) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_6_def_9 sorry
    thus "FuncsFUNCT-6K8({}XBOOLE-0K1,f) =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
      using A1 funcop_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_51:
" for X be setHIDDENM2 holds FuncsFUNCT-6K8(X,{}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds FuncsFUNCT-6K8(X,{}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "domRELAT-1K1 (FuncsFUNCT-6K8(X,{}XBOOLE-0K1)) =XBOOLE-0R4 domRELAT-1K1 ({}XBOOLE-0K1)"
      using funct_6_def_9 sorry
    thus "FuncsFUNCT-6K8(X,{}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_52:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds FuncsFUNCT-6K8(X,Y -->FUNCOP-1K7 Z) =FUNCT-1R1 Y -->FUNCOP-1K7 FuncsFUNCT-2K1(X,Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds FuncsFUNCT-6K8(X,Y -->FUNCOP-1K7 Z) =FUNCT-1R1 Y -->FUNCOP-1K7 FuncsFUNCT-2K1(X,Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have A1: "Y =XBOOLE-0R4 domRELAT-1K1 (Y -->FUNCOP-1K7 Z)"
      using funcop_1_th_13 sorry
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies FuncsFUNCT-6K8(X,Y -->FUNCOP-1K7 Z) .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,Z)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 Y"
      then have "FuncsFUNCT-6K8(X,Y -->FUNCOP-1K7 Z) .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,(Y -->FUNCOP-1K7 Z).FUNCT-1K1 x)"
        using A1 funct_6_def_9 sorry
      thus "FuncsFUNCT-6K8(X,Y -->FUNCOP-1K7 Z) .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(X,Z)"
        using A3 funcop_1_th_7 sorry
    qed "sorry"
    have "domRELAT-1K1 (FuncsFUNCT-6K8(X,Y -->FUNCOP-1K7 Z)) =XBOOLE-0R4 domRELAT-1K1 (Y -->FUNCOP-1K7 Z)"
      using funct_6_def_9 sorry
    thus "FuncsFUNCT-6K8(X,Y -->FUNCOP-1K7 Z) =FUNCT-1R1 Y -->FUNCOP-1K7 FuncsFUNCT-2K1(X,Z)"
      using A1 A2 funcop_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_53:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (productCARD-3K4 (FuncsFUNCT-6K8(X,f)),FuncsFUNCT-2K1(X,productCARD-3K4 f))are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (productCARD-3K4 (FuncsFUNCT-6K8(X,f)),FuncsFUNCT-2K1(X,productCARD-3K4 f))are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "FuncsFUNCT-2K9(X,productCARD-3K4 ({}XBOOLE-0K1)) =XBOOLE-0R4 {TARSKIK1 X -->FUNCOP-1K7 {}XBOOLE-0K1 }"
      using card_3_th_10 funct_5_th_59 sorry
    have A2: "productCARD-3K4 (FuncsFUNCT-6K8({}XBOOLE-0K1,f)) =HIDDENR1 productCARD-3K4 (domRELAT-1K1 f -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })"
      using funct_6_th_50 sorry
    also have "... = FuncsFUNCT-2K9(domRELAT-1K1 f,{TARSKIK1 {}XBOOLE-0K1 })"
      using card_3_th_11 sorry
    also have "... = {TARSKIK1 domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1 }"
      using funct_5_th_59 sorry
    finally have "productCARD-3K4 (FuncsFUNCT-6K8({}XBOOLE-0K1,f)) =HIDDENR1 {TARSKIK1 domRELAT-1K1 f -->FUNCOP-1K7 {}XBOOLE-0K1 }"
       sorry
    have A3: "FuncsFUNCT-2K1({}XBOOLE-0K1,productCARD-3K4 f) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 } & productCARD-3K4 (FuncsFUNCT-6K8(X,{}XBOOLE-0K1)) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      using funct_6_th_51 card_3_th_10 funct_5_th_57 sorry
    have "X <>HIDDENR2 {}XBOOLE-0K1 & f <>HIDDENR2 {}XBOOLE-0K1 implies (productCARD-3K4 (FuncsFUNCT-6K8(X,f)),FuncsFUNCT-2K1(X,productCARD-3K4 f))are-equipotentWELLORD2R2"
      using funct_6_lm_4 sorry
    thus "(productCARD-3K4 (FuncsFUNCT-6K8(X,f)),FuncsFUNCT-2K1(X,productCARD-3K4 f))are-equipotentWELLORD2R2"
      using A2 A3 A1 card_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef funct_6_def_10 ("commuteFUNCT-6K9  _ " [164]164 ) where
  mlet "f be FunctionFUNCT-1M1"
"func commuteFUNCT-6K9 f \<rightarrow> Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 equals
  curry'FUNCT-5K3 (uncurryFUNCT-5K2 f)"
proof-
  (*coherence*)
    show "curry'FUNCT-5K3 (uncurryFUNCT-5K2 f) be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem funct_6_th_54:
" for f be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 (commuteFUNCT-6K9 f) implies (commuteFUNCT-6K9 f).FUNCT-1K1 x be FunctionFUNCT-1M1"
   sorry

mtheorem funct_6_th_55:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1) & f inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(B,C)) implies commuteFUNCT-6K9 f inTARSKIR2 FuncsFUNCT-2K1(B,FuncsFUNCT-2K1(A,C))"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  fix C assume [ty]: "C be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  assume "(A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1) & f inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(B,C))"
  then have "[:ZFMISC-1K2 A,B :] <>HIDDENR2 {}XBOOLE-0K1 & uncurryFUNCT-5K2 f inTARSKIR2 FuncsFUNCT-2K1([:ZFMISC-1K2 A,B :],C)"
    using funct_6_th_11 zfmisc_1_th_90 sorry
  thus "commuteFUNCT-6K9 f inTARSKIR2 FuncsFUNCT-2K1(B,FuncsFUNCT-2K1(A,C))"
    using funct_6_th_10 sorry
qed "sorry"

mtheorem funct_6_th_56:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1) & f inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(B,C)) implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds ((x inTARSKIR2 A & y inTARSKIR2 B) & f .FUNCT-1K1 x =XBOOLE-0R4 g) & (commuteFUNCT-6K9 f).FUNCT-1K1 y =FUNCT-1R1 h implies (((h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y & domRELAT-1K1 h =XBOOLE-0R4 A) & domRELAT-1K1 g =XBOOLE-0R4 B) & rngFUNCT-1K2 h c=TARSKIR1 C) & rngFUNCT-1K2 g c=TARSKIR1 C)"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1) & f inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(B,C)) implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 A & (y inTARSKIR2 B & (f .FUNCT-1K1 x =XBOOLE-0R4 g & (commuteFUNCT-6K9 f).FUNCT-1K1 y =FUNCT-1R1 h)) implies (((h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y & domRELAT-1K1 h =XBOOLE-0R4 A) & domRELAT-1K1 g =XBOOLE-0R4 B) & rngFUNCT-1K2 h c=TARSKIR1 C) & rngFUNCT-1K2 g c=TARSKIR1 C)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "f inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(B,C))"
    let ?uf = "uncurryFUNCT-5K2 f"
    let ?cf = "commuteFUNCT-6K9 f"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume A3: "x inTARSKIR2 A"
      and A4: "y inTARSKIR2 B"
      and A5: "f .FUNCT-1K1 x =XBOOLE-0R4 g"
      and A6: "(commuteFUNCT-6K9 f).FUNCT-1K1 y =FUNCT-1R1 h"
    have "commuteFUNCT-6K9 f inTARSKIR2 FuncsFUNCT-2K1(B,FuncsFUNCT-2K1(A,C))"
      using A1 A2 funct_6_th_55 sorry
    then have A7: " ex g be FunctionFUNCT-1M1 st (g =FUNCT-1R1 ?cf & domRELAT-1K1 g =XBOOLE-0R4 B) & rngFUNCT-1K2 g c=TARSKIR1 FuncsFUNCT-2K1(A,C)"
      using funct_2_def_2 sorry
    then have "?cf .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 ?cf"
      using A4 funct_1_def_3 sorry
    then have A8: " ex t be FunctionFUNCT-1M1 st (t =FUNCT-1R1 h & domRELAT-1K1 t =XBOOLE-0R4 A) & rngFUNCT-1K2 t c=TARSKIR1 C"
      using A6 A7 funct_2_def_2 sorry
    have A9: " ex g be FunctionFUNCT-1M1 st (g =FUNCT-1R1 f & domRELAT-1K1 g =XBOOLE-0R4 A) & rngFUNCT-1K2 g c=TARSKIR1 FuncsFUNCT-2K1(B,C)"
      using A2 funct_2_def_2 sorry
    then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
      using A3 funct_1_def_3 sorry
    then have A10: " ex t be FunctionFUNCT-1M1 st (t =FUNCT-1R1 g & domRELAT-1K1 t =XBOOLE-0R4 B) & rngFUNCT-1K2 t c=TARSKIR1 C"
      using A5 A9 funct_2_def_2 sorry
    then have "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 ?uf & ?uf .BINOP-1K1(x,y) =XBOOLE-0R4 g .FUNCT-1K1 y"
      using A3 A4 A5 A9 funct_5_th_38 sorry
    thus "(((h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y & domRELAT-1K1 h =XBOOLE-0R4 A) & domRELAT-1K1 g =XBOOLE-0R4 B) & rngFUNCT-1K2 h c=TARSKIR1 C) & rngFUNCT-1K2 g c=TARSKIR1 C"
      using A6 A10 A8 funct_5_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_6_th_57:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1) & f inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(B,C)) implies commuteFUNCT-6K9 (commuteFUNCT-6K9 f) =FUNCT-1R1 f"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  fix C assume [ty]: "C be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  assume A1: "A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1"
    and A2: "f inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(B,C))"
  have A3: " ex g be FunctionFUNCT-1M1 st (g =FUNCT-1R1 f & domRELAT-1K1 g =XBOOLE-0R4 A) & rngFUNCT-1K2 g c=TARSKIR1 FuncsFUNCT-2K1(B,C)"
    using A2 funct_2_def_2 sorry
  let ?cf = "commuteFUNCT-6K9 f"
  have A4: "commuteFUNCT-6K9 f inTARSKIR2 FuncsFUNCT-2K1(B,FuncsFUNCT-2K1(A,C))"
    using A1 A2 funct_6_th_55 sorry
  then have "commuteFUNCT-6K9 ?cf inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(B,C))"
    using A1 funct_6_th_55 sorry
  then have A5: " ex h be FunctionFUNCT-1M1 st (h =FUNCT-1R1 commuteFUNCT-6K9 ?cf & domRELAT-1K1 h =XBOOLE-0R4 A) & rngFUNCT-1K2 h c=TARSKIR1 FuncsFUNCT-2K1(B,C)"
    using funct_2_def_2 sorry
  have A6: " ex g be FunctionFUNCT-1M1 st (g =FUNCT-1R1 ?cf & domRELAT-1K1 g =XBOOLE-0R4 B) & rngFUNCT-1K2 g c=TARSKIR1 FuncsFUNCT-2K1(A,C)"
    using A4 funct_2_def_2 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies f .FUNCT-1K1 x =XBOOLE-0R4 (commuteFUNCT-6K9 ?cf).FUNCT-1K1 x"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies f .FUNCT-1K1 x =XBOOLE-0R4 (commuteFUNCT-6K9 (commuteFUNCT-6K9 f)).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      let ?ccf = "commuteFUNCT-6K9 ?cf"
      let ?uf = "uncurryFUNCT-5K2 f"
      let ?ucf = "uncurryFUNCT-5K2 ?cf"
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 A"
      then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
        using A3 funct_1_def_3 sorry
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A8: "g =XBOOLE-0R4 f .FUNCT-1K1 x & domRELAT-1K1 g =XBOOLE-0R4 B"and "rngFUNCT-1K2 g c=TARSKIR1 C"
        using A3 funct_2_def_2 sorry
      have "?ccf .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 ?ccf"
        using A5 A7 funct_1_def_3 sorry
      then obtain h where
        [ty]:"h be FunctionFUNCT-1M1" and 
        A9: "h =FUNCT-1R1 ?ccf .FUNCT-1K1 x"and A10: "domRELAT-1K1 h =XBOOLE-0R4 B"and "rngFUNCT-1K2 h c=TARSKIR1 C"
        using A5 funct_2_def_2 sorry
      have A11: " for y be objectHIDDENM1 holds y inHIDDENR3 B implies ( for h be FunctionFUNCT-1M1 holds h =FUNCT-1R1 ?cf .FUNCT-1K1 y implies x inHIDDENR3 domRELAT-1K1 h & h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y)"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 B implies ( for h be FunctionFUNCT-1M1 holds h =FUNCT-1R1 (commuteFUNCT-6K9 f).FUNCT-1K1 y implies x inHIDDENR3 domRELAT-1K1 h & h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y)"
        proof(rule ballI,rule impI,rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 B"
          then have A12: "[TARSKIK4 x,y ] inHIDDENR3 domRELAT-1K1 ?uf & ?uf .BINOP-1K1(x,y) =XBOOLE-0R4 g .FUNCT-1K1 y"
            using A3 A7 A8 funct_5_th_38 sorry
          fix h assume [ty]: "h be FunctionFUNCT-1M1"
          assume "h =FUNCT-1R1 ?cf .FUNCT-1K1 y"
          thus "x inHIDDENR3 domRELAT-1K1 h & h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
            using A12 funct_5_th_22 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A13: " for y be objectHIDDENM1 holds y inHIDDENR3 B implies [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 ?ucf & ?ucf .BINOP-1K1(y,x) =XBOOLE-0R4 g .FUNCT-1K1 y"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 B implies [TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 (commuteFUNCT-6K9 f)) & uncurryFUNCT-5K2 (commuteFUNCT-6K9 f) .BINOP-1K1(y,x) =XBOOLE-0R4 g .FUNCT-1K1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          obtain h where 
            [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = ?cf .FUNCT-1K1 y"
             sorry
          assume A14: "y inHIDDENR3 B"
          then have "x inHIDDENR3 domRELAT-1K1 h & h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
            using A11 sorry
          thus "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 (commuteFUNCT-6K9 f)) & uncurryFUNCT-5K2 (commuteFUNCT-6K9 f) .BINOP-1K1(y,x) =XBOOLE-0R4 g .FUNCT-1K1 y"
            using A6 A14 funct_5_th_38 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 B implies h .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 B"
        then have "[TARSKIK4 y,x ] inHIDDENR3 domRELAT-1K1 ?ucf & ?ucf .BINOP-1K1(y,x) =XBOOLE-0R4 g .FUNCT-1K1 y"
          using A13 sorry
        thus "h .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
          using A9 funct_5_th_22 sorry
      qed "sorry"
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 (commuteFUNCT-6K9 (commuteFUNCT-6K9 f)).FUNCT-1K1 x"
        using A8 A9 A10 funct_1_th_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "commuteFUNCT-6K9 (commuteFUNCT-6K9 f) =FUNCT-1R1 f"
    using A3 A5 sorry
qed "sorry"

mtheorem funct_6_th_58:
"commuteFUNCT-6K9 {}XBOOLE-0K1 =FUNCT-1R1 {}XBOOLE-0K1"
  using funct_5_th_42 funct_5_th_43 sorry

mtheorem funct_6_th_59:
" for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
  using funct_6_def_2 sorry

mtheorem funct_6_th_60:
" for f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (rngsFUNCT-6K2 f) =XBOOLE-0R4 domRELAT-1K1 f"
  using funct_6_def_3 sorry

end
