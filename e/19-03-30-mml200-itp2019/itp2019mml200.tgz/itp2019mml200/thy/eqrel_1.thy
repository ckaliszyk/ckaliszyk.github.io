theory eqrel_1
  imports domain_1 finseq_1 orders_1 setwiseo
   "../mizar_extension/E_number"
begin
(*begin*)
reserve X, Y, Z for "setHIDDENM2"
reserve x, y, z for "objectHIDDENM1"
reserve i, j for "NatNAT-1M1"
reserve A, B, C for "SubsetSUBSET-1M2-of X"
reserve R, R1, R2 for "RelationRELSET-1M2-of X"
reserve AX for "SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,X :]"
reserve SFXX for "Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,X :]"
mdef eqrel_1_def_1 ("nablaEQREL-1K1  _ " [164]164 ) where
  mlet "X be setHIDDENM2"
"func nablaEQREL-1K1 X \<rightarrow> RelationRELSET-1M2-of X equals
  [:ZFMISC-1K2 X,X :]"
proof-
  (*coherence*)
    show "[:ZFMISC-1K2 X,X :] be RelationRELSET-1M2-of X"
    proof-
      have "[:ZFMISC-1K2 X,X :] c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
         sorry
      thus "[:ZFMISC-1K2 X,X :] be RelationRELSET-1M2-of X"
         sorry
    qed
qed "sorry"

mtheorem eqrel_1_cl_1:
  mlet "X be setHIDDENM2"
"cluster nablaEQREL-1K1 X as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1"
proof
(*coherence*)
  show "nablaEQREL-1K1 X be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1"
  proof-
    have "nablaEQREL-1K1 X be totalPARTFUN1V1\<^bsub>(X)\<^esub> & nablaEQREL-1K1 X be reflexiveRELAT-2V1"
    proof-
      have "domRELSET-1K1\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X) c=TARSKIR1 X & (X c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X) & nablaEQREL-1K1 X be reflexiveRELAT-2V1)"
      proof(rule conjMI,rule conjMI)
        show "domRELSET-1K1\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X) c=TARSKIR1 X"
           sorry
        show "X c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X)"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X"
            then have "[TARSKIK4 x,x ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
              using zfmisc_1_th_87 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X)"
              using xtuple_0_def_12 sorry
          qed "sorry"
          thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X)"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 (nablaEQREL-1K1 X) implies [TARSKIK4 x,x ] inHIDDENR3 nablaEQREL-1K1 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 fieldRELAT-1K3 (nablaEQREL-1K1 X)"
          then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X) \\/SUBSET-1K4\<^bsub>(X)\<^esub> rngRELSET-1K2\<^bsub>(X)\<^esub> (nablaEQREL-1K1 X)"
             sorry
          thus "[TARSKIK4 x,x ] inHIDDENR3 nablaEQREL-1K1 X"
            using zfmisc_1_th_87 sorry
        qed "sorry"
        thus "nablaEQREL-1K1 X be reflexiveRELAT-2V1"
          using relat_2_def_1 relat_2_def_9 sorry
      qed
      thus "nablaEQREL-1K1 X be totalPARTFUN1V1\<^bsub>(X)\<^esub> & nablaEQREL-1K1 X be reflexiveRELAT-2V1"
        using xboole_0_def_10 partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax EQREL_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/'\\EQREL-1K2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "R1 /\\EQREL-1K2\<^bsub>(X)\<^esub> R2" \<rightharpoonup> "R1 /\\XBOOLE-0K3 R2"

mtheorem eqrel_1_add_1:
  mlet "X be setHIDDENM2", "R1 be RelationRELSET-1M2-of X", "R2 be RelationRELSET-1M2-of X"
"cluster R1 /\\XBOOLE-0K3 R2 as-term-is RelationRELSET-1M2-of X"
proof
(*coherence*)
  show "R1 /\\XBOOLE-0K3 R2 be RelationRELSET-1M2-of X"
  proof-
    have "R1 /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> R2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> [:ZFMISC-1K2 X,X :]"
       sorry
    thus "R1 /\\XBOOLE-0K3 R2 be RelationRELSET-1M2-of X"
       sorry
  qed
qed "sorry"

syntax EQREL_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\'/EQREL-1K3\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "R1 \\/EQREL-1K3\<^bsub>(X)\<^esub> R2" \<rightharpoonup> "R1 \\/XBOOLE-0K2 R2"

mtheorem eqrel_1_add_2:
  mlet "X be setHIDDENM2", "R1 be RelationRELSET-1M2-of X", "R2 be RelationRELSET-1M2-of X"
"cluster R1 \\/XBOOLE-0K2 R2 as-term-is RelationRELSET-1M2-of X"
proof
(*coherence*)
  show "R1 \\/XBOOLE-0K2 R2 be RelationRELSET-1M2-of X"
  proof-
    have "R1 \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> R2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> [:ZFMISC-1K2 X,X :]"
       sorry
    thus "R1 \\/XBOOLE-0K2 R2 be RelationRELSET-1M2-of X"
       sorry
  qed
qed "sorry"

mtheorem eqrel_1_th_1:
" for X be setHIDDENM2 holds  for R1 be RelationRELSET-1M2-of X holds nablaEQREL-1K1 X \\/EQREL-1K3\<^bsub>(X)\<^esub> R1 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X"
  using xboole_1_th_12 sorry

mtheorem eqrel_1_th_2:
" for X be setHIDDENM2 holds (idPARTFUN1K6 X is-reflexive-inRELAT-2R1 X & idPARTFUN1K6 X is-symmetric-inRELAT-2R3 X) & idPARTFUN1K6 X is-transitive-inRELAT-2R8 X"
  using relat_1_def_10 sorry

syntax EQREL_1M1 :: " Set \<Rightarrow> Ty" ("ToleranceEQREL-1M1-of  _ " [70]70)
translations "ToleranceEQREL-1M1-of X" \<rightharpoonup> "totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>symmetricRELAT-2V3\<bar>RelationRELSET-1M2-of X"

syntax EQREL_1M2 :: " Set \<Rightarrow> Ty" ("Equivalence-RelationEQREL-1M2-of  _ " [70]70)
translations "Equivalence-RelationEQREL-1M2-of X" \<rightharpoonup> "totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>transitiveRELAT-2V8\<bar>RelationRELSET-1M2-of X"

mtheorem eqrel_1_th_3:
" for X be setHIDDENM2 holds idPARTFUN1K6 X be Equivalence-RelationEQREL-1M2-of X"
   sorry

mtheorem eqrel_1_th_4:
" for X be setHIDDENM2 holds nablaEQREL-1K1 X be Equivalence-RelationEQREL-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds nablaEQREL-1K1 X be Equivalence-RelationEQREL-1M2-of X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & [TARSKIK4 x,y ] inHIDDENR3 nablaEQREL-1K1 X implies [TARSKIK4 y,x ] inHIDDENR3 nablaEQREL-1K1 X"
      using zfmisc_1_th_88 sorry
    then have A1: "nablaEQREL-1K1 X is-symmetric-inRELAT-2R3 X"
       sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (((x inHIDDENR3 X & y inHIDDENR3 X) & z inHIDDENR3 X) & [TARSKIK4 x,y ] inHIDDENR3 nablaEQREL-1K1 X) & [TARSKIK4 y,z ] inHIDDENR3 nablaEQREL-1K1 X implies [TARSKIK4 x,z ] inHIDDENR3 nablaEQREL-1K1 X"
      using zfmisc_1_th_87 sorry
    then have A2: "nablaEQREL-1K1 X is-transitive-inRELAT-2R8 X"
       sorry
    have "fieldRELAT-1K3 (nablaEQREL-1K1 X) =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    thus "nablaEQREL-1K1 X be Equivalence-RelationEQREL-1M2-of X"
      using A1 A2 relat_2_def_11 relat_2_def_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_cl_2:
  mlet "X be setHIDDENM2"
"cluster nablaEQREL-1K1 X as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>transitiveRELAT-2V8"
proof
(*coherence*)
  show "nablaEQREL-1K1 X be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>transitiveRELAT-2V8"
    using eqrel_1_th_4 sorry
qed "sorry"

reserve EqR, EqR1, EqR2, EqR3 for "Equivalence-RelationEQREL-1M2-of X"
mlemma eqrel_1_lm_1:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELSET-1M2-of X holds [TARSKIK4 x,y ] inHIDDENR3 R implies x inHIDDENR3 X & y inHIDDENR3 X"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELSET-1M2-of X holds [TARSKIK4 x,y ] inHIDDENR3 R implies x inHIDDENR3 X & y inHIDDENR3 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELSET-1M2-of X"
    assume "[TARSKIK4 x,y ] inHIDDENR3 R"
    then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R & y inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> R"
      using xtuple_0_def_12 xtuple_0_def_13 sorry
    thus "x inHIDDENR3 X & y inHIDDENR3 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_5:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>RelationRELSET-1M2-of X holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>RelationRELSET-1M2-of X holds  not (x inHIDDENR3 X &  not [TARSKIK4 x,x ] inHIDDENR3 R)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix R assume [ty]: "R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>RelationRELSET-1M2-of X"
    have "fieldRELAT-1K3 R =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    then have "R is-reflexive-inRELAT-2R1 X"
      using relat_2_def_9 sorry
    thus " not (x inHIDDENR3 X &  not [TARSKIK4 x,x ] inHIDDENR3 R)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_6:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>RelationRELSET-1M2-of X holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 y,x ] inHIDDENR3 R"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>RelationRELSET-1M2-of X holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 y,x ] inHIDDENR3 R"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>RelationRELSET-1M2-of X"
    have "fieldRELAT-1K3 R =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    then have A1: "R is-symmetric-inRELAT-2R3 X"
      using relat_2_def_11 sorry
    assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
    then have "x inHIDDENR3 X & y inHIDDENR3 X"
      using eqrel_1_lm_1 sorry
    thus "[TARSKIK4 y,x ] inHIDDENR3 R"
      using A2 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_7:
" for X be setHIDDENM2 holds  for z be objectHIDDENM1 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>transitiveRELAT-2V8\<bar>RelationRELSET-1M2-of X holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R"
proof-
  have " for X be setHIDDENM2 holds  for z be objectHIDDENM1 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>transitiveRELAT-2V8\<bar>RelationRELSET-1M2-of X holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 R"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix R assume [ty]: "R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>transitiveRELAT-2V8\<bar>RelationRELSET-1M2-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 R"
      and A2: "[TARSKIK4 y,z ] inHIDDENR3 R"
    have A3: "z inHIDDENR3 X"
      using A2 eqrel_1_lm_1 sorry
    have "fieldRELAT-1K3 R =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    then have A4: "R is-transitive-inRELAT-2R8 X"
      using relat_2_def_16 sorry
    have "x inHIDDENR3 X & y inHIDDENR3 X"
      using A1 eqrel_1_lm_1 sorry
    thus "[TARSKIK4 x,z ] inHIDDENR3 R"
      using A1 A2 A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_8:
" for X be setHIDDENM2 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>RelationRELSET-1M2-of X holds ( ex x be setHIDDENM2 st x inTARSKIR2 X) implies R <>HIDDENR2 {}XBOOLE-0K1"
   sorry

mtheorem eqrel_1_th_9:
" for X be setHIDDENM2 holds  for R be RelationRELSET-1M2-of X holds R be Equivalence-RelationEQREL-1M2-of X iff R be reflexiveRELAT-2V1\<bar>symmetricRELAT-2V3\<bar>transitiveRELAT-2V8 & fieldRELAT-1K3 R =XBOOLE-0R4 X"
  using orders_1_th_12 orders_1_th_13 partfun1_def_2 sorry

syntax EQREL_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/'\\EQREL-1K4\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR2" \<rightharpoonup> "EqR1 /\\XBOOLE-0K3 EqR2"

mtheorem eqrel_1_add_3:
  mlet "X be setHIDDENM2", "EqR1 be Equivalence-RelationEQREL-1M2-of X", "EqR2 be Equivalence-RelationEQREL-1M2-of X"
"cluster EqR1 /\\XBOOLE-0K3 EqR2 as-term-is Equivalence-RelationEQREL-1M2-of X"
proof
(*coherence*)
  show "EqR1 /\\XBOOLE-0K3 EqR2 be Equivalence-RelationEQREL-1M2-of X"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 EqR2"
      using eqrel_1_th_5 sorry
    then have A1: "idPARTFUN1K6 X c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2"
      using relat_1_th_47 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 EqR1"
      using eqrel_1_th_5 sorry
    then have "idPARTFUN1K6 X c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1"
      using relat_1_th_47 sorry
    then have "idPARTFUN1K6 X c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 /\\EQREL-1K2\<^bsub>(X)\<^esub> EqR2"
      using A1 xboole_1_th_19 sorry
    then have "domRELSET-1K1\<^bsub>(X)\<^esub> (EqR1 /\\EQREL-1K2\<^bsub>(X)\<^esub> EqR2) =XBOOLE-0R4 X & rngRELSET-1K2\<^bsub>(X)\<^esub> (EqR1 /\\EQREL-1K2\<^bsub>(X)\<^esub> EqR2) =XBOOLE-0R4 X"
      using relset_1_th_16 sorry
    then have "fieldRELAT-1K3 (EqR1 /\\EQREL-1K2\<^bsub>(X)\<^esub> EqR2) =XBOOLE-0R4 X"
       sorry
    thus "EqR1 /\\XBOOLE-0K3 EqR2 be Equivalence-RelationEQREL-1M2-of X"
      using eqrel_1_th_9 sorry
  qed
qed "sorry"

mtheorem eqrel_1_th_10:
" for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds idPARTFUN1K6 X /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
proof-
  have " for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds idPARTFUN1K6 X /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR assume [ty]: "EqR be Equivalence-RelationEQREL-1M2-of X"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idPARTFUN1K6 X implies [TARSKIK4 x,y ] inHIDDENR3 EqR"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 idPARTFUN1K6 X"
      then have "x inHIDDENR3 X & x =HIDDENR1 y"
        using relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 EqR"
        using eqrel_1_th_5 sorry
    qed "sorry"
    then have "idPARTFUN1K6 X c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR"
       sorry
    thus "idPARTFUN1K6 X /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR =RELSET-1R2\<^bsub>(X,X)\<^esub> idPARTFUN1K6 X"
      using xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_11:
" for X be setHIDDENM2 holds  for SFXX be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,X :] holds SFXX <>HIDDENR2 {}XBOOLE-0K1 & ( for Y be setHIDDENM2 holds Y inTARSKIR2 SFXX implies Y be Equivalence-RelationEQREL-1M2-of X) implies meetSETFAM-1K6\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> SFXX be Equivalence-RelationEQREL-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for SFXX be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,X :] holds SFXX <>HIDDENR2 {}XBOOLE-0K1 & ( for Y be setHIDDENM2 holds Y inTARSKIR2 SFXX implies Y be Equivalence-RelationEQREL-1M2-of X) implies meetSETFAM-1K6\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> SFXX be Equivalence-RelationEQREL-1M2-of X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix SFXX assume [ty]: "SFXX be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,X :]"
    assume A1: "SFXX <>HIDDENR2 {}XBOOLE-0K1"
      and A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 SFXX implies Y be Equivalence-RelationEQREL-1M2-of X"
    obtain XX where 
      [ty]:"XX be RelationRELSET-1M2-of X" and XXDef:"XX = meetSETFAM-1K6\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> SFXX"
       sorry
    have A3: "XX is-symmetric-inRELAT-2R3 X"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & (y inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 XX) implies [TARSKIK4 y,x ] inHIDDENR3 XX"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "x inHIDDENR3 X"
          and "y inHIDDENR3 X"
          and A4: "[TARSKIK4 x,y ] inHIDDENR3 XX"
        have " for Y be setHIDDENM2 holds Y inTARSKIR2 SFXX implies [TARSKIK4 y,x ] inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume "Y inTARSKIR2 SFXX"
          then have "Y be Equivalence-RelationEQREL-1M2-of X & [TARSKIK4 x,y ] inHIDDENR3 Y"
            using A2 A4 setfam_1_def_1 sorry
          thus "[TARSKIK4 y,x ] inHIDDENR3 Y"
            using eqrel_1_th_6 sorry
        qed "sorry"
        thus "[TARSKIK4 y,x ] inHIDDENR3 XX"
          using A1 setfam_1_def_1 sorry
      qed "sorry"
      thus "XX is-symmetric-inRELAT-2R3 X"
        using relat_2_def_3 sorry
    qed
    have A5: "XX is-transitive-inRELAT-2R8 X"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 X & (y inHIDDENR3 X & (z inHIDDENR3 X & ([TARSKIK4 x,y ] inHIDDENR3 XX & [TARSKIK4 y,z ] inHIDDENR3 XX))) implies [TARSKIK4 x,z ] inHIDDENR3 XX"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "x inHIDDENR3 X"
          and "y inHIDDENR3 X"
          and "z inHIDDENR3 X"
          and A6: "[TARSKIK4 x,y ] inHIDDENR3 XX"
          and A7: "[TARSKIK4 y,z ] inHIDDENR3 XX"
        have " for Y be setHIDDENM2 holds Y inTARSKIR2 SFXX implies [TARSKIK4 x,z ] inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume A8: "Y inTARSKIR2 SFXX"
          then have A9: "[TARSKIK4 y,z ] inHIDDENR3 Y"
            using A7 setfam_1_def_1 sorry
          have "Y be Equivalence-RelationEQREL-1M2-of X & [TARSKIK4 x,y ] inHIDDENR3 Y"
            using A2 A6 A8 setfam_1_def_1 sorry
          thus "[TARSKIK4 x,z ] inHIDDENR3 Y"
            using A9 eqrel_1_th_7 sorry
        qed "sorry"
        thus "[TARSKIK4 x,z ] inHIDDENR3 XX"
          using A1 setfam_1_def_1 sorry
      qed "sorry"
      thus "XX is-transitive-inRELAT-2R8 X"
        using relat_2_def_8 sorry
    qed
    have "XX is-reflexive-inRELAT-2R1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 XX"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A10: "x inHIDDENR3 X"
        have " for Y be setHIDDENM2 holds Y inTARSKIR2 SFXX implies [TARSKIK4 x,x ] inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume "Y inTARSKIR2 SFXX"
          then have "Y be Equivalence-RelationEQREL-1M2-of X"
            using A2 sorry
          thus "[TARSKIK4 x,x ] inHIDDENR3 Y"
            using A10 eqrel_1_th_5 sorry
        qed "sorry"
        thus "[TARSKIK4 x,x ] inHIDDENR3 XX"
          using A1 setfam_1_def_1 sorry
      qed "sorry"
      thus "XX is-reflexive-inRELAT-2R1 X"
        using relat_2_def_1 sorry
    qed
    then have "fieldRELAT-1K3 XX =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> XX =XBOOLE-0R4 X"
      using orders_1_th_13 sorry
    thus "meetSETFAM-1K6\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> SFXX be Equivalence-RelationEQREL-1M2-of X"
      using A3 A5 partfun1_def_2 relat_2_def_11 relat_2_def_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_12:
" for X be setHIDDENM2 holds  for R be RelationRELSET-1M2-of X holds  ex EqR be Equivalence-RelationEQREL-1M2-of X st R c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR & ( for EqR2 be Equivalence-RelationEQREL-1M2-of X holds R c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 implies EqR c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELSET-1M2-of X holds  ex tVar1 be Equivalence-RelationEQREL-1M2-of X st R c=RELSET-1R1\<^bsub>(X,X)\<^esub> tVar1 & ( for EqR2 be Equivalence-RelationEQREL-1M2-of X holds  not (R c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 &  not tVar1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2))"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M2-of X"
    let ?P = "\<lambda>Lamb1. Lamb1 be Equivalence-RelationEQREL-1M2-of X & R c=RELSET-1R1\<^bsub>(X,X)\<^esub> Lamb1"
    obtain F where
      [ty]:"F be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,X :]" and 
      A1: " for AX be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,X :] holds AX inTARSKIR2 F iff ?P(AX)"
      using subset_1_sch_3 sorry
    have "R c=RELSET-1R1\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X"
       sorry
    then have A2: "F <>HIDDENR2 {}XBOOLE-0K1"
      using A1 sorry
    have " for Y be setHIDDENM2 holds Y inTARSKIR2 F implies Y be Equivalence-RelationEQREL-1M2-of X"
      using A1 sorry
    then obtain EqR where 
      [ty]:"EqR be Equivalence-RelationEQREL-1M2-of X" and EqRDef:"EqR = meetSETFAM-1K6\<^bsub>([:ZFMISC-1K2 X,X :])\<^esub> F"
      using A2 eqrel_1_th_11 sorry
    have A3: " for EqR2 be Equivalence-RelationEQREL-1M2-of X holds R c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 implies EqR c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2"
      using A1 setfam_1_th_3 sorry
    show " ex tVar1 be Equivalence-RelationEQREL-1M2-of X st R c=RELSET-1R1\<^bsub>(X,X)\<^esub> tVar1 & ( for EqR2 be Equivalence-RelationEQREL-1M2-of X holds  not (R c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 &  not tVar1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2))"
    proof(rule bexI[of _ "EqR"])
      have " for Y be setHIDDENM2 holds Y inTARSKIR2 F implies R c=RELSET-1R1\<^bsub>(X,X)\<^esub> Y"
        using A1 sorry
      thus "R c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR & ( for EqR2 be Equivalence-RelationEQREL-1M2-of X holds  not (R c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 &  not EqR c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2))"
        using A2 A3 setfam_1_th_5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef eqrel_1_def_2 (" _ \<inverse>'\\'/\<inverse>EQREL-1K5\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "X be setHIDDENM2", "EqR1 be Equivalence-RelationEQREL-1M2-of X", "EqR2 be Equivalence-RelationEQREL-1M2-of X"
"func EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 \<rightarrow> Equivalence-RelationEQREL-1M2-of X means
  \<lambda>it. EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> it & ( for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR implies it c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR)"
proof-
  (*existence*)
    show " ex it be Equivalence-RelationEQREL-1M2-of X st EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> it & ( for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR implies it c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR)"
      using eqrel_1_th_12 sorry
  (*uniqueness*)
    show " for it1 be Equivalence-RelationEQREL-1M2-of X holds  for it2 be Equivalence-RelationEQREL-1M2-of X holds (EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> it1 & ( for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR implies it1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR)) & (EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> it2 & ( for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR implies it2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR)) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem EQREL_1K5_commutativity:
  mlet "X be setHIDDENM2"
" for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 =HIDDENR1 EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR1"
proof-
  have " for it be Equivalence-RelationEQREL-1M2-of X holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds it =HIDDENR1 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 implies it =HIDDENR1 EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR1"
  proof-
    have " for it be Equivalence-RelationEQREL-1M2-of X holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> it & ( for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR implies it c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR) implies EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> it & ( for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR implies it c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR)"
       sorry
    thus " ?thesis "
      using eqrel_1_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem EQREL_1K5_idempotence:
  mlet "X be setHIDDENM2"
" for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR2 =HIDDENR1 EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
proof-
  have " for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 & ( for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR implies EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR)"
     sorry
  thus " ?thesis "
    using eqrel_1_def_2 sorry
qed

mtheorem eqrel_1_th_13:
" for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds  for EqR3 be Equivalence-RelationEQREL-1M2-of X holds (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3)"
proof-
  have " for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds  for EqR3 be Equivalence-RelationEQREL-1M2-of X holds (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR1 assume [ty]: "EqR1 be Equivalence-RelationEQREL-1M2-of X"
    fix EqR2 assume [ty]: "EqR2 be Equivalence-RelationEQREL-1M2-of X"
    fix EqR3 assume [ty]: "EqR3 be Equivalence-RelationEQREL-1M2-of X"
    have " for EqR4 be Equivalence-RelationEQREL-1M2-of X holds EqR4 =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3) implies (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
    proof(rule ballI,rule impI)
      fix EqR4 assume [ty]: "EqR4 be Equivalence-RelationEQREL-1M2-of X"
      have A1: "EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3"
        using eqrel_1_def_2 sorry
      assume "EqR4 =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3)"
      then have A2: "EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using eqrel_1_def_2 sorry
      have "EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3"
        using xboole_1_th_7 sorry
      then have "EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A2 sorry
      then have A3: "EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A1 sorry
      have "EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3"
        using xboole_1_th_7 sorry
      then have A4: "EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A3 sorry
      have "EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3"
        using xboole_1_th_7 sorry
      then have "EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A2 sorry
      then have "EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A4 xboole_1_th_8 sorry
      then have A5: "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using eqrel_1_def_2 sorry
      have "EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3"
        using xboole_1_th_7 sorry
      then have "EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A3 sorry
      then have "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A5 xboole_1_th_8 sorry
      thus "(EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using eqrel_1_def_2 sorry
    qed "sorry"
    then have A6: "(EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3)"
       sorry
    have " for EqR4 be Equivalence-RelationEQREL-1M2-of X holds EqR4 =RELSET-1R2\<^bsub>(X,X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 implies EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3) c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
    proof(rule ballI,rule impI)
      fix EqR4 assume [ty]: "EqR4 be Equivalence-RelationEQREL-1M2-of X"
      have A7: "EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
        using eqrel_1_def_2 sorry
      assume "EqR4 =RELSET-1R2\<^bsub>(X,X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3"
      then have A8: "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using eqrel_1_def_2 sorry
      have "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3"
        using xboole_1_th_7 sorry
      then have "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A8 sorry
      then have A9: "EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A7 sorry
      have "EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3"
        using xboole_1_th_7 sorry
      then have A10: "EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A8 sorry
      have "EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
        using xboole_1_th_7 sorry
      then have "EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A9 sorry
      then have "EqR2 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A10 xboole_1_th_8 sorry
      then have A11: "EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using eqrel_1_def_2 sorry
      have "EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
        using xboole_1_th_7 sorry
      then have "EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A9 sorry
      then have "EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using A11 xboole_1_th_8 sorry
      thus "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3) c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR4"
        using eqrel_1_def_2 sorry
    qed "sorry"
    then have "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3) c=RELSET-1R1\<^bsub>(X,X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3"
       sorry
    thus "(EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)\<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3 =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR3)"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_14:
" for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR"
   sorry

mtheorem eqrel_1_th_15:
" for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR2 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR1"
   sorry

mtheorem eqrel_1_th_16:
" for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2) =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1"
proof-
  have " for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2) =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR1 assume [ty]: "EqR1 be Equivalence-RelationEQREL-1M2-of X"
    fix EqR2 assume [ty]: "EqR2 be Equivalence-RelationEQREL-1M2-of X"
    have "EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2) c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 & EqR1 c=TARSKIR1 EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)"
    proof(rule conjMI)
      show "EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2) c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1"
        using xboole_1_th_17 sorry
      have "EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 & EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
        using eqrel_1_def_2 xboole_1_th_7 sorry
      then have "EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
         sorry
      thus "EqR1 c=TARSKIR1 EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)"
        using xboole_1_th_19 sorry
    qed
    thus "EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> (EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2) =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_17:
" for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR2) =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1"
proof-
  have " for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR2) =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR1 assume [ty]: "EqR1 be Equivalence-RelationEQREL-1M2-of X"
    fix EqR2 assume [ty]: "EqR2 be Equivalence-RelationEQREL-1M2-of X"
    have "EqR1 =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR2 & ( for EqR be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR implies EqR1 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR)"
      using xboole_1_th_22 sorry
    thus "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> (EqR1 /\\EQREL-1K4\<^bsub>(X)\<^esub> EqR2) =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1"
      using eqrel_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem eqrel_1_sch_1:
  fixes Xf0 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies Pp2(x,x)" and
   A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds Pp2(x,y) implies Pp2(y,x)" and
   A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds Pp2(x,y) & Pp2(y,z) implies Pp2(x,z)"
  shows " ex EqR be Equivalence-RelationEQREL-1M2-of Xf0 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 EqR iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & Pp2(x,y)"
  proof-
    have " ex tVar2 be Equivalence-RelationEQREL-1M2-of Xf0 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar2 &  not ((x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar2)"
    proof-
      obtain Y where
        [ty]:"Y be RelationRELSET-1M1-of(Xf0,Xf0)" and 
        A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Y iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & Pp2(x,y)"
        using relset_1_sch_1 sorry
      have A5: "Y is-transitive-inRELAT-2R8 Xf0"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 Xf0 & (y inHIDDENR3 Xf0 & (z inHIDDENR3 Xf0 & ([TARSKIK4 x,y ] inHIDDENR3 Y & [TARSKIK4 y,z ] inHIDDENR3 Y))) implies [TARSKIK4 x,z ] inHIDDENR3 Y"
        proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A6: "x inHIDDENR3 Xf0"
            and "y inHIDDENR3 Xf0"
            and A7: "z inHIDDENR3 Xf0"
            and A8: "[TARSKIK4 x,y ] inHIDDENR3 Y & [TARSKIK4 y,z ] inHIDDENR3 Y"
          have "Pp2(x,y) & Pp2(y,z)"
            using A4 A8 sorry
          then have "Pp2(x,z)"
            using A3 sorry
          thus "[TARSKIK4 x,z ] inHIDDENR3 Y"
            using A4 A6 A7 sorry
        qed "sorry"
        thus "Y is-transitive-inRELAT-2R8 Xf0"
          using relat_2_def_8 sorry
      qed
      have A9: "Y is-symmetric-inRELAT-2R3 Xf0"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & [TARSKIK4 x,y ] inHIDDENR3 Y implies [TARSKIK4 y,x ] inHIDDENR3 Y"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A10: "x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0"
            and A11: "[TARSKIK4 x,y ] inHIDDENR3 Y"
          have "Pp2(x,y)"
            using A4 A11 sorry
          then have "Pp2(y,x)"
            using A2 sorry
          thus "[TARSKIK4 y,x ] inHIDDENR3 Y"
            using A4 A10 sorry
        qed "sorry"
        thus "Y is-symmetric-inRELAT-2R3 Xf0"
          using relat_2_def_3 sorry
      qed
      have "Y is-reflexive-inRELAT-2R1 Xf0"
        using A1 A4 sorry
      then have "fieldRELAT-1K3 Y =XBOOLE-0R4 Xf0 & domRELSET-1K1\<^bsub>(Xf0)\<^esub> Y =XBOOLE-0R4 Xf0"
        using orders_1_th_13 sorry
      then obtain R1 where 
        [ty]:"R1 be Equivalence-RelationEQREL-1M2-of Xf0" and R1Def:"R1 = Y"
        using A9 A5 partfun1_def_2 relat_2_def_11 relat_2_def_16 sorry
      show " ex tVar2 be Equivalence-RelationEQREL-1M2-of Xf0 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar2 &  not ((x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar2)"
      proof(rule bexI[of _ "R1"])
        show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 R1 &  not ((x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Xf0 & y inHIDDENR3 Xf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 R1)"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

abbreviation(input) EQREL_1K6("ClassEQREL-1K6'( _ , _ ')" [0,0]164) where
  "ClassEQREL-1K6(R,x) \<equiv> ImRELAT-1K12(R,x)"

syntax EQREL_1K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("ClassEQREL-1K7\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]164)
translations "ClassEQREL-1K7\<^bsub>(X,Y)\<^esub>(R,x)" \<rightharpoonup> "ImRELAT-1K12(R,x)"

mtheorem eqrel_1_add_4:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)", "x be objectHIDDENM1"
"cluster ImRELAT-1K12(R,x) as-term-is SubsetSUBSET-1M2-of Y"
proof
(*coherence*)
  show "ImRELAT-1K12(R,x) be SubsetSUBSET-1M2-of Y"
  proof-
    have "R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x} c=TARSKIR1 Y"
       sorry
    thus "ImRELAT-1K12(R,x) be SubsetSUBSET-1M2-of Y"
       sorry
  qed
qed "sorry"

mtheorem eqrel_1_th_18:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds y inHIDDENR3 ClassEQREL-1K6(R,x) iff [TARSKIK4 x,y ] inHIDDENR3 R"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (y inHIDDENR3 ClassEQREL-1K6(R,x) implies [TARSKIK4 x,y ] inHIDDENR3 R) & ([TARSKIK4 x,y ] inHIDDENR3 R implies y inHIDDENR3 ClassEQREL-1K6(R,x))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "y inHIDDENR3 ClassEQREL-1K6(R,x) implies [TARSKIK4 x,y ] inHIDDENR3 R"
    proof(rule impI)
      assume "y inHIDDENR3 ClassEQREL-1K6(R,x)"
      then have " ex z be objectHIDDENM1 st [TARSKIK4 z,y ] inHIDDENR3 R & z inHIDDENR3 {TARSKIK1 x}"
        using relat_1_def_13 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R"
        using tarski_def_1 sorry
    qed
    have A1: "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    assume "[TARSKIK4 x,y ] inHIDDENR3 R"
    thus "y inHIDDENR3 ClassEQREL-1K6(R,x)"
      using A1 relat_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_19:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>RelationRELSET-1M2-of X holds y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x) iff [TARSKIK4 y,x ] inHIDDENR3 R"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>RelationRELSET-1M2-of X holds (y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x) implies [TARSKIK4 y,x ] inHIDDENR3 R) & ([TARSKIK4 y,x ] inHIDDENR3 R implies y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>symmetricRELAT-2V3\<bar>RelationRELSET-1M2-of X"
    show "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x) implies [TARSKIK4 y,x ] inHIDDENR3 R"
    proof(rule impI)
      assume "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
      then have " ex z be objectHIDDENM1 st [TARSKIK4 z,y ] inHIDDENR3 R & z inHIDDENR3 {TARSKIK1 x}"
        using relat_1_def_13 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using tarski_def_1 sorry
      thus "[TARSKIK4 y,x ] inHIDDENR3 R"
        using eqrel_1_th_6 sorry
    qed
    assume "[TARSKIK4 y,x ] inHIDDENR3 R"
    then have A1: "[TARSKIK4 x,y ] inHIDDENR3 R"
      using eqrel_1_th_6 sorry
    have "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
      using A1 relat_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_20:
" for X be setHIDDENM2 holds  for R be ToleranceEQREL-1M1-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
proof-
  have " for X be setHIDDENM2 holds  for R be ToleranceEQREL-1M1-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be ToleranceEQREL-1M1-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 X"
    then have "[TARSKIK4 x,x ] inHIDDENR3 R"
      using eqrel_1_th_5 sorry
    thus "x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
      using eqrel_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_21:
" for X be setHIDDENM2 holds  for R be ToleranceEQREL-1M1-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,y))"
proof-
  have " for X be setHIDDENM2 holds  for R be ToleranceEQREL-1M1-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies  not ( for y be objectHIDDENM1 holds  not x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,y))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be ToleranceEQREL-1M1-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 X"
    then have "x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
      using eqrel_1_th_20 sorry
    thus " not ( for y be objectHIDDENM1 holds  not x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,y))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_22:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for R be transitiveRELAT-2V8\<bar>ToleranceEQREL-1M1-of X holds y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x) & z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x) implies [TARSKIK4 y,z ] inHIDDENR3 R"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for R be transitiveRELAT-2V8\<bar>ToleranceEQREL-1M1-of X holds y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x) & z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x) implies [TARSKIK4 y,z ] inHIDDENR3 R"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix R assume [ty]: "R be transitiveRELAT-2V8\<bar>ToleranceEQREL-1M1-of X"
    assume A1: "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
      and A2: "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
    have "[TARSKIK4 z,x ] inHIDDENR3 R"
      using A2 eqrel_1_th_19 sorry
    then have A3: "[TARSKIK4 x,z ] inHIDDENR3 R"
      using eqrel_1_th_6 sorry
    have "[TARSKIK4 y,x ] inHIDDENR3 R"
      using A1 eqrel_1_th_19 sorry
    thus "[TARSKIK4 y,z ] inHIDDENR3 R"
      using A3 eqrel_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma eqrel_1_lm_2:
" for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ([TARSKIK4 x,y ] inHIDDENR3 EqR iff ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y))"
proof-
  have " for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ([TARSKIK4 x,y ] inHIDDENR3 EqR implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)) & (ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y) implies [TARSKIK4 x,y ] inHIDDENR3 EqR)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix EqR assume [ty]: "EqR be Equivalence-RelationEQREL-1M2-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 X"
    show "[TARSKIK4 x,y ] inHIDDENR3 EqR implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
    proof(rule impI)
      assume A2: "[TARSKIK4 x,y ] inHIDDENR3 EqR"
      have " for z be objectHIDDENM1 holds z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y) implies z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
        then have A3: "[TARSKIK4 z,y ] inHIDDENR3 EqR"
          using eqrel_1_th_19 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 EqR"
          using A2 eqrel_1_th_6 sorry
        then have "[TARSKIK4 z,x ] inHIDDENR3 EqR"
          using A3 eqrel_1_th_7 sorry
        thus "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
          using eqrel_1_th_19 sorry
      qed "sorry"
      then have A4: "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y) c=TARSKIR1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
         sorry
      have " for z be objectHIDDENM1 holds z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) implies z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
        then have "[TARSKIK4 z,x ] inHIDDENR3 EqR"
          using eqrel_1_th_19 sorry
        then have "[TARSKIK4 z,y ] inHIDDENR3 EqR"
          using A2 eqrel_1_th_7 sorry
        thus "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
          using eqrel_1_th_19 sorry
      qed "sorry"
      then have "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) c=TARSKIR1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
         sorry
      thus "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
        using A4 sorry
    qed
    assume "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
    then have "x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
      using A1 eqrel_1_th_20 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 EqR"
      using eqrel_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_23:
" for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies (y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) iff ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y))"
proof-
  have " for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies (y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)) & (ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y) implies y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix EqR assume [ty]: "EqR be Equivalence-RelationEQREL-1M2-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 X"
    show "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
    proof(rule impI)
      assume "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
      then have "[TARSKIK4 y,x ] inHIDDENR3 EqR"
        using eqrel_1_th_19 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 EqR"
        using eqrel_1_th_6 sorry
      thus "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
        using A1 eqrel_1_lm_2 sorry
    qed
    assume "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
    then have "[TARSKIK4 x,y ] inHIDDENR3 EqR"
      using A1 eqrel_1_lm_2 sorry
    then have "[TARSKIK4 y,x ] inHIDDENR3 EqR"
      using eqrel_1_th_6 sorry
    thus "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
      using eqrel_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_24:
" for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds y inHIDDENR3 X implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y) or ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) missesXBOOLE-0R1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
proof-
  have " for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds y inHIDDENR3 X implies  not ( not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y) &  not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) missesXBOOLE-0R1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR assume [ty]: "EqR be Equivalence-RelationEQREL-1M2-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have A1: " not [TARSKIK4 x,y ] inHIDDENR3 EqR implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) missesXBOOLE-0R1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
    proof-
      have " not [TARSKIK4 x,y ] inHIDDENR3 EqR implies (ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) meetsXBOOLE-0R5 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y) implies  False )"
      proof(rule impI,rule impI)
        assume A2: " not [TARSKIK4 x,y ] inHIDDENR3 EqR"
        assume "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) meetsXBOOLE-0R5 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A3: "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"and A4: "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
          using xboole_0_th_3 sorry
        have "[TARSKIK4 z,x ] inHIDDENR3 EqR"
          using A3 eqrel_1_th_19 sorry
        then have A5: "[TARSKIK4 x,z ] inHIDDENR3 EqR"
          using eqrel_1_th_6 sorry
        have "[TARSKIK4 z,y ] inHIDDENR3 EqR"
          using A4 eqrel_1_th_19 sorry
        thus " False "
          using A2 A5 eqrel_1_th_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A6: "y inHIDDENR3 X"
    have "[TARSKIK4 x,y ] inHIDDENR3 EqR implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
    proof(rule impI)
      assume "[TARSKIK4 x,y ] inHIDDENR3 EqR"
      then have "x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
        using eqrel_1_th_19 sorry
      thus "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
        using A6 eqrel_1_th_23 sorry
    qed
    thus " not ( not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y) &  not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) missesXBOOLE-0R1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_25:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) =XBOOLE-0R4 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: " for y be objectHIDDENM1 holds y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) implies y =HIDDENR1 x"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x)"
      then have "[TARSKIK4 y,x ] inHIDDENR3 idPARTFUN1K6 X"
        using eqrel_1_th_19 sorry
      thus "y =HIDDENR1 x"
        using relat_1_def_10 sorry
    qed "sorry"
    assume "x inHIDDENR3 X"
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) iff y =HIDDENR1 x"
      using A1 eqrel_1_th_20 sorry
    thus "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) =XBOOLE-0R4 {TARSKIK1 x}"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_26:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(nablaEQREL-1K1 X,x) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(nablaEQREL-1K1 X,x) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 X"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(nablaEQREL-1K1 X,x)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 X"
      then have "[TARSKIK4 y,x ] inHIDDENR3 nablaEQREL-1K1 X"
        using A1 zfmisc_1_th_87 sorry
      thus "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(nablaEQREL-1K1 X,x)"
        using eqrel_1_th_19 sorry
    qed "sorry"
    then have " for y be objectHIDDENM1 holds y inHIDDENR3 X iff y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(nablaEQREL-1K1 X,x)"
       sorry
    thus "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(nablaEQREL-1K1 X,x) =XBOOLE-0R4 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_27:
" for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds ( ex x be objectHIDDENM1 st ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 X) implies EqR =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds ( ex x be objectHIDDENM1 st ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 X) implies EqR =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR assume [ty]: "EqR be Equivalence-RelationEQREL-1M2-of X"
    assume Given: " ex x be objectHIDDENM1 st ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 X"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 X"
       sorry
    have "[:ZFMISC-1K2 X,X :] c=RELAT-1R2 EqR"
    proof-
      have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 X,X :] implies [TARSKIK4 y,z ] inHIDDENR3 EqR"
      proof(rule ballI,rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A2: "[TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
        then have "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
          using A1 zfmisc_1_th_87 sorry
        then have "[TARSKIK4 z,x ] inHIDDENR3 EqR"
          using eqrel_1_th_19 sorry
        then have A3: "[TARSKIK4 x,z ] inHIDDENR3 EqR"
          using eqrel_1_th_6 sorry
        have "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
          using A1 A2 zfmisc_1_th_87 sorry
        then have "[TARSKIK4 y,x ] inHIDDENR3 EqR"
          using eqrel_1_th_19 sorry
        thus "[TARSKIK4 y,z ] inHIDDENR3 EqR"
          using A3 eqrel_1_th_7 sorry
      qed "sorry"
      thus "[:ZFMISC-1K2 X,X :] c=RELAT-1R2 EqR"
        using relat_1_def_3 sorry
    qed
    thus "EqR =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_28:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds x inHIDDENR3 X implies ([TARSKIK4 x,y ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 iff ( ex f be FinSequenceFINSEQ-1M1 st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2)))"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds x inHIDDENR3 X implies ([TARSKIK4 x,y ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 implies ( ex f be FinSequenceFINSEQ-1M1 st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2))) & (( ex f be FinSequenceFINSEQ-1M1 st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2)) implies [TARSKIK4 x,y ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix EqR1 assume [ty]: "EqR1 be Equivalence-RelationEQREL-1M2-of X"
    fix EqR2 assume [ty]: "EqR2 be Equivalence-RelationEQREL-1M2-of X"
    assume A1: "x inHIDDENR3 X"
    show "[TARSKIK4 x,y ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 implies ( ex f be FinSequenceFINSEQ-1M1 st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2))"
    proof-
      have "[TARSKIK4 x,y ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 implies ( ex tVar3 be FinSequenceFINSEQ-1M1 st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 tVar3 & x =HIDDENR1 tVar3 .FUNCT-1K1 \<one>\<^sub>M) & y =HIDDENR1 tVar3 .FUNCT-1K1 lenFINSEQ-1K4 tVar3) & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i &  not i <XXREAL-0R3 lenFINSEQ-1K4 tVar3) &  not [TARSKIK4 tVar3 .FUNCT-1K1 i,tVar3 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2)))"
      proof(rule impI)
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex f be FinSequenceFINSEQ-1M1 st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & Lamb1 =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & Lamb2 =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2)"
        obtain Y where
          [ty]:"Y be RelationRELSET-1M1-of(X,X)" and 
          A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Y iff (x inHIDDENR3 X & y inHIDDENR3 X) & ?P(x,y)"
          using relset_1_sch_1 sorry
        have A3: "Y is-transitive-inRELAT-2R8 X"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 X & (y inHIDDENR3 X & (z inHIDDENR3 X & ([TARSKIK4 x,y ] inHIDDENR3 Y & [TARSKIK4 y,z ] inHIDDENR3 Y))) implies [TARSKIK4 x,z ] inHIDDENR3 Y"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A4: "x inHIDDENR3 X"
              and A5: "y inHIDDENR3 X"
              and A6: "z inHIDDENR3 X"
              and A7: "[TARSKIK4 x,y ] inHIDDENR3 Y"
              and A8: "[TARSKIK4 y,z ] inHIDDENR3 Y"
            obtain g where
              [ty]:"g be FinSequenceFINSEQ-1M1" and 
              A9: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 g"and A10: "y =HIDDENR1 g .FUNCT-1K1 \<one>\<^sub>M"and A11: "z =HIDDENR1 g .FUNCT-1K1 lenFINSEQ-1K4 g"and A12: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 g implies [TARSKIK4 g .FUNCT-1K1 i,g .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
              using A2 A8 sorry
            obtain f where
              [ty]:"f be FinSequenceFINSEQ-1M1" and 
              A13: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"and A14: "x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"and A15: "y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f"and A16: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
              using A2 A7 sorry
            let ?h = "f ^FINSEQ-1K8 g"
            have A17: "lenFINSEQ-1K4 ?h =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 g"
              using finseq_1_th_22 sorry
            have A18: "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 g"
              using A9 xreal_1_th_7 sorry
            then have A19: "?h .FUNCT-1K1 lenFINSEQ-1K4 ?h =HIDDENR1 g .FUNCT-1K1 ((lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 lenFINSEQ-1K4 f)"
              using A17 finseq_1_th_23 sorry
            also have "... = g .FUNCT-1K1 lenFINSEQ-1K4 g"
               sorry
            finally have "?h .FUNCT-1K1 lenFINSEQ-1K4 ?h =HIDDENR1 g .FUNCT-1K1 lenFINSEQ-1K4 g"
               sorry
            have A20: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 ?h implies [TARSKIK4 ?h .FUNCT-1K1 i,?h .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
            proof-
              have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 (f ^FINSEQ-1K8 g) implies [TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
              proof(rule ballI,rule impMI ,rule impI)
                fix i assume [ty]: "i be NatNAT-1M1"
                assume A21: "\<one>\<^sub>M <=XXREAL-0R1 i"
                  and A22: "i <XXREAL-0R3 lenFINSEQ-1K4 ?h"
                have A23: "(\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f or i =XBOOLE-0R4 lenFINSEQ-1K4 f) or lenFINSEQ-1K4 f <XXREAL-0R3 i"
                  using A21 xxreal_0_th_1 sorry
                have "[TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                proof-
                  show "[TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                  proof-
                    have cases: "(\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f or i =XBOOLE-0R4 lenFINSEQ-1K4 f) or lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 ?h"
                      using A22 A23 nat_1_th_13 sorry
                    have case1: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                    proof(rule impI)
                      assume A24: "\<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f"
                      then have "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                        using nat_1_th_13 sorry
                      then have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
                        using finseq_1_th_1 sorry
                      then have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> f"
                        using finseq_1_def_3 sorry
                      then have A25: "?h .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
                        using finseq_1_def_7 sorry
                      have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
                        using A24 finseq_1_th_1 sorry
                      then have "i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> f"
                        using finseq_1_def_3 sorry
                      then have "?h .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
                        using finseq_1_def_7 sorry
                      thus "[TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                        using A16 A24 A25 sorry
                    qed
                    have case2: "i =XBOOLE-0R4 lenFINSEQ-1K4 f implies [TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                    proof(rule impI)
                      assume A26: "i =XBOOLE-0R4 lenFINSEQ-1K4 f"
                      have "lenFINSEQ-1K4 f inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
                        using A13 finseq_1_th_1 sorry
                      then have "lenFINSEQ-1K4 f inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> f"
                        using finseq_1_def_3 sorry
                      then have A27: "?h .FUNCT-1K1 i =HIDDENR1 y"
                        using A15 A26 finseq_1_def_7 sorry
                      have A28: "[TARSKIK4 y,y ] inHIDDENR3 EqR1"
                        using A5 eqrel_1_th_5 sorry
                      have "?h .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 lenFINSEQ-1K4 f)"
                        using A18 A26 finseq_1_th_23 sorry
                      also have "... = y"
                        using A10 sorry
                      finally have "?h .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 y"
                         sorry
                      thus "[TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                        using A27 A28 xboole_0_def_3 sorry
                    qed
                    have case3: "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 (f ^FINSEQ-1K8 g) implies [TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                    proof(rule impI)
                      assume A29: "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 ?h"
                      then have "lenFINSEQ-1K4 f <XXREAL-0R3 i"
                        using nat_1_th_13 sorry
                      then obtain k where 
                        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = i -XCMPLX-0K6 lenFINSEQ-1K4 f"
                        using nat_1_th_21 sorry
                      have "i <XXREAL-0R3 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 g"
                        using A29 finseq_1_th_22 sorry
                      then have A30: "i -XCMPLX-0K6 lenFINSEQ-1K4 f <XXREAL-0R3 lenFINSEQ-1K4 g"
                        using xreal_1_th_19 sorry
                      have "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 g"
                        using A17 A29 nat_1_th_13 sorry
                      then have A31: "?h .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((\<one>\<^sub>M +XCMPLX-0K2 i)-XCMPLX-0K6 lenFINSEQ-1K4 f)"
                        using finseq_1_th_23 sorry
                      also have "... = g .FUNCT-1K1 ((i -XCMPLX-0K6 lenFINSEQ-1K4 f)+XCMPLX-0K2 \<one>\<^sub>M)"
                         sorry
                      finally have "?h .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((i -XCMPLX-0K6 lenFINSEQ-1K4 f)+XCMPLX-0K2 \<one>\<^sub>M)"
                         sorry
                      have "(\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 lenFINSEQ-1K4 f <=XXREAL-0R1 i -XCMPLX-0K6 lenFINSEQ-1K4 f"
                        using A29 xreal_1_th_9 sorry
                      then have "[TARSKIK4 g .FUNCT-1K1 k,g .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                        using A12 A30 sorry
                      thus "[TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                        using A17 A29 A31 finseq_1_th_23 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 case3 sorry
                  qed
                qed
                thus "[TARSKIK4 (f ^FINSEQ-1K8 g).FUNCT-1K1 i,(f ^FINSEQ-1K8 g).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                   sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
              using A13 finseq_1_th_1 sorry
            then have "\<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> f"
              using finseq_1_def_3 sorry
            then have A32: "x =HIDDENR1 ?h .FUNCT-1K1 \<one>\<^sub>M"
              using A14 finseq_1_def_7 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?h"
              using A13 A17 nat_1_th_12 sorry
            thus "[TARSKIK4 x,z ] inHIDDENR3 Y"
              using A2 A4 A6 A11 A32 A19 A20 sorry
          qed "sorry"
          thus "Y is-transitive-inRELAT-2R8 X"
            using relat_2_def_8 sorry
        qed
        have A33: "Y is-symmetric-inRELAT-2R3 X"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & [TARSKIK4 x,y ] inHIDDENR3 Y implies [TARSKIK4 y,x ] inHIDDENR3 Y"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A34: "x inHIDDENR3 X & y inHIDDENR3 X"
              and A35: "[TARSKIK4 x,y ] inHIDDENR3 Y"
            obtain f where
              [ty]:"f be FinSequenceFINSEQ-1M1" and 
              A36: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"and A37: "x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"and A38: "y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f"and A39: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
              using A2 A35 sorry
            let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 f .FUNCT-1K1 ((\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 Lamb1)"
            have A40: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) implies ( ex z be objectHIDDENM1 st ?P(k,z))"
               sorry
            obtain g where
              [ty]:"g be FinSequenceFINSEQ-1M1" and 
              A41: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> g =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) & ( for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) implies ?P(k,g .FUNCT-1K1 k))"
              using finseq_1_sch_1 A40 sorry
            have A42: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g"
              using A41 finseq_1_def_3 sorry
            have A43: " for j be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 j & j <XXREAL-0R3 lenFINSEQ-1K4 g implies [TARSKIK4 g .FUNCT-1K1 j,g .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
            proof(rule ballI,rule impMI ,rule impI)
              fix j assume [ty]: "j be NatNAT-1M1"
              assume A44: "\<one>\<^sub>M <=XXREAL-0R1 j"
                and A45: "j <XXREAL-0R3 lenFINSEQ-1K4 g"
              obtain k where 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = lenFINSEQ-1K4 f -XCMPLX-0K6 j"
                using A42 A45 nat_1_th_21 sorry
              have "j -XCMPLX-0K6 lenFINSEQ-1K4 f <XXREAL-0R3 lenFINSEQ-1K4 f -XCMPLX-0K6 lenFINSEQ-1K4 f"
                using A42 A45 xreal_1_th_9 sorry
              then have "-XCMPLX-0K4 (lenFINSEQ-1K4 f -XCMPLX-0K6 j) <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
                 sorry
              then have "0NUMBERSK6 <XXREAL-0R3 k"
                 sorry
              then have A46: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
                using nat_1_th_13 sorry
              have "-XCMPLX-0K4 j <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
                using A44 xreal_1_th_24 sorry
              then have "lenFINSEQ-1K4 f +XCMPLX-0K2 (-XCMPLX-0K4 j) <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 lenFINSEQ-1K4 f"
                using xreal_1_th_6 sorry
              then have A47: "[TARSKIK4 f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                using A39 A46 sorry
              have A48: "[TARSKIK4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 k ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
              proof-
                show "[TARSKIK4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 k ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                proof-
                  have cases: "[TARSKIK4 f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 or [TARSKIK4 f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR2"
                    using A47 xboole_0_def_3 sorry
                  have case1: "[TARSKIK4 f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 implies [TARSKIK4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 k ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                  proof(rule impI)
                    assume "[TARSKIK4 f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1"
                    then have "[TARSKIK4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 k ] inHIDDENR3 EqR1"
                      using eqrel_1_th_6 sorry
                    thus "[TARSKIK4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 k ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                      using xboole_0_def_3 sorry
                  qed
                  have case2: "[TARSKIK4 f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR2 implies [TARSKIK4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 k ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                  proof(rule impI)
                    assume "[TARSKIK4 f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR2"
                    then have "[TARSKIK4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 k ] inHIDDENR3 EqR2"
                      using eqrel_1_th_6 sorry
                    thus "[TARSKIK4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 k ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                      using xboole_0_def_3 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              have "\<one>\<^sub>M <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M & j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                using A42 A45 nat_1_th_12 nat_1_th_13 sorry
              then have "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
                using finseq_1_th_1 sorry
              then have A49: "g .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 ((lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M +XCMPLX-0K2 j))"
                using A41 sorry
              also have "... = f .FUNCT-1K1 (lenFINSEQ-1K4 f -XCMPLX-0K6 j)"
                 sorry
              finally have "g .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 (lenFINSEQ-1K4 f -XCMPLX-0K6 j)"
                 sorry
              have "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
                using A42 A44 A45 finseq_1_th_1 sorry
              then have "g .FUNCT-1K1 j =HIDDENR1 f .FUNCT-1K1 ((\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 j)"
                using A41 sorry
              also have "... = f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M)"
                 sorry
              finally have "g .FUNCT-1K1 j =HIDDENR1 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M)"
                 sorry
              thus "[TARSKIK4 g .FUNCT-1K1 j,g .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                using A49 A48 sorry
            qed "sorry"
            have "lenFINSEQ-1K4 f inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
              using A36 finseq_1_th_1 sorry
            then have "g .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 f .FUNCT-1K1 ((\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 lenFINSEQ-1K4 f)"
              using A41 sorry
            also have "... = f .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
               sorry
            finally have "g .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 f .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
               sorry
            then have A50: "x =HIDDENR1 g .FUNCT-1K1 lenFINSEQ-1K4 g"
              using A37 A41 finseq_1_def_3 sorry
            have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
              using A36 finseq_1_th_1 sorry
            then have A51: "g .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 ((lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
              using A41 sorry
            also have "... = f .FUNCT-1K1 lenFINSEQ-1K4 f"
               sorry
            finally have "g .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f"
               sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 g"
              using A36 A41 finseq_1_def_3 sorry
            thus "[TARSKIK4 y,x ] inHIDDENR3 Y"
              using A2 A34 A38 A51 A50 A43 sorry
          qed "sorry"
          thus "Y is-symmetric-inRELAT-2R3 X"
            using relat_2_def_3 sorry
        qed
        have "Y is-reflexive-inRELAT-2R1 X"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 Y"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A52: "x inHIDDENR3 X"
            let ?g = "<*FINSEQ-1K10 x*>"
            have A53: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 ?g implies [TARSKIK4 ?g .FUNCT-1K1 i,?g .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
              using finseq_1_th_40 sorry
            have "lenFINSEQ-1K4 ?g =XBOOLE-0R4 \<one>\<^sub>M & ?g .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
              using finseq_1_th_40 sorry
            thus "[TARSKIK4 x,x ] inHIDDENR3 Y"
              using A2 A52 A53 sorry
          qed "sorry"
          thus "Y is-reflexive-inRELAT-2R1 X"
            using relat_2_def_1 sorry
        qed
        then have "fieldRELAT-1K3 Y =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> Y =XBOOLE-0R4 X"
          using orders_1_th_13 sorry
        then obtain R1 where 
          [ty]:"R1 be Equivalence-RelationEQREL-1M2-of X" and R1Def:"R1 = Y"
          using A33 A3 partfun1_def_2 relat_2_def_11 relat_2_def_16 sorry
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 implies [TARSKIK4 x,y ] inHIDDENR3 R1"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A54: "[TARSKIK4 x,y ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
          let ?g = "<*FINSEQ-1K11 x,y *>"
          have A55: "lenFINSEQ-1K4 ?g =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
            using finseq_1_th_44 sorry
          have A56: "?g .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x"
            using finseq_1_th_44 sorry
          have A57: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 ?g implies [TARSKIK4 ?g .FUNCT-1K1 i,?g .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
          proof-
            have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) implies [TARSKIK4 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 i,(<*FINSEQ-1K11 x,y *>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
            proof(rule ballI,rule impMI ,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume A58: "\<one>\<^sub>M <=XXREAL-0R1 i"
                and A59: "i <XXREAL-0R3 lenFINSEQ-1K4 ?g"
              have "i <=XXREAL-0R1 \<one>\<^sub>M"
                using A55 A59 nat_1_th_13 sorry
              then have "\<one>\<^sub>M =XBOOLE-0R4 i"
                using A58 xxreal_0_th_1 sorry
              thus "[TARSKIK4 (<*FINSEQ-1K11 x,y *>).FUNCT-1K1 i,(<*FINSEQ-1K11 x,y *>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                using A54 A56 finseq_1_th_44 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have "lenFINSEQ-1K4 ?g =XBOOLE-0R4 \<two>\<^sub>M"
            using finseq_1_th_44 sorry
          then have A60: "?g .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x & ?g .FUNCT-1K1 lenFINSEQ-1K4 ?g =HIDDENR1 y"
            using finseq_1_th_44 sorry
          have "x inHIDDENR3 X & y inHIDDENR3 X"
            using A54 eqrel_1_lm_1 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R1"
            using A2 A55 A60 A57 sorry
        qed "sorry"
        then have "EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> R1"
           sorry
        then have A61: "EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> R1"
          using eqrel_1_def_2 sorry
        assume "[TARSKIK4 x,y ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
        then obtain f where
          [ty]:"f be FinSequenceFINSEQ-1M1" and 
          A62: "(\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & (y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2))"
          using A2 A61 sorry
        show " ex tVar3 be FinSequenceFINSEQ-1M1 st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 tVar3 & x =HIDDENR1 tVar3 .FUNCT-1K1 \<one>\<^sub>M) & y =HIDDENR1 tVar3 .FUNCT-1K1 lenFINSEQ-1K4 tVar3) & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i &  not i <XXREAL-0R3 lenFINSEQ-1K4 tVar3) &  not [TARSKIK4 tVar3 .FUNCT-1K1 i,tVar3 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2))"
        proof(rule bexI[of _ "f"])
          show "((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i &  not i <XXREAL-0R3 lenFINSEQ-1K4 f) &  not [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2))"
            using A62 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex f be FinSequenceFINSEQ-1M1 st ((\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f & x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2)"
    then obtain f where
      [ty]:"f be FinSequenceFINSEQ-1M1" and 
      A63: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"and A64: "x =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"and A65: "y =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f"and A66: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
       sorry
    let ?P = "\<lambda>Lamb1. \<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 Lamb1 ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
    have A67: " for i be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 i ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2) implies (\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2)"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A68: "?P(i)"
      show "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
      proof(rule impMI ,rule impI)
        assume A69: "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M"
          and A70: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
        have A71: "\<one>\<^sub>M <=XXREAL-0R1 i or \<one>\<^sub>M =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
          using A69 nat_1_th_8 sorry
        have A72: "EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 c=RELSET-1R1\<^bsub>(X,X)\<^esub> EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
          using eqrel_1_def_2 sorry
        have A73: "i <XXREAL-0R3 lenFINSEQ-1K4 f"
          using A70 nat_1_th_13 sorry
        have "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
        proof-
          show "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
          proof-
            have cases: "\<one>\<^sub>M <=XXREAL-0R1 i or 0NUMBERSK6 =XBOOLE-0R4 i"
              using A71 sorry
            have case1: "\<one>\<^sub>M <=XXREAL-0R1 i implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
            proof(rule impI)
              assume A74: "\<one>\<^sub>M <=XXREAL-0R1 i"
              then have "[TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                using A66 A73 sorry
              thus "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
                using A68 A70 A72 A74 eqrel_1_th_7 nat_1_th_13 sorry
            qed
            have case2: "0NUMBERSK6 =XBOOLE-0R4 i implies [TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
            proof(rule impI)
              assume A75: "0NUMBERSK6 =XBOOLE-0R4 i"
              have "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 \<one>\<^sub>M ] inHIDDENR3 EqR1"
                using A1 A64 eqrel_1_th_5 sorry
              then have "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 \<one>\<^sub>M ] inHIDDENR3 EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
                using xboole_0_def_3 sorry
              thus "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
                using A72 A75 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "[TARSKIK4 f .FUNCT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
           sorry
      qed
    qed "sorry"
    have A76: "?P(0NUMBERSK6)"
       sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A76 A67 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 EqR1 \<inverse>\\/\<inverse>EQREL-1K5\<^bsub>(X)\<^esub> EqR2"
      using A63 A64 A65 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_29:
" for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds  for E be Equivalence-RelationEQREL-1M2-of X holds E =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) or ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x))"
proof-
  have " for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds  for E be Equivalence-RelationEQREL-1M2-of X holds E =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 implies ( for x be objectHIDDENM1 holds  not ((x inHIDDENR3 X &  not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x)) &  not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR1 assume [ty]: "EqR1 be Equivalence-RelationEQREL-1M2-of X"
    fix EqR2 assume [ty]: "EqR2 be Equivalence-RelationEQREL-1M2-of X"
    fix E assume [ty]: "E be Equivalence-RelationEQREL-1M2-of X"
    assume A1: "E =RELSET-1R2\<^bsub>(X,X)\<^esub> EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) or ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) &  not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x) implies  False )"
      proof(rule ballI,rule impI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        assume A2: " not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x)"
          and A3: " not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x)"
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) &  not y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) or y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) &  not y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x)"
          using A2 tarski_th_2 sorry
        have A5: "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) &  not y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) implies  False "
        proof(rule impMI ,rule impI)
          assume A6: "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x)"
            and A7: " not y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x)"
          have "[TARSKIK4 y,x ] inHIDDENR3 EqR1"
            using A6 eqrel_1_th_19 sorry
          then have "[TARSKIK4 y,x ] inHIDDENR3 E"
            using A1 xboole_0_def_3 sorry
          thus " False "
            using A7 eqrel_1_th_19 sorry
        qed
        then have A8: "[TARSKIK4 y,x ] inHIDDENR3 E"
          using A4 eqrel_1_th_19 sorry
        obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A9: "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) &  not z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x) or z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x) &  not z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x)"
          using A3 tarski_th_2 sorry
        have A10: "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x) &  not z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) implies  False "
        proof(rule impMI ,rule impI)
          assume A11: "z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x)"
            and A12: " not z inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x)"
          have "[TARSKIK4 z,x ] inHIDDENR3 EqR2"
            using A11 eqrel_1_th_19 sorry
          then have "[TARSKIK4 z,x ] inHIDDENR3 E"
            using A1 xboole_0_def_3 sorry
          thus " False "
            using A12 eqrel_1_th_19 sorry
        qed
        then have A13: "[TARSKIK4 z,x ] inHIDDENR3 E"
          using A9 eqrel_1_th_19 sorry
        have " not [TARSKIK4 z,x ] inHIDDENR3 EqR2"
          using A9 A10 eqrel_1_th_19 sorry
        then have A14: "[TARSKIK4 z,x ] inHIDDENR3 EqR1"
          using A1 A13 xboole_0_def_3 sorry
        have A15: "[TARSKIK4 y,z ] inHIDDENR3 EqR1 implies  False "
        proof(rule impI)
          assume "[TARSKIK4 y,z ] inHIDDENR3 EqR1"
          then have A16: "[TARSKIK4 z,y ] inHIDDENR3 EqR1"
            using eqrel_1_th_6 sorry
          have "[TARSKIK4 x,z ] inHIDDENR3 EqR1"
            using A14 eqrel_1_th_6 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 EqR1"
            using A16 eqrel_1_th_7 sorry
          then have "[TARSKIK4 y,x ] inHIDDENR3 EqR1"
            using eqrel_1_th_6 sorry
          thus " False "
            using A4 A5 eqrel_1_th_19 sorry
        qed
        have " not [TARSKIK4 y,x ] inHIDDENR3 EqR1"
          using A4 A5 eqrel_1_th_19 sorry
        then have A17: "[TARSKIK4 y,x ] inHIDDENR3 EqR2"
          using A1 A8 xboole_0_def_3 sorry
        have A18: "[TARSKIK4 y,z ] inHIDDENR3 EqR2 implies  False "
        proof(rule impI)
          assume A19: "[TARSKIK4 y,z ] inHIDDENR3 EqR2"
          have "[TARSKIK4 x,y ] inHIDDENR3 EqR2"
            using A17 eqrel_1_th_6 sorry
          then have "[TARSKIK4 x,z ] inHIDDENR3 EqR2"
            using A19 eqrel_1_th_7 sorry
          then have "[TARSKIK4 z,x ] inHIDDENR3 EqR2"
            using eqrel_1_th_6 sorry
          thus " False "
            using A9 A10 eqrel_1_th_19 sorry
        qed
        have "[TARSKIK4 x,z ] inHIDDENR3 E"
          using A13 eqrel_1_th_6 sorry
        then have "[TARSKIK4 y,z ] inHIDDENR3 E"
          using A8 eqrel_1_th_7 sorry
        thus " False "
          using A1 A18 A15 xboole_0_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " for x be objectHIDDENM1 holds  not ((x inHIDDENR3 X &  not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x)) &  not ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(E,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_30:
" for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X implies EqR1 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X or EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for EqR1 be Equivalence-RelationEQREL-1M2-of X holds  for EqR2 be Equivalence-RelationEQREL-1M2-of X holds EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X implies  not ( not EqR1 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X &  not EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR1 assume [ty]: "EqR1 be Equivalence-RelationEQREL-1M2-of X"
    fix EqR2 assume [ty]: "EqR2 be Equivalence-RelationEQREL-1M2-of X"
    assume A1: "EqR1 \\/EQREL-1K3\<^bsub>(X)\<^esub> EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X"
    have "X <>HIDDENR2 {}XBOOLE-0K1 implies EqR1 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X or EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X"
    proof-
      have "X <>HIDDENR2 {}XBOOLE-0K1 implies  not ( not EqR1 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X &  not EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X)"
      proof(rule impI)
        let ?y = "the ElementSUBSET-1M1-of X"
        have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) =XBOOLE-0R4 X or ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x) =XBOOLE-0R4 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 X"
          then have "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(nablaEQREL-1K1 X,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) or ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(nablaEQREL-1K1 X,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x)"
            using A1 eqrel_1_th_29 sorry
          thus "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,x) =XBOOLE-0R4 X or ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,x) =XBOOLE-0R4 X"
            using A3 eqrel_1_th_26 sorry
        qed "sorry"
        assume "X <>HIDDENR2 {}XBOOLE-0K1"
        then have "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR1,?y) =XBOOLE-0R4 X or ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR2,?y) =XBOOLE-0R4 X"
          using A2 sorry
        thus " not ( not EqR1 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X &  not EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X)"
          using eqrel_1_th_27 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( not EqR1 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X &  not EqR2 =RELSET-1R2\<^bsub>(X,X)\<^esub> nablaEQREL-1K1 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef eqrel_1_def_3 ("ClassEQREL-1K8\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "X be setHIDDENM2", "EqR be Equivalence-RelationEQREL-1M2-of X"
"func ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR \<rightarrow> Subset-FamilySETFAM-1M1-of X means
  \<lambda>it.  for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 it iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))"
proof-
  (*existence*)
    show " ex it be Subset-FamilySETFAM-1M1-of X st  for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 it iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))"
    proof-
      have " ex tVar4 be Subset-FamilySETFAM-1M1-of X st  for A be SubsetSUBSET-1M2-of X holds  not (A inTARSKIR2 tVar4 & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)))) &  not ( not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))) &  not A inTARSKIR2 tVar4)"
      proof-
        let ?P = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st x inHIDDENR3 X & Lamb1 =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
        obtain F where
          [ty]:"F be Subset-FamilySETFAM-1M1-of X" and 
          A1: " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F iff ?P(A)"
          using subset_1_sch_3 sorry
        show " ex tVar4 be Subset-FamilySETFAM-1M1-of X st  for A be SubsetSUBSET-1M2-of X holds  not (A inTARSKIR2 tVar4 & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)))) &  not ( not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))) &  not A inTARSKIR2 tVar4)"
        proof(rule bexI[of _ "F"])
          show " for A be SubsetSUBSET-1M2-of X holds  not (A inTARSKIR2 F & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)))) &  not ( not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))) &  not A inTARSKIR2 F)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Subset-FamilySETFAM-1M1-of X holds  for it2 be Subset-FamilySETFAM-1M1-of X holds ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 it1 iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))) & ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 it2 iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))) implies it1 =HIDDENR1 it2"
    proof-
      have " for F1 be Subset-FamilySETFAM-1M1-of X holds  for F2 be Subset-FamilySETFAM-1M1-of X holds ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F1 iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))) & ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F2 iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))) implies F1 =HIDDENR1 F2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix F1 assume [ty]: "F1 be Subset-FamilySETFAM-1M1-of X"
        fix F2 assume [ty]: "F2 be Subset-FamilySETFAM-1M1-of X"
        assume A2: " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F1 iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))"
          and A3: " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F2 iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))"
        have " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F1 iff A inTARSKIR2 F2"
        proof(rule ballI)
          fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
          have "A inTARSKIR2 F1 iff ( ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x))"
            using A2 sorry
          thus "A inTARSKIR2 F1 iff A inTARSKIR2 F2"
            using A3 sorry
        qed "sorry"
        thus "F1 =HIDDENR1 F2"
          using setfam_1_th_31 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem eqrel_1_th_31:
" for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds X =XBOOLE-0R4 {}XBOOLE-0K1 implies ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds X =XBOOLE-0R4 {}XBOOLE-0K1 & ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR assume [ty]: "EqR be Equivalence-RelationEQREL-1M2-of X"
    assume A1: "X =XBOOLE-0R4 {}XBOOLE-0K1"
      and A2: "ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR <>HIDDENR2 {}XBOOLE-0K1"
    let ?z = "the ElementSUBSET-1M1-of ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR"
    have "?z be SubsetSUBSET-1M2-of X"
      using A2 tarski_def_3 sorry
    then have " ex x be objectHIDDENM1 st x inHIDDENR3 X & ?z =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
      using A2 eqrel_1_def_3 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef eqrel_1_def_4 ("a-partitionEQREL-1M3-of  _ " [70]70 ) where
  mlet "X be setHIDDENM2"
"mode a-partitionEQREL-1M3-of X \<rightarrow> Subset-FamilySETFAM-1M1-of X means
  (\<lambda>it. unionSETFAM-1K5\<^bsub>(X)\<^esub> it =XBOOLE-0R4 X & ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 it implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 it implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)))"
proof-
  (*existence*)
    show " ex it be Subset-FamilySETFAM-1M1-of X st unionSETFAM-1K5\<^bsub>(X)\<^esub> it =XBOOLE-0R4 X & ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 it implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 it implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B))"
    proof-
      have " ex tVar5 be Subset-FamilySETFAM-1M1-of X st unionSETFAM-1K5\<^bsub>(X)\<^esub> tVar5 =XBOOLE-0R4 X & ( for A be SubsetSUBSET-1M2-of X holds  not (A inTARSKIR2 tVar5 &  not ( not A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds  not ((B inTARSKIR2 tVar5 &  not A =XBOOLE-0R4 B) &  not A missesXBOOLE-0R1 B)))))"
      proof-
        let ?P = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st x inHIDDENR3 X & Lamb1 =XBOOLE-0R4 {TARSKIK1 x}"
        obtain F where
          [ty]:"F be Subset-FamilySETFAM-1M1-of X" and 
          A1: " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F iff ?P(A)"
          using subset_1_sch_3 sorry
        have A2: " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 F implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
        proof-
          have " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 F implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 F implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B))"
          proof(rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
            fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
            assume "A inTARSKIR2 F"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              "x inHIDDENR3 X"and A3: "A =XBOOLE-0R4 {TARSKIK1 x}"
              using A1 sorry
            show "A <>HIDDENR2 {}XBOOLE-0K1"
              using A3 sorry
            fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
            assume "B inTARSKIR2 F"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              "y inHIDDENR3 X"and A4: "B =XBOOLE-0R4 {TARSKIK1 y}"
              using A1 sorry
            have " not x =HIDDENR1 y implies A missesXBOOLE-0R1 B"
            proof(rule impI)
              assume A5: " not x =HIDDENR1 y"
              have " for z be objectHIDDENM1 holds z inHIDDENR3 A implies  not z inHIDDENR3 B"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 A"
                then have " not z =HIDDENR1 y"
                  using A3 A5 tarski_def_1 sorry
                thus " not z inHIDDENR3 B"
                  using A4 tarski_def_1 sorry
              qed "sorry"
              thus "A missesXBOOLE-0R1 B"
                using xboole_0_th_3 sorry
            qed
            thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
              using A3 A4 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " ex tVar5 be Subset-FamilySETFAM-1M1-of X st unionSETFAM-1K5\<^bsub>(X)\<^esub> tVar5 =XBOOLE-0R4 X & ( for A be SubsetSUBSET-1M2-of X holds  not (A inTARSKIR2 tVar5 &  not ( not A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds  not ((B inTARSKIR2 tVar5 &  not A =XBOOLE-0R4 B) &  not A missesXBOOLE-0R1 B)))))"
        proof(rule bexI[of _ "F"])
          have " for y be objectHIDDENM1 holds y inHIDDENR3 X iff ( ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 F)"
          proof(rule ballI)
            fix y assume [ty]: "y be objectHIDDENM1"
            have "y inHIDDENR3 X implies ( ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 F)"
            proof(rule impI)
              let ?Z = "{TARSKIK1 y}"
              assume A6: "y inHIDDENR3 X"
              then have "?Z be SubsetSUBSET-1M2-of X"
                using zfmisc_1_th_31 sorry
              then have "y inHIDDENR3 ?Z & ?Z inTARSKIR2 F"
                using A1 A6 tarski_def_1 sorry
              thus " ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 F"
                 sorry
            qed
            thus "y inHIDDENR3 X iff ( ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 F)"
               sorry
          qed "sorry"
          thus "unionSETFAM-1K5\<^bsub>(X)\<^esub> F =XBOOLE-0R4 X & ( for A be SubsetSUBSET-1M2-of X holds  not (A inTARSKIR2 F &  not ( not A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds  not ((B inTARSKIR2 F &  not A =XBOOLE-0R4 B) &  not A missesXBOOLE-0R1 B)))))"
            using A2 tarski_def_4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem eqrel_1_th_32:
" for P be a-partitionEQREL-1M3-of {}XBOOLE-0K1 holds P =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for P be a-partitionEQREL-1M3-of {}XBOOLE-0K1 holds  not P =XBOOLE-0R4 {}XBOOLE-0K1 implies  not  True "
  proof(rule ballI,rule impI)
    fix P assume [ty]: "P be a-partitionEQREL-1M3-of {}XBOOLE-0K1"
    assume " not P =XBOOLE-0R4 {}XBOOLE-0K1"
    then obtain Z where
      [ty]:"Z be objectHIDDENM1" and 
      A1: "Z inHIDDENR3 P"
      using xboole_0_def_1 sorry
    have "Z <>HIDDENR2 {}XBOOLE-0K1"
      using A1 eqrel_1_def_4 sorry
    thus " not  True "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_cl_3:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that emptyXBOOLE-0V1 for a-partitionEQREL-1M3-of X"
proof
(*coherence*)
  show " for it be a-partitionEQREL-1M3-of X holds it be emptyXBOOLE-0V1"
    using eqrel_1_th_32 sorry
qed "sorry"

mtheorem eqrel_1_cl_4:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster emptyXBOOLE-0V1 for a-partitionEQREL-1M3-of X"
proof
(*existence*)
  show " ex it be a-partitionEQREL-1M3-of X st it be emptyXBOOLE-0V1"
  proof-
    have " ex tVar6 be a-partitionEQREL-1M3-of X st tVar6 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar6 be a-partitionEQREL-1M3-of X st tVar6 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "the a-partitionEQREL-1M3-of X"])
        show "the a-partitionEQREL-1M3-of X be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem eqrel_1_th_33:
" for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR be a-partitionEQREL-1M3-of X"
proof-
  have " for X be setHIDDENM2 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR be a-partitionEQREL-1M3-of X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix EqR assume [ty]: "EqR be Equivalence-RelationEQREL-1M2-of X"
    have Cut1128: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR)"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 X implies ( ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR)"
      proof(rule impI)
        obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A1: "Z =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
           sorry
        assume A2: "x inHIDDENR3 X"
        then have "Z inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR"
          using A1 eqrel_1_def_3 sorry
        thus " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR"
          using A2 A1 eqrel_1_th_20 sorry
      qed
      thus "x inHIDDENR3 X iff ( ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR)"
         sorry
    qed "sorry"
    have "unionSETFAM-1K5\<^bsub>(X)\<^esub> (ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR) =XBOOLE-0R4 X & ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)))"
    proof(rule conjMI,rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
      show "unionSETFAM-1K5\<^bsub>(X)\<^esub> (ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR) =XBOOLE-0R4 X"
        using tarski_def_4 Cut1128 sorry
      fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
      assume "A inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR"
      then have A3: " ex x be objectHIDDENM1 st x inHIDDENR3 X & A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x)"
        using eqrel_1_def_3 sorry
      thus "A <>HIDDENR2 {}XBOOLE-0K1"
        using eqrel_1_th_20 sorry
      fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
      assume "B inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR"
      then have " ex y be objectHIDDENM1 st y inHIDDENR3 X & B =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
        using eqrel_1_def_3 sorry
      thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
        using A3 eqrel_1_th_24 sorry
    qed "sorry"
    thus "ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR be a-partitionEQREL-1M3-of X"
      using eqrel_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_34:
" for X be setHIDDENM2 holds  for P be a-partitionEQREL-1M3-of X holds  ex EqR be Equivalence-RelationEQREL-1M2-of X st P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR"
proof-
  have " for X be setHIDDENM2 holds  for P be a-partitionEQREL-1M3-of X holds  not ( for EqR be Equivalence-RelationEQREL-1M2-of X holds  not P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix P assume [ty]: "P be a-partitionEQREL-1M3-of X"
    have A1: "X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex EqR be Equivalence-RelationEQREL-1M2-of X st P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR)"
    proof-
      have "X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar8 be Equivalence-RelationEQREL-1M2-of X st P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> tVar8)"
      proof(rule impI)
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be SubsetSUBSET-1M2-of X st (A inTARSKIR2 P & Lamb1 inHIDDENR3 A) & Lamb2 inHIDDENR3 A"
        assume "X <>HIDDENR2 {}XBOOLE-0K1"
        have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?P(x,y) & ?P(y,z) implies ?P(x,z)"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ( ex A be SubsetSUBSET-1M2-of X st A inTARSKIR2 P & (x inHIDDENR3 A & y inHIDDENR3 A)) implies (( ex B be SubsetSUBSET-1M2-of X st B inTARSKIR2 P & (y inHIDDENR3 B & z inHIDDENR3 B)) implies ( ex A be SubsetSUBSET-1M2-of X st (A inTARSKIR2 P & x inHIDDENR3 A) & z inHIDDENR3 A))"
          proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            fix z assume [ty]: "z be objectHIDDENM1"
            assume Given: " ex A be SubsetSUBSET-1M2-of X st A inTARSKIR2 P & (x inHIDDENR3 A & y inHIDDENR3 A)"
            then obtain A where
              [ty]:"A be SubsetSUBSET-1M2-of X" and 
              A3: "A inTARSKIR2 P"and A4: "x inHIDDENR3 A & y inHIDDENR3 A"
               sorry
            assume Given: " ex B be SubsetSUBSET-1M2-of X st B inTARSKIR2 P & (y inHIDDENR3 B & z inHIDDENR3 B)"
            then obtain B where
              [ty]:"B be SubsetSUBSET-1M2-of X" and 
              A5: "B inTARSKIR2 P"and A6: "y inHIDDENR3 B & z inHIDDENR3 B"
               sorry
            have "A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B"
              using A3 A5 eqrel_1_def_4 sorry
            thus " ex A be SubsetSUBSET-1M2-of X st (A inTARSKIR2 P & x inHIDDENR3 A) & z inHIDDENR3 A"
              using A3 A4 A6 xboole_0_th_3 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A7: "unionSETFAM-1K5\<^bsub>(X)\<^esub> P =XBOOLE-0R4 X"
          using eqrel_1_def_4 sorry
        have A8: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ?P(x,x)"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex tVar7 be SubsetSUBSET-1M2-of X st (tVar7 inTARSKIR2 P & x inHIDDENR3 tVar7) & x inHIDDENR3 tVar7)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X"
            then obtain Z where
              [ty]:"Z be setHIDDENM2" and 
              A9: "x inHIDDENR3 Z"and A10: "Z inTARSKIR2 P"
              using A7 tarski_def_4 sorry
            obtain A where 
              [ty]:"A be SubsetSUBSET-1M2-of X" and ADef:"A = Z"
              using A10 sorry
            show " ex tVar7 be SubsetSUBSET-1M2-of X st (tVar7 inTARSKIR2 P & x inHIDDENR3 tVar7) & x inHIDDENR3 tVar7"
            proof(rule bexI[of _ "A"])
              show "(A inTARSKIR2 P & x inHIDDENR3 A) & x inHIDDENR3 A"
                using A9 A10 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A11: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?P(x,y) implies ?P(y,x)"
           sorry
        obtain R where
          [ty]:"R be Equivalence-RelationEQREL-1M2-of X" and 
          A12: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 X & y inHIDDENR3 X) & ?P(x,y)"
          using eqrel_1_sch_1 A8 A11 A2 sorry
        show " ex tVar8 be Equivalence-RelationEQREL-1M2-of X st P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> tVar8"
        proof(rule bexI[of _ "R"])
          have " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 P iff A inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> R"
          proof(rule ballI)
            fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
            have A13: "A inTARSKIR2 P implies A inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> R"
            proof(rule impI)
              let ?x = "the ElementSUBSET-1M1-of A"
              assume A14: "A inTARSKIR2 P"
              then have A15: "A <>HIDDENR2 {}XBOOLE-0K1"
                using eqrel_1_def_4 sorry
              then have A16: "?x inTARSKIR2 X"
                using tarski_def_3 sorry
              have " for y be objectHIDDENM1 holds y inHIDDENR3 A iff y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,the ElementSUBSET-1M1-of A)"
              proof(rule ballI)
                fix y assume [ty]: "y be objectHIDDENM1"
                have A17: "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,the ElementSUBSET-1M1-of A) implies y inHIDDENR3 A"
                proof(rule impI)
                  assume "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,?x)"
                  then have "[TARSKIK4 y,?x ] inHIDDENR3 R"
                    using eqrel_1_th_19 sorry
                  then obtain B where
                    [ty]:"B be SubsetSUBSET-1M2-of X" and 
                    A18: "B inTARSKIR2 P & y inHIDDENR3 B"and A19: "?x inTARSKIR2 B"
                    using A12 sorry
                  have "A meetsXBOOLE-0R5 B"
                    using A15 A19 xboole_0_th_3 sorry
                  thus "y inHIDDENR3 A"
                    using A14 A18 eqrel_1_def_4 sorry
                qed
                have "y inHIDDENR3 A implies y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,the ElementSUBSET-1M1-of A)"
                proof(rule impI)
                  assume "y inHIDDENR3 A"
                  then have "[TARSKIK4 y,?x ] inHIDDENR3 R"
                    using A12 A14 A16 sorry
                  thus "y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,the ElementSUBSET-1M1-of A)"
                    using eqrel_1_th_19 sorry
                qed
                thus "y inHIDDENR3 A iff y inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,the ElementSUBSET-1M1-of A)"
                  using A17 sorry
              qed "sorry"
              then have "A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,?x)"
                using tarski_th_2 sorry
              thus "A inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> R"
                using A16 eqrel_1_def_3 sorry
            qed
            have "A inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> R implies A inTARSKIR2 P"
            proof(rule impI)
              assume "A inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> R"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A20: "x inHIDDENR3 X"and A21: "A =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
                using eqrel_1_def_3 sorry
              have "x inHIDDENR3 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(R,x)"
                using A20 eqrel_1_th_20 sorry
              then have "[TARSKIK4 x,x ] inHIDDENR3 R"
                using eqrel_1_th_19 sorry
              then obtain B where
                [ty]:"B be SubsetSUBSET-1M2-of X" and 
                A22: "B inTARSKIR2 P"and A23: "x inHIDDENR3 B"and "x inHIDDENR3 B"
                using A12 sorry
              have " for y be objectHIDDENM1 holds y inHIDDENR3 A iff y inHIDDENR3 B"
              proof(rule ballI)
                fix y assume [ty]: "y be objectHIDDENM1"
                have A24: "y inHIDDENR3 A implies y inHIDDENR3 B"
                proof(rule impI)
                  assume "y inHIDDENR3 A"
                  then have "[TARSKIK4 y,x ] inHIDDENR3 R"
                    using A21 eqrel_1_th_19 sorry
                  then obtain C where
                    [ty]:"C be SubsetSUBSET-1M2-of X" and 
                    A25: "C inTARSKIR2 P & y inHIDDENR3 C"and A26: "x inHIDDENR3 C"
                    using A12 sorry
                  have "B meetsXBOOLE-0R5 C"
                    using A23 A26 xboole_0_th_3 sorry
                  thus "y inHIDDENR3 B"
                    using A22 A25 eqrel_1_def_4 sorry
                qed
                have "y inHIDDENR3 B implies y inHIDDENR3 A"
                proof(rule impI)
                  assume "y inHIDDENR3 B"
                  then have "[TARSKIK4 y,x ] inHIDDENR3 R"
                    using A12 A22 A23 sorry
                  thus "y inHIDDENR3 A"
                    using A21 eqrel_1_th_19 sorry
                qed
                thus "y inHIDDENR3 A iff y inHIDDENR3 B"
                  using A24 sorry
              qed "sorry"
              thus "A inTARSKIR2 P"
                using A22 tarski_th_2 sorry
            qed
            thus "A inTARSKIR2 P iff A inTARSKIR2 ClassEQREL-1K8\<^bsub>(X)\<^esub> R"
              using A13 sorry
          qed "sorry"
          thus "P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> R"
            using setfam_1_th_31 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    have "X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex EqR be Equivalence-RelationEQREL-1M2-of X st P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR)"
    proof-
      have "X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar9 be Equivalence-RelationEQREL-1M2-of X st P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> tVar9)"
      proof(rule impI)
        let ?EqR1 = "the Equivalence-RelationEQREL-1M2-of X"
        assume A27: "X =XBOOLE-0R4 {}XBOOLE-0K1"
        show " ex tVar9 be Equivalence-RelationEQREL-1M2-of X st P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> tVar9"
        proof(rule bexI[of _ "?EqR1"])
          have "P =XBOOLE-0R4 {}XBOOLE-0K1"
            using A27 sorry
          thus "P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> (the Equivalence-RelationEQREL-1M2-of X)"
            using A27 eqrel_1_th_31 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( for EqR be Equivalence-RelationEQREL-1M2-of X holds  not P =XBOOLE-0R4 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_35:
" for X be setHIDDENM2 holds  for y be objectHIDDENM1 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies ([TARSKIK4 x,y ] inHIDDENR3 EqR iff ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y))"
  using eqrel_1_lm_2 sorry

mtheorem eqrel_1_th_36:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds x inHIDDENR3 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR implies ( ex y be ElementSUBSET-1M1-of X st x =HIDDENR1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y))"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for EqR be Equivalence-RelationEQREL-1M2-of X holds x inHIDDENR3 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR implies ( ex tVar10 be ElementSUBSET-1M1-of X st x =HIDDENR1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,tVar10))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix EqR assume [ty]: "EqR be Equivalence-RelationEQREL-1M2-of X"
    assume A1: "x inHIDDENR3 ClassEQREL-1K8\<^bsub>(X)\<^esub> EqR"
    then have 
      [ty]:"x be SubsetSUBSET-1M2-of X"
       sorry
    obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A2: "y inHIDDENR3 X"and A3: "x =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
      using A1 eqrel_1_def_3 sorry
    have 
      [ty]:"y be ElementSUBSET-1M1-of X"
      using A2 sorry
    show " ex tVar10 be ElementSUBSET-1M1-of X st x =HIDDENR1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,tVar10)"
    proof(rule bexI[of _ "y"])
      show "x =HIDDENR1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EqR,y)"
        using A3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem eqrel_1_cl_5:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that  non emptyXBOOLE-0V1 for a-partitionEQREL-1M3-of X"
proof
(*coherence*)
  show " for it be a-partitionEQREL-1M3-of X holds it be  non emptyXBOOLE-0V1"
  proof-
    have " for P be a-partitionEQREL-1M3-of X holds  not P be emptyXBOOLE-0V1"
    proof(rule ballI)
      let ?x = "the ElementSUBSET-1M1-of X"
      fix P assume [ty]: "P be a-partitionEQREL-1M3-of X"
      have "unionSETFAM-1K5\<^bsub>(X)\<^esub> P =XBOOLE-0R4 X"
        using eqrel_1_def_4 sorry
      then have " ex A be setHIDDENM2 st ?x inTARSKIR2 A & A inTARSKIR2 P"
        using tarski_def_4 sorry
      thus " not P be emptyXBOOLE-0V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem eqrel_1_cl_6:
  mlet "X be setHIDDENM2"
"cluster note-that with-non-empty-elementsSETFAM-1V1 for a-partitionEQREL-1M3-of X"
proof
(*coherence*)
  show " for it be a-partitionEQREL-1M3-of X holds it be with-non-empty-elementsSETFAM-1V1"
  proof-
    have " for P be a-partitionEQREL-1M3-of X holds P be with-non-empty-elementsSETFAM-1V1"
    proof(rule ballI)
      fix P assume [ty]: "P be a-partitionEQREL-1M3-of X"
      have "{}XBOOLE-0K1 inTARSKIR2 P implies  False "
      proof(rule impI)
        assume "{}XBOOLE-0K1 inTARSKIR2 P"
        thus " False "
          using eqrel_1_def_4 sorry
      qed
      thus "P be with-non-empty-elementsSETFAM-1V1"
        using setfam_1_def_8 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) EQREL_1K9("ClassEQREL-1K9\<^bsub>'( _ ')\<^esub>  _ " [0,164]164) where
  "ClassEQREL-1K9\<^bsub>(X)\<^esub> R \<equiv> ClassEQREL-1K8\<^bsub>(X)\<^esub> R"

mtheorem eqrel_1_add_5:
  mlet "X be setHIDDENM2", "R be Equivalence-RelationEQREL-1M2-of X"
"cluster ClassEQREL-1K8\<^bsub>(X)\<^esub> R as-term-is a-partitionEQREL-1M3-of X"
proof
(*coherence*)
  show "ClassEQREL-1K8\<^bsub>(X)\<^esub> R be a-partitionEQREL-1M3-of X"
    using eqrel_1_th_33 sorry
qed "sorry"

mtheorem eqrel_1_cl_7:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "R be Equivalence-RelationEQREL-1M2-of I"
"cluster ClassEQREL-1K9\<^bsub>(I)\<^esub> R as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "ClassEQREL-1K9\<^bsub>(I)\<^esub> R be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem eqrel_1_cl_8:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "R be Equivalence-RelationEQREL-1M2-of I"
"cluster ClassEQREL-1K9\<^bsub>(I)\<^esub> R as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "ClassEQREL-1K9\<^bsub>(I)\<^esub> R be with-non-empty-elementsSETFAM-1V1"
     sorry
qed "sorry"

syntax EQREL_1K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("EqClassEQREL-1K10\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164)
translations "EqClassEQREL-1K10\<^bsub>(I)\<^esub>(R,x)" \<rightharpoonup> "ClassEQREL-1K6(R,x)"

syntax EQREL_1K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("EqClassEQREL-1K11\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164)
translations "EqClassEQREL-1K11\<^bsub>(I)\<^esub>(R,x)" \<rightharpoonup> "ImRELAT-1K12(R,x)"

mtheorem eqrel_1_add_6:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "R be Equivalence-RelationEQREL-1M2-of I", "x be ElementSUBSET-1M1-of I"
"cluster ImRELAT-1K12(R,x) as-term-is ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 I)\<^esub>-of ClassEQREL-1K9\<^bsub>(I)\<^esub> R"
proof
(*coherence*)
  show "ImRELAT-1K12(R,x) be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 I)\<^esub>-of ClassEQREL-1K9\<^bsub>(I)\<^esub> R"
  proof-
    have "ClassEQREL-1K7\<^bsub>(I,I)\<^esub>(R,x) be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 I)\<^esub>-of ClassEQREL-1K9\<^bsub>(I)\<^esub> R"
    proof-
      show "ClassEQREL-1K7\<^bsub>(I,I)\<^esub>(R,x) be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 I)\<^esub>-of ClassEQREL-1K9\<^bsub>(I)\<^esub> R"
        using eqrel_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef eqrel_1_def_5 ("SmallestPartitionEQREL-1K12  _ " [164]164 ) where
  mlet "X be setHIDDENM2"
"func SmallestPartitionEQREL-1K12 X \<rightarrow> setHIDDENM2 equals
  ClassEQREL-1K9\<^bsub>(X)\<^esub> idPARTFUN1K6 X"
proof-
  (*coherence*)
    show "ClassEQREL-1K9\<^bsub>(X)\<^esub> idPARTFUN1K6 X be setHIDDENM2"
       sorry
qed "sorry"

abbreviation(input) EQREL_1K13("SmallestPartitionEQREL-1K13  _ " [164]164) where
  "SmallestPartitionEQREL-1K13 X \<equiv> SmallestPartitionEQREL-1K12 X"

mtheorem eqrel_1_add_7:
  mlet "X be setHIDDENM2"
"cluster SmallestPartitionEQREL-1K12 X as-term-is a-partitionEQREL-1M3-of X"
proof
(*coherence*)
  show "SmallestPartitionEQREL-1K12 X be a-partitionEQREL-1M3-of X"
     sorry
qed "sorry"

mtheorem eqrel_1_th_37:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds SmallestPartitionEQREL-1K13 X =XBOOLE-0R4 {{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  }"
proof(rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  let ?Y = "{{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  }"
  have "( for x be objectHIDDENM1 holds x inHIDDENR3 SmallestPartitionEQREL-1K13 X implies x inHIDDENR3 {{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  }) & {{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  } c=TARSKIR1 SmallestPartitionEQREL-1K13 X"
  proof(rule conjMI)
    show " for x be objectHIDDENM1 holds x inHIDDENR3 SmallestPartitionEQREL-1K13 X implies x inHIDDENR3 {{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 SmallestPartitionEQREL-1K13 X"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 X"and A2: "x =HIDDENR1 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,y)"
        using eqrel_1_def_3 sorry
      have "x =HIDDENR1 {TARSKIK1 y}"
        using A1 A2 eqrel_1_th_25 sorry
      thus "x inHIDDENR3 {{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  }"
        using A1 sorry
    qed "sorry"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  } implies x inHIDDENR3 SmallestPartitionEQREL-1K13 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 ?Y"
      then obtain y where
        [ty]:"y be ElementSUBSET-1M1-of X" and 
        A3: "x =HIDDENR1 {DOMAIN-1K6\<^bsub>(X)\<^esub> y}"
         sorry
      have "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,y) =HIDDENR1 x"
        using A3 eqrel_1_th_25 sorry
      thus "x inHIDDENR3 SmallestPartitionEQREL-1K13 X"
        using eqrel_1_def_3 sorry
    qed "sorry"
    thus "{{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  } c=TARSKIR1 SmallestPartitionEQREL-1K13 X"
      using tarski_def_3 sorry
  qed
  thus "SmallestPartitionEQREL-1K13 X =XBOOLE-0R4 {{DOMAIN-1K6\<^bsub>(X)\<^esub> x} where x be ElementSUBSET-1M1-of X :  True  }"
    using tarski_def_3 xboole_0_def_10 sorry
qed "sorry"

reserve X for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve x for "ElementSUBSET-1M1-of X"
mdef eqrel_1_def_6 ("EqClassEQREL-1K14\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of X", "S1 be a-partitionEQREL-1M3-of X"
"func EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) \<rightarrow> SubsetSUBSET-1M2-of X means
  \<lambda>it. x inTARSKIR2 it & it inTARSKIR2 S1"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of X st x inTARSKIR2 it & it inTARSKIR2 S1"
    proof-
      have " ex tVar11 be SubsetSUBSET-1M2-of X st x inTARSKIR2 tVar11 & tVar11 inTARSKIR2 S1"
      proof-
        obtain EQR where
          [ty]:"EQR be Equivalence-RelationEQREL-1M2-of X" and 
          A1: "S1 =XBOOLE-0R4 ClassEQREL-1K9\<^bsub>(X)\<^esub> EQR"
          using eqrel_1_th_34 sorry
        show " ex tVar11 be SubsetSUBSET-1M2-of X st x inTARSKIR2 tVar11 & tVar11 inTARSKIR2 S1"
        proof(rule bexI[of _ "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,x)"],rule conjMI)
          show "x inTARSKIR2 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,x)"
            using eqrel_1_th_20 sorry
          show "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,x) inTARSKIR2 S1"
            using A1 eqrel_1_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of X holds  for it2 be SubsetSUBSET-1M2-of X holds (x inTARSKIR2 it1 & it1 inTARSKIR2 S1) & (x inTARSKIR2 it2 & it2 inTARSKIR2 S1) implies it1 =HIDDENR1 it2"
      using eqrel_1_def_4 xboole_0_th_3 sorry
qed "sorry"

mtheorem eqrel_1_th_38:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S1 be a-partitionEQREL-1M3-of X holds  for S2 be a-partitionEQREL-1M3-of X holds ( for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2)) implies S1 =XBOOLE-0R4 S2"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S1 be a-partitionEQREL-1M3-of X holds  for S2 be a-partitionEQREL-1M3-of X holds ( for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2)) implies S1 =XBOOLE-0R4 S2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix S1 assume [ty]: "S1 be a-partitionEQREL-1M3-of X"
    fix S2 assume [ty]: "S2 be a-partitionEQREL-1M3-of X"
    assume A1: " for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2)"
    have " for P be SubsetSUBSET-1M2-of X holds (P inTARSKIR2 S1 implies P inTARSKIR2 S2) & (P inTARSKIR2 S2 implies P inTARSKIR2 S1)"
    proof(rule ballI,rule conjMI)
      fix P assume [ty]: "P be SubsetSUBSET-1M2-of X"
      show "P inTARSKIR2 S1 implies P inTARSKIR2 S2"
      proof(rule impI)
        let ?x = "the ElementSUBSET-1M1-of P"
        assume A2: "P inTARSKIR2 S1"
        then have A3: "P be  non emptyXBOOLE-0V1"
          using eqrel_1_def_4 sorry
        then have "?x inTARSKIR2 P"
           sorry
        then obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of X" and xDef:"x = ?x"
           sorry
        have "P =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1)"
          using A2 A3 eqrel_1_def_6 sorry
        then have "P =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2)"
          using A1 sorry
        thus "P inTARSKIR2 S2"
          using eqrel_1_def_6 sorry
      qed
      show "P inTARSKIR2 S2 implies P inTARSKIR2 S1"
      proof(rule impI)
        let ?x = "the ElementSUBSET-1M1-of P"
        assume A4: "P inTARSKIR2 S2"
        then have A5: "P <>HIDDENR2 {}XBOOLE-0K1"
          using eqrel_1_def_4 sorry
        then have "?x inTARSKIR2 P"
           sorry
        then obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of X" and xDef:"x = ?x"
           sorry
        have "P =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2)"
          using A4 A5 eqrel_1_def_6 sorry
        then have "P =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1)"
          using A1 sorry
        thus "P inTARSKIR2 S1"
          using eqrel_1_def_6 sorry
      qed
    qed "sorry"
    thus "S1 =XBOOLE-0R4 S2"
      using setfam_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_39:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {TARSKIK1 X} be a-partitionEQREL-1M3-of X"
proof(rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  obtain A1 where 
    [ty]:"A1 be Subset-FamilySETFAM-1M1-of X" and A1Def:"A1 = {TARSKIK1 X}"
    using zfmisc_1_th_68 sorry
  have A1: " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 A1 implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 A1 implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B)"
  proof-
    have " for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 A1 implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 A1 implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B))"
    proof(rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
      fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
      assume A2: "A inTARSKIR2 A1"
      thus "A <>HIDDENR2 {}XBOOLE-0K1"
        using tarski_def_1 sorry
      fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
      assume "B inTARSKIR2 A1"
      then have "B =XBOOLE-0R4 X"
        using tarski_def_1 sorry
      thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
        using A2 tarski_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "unionSETFAM-1K5\<^bsub>(X)\<^esub> A1 =XBOOLE-0R4 X"
     sorry
  thus "{TARSKIK1 X} be a-partitionEQREL-1M3-of X"
    using A1 eqrel_1_def_4 sorry
qed "sorry"

abbreviation(input) EQREL_1M4("Family-ClassEQREL-1M4-of  _ " [70]70) where
  "Family-ClassEQREL-1M4-of X \<equiv> Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 X"

mdef eqrel_1_def_7 ("partition-memberedEQREL-1V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr partition-memberedEQREL-1V1\<^bsub>(X)\<^esub> for Family-ClassEQREL-1M4-of X means
  (\<lambda>F.  for S be setHIDDENM2 holds S inTARSKIR2 F implies S be a-partitionEQREL-1M3-of X)"..

mtheorem eqrel_1_cl_9:
  mlet "X be setHIDDENM2"
"cluster partition-memberedEQREL-1V1\<^bsub>(X)\<^esub> for Family-ClassEQREL-1M4-of X"
proof
(*existence*)
  show " ex it be Family-ClassEQREL-1M4-of X st it be partition-memberedEQREL-1V1\<^bsub>(X)\<^esub>"
  proof-
    have " ex tVar12 be Family-ClassEQREL-1M4-of X st tVar12 be partition-memberedEQREL-1V1\<^bsub>(X)\<^esub>"
    proof-
      obtain E where 
        [ty]:"E be Family-ClassEQREL-1M4-of X" and EDef:"E = {}XBOOLE-0K1"
        using xboole_1_th_2 sorry
      show " ex tVar12 be Family-ClassEQREL-1M4-of X st tVar12 be partition-memberedEQREL-1V1\<^bsub>(X)\<^esub>"
      proof(rule bexI[of _ "E"])
        have " for S be setHIDDENM2 holds S inTARSKIR2 E implies S be a-partitionEQREL-1M3-of X"
        proof(rule ballI,rule impI)
          fix S assume [ty]: "S be setHIDDENM2"
          assume "S inTARSKIR2 E"
          thus "S be a-partitionEQREL-1M3-of X"
             sorry
        qed "sorry"
        thus "E be partition-memberedEQREL-1V1\<^bsub>(X)\<^esub>"
          using eqrel_1_def_7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax EQREL_1M5 :: " Set \<Rightarrow> Ty" ("Part-FamilyEQREL-1M5-of  _ " [70]70)
translations "Part-FamilyEQREL-1M5-of X" \<rightharpoonup> "partition-memberedEQREL-1V1\<^bsub>(X)\<^esub>\<bar>Family-ClassEQREL-1M4-of X"

reserve F for "Part-FamilyEQREL-1M5-of X"
mtheorem eqrel_1_cl_10:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for a-partitionEQREL-1M3-of X"
proof
(*existence*)
  show " ex it be a-partitionEQREL-1M3-of X st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar13 be a-partitionEQREL-1M3-of X st (tVar13 be Subset-FamilySETFAM-1M1-of X & tVar13 be a-partitionEQREL-1M3-of X) &  not tVar13 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar13 be a-partitionEQREL-1M3-of X st (tVar13 be Subset-FamilySETFAM-1M1-of X & tVar13 be a-partitionEQREL-1M3-of X) &  not tVar13 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "{TARSKIK1 X}"])
        show "({TARSKIK1 X} be Subset-FamilySETFAM-1M1-of X & {TARSKIK1 X} be a-partitionEQREL-1M3-of X) &  not {TARSKIK1 X} be emptyXBOOLE-0V1"
          using eqrel_1_th_39 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem eqrel_1_th_40:
" for X be setHIDDENM2 holds  for p be a-partitionEQREL-1M3-of X holds {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 X))\<^esub> p} be Part-FamilyEQREL-1M5-of X"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix p assume [ty]: "p be a-partitionEQREL-1M3-of X"
  have " for x be setHIDDENM2 holds x inTARSKIR2 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 X))\<^esub> p} implies x be a-partitionEQREL-1M3-of X"
    using tarski_def_1 sorry
  thus "{DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 X))\<^esub> p} be Part-FamilyEQREL-1M5-of X"
    using eqrel_1_def_7 sorry
qed "sorry"

mtheorem eqrel_1_cl_11:
  mlet "X be setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for Part-FamilyEQREL-1M5-of X"
proof
(*existence*)
  show " ex it be Part-FamilyEQREL-1M5-of X st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar14 be Part-FamilyEQREL-1M5-of X st  not tVar14 be emptyXBOOLE-0V1"
    proof-
      let ?p = "the a-partitionEQREL-1M3-of X"
      obtain P where 
        [ty]:"P be Part-FamilyEQREL-1M5-of X" and PDef:"P = {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 X))\<^esub> ?p}"
        using eqrel_1_th_40 sorry
      show " ex tVar14 be Part-FamilyEQREL-1M5-of X st  not tVar14 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "P"])
        show " not P be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem eqrel_1_th_41:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S1 be a-partitionEQREL-1M3-of X holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) meetsXBOOLE-0R5 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S1) implies EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S1)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S1 be a-partitionEQREL-1M3-of X holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) meetsXBOOLE-0R5 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S1) implies EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix S1 assume [ty]: "S1 be a-partitionEQREL-1M3-of X"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of X"
    obtain EQR where
      [ty]:"EQR be Equivalence-RelationEQREL-1M2-of X" and 
      A1: "S1 =XBOOLE-0R4 ClassEQREL-1K9\<^bsub>(X)\<^esub> EQR"
      using eqrel_1_th_34 sorry
    have A2: "y inTARSKIR2 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,y)"
      using eqrel_1_th_20 sorry
    have "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,y) inTARSKIR2 S1"
      using A1 eqrel_1_def_3 sorry
    then have A3: "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,y) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S1)"
      using A2 eqrel_1_def_6 sorry
    have A4: "x inTARSKIR2 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,x)"
      using eqrel_1_th_20 sorry
    have "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,x) inTARSKIR2 S1"
      using A1 eqrel_1_def_3 sorry
    then have A5: "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(EQR,x) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1)"
      using A4 eqrel_1_def_6 sorry
    assume "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) meetsXBOOLE-0R5 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S1)"
    thus "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S1)"
      using A5 A3 eqrel_1_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma eqrel_1_lm_3:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds  for F be Part-FamilyEQREL-1M5-of X holds  for A be setHIDDENM2 holds A inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } implies ( ex T be a-partitionEQREL-1M3-of X st T inTARSKIR2 F & A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds  for F be Part-FamilyEQREL-1M5-of X holds  for A be setHIDDENM2 holds A inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } implies ( ex tVar15 be a-partitionEQREL-1M3-of X st tVar15 inTARSKIR2 F & A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,tVar15))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    fix F assume [ty]: "F be Part-FamilyEQREL-1M5-of X"
    fix A assume [ty]: "A be setHIDDENM2"
    assume "A inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
    then obtain S where
      [ty]:"S be a-partitionEQREL-1M3-of X" and 
      A1: "A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) & S inTARSKIR2 F"
       sorry
    show " ex tVar15 be a-partitionEQREL-1M3-of X st tVar15 inTARSKIR2 F & A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,tVar15)"
    proof(rule bexI[of _ "S"])
      show "S inTARSKIR2 F & A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S)"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_42:
" for A be setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be a-partitionEQREL-1M3-of X holds A inTARSKIR2 S implies ( ex x be ElementSUBSET-1M1-of X st A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S))"
proof-
  have " for A be setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be a-partitionEQREL-1M3-of X holds A inTARSKIR2 S implies ( ex tVar16 be ElementSUBSET-1M1-of X st (tVar16 be setHIDDENM2 & tVar16 be ElementSUBSET-1M1-of X) & A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(tVar16,S))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix S assume [ty]: "S be a-partitionEQREL-1M3-of X"
    assume A1: "A inTARSKIR2 S"
    then have "A be  non emptyXBOOLE-0V1"
      using eqrel_1_def_4 sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 A"
       sorry
    show " ex tVar16 be ElementSUBSET-1M1-of X st (tVar16 be setHIDDENM2 & tVar16 be ElementSUBSET-1M1-of X) & A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(tVar16,S)"
    proof(rule bexI[of _ "x"])
      show "(x be setHIDDENM2 & x be ElementSUBSET-1M1-of X) & A =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S)"
        using A1 A2 eqrel_1_def_6 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef eqrel_1_def_8 ("IntersectionEQREL-1K15\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>Part-FamilyEQREL-1M5-of X"
"func IntersectionEQREL-1K15\<^bsub>(X)\<^esub> F \<rightarrow>  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X means
  \<lambda>it.  for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,it) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
proof-
  (*uniqueness*)
    show " for it1 be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for it2 be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds ( for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,it1) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })) & ( for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,it2) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })) implies it1 =HIDDENR1 it2"
    proof-
      have "( ex S1 be a-partitionEQREL-1M3-of X st  ex S2 be a-partitionEQREL-1M3-of X st (( for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })) & ( for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }))) &  not S1 =XBOOLE-0R4 S2) implies  False "
      proof(rule impI)
        assume Given: " ex S1 be a-partitionEQREL-1M3-of X st  ex S2 be a-partitionEQREL-1M3-of X st (( for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })) & ( for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }))) &  not S1 =XBOOLE-0R4 S2"
        then obtain S1 S2 where
          [ty]:"S1 be a-partitionEQREL-1M3-of X" "S2 be a-partitionEQREL-1M3-of X" and 
          A1: " for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"and A2: " for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"and A3: " not S1 =XBOOLE-0R4 S2"
           sorry
        have " for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2)"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
          have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
            using A1 sorry
          thus "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S1) =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S2)"
            using A2 sorry
        qed "sorry"
        thus " False "
          using A3 eqrel_1_th_38 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X st  for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,it) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
    proof-
      have " ex G be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X st  for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,G) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
      proof-
        show " ex G be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X st  for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,G) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
        proof-
          have " ex tVar18 be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X st  for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,tVar18) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
          proof-
            let ?G = "{meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }) where x be ElementSUBSET-1M1-of X :  True  }"
            have "?G c=TARSKIR1 boolSETFAM-1K9 X"
            proof-
              have "{meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }) where x be ElementSUBSET-1M1-of X :  True  } c=TARSKIR1 boolSETFAM-1K9 X"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 {meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }) where x be ElementSUBSET-1M1-of X :  True  } implies y inHIDDENR3 boolSETFAM-1K9 X"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  obtain yy where 
                    [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
                    using tarski_th_1 sorry
                  assume "y inHIDDENR3 ?G"
                  then obtain x where
                    [ty]:"x be ElementSUBSET-1M1-of X" and 
                    A4: "y =HIDDENR1 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                     sorry
                  have "yy c=TARSKIR1 X"
                  proof-
                    have " for e be objectHIDDENM1 holds e inHIDDENR3 yy implies e inHIDDENR3 X"
                    proof(rule ballI,rule impI)
                      fix e assume [ty]: "e be objectHIDDENM1"
                      obtain T where
                        [ty]:"T be objectHIDDENM1" and 
                        A5: "T inHIDDENR3 F"
                        using xboole_0_def_1 sorry
                      have 
                        [ty]:"T be a-partitionEQREL-1M3-of X"
                        using A5 eqrel_1_def_7 sorry
                      have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                        using A5 sorry
                      then obtain f where
                        [ty]:"f be setHIDDENM2" and 
                        A6: "f inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                         sorry
                      obtain S where
                        [ty]:"S be a-partitionEQREL-1M3-of X" and 
                        A7: "f =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S)"and "S inTARSKIR2 F"
                        using A6 sorry
                      assume "e inHIDDENR3 yy"
                      then have "e inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S)"
                        using A4 A6 A7 setfam_1_def_1 sorry
                      thus "e inHIDDENR3 X"
                         sorry
                    qed "sorry"
                    thus "yy c=TARSKIR1 X"
                      using tarski_def_3 sorry
                  qed
                  thus "y inHIDDENR3 boolSETFAM-1K9 X"
                     sorry
                qed "sorry"
                thus "{meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }) where x be ElementSUBSET-1M1-of X :  True  } c=TARSKIR1 boolSETFAM-1K9 X"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain G where 
              [ty]:"G be Subset-FamilySETFAM-1M1-of X" and GDef:"G = ?G"
               sorry
            have "G be a-partitionEQREL-1M3-of X"
            proof-
              have Cut1635: "X c=TARSKIR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> G"
              proof-
                have " for a be objectHIDDENM1 holds a inHIDDENR3 X implies a inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> G"
                proof(rule ballI,rule impI)
                  fix a assume [ty]: "a be objectHIDDENM1"
                  obtain T where
                    [ty]:"T be objectHIDDENM1" and 
                    A8: "T inHIDDENR3 F"
                    using xboole_0_def_1 sorry
                  assume "a inHIDDENR3 X"
                  then obtain a1 where 
                    [ty]:"a1 be ElementSUBSET-1M1-of X" and a1Def:"a1 = a"
                     sorry
                  have 
                    [ty]:"T be a-partitionEQREL-1M3-of X"
                    using A8 eqrel_1_def_7 sorry
                  have A9: "meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(a1,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }) inTARSKIR2 G"
                     sorry
                  have A10: " for T be setHIDDENM2 holds T inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(a1,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } implies a1 inTARSKIR2 T"
                  proof(rule ballI,rule impI)
                    fix T assume [ty]: "T be setHIDDENM2"
                    assume "T inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(a1,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                    then have " ex A be a-partitionEQREL-1M3-of X st T =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(a1,A) & A inTARSKIR2 F"
                       sorry
                    thus "a1 inTARSKIR2 T"
                      using eqrel_1_def_6 sorry
                  qed "sorry"
                  have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(a1,T) inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(a1,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                    using A8 sorry
                  then have "a inHIDDENR3 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(a1,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                    using A10 setfam_1_def_1 sorry
                  thus "a inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> G"
                    using A9 tarski_def_4 sorry
                qed "sorry"
                thus "X c=TARSKIR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> G"
                  using tarski_def_3 sorry
              qed
              have "unionSETFAM-1K5\<^bsub>(X)\<^esub> G =XBOOLE-0R4 X & ( for A be SubsetSUBSET-1M2-of X holds A inTARSKIR2 G implies A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 G implies A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B))"
              proof(rule conjMI,rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
                show "unionSETFAM-1K5\<^bsub>(X)\<^esub> G =XBOOLE-0R4 X"
                  using Cut1635 sorry
                fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
                obtain T where
                  [ty]:"T be objectHIDDENM1" and 
                  A11: "T inHIDDENR3 F"
                  using xboole_0_def_1 sorry
                have 
                  [ty]:"T be a-partitionEQREL-1M3-of X"
                  using A11 eqrel_1_def_7 sorry
                assume A12: "A inTARSKIR2 G"
                then obtain x where
                  [ty]:"x be ElementSUBSET-1M1-of X" and 
                  A13: "A =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                   sorry
                have A14: " for Y be setHIDDENM2 holds Y inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } implies x inTARSKIR2 Y"
                proof(rule ballI,rule impI)
                  fix Y assume [ty]: "Y be setHIDDENM2"
                  assume "Y inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                  then have " ex T be a-partitionEQREL-1M3-of X st Y =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) & T inTARSKIR2 F"
                     sorry
                  thus "x inTARSKIR2 Y"
                    using eqrel_1_def_6 sorry
                qed "sorry"
                have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                  using A11 sorry
                thus "A <>HIDDENR2 {}XBOOLE-0K1"
                  using A13 A14 setfam_1_def_1 sorry
                obtain x where
                  [ty]:"x be ElementSUBSET-1M1-of X" and 
                  A15: "A =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                  using A12 sorry
                fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
                assume "B inTARSKIR2 G"
                then obtain y where
                  [ty]:"y be ElementSUBSET-1M1-of X" and 
                  A16: "B =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                   sorry
                show "A =XBOOLE-0R4 B or A missesXBOOLE-0R1 B"
                proof-
                  have " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
                  proof-
                    have A17: "{EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be  non emptyXBOOLE-0V1"
                    proof-
                      have " not {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be emptyXBOOLE-0V1"
                      proof-
                        obtain T where
                          [ty]:"T be objectHIDDENM1" and 
                          A18: "T inHIDDENR3 F"
                          using xboole_0_def_1 sorry
                        have 
                          [ty]:"T be a-partitionEQREL-1M3-of X"
                          using A18 eqrel_1_def_7 sorry
                        have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T) inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                          using A18 sorry
                        thus " not {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be emptyXBOOLE-0V1"
                           sorry
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                    have A19: "{EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be  non emptyXBOOLE-0V1"
                    proof-
                      have " not {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be emptyXBOOLE-0V1"
                      proof-
                        obtain T where
                          [ty]:"T be objectHIDDENM1" and 
                          A20: "T inHIDDENR3 F"
                          using xboole_0_def_1 sorry
                        have 
                          [ty]:"T be a-partitionEQREL-1M3-of X"
                          using A20 eqrel_1_def_7 sorry
                        have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                          using A20 sorry
                        thus " not {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be emptyXBOOLE-0V1"
                           sorry
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                    have "A meetsXBOOLE-0R5 B implies  not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
                    proof(rule impI)
                      assume "A meetsXBOOLE-0R5 B"
                      then obtain c where
                        [ty]:"c be objectHIDDENM1" and 
                        A21: "c inHIDDENR3 A & c inHIDDENR3 B"
                        using xboole_0_th_3 sorry
                      have "c inHIDDENR3 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }) /\\XBOOLE-0K3 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                        using A15 A16 A21 xboole_0_def_4 sorry
                      then have A22: "c inHIDDENR3 meetSETFAM-1K1 (({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })\\/XBOOLE-0K2 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }))"
                        using A19 A17 setfam_1_th_9 sorry
                      have A23: " for T be a-partitionEQREL-1M3-of X holds T inTARSKIR2 F implies c inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                      proof(rule ballI,rule impI)
                        fix T assume [ty]: "T be a-partitionEQREL-1M3-of X"
                        assume "T inTARSKIR2 F"
                        then have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T) inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                           sorry
                        then have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T) inTARSKIR2 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })\\/XBOOLE-0K2 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                          using xboole_0_def_3 sorry
                        thus "c inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                          using A22 setfam_1_def_1 sorry
                      qed "sorry"
                      have A24: " for T be a-partitionEQREL-1M3-of X holds T inTARSKIR2 F implies c inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T)"
                      proof(rule ballI,rule impI)
                        fix T assume [ty]: "T be a-partitionEQREL-1M3-of X"
                        assume "T inTARSKIR2 F"
                        then have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                           sorry
                        then have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) inTARSKIR2 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })\\/XBOOLE-0K2 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                          using xboole_0_def_3 sorry
                        thus "c inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T)"
                          using A22 setfam_1_def_1 sorry
                      qed "sorry"
                      have A25: " for T be a-partitionEQREL-1M3-of X holds T inTARSKIR2 F implies ( ex A be objectHIDDENM1 st A inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) & A inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T))"
                      proof-
                        have " for T be a-partitionEQREL-1M3-of X holds T inTARSKIR2 F implies ( ex tVar17 be objectHIDDENM1 st tVar17 inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) & tVar17 inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T))"
                        proof(rule ballI,rule impI)
                          fix T assume [ty]: "T be a-partitionEQREL-1M3-of X"
                          assume A26: "T inTARSKIR2 F"
                          show " ex tVar17 be objectHIDDENM1 st tVar17 inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) & tVar17 inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                          proof(rule bexI[of _ "c"])
                            show "c inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) & c inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                              using A24 A23 A26 sorry
                          qed "sorry"
                        qed "sorry"
                        thus " ?thesis "
                           sorry
                      qed
                      have A27: " for T be a-partitionEQREL-1M3-of X holds T inTARSKIR2 F implies EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) meetsXBOOLE-0R5 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                      proof-
                        have " for T be a-partitionEQREL-1M3-of X holds T inTARSKIR2 F implies  not EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) meetsXBOOLE-0R5 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                        proof(rule ballI,rule impI)
                          fix T assume [ty]: "T be a-partitionEQREL-1M3-of X"
                          assume "T inTARSKIR2 F"
                          then have " ex A be objectHIDDENM1 st A inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) & A inHIDDENR3 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                            using A25 sorry
                          thus " not EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) meetsXBOOLE-0R5 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                            using xboole_0_th_3 sorry
                        qed "sorry"
                        thus " ?thesis "
                           sorry
                      qed
                      have A28: "{EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } c=TARSKIR1 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                      proof-
                        have " for A be objectHIDDENM1 holds A inHIDDENR3 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } implies A inHIDDENR3 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                        proof(rule ballI,rule impI)
                          fix A assume [ty]: "A be objectHIDDENM1"
                          assume "A inHIDDENR3 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                          then obtain T where
                            [ty]:"T be a-partitionEQREL-1M3-of X" and 
                            A29: "T inTARSKIR2 F"and A30: "A =HIDDENR1 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                            using eqrel_1_lm_3 sorry
                          have "A =HIDDENR1 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T)"
                            using A27 A29 A30 eqrel_1_th_41 sorry
                          thus "A inHIDDENR3 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                            using A29 sorry
                        qed "sorry"
                        thus "{EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } c=TARSKIR1 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                          using tarski_def_3 sorry
                      qed
                      have "{EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } c=TARSKIR1 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                      proof-
                        have " for A be objectHIDDENM1 holds A inHIDDENR3 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } implies A inHIDDENR3 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                        proof(rule ballI,rule impI)
                          fix A assume [ty]: "A be objectHIDDENM1"
                          assume "A inHIDDENR3 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                          then obtain T where
                            [ty]:"T be a-partitionEQREL-1M3-of X" and 
                            A31: "T inTARSKIR2 F"and A32: "A =HIDDENR1 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T)"
                            using eqrel_1_lm_3 sorry
                          have "A =HIDDENR1 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,T)"
                            using A27 A31 A32 eqrel_1_th_41 sorry
                          thus "A inHIDDENR3 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                            using A31 sorry
                        qed "sorry"
                        thus "{EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } c=TARSKIR1 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(y,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                          using tarski_def_3 sorry
                      qed
                      thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
                        using A15 A16 A28 xboole_0_def_10 sorry
                    qed
                    thus " not ( not A =XBOOLE-0R4 B &  not A missesXBOOLE-0R1 B)"
                       sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
              qed "sorry"
              thus "G be a-partitionEQREL-1M3-of X"
                using eqrel_1_def_4 sorry
            qed
            then have 
              [ty]:"G be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X"
               sorry
            show " ex tVar18 be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X st  for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,tVar18) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
            proof(rule bexI[of _ "G"])
              have " for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,G) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
              proof(rule ballI)
                fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
                have A33: " for Y be setHIDDENM2 holds Y inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } implies x inTARSKIR2 Y"
                proof(rule ballI,rule impI)
                  fix Y assume [ty]: "Y be setHIDDENM2"
                  assume "Y inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                  then have " ex T be a-partitionEQREL-1M3-of X st Y =XBOOLE-0R4 EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) & T inTARSKIR2 F"
                     sorry
                  thus "x inTARSKIR2 Y"
                    using eqrel_1_def_6 sorry
                qed "sorry"
                have "{EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be  non emptyXBOOLE-0V1"
                proof-
                  have " not {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be emptyXBOOLE-0V1"
                  proof-
                    obtain T where
                      [ty]:"T be objectHIDDENM1" and 
                      A34: "T inHIDDENR3 F"
                      using xboole_0_def_1 sorry
                    have 
                      [ty]:"T be a-partitionEQREL-1M3-of X"
                      using A34 eqrel_1_def_7 sorry
                    have "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,T) inTARSKIR2 {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }"
                      using A34 sorry
                    thus " not {EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F } be emptyXBOOLE-0V1"
                       sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                then have "meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F }) inTARSKIR2 G & x inTARSKIR2 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                  using A33 setfam_1_def_1 sorry
                thus "EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,G) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                  using eqrel_1_def_6 sorry
              qed "sorry"
              thus " for x be ElementSUBSET-1M1-of X holds EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,G) =XBOOLE-0R4 meetSETFAM-1K1 ({EqClassEQREL-1K14\<^bsub>(X)\<^esub>(x,S) where S be a-partitionEQREL-1M3-of X : S inTARSKIR2 F })"
                 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem eqrel_1_th_43:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be a-partitionEQREL-1M3-of X holds  for A be SubsetSUBSET-1M2-of S holds unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A =XBOOLE-0R4 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A)"
proof(rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix S assume [ty]: "S be a-partitionEQREL-1M3-of X"
  fix A assume [ty]: "A be SubsetSUBSET-1M2-of S"
  have "unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A c=TARSKIR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A) & unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A) c=TARSKIR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A"
  proof(rule conjMI)
    show "unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A c=TARSKIR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A implies y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A1: "y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A"
        then have "y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> S"
          using xboole_0_def_5 sorry
        then obtain z where
          [ty]:"z be setHIDDENM2" and 
          A2: "y inHIDDENR3 z"and A3: "z inTARSKIR2 S"
          using tarski_def_4 sorry
        have " not y inHIDDENR3 unionTARSKIK3 A"
          using A1 xboole_0_def_5 sorry
        then have " not z inTARSKIR2 A"
          using A2 tarski_def_4 sorry
        then have "z inTARSKIR2 S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A"
          using A3 xboole_0_def_5 sorry
        thus "y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A)"
          using A2 tarski_def_4 sorry
      qed "sorry"
      thus "unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A c=TARSKIR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A)"
        using tarski_def_3 sorry
    qed
    show "unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A) c=TARSKIR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A) implies y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A)"
        then obtain z where
          [ty]:"z be setHIDDENM2" and 
          A4: "y inHIDDENR3 z"and A5: "z inTARSKIR2 S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A"
          using tarski_def_4 sorry
        have A6: "z inTARSKIR2 S"
          using A5 xboole_0_def_5 sorry
        have A7: " not z inTARSKIR2 A"
          using A5 xboole_0_def_5 sorry
        have A8: " for w be setHIDDENM2 holds w inTARSKIR2 A implies  not y inHIDDENR3 w"
        proof(rule ballI,rule impI)
          fix w assume [ty]: "w be setHIDDENM2"
          assume A9: "w inTARSKIR2 A"
          then have "w inTARSKIR2 S"
             sorry
          then have "z missesXBOOLE-0R1 w"
            using A6 A7 A9 eqrel_1_def_4 sorry
          thus " not y inHIDDENR3 w"
            using A4 xboole_0_th_3 sorry
        qed "sorry"
        have A10: "y inHIDDENR3 unionTARSKIK3 A implies  False "
        proof(rule impI)
          assume "y inHIDDENR3 unionTARSKIK3 A"
          then have " ex v be setHIDDENM2 st y inHIDDENR3 v & v inTARSKIR2 A"
            using tarski_def_4 sorry
          thus " False "
            using A8 sorry
        qed
        have "y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> S"
          using A4 A6 tarski_def_4 sorry
        thus "y inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A"
          using A10 xboole_0_def_5 sorry
      qed "sorry"
      thus "unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A) c=TARSKIR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A"
        using tarski_def_3 sorry
    qed
  qed
  thus "unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 A =XBOOLE-0R4 unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> A)"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem eqrel_1_th_44:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for S be a-partitionEQREL-1M3-of X holds A inTARSKIR2 S implies unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> A}) =XBOOLE-0R4 X \\SUBSET-1K6 A"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds  for S be a-partitionEQREL-1M3-of X holds A inTARSKIR2 S implies unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> A}) =HIDDENR1 X \\SUBSET-1K6 A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
    fix S assume [ty]: "S be a-partitionEQREL-1M3-of X"
    assume A1: "A inTARSKIR2 S"
    have "{DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> A} c=TARSKIR1 S"
      using A1 tarski_def_1 sorry
    then obtain AA where 
      [ty]:"AA be SubsetSUBSET-1M2-of S" and AADef:"AA = {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> A}"
       sorry
    have "unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> A}) =HIDDENR1 unionSETFAM-1K5\<^bsub>(X)\<^esub> S \\SUBSET-1K7\<^bsub>(X)\<^esub> unionTARSKIK3 AA"
      using eqrel_1_th_43 sorry
    also have "... = X \\SUBSET-1K6 unionSETFAM-1K5\<^bsub>(X)\<^esub> {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> A}"
      using eqrel_1_def_4 sorry
    also have "... = X \\SUBSET-1K6 A"
       sorry
    finally show "unionSETFAM-1K5\<^bsub>(X)\<^esub> (S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 X)\<^esub> {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 X)\<^esub> A}) =HIDDENR1 X \\SUBSET-1K6 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_45:
"{}XBOOLE-0K1 be a-partitionEQREL-1M3-of {}XBOOLE-0K1"
proof-
  obtain A where 
    [ty]:"A be Subset-FamilySETFAM-1M1-of {}XBOOLE-0K1" and ADef:"A = {}XBOOLE-0K1"
    using xboole_1_th_2 sorry
  have "unionSETFAM-1K5\<^bsub>({}XBOOLE-0K1)\<^esub> A =FUNCT-1R1 {}XBOOLE-0K1 & ( for a be SubsetSUBSET-1M2-of {}XBOOLE-0K1 holds a inTARSKIR2 A implies a <>HIDDENR2 {}XBOOLE-0K1 & ( for b be SubsetSUBSET-1M2-of {}XBOOLE-0K1 holds b inTARSKIR2 A implies a =FUNCT-1R1 b or a missesXBOOLE-0R1 b))"
     sorry
  thus "{}XBOOLE-0K1 be a-partitionEQREL-1M3-of {}XBOOLE-0K1"
    using eqrel_1_def_4 sorry
qed

(*begin*)
reserve e, u, v for "objectHIDDENM1"
reserve E, X, Y, X1 for "setHIDDENM2"
mtheorem eqrel_1_th_46:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds X c=TARSKIR1 F \<inverse>FUNCT-1K6 X1 implies F .:FUNCT-1K5 X c=TARSKIR1 X1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds X c=TARSKIR1 F \<inverse>FUNCT-1K6 X1 implies F .:FUNCT-1K5 X c=TARSKIR1 X1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    assume "X c=TARSKIR1 F \<inverse>FUNCT-1K6 X1"
    then have A1: "F .:FUNCT-1K5 X c=TARSKIR1 F .:FUNCT-1K5 F \<inverse>FUNCT-1K6 X1"
      using relat_1_th_123 sorry
    have "F .:FUNCT-1K5 F \<inverse>FUNCT-1K6 X1 c=TARSKIR1 X1"
      using funct_1_th_75 sorry
    thus "F .:FUNCT-1K5 X c=TARSKIR1 X1"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_47:
" for E be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds E c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 E =XBOOLE-0R4 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> E"
proof-
  have " for E be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds E c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 E =XBOOLE-0R4 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> E"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "E c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    then have "E c=TARSKIR1 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (pr1FUNCT-3K10(X,Y))"
      using funct_3_def_4 sorry
    thus "(.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 E =XBOOLE-0R4 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> E"
      using funct_3_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_48:
" for E be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds E c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 E =XBOOLE-0R4 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> E"
proof-
  have " for E be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds E c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 E =XBOOLE-0R4 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> E"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "E c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    then have "E c=TARSKIR1 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (pr2FUNCT-3K11(X,Y))"
      using funct_3_def_5 sorry
    thus "(.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 E =XBOOLE-0R4 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> E"
      using funct_3_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_49:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for X1 be SubsetSUBSET-1M2-of X holds  for Y1 be SubsetSUBSET-1M2-of Y holds [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :] <>HIDDENR2 {}XBOOLE-0K1 implies pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =XBOOLE-0R4 X1 & pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =XBOOLE-0R4 Y1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for X1 be SubsetSUBSET-1M2-of X holds  for Y1 be SubsetSUBSET-1M2-of Y holds [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :] <>HIDDENR2 {}XBOOLE-0K1 implies pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =XBOOLE-0R4 X1 & pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =XBOOLE-0R4 Y1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix X1 assume [ty]: "X1 be SubsetSUBSET-1M2-of X"
    fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of Y"
    assume A1: "[:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :] <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "X1 <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have A3: "Y1 <>HIDDENR2 {}XBOOLE-0K1"
      using A1 sorry
    have A4: "X <>HIDDENR2 {}XBOOLE-0K1"
      using A2 sorry
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) implies x inHIDDENR3 X1) & (x inHIDDENR3 X1 implies x inHIDDENR3 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]))"
    proof(rule ballI,rule conjMI,rule impI)
      let ?y = "the ElementSUBSET-1M1-of Y1"
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) implies x inHIDDENR3 X1"
      proof(rule impI)
        assume "x inHIDDENR3 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])"
        then obtain u where
          [ty]:"u be objectHIDDENM1" and 
          A5: "u inHIDDENR3 [:ZFMISC-1K2 X,Y :]"and A6: "u inHIDDENR3 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :] & x =HIDDENR1 pr1FUNCT-3K10(X,Y) .FUNCT-1K1 u"
          using funct_2_th_64 sorry
        have A7: "u `2XTUPLE-0K2 inHIDDENR3 Y"
          using A5 mcart_1_th_10 sorry
        have "u `1XTUPLE-0K1 inHIDDENR3 X1 & x =HIDDENR1 pr1FUNCT-3K10(X,Y) .BINOP-1K1(u `1XTUPLE-0K1,u `2XTUPLE-0K2)"
          using A6 mcart_1_th_10 mcart_1_th_21 sorry
        thus "x inHIDDENR3 X1"
          using A7 funct_3_def_4 sorry
      qed
      assume A8: "x inHIDDENR3 X1"
      have "?y inTARSKIR2 Y"
        using A3 tarski_def_3 sorry
      then have A9: "x =HIDDENR1 pr1FUNCT-3K10(X,Y) .BINOP-1K1(x,?y)"
        using A8 funct_3_def_4 sorry
      have "[TARSKIK4 x,?y ] inHIDDENR3 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]"
        using A3 A8 zfmisc_1_th_87 sorry
      thus "x inHIDDENR3 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])"
        using A4 A9 funct_2_th_35 sorry
    qed "sorry"
    thus "pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =XBOOLE-0R4 X1"
      using tarski_th_2 sorry
    have A10: "Y <>HIDDENR2 {}XBOOLE-0K1"
      using A3 sorry
    have " for y be objectHIDDENM1 holds (y inHIDDENR3 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) implies y inHIDDENR3 Y1) & (y inHIDDENR3 Y1 implies y inHIDDENR3 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]))"
    proof(rule ballI,rule conjMI,rule impI)
      let ?x = "the ElementSUBSET-1M1-of X1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "y inHIDDENR3 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) implies y inHIDDENR3 Y1"
      proof(rule impI)
        assume "y inHIDDENR3 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])"
        then obtain u where
          [ty]:"u be objectHIDDENM1" and 
          A11: "u inHIDDENR3 [:ZFMISC-1K2 X,Y :]"and A12: "u inHIDDENR3 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :] & y =HIDDENR1 pr2FUNCT-3K11(X,Y) .FUNCT-1K1 u"
          using funct_2_th_64 sorry
        have A13: "u `1XTUPLE-0K1 inHIDDENR3 X"
          using A11 mcart_1_th_10 sorry
        have "u `2XTUPLE-0K2 inHIDDENR3 Y1 & y =HIDDENR1 pr2FUNCT-3K11(X,Y) .BINOP-1K1(u `1XTUPLE-0K1,u `2XTUPLE-0K2)"
          using A12 mcart_1_th_10 mcart_1_th_21 sorry
        thus "y inHIDDENR3 Y1"
          using A13 funct_3_def_5 sorry
      qed
      assume A14: "y inHIDDENR3 Y1"
      have "?x inTARSKIR2 X"
        using A2 tarski_def_3 sorry
      then have A15: "y =HIDDENR1 pr2FUNCT-3K11(X,Y) .BINOP-1K1(?x,y)"
        using A14 funct_3_def_5 sorry
      have "[TARSKIK4 ?x,y ] inHIDDENR3 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]"
        using A2 A14 zfmisc_1_th_87 sorry
      thus "y inHIDDENR3 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])"
        using A10 A15 funct_2_th_35 sorry
    qed "sorry"
    thus "pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =XBOOLE-0R4 Y1"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_50:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for X1 be SubsetSUBSET-1M2-of X holds  for Y1 be SubsetSUBSET-1M2-of Y holds [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :] <>HIDDENR2 {}XBOOLE-0K1 implies (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =XBOOLE-0R4 X1 & (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =XBOOLE-0R4 Y1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for X1 be SubsetSUBSET-1M2-of X holds  for Y1 be SubsetSUBSET-1M2-of Y holds [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :] <>HIDDENR2 {}XBOOLE-0K1 implies (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =HIDDENR1 X1 & (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =HIDDENR1 Y1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix X1 assume [ty]: "X1 be SubsetSUBSET-1M2-of X"
    fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of Y"
    assume A1: "[:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :] <>HIDDENR2 {}XBOOLE-0K1"
    have "(.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =HIDDENR1 pr1FUNCT-3K10(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],X)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])"
      using eqrel_1_th_47 sorry
    also have "... = X1"
      using A1 eqrel_1_th_49 sorry
    finally show "(.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =HIDDENR1 X1"
       sorry
    have "(.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =HIDDENR1 pr2FUNCT-3K11(X,Y) .:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Y :],Y)\<^esub> ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])"
      using eqrel_1_th_48 sorry
    also have "... = Y1"
      using A1 eqrel_1_th_49 sorry
    finally show "(.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 ([:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]) =HIDDENR1 Y1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_51:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :] holds  for H be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,Y :] holds ( for E be setHIDDENM2 holds E inTARSKIR2 H implies E c=TARSKIR1 A & ( ex X1 be SubsetSUBSET-1M2-of X st  ex Y1 be SubsetSUBSET-1M2-of Y st E =XBOOLE-0R4 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])) implies [:ZFMISC-1K2 unionTARSKIK3 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),meetSETFAM-1K1 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :] c=RELAT-1R2 A"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :] holds  for H be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,Y :] holds ( for E be setHIDDENM2 holds E inTARSKIR2 H implies E c=TARSKIR1 A & ( ex X1 be SubsetSUBSET-1M2-of X st  ex Y1 be SubsetSUBSET-1M2-of Y st E =XBOOLE-0R4 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])) implies [:ZFMISC-1K2 unionTARSKIK3 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),meetSETFAM-1K1 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :] c=RELAT-1R2 A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :]"
    fix H assume [ty]: "H be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,Y :]"
    assume A1: " for E be setHIDDENM2 holds E inTARSKIR2 H implies E c=TARSKIR1 A & ( ex X1 be SubsetSUBSET-1M2-of X st  ex Y1 be SubsetSUBSET-1M2-of Y st E =XBOOLE-0R4 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])"
    have " for u be objectHIDDENM1 holds  for v be objectHIDDENM1 holds [TARSKIK4 u,v ] inHIDDENR3 [:ZFMISC-1K2 unionTARSKIK3 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),meetSETFAM-1K1 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :] implies [TARSKIK4 u,v ] inHIDDENR3 A"
    proof(rule ballI,rule ballI,rule impI)
      fix u assume [ty]: "u be objectHIDDENM1"
      fix v assume [ty]: "v be objectHIDDENM1"
      assume A2: "[TARSKIK4 u,v ] inHIDDENR3 [:ZFMISC-1K2 unionTARSKIK3 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),meetSETFAM-1K1 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :]"
      then have A3: "v inHIDDENR3 meetSETFAM-1K1 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H)"
        using zfmisc_1_th_87 sorry
      have "u inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H)"
        using A2 zfmisc_1_th_87 sorry
      then obtain x where
        [ty]:"x be setHIDDENM2" and 
        A4: "u inHIDDENR3 x"and A5: "x inTARSKIR2 (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H"
        using tarski_def_4 sorry
      obtain y where
        [ty]:"y be objectHIDDENM1" and 
        "y inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y))"and A6: "y inHIDDENR3 H"and A7: "x =XBOOLE-0R4 (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 y"
        using A5 funct_1_def_6 sorry
      have 
        [ty]:"y be setHIDDENM2"
        using tarski_th_1 sorry
      obtain X1 Y1 where
        [ty]:"X1 be SubsetSUBSET-1M2-of X" "Y1 be SubsetSUBSET-1M2-of Y" and 
        A8: "y =XBOOLE-0R4 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]"
        using A1 A6 sorry
      have A9: "y <>HIDDENR2 {}XBOOLE-0K1"
        using A4 A7 funct_3_th_8 sorry
      have "y inTARSKIR2 boolSETFAM-1K9 ([:ZFMISC-1K2 X,Y :])"
        using A6 sorry
      then have "y inTARSKIR2 boolSETFAM-1K9 (domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (pr2FUNCT-3K11(X,Y)))"
        using funct_3_def_5 sorry
      then have "y inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y))"
        using funct_3_def_1 sorry
      then have "(.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 y inTARSKIR2 (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H"
        using A6 funct_1_def_6 sorry
      then have "Y1 inTARSKIR2 (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H"
        using A8 A9 eqrel_1_th_50 sorry
      then have A10: "v inHIDDENR3 Y1"
        using A3 setfam_1_def_1 sorry
      have "u inHIDDENR3 X1"
        using A4 A7 A8 A9 eqrel_1_th_50 sorry
      then have A11: "[TARSKIK4 u,v ] inHIDDENR3 y"
        using A8 A10 zfmisc_1_th_87 sorry
      have "y c=TARSKIR1 A"
        using A1 A6 sorry
      thus "[TARSKIK4 u,v ] inHIDDENR3 A"
        using A11 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 unionTARSKIK3 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),meetSETFAM-1K1 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :] c=RELAT-1R2 A"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_52:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :] holds  for H be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,Y :] holds ( for E be setHIDDENM2 holds E inTARSKIR2 H implies E c=TARSKIR1 A & ( ex X1 be SubsetSUBSET-1M2-of X st  ex Y1 be SubsetSUBSET-1M2-of Y st E =XBOOLE-0R4 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])) implies [:ZFMISC-1K2 meetSETFAM-1K1 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),unionTARSKIK3 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :] c=RELAT-1R2 A"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :] holds  for H be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,Y :] holds ( for E be setHIDDENM2 holds E inTARSKIR2 H implies E c=TARSKIR1 A & ( ex X1 be SubsetSUBSET-1M2-of X st  ex Y1 be SubsetSUBSET-1M2-of Y st E =XBOOLE-0R4 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])) implies [:ZFMISC-1K2 meetSETFAM-1K1 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),unionTARSKIK3 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :] c=RELAT-1R2 A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :]"
    fix H assume [ty]: "H be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 X,Y :]"
    assume A1: " for E be setHIDDENM2 holds E inTARSKIR2 H implies E c=TARSKIR1 A & ( ex X1 be SubsetSUBSET-1M2-of X st  ex Y1 be SubsetSUBSET-1M2-of Y st E =XBOOLE-0R4 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :])"
    have " for u be objectHIDDENM1 holds  for v be objectHIDDENM1 holds [TARSKIK4 u,v ] inHIDDENR3 [:ZFMISC-1K2 meetSETFAM-1K1 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),unionTARSKIK3 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :] implies [TARSKIK4 u,v ] inHIDDENR3 A"
    proof(rule ballI,rule ballI,rule impI)
      fix u assume [ty]: "u be objectHIDDENM1"
      fix v assume [ty]: "v be objectHIDDENM1"
      assume A2: "[TARSKIK4 u,v ] inHIDDENR3 [:ZFMISC-1K2 meetSETFAM-1K1 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),unionTARSKIK3 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :]"
      then have A3: "u inHIDDENR3 meetSETFAM-1K1 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H)"
        using zfmisc_1_th_87 sorry
      have "v inHIDDENR3 unionTARSKIK3 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H)"
        using A2 zfmisc_1_th_87 sorry
      then obtain x where
        [ty]:"x be setHIDDENM2" and 
        A4: "v inHIDDENR3 x"and A5: "x inTARSKIR2 (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H"
        using tarski_def_4 sorry
      obtain y where
        [ty]:"y be objectHIDDENM1" and 
        "y inHIDDENR3 domRELAT-1K1 (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y))"and A6: "y inHIDDENR3 H"and A7: "x =XBOOLE-0R4 (.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).FUNCT-1K1 y"
        using A5 funct_1_def_6 sorry
      have 
        [ty]:"y be setHIDDENM2"
        using tarski_th_1 sorry
      obtain X1 Y1 where
        [ty]:"X1 be SubsetSUBSET-1M2-of X" "Y1 be SubsetSUBSET-1M2-of Y" and 
        A8: "y =XBOOLE-0R4 [:MCART-1K8\<^bsub>(X,Y)\<^esub> X1,Y1 :]"
        using A1 A6 sorry
      have A9: "y <>HIDDENR2 {}XBOOLE-0K1"
        using A4 A7 funct_3_th_8 sorry
      have "y inTARSKIR2 boolSETFAM-1K9 ([:ZFMISC-1K2 X,Y :])"
        using A6 sorry
      then have "y inTARSKIR2 boolSETFAM-1K9 (domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> (pr1FUNCT-3K10(X,Y)))"
        using funct_3_def_4 sorry
      then have "y inTARSKIR2 domRELAT-1K1 (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y))"
        using funct_3_def_1 sorry
      then have "(.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).FUNCT-1K1 y inTARSKIR2 (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H"
        using A6 funct_1_def_6 sorry
      then have "X1 inTARSKIR2 (.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H"
        using A8 A9 eqrel_1_th_50 sorry
      then have A10: "u inHIDDENR3 X1"
        using A3 setfam_1_def_1 sorry
      have "v inHIDDENR3 Y1"
        using A4 A7 A8 A9 eqrel_1_th_50 sorry
      then have A11: "[TARSKIK4 u,v ] inHIDDENR3 y"
        using A8 A10 zfmisc_1_th_87 sorry
      have "y c=TARSKIR1 A"
        using A1 A6 sorry
      thus "[TARSKIK4 u,v ] inHIDDENR3 A"
        using A11 sorry
    qed "sorry"
    thus "[:ZFMISC-1K2 meetSETFAM-1K1 ((.:FUNCT-3K1 pr1FUNCT-3K10(X,Y)).:FUNCT-1K5 H),unionTARSKIK3 ((.:FUNCT-3K1 pr2FUNCT-3K11(X,Y)).:FUNCT-1K5 H) :] c=RELAT-1R2 A"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_53:
" for X be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for H be Subset-FamilySETFAM-1M1-of X holds unionSETFAM-1K5\<^bsub>(Y)\<^esub> ((.:FUNCT-3K2\<^bsub>(X,Y)\<^esub> f).:RELSET-1K7\<^bsub>(boolZFMISC-1K1 X,boolZFMISC-1K1 Y)\<^esub> H) =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> unionSETFAM-1K5\<^bsub>(X)\<^esub> H"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
  fix H assume [ty]: "H be Subset-FamilySETFAM-1M1-of X"
  have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
    using funct_2_def_1 sorry
  thus "unionSETFAM-1K5\<^bsub>(Y)\<^esub> ((.:FUNCT-3K2\<^bsub>(X,Y)\<^esub> f).:RELSET-1K7\<^bsub>(boolZFMISC-1K1 X,boolZFMISC-1K1 Y)\<^esub> H) =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> unionSETFAM-1K5\<^bsub>(X)\<^esub> H"
    using funct_3_th_14 sorry
qed "sorry"

reserve X, Y, Z for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem eqrel_1_th_54:
" for X be setHIDDENM2 holds  for a be Subset-FamilySETFAM-1M1-of X holds unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a) =XBOOLE-0R4 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a })"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix a assume [ty]: "a be Subset-FamilySETFAM-1M1-of X"
  have "unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a) c=TARSKIR1 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a }) & unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a }) c=TARSKIR1 unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a)"
  proof(rule conjMI)
    show "unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a) c=TARSKIR1 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a })"
    proof-
      have " for e be objectHIDDENM1 holds e inHIDDENR3 unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a) implies e inHIDDENR3 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a })"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a)"
        then obtain B where
          [ty]:"B be setHIDDENM2" and 
          A1: "e inHIDDENR3 B"and A2: "B inTARSKIR2 unionSETFAM-1K5\<^bsub>(X)\<^esub> a"
          using tarski_def_4 sorry
        obtain C where
          [ty]:"C be setHIDDENM2" and 
          A3: "B inTARSKIR2 C"and A4: "C inTARSKIR2 a"
          using A2 tarski_def_4 sorry
        have A5: "unionTARSKIK3 C inTARSKIR2 {unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a }"
          using A4 sorry
        have "e inHIDDENR3 unionTARSKIK3 C"
          using A1 A3 tarski_def_4 sorry
        thus "e inHIDDENR3 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a })"
          using A5 tarski_def_4 sorry
      qed "sorry"
      thus "unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a) c=TARSKIR1 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a })"
        using tarski_def_3 sorry
    qed
    have " for e be objectHIDDENM1 holds e inHIDDENR3 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a }) implies e inHIDDENR3 unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a)"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume "e inHIDDENR3 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a })"
      then obtain c where
        [ty]:"c be setHIDDENM2" and 
        A6: "e inHIDDENR3 c"and A7: "c inTARSKIR2 {unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a }"
        using tarski_def_4 sorry
      obtain A where
        [ty]:"A be SubsetSUBSET-1M2-of X" and 
        A8: "c =XBOOLE-0R4 unionTARSKIK3 A"and A9: "A inTARSKIR2 a"
        using A7 sorry
      obtain b where
        [ty]:"b be setHIDDENM2" and 
        A10: "e inHIDDENR3 b"and A11: "b inTARSKIR2 A"
        using A6 A8 tarski_def_4 sorry
      have "b inTARSKIR2 unionSETFAM-1K5\<^bsub>(X)\<^esub> a"
        using A9 A11 tarski_def_4 sorry
      thus "e inHIDDENR3 unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a)"
        using A10 tarski_def_4 sorry
    qed "sorry"
    thus "unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a }) c=TARSKIR1 unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a)"
      using tarski_def_3 sorry
  qed
  thus "unionTARSKIK3 (unionSETFAM-1K5\<^bsub>(X)\<^esub> a) =XBOOLE-0R4 unionTARSKIK3 ({unionTARSKIK3 A where A be SubsetSUBSET-1M2-of X : A inTARSKIR2 a })"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem eqrel_1_th_55:
" for X be setHIDDENM2 holds  for D be Subset-FamilySETFAM-1M1-of X holds unionSETFAM-1K5\<^bsub>(X)\<^esub> D =XBOOLE-0R4 X implies ( for A be SubsetSUBSET-1M2-of D holds  for B be SubsetSUBSET-1M2-of X holds B =XBOOLE-0R4 unionTARSKIK3 A implies B `SUBSET-1K3\<^bsub>(X)\<^esub> c=TARSKIR1 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>)"
proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix D assume [ty]: "D be Subset-FamilySETFAM-1M1-of X"
  assume A1: "unionSETFAM-1K5\<^bsub>(X)\<^esub> D =XBOOLE-0R4 X"
  fix A assume [ty]: "A be SubsetSUBSET-1M2-of D"
  fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
  assume A2: "B =XBOOLE-0R4 unionTARSKIK3 A"
  have " for e be objectHIDDENM1 holds e inHIDDENR3 B `SUBSET-1K3\<^bsub>(X)\<^esub> implies e inHIDDENR3 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    assume A3: "e inHIDDENR3 B `SUBSET-1K3\<^bsub>(X)\<^esub>"
    then obtain u where
      [ty]:"u be setHIDDENM2" and 
      A4: "e inHIDDENR3 u"and A5: "u inTARSKIR2 D"
      using A1 tarski_def_4 sorry
    have " not e inHIDDENR3 B"
      using A3 xboole_0_def_5 sorry
    then have " not u inTARSKIR2 A"
      using A2 A4 tarski_def_4 sorry
    then have "u inTARSKIR2 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
      using A5 subset_1_th_29 sorry
    thus "e inHIDDENR3 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
      using A4 tarski_def_4 sorry
  qed "sorry"
  thus "B `SUBSET-1K3\<^bsub>(X)\<^esub> c=TARSKIR1 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
    using tarski_def_3 sorry
qed "sorry"

mtheorem eqrel_1_th_56:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(X,Z) holds ( for x be ElementSUBSET-1M1-of X holds  for x9 be ElementSUBSET-1M1-of X holds F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9 implies G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x9) implies ( ex H be FunctionFUNCT-2M1-of(Y,Z) st H *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F =FUNCT-2R2\<^bsub>(X,Z)\<^esub> G)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(X,Z) holds ( for x be ElementSUBSET-1M1-of X holds  for x9 be ElementSUBSET-1M1-of X holds F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9 implies G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x9) implies ( ex tVar21 be FunctionFUNCT-2M1-of(Y,Z) st tVar21 *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F =FUNCT-2R2\<^bsub>(X,Z)\<^esub> G)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    fix G assume [ty]: "G be FunctionFUNCT-2M1-of(X,Z)"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  not ( ex x be ElementSUBSET-1M1-of X st Lamb1 =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) or ( for x be ElementSUBSET-1M1-of X holds Lamb1 =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x implies Lamb2 =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x)"
    assume A1: " for x be ElementSUBSET-1M1-of X holds  for x9 be ElementSUBSET-1M1-of X holds F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9 implies G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x9"
    have A2: " for e be objectHIDDENM1 holds e inHIDDENR3 Y implies ( ex u be objectHIDDENM1 st u inHIDDENR3 Z & ( not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) or ( for x be ElementSUBSET-1M1-of X holds e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x implies u =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x)))"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume "e inHIDDENR3 Y"
      have "( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) & ( ex u be ElementSUBSET-1M1-of Z st u inTARSKIR2 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x))) or  not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) & ( not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex u be objectHIDDENM1 st u inHIDDENR3 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x))))"
      proof-
        show "( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) & ( ex u be ElementSUBSET-1M1-of Z st u inTARSKIR2 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x))) or  not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) & ( not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex u be objectHIDDENM1 st u inHIDDENR3 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x))))"
        proof-
          have cases: "( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) or  not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
             sorry
          have case1: "( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex u be ElementSUBSET-1M1-of Z st u inTARSKIR2 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x)))"
          proof(rule impI)
            assume " ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
            then obtain x where
              [ty]:"x be ElementSUBSET-1M1-of X" and 
              A3: "e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
               sorry
            obtain u where 
              [ty]:"u be ElementSUBSET-1M1-of Z" and uDef:"u = G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x"
               sorry
            show " ex u be ElementSUBSET-1M1-of Z st u inTARSKIR2 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x))"
            proof(rule bexI[of _ "u"])
              show "u inTARSKIR2 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x))"
                using A3 sorry
            qed "sorry"
          qed
          have case2: " not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex u be objectHIDDENM1 st u inHIDDENR3 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x)))"
          proof(rule impI)
            assume A4: " not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
            let ?u = "the ElementSUBSET-1M1-of Z"
            have "?u inTARSKIR2 Z"
               sorry
            thus " ex u be objectHIDDENM1 st u inHIDDENR3 Z & (( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x))"
              using A4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      then obtain u where
        [ty]:"u be objectHIDDENM1" and 
        A5: "u inHIDDENR3 Z"and A6: "( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) implies ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x & u =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x)"
         sorry
      have 
        [ty]:"u be objectHIDDENM1"
         sorry
      show " ex u be objectHIDDENM1 st u inHIDDENR3 Z & ( not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) or ( for x be ElementSUBSET-1M1-of X holds e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x implies u =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x))"
      proof(rule bexI[of _ "u"],rule conjMI)
        show "u inHIDDENR3 Z"
          using A5 sorry
        show " not ( ex x be ElementSUBSET-1M1-of X st e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) or ( for x be ElementSUBSET-1M1-of X holds e =HIDDENR1 F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x implies u =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x)"
          using A1 A6 sorry
      qed "sorry"
    qed "sorry"
    obtain H where
      [ty]:"H be FunctionFUNCT-2M1-of(Y,Z)" and 
      A7: " for e be objectHIDDENM1 holds e inHIDDENR3 Y implies ?P(e,H .FUNCT-1K1 e)"
      using funct_2_sch_1 A2 sorry
    show " ex tVar21 be FunctionFUNCT-2M1-of(Y,Z) st tVar21 *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F =FUNCT-2R2\<^bsub>(X,Z)\<^esub> G"
    proof(rule bexI[of _ "H"])
      have " for x be ElementSUBSET-1M1-of X holds (H *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F).FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
        have "(H *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F).FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =HIDDENR1 H .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
          using funct_2_th_15 sorry
        also have "... = G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x"
          using A7 sorry
        finally show "(H *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F).FUNCT-2K3\<^bsub>(X,Z)\<^esub> x =HIDDENR1 G .FUNCT-2K3\<^bsub>(X,Z)\<^esub> x"
           sorry
      qed "sorry"
      thus "H *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F =FUNCT-2R2\<^bsub>(X,Z)\<^esub> G"
        using funct_2_th_63 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_57:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for y be ElementSUBSET-1M1-of Y holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(Y,Z) holds F \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y} c=TARSKIR1 (G *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(X,Z)\<^esub> {DOMAIN-1K6\<^bsub>(Z)\<^esub> G .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> y }"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
  fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
  fix G assume [ty]: "G be FunctionFUNCT-2M1-of(Y,Z)"
  have "F \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y} c=TARSKIR1 (G *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(X,Z)\<^esub> (ImRELAT-1K12(G,y))"
    using funct_2_th_44 sorry
  thus "F \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y} c=TARSKIR1 (G *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(X,Z)\<^esub> {DOMAIN-1K6\<^bsub>(Z)\<^esub> G .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> y }"
    using setwiseo_th_8 sorry
qed "sorry"

mtheorem eqrel_1_th_58:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds  for z be ElementSUBSET-1M1-of Z holds ([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :]).BINOP-1K2\<^bsub>(X,Z,[:ZFMISC-1K2 Y,Z :])\<^esub>(x,z) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,z ]"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds  for z be ElementSUBSET-1M1-of Z holds ([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :]).BINOP-1K2\<^bsub>(X,Z,[:ZFMISC-1K2 Y,Z :])\<^esub>(x,z) =HIDDENR1 [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,z ]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of Z"
    have "([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :]).BINOP-1K2\<^bsub>(X,Z,[:ZFMISC-1K2 Y,Z :])\<^esub>(x,z) =HIDDENR1 [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,idPARTFUN1K6 Z .FUNCT-2K3\<^bsub>(Z,Z)\<^esub> z ]"
      using funct_3_th_75 sorry
    also have "... = [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,z ]"
       sorry
    finally show "([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :]).BINOP-1K2\<^bsub>(X,Z,[:ZFMISC-1K2 Y,Z :])\<^esub>(x,z) =HIDDENR1 [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,z ]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_59:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of Z holds ([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :]).:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> ([:MCART-1K8\<^bsub>(X,Z)\<^esub> A,B :]) =RELSET-1R2\<^bsub>(Y,Z)\<^esub> [:MCART-1K8\<^bsub>(Y,Z)\<^esub> F .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A,B :]"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for A be SubsetSUBSET-1M2-of X holds  for B be SubsetSUBSET-1M2-of Z holds ([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :]).:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> ([:MCART-1K8\<^bsub>(X,Z)\<^esub> A,B :]) =HIDDENR1 [:MCART-1K8\<^bsub>(Y,Z)\<^esub> F .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A,B :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of Z"
    have "([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :]).:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> ([:MCART-1K8\<^bsub>(X,Z)\<^esub> A,B :]) =HIDDENR1 [:MCART-1K8\<^bsub>(Y,Z)\<^esub> F .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A,idPARTFUN1K6 Z .:RELSET-1K7\<^bsub>(Z,Z)\<^esub> B :]"
      using funct_3_th_72 sorry
    also have "... = [:MCART-1K8\<^bsub>(Y,Z)\<^esub> F .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A,B :]"
      using funct_1_th_92 sorry
    finally show "([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :]).:RELSET-1K7\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> ([:MCART-1K8\<^bsub>(X,Z)\<^esub> A,B :]) =HIDDENR1 [:MCART-1K8\<^bsub>(Y,Z)\<^esub> F .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A,B :]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_60:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for y be ElementSUBSET-1M1-of Y holds  for z be ElementSUBSET-1M1-of Z holds ([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :])\<inverse>RELSET-1K8\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> {DOMAIN-1K6\<^bsub>([:ZFMISC-1K2 Y,Z :])\<^esub> [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> y,z ] } =RELSET-1R2\<^bsub>(X,Z)\<^esub> [:MCART-1K8\<^bsub>(X,Z)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y},{DOMAIN-1K6\<^bsub>(Z)\<^esub> z} :]"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for y be ElementSUBSET-1M1-of Y holds  for z be ElementSUBSET-1M1-of Z holds ([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :])\<inverse>RELSET-1K8\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> {DOMAIN-1K6\<^bsub>([:ZFMISC-1K2 Y,Z :])\<^esub> [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> y,z ] } =HIDDENR1 [:MCART-1K8\<^bsub>(X,Z)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y},{DOMAIN-1K6\<^bsub>(Z)\<^esub> z} :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of Z"
    have "([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :])\<inverse>RELSET-1K8\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> {DOMAIN-1K6\<^bsub>([:ZFMISC-1K2 Y,Z :])\<^esub> [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> y,z ] } =HIDDENR1 ([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :])\<inverse>RELSET-1K8\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> ([:MCART-1K8\<^bsub>(Y,Z)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y},{DOMAIN-1K6\<^bsub>(Z)\<^esub> z} :])"
      using zfmisc_1_th_29 sorry
    also have "... = [:MCART-1K8\<^bsub>(X,Z)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y},(idPARTFUN1K6 Z)\<inverse>RELSET-1K8\<^bsub>(Z,Z)\<^esub> {DOMAIN-1K6\<^bsub>(Z)\<^esub> z} :]"
      using funct_3_th_73 sorry
    also have "... = [:MCART-1K8\<^bsub>(X,Z)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y},{DOMAIN-1K6\<^bsub>(Z)\<^esub> z} :]"
      using funct_2_th_94 sorry
    finally show "([:FUNCT-3K17\<^bsub>(X,Z,Y,Z)\<^esub> F,idPARTFUN1K6 Z :])\<inverse>RELSET-1K8\<^bsub>([:ZFMISC-1K2 X,Z :],[:ZFMISC-1K2 Y,Z :])\<^esub> {DOMAIN-1K6\<^bsub>([:ZFMISC-1K2 Y,Z :])\<^esub> [DOMAIN-1K1\<^bsub>(Y,Z)\<^esub> y,z ] } =HIDDENR1 [:MCART-1K8\<^bsub>(X,Z)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {DOMAIN-1K6\<^bsub>(Y)\<^esub> y},{DOMAIN-1K6\<^bsub>(Z)\<^esub> z} :]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_61:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be Subset-FamilySETFAM-1M1-of X holds  for A be SubsetSUBSET-1M2-of D holds unionTARSKIK3 A be SubsetSUBSET-1M2-of X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be Subset-FamilySETFAM-1M1-of X holds  for A be SubsetSUBSET-1M2-of D holds unionTARSKIK3 A be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be Subset-FamilySETFAM-1M1-of X"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of D"
    have "unionTARSKIK3 A c=TARSKIR1 X"
    proof-
      have " for e be objectHIDDENM1 holds e inHIDDENR3 unionTARSKIK3 A implies e inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 unionTARSKIK3 A"
        then have " ex u be setHIDDENM2 st e inHIDDENR3 u & u inTARSKIR2 A"
          using tarski_def_4 sorry
        then have "e inHIDDENR3 unionSETFAM-1K5\<^bsub>(X)\<^esub> D"
          using tarski_def_4 sorry
        thus "e inHIDDENR3 X"
           sorry
      qed "sorry"
      thus "unionTARSKIK3 A c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    thus "unionTARSKIK3 A be SubsetSUBSET-1M2-of X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_62:
" for X be setHIDDENM2 holds  for D be a-partitionEQREL-1M3-of X holds  for A be SubsetSUBSET-1M2-of D holds  for B be SubsetSUBSET-1M2-of D holds unionTARSKIK3 (A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B) =XBOOLE-0R4 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix D assume [ty]: "D be a-partitionEQREL-1M3-of X"
  fix A assume [ty]: "A be SubsetSUBSET-1M2-of D"
  fix B assume [ty]: "B be SubsetSUBSET-1M2-of D"
  have "unionTARSKIK3 (A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B) c=TARSKIR1 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B & unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B c=TARSKIR1 unionTARSKIK3 (A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B)"
  proof(rule conjMI)
    show "unionTARSKIK3 (A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B) c=TARSKIR1 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
      using zfmisc_1_th_79 sorry
    have " for e be objectHIDDENM1 holds e inHIDDENR3 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B implies e inHIDDENR3 unionTARSKIK3 (A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B)"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume A1: "e inHIDDENR3 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
      then have "e inHIDDENR3 unionTARSKIK3 A"
        using xboole_0_def_4 sorry
      then obtain a where
        [ty]:"a be setHIDDENM2" and 
        A2: "e inHIDDENR3 a"and A3: "a inTARSKIR2 A"
        using tarski_def_4 sorry
      have A4: "a inTARSKIR2 D"
        using A3 sorry
      have "e inHIDDENR3 unionTARSKIK3 B"
        using A1 xboole_0_def_4 sorry
      then obtain b where
        [ty]:"b be setHIDDENM2" and 
        A5: "e inHIDDENR3 b"and A6: "b inTARSKIR2 B"
        using tarski_def_4 sorry
      have A7: "b inTARSKIR2 D"
        using A6 sorry
      have " not a missesXBOOLE-0R1 b"
        using A2 A5 xboole_0_th_3 sorry
      then have "a =XBOOLE-0R4 b"
        using A4 A7 eqrel_1_def_4 sorry
      then have "a inTARSKIR2 A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B"
        using A3 A6 xboole_0_def_4 sorry
      thus "e inHIDDENR3 unionTARSKIK3 (A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B)"
        using A2 tarski_def_4 sorry
    qed "sorry"
    thus "unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B c=TARSKIR1 unionTARSKIK3 (A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B)"
      using tarski_def_3 sorry
  qed
  thus "unionTARSKIK3 (A /\\SUBSET-1K9\<^bsub>(D)\<^esub> B) =XBOOLE-0R4 unionTARSKIK3 A /\\XBOOLE-0K3 unionTARSKIK3 B"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem eqrel_1_th_63:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be a-partitionEQREL-1M3-of X holds  for A be SubsetSUBSET-1M2-of D holds  for B be SubsetSUBSET-1M2-of X holds B =XBOOLE-0R4 unionTARSKIK3 A implies B `SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be a-partitionEQREL-1M3-of X holds  for A be SubsetSUBSET-1M2-of D holds  for B be SubsetSUBSET-1M2-of X holds B =XBOOLE-0R4 unionTARSKIK3 A implies B `SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be a-partitionEQREL-1M3-of X"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of D"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of X"
    assume A1: "B =XBOOLE-0R4 unionTARSKIK3 A"
    have Cut2282: "unionSETFAM-1K5\<^bsub>(X)\<^esub> D =XBOOLE-0R4 X"
      using eqrel_1_def_4 sorry
    have "B `SUBSET-1K3\<^bsub>(X)\<^esub> c=TARSKIR1 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub> & unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub> c=TARSKIR1 B `SUBSET-1K3\<^bsub>(X)\<^esub>"
    proof(rule conjMI)
      show "B `SUBSET-1K3\<^bsub>(X)\<^esub> c=TARSKIR1 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
        using A1 eqrel_1_th_55 Cut2282 sorry
      have " for e be objectHIDDENM1 holds e inHIDDENR3 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub> implies ( not e inHIDDENR3 B `SUBSET-1K3\<^bsub>(X)\<^esub> implies  False )"
      proof(rule ballI,rule impI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
        then obtain u where
          [ty]:"u be setHIDDENM2" and 
          A2: "e inHIDDENR3 u"and A3: "u inTARSKIR2 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
          using tarski_def_4 sorry
        have A4: "u inTARSKIR2 D"
          using A3 sorry
        assume " not e inHIDDENR3 B `SUBSET-1K3\<^bsub>(X)\<^esub>"
        then have "e inHIDDENR3 B"
          using A2 A4 subset_1_th_29 sorry
        then obtain v where
          [ty]:"v be setHIDDENM2" and 
          A5: "e inHIDDENR3 v"and A6: "v inTARSKIR2 A"
          using A1 tarski_def_4 sorry
        have A7: "v inTARSKIR2 D"
          using A6 sorry
        have " not u missesXBOOLE-0R1 v"
          using A2 A5 xboole_0_th_3 sorry
        then have "u =XBOOLE-0R4 v"
          using A4 A7 eqrel_1_def_4 sorry
        thus " False "
          using A3 A6 xboole_0_def_5 sorry
      qed "sorry"
      thus "unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub> c=TARSKIR1 B `SUBSET-1K3\<^bsub>(X)\<^esub>"
        using tarski_def_3 sorry
    qed
    thus "B `SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 unionTARSKIK3 A `SUBSET-1K3\<^bsub>(D)\<^esub>"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_64:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be Equivalence-RelationEQREL-1M2-of X holds ClassEQREL-1K9\<^bsub>(X)\<^esub> E be  non emptyXBOOLE-0V1"
   sorry

mdef eqrel_1_def_9 ("projEQREL-1K16\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X"
"func projEQREL-1K16\<^bsub>(X)\<^esub> D \<rightarrow> FunctionFUNCT-2M1-of(X,D) means
  \<lambda>it.  for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 it .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(X,D) st  for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 it .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
    proof-
      have " ex tVar22 be FunctionFUNCT-2M1-of(X,D) st  for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 tVar22 .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st A =HIDDENR1 Lamb2 & Lamb1 inHIDDENR3 A"
        have A1: " for e be objectHIDDENM1 holds e inHIDDENR3 X implies ( ex u be objectHIDDENM1 st u inHIDDENR3 D & ( ex A be setHIDDENM2 st A =HIDDENR1 u & e inHIDDENR3 A))"
        proof(rule ballI,rule impI)
          have A2: "unionSETFAM-1K5\<^bsub>(X)\<^esub> D =XBOOLE-0R4 X"
            using eqrel_1_def_4 sorry
          fix e assume [ty]: "e be objectHIDDENM1"
          assume "e inHIDDENR3 X"
          then have " ex u be setHIDDENM2 st e inHIDDENR3 u & u inTARSKIR2 D"
            using A2 tarski_def_4 sorry
          thus " ex u be objectHIDDENM1 st u inHIDDENR3 D & ( ex A be setHIDDENM2 st A =HIDDENR1 u & e inHIDDENR3 A)"
             sorry
        qed "sorry"
        obtain F where
          [ty]:"F be FunctionFUNCT-2M1-of(X,D)" and 
          A3: " for e be objectHIDDENM1 holds e inHIDDENR3 X implies ?P(e,F .FUNCT-1K1 e)"
          using funct_2_sch_1 A1 sorry
        show " ex tVar22 be FunctionFUNCT-2M1-of(X,D) st  for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 tVar22 .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
        proof(rule bexI[of _ "F"],rule ballI)
          fix p assume [ty]: "p be ElementSUBSET-1M1-of X"
          have "?P(p,F .FUNCT-2K3\<^bsub>(X,D)\<^esub> p)"
            using A3 sorry
          thus "p inTARSKIR2 F .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(X,D) holds  for it2 be FunctionFUNCT-2M1-of(X,D) holds ( for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 it1 .FUNCT-2K3\<^bsub>(X,D)\<^esub> p) & ( for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 it2 .FUNCT-2K3\<^bsub>(X,D)\<^esub> p) implies it1 =HIDDENR1 it2"
    proof-
      have " for F be FunctionFUNCT-2M1-of(X,D) holds  for G be FunctionFUNCT-2M1-of(X,D) holds ( for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 F .FUNCT-2K3\<^bsub>(X,D)\<^esub> p) & ( for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 G .FUNCT-2K3\<^bsub>(X,D)\<^esub> p) implies F =FUNCT-2R2\<^bsub>(X,D)\<^esub> G"
      proof(rule ballI,rule ballI,rule impI)
        fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,D)"
        fix G assume [ty]: "G be FunctionFUNCT-2M1-of(X,D)"
        assume A4: "( for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 F .FUNCT-2K3\<^bsub>(X,D)\<^esub> p) & ( for p be ElementSUBSET-1M1-of X holds p inTARSKIR2 G .FUNCT-2K3\<^bsub>(X,D)\<^esub> p)"
        have " for x be ElementSUBSET-1M1-of X holds F .FUNCT-2K3\<^bsub>(X,D)\<^esub> x =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,D)\<^esub> x"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
          have "x inTARSKIR2 F .FUNCT-2K3\<^bsub>(X,D)\<^esub> x & x inTARSKIR2 G .FUNCT-2K3\<^bsub>(X,D)\<^esub> x"
            using A4 sorry
          then have A5: " not F .FUNCT-2K3\<^bsub>(X,D)\<^esub> x missesXBOOLE-0R1 G .FUNCT-2K3\<^bsub>(X,D)\<^esub> x"
            using xboole_0_th_3 sorry
          have "F .FUNCT-2K3\<^bsub>(X,D)\<^esub> x be SubsetSUBSET-1M2-of X & G .FUNCT-2K3\<^bsub>(X,D)\<^esub> x be SubsetSUBSET-1M2-of X"
            using tarski_def_3 sorry
          thus "F .FUNCT-2K3\<^bsub>(X,D)\<^esub> x =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(X,D)\<^esub> x"
            using A5 eqrel_1_def_4 sorry
        qed "sorry"
        thus "F =FUNCT-2R2\<^bsub>(X,D)\<^esub> G"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem eqrel_1_th_65:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for p be ElementSUBSET-1M1-of X holds  for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D holds p inTARSKIR2 A implies A =XBOOLE-0R4 projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for p be ElementSUBSET-1M1-of X holds  for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D holds p inTARSKIR2 A implies A =XBOOLE-0R4 projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of X"
    fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D"
    assume A1: "p inTARSKIR2 A"
    have "p inTARSKIR2 projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
      using eqrel_1_def_9 sorry
    then have "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> p be SubsetSUBSET-1M2-of X &  not projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> p missesXBOOLE-0R1 A"
      using A1 tarski_def_3 xboole_0_th_3 sorry
    thus "A =XBOOLE-0R4 projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> p"
      using eqrel_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_66:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D holds p =XBOOLE-0R4 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D holds p =XBOOLE-0R4 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X"
    fix p assume [ty]: "p be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D"
    have "p c=TARSKIR1 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p} & (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p} c=TARSKIR1 p"
    proof(rule conjMI)
      show "p c=TARSKIR1 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
      proof-
        have " for e be objectHIDDENM1 holds e inHIDDENR3 p implies e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
        proof(rule ballI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          assume A1: "e inHIDDENR3 p"
          then have "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-1K1 e =XBOOLE-0R4 p"
            using eqrel_1_th_65 sorry
          then have "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
            using tarski_def_1 sorry
          thus "e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
            using A1 funct_2_th_38 sorry
        qed "sorry"
        thus "p c=TARSKIR1 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
          using tarski_def_3 sorry
      qed
      have " for e be objectHIDDENM1 holds e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p} implies e inHIDDENR3 p"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume A2: "e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
        then have "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-1K1 e inTARSKIR2 {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
          using funct_1_def_7 sorry
        then have "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-1K1 e =XBOOLE-0R4 p"
          using tarski_def_1 sorry
        thus "e inHIDDENR3 p"
          using A2 eqrel_1_def_9 sorry
      qed "sorry"
      thus "(projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p} c=TARSKIR1 p"
        using tarski_def_3 sorry
    qed
    thus "p =XBOOLE-0R4 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> {DOMAIN-1K6\<^bsub>(D)\<^esub> p}"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_67:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for A be SubsetSUBSET-1M2-of D holds (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A =XBOOLE-0R4 unionTARSKIK3 A"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for A be SubsetSUBSET-1M2-of D holds (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A =XBOOLE-0R4 unionTARSKIK3 A"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of D"
    have "(projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A c=TARSKIR1 unionTARSKIK3 A & unionTARSKIK3 A c=TARSKIR1 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A"
    proof(rule conjMI)
      show "(projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A c=TARSKIR1 unionTARSKIK3 A"
      proof-
        have " for e be objectHIDDENM1 holds e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A implies e inHIDDENR3 unionTARSKIK3 A"
        proof(rule ballI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          assume "e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A"
          then have "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-1K1 e inTARSKIR2 A & e inHIDDENR3 projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-1K1 e"
            using eqrel_1_def_9 funct_2_th_38 sorry
          thus "e inHIDDENR3 unionTARSKIK3 A"
            using tarski_def_4 sorry
        qed "sorry"
        thus "(projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A c=TARSKIR1 unionTARSKIK3 A"
          using tarski_def_3 sorry
      qed
      have " for e be objectHIDDENM1 holds e inHIDDENR3 unionTARSKIK3 A implies e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 unionTARSKIK3 A"
        then obtain u where
          [ty]:"u be setHIDDENM2" and 
          A1: "e inHIDDENR3 u"and A2: "u inTARSKIR2 A"
          using tarski_def_4 sorry
        have A3: "u inTARSKIR2 D"
          using A2 sorry
        then have "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-1K1 e =XBOOLE-0R4 u"
          using A1 eqrel_1_th_65 sorry
        thus "e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A"
          using A1 A2 A3 funct_2_th_38 sorry
      qed "sorry"
      thus "unionTARSKIK3 A c=TARSKIR1 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A"
        using tarski_def_3 sorry
    qed
    thus "(projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> A =XBOOLE-0R4 unionTARSKIK3 A"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_68:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for W be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D holds  ex W9 be ElementSUBSET-1M1-of X st projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> W9 =XBOOLE-0R4 W"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for W be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D holds  ex tVar23 be ElementSUBSET-1M1-of X st projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> tVar23 =XBOOLE-0R4 W"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X"
    fix W assume [ty]: "W be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of D"
    obtain p where 
      [ty]:"p be SubsetSUBSET-1M2-of X" and pDef:"p = W"
       sorry
    have "p <>HIDDENR2 {}XBOOLE-0K1"
      using eqrel_1_def_4 sorry
    then obtain W9 where
      [ty]:"W9 be ElementSUBSET-1M1-of X" and 
      A1: "W9 inTARSKIR2 p"
      using subset_1_th_4 sorry
    show " ex tVar23 be ElementSUBSET-1M1-of X st projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> tVar23 =XBOOLE-0R4 W"
    proof(rule bexI[of _ "W9"])
      show "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> W9 =XBOOLE-0R4 W"
        using A1 eqrel_1_th_65 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_69:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for W be SubsetSUBSET-1M2-of X holds ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 D & B meetsXBOOLE-0R5 W implies B c=TARSKIR1 W) implies W =XBOOLE-0R4 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X holds  for W be SubsetSUBSET-1M2-of X holds ( for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 D & B meetsXBOOLE-0R5 W implies B c=TARSKIR1 W) implies W =XBOOLE-0R4 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>a-partitionEQREL-1M3-of X"
    fix W assume [ty]: "W be SubsetSUBSET-1M2-of X"
    assume A1: " for B be SubsetSUBSET-1M2-of X holds B inTARSKIR2 D & B meetsXBOOLE-0R5 W implies B c=TARSKIR1 W"
    have "W c=TARSKIR1 X"
       sorry
    then have Cut2422: "W c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D)"
      using funct_2_def_1 sorry
    have "W c=TARSKIR1 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W) & (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W) c=TARSKIR1 W"
    proof(rule conjMI)
      show "W c=TARSKIR1 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W)"
        using funct_1_th_76 Cut2422 sorry
      have " for e be objectHIDDENM1 holds e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W) implies e inHIDDENR3 W"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume A2: "e inHIDDENR3 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W)"
        then obtain d where 
          [ty]:"d be ElementSUBSET-1M1-of X" and dDef:"d = e"
           sorry
        have "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-1K1 e inTARSKIR2 projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W"
          using A2 funct_1_def_7 sorry
        then obtain c where
          [ty]:"c be ElementSUBSET-1M1-of X" and 
          A3: "c inTARSKIR2 W"and A4: "projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> d =XBOOLE-0R4 projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> c"
          using funct_2_th_65 sorry
        obtain B where 
          [ty]:"B be SubsetSUBSET-1M2-of X" and BDef:"B = projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> c"
          using tarski_def_3 sorry
        have "c inTARSKIR2 projEQREL-1K16\<^bsub>(X)\<^esub> D .FUNCT-2K3\<^bsub>(X,D)\<^esub> c"
          using eqrel_1_def_9 sorry
        then have "B meetsXBOOLE-0R5 W"
          using A3 xboole_0_th_3 sorry
        then have A5: "B c=TARSKIR1 W"
          using A1 sorry
        have "d inTARSKIR2 B"
          using A4 eqrel_1_def_9 sorry
        thus "e inHIDDENR3 W"
          using A5 sorry
      qed "sorry"
      thus "(projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W) c=TARSKIR1 W"
        using tarski_def_3 sorry
    qed
    thus "W =XBOOLE-0R4 (projEQREL-1K16\<^bsub>(X)\<^esub> D)\<inverse>RELSET-1K8\<^bsub>(X,D)\<^esub> (projEQREL-1K16\<^bsub>(X)\<^esub> D .:RELSET-1K7\<^bsub>(X,D)\<^esub> W)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem eqrel_1_th_70:
" for X be setHIDDENM2 holds  for P be a-partitionEQREL-1M3-of X holds  for x be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds ((x inTARSKIR2 a & a inTARSKIR2 P) & x inTARSKIR2 b) & b inTARSKIR2 P implies a =XBOOLE-0R4 b"
  using eqrel_1_def_4 xboole_0_th_3 sorry

end
