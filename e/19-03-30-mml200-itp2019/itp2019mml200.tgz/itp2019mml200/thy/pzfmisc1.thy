theory pzfmisc1
  imports mboolean enumset1
begin
(*begin*)
reserve i for "objectHIDDENM1"
reserve I for "setHIDDENM2"
reserve f for "FunctionFUNCT-1M1"
reserve x, x1, x2, y, A, B, X, Y, Z for "ManySortedSetPBOOLEM1-of I"
mtheorem pzfmisc1_th_1:
" for i be objectHIDDENM1 holds  for I be setHIDDENM2 holds  for X be objectHIDDENM1 holds  for M be ManySortedSetPBOOLEM1-of I holds i inHIDDENR3 I implies domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =XBOOLE-0R4 I"
proof-
  have " for i be objectHIDDENM1 holds  for I be setHIDDENM2 holds  for X be objectHIDDENM1 holds  for M be ManySortedSetPBOOLEM1-of I holds i inHIDDENR3 I implies domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =HIDDENR1 I"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be objectHIDDENM1"
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be objectHIDDENM1"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    assume A1: "i inHIDDENR3 I"
    have "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =HIDDENR1 domRELAT-1K1 M \\/XBOOLE-0K2 domRELAT-1K1 (i .-->FUNCOP-1K17 X)"
      using funct_4_def_1 sorry
    also have "... = I \\/XBOOLE-0K2 domRELAT-1K1 (i .-->FUNCOP-1K17 X)"
      using partfun1_def_2 sorry
    also have "... = I \\/XBOOLE-0K2 {TARSKIK1 i}"
      using funcop_1_th_13 sorry
    also have "... = I"
      using A1 zfmisc_1_th_40 sorry
    finally show "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =HIDDENR1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_2:
" for f be FunctionFUNCT-1M1 holds f =XBOOLE-0R4 {}XBOOLE-0K1 implies f be ManySortedSetPBOOLEM1-of {}XBOOLE-0K1"
  using partfun1_def_2 relat_1_th_38 relat_1_def_18 sorry

mtheorem pzfmisc1_th_3:
" for I be setHIDDENM2 holds I be  non emptyXBOOLE-0V1 implies  not ( ex X be ManySortedSetPBOOLEM1-of I st X be empty-yieldingRELAT-1V3 & X be non-emptyRELAT-1V2)"
proof-
  have " for I be setHIDDENM2 holds I be  non emptyXBOOLE-0V1 implies (( ex X be ManySortedSetPBOOLEM1-of I st X be empty-yieldingRELAT-1V3 & X be non-emptyRELAT-1V2) implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    assume A1: "I be  non emptyXBOOLE-0V1"
    assume Given: " ex X be ManySortedSetPBOOLEM1-of I st X be empty-yieldingRELAT-1V3 & X be non-emptyRELAT-1V2"
    then obtain X where
      [ty]:"X be ManySortedSetPBOOLEM1-of I" and 
      A2: "X be empty-yieldingRELAT-1V3"and A3: "X be non-emptyRELAT-1V2"
       sorry
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A4: "i inHIDDENR3 I"
      using A1 xboole_0_def_1 sorry
    have "X .FUNCT-1K1 i be emptyXBOOLE-0V1"
      using A2 A4 sorry
    thus " False "
      using A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef pzfmisc1_def_1 ("{PZFMISC1K1\<^bsub>'( _ ')\<^esub>  _ }" [0,0]356 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"func {PZFMISC1K1\<^bsub>(I)\<^esub> A} \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }"
    proof-
      have " ex M be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }"
      proof-
        let ?F = "\<lambda>Lamb1. {TARSKIK1 A .FUNCT-1K1 Lamb1 }"
        show " ex M be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }"
          using pboole_sch_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }) implies it1 =HIDDENR1 it2"
    proof-
      have " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
        fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
        assume A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }"
          and A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 A .FUNCT-1K1 i }"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =HIDDENR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i =HIDDENR1 {TARSKIK1 A .FUNCT-1K1 i }"
            using A1 sorry
          also have "... = Y .FUNCT-1K1 i"
            using A2 A3 sorry
          finally show "X .FUNCT-1K1 i =HIDDENR1 Y .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem pzfmisc1_cl_1:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"cluster {PZFMISC1K1\<^bsub>(I)\<^esub> A} as-term-is non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "{PZFMISC1K1\<^bsub>(I)\<^esub> A} be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
  proof-
    have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} be non-emptyRELAT-1V2 & {PZFMISC1K1\<^bsub>(I)\<^esub> A} be finite-yieldingFINSET-1V3"
    proof(rule conjMI)
      show "{PZFMISC1K1\<^bsub>(I)\<^esub> A} be non-emptyRELAT-1V2"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i be emptyXBOOLE-0V1"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A1: "i inHIDDENR3 I"
          have "{TARSKIK1 A .FUNCT-1K1 i } <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          thus " not {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i be emptyXBOOLE-0V1"
            using A1 pzfmisc1_def_1 sorry
        qed "sorry"
        thus "{PZFMISC1K1\<^bsub>(I)\<^esub> A} be non-emptyRELAT-1V2"
          using pboole_def_13 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i be finiteFINSET-1V1"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        have "{TARSKIK1 A .FUNCT-1K1 i } be finiteFINSET-1V1"
           sorry
        thus "{PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i be finiteFINSET-1V1"
          using A2 pzfmisc1_def_1 sorry
      qed "sorry"
      thus "{PZFMISC1K1\<^bsub>(I)\<^esub> A} be finite-yieldingFINSET-1V3"
        using finset_1_def_5 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef pzfmisc1_def_2 ("{PZFMISC1K2\<^bsub>'( _ ')\<^esub> _ , _ }" [0,0,0]356 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"func {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
    proof-
      have " ex M be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
      proof-
        let ?F = "\<lambda>Lamb1. {TARSKIK2 A .FUNCT-1K1 Lamb1,B .FUNCT-1K1 Lamb1 }"
        show " ex M be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
          using pboole_sch_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }) implies it1 =HIDDENR1 it2"
    proof-
      have " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
        fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
        assume A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
          and A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =HIDDENR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i =HIDDENR1 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
            using A1 sorry
          also have "... = Y .FUNCT-1K1 i"
            using A2 A3 sorry
          finally show "X .FUNCT-1K1 i =HIDDENR1 Y .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem PZFMISC1K2_commutativity:
  mlet "I be setHIDDENM2"
" for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> B,A }"
proof-
  have " for it be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds it =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } implies it =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> B,A }"
  proof-
    have " for it be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }) implies ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 B .FUNCT-1K1 i,A .FUNCT-1K1 i })"
       sorry
    thus " ?thesis "
      using pzfmisc1_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_cl_2:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"cluster {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } as-term-is non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
  proof-
    have "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be non-emptyRELAT-1V2 & {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be finite-yieldingFINSET-1V3"
    proof(rule conjMI)
      show "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be non-emptyRELAT-1V2"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i be emptyXBOOLE-0V1"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A1: "i inHIDDENR3 I"
          have "{TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i } <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          thus " not {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i be emptyXBOOLE-0V1"
            using A1 pzfmisc1_def_2 sorry
        qed "sorry"
        thus "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be non-emptyRELAT-1V2"
          using pboole_def_13 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i be finiteFINSET-1V1"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        have "{TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i } be finiteFINSET-1V1"
           sorry
        thus "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i be finiteFINSET-1V1"
          using A2 pzfmisc1_def_2 sorry
      qed "sorry"
      thus "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be finite-yieldingFINSET-1V3"
        using finset_1_def_5 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pzfmisc1_th_4:
" for I be setHIDDENM2 holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} iff ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> y)"
proof-
  have " for I be setHIDDENM2 holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds (X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> y)) & (( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> y) implies X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y})"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> y)"
    proof-
      have "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies ( for x be ManySortedSetPBOOLEM1-of I holds (x inPBOOLER1\<^bsub>(I)\<^esub> X implies x =PBOOLER7\<^bsub>(I)\<^esub> y) & (x =PBOOLER7\<^bsub>(I)\<^esub> y implies x inPBOOLER1\<^bsub>(I)\<^esub> X))"
      proof(rule impI,rule ballI,rule conjMI,rule impI)
        assume A1: "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
        fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
        show "x inPBOOLER1\<^bsub>(I)\<^esub> X implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
        proof(rule impI)
          assume A2: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume A3: "i inHIDDENR3 I"
            then have A4: "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
              using A2 sorry
            have "X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 y .FUNCT-1K1 i }"
              using A1 A3 pzfmisc1_def_1 sorry
            thus "x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
              using A4 tarski_def_1 sorry
          qed "sorry"
          thus "x =PBOOLER7\<^bsub>(I)\<^esub> y"
             sorry
        qed
        assume A5: "x =PBOOLER7\<^bsub>(I)\<^esub> y"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 y .FUNCT-1K1 i }"
            using A1 pzfmisc1_def_1 sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
            using A5 tarski_def_1 sorry
        qed "sorry"
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
          using pboole_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A6: " for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> y"
    then have A7: "y inPBOOLER1\<^bsub>(I)\<^esub> X"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A8: "i inHIDDENR3 I"
      have " for a be objectHIDDENM1 holds a inHIDDENR3 X .FUNCT-1K1 i iff a =HIDDENR1 y .FUNCT-1K1 i"
      proof(rule ballI)
        fix a assume [ty]: "a be objectHIDDENM1"
        show "a inHIDDENR3 X .FUNCT-1K1 i iff a =HIDDENR1 y .FUNCT-1K1 i"
        proof-
          have "(a inHIDDENR3 X .FUNCT-1K1 i implies a =HIDDENR1 y .FUNCT-1K1 i) & (a =HIDDENR1 y .FUNCT-1K1 i implies a inHIDDENR3 X .FUNCT-1K1 i)"
          proof(rule conjMI,rule impI)
            show "a inHIDDENR3 X .FUNCT-1K1 i implies a =HIDDENR1 y .FUNCT-1K1 i"
            proof(rule impI)
              assume A9: "a inHIDDENR3 X .FUNCT-1K1 i"
              have A10: "domRELAT-1K1 (i .-->FUNCOP-1K17 a) =XBOOLE-0R4 {TARSKIK1 i}"
                using funcop_1_th_13 sorry
              have "domRELAT-1K1 (y +*FUNCT-4K1 (i .-->FUNCOP-1K17 a)) =XBOOLE-0R4 I"
                using A8 pzfmisc1_th_1 sorry
              then obtain x1 where 
                [ty]:"x1 be ManySortedSetPBOOLEM1-of I" and x1Def:"x1 = y +*FUNCT-4K1 (i .-->FUNCOP-1K17 a)"
                using partfun1_def_2 relat_1_def_18 sorry
              have "i inHIDDENR3 {TARSKIK1 i}"
                using tarski_def_1 sorry
              then have A11: "x1 .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 a).FUNCT-1K1 i"
                using A10 funct_4_th_13 sorry
              also have "... = a"
                using funcop_1_th_72 sorry
              finally have "x1 .FUNCT-1K1 i =HIDDENR1 a"
                 sorry
              have "x1 inPBOOLER1\<^bsub>(I)\<^esub> X"
              proof-
                have " for q be objectHIDDENM1 holds q inHIDDENR3 I implies x1 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                proof(rule ballI,rule impI)
                  fix q assume [ty]: "q be objectHIDDENM1"
                  assume A12: "q inHIDDENR3 I"
                  show "x1 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                  proof-
                    have cases: "i =HIDDENR1 q or i <>HIDDENR2 q"
                       sorry
                    have case1: "i =HIDDENR1 q implies x1 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                    proof(rule impI)
                      assume "i =HIDDENR1 q"
                      thus "x1 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                        using A9 A11 sorry
                    qed
                    have case2: "i <>HIDDENR2 q implies x1 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                    proof(rule impI)
                      assume "i <>HIDDENR2 q"
                      then have " not q inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 a)"
                        using A10 tarski_def_1 sorry
                      then have "x1 .FUNCT-1K1 q =XBOOLE-0R4 y .FUNCT-1K1 q"
                        using funct_4_th_11 sorry
                      thus "x1 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                        using A7 A12 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed "sorry"
                thus "x1 inPBOOLER1\<^bsub>(I)\<^esub> X"
                  using pboole_def_1 sorry
              qed
              thus "a =HIDDENR1 y .FUNCT-1K1 i"
                using A6 A11 sorry
            qed
            assume "a =HIDDENR1 y .FUNCT-1K1 i"
            thus "a inHIDDENR3 X .FUNCT-1K1 i"
              using A7 A8 sorry
          qed
          thus " ?thesis "
             sorry
        qed
      qed "sorry"
      then have "X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 y .FUNCT-1K1 i }"
        using tarski_def_1 sorry
      thus "X .FUNCT-1K1 i =XBOOLE-0R4 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using A8 pzfmisc1_def_1 sorry
    qed "sorry"
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_5:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2) implies X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2) implies X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: " for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2"
    then have A2: "x1 inPBOOLER1\<^bsub>(I)\<^esub> X"
       sorry
    have A3: "x2 inPBOOLER1\<^bsub>(I)\<^esub> X"
      using A1 sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      have " for a be objectHIDDENM1 holds a inHIDDENR3 X .FUNCT-1K1 i iff a =HIDDENR1 x1 .FUNCT-1K1 i or a =HIDDENR1 x2 .FUNCT-1K1 i"
      proof(rule ballI)
        fix a assume [ty]: "a be objectHIDDENM1"
        show "a inHIDDENR3 X .FUNCT-1K1 i iff a =HIDDENR1 x1 .FUNCT-1K1 i or a =HIDDENR1 x2 .FUNCT-1K1 i"
        proof-
          have "(a inHIDDENR3 X .FUNCT-1K1 i implies a =HIDDENR1 x1 .FUNCT-1K1 i or a =HIDDENR1 x2 .FUNCT-1K1 i) & (a =HIDDENR1 x1 .FUNCT-1K1 i or a =HIDDENR1 x2 .FUNCT-1K1 i implies a inHIDDENR3 X .FUNCT-1K1 i)"
          proof(rule conjMI,rule impI)
            show "a inHIDDENR3 X .FUNCT-1K1 i implies a =HIDDENR1 x1 .FUNCT-1K1 i or a =HIDDENR1 x2 .FUNCT-1K1 i"
            proof-
              have "a inHIDDENR3 X .FUNCT-1K1 i & a <>HIDDENR2 x1 .FUNCT-1K1 i implies a =HIDDENR1 x2 .FUNCT-1K1 i"
              proof(rule impMI ,rule impI)
                assume A5: "a inHIDDENR3 X .FUNCT-1K1 i"
                  and A6: "a <>HIDDENR2 x1 .FUNCT-1K1 i"
                have A7: "domRELAT-1K1 (i .-->FUNCOP-1K17 a) =XBOOLE-0R4 {TARSKIK1 i}"
                  using funcop_1_th_13 sorry
                have "domRELAT-1K1 (x2 +*FUNCT-4K1 (i .-->FUNCOP-1K17 a)) =XBOOLE-0R4 I"
                  using A4 pzfmisc1_th_1 sorry
                then obtain k2 where 
                  [ty]:"k2 be ManySortedSetPBOOLEM1-of I" and k2Def:"k2 = x2 +*FUNCT-4K1 (i .-->FUNCOP-1K17 a)"
                  using partfun1_def_2 relat_1_def_18 sorry
                have "i inHIDDENR3 {TARSKIK1 i}"
                  using tarski_def_1 sorry
                then have A8: "k2 .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 a).FUNCT-1K1 i"
                  using A7 funct_4_th_13 sorry
                also have "... = a"
                  using funcop_1_th_72 sorry
                finally have "k2 .FUNCT-1K1 i =HIDDENR1 a"
                   sorry
                have "k2 inPBOOLER1\<^bsub>(I)\<^esub> X"
                proof-
                  have " for q be objectHIDDENM1 holds q inHIDDENR3 I implies k2 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                  proof(rule ballI,rule impI)
                    fix q assume [ty]: "q be objectHIDDENM1"
                    assume A9: "q inHIDDENR3 I"
                    show "k2 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                    proof-
                      have cases: "i =HIDDENR1 q or i <>HIDDENR2 q"
                         sorry
                      have case1: "i =HIDDENR1 q implies k2 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                      proof(rule impI)
                        assume "i =HIDDENR1 q"
                        thus "k2 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                          using A5 A8 sorry
                      qed
                      have case2: "i <>HIDDENR2 q implies k2 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                      proof(rule impI)
                        assume "i <>HIDDENR2 q"
                        then have " not q inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 a)"
                          using A7 tarski_def_1 sorry
                        then have "k2 .FUNCT-1K1 q =XBOOLE-0R4 x2 .FUNCT-1K1 q"
                          using funct_4_th_11 sorry
                        thus "k2 .FUNCT-1K1 q inTARSKIR2 X .FUNCT-1K1 q"
                          using A3 A9 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                  thus "k2 inPBOOLER1\<^bsub>(I)\<^esub> X"
                    using pboole_def_1 sorry
                qed
                thus "a =HIDDENR1 x2 .FUNCT-1K1 i"
                  using A1 A6 A8 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            assume A10: "a =HIDDENR1 x1 .FUNCT-1K1 i or a =HIDDENR1 x2 .FUNCT-1K1 i"
            show "a inHIDDENR3 X .FUNCT-1K1 i"
            proof-
              have cases: "a =HIDDENR1 x1 .FUNCT-1K1 i or a =HIDDENR1 x2 .FUNCT-1K1 i"
                using A10 sorry
              have case1: "a =HIDDENR1 x1 .FUNCT-1K1 i implies a inHIDDENR3 X .FUNCT-1K1 i"
              proof(rule impI)
                assume "a =HIDDENR1 x1 .FUNCT-1K1 i"
                thus "a inHIDDENR3 X .FUNCT-1K1 i"
                  using A2 A4 sorry
              qed
              have case2: "a =HIDDENR1 x2 .FUNCT-1K1 i implies a inHIDDENR3 X .FUNCT-1K1 i"
              proof(rule impI)
                assume "a =HIDDENR1 x2 .FUNCT-1K1 i"
                thus "a inHIDDENR3 X .FUNCT-1K1 i"
                  using A3 A4 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
      qed "sorry"
      then have "X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i }"
        using tarski_def_2 sorry
      thus "X .FUNCT-1K1 i =XBOOLE-0R4 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
        using A4 pzfmisc1_def_2 sorry
    qed "sorry"
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_6:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } implies ( for x be ManySortedSetPBOOLEM1-of I holds x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2 implies x inPBOOLER1\<^bsub>(I)\<^esub> X)"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } implies ( for x be ManySortedSetPBOOLEM1-of I holds x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2 implies x inPBOOLER1\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    assume A2: "x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have A3: "X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_2 sorry
      show "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof-
        have cases: "x =PBOOLER7\<^bsub>(I)\<^esub> x1 or x =PBOOLER7\<^bsub>(I)\<^esub> x2"
          using A2 sorry
        have case1: "x =PBOOLER7\<^bsub>(I)\<^esub> x1 implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        proof(rule impI)
          assume "x =PBOOLER7\<^bsub>(I)\<^esub> x1"
          thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
            using A3 tarski_def_2 sorry
        qed
        have case2: "x =PBOOLER7\<^bsub>(I)\<^esub> x2 implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        proof(rule impI)
          assume "x =PBOOLER7\<^bsub>(I)\<^esub> x2"
          thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
            using A3 tarski_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_7:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies x =PBOOLER7\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies x =PBOOLER7\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "x .FUNCT-1K1 i inTARSKIR2 {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i"
        using A1 sorry
      then have "x .FUNCT-1K1 i inTARSKIR2 {TARSKIK1 A .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      thus "x .FUNCT-1K1 i =XBOOLE-0R4 A .FUNCT-1K1 i"
        using tarski_def_1 sorry
    qed "sorry"
    thus "x =PBOOLER7\<^bsub>(I)\<^esub> A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_8:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have "x .FUNCT-1K1 i inTARSKIR2 {TARSKIK1 x .FUNCT-1K1 i }"
        using tarski_def_1 sorry
      thus "x .FUNCT-1K1 i inTARSKIR2 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using A1 pzfmisc1_def_1 sorry
    qed "sorry"
    thus "x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_9:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x =PBOOLER7\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x =PBOOLER7\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "x =PBOOLER7\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B"
    show "x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
    proof-
      have cases: "x =PBOOLER7\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B"
        using A1 sorry
      have case1: "x =PBOOLER7\<^bsub>(I)\<^esub> A implies x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
      proof(rule impI)
        assume A2: "x =PBOOLER7\<^bsub>(I)\<^esub> A"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          have "x .FUNCT-1K1 i inTARSKIR2 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
            using A2 tarski_def_2 sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i"
            using A3 pzfmisc1_def_2 sorry
        qed "sorry"
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
          using pboole_def_1 sorry
      qed
      have case2: "x =PBOOLER7\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
      proof(rule impI)
        assume A4: "x =PBOOLER7\<^bsub>(I)\<^esub> B"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A5: "i inHIDDENR3 I"
          have "x .FUNCT-1K1 i inTARSKIR2 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
            using A4 tarski_def_2 sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i"
            using A5 pzfmisc1_def_2 sorry
        qed "sorry"
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
          using pboole_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_10:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "({PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i \\/XBOOLE-0K2 {PZFMISC1K1\<^bsub>(I)\<^esub> B} .FUNCT-1K1 i"
        using pboole_def_4 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i \\/XBOOLE-0K2 {TARSKIK1 B .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK1 A .FUNCT-1K1 i } \\/XBOOLE-0K2 {TARSKIK1 B .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
        using enumset1_th_1 sorry
      also have "... = {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i"
        using A1 pzfmisc1_def_2 sorry
      finally show "({PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_11:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,x } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,x } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,x } .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x,x } .FUNCT-1K1 i =HIDDENR1 {TARSKIK2 x .FUNCT-1K1 i,x .FUNCT-1K1 i }"
        using pzfmisc1_def_2 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
        using enumset1_th_29 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using A1 pzfmisc1_def_1 sorry
      finally show "{PZFMISC1K2\<^bsub>(I)\<^esub> x,x } .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K2\<^bsub>(I)\<^esub> x,x } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_12:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} implies A =PBOOLER7\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} implies A =PBOOLER7\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K1\<^bsub>(I)\<^esub> B} .FUNCT-1K1 i"
        using A1 sorry
      then have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i c=TARSKIR1 {TARSKIK1 B .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      then have "{TARSKIK1 A .FUNCT-1K1 i } c=TARSKIR1 {TARSKIK1 B .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      thus "A .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
        using zfmisc_1_th_18 sorry
    qed "sorry"
    thus "A =PBOOLER7\<^bsub>(I)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_13:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using pzfmisc1_def_1 sorry
      also have "... = {TARSKIK1 y .FUNCT-1K1 i }"
        using A1 A2 pzfmisc1_def_1 sorry
      finally have "{TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {TARSKIK1 y .FUNCT-1K1 i }"
         sorry
      thus "x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
        using zfmisc_1_th_3 sorry
    qed "sorry"
    thus "x =PBOOLER7\<^bsub>(I)\<^esub> y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_14:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } implies x =PBOOLER7\<^bsub>(I)\<^esub> A & x =PBOOLER7\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } implies x =PBOOLER7\<^bsub>(I)\<^esub> A & x =PBOOLER7\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using pzfmisc1_def_1 sorry
      also have "... = {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
        using A1 A2 pzfmisc1_def_2 sorry
      finally have "{TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
         sorry
      thus "x .FUNCT-1K1 i =XBOOLE-0R4 A .FUNCT-1K1 i"
        using zfmisc_1_th_4 sorry
    qed "sorry"
    thus "x =PBOOLER7\<^bsub>(I)\<^esub> A"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have "{TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using pzfmisc1_def_1 sorry
      also have "... = {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
        using A1 A3 pzfmisc1_def_2 sorry
      finally have "{TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
         sorry
      thus "x .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
        using zfmisc_1_th_4 sorry
    qed "sorry"
    thus "x =PBOOLER7\<^bsub>(I)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_15:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } implies A =PBOOLER7\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } implies A =PBOOLER7\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using pzfmisc1_def_1 sorry
      also have "... = {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
        using A1 A2 pzfmisc1_def_2 sorry
      finally have "{TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
         sorry
      thus "A .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
        using zfmisc_1_th_5 sorry
    qed "sorry"
    thus "A =PBOOLER7\<^bsub>(I)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_16:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } & {PZFMISC1K1\<^bsub>(I)\<^esub> y} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } & {PZFMISC1K1\<^bsub>(I)\<^esub> y} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    show "{PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A1: "i inHIDDENR3 I"
        have "{TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
          using zfmisc_1_th_7 sorry
        then have "{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
          using A1 pzfmisc1_def_1 sorry
        thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
          using A1 pzfmisc1_def_2 sorry
      qed "sorry"
      thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
        using pboole_def_2 sorry
    qed
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      have "{TARSKIK1 y .FUNCT-1K1 i } c=TARSKIR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using zfmisc_1_th_7 sorry
      then have "{PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i c=TARSKIR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      thus "{PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using A2 pzfmisc1_def_2 sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> y} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_17:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      have "{TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\/XBOOLE-0K2 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      also have "... = ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}).FUNCT-1K1 i"
        using A2 pboole_def_4 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
        using A2 A1 pzfmisc1_def_1 sorry
      finally have "{TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i }"
         sorry
      thus "x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
        using zfmisc_1_th_8 sorry
    qed "sorry"
    thus "x =PBOOLER7\<^bsub>(I)\<^esub> y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_18:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\/XBOOLE-0K2 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using pboole_def_4 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using A1 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_2 sorry
      also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using zfmisc_1_th_9 sorry
      also have "... = {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using A1 pzfmisc1_def_2 sorry
      finally show "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_19:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x <>HIDDENR2 y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  not x <>HIDDENR2 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " ex i be objectHIDDENM1 st x .FUNCT-1K1 i <>HIDDENR2 y .FUNCT-1K1 i"
    proof-
      obtain i where
        [ty]:"i be objectHIDDENM1" and 
        A3: "i inHIDDENR3 I"
        using A1 xboole_0_def_1 sorry
      show " ex i be objectHIDDENM1 st x .FUNCT-1K1 i <>HIDDENR2 y .FUNCT-1K1 i"
      proof(rule bexI[of _ "i"])
        have "{TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i /\\XBOOLE-0K3 {TARSKIK1 y .FUNCT-1K1 i }"
          using A3 pzfmisc1_def_1 sorry
        also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i /\\XBOOLE-0K3 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
          using A3 pzfmisc1_def_1 sorry
        also have "... = ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}).FUNCT-1K1 i"
          using A3 pboole_def_5 sorry
        also have "... = {}XBOOLE-0K1"
          using A2 pboole_th_5 sorry
        finally have "{TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {}XBOOLE-0K1"
           sorry
        thus "x .FUNCT-1K1 i <>HIDDENR2 y .FUNCT-1K1 i"
           sorry
      qed "sorry"
    qed
    thus " not x <>HIDDENR2 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_20:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using pzfmisc1_def_1 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i /\\XBOOLE-0K3 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      also have "... = ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}).FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
        using A1 A2 pzfmisc1_def_1 sorry
      finally have "{TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i }"
         sorry
      thus "x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
        using zfmisc_1_th_12 sorry
    qed "sorry"
    thus "x =PBOOLER7\<^bsub>(I)\<^esub> y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_21:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i /\\XBOOLE-0K3 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using pboole_def_5 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using A1 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_2 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
        using zfmisc_1_th_13 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using A1 pzfmisc1_def_1 sorry
      finally show "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_22:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x <>HIDDENR2 y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies  not x <>HIDDENR2 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
    have " ex i be objectHIDDENM1 st x .FUNCT-1K1 i <>HIDDENR2 y .FUNCT-1K1 i"
    proof-
      obtain i where
        [ty]:"i be objectHIDDENM1" and 
        A3: "i inHIDDENR3 I"
        using A1 xboole_0_def_1 sorry
      show " ex i be objectHIDDENM1 st x .FUNCT-1K1 i <>HIDDENR2 y .FUNCT-1K1 i"
      proof(rule bexI[of _ "i"])
        have "{TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK1 y .FUNCT-1K1 i }"
          using A3 pzfmisc1_def_1 sorry
        also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
          using A3 pzfmisc1_def_1 sorry
        also have "... = ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}).FUNCT-1K1 i"
          using A3 pboole_def_6 sorry
        also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
          using A2 A3 pzfmisc1_def_1 sorry
        finally have "{TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i }"
           sorry
        thus "x .FUNCT-1K1 i <>HIDDENR2 y .FUNCT-1K1 i"
          using zfmisc_1_th_14 sorry
      qed "sorry"
    qed
    thus " not x <>HIDDENR2 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_23:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x =PBOOLER7\<^bsub>(I)\<^esub> y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK1 y .FUNCT-1K1 i }"
        using pzfmisc1_def_1 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      also have "... = ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}).FUNCT-1K1 i"
        using A2 pboole_def_6 sorry
      also have "... = {}XBOOLE-0K1"
        using A1 pboole_th_5 sorry
      finally have "{TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 {TARSKIK1 y .FUNCT-1K1 i } =HIDDENR1 {}XBOOLE-0K1"
         sorry
      thus "x .FUNCT-1K1 i =XBOOLE-0R4 y .FUNCT-1K1 i"
        using zfmisc_1_th_15 sorry
    qed "sorry"
    thus "x =PBOOLER7\<^bsub>(I)\<^esub> y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_24:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using pboole_def_6 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using A1 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_2 sorry
      also have "... = {}XBOOLE-0K1"
        using zfmisc_1_th_16 sorry
      also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_th_5 sorry
      finally show "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_25:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using A1 sorry
      then have "{TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      then have A3: "{TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 {TARSKIK1 y .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      have "{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK1 y .FUNCT-1K1 i }"
        using A3 zfmisc_1_th_18 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      finally show "{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_26:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies x =PBOOLER7\<^bsub>(I)\<^esub> A & y =PBOOLER7\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies x =PBOOLER7\<^bsub>(I)\<^esub> A & y =PBOOLER7\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i =XBOOLE-0R4 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i"
        using A1 sorry
      then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i c=TARSKIR1 {TARSKIK1 A .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } c=TARSKIR1 {TARSKIK1 A .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_2 sorry
      thus "x .FUNCT-1K1 i =XBOOLE-0R4 A .FUNCT-1K1 i"
        using zfmisc_1_th_20 sorry
    qed "sorry"
    thus "x =PBOOLER7\<^bsub>(I)\<^esub> A"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies y .FUNCT-1K1 i =XBOOLE-0R4 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i"
        using A1 sorry
      then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i c=TARSKIR1 {TARSKIK1 A .FUNCT-1K1 i }"
        using A3 pzfmisc1_def_1 sorry
      then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } c=TARSKIR1 {TARSKIK1 A .FUNCT-1K1 i }"
        using A3 pzfmisc1_def_2 sorry
      thus "y .FUNCT-1K1 i =XBOOLE-0R4 A .FUNCT-1K1 i"
        using zfmisc_1_th_20 sorry
    qed "sorry"
    thus "y =PBOOLER7\<^bsub>(I)\<^esub> A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_27:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A}"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A} implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i"
        using A1 sorry
      then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } c=TARSKIR1 {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_2 sorry
      then have A3: "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } c=TARSKIR1 {TARSKIK1 A .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      have "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i =HIDDENR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_2 sorry
      also have "... = {TARSKIK1 A .FUNCT-1K1 i }"
        using A3 zfmisc_1_th_21 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      finally show "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> A}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_28:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I,{PZFMISC1K1\<^bsub>(I)\<^esub> x} }"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I,{PZFMISC1K1\<^bsub>(I)\<^esub> x} }"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I,{PZFMISC1K1\<^bsub>(I)\<^esub> x} } .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 ({PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i)"
        using mboolean_def_1 sorry
      also have "... = boolZFMISC-1K1 {TARSKIK1 x .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x .FUNCT-1K1 i } }"
        using zfmisc_1_th_24 sorry
      also have "... = {TARSKIK2 EmptyMSPBOOLEK1 I .FUNCT-1K1 i,{TARSKIK1 x .FUNCT-1K1 i } }"
        using pboole_th_5 sorry
      also have "... = {TARSKIK2 EmptyMSPBOOLEK1 I .FUNCT-1K1 i,{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_1 sorry
      also have "... = {PZFMISC1K2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I,{PZFMISC1K1\<^bsub>(I)\<^esub> x} } .FUNCT-1K1 i"
        using A1 pzfmisc1_def_2 sorry
      finally show "boolMBOOLEANK1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I,{PZFMISC1K1\<^bsub>(I)\<^esub> x} } .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I,{PZFMISC1K1\<^bsub>(I)\<^esub> x} }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_29:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have "{TARSKIK1 A .FUNCT-1K1 i } c=TARSKIR1 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
        using zfmisc_1_th_68 sorry
      then have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i c=TARSKIR1 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
        using A1 pzfmisc1_def_1 sorry
      thus "{PZFMISC1K1\<^bsub>(I)\<^esub> A} .FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
        using A1 mboolean_def_1 sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_30:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> x"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> x"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 x .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 ({PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i)"
        using mboolean_def_2 sorry
      also have "... = unionTARSKIK3 {TARSKIK1 x .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_1 sorry
      also have "... = x .FUNCT-1K1 i"
        using zfmisc_1_th_25 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i =HIDDENR1 x .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_31:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},{PZFMISC1K1\<^bsub>(I)\<^esub> y} } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},{PZFMISC1K1\<^bsub>(I)\<^esub> y} } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},{PZFMISC1K1\<^bsub>(I)\<^esub> y} } .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},{PZFMISC1K1\<^bsub>(I)\<^esub> y} } .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 ({PZFMISC1K2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},{PZFMISC1K1\<^bsub>(I)\<^esub> y} } .FUNCT-1K1 i)"
        using mboolean_def_2 sorry
      also have "... = unionTARSKIK3 {TARSKIK2 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i,{PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_2 sorry
      also have "... = unionTARSKIK3 {TARSKIK2 {TARSKIK1 x .FUNCT-1K1 i },{PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_1 sorry
      also have "... = unionTARSKIK3 {TARSKIK2 {TARSKIK1 x .FUNCT-1K1 i },{TARSKIK1 y .FUNCT-1K1 i } }"
        using A1 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using zfmisc_1_th_26 sorry
      also have "... = {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
        using A1 pzfmisc1_def_2 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},{PZFMISC1K1\<^bsub>(I)\<^esub> y} } .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},{PZFMISC1K1\<^bsub>(I)\<^esub> y} } =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_32:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } =PBOOLER7\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } =PBOOLER7\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i =HIDDENR1 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 ({PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i)"
        using mboolean_def_2 sorry
      also have "... = unionTARSKIK3 {TARSKIK2 A .FUNCT-1K1 i,B .FUNCT-1K1 i }"
        using A1 pzfmisc1_def_2 sorry
      also have "... = A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i"
        using zfmisc_1_th_75 sorry
      also have "... = (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } .FUNCT-1K1 i =HIDDENR1 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } =PBOOLER7\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_33:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> X iff x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ({PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> X) & (x inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "{PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof(rule impI)
      assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> X"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        then have "{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
          using A1 sorry
        then have "{TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 X .FUNCT-1K1 i"
          using A2 pzfmisc1_def_1 sorry
        thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using zfmisc_1_th_31 sorry
      qed "sorry"
      thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        using pboole_def_1 sorry
    qed
    assume A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A3 sorry
      then have "{TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 X .FUNCT-1K1 i"
        using zfmisc_1_th_31 sorry
      thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
        using A4 pzfmisc1_def_1 sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_34:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } c=PBOOLER2\<^bsub>(I)\<^esub> X iff x1 inPBOOLER1\<^bsub>(I)\<^esub> X & x2 inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ({PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } c=PBOOLER2\<^bsub>(I)\<^esub> X implies x1 inPBOOLER1\<^bsub>(I)\<^esub> X & x2 inPBOOLER1\<^bsub>(I)\<^esub> X) & (x1 inPBOOLER1\<^bsub>(I)\<^esub> X & x2 inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } c=PBOOLER2\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "{PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } c=PBOOLER2\<^bsub>(I)\<^esub> X implies x1 inPBOOLER1\<^bsub>(I)\<^esub> X & x2 inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof(rule impI,rule conjMI)
      assume A1: "{PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } c=PBOOLER2\<^bsub>(I)\<^esub> X"
      show "x1 inPBOOLER1\<^bsub>(I)\<^esub> X"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x1 .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A2: "i inHIDDENR3 I"
          then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
            using A1 sorry
          then have "{TARSKIK2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i } c=TARSKIR1 X .FUNCT-1K1 i"
            using A2 pzfmisc1_def_2 sorry
          thus "x1 .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
            using zfmisc_1_th_32 sorry
        qed "sorry"
        thus "x1 inPBOOLER1\<^bsub>(I)\<^esub> X"
          using pboole_def_1 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x2 .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
          using A1 sorry
        then have "{TARSKIK2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i } c=TARSKIR1 X .FUNCT-1K1 i"
          using A3 pzfmisc1_def_2 sorry
        thus "x2 .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using zfmisc_1_th_32 sorry
      qed "sorry"
      thus "x2 inPBOOLER1\<^bsub>(I)\<^esub> X"
        using pboole_def_1 sorry
    qed
    assume A4: "x1 inPBOOLER1\<^bsub>(I)\<^esub> X"
      and A5: "x2 inPBOOLER1\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A6: "i inHIDDENR3 I"
      then have A7: "x1 .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A4 sorry
      have "x2 .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A5 A6 sorry
      then have "{TARSKIK2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i } c=TARSKIR1 X .FUNCT-1K1 i"
        using A7 zfmisc_1_th_32 sorry
      thus "{PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
        using A6 pzfmisc1_def_2 sorry
    qed "sorry"
    thus "{PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_35:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds ((A =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x1}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x2}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } implies A c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds ((A =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x1}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x2}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } implies A c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    assume A1: "((A =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x1}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x2}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      show "A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
      proof-
        have cases: "((A =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x1}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x2}) or A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
          using A1 sorry
        have case1: "A =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
        proof(rule impI)
          assume "A =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
          then have "A .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
            using pboole_th_5 sorry
          then have "A .FUNCT-1K1 i c=TARSKIR1 {TARSKIK2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i }"
            using zfmisc_1_th_36 sorry
          thus "A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
            using A2 pzfmisc1_def_2 sorry
        qed
        have case2: "A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x1} implies A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
        proof(rule impI)
          assume "A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x1}"
          then have "A .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 x1 .FUNCT-1K1 i }"
            using A2 pzfmisc1_def_1 sorry
          then have "A .FUNCT-1K1 i c=TARSKIR1 {TARSKIK2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i }"
            using zfmisc_1_th_36 sorry
          thus "A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
            using A2 pzfmisc1_def_2 sorry
        qed
        have case3: "A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x2} implies A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
        proof(rule impI)
          assume "A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x2}"
          then have "A .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 x2 .FUNCT-1K1 i }"
            using A2 pzfmisc1_def_1 sorry
          then have "A .FUNCT-1K1 i c=TARSKIR1 {TARSKIK2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i }"
            using zfmisc_1_th_36 sorry
          thus "A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
            using A2 pzfmisc1_def_2 sorry
        qed
        have case4: "A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } implies A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
        proof(rule impI)
          assume "A =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
          thus "A .FUNCT-1K1 i c=TARSKIR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 } .FUNCT-1K1 i"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 case4 sorry
      qed
    qed "sorry"
    thus "A c=PBOOLER2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x1,x2 }"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem pzfmisc1_th_36:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      show "x .FUNCT-1K1 i inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i"
      proof-
        have cases: "x inPBOOLER1\<^bsub>(I)\<^esub> A or x =PBOOLER7\<^bsub>(I)\<^esub> B"
          using A1 sorry
        have case1: "x inPBOOLER1\<^bsub>(I)\<^esub> A implies x .FUNCT-1K1 i inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i"
        proof(rule impI)
          assume "x inPBOOLER1\<^bsub>(I)\<^esub> A"
          then have "x .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
            using A2 sorry
          then have "x .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 {TARSKIK1 B .FUNCT-1K1 i }"
            using zfmisc_1_th_136 sorry
          then have "x .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 {PZFMISC1K1\<^bsub>(I)\<^esub> B} .FUNCT-1K1 i"
            using A2 pzfmisc1_def_1 sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i"
            using A2 pboole_def_4 sorry
        qed
        have case2: "x =PBOOLER7\<^bsub>(I)\<^esub> B implies x .FUNCT-1K1 i inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i"
        proof(rule impI)
          assume "x =PBOOLER7\<^bsub>(I)\<^esub> B"
          then have "x .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 {TARSKIK1 B .FUNCT-1K1 i }"
            using zfmisc_1_th_136 sorry
          then have "x .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 {PZFMISC1K1\<^bsub>(I)\<^esub> B} .FUNCT-1K1 i"
            using A2 pzfmisc1_def_1 sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}).FUNCT-1K1 i"
            using A2 pboole_def_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "x inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B}"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_37:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> B iff x inPBOOLER1\<^bsub>(I)\<^esub> B & A c=PBOOLER2\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> B & A c=PBOOLER2\<^bsub>(I)\<^esub> B) & (x inPBOOLER1\<^bsub>(I)\<^esub> B & A c=PBOOLER2\<^bsub>(I)\<^esub> B implies A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    show "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> B implies x inPBOOLER1\<^bsub>(I)\<^esub> B & A c=PBOOLER2\<^bsub>(I)\<^esub> B"
    proof(rule impI,rule conjMI)
      assume A1: "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> B"
      have A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i \\/XBOOLE-0K2 {TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 B .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have "(A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
          using A1 sorry
        then have "A .FUNCT-1K1 i \\/XBOOLE-0K2 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
          using A3 pboole_def_4 sorry
        thus "A .FUNCT-1K1 i \\/XBOOLE-0K2 {TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 B .FUNCT-1K1 i"
          using A3 pzfmisc1_def_1 sorry
      qed "sorry"
      show "x inPBOOLER1\<^bsub>(I)\<^esub> B"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 B .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "A .FUNCT-1K1 i \\/XBOOLE-0K2 {TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 B .FUNCT-1K1 i"
            using A2 sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 B .FUNCT-1K1 i"
            using zfmisc_1_th_137 sorry
        qed "sorry"
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> B"
          using pboole_def_1 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 I"
        then have "A .FUNCT-1K1 i \\/XBOOLE-0K2 {TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 B .FUNCT-1K1 i"
          using A2 sorry
        thus "A .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
          using zfmisc_1_th_137 sorry
      qed "sorry"
      thus "A c=PBOOLER2\<^bsub>(I)\<^esub> B"
        using pboole_def_2 sorry
    qed
    assume A4: "x inPBOOLER1\<^bsub>(I)\<^esub> B"
      and A5: "A c=PBOOLER2\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A6: "i inHIDDENR3 I"
      then have A7: "x .FUNCT-1K1 i inTARSKIR2 B .FUNCT-1K1 i"
        using A4 sorry
      have "A .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A5 A6 sorry
      then have "A .FUNCT-1K1 i \\/XBOOLE-0K2 {TARSKIK1 x .FUNCT-1K1 i } c=TARSKIR1 B .FUNCT-1K1 i"
        using A7 zfmisc_1_th_137 sorry
      then have "A .FUNCT-1K1 i \\/XBOOLE-0K2 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A6 pzfmisc1_def_1 sorry
      thus "(A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A6 pboole_def_4 sorry
    qed "sorry"
    thus "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} c=PBOOLER2\<^bsub>(I)\<^esub> B"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_38:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "{TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i"
        using pzfmisc1_def_1 sorry
      also have "... = X .FUNCT-1K1 i"
        using A1 A2 pboole_def_4 sorry
      finally have "{TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 X .FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i"
         sorry
      thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using zfmisc_1_th_39 sorry
    qed "sorry"
    thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_39:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A1 sorry
      have "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i"
        using A2 pboole_def_4 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 X .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      also have "... = X .FUNCT-1K1 i"
        using A3 zfmisc_1_th_40 sorry
      finally show "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_40:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A =PBOOLER7\<^bsub>(I)\<^esub> A iff x inPBOOLER1\<^bsub>(I)\<^esub> A & y inPBOOLER1\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A =PBOOLER7\<^bsub>(I)\<^esub> A implies x inPBOOLER1\<^bsub>(I)\<^esub> A & y inPBOOLER1\<^bsub>(I)\<^esub> A) & (x inPBOOLER1\<^bsub>(I)\<^esub> A & y inPBOOLER1\<^bsub>(I)\<^esub> A implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A =PBOOLER7\<^bsub>(I)\<^esub> A)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    show "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A =PBOOLER7\<^bsub>(I)\<^esub> A implies x inPBOOLER1\<^bsub>(I)\<^esub> A & y inPBOOLER1\<^bsub>(I)\<^esub> A"
    proof(rule impI,rule conjMI)
      assume A1: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A =PBOOLER7\<^bsub>(I)\<^esub> A"
      show "x inPBOOLER1\<^bsub>(I)\<^esub> A"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A2: "i inHIDDENR3 I"
          then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\/XBOOLE-0K2 A .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\/XBOOLE-0K2 A .FUNCT-1K1 i"
            using pzfmisc1_def_2 sorry
          also have "... = A .FUNCT-1K1 i"
            using A1 A2 pboole_def_4 sorry
          finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\/XBOOLE-0K2 A .FUNCT-1K1 i =HIDDENR1 A .FUNCT-1K1 i"
             sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
            using zfmisc_1_th_41 sorry
        qed "sorry"
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> A"
          using pboole_def_1 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies y .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\/XBOOLE-0K2 A .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\/XBOOLE-0K2 A .FUNCT-1K1 i"
          using pzfmisc1_def_2 sorry
        also have "... = A .FUNCT-1K1 i"
          using A1 A3 pboole_def_4 sorry
        finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\/XBOOLE-0K2 A .FUNCT-1K1 i =HIDDENR1 A .FUNCT-1K1 i"
           sorry
        thus "y .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
          using zfmisc_1_th_41 sorry
      qed "sorry"
      thus "y inPBOOLER1\<^bsub>(I)\<^esub> A"
        using pboole_def_1 sorry
    qed
    assume A4: "x inPBOOLER1\<^bsub>(I)\<^esub> A"
      and A5: "y inPBOOLER1\<^bsub>(I)\<^esub> A"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A).FUNCT-1K1 i =HIDDENR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A6: "i inHIDDENR3 I"
      then have A7: "x .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
        using A4 sorry
      have A8: "y .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
        using A5 A6 sorry
      have "({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\/XBOOLE-0K2 A .FUNCT-1K1 i"
        using A6 pboole_def_4 sorry
      also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\/XBOOLE-0K2 A .FUNCT-1K1 i"
        using A6 pzfmisc1_def_2 sorry
      also have "... = A .FUNCT-1K1 i"
        using A7 A8 zfmisc_1_th_42 sorry
      finally show "({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A).FUNCT-1K1 i =HIDDENR1 A .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> A =PBOOLER7\<^bsub>(I)\<^esub> A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_41:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X <>HIDDENR2 EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A3: "i inHIDDENR3 I"
      using A1 xboole_0_def_1 sorry
    have "{TARSKIK1 x .FUNCT-1K1 i } \\/XBOOLE-0K2 X .FUNCT-1K1 i <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then have "{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i <>HIDDENR2 {}XBOOLE-0K1"
      using A3 pzfmisc1_def_1 sorry
    then have "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X).FUNCT-1K1 i <>HIDDENR2 {}XBOOLE-0K1"
      using A3 pboole_def_4 sorry
    thus " False "
      using A2 pboole_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_42:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X <>HIDDENR2 EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A3: "i inHIDDENR3 I"
      using A1 xboole_0_def_1 sorry
    have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\/XBOOLE-0K2 X .FUNCT-1K1 i <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then have "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i <>HIDDENR2 {}XBOOLE-0K1"
      using A3 pzfmisc1_def_2 sorry
    then have "({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X).FUNCT-1K1 i <>HIDDENR2 {}XBOOLE-0K1"
      using A3 pboole_def_4 sorry
    thus " False "
      using A2 pboole_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem pzfmisc1_th_43:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i /\\XBOOLE-0K3 {TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 X .FUNCT-1K1 i /\\XBOOLE-0K3 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using pzfmisc1_def_1 sorry
      also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
        using A1 A2 pzfmisc1_def_1 sorry
      finally have "X .FUNCT-1K1 i /\\XBOOLE-0K3 {TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i }"
         sorry
      thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using zfmisc_1_th_45 sorry
    qed "sorry"
    thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_44:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A1 sorry
      have "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i /\\XBOOLE-0K3 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      also have "... = X .FUNCT-1K1 i /\\XBOOLE-0K3 {TARSKIK1 x .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
        using A3 zfmisc_1_th_46 sorry
      also have "... = {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using A2 pzfmisc1_def_1 sorry
      finally show "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_45:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X iff {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds (x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }) & ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } implies x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
    proof(rule impMI ,rule impI)
      assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        and A2: "y inPBOOLER1\<^bsub>(I)\<^esub> X"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have A4: "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using A1 sorry
        have A5: "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using A2 A3 sorry
        have "({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i /\\XBOOLE-0K3 X .FUNCT-1K1 i"
          using A3 pboole_def_5 sorry
        also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i"
          using A3 pzfmisc1_def_2 sorry
        also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
          using A4 A5 zfmisc_1_th_47 sorry
        also have "... = {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
          using A3 pzfmisc1_def_2 sorry
        finally show "({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
           sorry
      qed "sorry"
      thus "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
         sorry
    qed
    assume A6: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
    show "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A7: "i inHIDDENR3 I"
        then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i /\\XBOOLE-0K3 X .FUNCT-1K1 i"
          using pzfmisc1_def_2 sorry
        also have "... = ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
          using A7 pboole_def_5 sorry
        also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
          using A6 A7 pzfmisc1_def_2 sorry
        finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
           sorry
        thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using zfmisc_1_th_55 sorry
      qed "sorry"
      thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        using pboole_def_1 sorry
    qed
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A8: "i inHIDDENR3 I"
      then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i /\\XBOOLE-0K3 X .FUNCT-1K1 i"
        using pzfmisc1_def_2 sorry
      also have "... = ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
        using A8 pboole_def_5 sorry
      also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
        using A6 A8 pzfmisc1_def_2 sorry
      finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
         sorry
      thus "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using zfmisc_1_th_55 sorry
    qed "sorry"
    thus "y inPBOOLER1\<^bsub>(I)\<^esub> X"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_46:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I & x inPBOOLER1\<^bsub>(I)\<^esub> X) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      and A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A4: "i inHIDDENR3 I"
      using A1 xboole_0_def_1 sorry
    have "{TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i /\\XBOOLE-0K3 X .FUNCT-1K1 i"
      using A4 pzfmisc1_def_1 sorry
    also have "... = ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
      using A4 pboole_def_5 sorry
    also have "... = {}XBOOLE-0K1"
      using A2 pboole_th_5 sorry
    finally have "{TARSKIK1 x .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
       sorry
    then have "{TARSKIK1 x .FUNCT-1K1 i } missesXBOOLE-0R1 X .FUNCT-1K1 i"
      using xboole_0_def_7 sorry
    then have " not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      using zfmisc_1_th_48 sorry
    thus " False "
      using A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_47:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X &  not y inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X & (y inPBOOLER1\<^bsub>(I)\<^esub> X implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have A3: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i /\\XBOOLE-0K3 X .FUNCT-1K1 i"
        using pzfmisc1_def_2 sorry
      also have "... = ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
        using A4 pboole_def_5 sorry
      also have "... = {}XBOOLE-0K1"
        using A2 pboole_th_5 sorry
      finally show "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
         sorry
    qed "sorry"
    show " not x inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof-
      have "x inPBOOLER1\<^bsub>(I)\<^esub> X implies  False "
      proof(rule impI)
        assume A5: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        have " ex i be objectHIDDENM1 st i inHIDDENR3 I &  not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        proof-
          obtain i where
            [ty]:"i be objectHIDDENM1" and 
            A6: "i inHIDDENR3 I"
            using A1 xboole_0_def_1 sorry
          show " ex i be objectHIDDENM1 st i inHIDDENR3 I &  not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          proof(rule bexI[of _ "i"])
            have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
              using A3 A6 sorry
            then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } missesXBOOLE-0R1 X .FUNCT-1K1 i"
              using xboole_0_def_7 sorry
            thus "i inHIDDENR3 I &  not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
              using A6 zfmisc_1_th_49 sorry
          qed "sorry"
        qed
        thus " False "
          using A5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A7: "y inPBOOLER1\<^bsub>(I)\<^esub> X"
    have " ex i be objectHIDDENM1 st i inHIDDENR3 I &  not y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
    proof-
      obtain i where
        [ty]:"i be objectHIDDENM1" and 
        A8: "i inHIDDENR3 I"
        using A1 xboole_0_def_1 sorry
      show " ex i be objectHIDDENM1 st i inHIDDENR3 I &  not y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule bexI[of _ "i"])
        have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } /\\XBOOLE-0K3 X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
          using A3 A8 sorry
        then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } missesXBOOLE-0R1 X .FUNCT-1K1 i"
          using xboole_0_def_7 sorry
        thus "i inHIDDENR3 I &  not y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using A8 zfmisc_1_th_49 sorry
      qed "sorry"
    qed
    thus " False "
      using A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem pzfmisc1_th_48:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds y inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies y inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds y inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies y inPBOOLER1\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "y inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "y .FUNCT-1K1 i inTARSKIR2 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i"
        using A1 sorry
      then have "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using A2 pboole_def_6 sorry
      then have "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK1 x .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_1 sorry
      thus "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using zfmisc_1_th_56 sorry
    qed "sorry"
    thus "y inPBOOLER1\<^bsub>(I)\<^esub> X"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_49:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & y inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies y <>HIDDENR2 x"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & y inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies  not y <>HIDDENR2 x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "y inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A3: "i inHIDDENR3 I"
      using A1 xboole_0_def_1 sorry
    have " ex i be objectHIDDENM1 st y .FUNCT-1K1 i <>HIDDENR2 x .FUNCT-1K1 i"
    proof-
      show " ex i be objectHIDDENM1 st y .FUNCT-1K1 i <>HIDDENR2 x .FUNCT-1K1 i"
      proof(rule bexI[of _ "i"])
        have "y .FUNCT-1K1 i inTARSKIR2 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}).FUNCT-1K1 i"
          using A2 A3 sorry
        then have "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
          using A3 pboole_def_6 sorry
        then have "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK1 x .FUNCT-1K1 i }"
          using A3 pzfmisc1_def_1 sorry
        thus "y .FUNCT-1K1 i <>HIDDENR2 x .FUNCT-1K1 i"
          using zfmisc_1_th_56 sorry
      qed "sorry"
    qed
    thus " not y <>HIDDENR2 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_50:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> X implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> X) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} =PBOOLER7\<^bsub>(I)\<^esub> X"
      and A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    have A4: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A5: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 X .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i"
        using pzfmisc1_def_1 sorry
      also have "... = X .FUNCT-1K1 i"
        using A2 A5 pboole_def_6 sorry
      finally show "X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK1 x .FUNCT-1K1 i } =HIDDENR1 X .FUNCT-1K1 i"
         sorry
    qed "sorry"
    have " ex i be objectHIDDENM1 st i inHIDDENR3 I &  not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
    proof-
      obtain i where
        [ty]:"i be objectHIDDENM1" and 
        A6: "i inHIDDENR3 I"
        using A1 xboole_0_def_1 sorry
      show " ex i be objectHIDDENM1 st i inHIDDENR3 I &  not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule bexI[of _ "i"],rule conjMI)
        show "i inHIDDENR3 I"
          using A6 sorry
        have "X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK1 x .FUNCT-1K1 i } =XBOOLE-0R4 X .FUNCT-1K1 i"
          using A4 A6 sorry
        thus " not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using zfmisc_1_th_57 sorry
      qed "sorry"
    qed
    thus " False "
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_51:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} & x inPBOOLER1\<^bsub>(I)\<^esub> X) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
      and A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A4: "i inHIDDENR3 I"
      using A1 xboole_0_def_1 sorry
    have "{TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
      using A4 pzfmisc1_def_1 sorry
    also have "... = ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
      using A4 pboole_def_6 sorry
    also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
      using A2 A4 pzfmisc1_def_1 sorry
    finally have "{TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i }"
       sorry
    then have " not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      using zfmisc_1_th_59 sorry
    thus " False "
      using A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_52:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I iff x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x inPBOOLER1\<^bsub>(I)\<^esub> X) & (x inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof(rule impI)
      assume A1: "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        then have "{TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
          using pzfmisc1_def_1 sorry
        also have "... = ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
          using A2 pboole_def_6 sorry
        also have "... = {}XBOOLE-0K1"
          using A1 pboole_th_5 sorry
        finally have "{TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
           sorry
        thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using zfmisc_1_th_60 sorry
      qed "sorry"
      thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        using pboole_def_1 sorry
    qed
    assume A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      then have A5: "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A3 sorry
      have "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
        using A4 pboole_def_6 sorry
      also have "... = {TARSKIK1 x .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i"
        using A4 pzfmisc1_def_1 sorry
      also have "... = {}XBOOLE-0K1"
        using A5 zfmisc_1_th_60 sorry
      also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_th_5 sorry
      finally show "({PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> x} (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_53:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "I be  non emptyXBOOLE-0V1"
      and A2: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A3: "i inHIDDENR3 I"
      using A1 xboole_0_def_1 sorry
    have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
      using A3 pzfmisc1_def_2 sorry
    also have "... = ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
      using A3 pboole_def_6 sorry
    also have "... = {TARSKIK1 x .FUNCT-1K1 i }"
      using A2 A3 pzfmisc1_def_1 sorry
    finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {TARSKIK1 x .FUNCT-1K1 i }"
       sorry
    then have " not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      using zfmisc_1_th_62 sorry
    thus " not x inPBOOLER1\<^bsub>(I)\<^esub> X"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_54:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 & {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X &  not y inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds I be  non emptyXBOOLE-0V1 implies ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } implies  not x inPBOOLER1\<^bsub>(I)\<^esub> X & (y inPBOOLER1\<^bsub>(I)\<^esub> X implies  False ))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume "I be  non emptyXBOOLE-0V1"
    then obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A1: "i inHIDDENR3 I"
      using xboole_0_def_1 sorry
    assume A2: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
    show " not x inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof-
      have "x inPBOOLER1\<^bsub>(I)\<^esub> X implies  False "
      proof(rule impI)
        assume A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
          using A1 pzfmisc1_def_2 sorry
        also have "... = ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
          using A1 pboole_def_6 sorry
        also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
          using A1 A2 pzfmisc1_def_2 sorry
        finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
           sorry
        then have " not x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using zfmisc_1_th_63 sorry
        thus " False "
          using A1 A3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A4: "y inPBOOLER1\<^bsub>(I)\<^esub> X"
    have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
      using A1 pzfmisc1_def_2 sorry
    also have "... = ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
      using A1 pboole_def_6 sorry
    also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
      using A1 A2 pzfmisc1_def_2 sorry
    finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
       sorry
    then have " not y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      using zfmisc_1_th_63 sorry
    thus " False "
      using A1 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_55:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I iff x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X) & (x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X implies {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies x inPBOOLER1\<^bsub>(I)\<^esub> X & y inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof(rule impI,rule conjMI)
      assume A1: "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      show "x inPBOOLER1\<^bsub>(I)\<^esub> X"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A2: "i inHIDDENR3 I"
          then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
            using pzfmisc1_def_2 sorry
          also have "... = ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
            using A2 pboole_def_6 sorry
          also have "... = {}XBOOLE-0K1"
            using A1 pboole_th_5 sorry
          finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
             sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
            using zfmisc_1_th_64 sorry
        qed "sorry"
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
          using pboole_def_1 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
          using pzfmisc1_def_2 sorry
        also have "... = ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
          using A3 pboole_def_6 sorry
        also have "... = {}XBOOLE-0K1"
          using A1 pboole_th_5 sorry
        finally have "{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
           sorry
        thus "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using zfmisc_1_th_64 sorry
      qed "sorry"
      thus "y inPBOOLER1\<^bsub>(I)\<^esub> X"
        using pboole_def_1 sorry
    qed
    assume A4: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
      and A5: "y inPBOOLER1\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A6: "i inHIDDENR3 I"
      then have A7: "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A4 sorry
      have A8: "y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A5 A6 sorry
      have "({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i \\XBOOLE-0K4 X .FUNCT-1K1 i"
        using A6 pboole_def_6 sorry
      also have "... = {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } \\XBOOLE-0K4 X .FUNCT-1K1 i"
        using A6 pzfmisc1_def_2 sorry
      also have "... = {}XBOOLE-0K1"
        using A7 A8 zfmisc_1_th_64 sorry
      also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_th_5 sorry
      finally show "({PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_56:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ((X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds ((X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "((X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
      proof-
        have cases: "((X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}) or X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
          using A1 sorry
        have case1: "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule impI)
          assume "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
          then have A3: "X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
            using pboole_th_5 sorry
          have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
            using A2 pboole_def_6 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using A3 pboole_th_5 sorry
          finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed
        have case2: "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x} implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule impI)
          assume "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x}"
          then have A4: "X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 x .FUNCT-1K1 i }"
            using A2 pzfmisc1_def_1 sorry
          have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
            using A2 pboole_def_6 sorry
          also have "... = X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
            using A2 pzfmisc1_def_2 sorry
          also have "... = {}XBOOLE-0K1"
            using A4 zfmisc_1_th_66 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed
        have case3: "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y} implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule impI)
          assume "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y}"
          then have A5: "X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK1 y .FUNCT-1K1 i }"
            using A2 pzfmisc1_def_1 sorry
          have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
            using A2 pboole_def_6 sorry
          also have "... = X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
            using A2 pzfmisc1_def_2 sorry
          also have "... = {}XBOOLE-0K1"
            using A5 zfmisc_1_th_66 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed
        have case4: "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule impI)
          assume "X =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }"
          then have A6: "X .FUNCT-1K1 i =XBOOLE-0R4 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
            using A2 pzfmisc1_def_2 sorry
          have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\XBOOLE-0K4 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i"
            using A2 pboole_def_6 sorry
          also have "... = X .FUNCT-1K1 i \\XBOOLE-0K4 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i }"
            using A2 pzfmisc1_def_2 sorry
          also have "... = {}XBOOLE-0K1"
            using A6 zfmisc_1_th_66 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y }).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 case4 sorry
      qed
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem pzfmisc1_th_57:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    show "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    proof-
      have cases: "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
        using A1 sorry
      have case1: "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      proof(rule impI)
        assume A2: "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          have A4: "X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
            using A2 pboole_th_5 sorry
          have "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
            using A3 pboole_def_16 sorry
          also have "... = {}XBOOLE-0K1"
            using A4 zfmisc_1_th_90 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
           sorry
      qed
      have case2: "Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      proof(rule impI)
        assume A5: "Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A6: "i inHIDDENR3 I"
          have A7: "Y .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
            using A5 pboole_th_5 sorry
          have "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
            using A6 pboole_def_16 sorry
          also have "... = {}XBOOLE-0K1"
            using A7 zfmisc_1_th_90 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_58:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X be non-emptyRELAT-1V2 & Y be non-emptyRELAT-1V2) & [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |] implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 & (Y be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X be non-emptyRELAT-1V2"
      and A2: "Y be non-emptyRELAT-1V2"
      and A3: "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      then have A5: "X .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A1 sorry
      have A6: "Y .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A2 A4 sorry
      have "[:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :] =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i"
        using A4 pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 Y .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
        using A3 A4 pboole_def_16 sorry
      finally have "[:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :] =HIDDENR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
         sorry
      thus "X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i"
        using A5 A6 zfmisc_1_th_91 sorry
    qed "sorry"
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_59:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X,X |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Y |] implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X,X |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Y |] implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "[|PBOOLEK6\<^bsub>(I)\<^esub> X,X |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Y |]"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "[:ZFMISC-1K2 X .FUNCT-1K1 i,X .FUNCT-1K1 i :] =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,X |]).FUNCT-1K1 i"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 Y .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using A1 A2 pboole_def_16 sorry
      finally have "[:ZFMISC-1K2 X .FUNCT-1K1 i,X .FUNCT-1K1 i :] =HIDDENR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
         sorry
      thus "X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i"
        using zfmisc_1_th_92 sorry
    qed "sorry"
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_60:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds Z be non-emptyRELAT-1V2 & ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] or [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]) implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds Z be non-emptyRELAT-1V2 & ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] or [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]) implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "Z be non-emptyRELAT-1V2"
      and A2: "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] or [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
    show "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    proof-
      have cases: "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] or [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
        using A2 sorry
      have case1: "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      proof(rule impI)
        assume A3: "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A4: "i inHIDDENR3 I"
          then have A5: "Z .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
            using A1 sorry
          have "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
            using A3 A4 sorry
          then have "[:ZFMISC-1K2 X .FUNCT-1K1 i,Z .FUNCT-1K1 i :] c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
            using A4 pboole_def_16 sorry
          then have "[:ZFMISC-1K2 X .FUNCT-1K1 i,Z .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
            using A4 pboole_def_16 sorry
          thus "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
            using A5 zfmisc_1_th_94 sorry
        qed "sorry"
        thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
          using pboole_def_2 sorry
      qed
      have case2: "[|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |] implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      proof(rule impI)
        assume A6: "[|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A7: "i inHIDDENR3 I"
          then have A8: "Z .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
            using A1 sorry
          have "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
            using A6 A7 sorry
          then have "[:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i :] c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
            using A7 pboole_def_16 sorry
          then have "[:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
            using A7 pboole_def_16 sorry
          thus "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
            using A8 zfmisc_1_th_94 sorry
        qed "sorry"
        thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
          using pboole_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_61:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    show "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        then have "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
          using A1 sorry
        then have "[:ZFMISC-1K2 X .FUNCT-1K1 i,Z .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
          using zfmisc_1_th_95 sorry
        then have "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
          using A2 pboole_def_16 sorry
        thus "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
          using A2 pboole_def_16 sorry
      qed "sorry"
      thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]"
        using pboole_def_2 sorry
    qed
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using A1 sorry
      then have "[:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using zfmisc_1_th_95 sorry
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using A3 pboole_def_16 sorry
      thus "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
        using A3 pboole_def_16 sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_62:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x1 c=PBOOLER2\<^bsub>(I)\<^esub> A & x2 c=PBOOLER2\<^bsub>(I)\<^esub> B implies [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x1 c=PBOOLER2\<^bsub>(I)\<^esub> A & x2 c=PBOOLER2\<^bsub>(I)\<^esub> B implies [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "x1 c=PBOOLER2\<^bsub>(I)\<^esub> A"
      and A2: "x2 c=PBOOLER2\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have A4: "x1 .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using A1 sorry
      have "x2 .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A2 A3 sorry
      then have "[:ZFMISC-1K2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A4 zfmisc_1_th_96 sorry
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |]).FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A3 pboole_def_16 sorry
      thus "([|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
        using A3 pboole_def_16 sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_63:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using A1 pboole_def_4 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i,Z .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using zfmisc_1_th_97 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i \\/XBOOLE-0K2 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 Z .FUNCT-1K1 i,(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i :]"
        using A2 pboole_def_4 sorry
      also have "... = [:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using zfmisc_1_th_97 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i \\/XBOOLE-0K2 [:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using A2 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
        using A2 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
        using A2 pboole_def_4 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_64:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\/)PBOOLEK2\<^bsub>(I)\<^esub> x2,A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B |] =PBOOLER7\<^bsub>(I)\<^esub> (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\/)PBOOLEK2\<^bsub>(I)\<^esub> x2,A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B |] =PBOOLER7\<^bsub>(I)\<^esub> (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\/)PBOOLEK2\<^bsub>(I)\<^esub> x2,A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i =HIDDENR1 ((([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\/)PBOOLEK2\<^bsub>(I)\<^esub> x2,A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 (x1 (\\/)PBOOLEK2\<^bsub>(I)\<^esub> x2).FUNCT-1K1 i,(A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 x1 .FUNCT-1K1 i \\/XBOOLE-0K2 x2 .FUNCT-1K1 i,(A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i :]"
        using A1 pboole_def_4 sorry
      also have "... = [:ZFMISC-1K2 x1 .FUNCT-1K1 i \\/XBOOLE-0K2 x2 .FUNCT-1K1 i,A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i :]"
        using A1 pboole_def_4 sorry
      also have "... = (([:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 x1 .FUNCT-1K1 i,B .FUNCT-1K1 i :])\\/XBOOLE-0K2 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,A .FUNCT-1K1 i :])\\/XBOOLE-0K2 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using zfmisc_1_th_98 sorry
      also have "... = ((([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i \\/XBOOLE-0K2 [:ZFMISC-1K2 x1 .FUNCT-1K1 i,B .FUNCT-1K1 i :])\\/XBOOLE-0K2 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,A .FUNCT-1K1 i :])\\/XBOOLE-0K2 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A1 pboole_def_16 sorry
      also have "... = ((([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |]).FUNCT-1K1 i)\\/XBOOLE-0K2 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,A .FUNCT-1K1 i :])\\/XBOOLE-0K2 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A1 pboole_def_16 sorry
      also have "... = ((([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |]).FUNCT-1K1 i)\\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |]).FUNCT-1K1 i)\\/XBOOLE-0K2 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A1 pboole_def_16 sorry
      also have "... = ((([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |]).FUNCT-1K1 i)\\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |]).FUNCT-1K1 i)\\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
        using A1 pboole_def_16 sorry
      also have "... = (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |]).FUNCT-1K1 i)\\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = ((([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\/)PBOOLEK2\<^bsub>(I)\<^esub> x2,A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i =HIDDENR1 ((([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\/)PBOOLEK2\<^bsub>(I)\<^esub> x2,A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B |] =PBOOLER7\<^bsub>(I)\<^esub> (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,B |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,A |])(\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_65:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]) & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |])"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]) & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 (([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |])).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using A1 pboole_def_5 sorry
      also have "... = ([:ZFMISC-1K2 X .FUNCT-1K1 i,Z .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :])"
        using zfmisc_1_th_99 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :])"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
        using A1 pboole_def_16 sorry
      also have "... = (([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |])).FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 (([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |])).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |])"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 (([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |])).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 Z .FUNCT-1K1 i,(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i :]"
        using A2 pboole_def_5 sorry
      also have "... = ([:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :])"
        using zfmisc_1_th_99 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :])"
        using A2 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
        using A2 pboole_def_16 sorry
      also have "... = (([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |])).FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 (([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |])).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |])"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_66:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2,A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2,A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2,A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i =HIDDENR1 (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2,A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 (x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2).FUNCT-1K1 i,(A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 x1 .FUNCT-1K1 i /\\XBOOLE-0K3 x2 .FUNCT-1K1 i,(A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i :]"
        using A1 pboole_def_5 sorry
      also have "... = [:ZFMISC-1K2 x1 .FUNCT-1K1 i /\\XBOOLE-0K3 x2 .FUNCT-1K1 i,A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i :]"
        using A1 pboole_def_5 sorry
      also have "... = ([:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :])"
        using zfmisc_1_th_100 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :])"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
        using A1 pboole_def_16 sorry
      also have "... = (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2,A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i =HIDDENR1 (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2,A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B |] =PBOOLER7\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_67:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> X & B c=PBOOLER2\<^bsub>(I)\<^esub> Y implies ([|PBOOLEK6\<^bsub>(I)\<^esub> A,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |]) =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> X & B c=PBOOLER2\<^bsub>(I)\<^esub> Y implies ([|PBOOLEK6\<^bsub>(I)\<^esub> A,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |]) =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "A c=PBOOLER2\<^bsub>(I)\<^esub> X"
      and A2: "B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (([|PBOOLEK6\<^bsub>(I)\<^esub> A,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |])).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have A4: "A .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
        using A1 sorry
      have A5: "B .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using A2 A3 sorry
      have "(([|PBOOLEK6\<^bsub>(I)\<^esub> A,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |])).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,Y |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |]).FUNCT-1K1 i"
        using A3 pboole_def_5 sorry
      also have "... = ([:ZFMISC-1K2 A .FUNCT-1K1 i,Y .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |]).FUNCT-1K1 i"
        using A3 pboole_def_16 sorry
      also have "... = ([:ZFMISC-1K2 A .FUNCT-1K1 i,Y .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 X .FUNCT-1K1 i,B .FUNCT-1K1 i :])"
        using A3 pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A4 A5 zfmisc_1_th_101 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
        using A3 pboole_def_16 sorry
      finally show "(([|PBOOLEK6\<^bsub>(I)\<^esub> A,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |])).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "([|PBOOLEK6\<^bsub>(I)\<^esub> A,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> X,B |]) =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_68:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] & [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i \\XBOOLE-0K4 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using A1 pboole_def_6 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i,Z .FUNCT-1K1 i :] \\XBOOLE-0K4 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using zfmisc_1_th_102 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i \\XBOOLE-0K4 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |]).FUNCT-1K1 i \\XBOOLE-0K4 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y,Z |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Z |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 Z .FUNCT-1K1 i,(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i \\XBOOLE-0K4 Y .FUNCT-1K1 i :]"
        using A2 pboole_def_6 sorry
      also have "... = [:ZFMISC-1K2 Z .FUNCT-1K1 i,X .FUNCT-1K1 i :] \\XBOOLE-0K4 [:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using zfmisc_1_th_102 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i \\XBOOLE-0K4 [:ZFMISC-1K2 Z .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using A2 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |]).FUNCT-1K1 i \\XBOOLE-0K4 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
        using A2 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
        using A2 pboole_def_6 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> Z,X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,X |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Z,Y |]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_69:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B |]"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |]).FUNCT-1K1 i \\XBOOLE-0K4 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
        using pboole_def_6 sorry
      also have "... = [:ZFMISC-1K2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i :] \\XBOOLE-0K4 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
        using A1 pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i :] \\XBOOLE-0K4 [:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A1 pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 x1 .FUNCT-1K1 i \\XBOOLE-0K4 A .FUNCT-1K1 i,x2 .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i :]"
        using zfmisc_1_th_103 sorry
      also have "... = [:ZFMISC-1K2 (x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A).FUNCT-1K1 i,x2 .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 x1 .FUNCT-1K1 i,x2 .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i :]"
        using A1 pboole_def_6 sorry
      also have "... = [:ZFMISC-1K2 (x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A).FUNCT-1K1 i,x2 .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 x1 .FUNCT-1K1 i,(x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B).FUNCT-1K1 i :]"
        using A1 pboole_def_6 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |]).FUNCT-1K1 i \\/XBOOLE-0K2 [:ZFMISC-1K2 x1 .FUNCT-1K1 i,(x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B).FUNCT-1K1 i :]"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 |] (\\)PBOOLEK4\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1 (\\)PBOOLEK4\<^bsub>(I)\<^esub> A,x2 |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x1,x2 (\\)PBOOLEK4\<^bsub>(I)\<^esub> B |]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_70:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2 =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2 =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2 =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    show "([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    proof-
      have cases: "x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2 =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I or A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
        using A1 sorry
      have case1: "x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2 =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      proof(rule impI)
        assume A2: "x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2 =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          then have "x1 .FUNCT-1K1 i /\\XBOOLE-0K3 x2 .FUNCT-1K1 i =HIDDENR1 (x1 (/\\)PBOOLEK3\<^bsub>(I)\<^esub> x2).FUNCT-1K1 i"
            using pboole_def_5 sorry
          also have "... = {}XBOOLE-0K1"
            using A2 pboole_th_5 sorry
          finally have "x1 .FUNCT-1K1 i /\\XBOOLE-0K3 x2 .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
             sorry
          then have "x1 .FUNCT-1K1 i missesXBOOLE-0R1 x2 .FUNCT-1K1 i"
            using xboole_0_def_7 sorry
          then have A4: "[:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :] missesXBOOLE-0R1 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
            using zfmisc_1_th_104 sorry
          have "(([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
            using A3 pboole_def_5 sorry
          also have "... = ([:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
            using A3 pboole_def_16 sorry
          also have "... = ([:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :])"
            using A3 pboole_def_16 sorry
          also have "... = {}XBOOLE-0K1"
            using A4 xboole_0_def_7 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "(([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
           sorry
      qed
      have case2: "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      proof(rule impI)
        assume A5: "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A6: "i inHIDDENR3 I"
          then have "A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i =HIDDENR1 (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
            using pboole_def_5 sorry
          also have "... = {}XBOOLE-0K1"
            using A5 pboole_th_5 sorry
          finally have "A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
             sorry
          then have "A .FUNCT-1K1 i missesXBOOLE-0R1 B .FUNCT-1K1 i"
            using xboole_0_def_7 sorry
          then have A7: "[:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :] missesXBOOLE-0R1 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
            using zfmisc_1_th_104 sorry
          have "(([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
            using A6 pboole_def_5 sorry
          also have "... = ([:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]).FUNCT-1K1 i"
            using A6 pboole_def_16 sorry
          also have "... = ([:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :])"
            using A6 pboole_def_16 sorry
          also have "... = {}XBOOLE-0K1"
            using A7 xboole_0_def_7 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "(([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |])).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_71:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 implies [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] be non-emptyRELAT-1V2"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 implies [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] be non-emptyRELAT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "X be non-emptyRELAT-1V2"
    show "[|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] be non-emptyRELAT-1V2"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |]).FUNCT-1K1 i be emptyXBOOLE-0V1"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        then have "X .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
          using A1 sorry
        then have "[:ZFMISC-1K2 {TARSKIK1 x .FUNCT-1K1 i },X .FUNCT-1K1 i :] be  non emptyXBOOLE-0V1"
          using zfmisc_1_th_107 sorry
        then have "[:ZFMISC-1K2 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i,X .FUNCT-1K1 i :] be  non emptyXBOOLE-0V1"
          using A2 pzfmisc1_def_1 sorry
        thus " not ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |]).FUNCT-1K1 i be emptyXBOOLE-0V1"
          using A2 pboole_def_16 sorry
      qed "sorry"
      thus "[|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] be non-emptyRELAT-1V2"
        using pboole_def_13 sorry
    qed
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |]).FUNCT-1K1 i be emptyXBOOLE-0V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A1 sorry
      then have "[:ZFMISC-1K2 X .FUNCT-1K1 i,{TARSKIK1 x .FUNCT-1K1 i } :] be  non emptyXBOOLE-0V1"
        using zfmisc_1_th_107 sorry
      then have "[:ZFMISC-1K2 X .FUNCT-1K1 i,{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i :] be  non emptyXBOOLE-0V1"
        using A3 pzfmisc1_def_1 sorry
      thus " not ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |]).FUNCT-1K1 i be emptyXBOOLE-0V1"
        using A3 pboole_def_16 sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] be non-emptyRELAT-1V2"
      using pboole_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_72:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y },X |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y},X |] & [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> y} |]"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y },X |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y},X |] & [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> y} |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y },X |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y},X |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y },X |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 {PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 {TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i },X .FUNCT-1K1 i :]"
        using A1 pzfmisc1_def_2 sorry
      also have "... = [:ZFMISC-1K2 {TARSKIK1 x .FUNCT-1K1 i },X .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 y .FUNCT-1K1 i },X .FUNCT-1K1 i :]"
        using zfmisc_1_th_109 sorry
      also have "... = [:ZFMISC-1K2 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i,X .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 y .FUNCT-1K1 i },X .FUNCT-1K1 i :]"
        using A1 pzfmisc1_def_1 sorry
      also have "... = [:ZFMISC-1K2 {PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i,X .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
        using A1 pzfmisc1_def_1 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |]).FUNCT-1K1 i \\/XBOOLE-0K2 [:ZFMISC-1K2 {PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y},X |]).FUNCT-1K1 i"
        using A1 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y},X |]).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y },X |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y},X |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> x,y },X |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> x},X |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> y},X |]"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> y} |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } |]).FUNCT-1K1 i =HIDDENR1 [:ZFMISC-1K2 X .FUNCT-1K1 i,{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } .FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i,{TARSKIK2 x .FUNCT-1K1 i,y .FUNCT-1K1 i } :]"
        using A2 pzfmisc1_def_2 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i,{TARSKIK1 x .FUNCT-1K1 i } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X .FUNCT-1K1 i,{TARSKIK1 y .FUNCT-1K1 i } :]"
        using zfmisc_1_th_109 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i,{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X .FUNCT-1K1 i,{TARSKIK1 y .FUNCT-1K1 i } :]"
        using A2 pzfmisc1_def_1 sorry
      also have "... = [:ZFMISC-1K2 X .FUNCT-1K1 i,{PZFMISC1K1\<^bsub>(I)\<^esub> x} .FUNCT-1K1 i :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X .FUNCT-1K1 i,{PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i :]"
        using A2 pzfmisc1_def_1 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |]).FUNCT-1K1 i \\/XBOOLE-0K2 [:ZFMISC-1K2 X .FUNCT-1K1 i,{PZFMISC1K1\<^bsub>(I)\<^esub> y} .FUNCT-1K1 i :]"
        using A2 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |]).FUNCT-1K1 i \\/XBOOLE-0K2 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> y} |]).FUNCT-1K1 i"
        using A2 pboole_def_16 sorry
      also have "... = ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> y} |]).FUNCT-1K1 i"
        using A2 pboole_def_4 sorry
      finally show "([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } |]).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> y} |]).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K2\<^bsub>(I)\<^esub> x,y } |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> x} |] (\\/)PBOOLEK2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,{PZFMISC1K1\<^bsub>(I)\<^esub> y} |]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_73:
" for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds (x1 be non-emptyRELAT-1V2 & A be non-emptyRELAT-1V2) & [|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |] implies x1 =PBOOLER7\<^bsub>(I)\<^esub> x2 & A =PBOOLER7\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for x1 be ManySortedSetPBOOLEM1-of I holds  for x2 be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds x1 be non-emptyRELAT-1V2 & (A be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]) implies x1 =PBOOLER7\<^bsub>(I)\<^esub> x2 & A =PBOOLER7\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ManySortedSetPBOOLEM1-of I"
    fix x2 assume [ty]: "x2 be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "x1 be non-emptyRELAT-1V2"
      and A2: "A be non-emptyRELAT-1V2"
      and A3: "[|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |] =PBOOLER7\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x2,B |]"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x1 .FUNCT-1K1 i =XBOOLE-0R4 x2 .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      then have A5: "x1 .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A1 sorry
      have A6: "A .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A2 A4 sorry
      have "[:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :] =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i"
        using A4 pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A3 A4 pboole_def_16 sorry
      finally have "[:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :] =HIDDENR1 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
         sorry
      thus "x1 .FUNCT-1K1 i =XBOOLE-0R4 x2 .FUNCT-1K1 i"
        using A5 A6 zfmisc_1_th_110 sorry
    qed "sorry"
    thus "x1 =PBOOLER7\<^bsub>(I)\<^esub> x2"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A7: "i inHIDDENR3 I"
      then have A8: "x1 .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A1 sorry
      have A9: "A .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A2 A7 sorry
      have "[:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :] =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> x1,A |]).FUNCT-1K1 i"
        using A7 pboole_def_16 sorry
      also have "... = [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A3 A7 pboole_def_16 sorry
      finally have "[:ZFMISC-1K2 x1 .FUNCT-1K1 i,A .FUNCT-1K1 i :] =HIDDENR1 [:ZFMISC-1K2 x2 .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
         sorry
      thus "A .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
        using A8 A9 zfmisc_1_th_110 sorry
    qed "sorry"
    thus "A =PBOOLER7\<^bsub>(I)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_74:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |] implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |] implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]"
    show "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    proof-
      have cases: "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]"
        using A1 sorry
      have case1: "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      proof(rule impI)
        assume A2: "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i"
            using A2 sorry
          then have "X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
            using A3 pboole_def_16 sorry
          then have "X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
            using zfmisc_1_th_111 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "X .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
           sorry
      qed
      have case2: "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |] implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      proof(rule impI)
        assume A4: "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A5: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]).FUNCT-1K1 i"
            using A4 sorry
          then have "X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
            using A5 pboole_def_16 sorry
          then have "X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
            using zfmisc_1_th_111 sorry
          also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
            using pboole_th_5 sorry
          finally show "X .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_75:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x,y |] & A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] implies A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X,y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x,y |] & A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] implies A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X,y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x,y |]"
      and A2: "A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i inTARSKIR2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X,y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have A4: "A .FUNCT-1K1 i inTARSKIR2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x,y |]).FUNCT-1K1 i"
        using A1 sorry
      have A5: "A .FUNCT-1K1 i inTARSKIR2 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i"
        using A2 A3 sorry
      have A6: "A .FUNCT-1K1 i inTARSKIR2 [:ZFMISC-1K2 x .FUNCT-1K1 i,y .FUNCT-1K1 i :]"
        using A3 A4 pboole_def_16 sorry
      have "A .FUNCT-1K1 i inTARSKIR2 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using A3 A5 pboole_def_16 sorry
      then have "A .FUNCT-1K1 i inTARSKIR2 [:ZFMISC-1K2 x .FUNCT-1K1 i /\\XBOOLE-0K3 X .FUNCT-1K1 i,y .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i :]"
        using A6 zfmisc_1_th_113 sorry
      then have "A .FUNCT-1K1 i inTARSKIR2 [:ZFMISC-1K2 (x (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i,y .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i :]"
        using A3 pboole_def_5 sorry
      then have "A .FUNCT-1K1 i inTARSKIR2 [:ZFMISC-1K2 (x (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i,(y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i :]"
        using A3 pboole_def_5 sorry
      thus "A .FUNCT-1K1 i inTARSKIR2 ([|PBOOLEK6\<^bsub>(I)\<^esub> x (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X,y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i"
        using A3 pboole_def_16 sorry
    qed "sorry"
    thus "A inPBOOLER1\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> x (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X,y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y |]"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_76:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> y,Y |] & [|PBOOLEK6\<^bsub>(I)\<^esub> x,X |] be non-emptyRELAT-1V2 implies x c=PBOOLER2\<^bsub>(I)\<^esub> y & X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> x,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> y,Y |] & [|PBOOLEK6\<^bsub>(I)\<^esub> x,X |] be non-emptyRELAT-1V2 implies x c=PBOOLER2\<^bsub>(I)\<^esub> y & X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "[|PBOOLEK6\<^bsub>(I)\<^esub> x,X |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> y,Y |]"
      and A2: "[|PBOOLEK6\<^bsub>(I)\<^esub> x,X |] be non-emptyRELAT-1V2"
    show "x c=PBOOLER2\<^bsub>(I)\<^esub> y"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i c=TARSKIR1 y .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have "([|PBOOLEK6\<^bsub>(I)\<^esub> x,X |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> y,Y |]).FUNCT-1K1 i"
          using A1 sorry
        then have "[:ZFMISC-1K2 x .FUNCT-1K1 i,X .FUNCT-1K1 i :] c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> y,Y |]).FUNCT-1K1 i"
          using A3 pboole_def_16 sorry
        then have A4: "[:ZFMISC-1K2 x .FUNCT-1K1 i,X .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 y .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
          using A3 pboole_def_16 sorry
        have "([|PBOOLEK6\<^bsub>(I)\<^esub> x,X |]).FUNCT-1K1 i be  non emptyXBOOLE-0V1"
          using A2 A3 sorry
        then have "[:ZFMISC-1K2 x .FUNCT-1K1 i,X .FUNCT-1K1 i :] be  non emptyXBOOLE-0V1"
          using A3 pboole_def_16 sorry
        thus "x .FUNCT-1K1 i c=TARSKIR1 y .FUNCT-1K1 i"
          using A4 zfmisc_1_th_114 sorry
      qed "sorry"
      thus "x c=PBOOLER2\<^bsub>(I)\<^esub> y"
        using pboole_def_2 sorry
    qed
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A5: "i inHIDDENR3 I"
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> x,X |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> y,Y |]).FUNCT-1K1 i"
        using A1 sorry
      then have "[:ZFMISC-1K2 x .FUNCT-1K1 i,X .FUNCT-1K1 i :] c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> y,Y |]).FUNCT-1K1 i"
        using A5 pboole_def_16 sorry
      then have A6: "[:ZFMISC-1K2 x .FUNCT-1K1 i,X .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 y .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using A5 pboole_def_16 sorry
      have "([|PBOOLEK6\<^bsub>(I)\<^esub> x,X |]).FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A2 A5 sorry
      then have "[:ZFMISC-1K2 x .FUNCT-1K1 i,X .FUNCT-1K1 i :] be  non emptyXBOOLE-0V1"
        using A5 pboole_def_16 sorry
      thus "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using A6 zfmisc_1_th_114 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_77:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> X implies [|PBOOLEK6\<^bsub>(I)\<^esub> A,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,X |]"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> X implies [|PBOOLEK6\<^bsub>(I)\<^esub> A,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,X |]"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "A c=PBOOLER2\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> A,A |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,X |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "A .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
        using A1 sorry
      then have "[:ZFMISC-1K2 A .FUNCT-1K1 i,A .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 X .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
        using zfmisc_1_th_96 sorry
      then have "([|PBOOLEK6\<^bsub>(I)\<^esub> A,A |]).FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 X .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
        using A2 pboole_def_16 sorry
      thus "([|PBOOLEK6\<^bsub>(I)\<^esub> A,A |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,X |]).FUNCT-1K1 i"
        using A2 pboole_def_16 sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> A,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,X |]"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_78:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |])).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
        using pboole_def_5 sorry
      also have "... = {}XBOOLE-0K1"
        using A1 pboole_th_5 sorry
      finally have "X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
         sorry
      then have "X .FUNCT-1K1 i missesXBOOLE-0R1 Y .FUNCT-1K1 i"
        using xboole_0_def_7 sorry
      then have A3: "[:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :] missesXBOOLE-0R1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
        using zfmisc_1_th_104 sorry
      have "(([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |])).FUNCT-1K1 i =HIDDENR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i /\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]).FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      also have "... = ([:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]).FUNCT-1K1 i"
        using A2 pboole_def_16 sorry
      also have "... = ([:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Y .FUNCT-1K1 i,X .FUNCT-1K1 i :])"
        using A2 pboole_def_16 sorry
      also have "... = {}XBOOLE-0K1"
        using A3 xboole_0_def_7 sorry
      also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_th_5 sorry
      finally show "(([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |])).FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |])(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_79:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A be non-emptyRELAT-1V2 & ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or [|PBOOLEK6\<^bsub>(I)\<^esub> B,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]) implies B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds A be non-emptyRELAT-1V2 & ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or [|PBOOLEK6\<^bsub>(I)\<^esub> B,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]) implies B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "A be non-emptyRELAT-1V2"
      and A2: "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or [|PBOOLEK6\<^bsub>(I)\<^esub> B,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]"
    show "B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    proof-
      have cases: "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] or [|PBOOLEK6\<^bsub>(I)\<^esub> B,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]"
        using A2 sorry
      have case1: "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] implies B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      proof(rule impI)
        assume A3: "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies B .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A4: "i inHIDDENR3 I"
          then have "([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i"
            using A3 sorry
          then have "[:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :] c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i"
            using A4 pboole_def_16 sorry
          then have A5: "[:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
            using A4 pboole_def_16 sorry
          have "A .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
            using A1 A4 sorry
          thus "B .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
            using A5 zfmisc_1_th_115 sorry
        qed "sorry"
        thus "B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
          using pboole_def_2 sorry
      qed
      have case2: "[|PBOOLEK6\<^bsub>(I)\<^esub> B,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |] implies B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      proof(rule impI)
        assume A6: "[|PBOOLEK6\<^bsub>(I)\<^esub> B,A |] c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies B .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A7: "i inHIDDENR3 I"
          then have "([|PBOOLEK6\<^bsub>(I)\<^esub> B,A |]).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]).FUNCT-1K1 i"
            using A6 sorry
          then have "[:ZFMISC-1K2 B .FUNCT-1K1 i,A .FUNCT-1K1 i :] c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,X |]).FUNCT-1K1 i"
            using A7 pboole_def_16 sorry
          then have A8: "[:ZFMISC-1K2 B .FUNCT-1K1 i,A .FUNCT-1K1 i :] c=TARSKIR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,X .FUNCT-1K1 i :]"
            using A7 pboole_def_16 sorry
          have "A .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
            using A1 A7 sorry
          thus "B .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
            using A8 zfmisc_1_th_115 sorry
        qed "sorry"
        thus "B c=PBOOLER2\<^bsub>(I)\<^esub> Y"
          using pboole_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pzfmisc1_th_80:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] & y c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] implies x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X,B (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for y be ManySortedSetPBOOLEM1-of I holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] & y c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] implies x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X,B (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix y assume [ty]: "y be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "x c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
      and A2: "y c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X,B (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have A4: "x .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
        using A1 sorry
      have A5: "y .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i"
        using A2 A3 sorry
      have A6: "x .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
        using A3 A4 pboole_def_16 sorry
      have "y .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using A3 A5 pboole_def_16 sorry
      then have "x .FUNCT-1K1 i \\/XBOOLE-0K2 y .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i,B .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i :]"
        using A6 zfmisc_1_th_119 sorry
      then have "(x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y).FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i,B .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i :]"
        using A3 pboole_def_4 sorry
      then have "(x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y).FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X).FUNCT-1K1 i,B .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i :]"
        using A3 pboole_def_4 sorry
      then have "(x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y).FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X).FUNCT-1K1 i,(B (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i :]"
        using A3 pboole_def_4 sorry
      thus "(x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y).FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X,B (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]).FUNCT-1K1 i"
        using A3 pboole_def_16 sorry
    qed "sorry"
    thus "x (\\/)PBOOLEK2\<^bsub>(I)\<^esub> y c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X,B (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y |]"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef pzfmisc1_def_3 (" _ is-transformable-toPZFMISC1R1\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"pred A is-transformable-toPZFMISC1R1\<^bsub>(I)\<^esub> B means
   for i be setHIDDENM2 holds i inTARSKIR2 I implies (B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1 implies A .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1)"..

mtheorem PZFMISC1R1_reflexivity:
  mlet "I be setHIDDENM2"
" for B be ManySortedSetPBOOLEM1-of I holds B is-transformable-toPZFMISC1R1\<^bsub>(I)\<^esub> B"
proof-
  have " for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies (B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1 implies B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1)"
     sorry
  thus " ?thesis "
    using pzfmisc1_def_3 sorry
qed

end
