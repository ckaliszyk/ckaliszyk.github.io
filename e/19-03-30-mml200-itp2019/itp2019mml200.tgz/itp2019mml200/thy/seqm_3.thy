theory seqm_3
  imports finseq_3 seq_1 rfunct_1 recdef_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m, k for "NatNAT-1M1"
reserve r, r1 for "RealXREAL-0M1"
reserve f, seq, seq1 for "Real-SequenceSEQ-1M1"
mlemma seqm_3_lm_1:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies ( ex k be NatNAT-1M1 st m =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies ( ex tVar1 be NatNAT-1M1 st m =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 tVar1)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "n <XXREAL-0R3 m"
    then obtain k1 where
      [ty]:"k1 be NatNAT-1M1" and 
      A2: "m =COMPLEX1R1 n +XCMPLX-0K2 k1"
      using nat_1_th_10 sorry
    have "k1 <>HIDDENR2 0NUMBERSK6"
      using A1 A2 sorry
    then obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A3: "k1 =COMPLEX1R1 n1 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have 
      [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    show " ex tVar1 be NatNAT-1M1 st m =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 tVar1"
    proof(rule bexI[of _ "n1"])
      show "m =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 n1"
        using A2 A3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seqm_3_lm_2:
" for seq be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k))) & (( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m))) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k))) & ((( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) implies ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))))"
  proof(rule ballI,rule conjMI,rule conjMI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k))"
    proof(rule impI,rule ballI)
      assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      fix n assume [ty]: "n be NatNAT-1M1"
      let ?X = "\<lambda>Lamb1. seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 Lamb1)"
      have A2: " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?X(k)"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
      have A4: "?X(0NUMBERSK6)"
        using A1 sorry
      show " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
        using nat_1_sch_2 A4 A2 sorry
    qed "sorry"
    show "( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
    proof-
      have "( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
      proof(rule impI,rule ballI,rule ballI,rule impI)
        assume A5: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
        fix n assume [ty]: "n be NatNAT-1M1"
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <XXREAL-0R3 m"
        then have " ex k be NatNAT-1M1 st m =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k"
          using seqm_3_lm_1 sorry
        thus " not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
          using A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A6: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    thus " not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seqm_3_lm_3:
" for seq be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ((( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)))"
  proof(rule ballI,rule conjMI,rule conjMI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof(rule impI,rule ballI)
      assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      fix n assume [ty]: "n be NatNAT-1M1"
      let ?X = "\<lambda>Lamb1. seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 Lamb1) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      have A2: " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?X(k)"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
          using A1 sorry
        thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
      have A4: "?X(0NUMBERSK6)"
        using A1 sorry
      show " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using nat_1_sch_2 A4 A2 sorry
    qed "sorry"
    show "( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      have "( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof(rule impI,rule ballI,rule ballI,rule impI)
        assume A5: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        fix n assume [ty]: "n be NatNAT-1M1"
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <XXREAL-0R3 m"
        then have " ex k be NatNAT-1M1 st m =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k"
          using seqm_3_lm_1 sorry
        thus " not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A6: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    thus " not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seqm_3_lm_4:
" for seq be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k))) & (( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m))) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k))) & ((( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))))"
  proof(rule ballI,rule conjMI,rule conjMI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k))"
    proof(rule impI,rule ballI)
      assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      fix n assume [ty]: "n be NatNAT-1M1"
      let ?X = "\<lambda>Lamb1. seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 Lamb1)"
      have A2: " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?X(k)"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
      have A4: "?X(0NUMBERSK6)"
         sorry
      show " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_sch_2 A4 A2 sorry
    qed "sorry"
    show "( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
    proof(rule impI,rule ballI,rule ballI,rule impI)
      assume A5: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n <=XXREAL-0R1 m"
      then obtain k1 where
        [ty]:"k1 be NatNAT-1M1" and 
        A6: "m =COMPLEX1R1 n +XCMPLX-0K2 k1"
        using nat_1_th_10 sorry
      show "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
        using A5 A6 sorry
    qed "sorry"
    assume A7: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      using A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seqm_3_lm_5:
" for seq be Real-SequenceSEQ-1M1 holds ((( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ((( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)))"
  proof(rule ballI,rule conjMI,rule conjMI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof(rule impI,rule ballI)
      assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      fix n assume [ty]: "n be NatNAT-1M1"
      let ?X = "\<lambda>Lamb1. seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 Lamb1) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      have A2: " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?X(k)"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
          using A1 sorry
        thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
      have A4: "?X(0NUMBERSK6)"
         sorry
      show " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using nat_1_sch_2 A4 A2 sorry
    qed "sorry"
    show "( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof(rule impI,rule ballI,rule ballI,rule impI)
      assume A5: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n <=XXREAL-0R1 m"
      then obtain k1 where
        [ty]:"k1 be NatNAT-1M1" and 
        A6: "m =COMPLEX1R1 n +XCMPLX-0K2 k1"
        using nat_1_th_10 sorry
      show "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A5 A6 sorry
    qed "sorry"
    assume A7: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) SEQM_3V1("increasingSEQM-3V1" 70) where
  "increasingSEQM-3V1 \<equiv> increasingVALUED-0V9"

mtheorem seqm_3_def_1:
  mlet "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr increasingSEQM-3V1 for NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m <XXREAL-0R3 f .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be increasingSEQM-3V1 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m <XXREAL-0R3 f .FUNCT-1K1 n)"
  proof(rule ballI)
    fix f assume [ty]: "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f be increasingSEQM-3V1 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m <XXREAL-0R3 f .FUNCT-1K1 n)"
       sorry
  qed "sorry"
qed "sorry"

abbreviation(input) SEQM_3V2("decreasingSEQM-3V2" 70) where
  "decreasingSEQM-3V2 \<equiv> decreasingVALUED-0V10"

mtheorem seqm_3_def_2:
  mlet "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr decreasingSEQM-3V2 for NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m >XXREAL-0R4 f .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be decreasingSEQM-3V2 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m >XXREAL-0R4 f .FUNCT-1K1 n)"
  proof(rule ballI)
    fix f assume [ty]: "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f be decreasingSEQM-3V2 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <XXREAL-0R3 n implies f .FUNCT-1K1 m >XXREAL-0R4 f .FUNCT-1K1 n)"
       sorry
  qed "sorry"
qed "sorry"

abbreviation(input) SEQM_3V3("non-decreasingSEQM-3V3" 70) where
  "non-decreasingSEQM-3V3 \<equiv> non-decreasingVALUED-0V11"

mtheorem seqm_3_def_3:
  mlet "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr non-decreasingSEQM-3V3 for NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m <=XXREAL-0R1 f .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be non-decreasingSEQM-3V3 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m <=XXREAL-0R1 f .FUNCT-1K1 n)"
  proof(rule ballI)
    fix f assume [ty]: "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f be non-decreasingSEQM-3V3 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m <=XXREAL-0R1 f .FUNCT-1K1 n)"
       sorry
  qed "sorry"
qed "sorry"

abbreviation(input) SEQM_3V4("non-increasingSEQM-3V4" 70) where
  "non-increasingSEQM-3V4 \<equiv> non-increasingVALUED-0V12"

mtheorem seqm_3_def_4:
  mlet "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr non-increasingSEQM-3V4 for NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m >=XXREAL-0R2 f .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be non-increasingSEQM-3V4 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m >=XXREAL-0R2 f .FUNCT-1K1 n)"
  proof(rule ballI)
    fix f assume [ty]: "f be NATNUMBERSK1 -definedRELAT-1V4\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f be non-increasingSEQM-3V4 iff ( for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m inTARSKIR2 domRELAT-1K1 f & n inTARSKIR2 domRELAT-1K1 f) & m <=XXREAL-0R1 n implies f .FUNCT-1K1 m >=XXREAL-0R2 f .FUNCT-1K1 n)"
       sorry
  qed "sorry"
qed "sorry"

mdef seqm_3_def_5 ("monotoneSEQM-3V5" 70 ) where
"attr monotoneSEQM-3V5 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq. seq be non-decreasingSEQM-3V3 or seq be non-increasingSEQM-3V4)"..

mtheorem seqm_3_th_1:
" for seq be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V1 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be increasingSEQM-3V1 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) implies seq be increasingSEQM-3V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be increasingSEQM-3V1 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
    proof-
      have "seq be increasingSEQM-3V1 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 m & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m))"
      proof(rule impI)
        assume "seq be increasingSEQM-3V1"
        then have " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        then have " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
          using seqm_3_lm_2 sorry
        thus " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 m & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
          using seqm_3_lm_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A1: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domRELAT-1K1 seq & (m inTARSKIR2 domRELAT-1K1 seq & n <XXREAL-0R3 m) implies  not seq .FUNCT-1K1 n <XXREAL-0R3 seq .FUNCT-1K1 m"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n inTARSKIR2 domRELAT-1K1 seq"
        and "m inTARSKIR2 domRELAT-1K1 seq"
        and A2: "n <XXREAL-0R3 m"
      show " not seq .FUNCT-1K1 n <XXREAL-0R3 seq .FUNCT-1K1 m"
        using A1 A2 sorry
    qed "sorry"
    thus "seq be increasingSEQM-3V1"
      using seqm_3_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_2:
" for seq be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V1 iff ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k))"
  using seqm_3_lm_2 sorry

mtheorem seqm_3_th_3:
" for seq be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V2 iff ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seqm_3_lm_3 sorry

mtheorem seqm_3_th_4:
" for seq be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V2 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be decreasingSEQM-3V2 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq be decreasingSEQM-3V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be decreasingSEQM-3V2 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      have "seq be decreasingSEQM-3V2 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 m & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
      proof(rule impI)
        assume "seq be decreasingSEQM-3V2"
        then have " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seqm_3_th_3 sorry
        thus " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 m & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using seqm_3_lm_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A1: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domRELAT-1K1 seq & (m inTARSKIR2 domRELAT-1K1 seq & n <XXREAL-0R3 m) implies  not seq .FUNCT-1K1 n >XXREAL-0R4 seq .FUNCT-1K1 m"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n inTARSKIR2 domRELAT-1K1 seq"
        and "m inTARSKIR2 domRELAT-1K1 seq"
        and A2: "n <XXREAL-0R3 m"
      show " not seq .FUNCT-1K1 n >XXREAL-0R4 seq .FUNCT-1K1 m"
        using A1 A2 sorry
    qed "sorry"
    thus "seq be decreasingSEQM-3V2"
      using seqm_3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_5:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V3 iff ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k))"
  using seqm_3_lm_4 sorry

mtheorem seqm_3_th_6:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V3 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be non-decreasingSEQM-3V3 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) implies seq be non-decreasingSEQM-3V3)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be non-decreasingSEQM-3V3 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
    proof-
      have "seq be non-decreasingSEQM-3V3 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m))"
      proof(rule impI)
        assume "seq be non-decreasingSEQM-3V3"
        then have " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
          using seqm_3_th_5 sorry
        thus " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
          using seqm_3_lm_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A1: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domRELAT-1K1 seq & (m inTARSKIR2 domRELAT-1K1 seq & n <=XXREAL-0R1 m) implies seq .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-1K1 m"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n inTARSKIR2 domRELAT-1K1 seq"
        and "m inTARSKIR2 domRELAT-1K1 seq"
        and A2: "n <=XXREAL-0R1 m"
      show "seq .FUNCT-1K1 n <=XXREAL-0R1 seq .FUNCT-1K1 m"
        using A1 A2 sorry
    qed "sorry"
    thus "seq be non-decreasingSEQM-3V3"
      using seqm_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_7:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V4 iff ( for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seqm_3_lm_5 sorry

mtheorem seqm_3_th_8:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V4 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be non-increasingSEQM-3V4 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq be non-increasingSEQM-3V4)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be non-increasingSEQM-3V4 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      have "seq be non-increasingSEQM-3V4 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
      proof(rule impI)
        assume "seq be non-increasingSEQM-3V4"
        then have " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seqm_3_th_7 sorry
        thus " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using seqm_3_lm_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A1: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domRELAT-1K1 seq & (m inTARSKIR2 domRELAT-1K1 seq & n <=XXREAL-0R1 m) implies seq .FUNCT-1K1 n >=XXREAL-0R2 seq .FUNCT-1K1 m"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n inTARSKIR2 domRELAT-1K1 seq"
        and "m inTARSKIR2 domRELAT-1K1 seq"
        and A2: "n <=XXREAL-0R1 m"
      show "seq .FUNCT-1K1 n >=XXREAL-0R2 seq .FUNCT-1K1 m"
        using A1 A2 sorry
    qed "sorry"
    thus "seq be non-increasingSEQM-3V4"
      using seqm_3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_9:
" for seq be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V1 implies ( for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seqm_3_th_1 sorry

mtheorem seqm_3_th_10:
" for seq be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V2 implies ( for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6))"
  using seqm_3_th_4 sorry

mtheorem seqm_3_th_11:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V3 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seqm_3_th_6 sorry

mtheorem seqm_3_th_12:
" for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V4 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6))"
  using seqm_3_th_8 sorry

mtheorem seqm_3_cl_1:
"cluster constantFUNCT-1V5 also-is non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4 for PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) holds it be constantFUNCT-1V5 implies it be non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4"
     sorry
qed "sorry"

mtheorem seqm_3_cl_2:
"cluster non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4 also-is constantFUNCT-1V5 for PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) holds it be non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4 implies it be constantFUNCT-1V5"
  proof-
    have " for f be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2) holds f be non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4 implies f be constantFUNCT-1V5"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(NATNUMBERSK1,REALNUMBERSK2)"
      assume A1: "f be non-decreasingSEQM-3V3\<bar>non-increasingSEQM-3V4"
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
        have "domRELAT-1K1 f c=TARSKIR1 NATNUMBERSK1"
          using relat_1_def_18 sorry
        then obtain m n where 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = x" and
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = y"
          using A2 sorry
        have "m <=XXREAL-0R1 n or n <=XXREAL-0R1 m"
           sorry
        then have "f .FUNCT-1K1 m <=XXREAL-0R1 f .FUNCT-1K1 n & f .FUNCT-1K1 n <=XXREAL-0R1 f .FUNCT-1K1 m"
          using A1 A2 sorry
        thus "f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y"
          using xxreal_0_th_1 sorry
      qed "sorry"
      thus "f be constantFUNCT-1V5"
        using funct_1_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma seqm_3_lm_6:
"idPARTFUN1K6 NATNUMBERSK1 be increasingSEQM-3V1\<bar>natural-valuedVALUED-0V8"
   sorry

mtheorem seqm_3_cl_3:
"cluster increasingSEQM-3V1\<bar>natural-valuedVALUED-0V8 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be increasingSEQM-3V1\<bar>natural-valuedVALUED-0V8"
  proof-
    have " ex tVar2 be Real-SequenceSEQ-1M1 st tVar2 be increasingSEQM-3V1 & tVar2 be natural-valuedVALUED-0V8"
    proof-
      obtain i where 
        [ty]:"i be Real-SequenceSEQ-1M1" and iDef:"i = idPARTFUN1K6 NATNUMBERSK1"
        using funct_2_th_7 numbers_th_19 sorry
      show " ex tVar2 be Real-SequenceSEQ-1M1 st tVar2 be increasingSEQM-3V1 & tVar2 be natural-valuedVALUED-0V8"
      proof(rule bexI[of _ "i"])
        show "i be increasingSEQM-3V1 & i be natural-valuedVALUED-0V8"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seqm_3_cl_4:
"cluster increasingSEQM-3V1 for sequenceNAT-1M2-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be sequenceNAT-1M2-of NATNUMBERSK1 st it be increasingSEQM-3V1"
    using seqm_3_lm_6 sorry
qed "sorry"

mlemma seqm_3_lm_7:
" for f be sequenceNAT-1M2-of NATNUMBERSK1 holds f be increasingSEQM-3V1 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
   sorry

reserve Nseq for "increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
mtheorem seqm_3_th_13:
" for seq be Real-SequenceSEQ-1M1 holds seq be sequenceNAT-1M2-of NATNUMBERSK1 iff ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be sequenceNAT-1M2-of NATNUMBERSK1 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1)) & (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1) implies seq be sequenceNAT-1M2-of NATNUMBERSK1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be sequenceNAT-1M2-of NATNUMBERSK1 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1)"
      using ordinal1_def_12 sorry
    assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "rngFUNCT-1K2 seq c=TARSKIR1 NATNUMBERSK1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 seq implies x inHIDDENR3 NATNUMBERSK1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 seq"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A2: "y inHIDDENR3 domRELAT-1K1 seq"and A3: "x =HIDDENR1 seq .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A2 funct_2_def_1 sorry
        have "x =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> y"
          using A3 sorry
        then have "x be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A1 sorry
        thus "x inHIDDENR3 NATNUMBERSK1"
           sorry
      qed "sorry"
      thus "rngFUNCT-1K2 seq c=TARSKIR1 NATNUMBERSK1"
        using tarski_def_3 sorry
    qed
    thus "seq be sequenceNAT-1M2-of NATNUMBERSK1"
      using funct_2_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_cl_5:
  mlet "Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1", "k be NatNAT-1M1"
"cluster Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k as-term-is increasingVALUED-0V9\<bar>natural-valuedVALUED-0V8 for ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k implies it be increasingVALUED-0V9\<bar>natural-valuedVALUED-0V8"
  proof-
    have " for VarFor1 be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k &  not (VarFor1 be increasingVALUED-0V9 & VarFor1 be natural-valuedVALUED-0V4))"
    proof-
      have " for n be NatNAT-1M1 holds (Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k).NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <XXREAL-0R3 (Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k).NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +XCMPLX-0K2 k) <XXREAL-0R3 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)"
          using seqm_3_lm_7 sorry
        then have "(Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k).NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <XXREAL-0R3 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
          using nat_1_def_3 sorry
        thus "(Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k).NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <XXREAL-0R3 (Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k).NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using nat_1_def_3 sorry
      qed "sorry"
      thus " for VarFor1 be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 Nseq ^\\VALUED-0K1\<^bsub>(NATNUMBERSK1)\<^esub> k &  not (VarFor1 be increasingVALUED-0V9 & VarFor1 be natural-valuedVALUED-0V4))"
        using seqm_3_lm_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) SEQM_3V6("increasingSEQM-3V6" 70) where
  "increasingSEQM-3V6 \<equiv> increasingVALUED-0V9"

mtheorem seqm_3_def_6:
  mlet "f be Real-SequenceSEQ-1M1"
"redefine attr increasingSEQM-3V6 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for f be Real-SequenceSEQ-1M1 holds f be increasingSEQM-3V6 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix f assume [ty]: "f be Real-SequenceSEQ-1M1"
    show "f be increasingSEQM-3V6 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
qed "sorry"

abbreviation(input) SEQM_3V7("decreasingSEQM-3V7" 70) where
  "decreasingSEQM-3V7 \<equiv> decreasingVALUED-0V10"

mtheorem seqm_3_def_7:
  mlet "f be Real-SequenceSEQ-1M1"
"redefine attr decreasingSEQM-3V7 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for f be Real-SequenceSEQ-1M1 holds f be decreasingSEQM-3V7 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix f assume [ty]: "f be Real-SequenceSEQ-1M1"
    show "f be decreasingSEQM-3V7 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
qed "sorry"

abbreviation(input) SEQM_3V8("non-decreasingSEQM-3V8" 70) where
  "non-decreasingSEQM-3V8 \<equiv> non-decreasingVALUED-0V11"

mtheorem seqm_3_def_8:
  mlet "f be Real-SequenceSEQ-1M1"
"redefine attr non-decreasingSEQM-3V8 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for f be Real-SequenceSEQ-1M1 holds f be non-decreasingSEQM-3V8 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix f assume [ty]: "f be Real-SequenceSEQ-1M1"
    show "f be non-decreasingSEQM-3V8 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
qed "sorry"

abbreviation(input) SEQM_3V9("non-increasingSEQM-3V9" 70) where
  "non-increasingSEQM-3V9 \<equiv> non-increasingVALUED-0V12"

mtheorem seqm_3_def_9:
  mlet "f be Real-SequenceSEQ-1M1"
"redefine attr non-increasingSEQM-3V9 for Real-SequenceSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for f be Real-SequenceSEQ-1M1 holds f be non-increasingSEQM-3V9 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix f assume [ty]: "f be Real-SequenceSEQ-1M1"
    show "f be non-increasingSEQM-3V9 iff ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
qed "sorry"

mtheorem seqm_3_th_14:
" for Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n"
proof-
  have " for Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds k <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k"
  proof(rule ballI)
    fix Nseq assume [ty]: "Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    let ?X = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1"
    have A1: " for k be NatNAT-1M1 holds k <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k implies k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A2: "?X(k)"
      have "Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k <XXREAL-0R3 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using seqm_3_lm_7 sorry
      then have "k <XXREAL-0R3 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using A2 xxreal_0_th_2 sorry
      thus "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using nat_1_th_13 sorry
    qed "sorry"
    have A3: "?X(0NUMBERSK6)"
       sorry
    show " for k be NatNAT-1M1 holds k <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> k"
      using nat_1_sch_2 A3 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_cl_6:
  mlet "s be Real-SequenceSEQ-1M1", "k be NatNAT-1M1"
"cluster s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem seqm_3_th_15:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using seq_1_th_7 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "((seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_16:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = -REAL-1K1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using seq_1_th_10 sorry
      also have "... = -REAL-1K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using nat_1_def_3 sorry
      also have "... = (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_10 sorry
      finally show "((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_17:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    have "(seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      using seqm_3_th_15 sorry
    also have "... = seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      using seqm_3_th_16 sorry
    finally show "(seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_18:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k))\<inverse>REAL-1K2"
        using valued_1_th_10 sorry
      also have "... = ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "(seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_19:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) *REAL-1K4 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using seq_1_th_8 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using nat_1_def_3 sorry
      also have "... = ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "((seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_20:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    have "(seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
      using seqm_3_th_19 sorry
    also have "... = (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
      using seqm_3_th_18 sorry
    finally show "(seq /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_21:
" for k be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
proof-
  have " for k be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using seq_1_th_9 sorry
      also have "... = r *XCMPLX-0K3 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using nat_1_def_3 sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      finally show "((r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_22:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V6 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be increasingSEQM-3V6"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be increasingSEQM-3V6 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be increasingSEQM-3V6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be increasingSEQM-3V6"
      and A2: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
    have " for n be NatNAT-1M1 holds  not seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain Nseq where
        [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
        A3: "seq1 =FUNCT-1R1 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
        using A2 valued_0_def_17 sorry
      have A4: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <XXREAL-0R3 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seqm_3_lm_7 sorry
      then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        using A1 seqm_3_th_1 sorry
      then have "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        using funct_2_th_15 A4 sorry
      thus " not seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A3 funct_2_th_15 sorry
    qed "sorry"
    thus "seq1 be increasingSEQM-3V6"
      using seqm_3_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_23:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V7 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be decreasingSEQM-3V7"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be decreasingSEQM-3V7 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be decreasingSEQM-3V7"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be decreasingSEQM-3V7"
      and A2: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
    have " for n be NatNAT-1M1 holds  not seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain Nseq where
        [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
        A3: "seq1 =FUNCT-1R1 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
        using A2 valued_0_def_17 sorry
      have A4: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <XXREAL-0R3 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seqm_3_lm_7 sorry
      then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
        using A1 seqm_3_th_4 sorry
      then have "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
        using funct_2_th_15 sorry
      thus " not seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A3 funct_2_th_15 A4 sorry
    qed "sorry"
    thus "seq1 be decreasingSEQM-3V7"
      using seqm_3_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_24:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V8 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be non-decreasingSEQM-3V8"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V8 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be non-decreasingSEQM-3V8"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-decreasingSEQM-3V8"
      and A2: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
    have " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain Nseq where
        [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
        A3: "seq1 =FUNCT-1R1 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
        using A2 valued_0_def_17 sorry
      have A4: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seqm_3_lm_7 sorry
      then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        using A1 seqm_3_th_6 sorry
      then have "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        using funct_2_th_15 A4 sorry
      thus "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A3 funct_2_th_15 sorry
    qed "sorry"
    thus "seq1 be non-decreasingSEQM-3V8"
      using seqm_3_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_25:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V9 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be non-increasingSEQM-3V9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V9 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be non-increasingSEQM-3V9"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be non-increasingSEQM-3V9"
      and A2: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
    have " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain Nseq where
        [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
        A3: "seq1 =FUNCT-1R1 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
        using A2 valued_0_def_17 sorry
      have A4: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n <=XXREAL-0R1 Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seqm_3_lm_7 sorry
      then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
        using A1 seqm_3_th_8 sorry
      then have "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
        using funct_2_th_15 sorry
      thus "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A3 funct_2_th_15 A4 sorry
    qed "sorry"
    thus "seq1 be non-increasingSEQM-3V9"
      using seqm_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_26:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be monotoneSEQM-3V5 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be monotoneSEQM-3V5"
  using seqm_3_th_25 seqm_3_th_24 sorry

mtheorem seqm_3_th_27:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be bounded-aboveSEQ-2V3"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be bounded-aboveSEQ-2V3"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be bounded-aboveSEQ-2V3"
      and A2: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r1"
      using A1 sorry
    obtain Nseq where
      [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A4: "seq1 =FUNCT-1R1 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
      using A2 valued_0_def_17 sorry
    obtain r where 
      [ty]:"r be RealXREAL-0M1" and rDef:"r = r1"
       sorry
    have " ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
    proof(rule bexI[of _ "r"],rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
        using A4 funct_2_th_15 sorry
      thus "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
        using A3 sorry
    qed "sorry"
    thus "seq1 be bounded-aboveSEQ-2V3"
      using seq_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_28:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be bounded-belowSEQ-2V4"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be bounded-belowSEQ-2V4"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be bounded-belowSEQ-2V4"
      and A2: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for n be NatNAT-1M1 holds r1 <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A1 sorry
    obtain Nseq where
      [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A4: "seq1 =FUNCT-1R1 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
      using A2 valued_0_def_17 sorry
    obtain r where 
      [ty]:"r be RealXREAL-0M1" and rDef:"r = r1"
       sorry
    have " ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule bexI[of _ "r"],rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
        using A4 funct_2_th_15 sorry
      thus "r <XXREAL-0R3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 sorry
    qed "sorry"
    thus "seq1 be bounded-belowSEQ-2V4"
      using seq_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_29:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be boundedSEQ-2V6 & seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq implies seq1 be boundedSEQ-2V6"
  using seqm_3_th_27 seqm_3_th_28 sorry

mtheorem seqm_3_th_30:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ((seq be increasingSEQM-3V6 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6) & (0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15)) & (seq be increasingSEQM-3V6 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7)"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be increasingSEQM-3V6 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6) & ((0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15) & (seq be increasingSEQM-3V6 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be increasingSEQM-3V6 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6"
    proof(rule impMI ,rule impI)
      assume A1: "seq be increasingSEQM-3V6"
        and A2: "0NUMBERSK6 <XXREAL-0R3 r"
      have " for n be NatNAT-1M1 holds  not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        then have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A2 xreal_1_th_68 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_9 sorry
        thus " not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_9 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6"
        using seqm_3_def_6 sorry
    qed
    show "0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15"
    proof(rule impI)
      assume A3: "0NUMBERSK6 =COMPLEX1R1 r"
      have " for n be NatNAT-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1 & r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A3 ordinal1_def_12 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_9 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_9 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be constantVALUED-0V15"
        using valued_0_th_25 sorry
    qed
    assume A4: "seq be increasingSEQM-3V6"
      and A5: "r <XXREAL-0R3 0NUMBERSK6"
    have " for n be NatNAT-1M1 holds  not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A4 sorry
      then have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A5 xreal_1_th_69 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      thus " not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seq_1_th_9 sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7"
      using seqm_3_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_31:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be decreasingSEQM-3V7 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7) & (seq be decreasingSEQM-3V7 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6)"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be decreasingSEQM-3V7 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7) & (seq be decreasingSEQM-3V7 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be decreasingSEQM-3V7 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7"
    proof(rule impMI ,rule impI)
      assume A1: "seq be decreasingSEQM-3V7"
        and A2: "0NUMBERSK6 <XXREAL-0R3 r"
      have " for n be NatNAT-1M1 holds  not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A1 sorry
        then have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A2 xreal_1_th_68 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_9 sorry
        thus " not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_9 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be decreasingSEQM-3V7"
        using seqm_3_def_7 sorry
    qed
    assume A3: "seq be decreasingSEQM-3V7"
      and A4: "r <XXREAL-0R3 0NUMBERSK6"
    have " for n be NatNAT-1M1 holds  not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 sorry
      then have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A4 xreal_1_th_69 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seq_1_th_9 sorry
      thus " not (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seq_1_th_9 sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be increasingSEQM-3V6"
      using seqm_3_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_32:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be non-decreasingSEQM-3V8 & 0NUMBERSK6 <=XXREAL-0R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8) & (seq be non-decreasingSEQM-3V8 & r <=XXREAL-0R1 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9)"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be non-decreasingSEQM-3V8 & 0NUMBERSK6 <=XXREAL-0R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8) & (seq be non-decreasingSEQM-3V8 & r <=XXREAL-0R1 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be non-decreasingSEQM-3V8 & 0NUMBERSK6 <=XXREAL-0R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8"
    proof(rule impMI ,rule impI)
      assume A1: "seq be non-decreasingSEQM-3V8"
        and A2: "0NUMBERSK6 <=XXREAL-0R1 r"
      have " for n be NatNAT-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        then have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A2 xreal_1_th_64 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_9 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_9 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8"
        using seqm_3_def_8 sorry
    qed
    assume A3: "seq be non-decreasingSEQM-3V8"
      and A4: "r <=XXREAL-0R1 0NUMBERSK6"
    have " for n be NatNAT-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A3 sorry
      then have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A4 xreal_1_th_65 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seq_1_th_9 sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9"
      using seqm_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_33:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be non-increasingSEQM-3V9 & 0NUMBERSK6 <=XXREAL-0R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9) & (seq be non-increasingSEQM-3V9 & r <=XXREAL-0R1 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8)"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be non-increasingSEQM-3V9 & 0NUMBERSK6 <=XXREAL-0R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9) & (seq be non-increasingSEQM-3V9 & r <=XXREAL-0R1 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be non-increasingSEQM-3V9 & 0NUMBERSK6 <=XXREAL-0R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9"
    proof(rule impMI ,rule impI)
      assume A1: "seq be non-increasingSEQM-3V9"
        and A2: "0NUMBERSK6 <=XXREAL-0R1 r"
      have " for n be NatNAT-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A1 sorry
        then have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A2 xreal_1_th_64 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_9 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_9 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-increasingSEQM-3V9"
        using seqm_3_def_9 sorry
    qed
    assume A3: "seq be non-increasingSEQM-3V9"
      and A4: "r <=XXREAL-0R1 0NUMBERSK6"
    have " for n be NatNAT-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 sorry
      then have "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A4 xreal_1_th_65 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seq_1_th_9 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seq_1_th_9 sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be non-decreasingSEQM-3V8"
      using seqm_3_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_34:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (((seq be increasingSEQM-3V6 & seq1 be increasingSEQM-3V6 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6) & (seq be decreasingSEQM-3V7 & seq1 be decreasingSEQM-3V7 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7)) & (seq be non-decreasingSEQM-3V8 & seq1 be non-decreasingSEQM-3V8 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8)) & (seq be non-increasingSEQM-3V9 & seq1 be non-increasingSEQM-3V9 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-increasingSEQM-3V9)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq be increasingSEQM-3V6 & seq1 be increasingSEQM-3V6 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6) & ((seq be decreasingSEQM-3V7 & seq1 be decreasingSEQM-3V7 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7) & ((seq be non-decreasingSEQM-3V8 & seq1 be non-decreasingSEQM-3V8 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8) & (seq be non-increasingSEQM-3V9 & seq1 be non-increasingSEQM-3V9 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-increasingSEQM-3V9)))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    show "seq be increasingSEQM-3V6 & seq1 be increasingSEQM-3V6 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6"
    proof(rule impI)
      assume A1: "seq be increasingSEQM-3V6 & seq1 be increasingSEQM-3V6"
      have " for n be NatNAT-1M1 holds  not (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) & seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_8 sorry
        then have "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_7 sorry
        thus " not (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_7 sorry
      qed "sorry"
      thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6"
        using seqm_3_def_6 sorry
    qed
    show "seq be decreasingSEQM-3V7 & seq1 be decreasingSEQM-3V7 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7"
    proof(rule impI)
      assume A2: "seq be decreasingSEQM-3V7 & seq1 be decreasingSEQM-3V7"
      have " for n be NatNAT-1M1 holds  not (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A2 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using xreal_1_th_8 sorry
        then have "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_7 sorry
        thus " not (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_7 sorry
      qed "sorry"
      thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7"
        using seqm_3_def_7 sorry
    qed
    show "seq be non-decreasingSEQM-3V8 & seq1 be non-decreasingSEQM-3V8 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8"
    proof(rule impI)
      assume A3: "seq be non-decreasingSEQM-3V8 & seq1 be non-decreasingSEQM-3V8"
      have " for n be NatNAT-1M1 holds (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) & seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A3 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_7 sorry
        then have "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_7 sorry
        thus "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_7 sorry
      qed "sorry"
      thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8"
        using seqm_3_def_8 sorry
    qed
    assume A4: "seq be non-increasingSEQM-3V9 & seq1 be non-increasingSEQM-3V9"
    have " for n be NatNAT-1M1 holds (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A4 sorry
      then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using xreal_1_th_7 sorry
      then have "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      thus "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using seq_1_th_7 sorry
    qed "sorry"
    thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-increasingSEQM-3V9"
      using seqm_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_35:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (((seq be increasingSEQM-3V6 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6) & (seq be decreasingSEQM-3V7 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7)) & (seq be non-decreasingSEQM-3V8 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8)) & (seq be non-increasingSEQM-3V9 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-increasingSEQM-3V9)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq be increasingSEQM-3V6 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6) & ((seq be decreasingSEQM-3V7 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7) & ((seq be non-decreasingSEQM-3V8 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8) & (seq be non-increasingSEQM-3V9 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-increasingSEQM-3V9)))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    show "seq be increasingSEQM-3V6 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6"
    proof(rule impMI ,rule impI)
      assume A1: "seq be increasingSEQM-3V6"
        and A2: "seq1 be constantVALUED-0V15"
      have " for n be NatNAT-1M1 holds  not (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        obtain r1 where
          [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A3: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r1"
          using A2 sorry
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 r1 <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 r1"
          using xreal_1_th_6 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 r1"
          using A3 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A3 sorry
        then have "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_7 sorry
        thus " not (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_7 sorry
      qed "sorry"
      thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be increasingSEQM-3V6"
        using seqm_3_def_6 sorry
    qed
    show "seq be decreasingSEQM-3V7 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7"
    proof(rule impMI ,rule impI)
      assume A4: "seq be decreasingSEQM-3V7"
        and A5: "seq1 be constantVALUED-0V15"
      have " for n be NatNAT-1M1 holds  not (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        obtain r1 where
          [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A6: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r1"
          using A5 sorry
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A4 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 r1 <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 r1"
          using xreal_1_th_6 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 r1"
          using A6 sorry
        then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A6 sorry
        then have "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_7 sorry
        thus " not (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using seq_1_th_7 sorry
      qed "sorry"
      thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be decreasingSEQM-3V7"
        using seqm_3_def_7 sorry
    qed
    show "seq be non-decreasingSEQM-3V8 & seq1 be constantVALUED-0V15 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-decreasingSEQM-3V8"
      using seqm_3_th_34 sorry
    assume "seq be non-increasingSEQM-3V9 & seq1 be constantVALUED-0V15"
    thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be non-increasingSEQM-3V9"
      using seqm_3_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_36:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ((seq be bounded-aboveSEQ-2V3 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-aboveSEQ-2V3) & (0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)) & (seq be bounded-aboveSEQ-2V3 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-belowSEQ-2V4)"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be bounded-aboveSEQ-2V3 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-aboveSEQ-2V3) & ((0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6) & (seq be bounded-aboveSEQ-2V3 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-belowSEQ-2V4))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be bounded-aboveSEQ-2V3 & 0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-aboveSEQ-2V3"
       sorry
    show "0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
    proof(rule impI)
      assume A1: "0NUMBERSK6 =COMPLEX1R1 r"
      have Cut881: " for n be NatNAT-1M1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (0NUMBERSK6)*XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A1 seq_1_th_9 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M"
           sorry
      qed "sorry"
      have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-aboveSEQ-2V3 & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-belowSEQ-2V2"
      proof(rule conjMI)
        show "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-aboveSEQ-2V3"
          using Cut881 sorry
        obtain p where 
          [ty]:"p be objectHIDDENM1" and pDef:"p = -XCMPLX-0K4 \<one>\<^sub>M"
           sorry
        have " ex p be objectHIDDENM1 st  for n be NatNAT-1M1 holds p <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule bexI[of _ "p"],rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6 & r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
            using A1 sorry
          thus "p <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using seq_1_th_9 sorry
        qed "sorry"
        thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-belowSEQ-2V2"
          using seq_2_def_4 sorry
      qed
      thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
        using seq_2_def_8 sorry
    qed
    assume A2: "seq be bounded-aboveSEQ-2V3"
      and A3: "r <XXREAL-0R3 0NUMBERSK6"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A4: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r1"
      using A2 sorry
    obtain p where 
      [ty]:"p be setHIDDENM2" and pDef:"p = r *XCMPLX-0K3 ( |.COMPLEX1K10 r1.|)"
       sorry
    have " ex p be setHIDDENM2 st  for n be NatNAT-1M1 holds p <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule bexI[of _ "p"],rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
        using absvalue_th_4 sorry
      then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3  |.COMPLEX1K10 r1.|"
        using A4 xxreal_0_th_2 sorry
      then have "r *XCMPLX-0K3 ( |.COMPLEX1K10 r1.|) <XXREAL-0R3 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 xreal_1_th_69 sorry
      thus "p <XXREAL-0R3 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be bounded-belowSEQ-2V4"
      using seq_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_37:
" for seq be Real-SequenceSEQ-1M1 holds ((seq be boundedSEQ-2V6 implies ( for r be RealXREAL-0M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)) & (seq be boundedSEQ-2V6 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)) & (seq be boundedSEQ-2V6 iff absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be boundedSEQ-2V6 implies ( for r be RealXREAL-0M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)) & ((seq be boundedSEQ-2V6 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6) & ((seq be boundedSEQ-2V6 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6) & (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6 implies seq be boundedSEQ-2V6)))"
  proof(rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be boundedSEQ-2V6 implies ( for r be RealXREAL-0M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6)"
    proof(rule impI,rule ballI)
      assume A1: "seq be boundedSEQ-2V6"
      fix r assume [ty]: "r be RealXREAL-0M1"
      show "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
      proof-
        have cases: "(0NUMBERSK6 <XXREAL-0R3 r or 0NUMBERSK6 =COMPLEX1R1 r) or r <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "0NUMBERSK6 <XXREAL-0R3 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
        proof(rule impI)
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
            using A1 sorry
        qed
        have case2: "0NUMBERSK6 =COMPLEX1R1 r implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
        proof(rule impI)
          assume "0NUMBERSK6 =COMPLEX1R1 r"
          thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
            using seqm_3_th_36 sorry
        qed
        have case3: "r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
        proof(rule impI)
          assume "r <XXREAL-0R3 0NUMBERSK6"
          thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
            using A1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed "sorry"
    show "seq be boundedSEQ-2V6 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
       sorry
    show "seq be boundedSEQ-2V6 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
       sorry
    assume "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be boundedSEQ-2V6"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A2: "0NUMBERSK6 <XXREAL-0R3 r"and A3: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <XXREAL-0R3 r"
      using seq_2_th_3 sorry
    have " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <XXREAL-0R3 r"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =HIDDENR1  |.COMPLEX1K10  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| .|"
        using seq_1_th_12 sorry
      also have "... =  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
         sorry
      finally have " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =HIDDENR1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
         sorry
      thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <XXREAL-0R3 r"
        using A3 sorry
    qed "sorry"
    thus "seq be boundedSEQ-2V6"
      using A2 seq_2_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_38:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be non-increasingSEQM-3V9 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be bounded-aboveSEQ-2V3"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq1 be non-increasingSEQM-3V9 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be bounded-aboveSEQ-2V3"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be bounded-aboveSEQ-2V3"
      and A2: "seq1 be non-increasingSEQM-3V9"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r1"
      using A1 sorry
    obtain r where 
      [ty]:"r be setHIDDENM2" and rDef:"r = r1 +XCMPLX-0K2 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
       sorry
    have " ex r be setHIDDENM2 st  for n be NatNAT-1M1 holds (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
    proof(rule bexI[of _ "r"],rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using A2 seqm_3_th_12 sorry
      then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r1 +XCMPLX-0K2 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using A3 xreal_1_th_8 sorry
      thus "(seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r"
        using seq_1_th_7 sorry
    qed "sorry"
    thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be bounded-aboveSEQ-2V3"
      using seq_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_39:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be non-decreasingSEQM-3V8 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be bounded-belowSEQ-2V4"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq1 be non-decreasingSEQM-3V8 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be bounded-belowSEQ-2V4"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be bounded-belowSEQ-2V4"
      and A2: "seq1 be non-decreasingSEQM-3V8"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for n be NatNAT-1M1 holds r1 <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A1 sorry
    obtain r where 
      [ty]:"r be setHIDDENM2" and rDef:"r = r1 +XCMPLX-0K2 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
       sorry
    have " ex r be setHIDDENM2 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule bexI[of _ "r"],rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <=XXREAL-0R1 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A2 seqm_3_th_11 sorry
      then have "r1 +XCMPLX-0K2 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 xreal_1_th_8 sorry
      thus "r <XXREAL-0R3 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
    qed "sorry"
    thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be bounded-belowSEQ-2V4"
      using seq_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_cl_7:
"cluster note-that natural-valuedVALUED-0V8 for FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds it be natural-valuedVALUED-0V8"
     sorry
qed "sorry"

(*begin*)
reserve v for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
reserve r, s for "RealXREAL-0M1"
reserve n, m, i, j, k for "NatNAT-1M1"
(*\$CT*)
mtheorem seqm_3_th_41:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M iff r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ( |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M implies r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M) & (r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    show " |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M implies r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M"
    proof-
      have " |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M implies  not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M))"
      proof(rule impI)
        assume A1: " |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M"
        have "(r >XXREAL-0R4 s &  not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M)) or r =COMPLEX1R1 s & (r =COMPLEX1R1 s implies  False )) or r <XXREAL-0R3 s & (r <XXREAL-0R3 s implies  not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M)))"
        proof-
          show "(r >XXREAL-0R4 s &  not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M)) or r =COMPLEX1R1 s & (r =COMPLEX1R1 s implies  False )) or r <XXREAL-0R3 s & (r <XXREAL-0R3 s implies  not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M)))"
          proof-
            have cases: "(r >XXREAL-0R4 s or r =COMPLEX1R1 s) or r <XXREAL-0R3 s"
              using xxreal_0_th_1 sorry
            have case1: "r >XXREAL-0R4 s implies  not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M))"
            proof(rule impI)
              assume A2: "r >XXREAL-0R4 s"
              then have "0NUMBERSK6 <XXREAL-0R3 r -XCMPLX-0K6 s"
                using xreal_1_th_50 sorry
              then have "r -XCMPLX-0K6 s =COMPLEX1R1 \<one>\<^sub>M"
                using A1 absvalue_def_1 sorry
              thus " not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M))"
                using A2 sorry
            qed
            have case2: "r =COMPLEX1R1 s implies  False "
            proof(rule impI)
              assume "r =COMPLEX1R1 s"
              thus " False "
                using A1 absvalue_th_2 sorry
            qed
            have case3: "r <XXREAL-0R3 s implies  not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M))"
            proof(rule impI)
              assume A3: "r <XXREAL-0R3 s"
              then have A4: "0NUMBERSK6 <XXREAL-0R3 s -XCMPLX-0K6 r"
                using xreal_1_th_50 sorry
              have "\<one>\<^sub>M =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 (r -XCMPLX-0K6 s) .|"
                using A1 complex1_th_52 sorry
              also have "... = s -XCMPLX-0K6 r"
                using A4 absvalue_def_1 sorry
              finally have "\<one>\<^sub>M =HIDDENR1 s -XCMPLX-0K6 r"
                 sorry
              thus " not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M))"
                using A3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
        thus " not ( not ( not r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M) &  not ( not r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or r <XXREAL-0R3 s & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M"
    show " |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M"
    proof-
      have cases: "r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or s >XXREAL-0R4 r & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M"
        using A5 sorry
      have case1: "r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M"
      proof(rule impI)
        assume "r >XXREAL-0R4 s & r =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M"
        thus " |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M"
          using absvalue_def_1 sorry
      qed
      have case2: "s >XXREAL-0R4 r & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =HIDDENR1 \<one>\<^sub>M"
      proof(rule impI)
        assume A6: "s >XXREAL-0R4 r & s =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M"
        have " |.COMPLEX1K10 r -XCMPLX-0K6 s .| =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 (r -XCMPLX-0K6 s) .|"
          using complex1_th_52 sorry
        also have "... = \<one>\<^sub>M"
          using A6 absvalue_def_1 sorry
        finally show " |.COMPLEX1K10 r -XCMPLX-0K6 s .| =HIDDENR1 \<one>\<^sub>M"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_42:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M iff  |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m or  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j"
proof-
  have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M implies  |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m or  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j) & ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m or  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j implies  |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    show " |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M implies  |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m or  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j"
    proof-
      have " |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M implies  not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
      proof(rule impI)
        assume A1: " |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M"
        have " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
        proof-
          show " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
          proof-
            have cases: "n =COMPLEX1R1 m or n <>HIDDENR2 m"
               sorry
            have case1: "n =COMPLEX1R1 m implies  not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
            proof(rule impI)
              assume A2: "n =COMPLEX1R1 m"
              then have "\<one>\<^sub>M =HIDDENR1  |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 0NUMBERSK6 .|"
                using A1 sorry
              also have "... =  |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2 0NUMBERSK6"
                using absvalue_th_2 sorry
              also have "... =  |.COMPLEX1K10 i -XCMPLX-0K6 j .|"
                 sorry
              finally have "\<one>\<^sub>M =HIDDENR1  |.COMPLEX1K10 i -XCMPLX-0K6 j .|"
                 sorry
              thus " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
                using A2 sorry
            qed
            have case2: "n <>HIDDENR2 m implies  not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
            proof(rule impI)
              assume A3: "n <>HIDDENR2 m"
              have " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
              proof-
                show " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
                proof-
                  have cases: "n <XXREAL-0R3 m or n >XXREAL-0R4 m"
                    using A3 xxreal_0_th_1 sorry
                  have case1: "n <XXREAL-0R3 m implies  not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
                  proof(rule impI)
                    assume A4: "n <XXREAL-0R3 m"
                    obtain l where 
                      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = m -XCMPLX-0K6 n"
                      using int_1_th_5 A4 sorry
                    have "0NUMBERSK6 <XXREAL-0R3 l"
                      using A4 xreal_1_th_50 sorry
                    then have A5: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 l"
                      using nat_1_th_13 sorry
                    have A6: " |.COMPLEX1K10 -XCMPLX-0K4 (m -XCMPLX-0K6 n) .| =COMPLEX1R1  |.COMPLEX1K10 l.|"
                      using complex1_th_52 sorry
                    then have A7: " |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1  |.COMPLEX1K10 l.|"
                       sorry
                    have A8: " |.COMPLEX1K10 l.| =COMPLEX1R1 l"
                      using absvalue_def_1 sorry
                    then have A9: "l <=XXREAL-0R1 \<one>\<^sub>M"
                      using A1 A6 complex1_th_46 xreal_1_th_31 sorry
                    then have "l =COMPLEX1R1 \<one>\<^sub>M"
                      using A5 xxreal_0_th_1 sorry
                    then have "i -XCMPLX-0K6 j =COMPLEX1R1 0NUMBERSK6"
                      using A1 A8 A7 absvalue_th_2 sorry
                    thus " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
                      using A6 A5 A8 A9 xxreal_0_th_1 sorry
                  qed
                  have case2: "n >XXREAL-0R4 m implies  not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
                  proof(rule impI)
                    assume A10: "n >XXREAL-0R4 m"
                    then obtain l where 
                      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = n -XCMPLX-0K6 m"
                      using int_1_th_5 sorry
                    have "0NUMBERSK6 <XXREAL-0R3 l"
                      using A10 xreal_1_th_50 sorry
                    then have A11: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 l"
                      using nat_1_th_13 sorry
                    have A12: " |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 l"
                      using absvalue_def_1 sorry
                    then have A13: "l <=XXREAL-0R1 \<one>\<^sub>M"
                      using A1 complex1_th_46 xreal_1_th_31 sorry
                    then have "l =COMPLEX1R1 \<one>\<^sub>M"
                      using A11 xxreal_0_th_1 sorry
                    then have "i -XCMPLX-0K6 j =COMPLEX1R1 0NUMBERSK6"
                      using A1 A12 absvalue_th_2 sorry
                    thus " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
                      using A11 A12 A13 xxreal_0_th_1 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " not ( not ( |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m) &  not ( |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A14: " |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m or  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j"
    have " |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M"
    proof-
      show " |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M"
      proof-
        have cases: " |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m or  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j"
          using A14 sorry
        have case1: " |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m implies  |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M"
        proof(rule impI)
          assume A15: " |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 \<one>\<^sub>M & n =COMPLEX1R1 m"
          then have " |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 0NUMBERSK6"
            using absvalue_th_2 sorry
          thus " |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M"
            using A15 sorry
        qed
        have case2: " |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j implies  |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M"
        proof(rule impI)
          assume A16: " |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M & i =COMPLEX1R1 j"
          then have " |.COMPLEX1K10 i -XCMPLX-0K6 j .| =COMPLEX1R1 0NUMBERSK6"
            using absvalue_th_2 sorry
          thus " |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M"
            using A16 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " |.COMPLEX1K10 i -XCMPLX-0K6 j .| +XCMPLX-0K2  |.COMPLEX1K10 n -XCMPLX-0K6 m .| =COMPLEX1R1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_43:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M iff ( ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & m >XXREAL-0R4 0NUMBERSK6)"
proof-
  have " for n be NatNAT-1M1 holds (n >XXREAL-0R4 \<one>\<^sub>M implies ( ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & m >XXREAL-0R4 0NUMBERSK6)) & (( ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & m >XXREAL-0R4 0NUMBERSK6) implies  not n >XXREAL-0R4 \<one>\<^sub>M)"
  proof(rule ballI,rule conjMI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    show "n >XXREAL-0R4 \<one>\<^sub>M implies ( ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & m >XXREAL-0R4 0NUMBERSK6)"
    proof-
      have "\<one>\<^sub>M <XXREAL-0R3 n implies ( ex tVar9 be NatNAT-1M1 st n =COMPLEX1R1 tVar9 +NAT-1K1 \<one>\<^sub>M &  not tVar9 >XXREAL-0R4 0NUMBERSK6)"
      proof(rule impI)
        assume A1: "\<one>\<^sub>M <XXREAL-0R3 n"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A2: "n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_6 sorry
        have 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        show " ex tVar9 be NatNAT-1M1 st n =COMPLEX1R1 tVar9 +NAT-1K1 \<one>\<^sub>M &  not tVar9 >XXREAL-0R4 0NUMBERSK6"
        proof(rule bexI[of _ "m"])
          have "m <>HIDDENR2 0NUMBERSK6"
            using A1 A2 sorry
          thus "n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M &  not m >XXREAL-0R4 0NUMBERSK6"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & m >XXREAL-0R4 0NUMBERSK6"
    then obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & m >XXREAL-0R4 0NUMBERSK6"
       sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 n"
      using A3 xreal_1_th_6 sorry
    thus " not n >XXREAL-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_44:
" for f be FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds (lenFINSEQ-1K4 f =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & n inTARSKIR2 domFINSEQ-1K5 f) & k inTARSKIR2 SegFINSEQ-1K2 m implies (DelFINSEQ-3K2(f,n)).FUNCT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 k or (DelFINSEQ-3K2(f,n)).FUNCT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds (lenFINSEQ-1K4 f =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & n inTARSKIR2 domFINSEQ-1K5 f) & k inTARSKIR2 SegFINSEQ-1K2 m implies  not ( not (DelFINSEQ-3K2(f,n)).FUNCT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 k &  not (DelFINSEQ-3K2(f,n)).FUNCT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "lenFINSEQ-1K4 f =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M & n inTARSKIR2 domFINSEQ-1K5 f"
      and A2: "k inTARSKIR2 SegFINSEQ-1K2 m"
    let ?X = "domFINSEQ-1K5 f \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 n}"
    have A3: "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
      using finseq_1_def_3 sorry
    then have A4: "n <=XXREAL-0R1 k & k <=XXREAL-0R1 m implies SgmFINSEQ-1K15 ?X .FUNCT-1K1 k =COMPLEX1R1 k +NAT-1K1 \<one>\<^sub>M"
      using A1 A2 finseq_3_th_108 sorry
    have "?X c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
      using A3 xboole_1_th_36 sorry
    then have "rngFUNCT-1K2 (SgmFINSEQ-1K15 ?X) =XBOOLE-0R4 ?X"
      using finseq_1_def_13 sorry
    then have A5: "domRELAT-1K1 (f *FUNCT-1K3 SgmFINSEQ-1K15 ?X) =XBOOLE-0R4 domFINSEQ-1K5 (SgmFINSEQ-1K15 ?X)"
      using relat_1_th_27 xboole_1_th_36 sorry
    have A6: "domFINSEQ-1K5 (SgmFINSEQ-1K15 ?X) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SgmFINSEQ-1K15 ?X)) & DelFINSEQ-3K2(f,n) =FUNCT-1R1 f *FUNCT-1K3 SgmFINSEQ-1K15 ?X"
      using finseq_1_def_3 finseq_3_def_2 sorry
    have A7: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 ?X) =COMPLEX1R1 m"
      using A1 A3 finseq_3_th_107 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 n implies SgmFINSEQ-1K15 ?X .FUNCT-1K1 k =COMPLEX1R1 k"
      using A1 A2 A3 finseq_3_th_108 sorry
    thus " not ( not (DelFINSEQ-3K2(f,n)).FUNCT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 k &  not (DelFINSEQ-3K2(f,n)).FUNCT-1K1 k =XBOOLE-0R4 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
      using A2 A6 A5 A7 A4 finseq_3_th_25 funct_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) SEQM_3V10("constantSEQM-3V10" 70) where
  "constantSEQM-3V10 \<equiv> constantFUNCT-1V5"

mtheorem seqm_3_def_10:
  mlet "f be FinSequenceFINSEQ-1M1"
"redefine attr constantSEQM-3V10 for FinSequenceFINSEQ-1M1 means
  (\<lambda>f.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 n =XBOOLE-0R4 f .FUNCT-1K1 m)"
proof
(*compatibility*)
  show " for f be FinSequenceFINSEQ-1M1 holds f be constantSEQM-3V10 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 n =XBOOLE-0R4 f .FUNCT-1K1 m)"
  proof(rule ballI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    show "f be constantSEQM-3V10 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f & m inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 n =XBOOLE-0R4 f .FUNCT-1K1 m)"
       sorry
  qed "sorry"
qed "sorry"

mtheorem seqm_3_cl_8:
"cluster note-that real-valuedVALUED-0V7 for FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem seqm_3_cl_9:
"cluster  non emptyXBOOLE-0V1\<bar>increasingSEQM-3V1 for FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>increasingSEQM-3V1"
  proof-
    have " ex v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st v be  non emptyXBOOLE-0V1 & v be increasingSEQM-3V1"
    proof-
      obtain v where 
        [ty]:"v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and vDef:"v = <*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) *>"
         sorry
      show " ex v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st v be  non emptyXBOOLE-0V1 & v be increasingSEQM-3V1"
      proof(rule bexI[of _ "v"],rule conjMI)
        show "v be  non emptyXBOOLE-0V1"
           sorry
        have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v implies  not ( not n <XXREAL-0R3 m & v .FUNCT-1K1 n <XXREAL-0R3 v .FUNCT-1K1 m)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A1: "n inTARSKIR2 domFINSEQ-1K5 v"
            and A2: "m inTARSKIR2 domFINSEQ-1K5 v"
          have A3: "domFINSEQ-1K5 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>) =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using finseq_1_th_2 finseq_1_th_38 sorry
          then have "n =COMPLEX1R1 \<one>\<^sub>M"
            using A1 tarski_def_1 sorry
          thus " not ( not n <XXREAL-0R3 m & v .FUNCT-1K1 n <XXREAL-0R3 v .FUNCT-1K1 m)"
            using A3 A2 tarski_def_1 sorry
        qed "sorry"
        thus "v be increasingSEQM-3V1"
          using seqm_3_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seqm_3_cl_10:
"cluster constantSEQM-3V10 for FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st it be constantSEQM-3V10"
  proof-
    have " ex v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st v be constantSEQM-3V10"
    proof-
      obtain v where 
        [ty]:"v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and vDef:"v = <*>FINSEQ-1K7 REALNUMBERSK2"
         sorry
      show " ex v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st v be constantSEQM-3V10"
      proof(rule bexI[of _ "v"])
        have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v implies v .FUNCT-1K1 n =XBOOLE-0R4 v .FUNCT-1K1 m"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n inTARSKIR2 domFINSEQ-1K5 v"
            and "m inTARSKIR2 domFINSEQ-1K5 v"
          show "v .FUNCT-1K1 n =XBOOLE-0R4 v .FUNCT-1K1 m"
             sorry
        qed "sorry"
        thus "v be constantSEQM-3V10"
          using seqm_3_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seqm_3_th_45:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for i be NatNAT-1M1 holds (((((((v <>HIDDENR2 {}XBOOLE-0K1 & rngFUNCT-1K2 v c=TARSKIR1 SegFINSEQ-1K2 n) & v .FUNCT-1K1 lenFINSEQ-1K4 v =COMPLEX1R1 n) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r =COMPLEX1R1 v .FUNCT-1K1 k & s =COMPLEX1R1 v .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r =COMPLEX1R1 s))) & i inTARSKIR2 SegFINSEQ-1K2 n) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n) & m inTARSKIR2 domFINSEQ-1K5 v) & v .FUNCT-1K1 m =COMPLEX1R1 i) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i implies k <=XXREAL-0R1 m) implies m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for i be NatNAT-1M1 holds v <>HIDDENR2 {}XBOOLE-0K1 & (rngFUNCT-1K2 v c=TARSKIR1 SegFINSEQ-1K2 n & (v .FUNCT-1K1 lenFINSEQ-1K4 v =COMPLEX1R1 n & (( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r =COMPLEX1R1 v .FUNCT-1K1 k & s =COMPLEX1R1 v .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r =COMPLEX1R1 s)) & (i inTARSKIR2 SegFINSEQ-1K2 n & (i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n & (m inTARSKIR2 domFINSEQ-1K5 v & (v .FUNCT-1K1 m =COMPLEX1R1 i & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i implies k <=XXREAL-0R1 m)))))))) implies m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "v <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "rngFUNCT-1K2 v c=TARSKIR1 SegFINSEQ-1K2 n"
      and A3: "v .FUNCT-1K1 lenFINSEQ-1K4 v =COMPLEX1R1 n"
      and A4: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r =COMPLEX1R1 v .FUNCT-1K1 k & s =COMPLEX1R1 v .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r =COMPLEX1R1 s)"
      and A5: "i inTARSKIR2 SegFINSEQ-1K2 n"
      and A6: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
      and A7: "m inTARSKIR2 domFINSEQ-1K5 v"
      and A8: "v .FUNCT-1K1 m =COMPLEX1R1 i"
      and A9: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i implies k <=XXREAL-0R1 m"
    have A10: "m <=XXREAL-0R1 lenFINSEQ-1K4 v"
      using A7 finseq_3_th_25 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 v"
      using A1 nat_1_th_13 sorry
    then have A11: "lenFINSEQ-1K4 v inTARSKIR2 domFINSEQ-1K5 v"
      using finseq_3_th_25 sorry
    obtain r where 
      [ty]:"r be RealXREAL-0M1" and rDef:"r = v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have A12: "i <=XXREAL-0R1 n"
      using A5 finseq_1_th_1 sorry
    have A13: "\<one>\<^sub>M <=XXREAL-0R1 m"
      using A7 finseq_3_th_25 sorry
    have A14: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
      using A6 finseq_1_th_1 sorry
    have A15: " not m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v implies  False "
    proof(rule impI)
      assume " not m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v"
      then have "\<one>\<^sub>M >XXREAL-0R4 m +NAT-1K1 \<one>\<^sub>M or m +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 lenFINSEQ-1K4 v"
        using finseq_3_th_25 sorry
      then have A16: "lenFINSEQ-1K4 v <=XXREAL-0R1 m"
        using nat_1_th_11 nat_1_th_13 sorry
      have "i <XXREAL-0R3 n"
        using A14 nat_1_th_13 sorry
      thus " False "
        using A3 A8 A10 A16 xxreal_0_th_1 sorry
    qed
    then have A17: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 v"
      using finseq_3_th_25 sorry
    then have A18: "m <XXREAL-0R3 lenFINSEQ-1K4 v"
      using nat_1_th_13 sorry
    have A19: "m <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M"
      using A17 xreal_1_th_19 sorry
    have " |.COMPLEX1K10 i -XCMPLX-0K6 r .| =COMPLEX1R1 \<one>\<^sub>M & (m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M) or i =COMPLEX1R1 r & (i =COMPLEX1R1 r implies  False )"
    proof-
      show " |.COMPLEX1K10 i -XCMPLX-0K6 r .| =COMPLEX1R1 \<one>\<^sub>M & (m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M) or i =COMPLEX1R1 r & (i =COMPLEX1R1 r implies  False )"
      proof-
        have cases: " |.COMPLEX1K10 i -XCMPLX-0K6 r .| =COMPLEX1R1 \<one>\<^sub>M or i =COMPLEX1R1 r"
          using A4 A8 A13 A19 sorry
        have case1: " |.COMPLEX1K10 i -XCMPLX-0K6 r .| =COMPLEX1R1 \<one>\<^sub>M implies m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
        proof(rule impI)
          assume A20: " |.COMPLEX1K10 i -XCMPLX-0K6 r .| =COMPLEX1R1 \<one>\<^sub>M"
          have "(i >XXREAL-0R4 r & i =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M) &  False  or (i <XXREAL-0R3 r & r =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M) & (i <XXREAL-0R3 r & r =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M implies m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M)"
          proof-
            show "(i >XXREAL-0R4 r & i =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M) &  False  or (i <XXREAL-0R3 r & r =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M) & (i <XXREAL-0R3 r & r =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M implies m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have cases: "i >XXREAL-0R4 r & i =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M or i <XXREAL-0R3 r & r =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
                using A20 seqm_3_th_41 sorry
              have case1: "i >XXREAL-0R4 r & i =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M implies  False "
              proof(rule impI)
                assume A21: "i >XXREAL-0R4 r & i =COMPLEX1R1 r +XCMPLX-0K2 \<one>\<^sub>M"
                let ?P = "\<lambda>Lamb1.  for k be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds ((k =XBOOLE-0R4 Lamb1 & k >XXREAL-0R4 0NUMBERSK6) & m +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 v) & r =COMPLEX1R1 v .FUNCT-1K1 (m +XCMPLX-0K2 k) implies r <XXREAL-0R3 i"
                have A22: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
                proof-
                  have " for k be NatNAT-1M1 holds ( for kc be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds ((kc =XBOOLE-0R4 k & kc >XXREAL-0R4 0NUMBERSK6) & m +XCMPLX-0K2 kc inTARSKIR2 domFINSEQ-1K5 v) & r =COMPLEX1R1 v .FUNCT-1K1 (m +XCMPLX-0K2 kc) implies r <XXREAL-0R3 i) implies ( for j be NatNAT-1M1 holds  for s be RealXREAL-0M1 holds j =COMPLEX1R1 k +NAT-1K1 \<one>\<^sub>M & (j >XXREAL-0R4 0NUMBERSK6 & (m +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 v & s =COMPLEX1R1 v .FUNCT-1K1 (m +XCMPLX-0K2 j))) implies  not s <XXREAL-0R3 i)"
                  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
                    fix k assume [ty]: "k be NatNAT-1M1"
                    assume A23: "?P(k)"
                    fix j assume [ty]: "j be NatNAT-1M1"
                    fix s assume [ty]: "s be RealXREAL-0M1"
                    assume A24: "j =COMPLEX1R1 k +NAT-1K1 \<one>\<^sub>M"
                      and A25: "j >XXREAL-0R4 0NUMBERSK6"
                      and A26: "m +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 v"
                      and A27: "s =COMPLEX1R1 v .FUNCT-1K1 (m +XCMPLX-0K2 j)"
                    have " not s <XXREAL-0R3 i"
                    proof-
                      show " not s <XXREAL-0R3 i"
                      proof-
                        have cases: "k =COMPLEX1R1 0NUMBERSK6 or k <>HIDDENR2 0NUMBERSK6"
                           sorry
                        have case1: "k =COMPLEX1R1 0NUMBERSK6 implies  not s <XXREAL-0R3 i"
                        proof(rule impI)
                          assume "k =COMPLEX1R1 0NUMBERSK6"
                          thus " not s <XXREAL-0R3 i"
                            using A21 A24 A27 sorry
                        qed
                        have case2: "k <>HIDDENR2 0NUMBERSK6 implies  not s <XXREAL-0R3 i"
                        proof(rule impI)
                          assume A28: "k <>HIDDENR2 0NUMBERSK6"
                          have A29: "m +XCMPLX-0K2 k <=XXREAL-0R1 (m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M"
                            using nat_1_th_11 sorry
                          have "m <=XXREAL-0R1 m +XCMPLX-0K2 k"
                            using nat_1_th_11 sorry
                          then have A30: "\<one>\<^sub>M <=XXREAL-0R1 m +XCMPLX-0K2 k"
                            using A13 xxreal_0_th_2 sorry
                          have A31: "m +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 v"
                            using A24 A26 finseq_3_th_25 sorry
                          then have "m +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 v"
                            using A29 xxreal_0_th_2 sorry
                          then have A32: "m +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 v"
                            using A30 finseq_3_th_25 sorry
                          then have "v .FUNCT-1K1 (m +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 v"
                            using funct_1_def_3 sorry
                          then have "v .FUNCT-1K1 (m +XCMPLX-0K2 k) inTARSKIR2 SegFINSEQ-1K2 n"
                            using A2 sorry
                          then obtain r1 where 
                            [ty]:"r1 be ElementSUBSET-1M1-of NATNUMBERSK1" and r1Def:"r1 = v .FUNCT-1K1 (m +XCMPLX-0K2 k)"
                             sorry
                          have A33: "r1 <XXREAL-0R3 i"
                            using A23 A28 A32 sorry
                          have A34: "m +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M"
                            using A29 A31 xreal_1_th_19 sorry
                          have " not s <XXREAL-0R3 i"
                          proof-
                            show " not s <XXREAL-0R3 i"
                            proof-
                              have cases: " |.COMPLEX1K10 r1 -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r1 =COMPLEX1R1 s"
                                using A4 A24 A27 A29 A30 A34 sorry
                              have case1: " |.COMPLEX1K10 r1 -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M implies  not s <XXREAL-0R3 i"
                              proof(rule impI)
                                assume A35: " |.COMPLEX1K10 r1 -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M"
                                have " not s <XXREAL-0R3 i"
                                proof-
                                  show " not s <XXREAL-0R3 i"
                                  proof-
                                    have cases: "r1 >XXREAL-0R4 s & r1 =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or r1 <XXREAL-0R3 s & s =COMPLEX1R1 r1 +NAT-1K1 \<one>\<^sub>M"
                                      using A35 seqm_3_th_41 sorry
                                    have case1: "r1 >XXREAL-0R4 s & r1 =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M implies  not s <XXREAL-0R3 i"
                                    proof(rule impI)
                                      assume "r1 >XXREAL-0R4 s & r1 =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M"
                                      thus " not s <XXREAL-0R3 i"
                                        using A33 xxreal_0_th_2 sorry
                                    qed
                                    have case2: "r1 <XXREAL-0R3 s & s =COMPLEX1R1 r1 +NAT-1K1 \<one>\<^sub>M implies  not s <XXREAL-0R3 i"
                                    proof(rule impI)
                                      assume "r1 <XXREAL-0R3 s & s =COMPLEX1R1 r1 +NAT-1K1 \<one>\<^sub>M"
                                      then have A36: "s <=XXREAL-0R1 i"
                                        using A33 nat_1_th_13 sorry
                                      have "s <XXREAL-0R3 i &  not s <XXREAL-0R3 i or s =COMPLEX1R1 i & (s =COMPLEX1R1 i implies  False )"
                                      proof-
                                        show "s <XXREAL-0R3 i &  not s <XXREAL-0R3 i or s =COMPLEX1R1 i & (s =COMPLEX1R1 i implies  False )"
                                        proof-
                                          have cases: "s <XXREAL-0R3 i or s =COMPLEX1R1 i"
                                            using A36 xxreal_0_th_1 sorry
                                          have case1: "s <XXREAL-0R3 i implies  not s <XXREAL-0R3 i"
                                          proof(rule impI)
                                            assume "s <XXREAL-0R3 i"
                                            thus " not s <XXREAL-0R3 i"
                                               sorry
                                          qed
                                          have case2: "s =COMPLEX1R1 i implies  False "
                                          proof(rule impI)
                                            assume "s =COMPLEX1R1 i"
                                            then have "m +XCMPLX-0K2 j <=XXREAL-0R1 m"
                                              using A9 A26 A27 sorry
                                            then have "j <=XXREAL-0R1 m -XCMPLX-0K6 m"
                                              using xreal_1_th_19 sorry
                                            thus " False "
                                              using A25 sorry
                                          qed
                                          show " ?thesis "
                                            using cases case1 case2 sorry
                                        qed
                                      qed
                                      thus " not s <XXREAL-0R3 i"
                                         sorry
                                    qed
                                    show " ?thesis "
                                      using cases case1 case2 sorry
                                  qed
                                qed
                                thus " not s <XXREAL-0R3 i"
                                   sorry
                              qed
                              have case2: "r1 =COMPLEX1R1 s implies  not s <XXREAL-0R3 i"
                              proof(rule impI)
                                assume "r1 =COMPLEX1R1 s"
                                thus " not s <XXREAL-0R3 i"
                                  using A23 A28 A32 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " not s <XXREAL-0R3 i"
                             sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " not s <XXREAL-0R3 i"
                       sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                obtain l where 
                  [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = lenFINSEQ-1K4 v -XCMPLX-0K6 m"
                  using A18 int_1_th_5 sorry
                have A37: "0NUMBERSK6 <XXREAL-0R3 lenFINSEQ-1K4 v -XCMPLX-0K6 m & m +NAT-1K1 l =COMPLEX1R1 lenFINSEQ-1K4 v"
                  using A17 xreal_1_th_19 sorry
                have A38: "?P(0NUMBERSK6)"
                   sorry
                have " for k be NatNAT-1M1 holds ?P(k)"
                  using nat_1_sch_2 A38 A22 sorry
                thus " False "
                  using A3 A11 A12 A37 sorry
              qed
              have case2: "i <XXREAL-0R3 r & r =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M implies m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
              proof(rule impI)
                assume "i <XXREAL-0R3 r & r =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
                thus "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
                  using A15 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
             sorry
        qed
        have case2: "i =COMPLEX1R1 r implies  False "
        proof(rule impI)
          assume "i =COMPLEX1R1 r"
          then have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
            using A9 A15 sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 m -XCMPLX-0K6 m"
            using xreal_1_th_19 sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
             sorry
          thus " False "
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqm_3_th_46:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds (((v <>HIDDENR2 {}XBOOLE-0K1 & rngFUNCT-1K2 v c=TARSKIR1 SegFINSEQ-1K2 n) & v .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M) & v .FUNCT-1K1 lenFINSEQ-1K4 v =COMPLEX1R1 n) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r =COMPLEX1R1 v .FUNCT-1K1 k & s =COMPLEX1R1 v .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r =COMPLEX1R1 s)) implies ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i)) & ( for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds ((((m inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 m =COMPLEX1R1 i) & ( for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 j =COMPLEX1R1 i implies j <=XXREAL-0R1 m)) & m <XXREAL-0R3 k) & k inTARSKIR2 domFINSEQ-1K5 v) & r =COMPLEX1R1 v .FUNCT-1K1 k implies i <XXREAL-0R3 r)"
proof-
  have " for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds v <>HIDDENR2 {}XBOOLE-0K1 & (rngFUNCT-1K2 v c=TARSKIR1 SegFINSEQ-1K2 n & (v .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M & (v .FUNCT-1K1 lenFINSEQ-1K4 v =COMPLEX1R1 n & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r =COMPLEX1R1 v .FUNCT-1K1 k & s =COMPLEX1R1 v .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r =COMPLEX1R1 s))))) implies ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i)) & ( for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for i be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds m inTARSKIR2 domFINSEQ-1K5 v & (v .FUNCT-1K1 m =COMPLEX1R1 i & (( for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 j =COMPLEX1R1 i implies j <=XXREAL-0R1 m) & (m <XXREAL-0R3 k & (k inTARSKIR2 domFINSEQ-1K5 v & r =COMPLEX1R1 v .FUNCT-1K1 k)))) implies  not i <XXREAL-0R3 r)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "v <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "rngFUNCT-1K2 v c=TARSKIR1 SegFINSEQ-1K2 n"
      and A3: "v .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
      and A4: "v .FUNCT-1K1 lenFINSEQ-1K4 v =COMPLEX1R1 n"
      and A5: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r =COMPLEX1R1 v .FUNCT-1K1 k & s =COMPLEX1R1 v .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 r -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r =COMPLEX1R1 s)"
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 SegFINSEQ-1K2 n implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 Lamb1)"
    have A6: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 v"
      using A1 nat_1_th_13 sorry
    then have A7: "lenFINSEQ-1K4 v inTARSKIR2 domFINSEQ-1K5 v"
      using finseq_3_th_25 sorry
    have A8: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be NatNAT-1M1 holds (i inTARSKIR2 SegFINSEQ-1K2 n implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i)) implies (i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n implies  not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M)))"
      proof(rule ballI,rule impI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A9: "i inTARSKIR2 SegFINSEQ-1K2 n implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i)"
        assume A10: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
        have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
        proof-
          show " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
          proof-
            have cases: "i =COMPLEX1R1 0NUMBERSK6 or i <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "i =COMPLEX1R1 0NUMBERSK6 implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A11: "i =COMPLEX1R1 0NUMBERSK6"
              obtain k where 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = \<one>\<^sub>M"
                 sorry
              show " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
              proof(rule bexI[of _ "k"])
                show "k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
                  using A3 A6 A11 finseq_3_th_25 sorry
              qed "sorry"
            qed
            have case2: "i <>HIDDENR2 0NUMBERSK6 implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A12: "i <>HIDDENR2 0NUMBERSK6"
              let ?R = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 Lamb1 =COMPLEX1R1 i"
              have A13: " for k be NatNAT-1M1 holds ?R(k) implies k <=XXREAL-0R1 lenFINSEQ-1K4 v"
                using finseq_3_th_25 sorry
              have "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                using A10 finseq_1_th_1 sorry
              then have A14: "i <=XXREAL-0R1 n"
                using nat_1_th_13 sorry
              have A15: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
                using A12 nat_1_th_13 sorry
              then have A16: " ex k be NatNAT-1M1 st ?R(k)"
                using A9 A14 finseq_1_th_1 sorry
              obtain m where
                [ty]:"m be NatNAT-1M1" and 
                A17: "?R(m) & ( for k be NatNAT-1M1 holds ?R(k) implies k <=XXREAL-0R1 m)"
                using nat_1_sch_6 A13 A16 sorry
              have 
                [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
                using ordinal1_def_12 sorry
              obtain k where 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = m +NAT-1K1 \<one>\<^sub>M"
                 sorry
              show " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
              proof(rule bexI[of _ "k"])
                have "i inTARSKIR2 SegFINSEQ-1K2 n"
                  using A15 A14 finseq_1_th_1 sorry
                thus "k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
                  using A1 A2 A4 A5 A10 A17 seqm_3_th_45 sorry
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " not ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A18: "?P(0NUMBERSK6)"
      using finseq_1_th_1 sorry
    show " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 k =COMPLEX1R1 i)"
      using nat_1_sch_2 A18 A8 sorry
    fix m assume [ty]: "m be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A19: "m inTARSKIR2 domFINSEQ-1K5 v"
      and A20: "v .FUNCT-1K1 m =COMPLEX1R1 i"
      and A21: " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 v & v .FUNCT-1K1 j =COMPLEX1R1 i implies j <=XXREAL-0R1 m"
      and A22: "m <XXREAL-0R3 k"
      and A23: "k inTARSKIR2 domFINSEQ-1K5 v"
      and A24: "r =COMPLEX1R1 v .FUNCT-1K1 k"
    have A25: "m <=XXREAL-0R1 lenFINSEQ-1K4 v & k <=XXREAL-0R1 lenFINSEQ-1K4 v"
      using A19 A23 finseq_3_th_25 sorry
    have A26: "\<one>\<^sub>M <=XXREAL-0R1 m"
      using A19 finseq_3_th_25 sorry
    have A27: "i inTARSKIR2 rngFUNCT-1K2 v"
      using A19 A20 funct_1_def_3 sorry
    then have A28: "i <=XXREAL-0R1 n"
      using A2 finseq_1_th_1 sorry
    have " not i <XXREAL-0R3 r"
    proof-
      show " not i <XXREAL-0R3 r"
      proof-
        have cases: "i =COMPLEX1R1 n or i <>HIDDENR2 n"
           sorry
        have case1: "i =COMPLEX1R1 n implies  not i <XXREAL-0R3 r"
        proof(rule impI)
          assume "i =COMPLEX1R1 n"
          then have "lenFINSEQ-1K4 v <=XXREAL-0R1 m"
            using A4 A7 A21 sorry
          thus " not i <XXREAL-0R3 r"
            using A22 A25 xxreal_0_th_1 sorry
        qed
        have case2: "i <>HIDDENR2 n implies  not i <XXREAL-0R3 r"
        proof(rule impI)
          assume A29: "i <>HIDDENR2 n"
          let ?P = "\<lambda>Lamb1.  for j be NatNAT-1M1 holds  for s be RealXREAL-0M1 holds ((j =XBOOLE-0R4 Lamb1 & j >XXREAL-0R4 0NUMBERSK6) & m +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 v) & s =COMPLEX1R1 v .FUNCT-1K1 (m +XCMPLX-0K2 j) implies i <XXREAL-0R3 s"
          have "i <XXREAL-0R3 n"
            using A28 A29 xxreal_0_th_1 sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
            using nat_1_th_11 nat_1_th_13 sorry
          then have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
            using finseq_1_th_1 sorry
          then have A30: "v .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 i +NAT-1K1 \<one>\<^sub>M"
            using A1 A2 A4 A5 A19 A20 A21 A27 seqm_3_th_45 sorry
          have A31: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for k be NatNAT-1M1 holds ?P(k) implies ( for j be NatNAT-1M1 holds  for s be RealXREAL-0M1 holds j =COMPLEX1R1 k +NAT-1K1 \<one>\<^sub>M & (j >XXREAL-0R4 0NUMBERSK6 & (m +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 v & s =COMPLEX1R1 v .FUNCT-1K1 (m +XCMPLX-0K2 j))) implies  not i <XXREAL-0R3 s)"
            proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A32: "?P(k)"
              fix j assume [ty]: "j be NatNAT-1M1"
              fix s assume [ty]: "s be RealXREAL-0M1"
              assume A33: "j =COMPLEX1R1 k +NAT-1K1 \<one>\<^sub>M"
                and A34: "j >XXREAL-0R4 0NUMBERSK6"
                and A35: "m +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 v"
                and A36: "s =COMPLEX1R1 v .FUNCT-1K1 (m +XCMPLX-0K2 j)"
              show " not i <XXREAL-0R3 s"
              proof-
                have cases: "k =COMPLEX1R1 0NUMBERSK6 or k <>HIDDENR2 0NUMBERSK6"
                   sorry
                have case1: "k =COMPLEX1R1 0NUMBERSK6 implies  not i <XXREAL-0R3 s"
                proof(rule impI)
                  assume "k =COMPLEX1R1 0NUMBERSK6"
                  thus " not i <XXREAL-0R3 s"
                    using A30 A33 A36 nat_1_th_13 sorry
                qed
                have case2: "k <>HIDDENR2 0NUMBERSK6 implies  not i <XXREAL-0R3 s"
                proof(rule impI)
                  assume A37: "k <>HIDDENR2 0NUMBERSK6"
                  have "m <=XXREAL-0R1 m +XCMPLX-0K2 k"
                    using nat_1_th_11 sorry
                  then have A38: "\<one>\<^sub>M <=XXREAL-0R1 m +XCMPLX-0K2 k"
                    using A26 xxreal_0_th_2 sorry
                  have "s inHIDDENR3 rngFUNCT-1K2 v"
                    using A35 A36 funct_1_def_3 sorry
                  then have "s inHIDDENR3 SegFINSEQ-1K2 n"
                    using A2 sorry
                  then obtain s1 where 
                    [ty]:"s1 be ElementSUBSET-1M1-of NATNUMBERSK1" and s1Def:"s1 = s"
                     sorry
                  have A39: "m +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 v"
                    using A33 A35 finseq_3_th_25 sorry
                  have "m +XCMPLX-0K2 k <=XXREAL-0R1 (m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M"
                    using nat_1_th_11 sorry
                  then have "m +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 v"
                    using A39 xxreal_0_th_2 sorry
                  then have A40: "m +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 v"
                    using A38 finseq_3_th_25 sorry
                  then have "v .FUNCT-1K1 (m +XCMPLX-0K2 k) inTARSKIR2 rngFUNCT-1K2 v"
                    using funct_1_def_3 sorry
                  then have "v .FUNCT-1K1 (m +XCMPLX-0K2 k) inTARSKIR2 SegFINSEQ-1K2 n"
                    using A2 sorry
                  then obtain r1 where 
                    [ty]:"r1 be ElementSUBSET-1M1-of NATNUMBERSK1" and r1Def:"r1 = v .FUNCT-1K1 (m +XCMPLX-0K2 k)"
                     sorry
                  have A41: "i <XXREAL-0R3 r1"
                    using A32 A37 A40 sorry
                  have A42: "(m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 m +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                     sorry
                  then have A43: "m +XCMPLX-0K2 k <=XXREAL-0R1 lenFINSEQ-1K4 v -XCMPLX-0K6 \<one>\<^sub>M"
                    using A39 xreal_1_th_19 sorry
                  have " not i <XXREAL-0R3 s"
                  proof-
                    show " not i <XXREAL-0R3 s"
                    proof-
                      have cases: " |.COMPLEX1K10 r1 -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M or r1 =COMPLEX1R1 s"
                        using A5 A33 A36 A42 A38 A43 sorry
                      have case1: " |.COMPLEX1K10 r1 -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M implies  not i <XXREAL-0R3 s"
                      proof(rule impI)
                        assume A44: " |.COMPLEX1K10 r1 -XCMPLX-0K6 s .| =COMPLEX1R1 \<one>\<^sub>M"
                        have " not i <XXREAL-0R3 s"
                        proof-
                          show " not i <XXREAL-0R3 s"
                          proof-
                            have cases: "r1 >XXREAL-0R4 s & r1 =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M or r1 <XXREAL-0R3 s & s =COMPLEX1R1 r1 +NAT-1K1 \<one>\<^sub>M"
                              using A44 seqm_3_th_41 sorry
                            have case1: "r1 >XXREAL-0R4 s & r1 =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M implies  not i <XXREAL-0R3 s"
                            proof(rule impI)
                              assume "r1 >XXREAL-0R4 s & r1 =COMPLEX1R1 s +XCMPLX-0K2 \<one>\<^sub>M"
                              then have A45: "i <=XXREAL-0R1 s1"
                                using A41 nat_1_th_13 sorry
                              have "i <XXREAL-0R3 s &  not i <XXREAL-0R3 s or s =COMPLEX1R1 i & (s =COMPLEX1R1 i implies  False )"
                              proof-
                                show "i <XXREAL-0R3 s &  not i <XXREAL-0R3 s or s =COMPLEX1R1 i & (s =COMPLEX1R1 i implies  False )"
                                proof-
                                  have cases: "i <XXREAL-0R3 s or s =COMPLEX1R1 i"
                                    using A45 xxreal_0_th_1 sorry
                                  have case1: "i <XXREAL-0R3 s implies  not i <XXREAL-0R3 s"
                                  proof(rule impI)
                                    assume "i <XXREAL-0R3 s"
                                    thus " not i <XXREAL-0R3 s"
                                       sorry
                                  qed
                                  have case2: "s =COMPLEX1R1 i implies  False "
                                  proof(rule impI)
                                    assume "s =COMPLEX1R1 i"
                                    then have "m +XCMPLX-0K2 j <=XXREAL-0R1 m"
                                      using A21 A35 A36 sorry
                                    then have "j <=XXREAL-0R1 m -XCMPLX-0K6 m"
                                      using xreal_1_th_19 sorry
                                    thus " False "
                                      using A34 sorry
                                  qed
                                  show " ?thesis "
                                    using cases case1 case2 sorry
                                qed
                              qed
                              thus " not i <XXREAL-0R3 s"
                                 sorry
                            qed
                            have case2: "r1 <XXREAL-0R3 s & s =COMPLEX1R1 r1 +NAT-1K1 \<one>\<^sub>M implies  not i <XXREAL-0R3 s"
                            proof(rule impI)
                              assume "r1 <XXREAL-0R3 s & s =COMPLEX1R1 r1 +NAT-1K1 \<one>\<^sub>M"
                              thus " not i <XXREAL-0R3 s"
                                using A41 xxreal_0_th_2 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                        thus " not i <XXREAL-0R3 s"
                           sorry
                      qed
                      have case2: "r1 =COMPLEX1R1 s implies  not i <XXREAL-0R3 s"
                      proof(rule impI)
                        assume "r1 =COMPLEX1R1 s"
                        thus " not i <XXREAL-0R3 s"
                          using A32 A37 A40 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus " not i <XXREAL-0R3 s"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain l where 
            [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = k -XCMPLX-0K6 m"
            using A22 int_1_th_5 sorry
          have A46: "0NUMBERSK6 <XXREAL-0R3 k -XCMPLX-0K6 m & m +NAT-1K1 l =COMPLEX1R1 k"
            using A22 xreal_1_th_50 sorry
          have A47: "?P(0NUMBERSK6)"
             sorry
          have " for k be NatNAT-1M1 holds ?P(k)"
            using nat_1_sch_2 A47 A31 sorry
          thus " not i <XXREAL-0R3 r"
            using A23 A24 A46 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not i <XXREAL-0R3 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
