theory sin_cos4
  imports sin_cos
   "../mizar_extension/E_number"
begin
(*begin*)
reserve th, th1, th2, th3 for "RealXREAL-0M1"
mdef sin_cos4_def_1 ("tanSIN-COS4K1  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func tanSIN-COS4K1 th \<rightarrow> RealXREAL-0M1 equals
  (sinSIN-COSK18 th)/XCMPLX-0K7 (cosSIN-COSK20 th)"
proof-
  (*coherence*)
    show "(sinSIN-COSK18 th)/XCMPLX-0K7 (cosSIN-COSK20 th) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos4_def_2 ("cotSIN-COS4K2  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func cotSIN-COS4K2 th \<rightarrow> RealXREAL-0M1 equals
  (cosSIN-COSK20 th)/XCMPLX-0K7 (sinSIN-COSK18 th)"
proof-
  (*coherence*)
    show "(cosSIN-COSK20 th)/XCMPLX-0K7 (sinSIN-COSK18 th) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos4_def_3 ("cosecSIN-COS4K3  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func cosecSIN-COS4K3 th \<rightarrow> RealXREAL-0M1 equals
  \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th)"
proof-
  (*coherence*)
    show "\<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef sin_cos4_def_4 ("secSIN-COS4K4  _ " [164]164 ) where
  mlet "th be RealXREAL-0M1"
"func secSIN-COS4K4 th \<rightarrow> RealXREAL-0M1 equals
  \<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK20 th)"
proof-
  (*coherence*)
    show "\<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK20 th) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem sin_cos4_th_1:
" for th be RealXREAL-0M1 holds tanSIN-COS4K1 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 th"
proof-
  have " for th be RealXREAL-0M1 holds tanSIN-COS4K1 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 th"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "tanSIN-COS4K1 (-XCMPLX-0K4 th) =HIDDENR1 (sinSIN-COSK18 (-XCMPLX-0K4 th))/XCMPLX-0K7 (cosSIN-COSK20 th)"
      using sin_cos_th_31 sorry
    also have "... = (-XCMPLX-0K4 sinSIN-COSK18 th)/XCMPLX-0K7 (cosSIN-COSK20 th)"
      using sin_cos_th_31 sorry
    also have "... = -XCMPLX-0K4 tanSIN-COS4K1 th"
      using xcmplx_1_th_187 sorry
    finally have "tanSIN-COS4K1 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 th"
       sorry
    thus "tanSIN-COS4K1 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 tanSIN-COS4K1 th"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_2:
" for th be RealXREAL-0M1 holds cosecSIN-COS4K3 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th)"
proof-
  have " for th be RealXREAL-0M1 holds cosecSIN-COS4K3 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th)"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "cosecSIN-COS4K3 (-XCMPLX-0K4 th) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 sinSIN-COSK18 th)"
      using sin_cos_th_31 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th)"
      using xcmplx_1_th_188 sorry
    finally have "cosecSIN-COS4K3 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th)"
       sorry
    thus "cosecSIN-COS4K3 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK18 th)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_3:
" for th be RealXREAL-0M1 holds cotSIN-COS4K2 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 cotSIN-COS4K2 th"
proof-
  have " for th be RealXREAL-0M1 holds cotSIN-COS4K2 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 cotSIN-COS4K2 th"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "cotSIN-COS4K2 (-XCMPLX-0K4 th) =HIDDENR1 (cosSIN-COSK20 th)/XCMPLX-0K7 (sinSIN-COSK18 (-XCMPLX-0K4 th))"
      using sin_cos_th_31 sorry
    also have "... = (cosSIN-COSK20 th)/XCMPLX-0K7 (-XCMPLX-0K4 sinSIN-COSK18 th)"
      using sin_cos_th_31 sorry
    also have "... = -XCMPLX-0K4 cotSIN-COS4K2 th"
      using xcmplx_1_th_188 sorry
    finally have "cotSIN-COS4K2 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 cotSIN-COS4K2 th"
       sorry
    thus "cotSIN-COS4K2 (-XCMPLX-0K4 th) =HIDDENR1 -XCMPLX-0K4 cotSIN-COS4K2 th"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_4:
" for th be RealXREAL-0M1 holds (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th)"
proof-
  have " for th be RealXREAL-0M1 holds (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th)"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "(sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) =HIDDENR1 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    also have "... = (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 ((sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) +XCMPLX-0K2 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th)))))"
      using sin_cos_th_29 sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th)"
       sorry
    finally have "(sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th)"
       sorry
    thus "(sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_5:
" for th be RealXREAL-0M1 holds (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th)"
proof-
  have " for th be RealXREAL-0M1 holds (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th)"
  proof(rule ballI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "(cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) =HIDDENR1 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    also have "... = (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 ((sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th) +XCMPLX-0K2 (cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th)))))"
      using sin_cos_th_29 sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th)"
       sorry
    finally have "(cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th)"
       sorry
    thus "(cosSIN-COSK20 th)*XCMPLX-0K3 (cosSIN-COSK20 th) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th)*XCMPLX-0K3 (sinSIN-COSK18 th)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_6:
" for th be RealXREAL-0M1 holds cosSIN-COSK20 th <>HIDDENR2 0NUMBERSK6 implies sinSIN-COSK18 th =HIDDENR1 (cosSIN-COSK20 th)*XCMPLX-0K3 (tanSIN-COS4K1 th)"
proof-
  have " for th be RealXREAL-0M1 holds cosSIN-COSK20 th <>HIDDENR2 0NUMBERSK6 implies sinSIN-COSK18 th =HIDDENR1 (cosSIN-COSK20 th)*XCMPLX-0K3 (tanSIN-COS4K1 th)"
  proof(rule ballI,rule impI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    assume "cosSIN-COSK20 th <>HIDDENR2 0NUMBERSK6"
    then have "sinSIN-COSK18 th =HIDDENR1 ((cosSIN-COSK20 th)/XCMPLX-0K7 (cosSIN-COSK20 th))*XCMPLX-0K3 (sinSIN-COSK18 th)"
      using xcmplx_1_th_88 sorry
    also have "... = (cosSIN-COSK20 th)*XCMPLX-0K3 (tanSIN-COS4K1 th)"
      using xcmplx_1_th_75 sorry
    finally have "sinSIN-COSK18 th =HIDDENR1 (cosSIN-COSK20 th)*XCMPLX-0K3 (tanSIN-COS4K1 th)"
       sorry
    thus "sinSIN-COSK18 th =HIDDENR1 (cosSIN-COSK20 th)*XCMPLX-0K3 (tanSIN-COS4K1 th)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_7:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (th1 +XCMPLX-0K2 th2) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (th1 +XCMPLX-0K2 th2) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6"
      and A2: "cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
    have "tanSIN-COS4K1 (th1 +XCMPLX-0K2 th2) =HIDDENR1 ((sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using A1 A2 xcmplx_1_th_55 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_62 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_120 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A2 xcmplx_1_th_88 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))/XCMPLX-0K7 (((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A1 xcmplx_1_th_88 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) -XCMPLX-0K6 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A2 xcmplx_1_th_88 sorry
    also have "... = (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
      using A1 xcmplx_1_th_60 sorry
    finally have "tanSIN-COS4K1 (th1 +XCMPLX-0K2 th2) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
    thus "tanSIN-COS4K1 (th1 +XCMPLX-0K2 th2) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_8:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6"
      and A2: "cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
    have "tanSIN-COS4K1 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((sinSIN-COSK18 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using A1 A2 xcmplx_1_th_55 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_31 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_31 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2)) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_31 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_31 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_120 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_62 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) -XCMPLX-0K6 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1)))/XCMPLX-0K7 (((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A2 xcmplx_1_th_88 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))/XCMPLX-0K7 (((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A1 xcmplx_1_th_88 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A2 xcmplx_1_th_88 sorry
    also have "... = (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
      using A1 xcmplx_1_th_60 sorry
    finally have "tanSIN-COS4K1 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
    thus "tanSIN-COS4K1 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_9:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (th1 +XCMPLX-0K2 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (th1 +XCMPLX-0K2 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6"
      and A2: "sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6"
    have "cotSIN-COS4K2 (th1 +XCMPLX-0K2 th2) =HIDDENR1 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using A1 A2 xcmplx_1_th_55 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_120 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_62 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 (sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))"
      using A2 xcmplx_1_th_88 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))"
      using A1 xcmplx_1_th_60 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))"
      using A1 xcmplx_1_th_88 sorry
    also have "... = ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1)"
      using A2 xcmplx_1_th_88 sorry
    finally have "cotSIN-COS4K2 (th1 +XCMPLX-0K2 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1)"
       sorry
    thus "cotSIN-COS4K2 (th1 +XCMPLX-0K2 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_10:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 -XCMPLX-0K6 cotSIN-COS4K2 th1)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 -XCMPLX-0K6 cotSIN-COS4K2 th1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6"
      and A2: "sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6"
    have "cotSIN-COS4K2 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using A1 A2 xcmplx_1_th_55 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using sin_cos_th_83 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using sin_cos_th_82 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_62 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_120 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 (sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))"
      using A2 xcmplx_1_th_88 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))"
      using A1 xcmplx_1_th_60 sorry
    also have "... = (((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2) -XCMPLX-0K6 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)))"
      using A1 xcmplx_1_th_88 sorry
    also have "... = ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 -XCMPLX-0K6 cotSIN-COS4K2 th1)"
      using A2 xcmplx_1_th_88 sorry
    finally have "cotSIN-COS4K2 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 -XCMPLX-0K6 cotSIN-COS4K2 th1)"
       sorry
    thus "cotSIN-COS4K2 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (cotSIN-COS4K2 th2 -XCMPLX-0K6 cotSIN-COS4K2 th1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_11:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6) & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6 implies sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & (cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6) implies sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6"
      and A2: "cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
      and A3: "cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6"
    have "sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 sinSIN-COSK18 (th1 +XCMPLX-0K2 (th2 +XCMPLX-0K2 th3))"
       sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 (th2 +XCMPLX-0K2 th3)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 (th2 +XCMPLX-0K2 th3))"
      using sin_cos_th_75 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 (th2 +XCMPLX-0K2 th3))"
      using sin_cos_th_75 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))+XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3))"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))+XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A1 sin_cos4_th_6 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))+XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A1 sin_cos4_th_6 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))+XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A2 sin_cos4_th_6 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th3))))+XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A3 sin_cos4_th_6 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th3))))+XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A2 sin_cos4_th_6 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1)) -XCMPLX-0K6 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2)))*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th3)))+XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th3))))"
      using A3 sin_cos4_th_6 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))"
       sorry
    finally have "sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))"
       sorry
    thus "sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_12:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6) & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & (cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6) implies cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6"
      and A2: "cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
      and A3: "cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6"
    have "cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 cosSIN-COSK20 (th1 +XCMPLX-0K2 (th2 +XCMPLX-0K2 th3))"
       sorry
    also have "... = (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 (th2 +XCMPLX-0K2 th3)) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 (th2 +XCMPLX-0K2 th3))"
      using sin_cos_th_75 sorry
    also have "... = (cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 (th2 +XCMPLX-0K2 th3))"
      using sin_cos_th_75 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3)))-XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3))"
      using sin_cos_th_75 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))-XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3))"
      using A2 sin_cos4_th_6 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th3))))-XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3))"
      using A3 sin_cos4_th_6 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th3))))-XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3))"
      using A1 sin_cos4_th_6 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3)) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th3))))-XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th3))"
      using A2 sin_cos4_th_6 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) -XCMPLX-0K6 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 ((tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3)))-XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th1))*XCMPLX-0K3 (((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (tanSIN-COS4K1 th2) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 ((cosSIN-COSK20 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th3)))"
      using A3 sin_cos4_th_6 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
    finally have "cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
    thus "cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_13:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6) & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))/XCMPLX-0K7 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6) & cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))/XCMPLX-0K7 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
      and A2: "cosSIN-COSK20 th3 <>HIDDENR2 0NUMBERSK6"
    have A3: "(cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    have "tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3)))/XCMPLX-0K7 (cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
      using A1 A2 sin_cos4_th_11 sorry
    also have "... = ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3)))/XCMPLX-0K7 ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2)))"
      using A1 A2 sin_cos4_th_12 sorry
    also have "... = ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3)))/XCMPLX-0K7 ((((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3)))"
      using xcmplx_1_th_84 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3)))"
      using A2 A3 xcmplx_1_th_60 sorry
    also have "... = (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))/XCMPLX-0K7 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
      using xcmplx_1_th_57 sorry
    finally have "tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))/XCMPLX-0K7 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
    thus "tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)+XCMPLX-0K2 tanSIN-COS4K1 th3)-XCMPLX-0K6 ((tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))*XCMPLX-0K3 (tanSIN-COS4K1 th3))/XCMPLX-0K7 (((\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th2)*XCMPLX-0K3 (tanSIN-COS4K1 th3))-XCMPLX-0K6 (tanSIN-COS4K1 th3)*XCMPLX-0K3 (tanSIN-COS4K1 th1))-XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_14:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds (sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6) & sinSIN-COSK18 th3 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((((cotSIN-COS4K2 th2)*XCMPLX-0K3 (cotSIN-COS4K2 th3) +XCMPLX-0K2 (cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th1))+XCMPLX-0K2 (cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))-XCMPLX-0K6 \<one>\<^sub>M)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & (sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th3 <>HIDDENR2 0NUMBERSK6) implies cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((((cotSIN-COS4K2 th2)*XCMPLX-0K3 (cotSIN-COS4K2 th3) +XCMPLX-0K2 (cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th1))+XCMPLX-0K2 (cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))-XCMPLX-0K6 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    assume A1: "sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6"
      and A2: "sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6"
      and A3: "sinSIN-COSK18 th3 <>HIDDENR2 0NUMBERSK6"
    have A4: "(sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) <>HIDDENR2 0NUMBERSK6"
      using A1 A2 sorry
    have "cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) -XCMPLX-0K6 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3))/XCMPLX-0K7 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) -XCMPLX-0K6 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3))/XCMPLX-0K7 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
      using sin_cos_th_75 sorry
    also have "... = ((cosSIN-COSK20 th3)*XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 (sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 th3)*XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 (sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A3 A4 xcmplx_1_th_55 sorry
    also have "... = (((cosSIN-COSK20 th3)*XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))) -XCMPLX-0K6 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using xcmplx_1_th_120 sorry
    also have "... = ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))) -XCMPLX-0K6 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using xcmplx_1_th_76 sorry
    also have "... = ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))) -XCMPLX-0K6 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using xcmplx_1_th_120 sorry
    also have "... = ((cotSIN-COS4K2 th3)*XCMPLX-0K3 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))) -XCMPLX-0K6 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 th3)*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using xcmplx_1_th_76 sorry
    also have "... = ((cotSIN-COS4K2 th3)*XCMPLX-0K3 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A1 A2 xcmplx_1_th_60 sorry
    also have "... = ((cotSIN-COS4K2 th3)*XCMPLX-0K3 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A3 xcmplx_1_th_91 sorry
    also have "... = ((cotSIN-COS4K2 th3)*XCMPLX-0K3 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using xcmplx_1_th_62 sorry
    also have "... = ((cotSIN-COS4K2 th3)*XCMPLX-0K3 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A1 xcmplx_1_th_91 sorry
    also have "... = ((cotSIN-COS4K2 th3)*XCMPLX-0K3 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2) -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 (cotSIN-COS4K2 th2 +XCMPLX-0K2 (cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1)))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using A2 xcmplx_1_th_91 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 (((sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using sin_cos_th_75 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 (((sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)) +XCMPLX-0K2 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)))"
      using xcmplx_1_th_62 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 (((sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using A3 xcmplx_1_th_91 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 ((sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))) +XCMPLX-0K2 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))) +XCMPLX-0K2 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))) +XCMPLX-0K2 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using xcmplx_1_th_62 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))) +XCMPLX-0K2 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using A1 xcmplx_1_th_91 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th2 +XCMPLX-0K2 (cosSIN-COSK20 th1)/XCMPLX-0K7 (sinSIN-COSK18 th1)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using A2 xcmplx_1_th_91 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1) +XCMPLX-0K2 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))"
      using xcmplx_1_th_120 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1) +XCMPLX-0K2 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 \<one>\<^sub>M))"
      using A1 A2 xcmplx_1_th_60 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th2 +XCMPLX-0K2 cotSIN-COS4K2 th1) +XCMPLX-0K2 ((cotSIN-COS4K2 th1)*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (sinSIN-COSK18 th2)) -XCMPLX-0K6 \<one>\<^sub>M))"
      using xcmplx_1_th_76 sorry
    also have "... = (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((((cotSIN-COS4K2 th2)*XCMPLX-0K3 (cotSIN-COS4K2 th3) +XCMPLX-0K2 (cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th1))+XCMPLX-0K2 (cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))-XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    finally have "cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((((cotSIN-COS4K2 th2)*XCMPLX-0K3 (cotSIN-COS4K2 th3) +XCMPLX-0K2 (cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th1))+XCMPLX-0K2 (cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))-XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    thus "cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) =HIDDENR1 (((((cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))*XCMPLX-0K3 (cotSIN-COS4K2 th3) -XCMPLX-0K6 cotSIN-COS4K2 th1)-XCMPLX-0K6 cotSIN-COS4K2 th2)-XCMPLX-0K6 cotSIN-COS4K2 th3)/XCMPLX-0K7 ((((cotSIN-COS4K2 th2)*XCMPLX-0K3 (cotSIN-COS4K2 th3) +XCMPLX-0K2 (cotSIN-COS4K2 th3)*XCMPLX-0K3 (cotSIN-COS4K2 th1))+XCMPLX-0K2 (cotSIN-COS4K2 th1)*XCMPLX-0K3 (cotSIN-COS4K2 th2))-XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_15:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2 =HIDDENR1 sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th1 /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    also have "... = ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))+XCMPLX-0K2 sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_75 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))) +XCMPLX-0K2 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_75 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))) +XCMPLX-0K2 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 \<one>\<^sub>M)"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))) +XCMPLX-0K2 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_75 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_83 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    finally have "sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    thus "sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_16:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2 =HIDDENR1 sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th1 /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    also have "... = ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))-XCMPLX-0K6 sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_75 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))) -XCMPLX-0K6 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_75 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))) -XCMPLX-0K6 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 \<one>\<^sub>M)"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))) +XCMPLX-0K2 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))-XCMPLX-0K6 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_82 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_75 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    finally have "sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    thus "sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_17:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2 =HIDDENR1 cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th1 /XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    also have "... = ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))+XCMPLX-0K2 cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)))+XCMPLX-0K2 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
       sorry
    also have "... = (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_29 sorry
    also have "... = ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))))+XCMPLX-0K2 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((-XCMPLX-0K4 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 \<one>\<^sub>M)"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))) +XCMPLX-0K2 (-XCMPLX-0K4 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 (((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))-XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))) +XCMPLX-0K2 (-XCMPLX-0K4 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))))"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_83 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_75 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    finally have "cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    thus "cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_18:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2 =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2 =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2 =HIDDENR1 cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th1 /XCMPLX-0K7 \<two>\<^sub>M) -XCMPLX-0K6 cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    also have "... = ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))-XCMPLX-0K6 cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M)"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)))-XCMPLX-0K6 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 ((-XCMPLX-0K4 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))+XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
       sorry
    also have "... = (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 ((-XCMPLX-0K4 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))+XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_29 sorry
    also have "... = ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))))+XCMPLX-0K2 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((-XCMPLX-0K4 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))+XCMPLX-0K2 ((-XCMPLX-0K4 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))+XCMPLX-0K2 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))) -XCMPLX-0K6 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_29 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))) +XCMPLX-0K2 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M))))"
       sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))) +XCMPLX-0K2 ((cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 ((cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M)))))))"
      using sin_cos_th_29 sorry
    also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 (((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M)))))*XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
       sorry
    also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 th2 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 (th2 /XCMPLX-0K7 \<two>\<^sub>M)) -XCMPLX-0K6 (cosSIN-COSK20 (th1 /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th2 /XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_75 sorry
    also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (th1 /XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 th2 /XCMPLX-0K7 \<two>\<^sub>M)))"
      using sin_cos_th_82 sorry
    also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    finally have "cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2 =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
    thus "cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2 =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_19:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
    then have "tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2 =HIDDENR1 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th1))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
      using xcmplx_1_th_116 sorry
    also have "... = (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
      using sin_cos_th_75 sorry
    finally have "tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
    thus "tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_20:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
    then have "tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2 =HIDDENR1 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th1))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
      using xcmplx_1_th_130 sorry
    also have "... = (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
      using sin_cos_th_82 sorry
    finally have "tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
    thus "tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2 =HIDDENR1 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_21:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6"
    then have "tanSIN-COS4K1 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using xcmplx_1_th_116 sorry
    also have "... = (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using sin_cos_th_83 sorry
    finally have "tanSIN-COS4K1 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    thus "tanSIN-COS4K1 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_22:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies tanSIN-COS4K1 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6"
    then have "tanSIN-COS4K1 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using xcmplx_1_th_130 sorry
    also have "... = (-XCMPLX-0K4 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    also have "... = -XCMPLX-0K4 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using xcmplx_1_th_187 sorry
    also have "... = -XCMPLX-0K4 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using sin_cos_th_75 sorry
    finally have "tanSIN-COS4K1 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    thus "tanSIN-COS4K1 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_23:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume "sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6"
    then have "cotSIN-COS4K2 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th1))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using xcmplx_1_th_116 sorry
    also have "... = (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using sin_cos_th_75 sorry
    finally have "cotSIN-COS4K2 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    thus "cotSIN-COS4K2 th1 +XCMPLX-0K2 cotSIN-COS4K2 th2 =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_24:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6 implies cotSIN-COS4K2 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume "sinSIN-COSK18 th1 <>HIDDENR2 0NUMBERSK6 & sinSIN-COSK18 th2 <>HIDDENR2 0NUMBERSK6"
    then have "cotSIN-COS4K2 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (cosSIN-COSK20 th2)*XCMPLX-0K3 (sinSIN-COSK18 th1))))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using xcmplx_1_th_130 sorry
    also have "... = (-XCMPLX-0K4 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    also have "... = (-XCMPLX-0K4 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using sin_cos_th_82 sorry
    also have "... = -XCMPLX-0K4 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using xcmplx_1_th_187 sorry
    finally have "cotSIN-COS4K2 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    thus "cotSIN-COS4K2 th1 -XCMPLX-0K6 cotSIN-COS4K2 th2 =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_25:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))+XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)"
      using sin_cos_th_75 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))+XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))"
      using sin_cos_th_82 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
    finally have "sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
    thus "sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_26:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))-XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)"
      using sin_cos_th_75 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))-XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))"
      using sin_cos_th_82 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    finally have "sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    thus "sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_27:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))+XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)"
      using sin_cos_th_75 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))+XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
      using sin_cos_th_83 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
    finally have "cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
    thus "cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_28:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))-XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)"
      using sin_cos_th_75 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))-XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using sin_cos_th_83 sorry
    also have "... = -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    finally have "cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    thus "cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_29:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))-XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))+XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2)) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))-XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))+XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_31 sorry
    also have "... = ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2)) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 th2))-XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))+XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2)) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2)))-XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))+XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_31 sorry
    also have "... = ((cosSIN-COSK20 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))+XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 \<two>\<^sub>M"
      using sin_cos_th_75 sorry
    also have "... = (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) -XCMPLX-0K6 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    also have "... = (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (\<two>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M)"
      using sin_cos_th_75 sorry
    also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
       sorry
    finally have "(sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
       sorry
    thus "(sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_30:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))+XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
       sorry
    finally have "(sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
       sorry
    thus "(sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_31:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))-XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2)) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
       sorry
    finally have "(cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
       sorry
    thus "(cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_32:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))+XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (-XCMPLX-0K4 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2)) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 th2))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))"
      using sin_cos_th_75 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
       sorry
    finally have "(cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
       sorry
    thus "(cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_33:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
  proof(rule ballI,rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    have "((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3) =HIDDENR1 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)))*XCMPLX-0K3 (sinSIN-COSK18 th3)"
      using sin_cos4_th_29 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3) -XCMPLX-0K6 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)+XCMPLX-0K2 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)-XCMPLX-0K6 th3)) -XCMPLX-0K6 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3))"
      using sin_cos4_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)+XCMPLX-0K2 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)-XCMPLX-0K6 th3)) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3)))"
      using sin_cos4_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 (-XCMPLX-0K4 sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)-XCMPLX-0K6 th3)))+XCMPLX-0K2 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3)))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 sinSIN-COSK18 (-XCMPLX-0K4 ((th1 -XCMPLX-0K6 th2)-XCMPLX-0K6 th3)))+XCMPLX-0K2 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3)))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
    finally have "((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
    thus "((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_34:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 ((((-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 ((((-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
  proof(rule ballI,rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    have "((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) -XCMPLX-0K6 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)))*XCMPLX-0K3 (cosSIN-COSK20 th3)"
      using sin_cos4_th_29 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) -XCMPLX-0K6 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)-XCMPLX-0K6 th3)) -XCMPLX-0K6 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))"
      using sin_cos4_th_32 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)-XCMPLX-0K6 th3)) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3)))"
      using sin_cos4_th_32 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 (((-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 cosSIN-COSK20 (-XCMPLX-0K4 ((th2 -XCMPLX-0K6 th1)+XCMPLX-0K2 th3)))+XCMPLX-0K2 (cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)+XCMPLX-0K2 (-XCMPLX-0K4 th2)) +XCMPLX-0K2 (-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 (((-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 cosSIN-COSK20 ((th2 -XCMPLX-0K6 th1)+XCMPLX-0K2 th3))+XCMPLX-0K2 (cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)+XCMPLX-0K2 (-XCMPLX-0K4 th2)) +XCMPLX-0K2 (-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 ((((-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
    finally have "((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 ((((-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
    thus "((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 ((((-XCMPLX-0K4 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))-XCMPLX-0K6 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_35:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
  proof(rule ballI,rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    have "((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)))*XCMPLX-0K3 (cosSIN-COSK20 th3)"
      using sin_cos4_th_30 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3)) +XCMPLX-0K2 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))"
      using sin_cos4_th_30 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3)) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)-XCMPLX-0K6 th3)))"
      using sin_cos4_th_30 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2))+XCMPLX-0K2 th3) +XCMPLX-0K2 sinSIN-COSK18 (-XCMPLX-0K4 ((th2 -XCMPLX-0K6 th1)+XCMPLX-0K2 th3))))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 ((-XCMPLX-0K4 sinSIN-COSK18 ((th2 -XCMPLX-0K6 th1)+XCMPLX-0K2 th3))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)+XCMPLX-0K2 (-XCMPLX-0K4 th2))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
    finally have "((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
    thus "((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) -XCMPLX-0K6 sinSIN-COSK18 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 sinSIN-COSK18 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_36:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds  for th3 be RealXREAL-0M1 holds ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
  proof(rule ballI,rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    fix th3 assume [ty]: "th3 be RealXREAL-0M1"
    have "((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2) +XCMPLX-0K2 cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)))*XCMPLX-0K3 (cosSIN-COSK20 th3)"
      using sin_cos4_th_32 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) +XCMPLX-0K2 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3)) +XCMPLX-0K2 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3))"
      using sin_cos4_th_32 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3)) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)-XCMPLX-0K6 th3)))"
      using sin_cos4_th_32 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 (cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)+XCMPLX-0K2 (-XCMPLX-0K4 th2)) +XCMPLX-0K2 cosSIN-COSK20 (-XCMPLX-0K4 ((th2 -XCMPLX-0K6 th1)+XCMPLX-0K2 th3))))"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3))+XCMPLX-0K2 (cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2) +XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)+XCMPLX-0K2 (-XCMPLX-0K4 th1))))"
      using sin_cos_th_31 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
    finally have "((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M))*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
    thus "((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (cosSIN-COSK20 th3) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)-XCMPLX-0K6 th3) +XCMPLX-0K2 cosSIN-COSK20 ((th2 +XCMPLX-0K2 th3)-XCMPLX-0K6 th1))+XCMPLX-0K2 cosSIN-COSK20 ((th3 +XCMPLX-0K2 th1)-XCMPLX-0K6 th2))+XCMPLX-0K2 cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)+XCMPLX-0K2 th3))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_37:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
      using sin_cos_th_75 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))))"
      using sin_cos_th_82 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)) -XCMPLX-0K6 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 th1))*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)) -XCMPLX-0K6 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th2)"
      using sin_cos4_th_5 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2))) -XCMPLX-0K6 ((\<one>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1))))*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th2)"
      using sin_cos4_th_5 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
    finally have "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
    thus "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_38:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1)"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
      using sin_cos4_th_37 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))-XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
      using sin_cos4_th_4 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))))-XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2))))"
      using sin_cos4_th_4 sorry
    also have "... = (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1)"
       sorry
    finally have "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1)"
       sorry
    thus "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_39:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
      using sin_cos_th_75 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using sin_cos_th_83 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2) +XCMPLX-0K2 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 (((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1)) +XCMPLX-0K2 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1)))"
       sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))"
      using sin_cos_th_29 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M)"
      using sin_cos_th_29 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
       sorry
    finally have "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
       sorry
    thus "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_40:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2)))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 (-XCMPLX-0K4 th2)))"
       sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 (-XCMPLX-0K4 th2))*XCMPLX-0K3 (cosSIN-COSK20 (-XCMPLX-0K4 th2))"
      using sin_cos4_th_39 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 (-XCMPLX-0K4 th2))*XCMPLX-0K3 (cosSIN-COSK20 th2)"
      using sin_cos_th_31 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (-XCMPLX-0K4 sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
      using sin_cos_th_31 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
       sorry
    finally have "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
       sorry
    thus "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_41:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
      using sin_cos_th_75 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))*XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using sin_cos_th_83 sorry
    also have "... = ((((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))*XCMPLX-0K3 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))+XCMPLX-0K2 (-XCMPLX-0K4 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))))+XCMPLX-0K2 (-XCMPLX-0K4 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1))*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (sinSIN-COSK18 th2))"
       sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)))) +XCMPLX-0K2 (-XCMPLX-0K4 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)))"
      using sin_cos4_th_5 sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (-XCMPLX-0K4 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1)))"
       sorry
    also have "... = ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using sin_cos_th_29 sorry
    also have "... = (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
    finally have "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
    thus "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_42:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1)"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th1) -XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
      using sin_cos4_th_41 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1))-XCMPLX-0K6 (sinSIN-COSK18 th2)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
      using sin_cos4_th_5 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1))-XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2))"
      using sin_cos4_th_4 sorry
    also have "... = (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1)"
       sorry
    finally have "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1)"
       sorry
    thus "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))*XCMPLX-0K3 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (cosSIN-COSK20 th2)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_43:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6"
      and A2: "cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
    have "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2))"
      using sin_cos_th_75 sorry
    also have "... = ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))"
      using sin_cos_th_82 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using A1 A2 xcmplx_1_th_55 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (-XCMPLX-0K4 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_62 sorry
    also have "... = (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 (-XCMPLX-0K4 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_62 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 (-XCMPLX-0K4 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 (-XCMPLX-0K4 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((-XCMPLX-0K4 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((-XCMPLX-0K4 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A2 xcmplx_1_th_88 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))/XCMPLX-0K7 (((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((-XCMPLX-0K4 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A1 xcmplx_1_th_88 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 ((cosSIN-COSK20 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1))*XCMPLX-0K3 ((-XCMPLX-0K4 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using A2 xcmplx_1_th_88 sorry
    also have "... = ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 (sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((sinSIN-COSK18 th1)/XCMPLX-0K7 (cosSIN-COSK20 th1) +XCMPLX-0K2 (-XCMPLX-0K4 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2))"
      using A1 xcmplx_1_th_88 sorry
    also have "... = (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (tanSIN-COS4K1 th1 +XCMPLX-0K2 (-XCMPLX-0K4 (sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_187 sorry
    also have "... = (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)"
       sorry
    finally have "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)"
       sorry
    thus "(sinSIN-COSK18 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (sinSIN-COSK18 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (tanSIN-COS4K1 th1 +XCMPLX-0K2 tanSIN-COS4K1 th2)/XCMPLX-0K7 (tanSIN-COS4K1 th1 -XCMPLX-0K6 tanSIN-COS4K1 th2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_44:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 th1 <>HIDDENR2 0NUMBERSK6 & cosSIN-COSK20 th2 <>HIDDENR2 0NUMBERSK6"
    have "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))"
      using sin_cos_th_75 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using A1 xcmplx_1_th_55 sorry
    also have "... = (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_120 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using A1 xcmplx_1_th_60 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 ((sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2)))/XCMPLX-0K7 ((cosSIN-COSK20 (th1 -XCMPLX-0K6 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_76 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using sin_cos_th_83 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)) +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using xcmplx_1_th_62 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ((sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2))/XCMPLX-0K7 ((cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2)))"
      using A1 xcmplx_1_th_60 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
      using xcmplx_1_th_76 sorry
    finally have "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
    thus "(cosSIN-COSK20 (th1 +XCMPLX-0K2 th2))/XCMPLX-0K7 (cosSIN-COSK20 (th1 -XCMPLX-0K6 th2)) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (tanSIN-COS4K1 th1)*XCMPLX-0K3 (tanSIN-COS4K1 th2))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_45:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2) =HIDDENR1 (tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2) =HIDDENR1 (tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)"
      using sin_cos4_th_15 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos4_th_16 sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))/XCMPLX-0K7 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using xcmplx_1_th_76 sorry
    also have "... = (tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))"
      using xcmplx_1_th_76 sorry
    finally have "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2) =HIDDENR1 (tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    thus "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2) =HIDDENR1 (tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_46:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
    have "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2)"
      using sin_cos4_th_15 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos4_th_17 sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))/XCMPLX-0K7 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using xcmplx_1_th_76 sorry
    also have "... = ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
      using xcmplx_1_th_76 sorry
    also have "... = tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 xcmplx_1_th_88 sorry
    finally have "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    thus "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_47:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
    have "(sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2)"
      using sin_cos4_th_16 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos4_th_17 sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))/XCMPLX-0K7 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using xcmplx_1_th_76 sorry
    also have "... = ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
      using xcmplx_1_th_76 sorry
    also have "... = tanSIN-COS4K1 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 xcmplx_1_th_88 sorry
    finally have "(sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    thus "(sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2) =HIDDENR1 tanSIN-COS4K1 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_48:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
    have "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1)"
      using sin_cos4_th_15 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos4_th_18 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))))"
       sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 (th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_31 sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))/XCMPLX-0K7 ((sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using xcmplx_1_th_76 sorry
    also have "... = ((cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M)))"
      using xcmplx_1_th_76 sorry
    also have "... = cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 xcmplx_1_th_88 sorry
    finally have "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    thus "(sinSIN-COSK18 th1 +XCMPLX-0K2 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_49:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies (sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    assume A1: "sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
    have "(sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1)"
      using sin_cos4_th_16 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos4_th_18 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))))"
       sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 (th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_31 sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))/XCMPLX-0K7 ((sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using xcmplx_1_th_76 sorry
    also have "... = ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (sinSIN-COSK18 ((th2 +XCMPLX-0K2 th1)/XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))"
      using xcmplx_1_th_76 sorry
    also have "... = cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 xcmplx_1_th_88 sorry
    finally have "(sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    thus "(sinSIN-COSK18 th1 -XCMPLX-0K6 sinSIN-COSK18 th2)/XCMPLX-0K7 (cosSIN-COSK20 th2 -XCMPLX-0K6 cosSIN-COSK20 th1) =HIDDENR1 cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem sin_cos4_th_50:
" for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2) =HIDDENR1 (cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds (cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2) =HIDDENR1 (cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))"
  proof(rule ballI,rule ballI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "(cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2)"
      using sin_cos4_th_17 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos4_th_18 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
       sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 (-XCMPLX-0K4 (th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using sin_cos_th_31 sorry
    also have "... = (\<two>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cosSIN-COSK20 ((th1 -XCMPLX-0K6 th2)/XCMPLX-0K7 \<two>\<^sub>M)))/XCMPLX-0K7 ((sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sinSIN-COSK18 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))))"
      using xcmplx_1_th_76 sorry
    also have "... = ((cosSIN-COSK20 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (sinSIN-COSK18 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M)))*XCMPLX-0K3 ((cosSIN-COSK20 (-XCMPLX-0K4 (th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (sinSIN-COSK18 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M)))"
      using xcmplx_1_th_76 sorry
    also have "... = (cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))"
      using sin_cos_th_31 sorry
    finally have "(cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2) =HIDDENR1 (cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
    thus "(cosSIN-COSK20 th1 +XCMPLX-0K2 cosSIN-COSK20 th2)/XCMPLX-0K7 (cosSIN-COSK20 th1 -XCMPLX-0K6 cosSIN-COSK20 th2) =HIDDENR1 (cotSIN-COS4K2 ((th1 +XCMPLX-0K2 th2)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (cotSIN-COS4K2 ((th2 -XCMPLX-0K6 th1)/XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
