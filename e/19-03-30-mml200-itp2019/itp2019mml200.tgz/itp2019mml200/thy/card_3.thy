theory card_3
  imports wellord1 finsub_1 pboole funct_5 grfunc_1 ordinal3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve A, B, C for "OrdinalORDINAL1M3"
reserve K, L, M, N for "CardinalCARD-1M1"
reserve x, y, y1, y2, z, u for "objectHIDDENM1"
reserve X, Y, Z, Z1, Z2 for "setHIDDENM2"
reserve f, f1, g, h for "FunctionFUNCT-1M1"
reserve Q, R for "RelationRELAT-1M1"
mdef card_3_def_1 ("Cardinal-yieldingCARD-3V1" 70 ) where
"attr Cardinal-yieldingCARD-3V1 for FunctionFUNCT-1M1 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 IT implies IT .FUNCT-1K1 x be CardinalCARD-1M1)"..

mtheorem card_3_cl_1:
"cluster emptyXBOOLE-0V1 also-is Cardinal-yieldingCARD-3V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be Cardinal-yieldingCARD-3V1"
     sorry
qed "sorry"

mtheorem card_3_cl_2:
"cluster Cardinal-yieldingCARD-3V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be Cardinal-yieldingCARD-3V1"
  proof-
    have " ex tVar1 be FunctionFUNCT-1M1 st tVar1 be Cardinal-yieldingCARD-3V1"
    proof-
      show " ex tVar1 be FunctionFUNCT-1M1 st tVar1 be Cardinal-yieldingCARD-3V1"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "{}XBOOLE-0K1 be Cardinal-yieldingCARD-3V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax CARD_3M1 :: "Ty" ("Cardinal-FunctionCARD-3M1" 70)
translations "Cardinal-FunctionCARD-3M1" \<rightharpoonup> "Cardinal-yieldingCARD-3V1\<bar>FunctionFUNCT-1M1"

reserve ff for "Cardinal-FunctionCARD-3M1"
mtheorem card_3_cl_3:
  mlet "ff be Cardinal-FunctionCARD-3M1", "X be setHIDDENM2"
"cluster ff  |RELAT-1K8 X as-term-is Cardinal-yieldingCARD-3V1"
proof
(*coherence*)
  show "ff  |RELAT-1K8 X be Cardinal-yieldingCARD-3V1"
  proof-
    have "ff  |RELAT-1K8 X be Cardinal-yieldingCARD-3V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (ff  |RELAT-1K8 X) implies (ff  |RELAT-1K8 X).FUNCT-1K1 x be CardinalCARD-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 domRELAT-1K1 (ff  |RELAT-1K8 X)"
        then have A2: "(ff  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 ff .FUNCT-1K1 x"
          using funct_1_th_47 sorry
        have "domRELAT-1K1 (ff  |RELAT-1K8 X) =XBOOLE-0R4 domRELAT-1K1 ff /\\XBOOLE-0K3 X"
          using relat_1_th_61 sorry
        then have "x inHIDDENR3 domRELAT-1K1 ff"
          using A1 xboole_0_def_4 sorry
        thus "(ff  |RELAT-1K8 X).FUNCT-1K1 x be CardinalCARD-1M1"
          using A2 card_3_def_1 sorry
      qed "sorry"
      thus "ff  |RELAT-1K8 X be Cardinal-yieldingCARD-3V1"
        using card_3_def_1 sorry
    qed
    thus "ff  |RELAT-1K8 X be Cardinal-yieldingCARD-3V1"
       sorry
  qed
qed "sorry"

mtheorem card_3_cl_4:
  mlet "X be setHIDDENM2", "K be CardinalCARD-1M1"
"cluster X -->FUNCOP-1K7 K as-term-is Cardinal-yieldingCARD-3V1"
proof
(*coherence*)
  show "X -->FUNCOP-1K7 K be Cardinal-yieldingCARD-3V1"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 K) implies (X -->FUNCOP-1K7 K).FUNCT-1K1 x be CardinalCARD-1M1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 K)"
      thus "(X -->FUNCOP-1K7 K).FUNCT-1K1 x be CardinalCARD-1M1"
        using funcop_1_th_7 sorry
    qed "sorry"
    thus "X -->FUNCOP-1K7 K be Cardinal-yieldingCARD-3V1"
      using card_3_def_1 sorry
  qed
qed "sorry"

mtheorem card_3_cl_5:
  mlet "X be objectHIDDENM1", "K be CardinalCARD-1M1"
"cluster X .-->FUNCOP-1K17 K as-term-is Cardinal-yieldingCARD-3V1"
proof
(*coherence*)
  show "X .-->FUNCOP-1K17 K be Cardinal-yieldingCARD-3V1"
     sorry
qed "sorry"

theorem card_3_sch_1:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be CardinalCARD-1M1"
  shows " ex ff be Cardinal-FunctionCARD-3M1 st domRELAT-1K1 ff =XBOOLE-0R4 Af0 & ( for x be setHIDDENM2 holds x inTARSKIR2 Af0 implies ff .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x))"
  proof-
    have " ex tVar2 be Cardinal-FunctionCARD-3M1 st domRELAT-1K1 tVar2 =XBOOLE-0R4 Af0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Af0 &  not tVar2 .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x))"
        using funct_1_sch_3 sorry
      have "f be Cardinal-yieldingCARD-3V1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be CardinalCARD-1M1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)"
            using A1 sorry
          thus "f .FUNCT-1K1 x be CardinalCARD-1M1"
             sorry
        qed "sorry"
        thus "f be Cardinal-yieldingCARD-3V1"
          using card_3_def_1 sorry
      qed
      then have 
        [ty]:"f be Cardinal-FunctionCARD-3M1"
         sorry
      show " ex tVar2 be Cardinal-FunctionCARD-3M1 st domRELAT-1K1 tVar2 =XBOOLE-0R4 Af0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Af0 &  not tVar2 .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)))"
      proof(rule bexI[of _ "f"])
        show "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Af0 &  not f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)))"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef card_3_def_2 ("CardCARD-3K1  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func CardCARD-3K1 f \<rightarrow> Cardinal-FunctionCARD-3M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be Cardinal-FunctionCARD-3M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x))"
    proof-
      have " ex tVar3 be Cardinal-FunctionCARD-3M1 st domRELAT-1K1 tVar3 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies tVar3 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x))"
      proof-
        let ?f = "\<lambda>Lamb1. cardCARD-1K1 (f .FUNCT-1K1 Lamb1)"
        obtain g where
          [ty]:"g be Cardinal-FunctionCARD-3M1" and 
          A1: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"and A2: " for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies g .FUNCT-1K1 x =XBOOLE-0R4 ?f(x)"
          using card_3_sch_1 sorry
        show " ex tVar3 be Cardinal-FunctionCARD-3M1 st domRELAT-1K1 tVar3 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies tVar3 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x))"
        proof(rule bexI[of _ "g"],rule conjMI,rule ballI,rule impI)
          show "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
            using A1 sorry
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 domRELAT-1K1 f"
          have 
            [ty]:"x be setHIDDENM2"
            using tarski_th_1 sorry
          have "g .FUNCT-1K1 x =XBOOLE-0R4 ?f(x)"
            using A3 A2 sorry
          thus "g .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Cardinal-FunctionCARD-3M1 holds  for it2 be Cardinal-FunctionCARD-3M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it1 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it2 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
    proof-
      have " for a1 be Cardinal-FunctionCARD-3M1 holds  for a2 be Cardinal-FunctionCARD-3M1 holds domRELAT-1K1 a1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a1 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x)) & (domRELAT-1K1 a2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a2 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x)))) implies a1 =HIDDENR1 a2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix a1 assume [ty]: "a1 be Cardinal-FunctionCARD-3M1"
        fix a2 assume [ty]: "a2 be Cardinal-FunctionCARD-3M1"
        assume A4: "domRELAT-1K1 a1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a1 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x)"
          and A6: "domRELAT-1K1 a2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a2 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a1 .FUNCT-1K1 x =XBOOLE-0R4 a2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A8: "x inHIDDENR3 domRELAT-1K1 f"
          then have "a1 .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x)"
            using A5 sorry
          thus "a1 .FUNCT-1K1 x =XBOOLE-0R4 a2 .FUNCT-1K1 x"
            using A7 A8 sorry
        qed "sorry"
        thus "a1 =HIDDENR1 a2"
          using A4 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef card_3_def_3 ("disjoinCARD-3K2  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func disjoinCARD-3K2 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :])"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :])"
    proof-
      have " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :])"
      proof-
        let ?f = "\<lambda>Lamb1. [:ZFMISC-1K2 f .FUNCT-1K1 Lamb1,{TARSKIK1 Lamb1} :]"
        show " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :])"
          using funct_1_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it1 .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :])) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it2 .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :])) implies it1 =HIDDENR1 it2"
    proof-
      have " for a1 be FunctionFUNCT-1M1 holds  for a2 be FunctionFUNCT-1M1 holds domRELAT-1K1 a1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a1 .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :]) & (domRELAT-1K1 a2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a2 .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :]))) implies a1 =HIDDENR1 a2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix a1 assume [ty]: "a1 be FunctionFUNCT-1M1"
        fix a2 assume [ty]: "a2 be FunctionFUNCT-1M1"
        assume A9: "domRELAT-1K1 a1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A10: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a1 .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :]"
          and A11: "domRELAT-1K1 a2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A12: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a2 .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :]"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies a1 .FUNCT-1K1 x =XBOOLE-0R4 a2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A13: "x inHIDDENR3 domRELAT-1K1 f"
          then have "a1 .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :]"
            using A10 sorry
          thus "a1 .FUNCT-1K1 x =XBOOLE-0R4 a2 .FUNCT-1K1 x"
            using A12 A13 sorry
        qed "sorry"
        thus "a1 =HIDDENR1 a2"
          using A9 A11 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef card_3_def_4 ("UnionCARD-3K3  _ " [164]164 ) where
  mlet "f be FunctionFUNCT-1M1"
"func UnionCARD-3K3 f \<rightarrow> setHIDDENM2 equals
  unionTARSKIK3 (rngFUNCT-1K2 f)"
proof-
  (*coherence*)
    show "unionTARSKIK3 (rngFUNCT-1K2 f) be setHIDDENM2"
       sorry
qed "sorry"

mdef card_3_def_5 ("productCARD-3K4  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func productCARD-3K4 f \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 y))"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 y))"
    proof-
      let ?P = "\<lambda>Lamb1.  ex g be FunctionFUNCT-1M1 st (Lamb1 =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
      show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 y))"
      proof-
        have " ex tVar4 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar4 implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))) & (( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)) implies x inHIDDENR3 tVar4)"
        proof-
          obtain X where
            [ty]:"X be setHIDDENM2" and 
            A14: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 FuncsFUNCT-2K1(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f)) & ?P(x)"
            using xboole_0_sch_1 sorry
          show " ex tVar4 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar4 implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))) & (( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)) implies x inHIDDENR3 tVar4)"
          proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 X implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
              using A14 sorry
            assume Given: " ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A15: "x =HIDDENR1 g"and A16: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"and A17: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
               sorry
            have "rngFUNCT-1K2 g c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 f)"
            proof-
              have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume "y inHIDDENR3 rngFUNCT-1K2 g"
                then obtain z where
                  [ty]:"z be objectHIDDENM1" and 
                  A18: "z inHIDDENR3 domRELAT-1K1 g"and A19: "y =HIDDENR1 g .FUNCT-1K1 z"
                  using funct_1_def_3 sorry
                have A20: "y inHIDDENR3 f .FUNCT-1K1 z"
                  using A16 A17 A18 A19 sorry
                have "f .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
                  using A16 A18 funct_1_def_3 sorry
                thus "y inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
                  using A20 tarski_def_4 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 g c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 f)"
                using tarski_def_3 sorry
            qed
            then have "x inHIDDENR3 FuncsFUNCT-2K1(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
              using A15 A16 funct_2_def_2 sorry
            thus "x inHIDDENR3 X"
              using A14 A15 A16 A17 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 y))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 y))) implies it1 =HIDDENR1 it2"
    proof-
      let ?P = "\<lambda>Lamb1.  ex g be FunctionFUNCT-1M1 st (Lamb1 =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
      show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 y))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 y))) implies it1 =HIDDENR1 it2"
      proof-
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 xc inTARSKIR2 f .FUNCT-1K1 xc))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 xc inTARSKIR2 f .FUNCT-1K1 xc))) implies X1 =HIDDENR1 X2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix X1 assume [ty]: "X1 be setHIDDENM2"
          fix X2 assume [ty]: "X2 be setHIDDENM2"
          assume A21: " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ?P(x)"
            and A22: " for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ?P(x)"
          show "X1 =HIDDENR1 X2"
            using xboole_0_sch_2 A21 A22 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem card_3_th_1:
" for ff be Cardinal-FunctionCARD-3M1 holds CardCARD-3K1 ff =FUNCT-1R1 ff"
proof-
  have " for ff be Cardinal-FunctionCARD-3M1 holds CardCARD-3K1 ff =FUNCT-1R1 ff"
  proof(rule ballI)
    fix ff assume [ty]: "ff be Cardinal-FunctionCARD-3M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ff implies ff .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (ff .FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 ff"
      then obtain M where 
        [ty]:"M be CardinalCARD-1M1" and MDef:"M = ff .FUNCT-1K1 x"
        using card_3_def_1 sorry
      have "cardCARD-1K1 M =XBOOLE-0R4 M"
         sorry
      thus "ff .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (ff .FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "CardCARD-3K1 ff =FUNCT-1R1 ff"
      using card_3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds CardCARD-3K1 (X -->FUNCOP-1K7 Y) =FUNCT-1R1 X -->FUNCOP-1K7 cardCARD-1K1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds CardCARD-3K1 (X -->FUNCOP-1K7 Y) =FUNCT-1R1 X -->FUNCOP-1K7 cardCARD-1K1 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "domRELAT-1K1 (CardCARD-3K1 (X -->FUNCOP-1K7 Y)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 Y)"
      using card_3_def_2 sorry
    then have A2: "domRELAT-1K1 (CardCARD-3K1 (X -->FUNCOP-1K7 Y)) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    have A3: "domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 cardCARD-1K1 Y) =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies CardCARD-3K1 (X -->FUNCOP-1K7 Y) .FUNCT-1K1 x =XBOOLE-0R4 (X -->FUNCOP-1K7 cardCARD-1K1 Y).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 X"
      then have A5: "CardCARD-3K1 (X -->FUNCOP-1K7 Y) .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 ((X -->FUNCOP-1K7 Y).FUNCT-1K1 x)"
        using A1 A2 card_3_def_2 sorry
      have "(X -->FUNCOP-1K7 cardCARD-1K1 Y).FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 Y"
        using A4 funcop_1_th_7 sorry
      thus "CardCARD-3K1 (X -->FUNCOP-1K7 Y) .FUNCT-1K1 x =XBOOLE-0R4 (X -->FUNCOP-1K7 cardCARD-1K1 Y).FUNCT-1K1 x"
        using A4 A5 funcop_1_th_7 sorry
    qed "sorry"
    thus "CardCARD-3K1 (X -->FUNCOP-1K7 Y) =FUNCT-1R1 X -->FUNCOP-1K7 cardCARD-1K1 Y"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_3:
"disjoinCARD-3K2 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
  using card_3_def_3 relat_1_th_38 sorry

mtheorem card_3_th_4:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds disjoinCARD-3K2 (x .-->FUNCOP-1K17 X) =FUNCT-1R1 x .-->FUNCOP-1K17 ([:ZFMISC-1K2 X,{TARSKIK1 x} :])"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds disjoinCARD-3K2 (x .-->FUNCOP-1K17 X) =FUNCT-1R1 x .-->FUNCOP-1K17 ([:ZFMISC-1K2 X,{TARSKIK1 x} :])"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "domRELAT-1K1 (disjoinCARD-3K2 ({TARSKIK1 x} -->FUNCOP-1K7 X)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> ({TARSKIK1 x} -->FUNCOP-1K7 X)"
      using card_3_def_3 sorry
    have A2: "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> ({TARSKIK1 x} -->FUNCOP-1K7 X) =XBOOLE-0R4 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    have A3: "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> ({TARSKIK1 x} -->FUNCOP-1K7 [:ZFMISC-1K2 X,{TARSKIK1 x} :]) =XBOOLE-0R4 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies disjoinCARD-3K2 ({TARSKIK1 x} -->FUNCOP-1K7 X) .FUNCT-1K1 y =XBOOLE-0R4 ({TARSKIK1 x} -->FUNCOP-1K7 [:ZFMISC-1K2 X,{TARSKIK1 x} :]).FUNCT-1K1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A4: "y inHIDDENR3 {TARSKIK1 x}"
      then have A5: "disjoinCARD-3K2 ({TARSKIK1 x} -->FUNCOP-1K7 X) .FUNCT-1K1 y =XBOOLE-0R4 [:ZFMISC-1K2 ({TARSKIK1 x} -->FUNCOP-1K7 X).FUNCT-1K1 y,{TARSKIK1 y} :]"
        using A2 card_3_def_3 sorry
      have A6: "({TARSKIK1 x} -->FUNCOP-1K7 X).FUNCT-1K1 y =XBOOLE-0R4 X"
        using A4 funcop_1_th_7 sorry
      have "({TARSKIK1 x} -->FUNCOP-1K7 [:ZFMISC-1K2 X,{TARSKIK1 x} :]).FUNCT-1K1 y =XBOOLE-0R4 [:ZFMISC-1K2 X,{TARSKIK1 x} :]"
        using A4 funcop_1_th_7 sorry
      thus "disjoinCARD-3K2 ({TARSKIK1 x} -->FUNCOP-1K7 X) .FUNCT-1K1 y =XBOOLE-0R4 ({TARSKIK1 x} -->FUNCOP-1K7 [:ZFMISC-1K2 X,{TARSKIK1 x} :]).FUNCT-1K1 y"
        using A4 A5 A6 tarski_def_1 sorry
    qed "sorry"
    thus "disjoinCARD-3K2 (x .-->FUNCOP-1K17 X) =FUNCT-1R1 x .-->FUNCOP-1K17 ([:ZFMISC-1K2 X,{TARSKIK1 x} :])"
      using A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_5:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & x <>HIDDENR2 y implies disjoinCARD-3K2 f .FUNCT-1K1 x missesXBOOLE-0R1 disjoinCARD-3K2 f .FUNCT-1K1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & (y inHIDDENR3 domRELAT-1K1 f & x <>HIDDENR2 y) implies disjoinCARD-3K2 f .FUNCT-1K1 x missesXBOOLE-0R1 disjoinCARD-3K2 f .FUNCT-1K1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
      and A2: "y inHIDDENR3 domRELAT-1K1 f"
      and A3: "x <>HIDDENR2 y"
    let ?z = "the ElementSUBSET-1M1-of disjoinCARD-3K2 f .FUNCT-1K1 x /\\XBOOLE-0K3 disjoinCARD-3K2 f .FUNCT-1K1 y"
    have "disjoinCARD-3K2 f .FUNCT-1K1 x /\\XBOOLE-0K3 disjoinCARD-3K2 f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume A4: "disjoinCARD-3K2 f .FUNCT-1K1 x /\\XBOOLE-0K3 disjoinCARD-3K2 f .FUNCT-1K1 y <>HIDDENR2 {}XBOOLE-0K1"
      have A5: "disjoinCARD-3K2 f .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :]"
        using A1 card_3_def_3 sorry
      have A6: "disjoinCARD-3K2 f .FUNCT-1K1 y =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 y,{TARSKIK1 y} :]"
        using A2 card_3_def_3 sorry
      have A7: "?z inTARSKIR2 disjoinCARD-3K2 f .FUNCT-1K1 x"
        using A4 xboole_0_def_4 sorry
      have A8: "?z inTARSKIR2 disjoinCARD-3K2 f .FUNCT-1K1 y"
        using A4 xboole_0_def_4 sorry
      have A9: "?z `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 x}"
        using A5 A7 mcart_1_th_10 sorry
      have A10: "?z `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 y}"
        using A6 A8 mcart_1_th_10 sorry
      have "?z `2XTUPLE-0K2 =HIDDENR1 x"
        using A9 tarski_def_1 sorry
      thus " False "
        using A3 A10 tarski_def_1 sorry
    qed
    thus "disjoinCARD-3K2 f .FUNCT-1K1 x missesXBOOLE-0R1 disjoinCARD-3K2 f .FUNCT-1K1 y"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds UnionCARD-3K3 (X -->FUNCOP-1K7 Y) c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds UnionCARD-3K3 (X -->FUNCOP-1K7 Y) c=TARSKIR1 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 (X -->FUNCOP-1K7 Y) implies x inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 UnionCARD-3K3 (X -->FUNCOP-1K7 Y)"
      then obtain Z where
        [ty]:"Z be setHIDDENM2" and 
        A1: "x inHIDDENR3 Z"and A2: "Z inTARSKIR2 rngRELSET-1K2\<^bsub>({TARSKIK1 Y})\<^esub> (X -->FUNCOP-1K7 Y)"
        using tarski_def_4 sorry
      have " ex z be objectHIDDENM1 st z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 Y) & Z =XBOOLE-0R4 (X -->FUNCOP-1K7 Y).FUNCT-1K1 z"
        using A2 funct_1_def_3 sorry
      thus "x inHIDDENR3 Y"
        using A1 funcop_1_th_7 sorry
    qed "sorry"
    thus "UnionCARD-3K3 (X -->FUNCOP-1K7 Y) c=TARSKIR1 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies UnionCARD-3K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies UnionCARD-3K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    let ?x = "the ElementSUBSET-1M1-of X"
    have "UnionCARD-3K3 (X -->FUNCOP-1K7 Y) c=TARSKIR1 Y & Y c=TARSKIR1 UnionCARD-3K3 (X -->FUNCOP-1K7 Y)"
    proof(rule conjMI)
      show "UnionCARD-3K3 (X -->FUNCOP-1K7 Y) c=TARSKIR1 Y"
        using card_3_th_6 sorry
      have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 X"
        using funcop_1_th_13 sorry
      have "(X -->FUNCOP-1K7 Y).FUNCT-1K1 ?x =XBOOLE-0R4 Y"
        using A1 funcop_1_th_7 sorry
      then have "Y inTARSKIR2 rngRELSET-1K2\<^bsub>({TARSKIK1 Y})\<^esub> (X -->FUNCOP-1K7 Y)"
        using A1 A2 funct_1_def_3 sorry
      thus "Y c=TARSKIR1 UnionCARD-3K3 (X -->FUNCOP-1K7 Y)"
        using zfmisc_1_th_74 sorry
    qed
    thus "UnionCARD-3K3 (X -->FUNCOP-1K7 Y) =XBOOLE-0R4 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_8:
" for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds UnionCARD-3K3 (x .-->FUNCOP-1K17 Y) =XBOOLE-0R4 Y"
  using card_3_th_7 sorry

mtheorem card_3_th_9:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 f iff domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (g inTARSKIR2 productCARD-3K4 f implies domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)) &  not ((domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))) &  not g inTARSKIR2 productCARD-3K4 f)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    show "g inTARSKIR2 productCARD-3K4 f implies domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
    proof-
      have "g inTARSKIR2 productCARD-3K4 f implies domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
      proof(rule impI)
        assume "g inTARSKIR2 productCARD-3K4 f"
        then have " ex h be FunctionFUNCT-1M1 st (g =FUNCT-1R1 h & domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies h .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
          using card_3_def_5 sorry
        thus "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " not ((domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))) &  not g inTARSKIR2 productCARD-3K4 f)"
      using card_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_10:
"productCARD-3K4 ({}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have "productCARD-3K4 ({}XBOOLE-0K1) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 } & {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 productCARD-3K4 ({}XBOOLE-0K1)"
  proof(rule conjMI)
    show "productCARD-3K4 ({}XBOOLE-0K1) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 ({}XBOOLE-0K1) implies x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 ({}XBOOLE-0K1)"
        then have " ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ({}XBOOLE-0K1)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 ({}XBOOLE-0K1) implies g .FUNCT-1K1 y inTARSKIR2 {}XBOOLE-0K1 .FUNCT-1K1 y)"
          using card_3_def_5 sorry
        then have "x =HIDDENR1 {}XBOOLE-0K1"
           sorry
        thus "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_1 sorry
      qed "sorry"
      thus "productCARD-3K4 ({}XBOOLE-0K1) c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 productCARD-3K4 ({}XBOOLE-0K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
      then have A1: "x =HIDDENR1 {}XBOOLE-0K1"
        using tarski_def_1 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 ({}XBOOLE-0K1) implies {}XBOOLE-0K1 .FUNCT-1K1 y inTARSKIR2 {}XBOOLE-0K1 .FUNCT-1K1 y"
         sorry
      thus "x inHIDDENR3 productCARD-3K4 ({}XBOOLE-0K1)"
        using A1 card_3_th_9 sorry
    qed "sorry"
    thus "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 productCARD-3K4 ({}XBOOLE-0K1)"
      using tarski_def_3 sorry
  qed
  thus "productCARD-3K4 ({}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
    using xboole_0_def_10 sorry
qed

mtheorem card_3_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds FuncsFUNCT-2K1(X,Y) =XBOOLE-0R4 productCARD-3K4 (X -->FUNCOP-1K7 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds FuncsFUNCT-2K1(X,Y) =XBOOLE-0R4 productCARD-3K4 (X -->FUNCOP-1K7 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?f = "X -->FUNCOP-1K7 Y"
    have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> ?f =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    have "FuncsFUNCT-2K1(X,Y) c=TARSKIR1 productCARD-3K4 (X -->FUNCOP-1K7 Y) & productCARD-3K4 (X -->FUNCOP-1K7 Y) c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
    proof(rule conjMI)
      show "FuncsFUNCT-2K1(X,Y) c=TARSKIR1 productCARD-3K4 (X -->FUNCOP-1K7 Y)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(X,Y) implies x inHIDDENR3 productCARD-3K4 (X -->FUNCOP-1K7 Y)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A2: "x =HIDDENR1 g"and A3: "domRELAT-1K1 g =XBOOLE-0R4 X"and A4: "rngFUNCT-1K2 g c=TARSKIR1 Y"
            using funct_2_def_2 sorry
          have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 Y) implies g .FUNCT-1K1 y inTARSKIR2 (X -->FUNCOP-1K7 Y).FUNCT-1K1 y"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A5: "y inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ?f"
            then have A6: "?f .FUNCT-1K1 y =XBOOLE-0R4 Y"
              using funcop_1_th_7 sorry
            have "g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 g"
              using A3 A5 funct_1_def_3 sorry
            thus "g .FUNCT-1K1 y inTARSKIR2 (X -->FUNCOP-1K7 Y).FUNCT-1K1 y"
              using A4 A6 sorry
          qed "sorry"
          thus "x inHIDDENR3 productCARD-3K4 (X -->FUNCOP-1K7 Y)"
            using A1 A2 A3 card_3_def_5 sorry
        qed "sorry"
        thus "FuncsFUNCT-2K1(X,Y) c=TARSKIR1 productCARD-3K4 (X -->FUNCOP-1K7 Y)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (X -->FUNCOP-1K7 Y) implies x inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 ?f"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A7: "x =HIDDENR1 g"and A8: "domRELAT-1K1 g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> ?f"and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ?f implies g .FUNCT-1K1 x inTARSKIR2 ?f .FUNCT-1K1 x"
          using card_3_def_5 sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 Y"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 Y"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 g"
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A10: "z inHIDDENR3 domRELAT-1K1 g"and A11: "y =HIDDENR1 g .FUNCT-1K1 z"
              using funct_1_def_3 sorry
            have "y inHIDDENR3 ?f .FUNCT-1K1 z"
              using A8 A9 A10 A11 sorry
            thus "y inHIDDENR3 Y"
              using A8 A10 funcop_1_th_7 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 g c=TARSKIR1 Y"
            using tarski_def_3 sorry
        qed
        thus "x inHIDDENR3 FuncsFUNCT-2K1(X,Y)"
          using A1 A7 A8 funct_2_def_2 sorry
      qed "sorry"
      thus "productCARD-3K4 (X -->FUNCOP-1K7 Y) c=TARSKIR1 FuncsFUNCT-2K1(X,Y)"
        using tarski_def_3 sorry
    qed
    thus "FuncsFUNCT-2K1(X,Y) =XBOOLE-0R4 productCARD-3K4 (X -->FUNCOP-1K7 Y)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_3_def_6 ("piCARD-3K5'( _ , _ ')" [0,0]228 ) where
  mlet "x be objectHIDDENM1", "X be setHIDDENM2"
"func piCARD-3K5(X,x) \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st Lamb1 =HIDDENR1 g & Lamb2 =HIDDENR1 g .FUNCT-1K1 x"
      show " ex it be setHIDDENM2 st  for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)"
      proof-
        have " ex tVar7 be setHIDDENM2 st  for y be objectHIDDENM1 holds (y inHIDDENR3 tVar7 implies ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) & (( ex g be FunctionFUNCT-1M1 st g inTARSKIR2 X & y =HIDDENR1 g .FUNCT-1K1 x) implies y inHIDDENR3 tVar7)"
        proof-
          obtain Y where
            [ty]:"Y be setHIDDENM2" and 
            A1: " for y be objectHIDDENM1 holds y inHIDDENR3 Y iff y inHIDDENR3 X & y be FunctionFUNCT-1M1"
            using xboole_0_sch_1 sorry
          have A2: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex z be objectHIDDENM1 st ?R(y,z))"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex tVar5 be objectHIDDENM1 st  ex tVar6 be FunctionFUNCT-1M1 st tVar6 =HIDDENR1 tVar6 & tVar6 .FUNCT-1K1 x =HIDDENR1 tVar6 .FUNCT-1K1 x)"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 Y"
              then have 
                [ty]:"y be FunctionFUNCT-1M1"
                using A1 sorry
              show " ex tVar5 be objectHIDDENM1 st  ex tVar6 be FunctionFUNCT-1M1 st tVar6 =HIDDENR1 tVar6 & tVar6 .FUNCT-1K1 x =HIDDENR1 tVar6 .FUNCT-1K1 x"
              proof(rule bexI[of _ "y .FUNCT-1K1 x"])
                show " ex tVar6 be FunctionFUNCT-1M1 st tVar6 =HIDDENR1 tVar6 & tVar6 .FUNCT-1K1 x =HIDDENR1 tVar6 .FUNCT-1K1 x"
                proof(rule bexI[of _ "y"])
                  show "y =HIDDENR1 y & y .FUNCT-1K1 x =HIDDENR1 y .FUNCT-1K1 x"
                     sorry
                qed "sorry"
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A3: "domRELAT-1K1 f =XBOOLE-0R4 Y & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ?R(y,f .FUNCT-1K1 y))"
            using classes1_sch_1 A2 sorry
          show " ex tVar7 be setHIDDENM2 st  for y be objectHIDDENM1 holds (y inHIDDENR3 tVar7 implies ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) & (( ex g be FunctionFUNCT-1M1 st g inTARSKIR2 X & y =HIDDENR1 g .FUNCT-1K1 x) implies y inHIDDENR3 tVar7)"
          proof(rule bexI[of _ "rngFUNCT-1K2 f"],rule ballI,rule conjMI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            show "y inHIDDENR3 rngFUNCT-1K2 f implies ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)"
            proof-
              have "y inHIDDENR3 rngFUNCT-1K2 f implies ( ex tVar8 be FunctionFUNCT-1M1 st tVar8 inTARSKIR2 X & y =HIDDENR1 tVar8 .FUNCT-1K1 x)"
              proof(rule impI)
                assume "y inHIDDENR3 rngFUNCT-1K2 f"
                then obtain z where
                  [ty]:"z be objectHIDDENM1" and 
                  A4: "z inHIDDENR3 domRELAT-1K1 f"and A5: "y =HIDDENR1 f .FUNCT-1K1 z"
                  using funct_1_def_3 sorry
                obtain g where
                  [ty]:"g be FunctionFUNCT-1M1" and 
                  A6: "z =HIDDENR1 g"and A7: "f .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 x"
                  using A3 A4 sorry
                show " ex tVar8 be FunctionFUNCT-1M1 st tVar8 inTARSKIR2 X & y =HIDDENR1 tVar8 .FUNCT-1K1 x"
                proof(rule bexI[of _ "g"])
                  show "g inTARSKIR2 X & y =HIDDENR1 g .FUNCT-1K1 x"
                    using A1 A3 A4 A5 A6 A7 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
            assume Given: " ex g be FunctionFUNCT-1M1 st g inTARSKIR2 X & y =HIDDENR1 g .FUNCT-1K1 x"
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A8: "g inTARSKIR2 X"and A9: "y =HIDDENR1 g .FUNCT-1K1 x"
               sorry
            have A10: "g inTARSKIR2 Y"
              using A1 A8 sorry
            then have " ex f1 be FunctionFUNCT-1M1 st g =FUNCT-1R1 f1 & f .FUNCT-1K1 g =XBOOLE-0R4 f1 .FUNCT-1K1 x"
              using A3 sorry
            thus "y inHIDDENR3 rngFUNCT-1K2 f"
              using A3 A9 A10 funct_1_def_3 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 it1 iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 it2 iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st Lamb1 =HIDDENR1 g & Lamb2 =HIDDENR1 g .FUNCT-1K1 x"
      show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 it1 iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 it2 iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
      proof-
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 X1 iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 X2 iff ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) implies X1 =HIDDENR1 X2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          let ?Z = "\<lambda>Lamb1.  ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & Lamb1 =HIDDENR1 f .FUNCT-1K1 x"
          fix X1 assume [ty]: "X1 be setHIDDENM2"
          fix X2 assume [ty]: "X2 be setHIDDENM2"
          assume A11: " for y be objectHIDDENM1 holds y inHIDDENR3 X1 iff ?Z(y)"
            and A12: " for y be objectHIDDENM1 holds y inHIDDENR3 X2 iff ?Z(y)"
          show "X1 =HIDDENR1 X2"
            using xboole_0_sch_2 A11 A12 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem card_3_th_12:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1 implies piCARD-3K5(productCARD-3K4 f,x) =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1 implies piCARD-3K5(productCARD-3K4 f,x) =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
      and A2: "productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1"
    have A3: "piCARD-3K5(productCARD-3K4 f,x) c=TARSKIR1 f .FUNCT-1K1 x"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 piCARD-3K5(productCARD-3K4 f,x) implies y inHIDDENR3 f .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 piCARD-3K5(productCARD-3K4 f,x)"
        then have " ex g be FunctionFUNCT-1M1 st g inTARSKIR2 productCARD-3K4 f & y =HIDDENR1 g .FUNCT-1K1 x"
          using card_3_def_6 sorry
        thus "y inHIDDENR3 f .FUNCT-1K1 x"
          using A1 card_3_th_9 sorry
      qed "sorry"
      thus "piCARD-3K5(productCARD-3K4 f,x) c=TARSKIR1 f .FUNCT-1K1 x"
        using tarski_def_3 sorry
    qed
    have "f .FUNCT-1K1 x c=TARSKIR1 piCARD-3K5(productCARD-3K4 f,x)"
    proof-
      let ?z = "the ElementSUBSET-1M1-of productCARD-3K4 f"
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        "?z =XBOOLE-0R4 g"and A4: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using A2 card_3_def_5 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 f .FUNCT-1K1 x implies y inHIDDENR3 piCARD-3K5(productCARD-3K4 f,x)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        obtain yy where 
          [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
          using tarski_th_1 sorry
        let ?f = "\<lambda>Lamb1. yy"
        let ?g = "\<lambda>Lamb1. g .FUNCT-1K1 Lamb1"
        let ?C = "\<lambda>Lamb1. x =HIDDENR1 Lamb1"
        obtain h where
          [ty]:"h be FunctionFUNCT-1M1" and 
          A6: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 g & ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 g implies (?C(z) implies h .FUNCT-1K1 z =XBOOLE-0R4 ?f(z)) & ( not ?C(z) implies h .FUNCT-1K1 z =XBOOLE-0R4 ?g(z)))"
          using partfun1_sch_1 sorry
        assume A7: "y inHIDDENR3 f .FUNCT-1K1 x"
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies h .FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A8: "z inHIDDENR3 domRELAT-1K1 f"
          then have "x <>HIDDENR2 z implies g .FUNCT-1K1 z =XBOOLE-0R4 h .FUNCT-1K1 z"
            using A4 A6 sorry
          thus "h .FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
            using A4 A5 A6 A7 A8 sorry
        qed "sorry"
        then have A9: "h inTARSKIR2 productCARD-3K4 f"
          using A4 A6 card_3_th_9 sorry
        have "h .FUNCT-1K1 x =HIDDENR1 y"
          using A1 A4 A6 sorry
        thus "y inHIDDENR3 piCARD-3K5(productCARD-3K4 f,x)"
          using A9 card_3_def_6 sorry
      qed "sorry"
      thus "f .FUNCT-1K1 x c=TARSKIR1 piCARD-3K5(productCARD-3K4 f,x)"
        using tarski_def_3 sorry
    qed
    thus "piCARD-3K5(productCARD-3K4 f,x) =XBOOLE-0R4 f .FUNCT-1K1 x"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_13:
" for x be objectHIDDENM1 holds piCARD-3K5({}XBOOLE-0K1,x) =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for x be objectHIDDENM1 holds  not piCARD-3K5({}XBOOLE-0K1,x) =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?y = "the ElementSUBSET-1M1-of piCARD-3K5({}XBOOLE-0K1,x)"
    assume " not piCARD-3K5({}XBOOLE-0K1,x) =XBOOLE-0R4 {}XBOOLE-0K1"
    then have " ex f be FunctionFUNCT-1M1 st f inTARSKIR2 {}XBOOLE-0K1 & ?y =XBOOLE-0R4 f .FUNCT-1K1 x"
      using card_3_def_6 sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_14:
" for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds piCARD-3K5({TARSKIK1 g},x) =XBOOLE-0R4 {TARSKIK1 g .FUNCT-1K1 x }"
proof-
  have " for x be objectHIDDENM1 holds  for g be FunctionFUNCT-1M1 holds piCARD-3K5({TARSKIK1 g},x) =XBOOLE-0R4 {TARSKIK1 g .FUNCT-1K1 x }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have "piCARD-3K5({TARSKIK1 g},x) c=TARSKIR1 {TARSKIK1 g .FUNCT-1K1 x } & {TARSKIK1 g .FUNCT-1K1 x } c=TARSKIR1 piCARD-3K5({TARSKIK1 g},x)"
    proof(rule conjMI)
      show "piCARD-3K5({TARSKIK1 g},x) c=TARSKIR1 {TARSKIK1 g .FUNCT-1K1 x }"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 piCARD-3K5({TARSKIK1 g},x) implies y inHIDDENR3 {TARSKIK1 g .FUNCT-1K1 x }"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 piCARD-3K5({TARSKIK1 g},x)"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A1: "f inTARSKIR2 {TARSKIK1 g}"and A2: "y =HIDDENR1 f .FUNCT-1K1 x"
            using card_3_def_6 sorry
          have "f =FUNCT-1R1 g"
            using A1 tarski_def_1 sorry
          thus "y inHIDDENR3 {TARSKIK1 g .FUNCT-1K1 x }"
            using A2 tarski_def_1 sorry
        qed "sorry"
        thus "piCARD-3K5({TARSKIK1 g},x) c=TARSKIR1 {TARSKIK1 g .FUNCT-1K1 x }"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 g .FUNCT-1K1 x } implies y inHIDDENR3 piCARD-3K5({TARSKIK1 g},x)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "y inHIDDENR3 {TARSKIK1 g .FUNCT-1K1 x }"
        have A4: "g inTARSKIR2 {TARSKIK1 g}"
          using tarski_def_1 sorry
        have "y =HIDDENR1 g .FUNCT-1K1 x"
          using A3 tarski_def_1 sorry
        thus "y inHIDDENR3 piCARD-3K5({TARSKIK1 g},x)"
          using A4 card_3_def_6 sorry
      qed "sorry"
      thus "{TARSKIK1 g .FUNCT-1K1 x } c=TARSKIR1 piCARD-3K5({TARSKIK1 g},x)"
        using tarski_def_3 sorry
    qed
    thus "piCARD-3K5({TARSKIK1 g},x) =XBOOLE-0R4 {TARSKIK1 g .FUNCT-1K1 x }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_15:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds piCARD-3K5({TARSKIK2 f,g },x) =XBOOLE-0R4 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x }"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds piCARD-3K5({TARSKIK2 f,g },x) =XBOOLE-0R4 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have "piCARD-3K5({TARSKIK2 f,g },x) c=TARSKIR1 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x } & {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x } c=TARSKIR1 piCARD-3K5({TARSKIK2 f,g },x)"
    proof(rule conjMI)
      show "piCARD-3K5({TARSKIK2 f,g },x) c=TARSKIR1 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x }"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 piCARD-3K5({TARSKIK2 f,g },x) implies y inHIDDENR3 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x }"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 piCARD-3K5({TARSKIK2 f,g },x)"
          then obtain f1 where
            [ty]:"f1 be FunctionFUNCT-1M1" and 
            A1: "f1 inTARSKIR2 {TARSKIK2 f,g }"and A2: "y =HIDDENR1 f1 .FUNCT-1K1 x"
            using card_3_def_6 sorry
          have "f1 =FUNCT-1R1 f or f1 =FUNCT-1R1 g"
            using A1 tarski_def_2 sorry
          thus "y inHIDDENR3 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x }"
            using A2 tarski_def_2 sorry
        qed "sorry"
        thus "piCARD-3K5({TARSKIK2 f,g },x) c=TARSKIR1 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x }"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x } implies y inHIDDENR3 piCARD-3K5({TARSKIK2 f,g },x)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "y inHIDDENR3 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x }"
        have A4: "f inTARSKIR2 {TARSKIK2 f,g }"
          using tarski_def_2 sorry
        have A5: "g inTARSKIR2 {TARSKIK2 f,g }"
          using tarski_def_2 sorry
        have "y =HIDDENR1 g .FUNCT-1K1 x or y =HIDDENR1 f .FUNCT-1K1 x"
          using A3 tarski_def_2 sorry
        thus "y inHIDDENR3 piCARD-3K5({TARSKIK2 f,g },x)"
          using A4 A5 card_3_def_6 sorry
      qed "sorry"
      thus "{TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x } c=TARSKIR1 piCARD-3K5({TARSKIK2 f,g },x)"
        using tarski_def_3 sorry
    qed
    thus "piCARD-3K5({TARSKIK2 f,g },x) =XBOOLE-0R4 {TARSKIK2 f .FUNCT-1K1 x,g .FUNCT-1K1 x }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_16:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds piCARD-3K5(X \\/XBOOLE-0K2 Y,x) =XBOOLE-0R4 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds piCARD-3K5(X \\/XBOOLE-0K2 Y,x) =XBOOLE-0R4 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "piCARD-3K5(X \\/XBOOLE-0K2 Y,x) c=TARSKIR1 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x) & piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
    proof(rule conjMI)
      show "piCARD-3K5(X \\/XBOOLE-0K2 Y,x) c=TARSKIR1 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x)"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 piCARD-3K5(X \\/XBOOLE-0K2 Y,x) implies y inHIDDENR3 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x)"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A1: "f inTARSKIR2 X \\/XBOOLE-0K2 Y"and A2: "y =HIDDENR1 f .FUNCT-1K1 x"
            using card_3_def_6 sorry
          have "f inTARSKIR2 X or f inTARSKIR2 Y"
            using A1 xboole_0_def_3 sorry
          then have "y inHIDDENR3 piCARD-3K5(X,x) or y inHIDDENR3 piCARD-3K5(Y,x)"
            using A2 card_3_def_6 sorry
          thus "y inHIDDENR3 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x)"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "piCARD-3K5(X \\/XBOOLE-0K2 Y,x) c=TARSKIR1 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x)"
          using tarski_def_3 sorry
      qed
      have " for y be objectHIDDENM1 holds y inHIDDENR3 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x) implies y inHIDDENR3 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x)"
        then have A3: "y inHIDDENR3 piCARD-3K5(X,x) or y inHIDDENR3 piCARD-3K5(Y,x)"
          using xboole_0_def_3 sorry
        have A4: "y inHIDDENR3 piCARD-3K5(X,x) implies y inHIDDENR3 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
        proof(rule impI)
          assume "y inHIDDENR3 piCARD-3K5(X,x)"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A5: "f inTARSKIR2 X"and A6: "y =HIDDENR1 f .FUNCT-1K1 x"
            using card_3_def_6 sorry
          have "f inTARSKIR2 X \\/XBOOLE-0K2 Y"
            using A5 xboole_0_def_3 sorry
          thus "y inHIDDENR3 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
            using A6 card_3_def_6 sorry
        qed
        have " not y inHIDDENR3 piCARD-3K5(X,x) implies y inHIDDENR3 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
        proof(rule impI)
          assume " not y inHIDDENR3 piCARD-3K5(X,x)"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A7: "f inTARSKIR2 Y"and A8: "y =HIDDENR1 f .FUNCT-1K1 x"
            using A3 card_3_def_6 sorry
          have "f inTARSKIR2 X \\/XBOOLE-0K2 Y"
            using A7 xboole_0_def_3 sorry
          thus "y inHIDDENR3 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
            using A8 card_3_def_6 sorry
        qed
        thus "y inHIDDENR3 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
          using A4 sorry
      qed "sorry"
      thus "piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\/XBOOLE-0K2 Y,x)"
        using tarski_def_3 sorry
    qed
    thus "piCARD-3K5(X \\/XBOOLE-0K2 Y,x) =XBOOLE-0R4 piCARD-3K5(X,x) \\/XBOOLE-0K2 piCARD-3K5(Y,x)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_17:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds piCARD-3K5(X /\\XBOOLE-0K3 Y,x) c=TARSKIR1 piCARD-3K5(X,x) /\\XBOOLE-0K3 piCARD-3K5(Y,x)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds piCARD-3K5(X /\\XBOOLE-0K3 Y,x) c=TARSKIR1 piCARD-3K5(X,x) /\\XBOOLE-0K3 piCARD-3K5(Y,x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 piCARD-3K5(X /\\XBOOLE-0K3 Y,x) implies y inHIDDENR3 piCARD-3K5(X,x) /\\XBOOLE-0K3 piCARD-3K5(Y,x)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 piCARD-3K5(X /\\XBOOLE-0K3 Y,x)"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "f inTARSKIR2 X /\\XBOOLE-0K3 Y"and A2: "y =HIDDENR1 f .FUNCT-1K1 x"
        using card_3_def_6 sorry
      have A3: "f inTARSKIR2 X"
        using A1 xboole_0_def_4 sorry
      have A4: "f inTARSKIR2 Y"
        using A1 xboole_0_def_4 sorry
      have A5: "y inHIDDENR3 piCARD-3K5(X,x)"
        using A2 A3 card_3_def_6 sorry
      have "y inHIDDENR3 piCARD-3K5(Y,x)"
        using A2 A4 card_3_def_6 sorry
      thus "y inHIDDENR3 piCARD-3K5(X,x) /\\XBOOLE-0K3 piCARD-3K5(Y,x)"
        using A5 xboole_0_def_4 sorry
    qed "sorry"
    thus "piCARD-3K5(X /\\XBOOLE-0K3 Y,x) c=TARSKIR1 piCARD-3K5(X,x) /\\XBOOLE-0K3 piCARD-3K5(Y,x)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_18:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds piCARD-3K5(X,x) \\SUBSET-1K6 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\SUBSET-1K6 Y,x)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds piCARD-3K5(X,x) \\SUBSET-1K6 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\SUBSET-1K6 Y,x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 piCARD-3K5(X,x) \\SUBSET-1K6 piCARD-3K5(Y,x) implies y inHIDDENR3 piCARD-3K5(X \\SUBSET-1K6 Y,x)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A1: "y inHIDDENR3 piCARD-3K5(X,x) \\SUBSET-1K6 piCARD-3K5(Y,x)"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "f inTARSKIR2 X"and A3: "y =HIDDENR1 f .FUNCT-1K1 x"
        using card_3_def_6 sorry
      have " not y inHIDDENR3 piCARD-3K5(Y,x)"
        using A1 xboole_0_def_5 sorry
      then have " not f inTARSKIR2 Y"
        using A3 card_3_def_6 sorry
      then have "f inTARSKIR2 X \\SUBSET-1K6 Y"
        using A2 xboole_0_def_5 sorry
      thus "y inHIDDENR3 piCARD-3K5(X \\SUBSET-1K6 Y,x)"
        using A3 card_3_def_6 sorry
    qed "sorry"
    thus "piCARD-3K5(X,x) \\SUBSET-1K6 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\SUBSET-1K6 Y,x)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_19:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds piCARD-3K5(X,x) \\+\\XBOOLE-0K5 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\+\\XBOOLE-0K5 Y,x)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds piCARD-3K5(X,x) \\+\\XBOOLE-0K5 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\+\\XBOOLE-0K5 Y,x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "piCARD-3K5(X,x) \\SUBSET-1K6 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\SUBSET-1K6 Y,x)"
      using card_3_th_18 sorry
    have A2: "piCARD-3K5(Y,x) \\SUBSET-1K6 piCARD-3K5(X,x) c=TARSKIR1 piCARD-3K5(Y \\SUBSET-1K6 X,x)"
      using card_3_th_18 sorry
    have "piCARD-3K5(X \\SUBSET-1K6 Y,x) \\/XBOOLE-0K2 piCARD-3K5(Y \\SUBSET-1K6 X,x) =XBOOLE-0R4 piCARD-3K5((X \\SUBSET-1K6 Y)\\/XBOOLE-0K2 (Y \\SUBSET-1K6 X),x)"
      using card_3_th_16 sorry
    thus "piCARD-3K5(X,x) \\+\\XBOOLE-0K5 piCARD-3K5(Y,x) c=TARSKIR1 piCARD-3K5(X \\+\\XBOOLE-0K5 Y,x)"
      using A1 A2 xboole_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_20:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds cardCARD-1K1 (piCARD-3K5(X,x)) c=ORDINAL1R1 cardCARD-1K1 X"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds cardCARD-1K1 (piCARD-3K5(X,x)) c=ORDINAL1R1 cardCARD-1K1 X"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A1: " for y be objectHIDDENM1 holds y inHIDDENR3 Y iff y inHIDDENR3 X & y be FunctionFUNCT-1M1"
      using xboole_0_sch_1 sorry
    let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st Lamb1 =HIDDENR1 g & Lamb2 =HIDDENR1 g .FUNCT-1K1 x"
    have A2: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex z be objectHIDDENM1 st ?R(y,z))"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex tVar9 be objectHIDDENM1 st  ex tVar10 be FunctionFUNCT-1M1 st tVar10 =HIDDENR1 tVar10 & tVar10 .FUNCT-1K1 x =HIDDENR1 tVar10 .FUNCT-1K1 x)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 Y"
        then have 
          [ty]:"y be FunctionFUNCT-1M1"
          using A1 sorry
        show " ex tVar9 be objectHIDDENM1 st  ex tVar10 be FunctionFUNCT-1M1 st tVar10 =HIDDENR1 tVar10 & tVar10 .FUNCT-1K1 x =HIDDENR1 tVar10 .FUNCT-1K1 x"
        proof(rule bexI[of _ "y .FUNCT-1K1 x"])
          show " ex tVar10 be FunctionFUNCT-1M1 st tVar10 =HIDDENR1 tVar10 & tVar10 .FUNCT-1K1 x =HIDDENR1 tVar10 .FUNCT-1K1 x"
          proof(rule bexI[of _ "y"])
            show "y =HIDDENR1 y & y .FUNCT-1K1 x =HIDDENR1 y .FUNCT-1K1 x"
               sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 f =XBOOLE-0R4 Y & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ?R(y,f .FUNCT-1K1 y))"
      using classes1_sch_1 A2 sorry
    have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 f implies ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)) & (( ex g be FunctionFUNCT-1M1 st g inTARSKIR2 X & y =HIDDENR1 g .FUNCT-1K1 x) implies y inHIDDENR3 rngFUNCT-1K2 f)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show "y inHIDDENR3 rngFUNCT-1K2 f implies ( ex f be FunctionFUNCT-1M1 st f inTARSKIR2 X & y =HIDDENR1 f .FUNCT-1K1 x)"
      proof-
        have "y inHIDDENR3 rngFUNCT-1K2 f implies ( ex tVar11 be FunctionFUNCT-1M1 st tVar11 inTARSKIR2 X & y =HIDDENR1 tVar11 .FUNCT-1K1 x)"
        proof(rule impI)
          assume "y inHIDDENR3 rngFUNCT-1K2 f"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A4: "z inHIDDENR3 domRELAT-1K1 f"and A5: "y =HIDDENR1 f .FUNCT-1K1 z"
            using funct_1_def_3 sorry
          obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A6: "z =HIDDENR1 g"and A7: "f .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 x"
            using A3 A4 sorry
          show " ex tVar11 be FunctionFUNCT-1M1 st tVar11 inTARSKIR2 X & y =HIDDENR1 tVar11 .FUNCT-1K1 x"
          proof(rule bexI[of _ "g"])
            show "g inTARSKIR2 X & y =HIDDENR1 g .FUNCT-1K1 x"
              using A1 A3 A4 A5 A6 A7 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      assume Given: " ex g be FunctionFUNCT-1M1 st g inTARSKIR2 X & y =HIDDENR1 g .FUNCT-1K1 x"
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A8: "g inTARSKIR2 X"and A9: "y =HIDDENR1 g .FUNCT-1K1 x"
         sorry
      have A10: "g inTARSKIR2 Y"
        using A1 A8 sorry
      then have " ex f1 be FunctionFUNCT-1M1 st g =FUNCT-1R1 f1 & f .FUNCT-1K1 g =XBOOLE-0R4 f1 .FUNCT-1K1 x"
        using A3 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 f"
        using A3 A9 A10 funct_1_def_3 sorry
    qed "sorry"
    then have "rngFUNCT-1K2 f =XBOOLE-0R4 piCARD-3K5(X,x)"
      using card_3_def_6 sorry
    then have A11: "cardCARD-1K1 (piCARD-3K5(X,x)) c=ORDINAL1R1 cardCARD-1K1 Y"
      using A3 card_1_th_12 sorry
    have "Y c=TARSKIR1 X"
      using A1 sorry
    then have "cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 X"
      using card_1_th_11 sorry
    thus "cardCARD-1K1 (piCARD-3K5(X,x)) c=ORDINAL1R1 cardCARD-1K1 X"
      using A11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_21:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ])"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f implies  not ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not x =HIDDENR1 [TARSKIK4 y,z ])"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f"
    then obtain X where
      [ty]:"X be setHIDDENM2" and 
      A1: "x inHIDDENR3 X"and A2: "X inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 f)"
      using tarski_def_4 sorry
    obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A3: "y inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 f)"and A4: "X =XBOOLE-0R4 disjoinCARD-3K2 f .FUNCT-1K1 y"
      using A2 funct_1_def_3 sorry
    have "y inHIDDENR3 domRELAT-1K1 f"
      using A3 card_3_def_3 sorry
    then have "X =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 y,{TARSKIK1 y} :]"
      using A4 card_3_def_3 sorry
    thus " not ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not x =HIDDENR1 [TARSKIK4 y,z ])"
      using A1 relat_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_22:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f iff (x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f & x `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 x `2XTUPLE-0K2) & x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds (x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f implies (x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f & x `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 x `2XTUPLE-0K2) & x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]) & (x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f & (x `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 x `2XTUPLE-0K2 & x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]) implies x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f implies (x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f & x `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 x `2XTUPLE-0K2) & x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
    proof(rule impI)
      assume "x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f"
      then obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: "x inHIDDENR3 X"and A2: "X inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 f)"
        using tarski_def_4 sorry
      obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A3: "y inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 f)"and A4: "X =XBOOLE-0R4 disjoinCARD-3K2 f .FUNCT-1K1 y"
        using A2 funct_1_def_3 sorry
      have A5: "y inHIDDENR3 domRELAT-1K1 f"
        using A3 card_3_def_3 sorry
      then have A6: "X =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 y,{TARSKIK1 y} :]"
        using A4 card_3_def_3 sorry
      then have A7: "x `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 y"
        using A1 mcart_1_th_10 sorry
      have "x `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 y}"
        using A1 A6 mcart_1_th_10 sorry
      thus "(x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f & x `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 x `2XTUPLE-0K2) & x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
        using A1 A5 A6 A7 mcart_1_th_21 tarski_def_1 sorry
    qed
    assume A8: "x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f"
      and A9: "x `1XTUPLE-0K1 inHIDDENR3 f .FUNCT-1K1 x `2XTUPLE-0K2"
      and A10: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
    have A11: "disjoinCARD-3K2 f .FUNCT-1K1 x `2XTUPLE-0K2 =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x `2XTUPLE-0K2,{TARSKIK1 x `2XTUPLE-0K2 } :]"
      using A8 card_3_def_3 sorry
    have A12: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (disjoinCARD-3K2 f)"
      using card_3_def_3 sorry
    have "x `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 x `2XTUPLE-0K2 }"
      using tarski_def_1 sorry
    then have A13: "x inHIDDENR3 [:ZFMISC-1K2 f .FUNCT-1K1 x `2XTUPLE-0K2,{TARSKIK1 x `2XTUPLE-0K2 } :]"
      using A9 A10 zfmisc_1_th_87 sorry
    have "[:ZFMISC-1K2 f .FUNCT-1K1 x `2XTUPLE-0K2,{TARSKIK1 x `2XTUPLE-0K2 } :] inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 f)"
      using A8 A11 A12 funct_1_def_3 sorry
    thus "x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 f"
      using A13 tarski_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_23:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies disjoinCARD-3K2 f c=RELAT-1R2 disjoinCARD-3K2 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies disjoinCARD-3K2 f c=RELAT-1R2 disjoinCARD-3K2 g"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f c=RELAT-1R2 g"
    then have A2: "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
      using grfunc_1_th_2 sorry
    have A3: "domRELAT-1K1 (disjoinCARD-3K2 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using card_3_def_3 sorry
    have A4: "domRELAT-1K1 (disjoinCARD-3K2 g) =XBOOLE-0R4 domRELAT-1K1 g"
      using card_3_def_3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 f) implies disjoinCARD-3K2 f .FUNCT-1K1 x =XBOOLE-0R4 disjoinCARD-3K2 g .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 f)"
      then have A6: "disjoinCARD-3K2 f .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 f .FUNCT-1K1 x,{TARSKIK1 x} :]"
        using A3 card_3_def_3 sorry
      have "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A1 A3 A5 grfunc_1_th_2 sorry
      thus "disjoinCARD-3K2 f .FUNCT-1K1 x =XBOOLE-0R4 disjoinCARD-3K2 g .FUNCT-1K1 x"
        using A2 A3 A5 A6 card_3_def_3 sorry
    qed "sorry"
    thus "disjoinCARD-3K2 f c=RELAT-1R2 disjoinCARD-3K2 g"
      using A2 A3 A4 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_24:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies UnionCARD-3K3 f c=TARSKIR1 UnionCARD-3K3 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies UnionCARD-3K3 f c=TARSKIR1 UnionCARD-3K3 g"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f c=RELAT-1R2 g"
    then have A2: "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
      using grfunc_1_th_2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 f implies x inHIDDENR3 UnionCARD-3K3 g"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 UnionCARD-3K3 f"
      then obtain X where
        [ty]:"X be setHIDDENM2" and 
        A3: "x inHIDDENR3 X"and A4: "X inTARSKIR2 rngFUNCT-1K2 f"
        using tarski_def_4 sorry
      obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A5: "y inHIDDENR3 domRELAT-1K1 f"and A6: "X =XBOOLE-0R4 f .FUNCT-1K1 y"
        using A4 funct_1_def_3 sorry
      have "f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
        using A1 A5 grfunc_1_th_2 sorry
      then have "X inTARSKIR2 rngFUNCT-1K2 g"
        using A2 A5 A6 funct_1_def_3 sorry
      thus "x inHIDDENR3 UnionCARD-3K3 g"
        using A3 tarski_def_4 sorry
    qed "sorry"
    thus "UnionCARD-3K3 f c=TARSKIR1 UnionCARD-3K3 g"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_25:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?f = "Y -->FUNCOP-1K7 X"
    have A1: "domRELSET-1K1\<^bsub>(Y)\<^esub> ?f =XBOOLE-0R4 Y"
      using funcop_1_th_13 sorry
    have "UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X) c=TARSKIR1 [:ZFMISC-1K2 X,Y :] & [:ZFMISC-1K2 X,Y :] c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X)"
    proof(rule conjMI)
      show "UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X) c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X) implies x inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 ?f"
          then obtain Z where
            [ty]:"Z be setHIDDENM2" and 
            A2: "x inHIDDENR3 Z"and A3: "Z inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 ?f)"
            using tarski_def_4 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A4: "y inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 ?f)"and A5: "Z =XBOOLE-0R4 disjoinCARD-3K2 ?f .FUNCT-1K1 y"
            using A3 funct_1_def_3 sorry
          have A6: "y inHIDDENR3 Y"
            using A1 A4 card_3_def_3 sorry
          then have A7: "Z =XBOOLE-0R4 [:ZFMISC-1K2 ?f .FUNCT-1K1 y,{TARSKIK1 y} :]"
            using A1 A5 card_3_def_3 sorry
          have A8: "?f .FUNCT-1K1 y =XBOOLE-0R4 X"
            using A6 funcop_1_th_7 sorry
          have "{TARSKIK1 y} c=TARSKIR1 Y"
            using A6 zfmisc_1_th_31 sorry
          then have "Z c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
            using A7 A8 zfmisc_1_th_95 sorry
          thus "x inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
            using A2 sorry
        qed "sorry"
        thus "UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X) c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
          using tarski_def_3 sorry
      qed
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies [TARSKIK4 x1,x2 ] inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X)"
      proof(rule ballI,rule ballI,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A9: "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        then have A10: "x1 inHIDDENR3 X"
          using zfmisc_1_th_87 sorry
        have A11: "x2 inHIDDENR3 Y"
          using A9 zfmisc_1_th_87 sorry
        then have A12: "?f .FUNCT-1K1 x2 =XBOOLE-0R4 X"
          using funcop_1_th_7 sorry
        have A13: "disjoinCARD-3K2 ?f .FUNCT-1K1 x2 =XBOOLE-0R4 [:ZFMISC-1K2 ?f .FUNCT-1K1 x2,{TARSKIK1 x2} :]"
          using A1 A11 card_3_def_3 sorry
        have A14: "x2 inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 ?f)"
          using A1 A11 card_3_def_3 sorry
        have "x2 inHIDDENR3 {TARSKIK1 x2}"
          using tarski_def_1 sorry
        then have A15: "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 ?f .FUNCT-1K1 x2,{TARSKIK1 x2} :]"
          using A10 A12 zfmisc_1_th_87 sorry
        have "[:ZFMISC-1K2 ?f .FUNCT-1K1 x2,{TARSKIK1 x2} :] inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 ?f)"
          using A13 A14 funct_1_def_3 sorry
        thus "[TARSKIK4 x1,x2 ] inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X)"
          using A15 tarski_def_4 sorry
      qed "sorry"
      thus "[:ZFMISC-1K2 X,Y :] c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X)"
        using relat_1_def_3 sorry
    qed
    thus "UnionCARD-3K3 disjoinCARD-3K2 (Y -->FUNCOP-1K7 X) =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_26:
" for f be FunctionFUNCT-1M1 holds productCARD-3K4 f =XBOOLE-0R4 {}XBOOLE-0K1 iff {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds (productCARD-3K4 f =XBOOLE-0R4 {}XBOOLE-0K1 implies {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f) & ({}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies (productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1 implies  False ))"
  proof(rule ballI,rule conjMI,rule impI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "productCARD-3K4 f =XBOOLE-0R4 {}XBOOLE-0K1 implies {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
    proof-
      have "productCARD-3K4 f =XBOOLE-0R4 {}XBOOLE-0K1 &  not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies  not  True "
      proof(rule impMI ,rule impI)
        assume A1: "productCARD-3K4 f =XBOOLE-0R4 {}XBOOLE-0K1"
          and A2: " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
        have A3: "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies  not  True "
        proof(rule impI)
          assume "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
          then have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
             sorry
          thus " not  True "
            using A1 card_3_def_5 sorry
        qed
        have "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1 implies  not  True "
        proof(rule impI)
          assume "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
          then obtain M where 
            [ty]:"M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and MDef:"M = rngFUNCT-1K2 f"
            using relat_1_th_42 sorry
          have " for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1"
            using A2 sorry
          then obtain f1 where
            [ty]:"f1 be FunctionFUNCT-1M1" and 
            "domRELAT-1K1 f1 =XBOOLE-0R4 M"and A4: " for X be setHIDDENM2 holds X inTARSKIR2 M implies f1 .FUNCT-1K1 X inTARSKIR2 X"
            using funct_1_th_111 sorry
          let ?g = "\<lambda>Lamb1. f1 .FUNCT-1K1 (f .FUNCT-1K1 Lamb1)"
          obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A5: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =XBOOLE-0R4 ?g(x))"
            using funct_1_sch_3 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A6: "x inHIDDENR3 domRELAT-1K1 f"
            then have A7: "f .FUNCT-1K1 x inTARSKIR2 M"
              using funct_1_def_3 sorry
            have "g .FUNCT-1K1 x =XBOOLE-0R4 f1 .FUNCT-1K1 (f .FUNCT-1K1 x)"
              using A5 A6 sorry
            thus "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
              using A4 A7 sorry
          qed "sorry"
          thus " not  True "
            using A1 A5 card_3_def_5 sorry
        qed
        thus " not  True "
          using A3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
    then have A8: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & {}XBOOLE-0K1 =XBOOLE-0R4 f .FUNCT-1K1 x"
      using funct_1_def_3 sorry
    assume A9: "productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1"
    let ?y = "the ElementSUBSET-1M1-of productCARD-3K4 f"
    have " ex g be FunctionFUNCT-1M1 st (?y =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
      using A9 card_3_def_5 sorry
    thus " False "
      using A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_27:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x c=TARSKIR1 g .FUNCT-1K1 x) implies productCARD-3K4 f c=TARSKIR1 productCARD-3K4 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x c=TARSKIR1 g .FUNCT-1K1 x) implies productCARD-3K4 f c=TARSKIR1 productCARD-3K4 g"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x c=TARSKIR1 g .FUNCT-1K1 x"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 f implies x inHIDDENR3 productCARD-3K4 g"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 productCARD-3K4 f"
      then obtain f1 where
        [ty]:"f1 be FunctionFUNCT-1M1" and 
        A3: "x =HIDDENR1 f1"and A4: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f"and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f1 .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using card_3_def_5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies f1 .FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 domRELAT-1K1 g"
        then have A7: "f1 .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
          using A1 A5 sorry
        have "f .FUNCT-1K1 x c=TARSKIR1 g .FUNCT-1K1 x"
          using A1 A2 A6 sorry
        thus "f1 .FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x"
          using A7 sorry
      qed "sorry"
      thus "x inHIDDENR3 productCARD-3K4 g"
        using A1 A3 A4 card_3_def_5 sorry
    qed "sorry"
    thus "productCARD-3K4 f c=TARSKIR1 productCARD-3K4 g"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve F, G for "Cardinal-FunctionCARD-3M1"
mtheorem card_3_th_28:
" for F be Cardinal-FunctionCARD-3M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies cardCARD-1K1 (F .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 x"
proof-
  have " for F be Cardinal-FunctionCARD-3M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies cardCARD-1K1 (F .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix F assume [ty]: "F be Cardinal-FunctionCARD-3M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 domRELAT-1K1 F"
    then obtain M where 
      [ty]:"M be CardinalCARD-1M1" and MDef:"M = F .FUNCT-1K1 x"
      using card_3_def_1 sorry
    have "cardCARD-1K1 M =XBOOLE-0R4 M"
       sorry
    thus "cardCARD-1K1 (F .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_29:
" for F be Cardinal-FunctionCARD-3M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies cardCARD-1K1 (disjoinCARD-3K2 F .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 x"
proof-
  have " for F be Cardinal-FunctionCARD-3M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies cardCARD-1K1 (disjoinCARD-3K2 F .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix F assume [ty]: "F be Cardinal-FunctionCARD-3M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 F"
    then obtain M where 
      [ty]:"M be CardinalCARD-1M1" and MDef:"M = F .FUNCT-1K1 x"
      using card_3_def_1 sorry
    have "(M,[:ZFMISC-1K2 M,{TARSKIK1 x} :])are-equipotentWELLORD2R2"
      using card_1_th_69 sorry
    then have "M =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 M,{TARSKIK1 x} :])"
      using card_1_def_2 sorry
    thus "cardCARD-1K1 (disjoinCARD-3K2 F .FUNCT-1K1 x) =XBOOLE-0R4 F .FUNCT-1K1 x"
      using A1 card_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_3_def_7 ("SumCARD-3K6  _ " [260]260 ) where
  mlet "F be Cardinal-FunctionCARD-3M1"
"func SumCARD-3K6 F \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F)"
proof-
  (*coherence*)
    show "cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F) be CardinalCARD-1M1"
       sorry
qed "sorry"

mdef card_3_def_8 ("ProductCARD-3K7  _ " [228]228 ) where
  mlet "F be Cardinal-FunctionCARD-3M1"
"func ProductCARD-3K7 F \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 (productCARD-3K4 F)"
proof-
  (*coherence*)
    show "cardCARD-1K1 (productCARD-3K4 F) be CardinalCARD-1M1"
       sorry
qed "sorry"

mtheorem card_3_th_30:
" for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x c=TARSKIR1 G .FUNCT-1K1 x) implies SumCARD-3K6 F c=ORDINAL1R1 SumCARD-3K6 G"
proof-
  have " for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x c=TARSKIR1 G .FUNCT-1K1 x) implies SumCARD-3K6 F c=ORDINAL1R1 SumCARD-3K6 G"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix F assume [ty]: "F be Cardinal-FunctionCARD-3M1"
    fix G assume [ty]: "G be Cardinal-FunctionCARD-3M1"
    assume A1: "domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x c=TARSKIR1 G .FUNCT-1K1 x"
    have "UnionCARD-3K3 disjoinCARD-3K2 F c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 G"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 F implies x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 G"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 F"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A3: "x inHIDDENR3 X"and A4: "X inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 F)"
          using tarski_def_4 sorry
        obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A5: "y inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 F)"and A6: "X =XBOOLE-0R4 disjoinCARD-3K2 F .FUNCT-1K1 y"
          using A4 funct_1_def_3 sorry
        have A7: "y inHIDDENR3 domRELAT-1K1 F"
          using A5 card_3_def_3 sorry
        then have A8: "F .FUNCT-1K1 y c=TARSKIR1 G .FUNCT-1K1 y"
          using A2 sorry
        have A9: "X =XBOOLE-0R4 [:ZFMISC-1K2 F .FUNCT-1K1 y,{TARSKIK1 y} :]"
          using A6 A7 card_3_def_3 sorry
        have A10: "disjoinCARD-3K2 G .FUNCT-1K1 y =XBOOLE-0R4 [:ZFMISC-1K2 G .FUNCT-1K1 y,{TARSKIK1 y} :]"
          using A1 A7 card_3_def_3 sorry
        have A11: "y inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 G)"
          using A1 A7 card_3_def_3 sorry
        have A12: "X c=TARSKIR1 [:ZFMISC-1K2 G .FUNCT-1K1 y,{TARSKIK1 y} :]"
          using A8 A9 zfmisc_1_th_95 sorry
        have "[:ZFMISC-1K2 G .FUNCT-1K1 y,{TARSKIK1 y} :] inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 G)"
          using A10 A11 funct_1_def_3 sorry
        thus "x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 G"
          using A3 A12 tarski_def_4 sorry
      qed "sorry"
      thus "UnionCARD-3K3 disjoinCARD-3K2 F c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 G"
        using tarski_def_3 sorry
    qed
    thus "SumCARD-3K6 F c=ORDINAL1R1 SumCARD-3K6 G"
      using card_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_31:
" for F be Cardinal-FunctionCARD-3M1 holds {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 F iff ProductCARD-3K7 F =XBOOLE-0R4 0ORDINAL1K5"
proof-
  have " for F be Cardinal-FunctionCARD-3M1 holds ({}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 F implies ProductCARD-3K7 F =XBOOLE-0R4 0ORDINAL1K5) & (ProductCARD-3K7 F =XBOOLE-0R4 0ORDINAL1K5 implies {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 F)"
  proof(rule ballI,rule conjMI,rule impI)
    fix F assume [ty]: "F be Cardinal-FunctionCARD-3M1"
    show "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 F implies ProductCARD-3K7 F =XBOOLE-0R4 0ORDINAL1K5"
      using card_3_th_26 card_1_th_27 sorry
    assume "ProductCARD-3K7 F =XBOOLE-0R4 0ORDINAL1K5"
    then have "productCARD-3K4 F =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 F"
      using card_3_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_32:
" for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x c=TARSKIR1 G .FUNCT-1K1 x) implies ProductCARD-3K7 F c=ORDINAL1R1 ProductCARD-3K7 G"
  using card_3_th_27 card_1_th_11 sorry

mtheorem card_3_th_33:
" for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds F c=RELAT-1R2 G implies SumCARD-3K6 F c=ORDINAL1R1 SumCARD-3K6 G"
proof-
  have " for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds F c=RELAT-1R2 G implies SumCARD-3K6 F c=ORDINAL1R1 SumCARD-3K6 G"
  proof(rule ballI,rule ballI,rule impI)
    fix F assume [ty]: "F be Cardinal-FunctionCARD-3M1"
    fix G assume [ty]: "G be Cardinal-FunctionCARD-3M1"
    assume "F c=RELAT-1R2 G"
    then have "disjoinCARD-3K2 F c=RELAT-1R2 disjoinCARD-3K2 G"
      using card_3_th_23 sorry
    thus "SumCARD-3K6 F c=ORDINAL1R1 SumCARD-3K6 G"
      using card_3_th_24 card_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_34:
" for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds F c=RELAT-1R2 G &  not 0ORDINAL1K5 inTARSKIR2 rngFUNCT-1K2 G implies ProductCARD-3K7 F c=ORDINAL1R1 ProductCARD-3K7 G"
proof-
  have " for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds F c=RELAT-1R2 G implies ( not 0ORDINAL1K5 inTARSKIR2 rngFUNCT-1K2 G implies ProductCARD-3K7 F c=ORDINAL1R1 ProductCARD-3K7 G)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix F assume [ty]: "F be Cardinal-FunctionCARD-3M1"
    fix G assume [ty]: "G be Cardinal-FunctionCARD-3M1"
    assume A1: "F c=RELAT-1R2 G"
    then have A2: "domRELAT-1K1 F c=TARSKIR1 domRELAT-1K1 G"
      using grfunc_1_th_2 sorry
    assume A3: " not 0ORDINAL1K5 inTARSKIR2 rngFUNCT-1K2 G"
    let ?f = "\<lambda>Lamb1. Lamb1  |RELAT-1K8 domRELAT-1K1 F"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A4: "domRELAT-1K1 f =XBOOLE-0R4 productCARD-3K4 G & ( for g be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 G implies f .FUNCT-1K1 g =XBOOLE-0R4 ?f(g))"
      using funct_5_sch_1 sorry
    have "productCARD-3K4 F c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 F implies x inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 F"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A5: "x =HIDDENR1 g"and A6: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 F"and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies g .FUNCT-1K1 x inTARSKIR2 F .FUNCT-1K1 x"
          using card_3_def_5 sorry
        have A8: "productCARD-3K4 G <>HIDDENR2 {}XBOOLE-0K1"
          using A3 card_3_th_26 sorry
        let ?y = "the ElementSUBSET-1M1-of productCARD-3K4 G"
        obtain h where
          [ty]:"h be FunctionFUNCT-1M1" and 
          "?y =XBOOLE-0R4 h"and "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 G"and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 G implies h .FUNCT-1K1 x inTARSKIR2 G .FUNCT-1K1 x"
          using A8 card_3_def_5 sorry
        let ?f = "\<lambda>Lamb1. g .FUNCT-1K1 Lamb1"
        let ?g = "\<lambda>Lamb1. h .FUNCT-1K1 Lamb1"
        let ?C = "\<lambda>Lamb1. Lamb1 inHIDDENR3 domRELAT-1K1 F"
        obtain f1 where
          [ty]:"f1 be FunctionFUNCT-1M1" and 
          A10: "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 G & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 G implies (?C(x) implies f1 .FUNCT-1K1 x =XBOOLE-0R4 ?f(x)) & ( not ?C(x) implies f1 .FUNCT-1K1 x =XBOOLE-0R4 ?g(x)))"
          using partfun1_sch_1 sorry
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 G implies f1 .FUNCT-1K1 z inTARSKIR2 G .FUNCT-1K1 z"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A11: "z inHIDDENR3 domRELAT-1K1 G"
          have A12: "z inHIDDENR3 domRELAT-1K1 F implies f1 .FUNCT-1K1 z inTARSKIR2 G .FUNCT-1K1 z"
          proof(rule impI)
            assume A13: "z inHIDDENR3 domRELAT-1K1 F"
            then have A14: "f1 .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z"
              using A10 A11 sorry
            have "g .FUNCT-1K1 z inTARSKIR2 F .FUNCT-1K1 z"
              using A7 A13 sorry
            thus "f1 .FUNCT-1K1 z inTARSKIR2 G .FUNCT-1K1 z"
              using A1 A13 A14 grfunc_1_th_2 sorry
          qed
          have " not z inHIDDENR3 domRELAT-1K1 F implies f1 .FUNCT-1K1 z =XBOOLE-0R4 h .FUNCT-1K1 z"
            using A10 A11 sorry
          thus "f1 .FUNCT-1K1 z inTARSKIR2 G .FUNCT-1K1 z"
            using A9 A11 A12 sorry
        qed "sorry"
        then have A15: "f1 inTARSKIR2 productCARD-3K4 G"
          using A10 card_3_def_5 sorry
        then have A16: "f .FUNCT-1K1 f1 =XBOOLE-0R4 f1  |RELAT-1K8 domRELAT-1K1 F"
          using A4 sorry
        have A17: "domRELAT-1K1 (f1  |RELAT-1K8 domRELAT-1K1 F) =XBOOLE-0R4 domRELAT-1K1 F"
          using A2 A10 relat_1_th_62 sorry
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 F implies (f1  |RELAT-1K8 domRELAT-1K1 F).FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A18: "z inHIDDENR3 domRELAT-1K1 F"
          then have "(f1  |RELAT-1K8 domRELAT-1K1 F).FUNCT-1K1 z =XBOOLE-0R4 f1 .FUNCT-1K1 z"
            using A17 funct_1_th_47 sorry
          thus "(f1  |RELAT-1K8 domRELAT-1K1 F).FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z"
            using A2 A10 A18 sorry
        qed "sorry"
        then have "f .FUNCT-1K1 f1 =XBOOLE-0R4 g"
          using A6 A16 A17 funct_1_th_2 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 f"
          using A4 A5 A15 funct_1_def_3 sorry
      qed "sorry"
      thus "productCARD-3K4 F c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    thus "ProductCARD-3K7 F c=ORDINAL1R1 ProductCARD-3K7 G"
      using A4 card_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_35:
" for K be CardinalCARD-1M1 holds SumCARD-3K6 ({}XBOOLE-0K1 -->FUNCOP-1K7 K) =XBOOLE-0R4 0ORDINAL1K5"
proof-
  have " for K be CardinalCARD-1M1 holds SumCARD-3K6 ({}XBOOLE-0K1 -->FUNCOP-1K7 K) =XBOOLE-0R4 0ORDINAL1K5"
  proof(rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    have "domRELSET-1K1\<^bsub>({}XBOOLE-0K1)\<^esub> ({}XBOOLE-0K1 -->FUNCOP-1K7 K) =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
    then have "domRELAT-1K1 (disjoinCARD-3K2 ({}XBOOLE-0K1 -->FUNCOP-1K7 K)) =XBOOLE-0R4 {}XBOOLE-0K1"
      using card_3_def_3 sorry
    thus "SumCARD-3K6 ({}XBOOLE-0K1 -->FUNCOP-1K7 K) =XBOOLE-0R4 0ORDINAL1K5"
      using card_1_th_27 relat_1_th_42 zfmisc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_36:
" for K be CardinalCARD-1M1 holds ProductCARD-3K7 ({}XBOOLE-0K1 -->FUNCOP-1K7 K) =XBOOLE-0R4 \<one>\<^sub>M"
  using card_3_th_10 card_1_th_30 sorry

mtheorem card_3_th_37:
" for K be CardinalCARD-1M1 holds  for x be objectHIDDENM1 holds SumCARD-3K6 (x .-->FUNCOP-1K17 K) =XBOOLE-0R4 K"
proof-
  have " for K be CardinalCARD-1M1 holds  for x be objectHIDDENM1 holds SumCARD-3K6 (x .-->FUNCOP-1K17 K) =HIDDENR1 K"
  proof(rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "SumCARD-3K6 (x .-->FUNCOP-1K17 K) =HIDDENR1 cardCARD-1K1 (UnionCARD-3K3 (x .-->FUNCOP-1K17 ([:ZFMISC-1K2 K,{TARSKIK1 x} :])))"
      using card_3_th_4 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 K,{TARSKIK1 x} :])"
      using card_3_th_7 sorry
    also have "... = cardCARD-1K1 K"
      using card_1_th_69 sorry
    also have "... = K"
       sorry
    finally show "SumCARD-3K6 (x .-->FUNCOP-1K17 K) =HIDDENR1 K"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_38:
" for K be CardinalCARD-1M1 holds  for x be objectHIDDENM1 holds ProductCARD-3K7 (x .-->FUNCOP-1K17 K) =XBOOLE-0R4 K"
proof-
  have " for K be CardinalCARD-1M1 holds  for x be objectHIDDENM1 holds ProductCARD-3K7 (x .-->FUNCOP-1K17 K) =HIDDENR1 K"
  proof(rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "ProductCARD-3K7 (x .-->FUNCOP-1K17 K) =HIDDENR1 cardCARD-1K1 (FuncsFUNCT-2K1({TARSKIK1 x},K))"
      using card_3_th_11 sorry
    also have "... = cardCARD-1K1 K"
      using funct_5_th_58 sorry
    also have "... = K"
       sorry
    finally show "ProductCARD-3K7 (x .-->FUNCOP-1K17 K) =HIDDENR1 K"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_39:
" for f be FunctionFUNCT-1M1 holds cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 f)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 f)"
    proof(rule impI)
      assume "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "{}XBOOLE-0K1 =XBOOLE-0R4 UnionCARD-3K3 f"
        using relat_1_th_42 zfmisc_1_th_2 sorry
      thus "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 f)"
         sorry
    qed
    have "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1 implies cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 f)"
    proof(rule impI)
      assume A2: "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st A =HIDDENR1 Lamb2 & ( for x be objectHIDDENM1 holds x inHIDDENR3 A iff x inHIDDENR3 FuncsFUNCT-2K1(cardCARD-1K1 Lamb1,Lamb1) & ( ex g be FunctionFUNCT-1M1 st x =HIDDENR1 g & rngFUNCT-1K2 g =XBOOLE-0R4 Lamb1))"
      let ?W = "\<lambda>Lamb1. \<lambda>Lamb2. ?P(f .FUNCT-1K1 Lamb1,Lamb2)"
      have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( ex y be objectHIDDENM1 st ?W(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( ex tVar12 be objectHIDDENM1 st  ex A be setHIDDENM2 st A =HIDDENR1 tVar12 & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 A iff xc inHIDDENR3 FuncsFUNCT-2K1(cardCARD-1K1 (f .FUNCT-1K1 x),f .FUNCT-1K1 x) & ( ex g be FunctionFUNCT-1M1 st xc =HIDDENR1 g & rngFUNCT-1K2 g =XBOOLE-0R4 f .FUNCT-1K1 x)))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          let ?A = "\<lambda>Lamb1.  ex g be FunctionFUNCT-1M1 st Lamb1 =HIDDENR1 g & rngFUNCT-1K2 g =XBOOLE-0R4 f .FUNCT-1K1 x"
          obtain Y where
            [ty]:"Y be setHIDDENM2" and 
            A4: " for z be objectHIDDENM1 holds z inHIDDENR3 Y iff z inHIDDENR3 FuncsFUNCT-2K1(cardCARD-1K1 (f .FUNCT-1K1 x),f .FUNCT-1K1 x) & ?A(z)"
            using xboole_0_sch_1 sorry
          show " ex tVar12 be objectHIDDENM1 st  ex A be setHIDDENM2 st A =HIDDENR1 tVar12 & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 A iff xc inHIDDENR3 FuncsFUNCT-2K1(cardCARD-1K1 (f .FUNCT-1K1 x),f .FUNCT-1K1 x) & ( ex g be FunctionFUNCT-1M1 st xc =HIDDENR1 g & rngFUNCT-1K2 g =XBOOLE-0R4 f .FUNCT-1K1 x))"
          proof(rule bexI[of _ "Y"])
            have "?P(f .FUNCT-1K1 x,Y)"
              using A4 sorry
            thus " ex A be setHIDDENM2 st A =HIDDENR1 Y & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 A iff xc inHIDDENR3 FuncsFUNCT-2K1(cardCARD-1K1 (f .FUNCT-1K1 x),f .FUNCT-1K1 x) & ( ex g be FunctionFUNCT-1M1 st xc =HIDDENR1 g & rngFUNCT-1K2 g =XBOOLE-0R4 f .FUNCT-1K1 x))"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain k where
        [ty]:"k be FunctionFUNCT-1M1" and 
        A5: "domRELAT-1K1 k =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ?W(x,k .FUNCT-1K1 x))"
        using classes1_sch_1 A3 sorry
      obtain M where 
        [ty]:"M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and MDef:"M = rngFUNCT-1K2 k"
        using A2 A5 relat_1_th_42 sorry
      have " for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        assume "X inTARSKIR2 M"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A6: "x inHIDDENR3 domRELAT-1K1 k"and A7: "X =XBOOLE-0R4 k .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have "(cardCARD-1K1 (f .FUNCT-1K1 x),f .FUNCT-1K1 x)are-equipotentWELLORD2R2"
          using card_1_def_2 sorry
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          "g be one-to-oneFUNCT-1V2"and A8: "domRELAT-1K1 g =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x)"and A9: "rngFUNCT-1K2 g =XBOOLE-0R4 f .FUNCT-1K1 x"
           sorry
        have A10: "g inTARSKIR2 FuncsFUNCT-2K1(cardCARD-1K1 (f .FUNCT-1K1 x),f .FUNCT-1K1 x)"
          using A8 A9 funct_2_def_2 sorry
        have "?W(x,k .FUNCT-1K1 x)"
          using A5 A6 sorry
        thus "X <>HIDDENR2 {}XBOOLE-0K1"
          using A7 A9 A10 sorry
      qed "sorry"
      then obtain FF where
        [ty]:"FF be FunctionFUNCT-1M1" and 
        "domRELAT-1K1 FF =XBOOLE-0R4 M"and A11: " for X be setHIDDENM2 holds X inTARSKIR2 M implies FF .FUNCT-1K1 X inTARSKIR2 X"
        using funct_1_th_111 sorry
      let ?DD = "unionTARSKIK3 (rngFUNCT-1K2 (disjoinCARD-3K2 (CardCARD-3K1 f)))"
      let ?S = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st g =XBOOLE-0R4 FF .FUNCT-1K1 (k .FUNCT-1K1 Lamb1 `2XTUPLE-0K2) & Lamb2 =HIDDENR1 g .FUNCT-1K1 Lamb1 `1XTUPLE-0K1"
      have A12: " for x be objectHIDDENM1 holds x inHIDDENR3 ?DD implies ( ex y be objectHIDDENM1 st ?S(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 (disjoinCARD-3K2 (CardCARD-3K1 f))) implies ( ex tVar13 be objectHIDDENM1 st  ex tVar14 be FunctionFUNCT-1M1 st tVar14 =XBOOLE-0R4 FF .FUNCT-1K1 (k .FUNCT-1K1 x `2XTUPLE-0K2) & tVar14 .FUNCT-1K1 x `1XTUPLE-0K1 =HIDDENR1 tVar14 .FUNCT-1K1 x `1XTUPLE-0K1)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?DD"
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A13: "x inHIDDENR3 X"and A14: "X inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 (CardCARD-3K1 f))"
            using tarski_def_4 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A15: "y inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 (CardCARD-3K1 f))"and A16: "X =XBOOLE-0R4 disjoinCARD-3K2 (CardCARD-3K1 f) .FUNCT-1K1 y"
            using A14 funct_1_def_3 sorry
          have A17: "domRELAT-1K1 (disjoinCARD-3K2 (CardCARD-3K1 f)) =XBOOLE-0R4 domRELAT-1K1 (CardCARD-3K1 f)"
            using card_3_def_3 sorry
          have A18: "domRELAT-1K1 (CardCARD-3K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
            using card_3_def_2 sorry
          have "X =XBOOLE-0R4 [:ZFMISC-1K2 CardCARD-3K1 f .FUNCT-1K1 y,{TARSKIK1 y} :]"
            using A15 A16 A17 card_3_def_3 sorry
          then have "x `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 y}"
            using A13 mcart_1_th_10 sorry
          then have A19: "x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 f"
            using A15 A17 A18 tarski_def_1 sorry
          then have "k .FUNCT-1K1 x `2XTUPLE-0K2 inTARSKIR2 M"
            using A5 funct_1_def_3 sorry
          then have A20: "FF .FUNCT-1K1 (k .FUNCT-1K1 x `2XTUPLE-0K2) inTARSKIR2 k .FUNCT-1K1 x `2XTUPLE-0K2"
            using A11 sorry
          have "?W(x `2XTUPLE-0K2,k .FUNCT-1K1 x `2XTUPLE-0K2)"
            using A5 A19 sorry
          then have "FF .FUNCT-1K1 (k .FUNCT-1K1 x `2XTUPLE-0K2) inTARSKIR2 FuncsFUNCT-2K1(cardCARD-1K1 (f .FUNCT-1K1 x `2XTUPLE-0K2),f .FUNCT-1K1 x `2XTUPLE-0K2)"
            using A20 sorry
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A21: "FF .FUNCT-1K1 (k .FUNCT-1K1 x `2XTUPLE-0K2) =XBOOLE-0R4 g"and "domRELAT-1K1 g =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x `2XTUPLE-0K2)"and "rngFUNCT-1K2 g c=TARSKIR1 f .FUNCT-1K1 x `2XTUPLE-0K2"
            using funct_2_def_2 sorry
          show " ex tVar13 be objectHIDDENM1 st  ex tVar14 be FunctionFUNCT-1M1 st tVar14 =XBOOLE-0R4 FF .FUNCT-1K1 (k .FUNCT-1K1 x `2XTUPLE-0K2) & tVar14 .FUNCT-1K1 x `1XTUPLE-0K1 =HIDDENR1 tVar14 .FUNCT-1K1 x `1XTUPLE-0K1"
          proof(rule bexI[of _ "g .FUNCT-1K1 x `1XTUPLE-0K1"])
            show " ex tVar14 be FunctionFUNCT-1M1 st tVar14 =XBOOLE-0R4 FF .FUNCT-1K1 (k .FUNCT-1K1 x `2XTUPLE-0K2) & tVar14 .FUNCT-1K1 x `1XTUPLE-0K1 =HIDDENR1 tVar14 .FUNCT-1K1 x `1XTUPLE-0K1"
            proof(rule bexI[of _ "g"])
              show "g =XBOOLE-0R4 FF .FUNCT-1K1 (k .FUNCT-1K1 x `2XTUPLE-0K2) & g .FUNCT-1K1 x `1XTUPLE-0K1 =HIDDENR1 g .FUNCT-1K1 x `1XTUPLE-0K1"
                using A21 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain t where
        [ty]:"t be FunctionFUNCT-1M1" and 
        A22: "domRELAT-1K1 t =XBOOLE-0R4 ?DD & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?DD implies ?S(x,t .FUNCT-1K1 x))"
        using classes1_sch_1 A12 sorry
      have "unionTARSKIK3 (rngFUNCT-1K2 f) c=TARSKIR1 rngFUNCT-1K2 t"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f) implies x inHIDDENR3 rngFUNCT-1K2 t"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A23: "x inHIDDENR3 X"and A24: "X inTARSKIR2 rngFUNCT-1K2 f"
            using tarski_def_4 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A25: "y inHIDDENR3 domRELAT-1K1 f"and A26: "X =XBOOLE-0R4 f .FUNCT-1K1 y"
            using A24 funct_1_def_3 sorry
          have "k .FUNCT-1K1 y inTARSKIR2 M"
            using A5 A25 funct_1_def_3 sorry
          then have A27: "FF .FUNCT-1K1 (k .FUNCT-1K1 y) inTARSKIR2 k .FUNCT-1K1 y"
            using A11 sorry
          have A28: "?W(y,k .FUNCT-1K1 y)"
            using A5 A25 sorry
          then have "FF .FUNCT-1K1 (k .FUNCT-1K1 y) inTARSKIR2 FuncsFUNCT-2K1(cardCARD-1K1 (f .FUNCT-1K1 y),f .FUNCT-1K1 y)"
            using A27 sorry
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A29: "FF .FUNCT-1K1 (k .FUNCT-1K1 y) =XBOOLE-0R4 g"and A30: "domRELAT-1K1 g =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 y)"and "rngFUNCT-1K2 g c=TARSKIR1 f .FUNCT-1K1 y"
            using funct_2_def_2 sorry
          have " ex g be FunctionFUNCT-1M1 st FF .FUNCT-1K1 (k .FUNCT-1K1 y) =XBOOLE-0R4 g & rngFUNCT-1K2 g =XBOOLE-0R4 f .FUNCT-1K1 y"
            using A27 A28 sorry
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A31: "z inHIDDENR3 domRELAT-1K1 g"and A32: "x =HIDDENR1 g .FUNCT-1K1 z"
            using A23 A26 A29 funct_1_def_3 sorry
          have A33: "CardCARD-3K1 f .FUNCT-1K1 y =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 y)"
            using A25 card_3_def_2 sorry
          have A34: "domRELAT-1K1 (CardCARD-3K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
            using card_3_def_2 sorry
          then have A35: "disjoinCARD-3K2 (CardCARD-3K1 f) .FUNCT-1K1 y =XBOOLE-0R4 [:ZFMISC-1K2 domRELAT-1K1 g,{TARSKIK1 y} :]"
            using A25 A30 A33 card_3_def_3 sorry
          have A36: "y inHIDDENR3 {TARSKIK1 y}"
            using tarski_def_1 sorry
          have A37: "domRELAT-1K1 (disjoinCARD-3K2 (CardCARD-3K1 f)) =XBOOLE-0R4 domRELAT-1K1 f"
            using A34 card_3_def_3 sorry
          have A38: "[TARSKIK4 z,y ] inHIDDENR3 [:ZFMISC-1K2 domRELAT-1K1 g,{TARSKIK1 y} :]"
            using A31 A36 zfmisc_1_th_87 sorry
          have "[:ZFMISC-1K2 domRELAT-1K1 g,{TARSKIK1 y} :] inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 (CardCARD-3K1 f))"
            using A25 A35 A37 funct_1_def_3 sorry
          then have A39: "[TARSKIK4 z,y ] inHIDDENR3 ?DD"
            using A38 tarski_def_4 sorry
          have A40: "[TARSKIK4 z,y ] `1XTUPLE-0K1 =HIDDENR1 z"
             sorry
          have "[TARSKIK4 z,y ] `2XTUPLE-0K2 =HIDDENR1 y"
             sorry
          then have " ex g be FunctionFUNCT-1M1 st g =XBOOLE-0R4 FF .FUNCT-1K1 (k .FUNCT-1K1 y) & t .FUNCT-1K1 [TARSKIK4 z,y ] =XBOOLE-0R4 g .FUNCT-1K1 z"
            using A22 A39 A40 sorry
          thus "x inHIDDENR3 rngFUNCT-1K2 t"
            using A22 A29 A32 A39 funct_1_def_3 sorry
        qed "sorry"
        thus "unionTARSKIK3 (rngFUNCT-1K2 f) c=TARSKIR1 rngFUNCT-1K2 t"
          using tarski_def_3 sorry
      qed
      thus "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 f)"
        using A22 card_1_th_12 sorry
    qed
    thus "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 f)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_40:
" for F be Cardinal-FunctionCARD-3M1 holds cardCARD-1K1 (UnionCARD-3K3 F) c=ORDINAL1R1 SumCARD-3K6 F"
proof-
  have " for F be Cardinal-FunctionCARD-3M1 holds cardCARD-1K1 (UnionCARD-3K3 F) c=ORDINAL1R1 SumCARD-3K6 F"
  proof(rule ballI)
    fix F assume [ty]: "F be Cardinal-FunctionCARD-3M1"
    have "CardCARD-3K1 F =FUNCT-1R1 F"
      using card_3_th_1 sorry
    thus "cardCARD-1K1 (UnionCARD-3K3 F) c=ORDINAL1R1 SumCARD-3K6 F"
      using card_3_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Koenig Theorem*)
mtheorem card_3_th_41:
" for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x inTARSKIR2 G .FUNCT-1K1 x) implies SumCARD-3K6 F inTARSKIR2 ProductCARD-3K7 G"
proof-
  have " for F be Cardinal-FunctionCARD-3M1 holds  for G be Cardinal-FunctionCARD-3M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x inTARSKIR2 G .FUNCT-1K1 x) implies SumCARD-3K6 F inTARSKIR2 ProductCARD-3K7 G"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix F assume [ty]: "F be Cardinal-FunctionCARD-3M1"
    fix G assume [ty]: "G be Cardinal-FunctionCARD-3M1"
    assume A1: "domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x inTARSKIR2 G .FUNCT-1K1 x"
    let ?f = "\<lambda>Lamb1. G .FUNCT-1K1 Lamb1 \\SUBSET-1K6 F .FUNCT-1K1 Lamb1"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 F & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies f .FUNCT-1K1 x =XBOOLE-0R4 ?f(x))"
      using funct_1_sch_3 sorry
    have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies  False "
    proof(rule impI)
      assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A4: "x inHIDDENR3 domRELAT-1K1 f"and A5: "{}XBOOLE-0K1 =XBOOLE-0R4 f .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      obtain Fx Gx where 
        [ty]:"Fx be CardinalCARD-1M1" and FxDef:"Fx = F .FUNCT-1K1 x" and
        [ty]:"Gx be CardinalCARD-1M1" and GxDef:"Gx = G .FUNCT-1K1 x"
        using A1 A3 A4 card_3_def_1 sorry
      have A6: "Fx inTARSKIR2 Gx"
        using A2 A3 A4 sorry
      have " not Fx inTARSKIR2 Fx"
         sorry
      then have "Fx inTARSKIR2 Gx \\SUBSET-1K6 Fx"
        using A6 xboole_0_def_5 sorry
      thus " False "
        using A3 A4 A5 sorry
    qed
    then have A7: "productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1"
      using card_3_th_26 sorry
    let ?a = "the ElementSUBSET-1M1-of productCARD-3K4 f"
    obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      "?a =XBOOLE-0R4 h"and "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"and A8: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies h .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
      using A7 card_3_def_5 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. domRELAT-1K1 Lamb2 =XBOOLE-0R4 domRELAT-1K1 F & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies (Lamb1 `2XTUPLE-0K2 =HIDDENR1 x implies Lamb2 .FUNCT-1K1 x =HIDDENR1 Lamb1 `1XTUPLE-0K1) & (Lamb1 `2XTUPLE-0K2 <>HIDDENR2 x implies Lamb2 .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x))"
    let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st Lamb2 =HIDDENR1 g & ?P(Lamb1,g)"
    have A9: " for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 F implies ( ex y be objectHIDDENM1 st ?R(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 F implies ( ex tVar15 be objectHIDDENM1 st  ex tVar16 be FunctionFUNCT-1M1 st tVar15 =HIDDENR1 tVar16 & (domRELAT-1K1 tVar16 =XBOOLE-0R4 domRELAT-1K1 F & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 domRELAT-1K1 F implies (x `2XTUPLE-0K2 =HIDDENR1 xc implies tVar16 .FUNCT-1K1 xc =HIDDENR1 x `1XTUPLE-0K1) & (x `2XTUPLE-0K2 <>HIDDENR2 xc implies tVar16 .FUNCT-1K1 xc =XBOOLE-0R4 h .FUNCT-1K1 xc))))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 F"
        let ?f = "\<lambda>Lamb1. x `1XTUPLE-0K1"
        let ?g = "\<lambda>Lamb1. h .FUNCT-1K1 Lamb1"
        let ?C = "\<lambda>Lamb1. Lamb1 =HIDDENR1 x `2XTUPLE-0K2"
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A10: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 F & ( for u be objectHIDDENM1 holds u inHIDDENR3 domRELAT-1K1 F implies (?C(u) implies g .FUNCT-1K1 u =HIDDENR1 ?f(u)) & ( not ?C(u) implies g .FUNCT-1K1 u =XBOOLE-0R4 ?g(u)))"
          using partfun1_sch_1 sorry
        obtain y where 
          [ty]:"y be objectHIDDENM1" and yDef:"y = g"
           sorry
        show " ex tVar15 be objectHIDDENM1 st  ex tVar16 be FunctionFUNCT-1M1 st tVar15 =HIDDENR1 tVar16 & (domRELAT-1K1 tVar16 =XBOOLE-0R4 domRELAT-1K1 F & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 domRELAT-1K1 F implies (x `2XTUPLE-0K2 =HIDDENR1 xc implies tVar16 .FUNCT-1K1 xc =HIDDENR1 x `1XTUPLE-0K1) & (x `2XTUPLE-0K2 <>HIDDENR2 xc implies tVar16 .FUNCT-1K1 xc =XBOOLE-0R4 h .FUNCT-1K1 xc)))"
        proof(rule bexI[of _ "y"])
          show " ex tVar16 be FunctionFUNCT-1M1 st y =HIDDENR1 tVar16 & (domRELAT-1K1 tVar16 =XBOOLE-0R4 domRELAT-1K1 F & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 domRELAT-1K1 F implies (x `2XTUPLE-0K2 =HIDDENR1 xc implies tVar16 .FUNCT-1K1 xc =HIDDENR1 x `1XTUPLE-0K1) & (x `2XTUPLE-0K2 <>HIDDENR2 xc implies tVar16 .FUNCT-1K1 xc =XBOOLE-0R4 h .FUNCT-1K1 xc)))"
          proof(rule bexI[of _ "g"])
            show "y =HIDDENR1 g & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 F & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 domRELAT-1K1 F implies (x `2XTUPLE-0K2 =HIDDENR1 xc implies g .FUNCT-1K1 xc =HIDDENR1 x `1XTUPLE-0K1) & (x `2XTUPLE-0K2 <>HIDDENR2 xc implies g .FUNCT-1K1 xc =XBOOLE-0R4 h .FUNCT-1K1 xc)))"
              using A10 sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f1 where
      [ty]:"f1 be FunctionFUNCT-1M1" and 
      A11: "domRELAT-1K1 f1 =XBOOLE-0R4 UnionCARD-3K3 disjoinCARD-3K2 F & ( for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 F implies ?R(x,f1 .FUNCT-1K1 x))"
      using classes1_sch_1 A9 sorry
    have A12: "f1 be one-to-oneFUNCT-1V2"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 & (y inHIDDENR3 domRELAT-1K1 f1 & (f1 .FUNCT-1K1 x =XBOOLE-0R4 f1 .FUNCT-1K1 y & x <>HIDDENR2 y)) implies  False "
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A13: "x inHIDDENR3 domRELAT-1K1 f1"
          and A14: "y inHIDDENR3 domRELAT-1K1 f1"
          and A15: "f1 .FUNCT-1K1 x =XBOOLE-0R4 f1 .FUNCT-1K1 y"
          and A16: "x <>HIDDENR2 y"
        obtain g1 where
          [ty]:"g1 be FunctionFUNCT-1M1" and 
          A17: "f1 .FUNCT-1K1 x =XBOOLE-0R4 g1"and A18: "?P(x,g1)"
          using A11 A13 sorry
        obtain g2 where
          [ty]:"g2 be FunctionFUNCT-1M1" and 
          A19: "f1 .FUNCT-1K1 y =XBOOLE-0R4 g2"and A20: "?P(y,g2)"
          using A11 A14 sorry
        have A21: "x `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 F"
          using A11 A13 card_3_th_22 sorry
        have A22: "y `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 F"
          using A11 A14 card_3_th_22 sorry
        have A23: "y `1XTUPLE-0K1 inHIDDENR3 F .FUNCT-1K1 y `2XTUPLE-0K2"
          using A11 A14 card_3_th_22 sorry
        have A24: " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using A11 A13 card_3_th_21 sorry
        have A25: " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st y =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using A11 A14 card_3_th_21 sorry
        have A26: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
          using A24 sorry
        have A27: "y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
          using A25 sorry
        have A28: "x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1 implies  False "
        proof(rule impI)
          assume A29: "x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1"
          have A30: "g2 .FUNCT-1K1 y `2XTUPLE-0K2 =HIDDENR1 y `1XTUPLE-0K1"
            using A20 A22 sorry
          have A31: "g1 .FUNCT-1K1 y `2XTUPLE-0K2 =XBOOLE-0R4 h .FUNCT-1K1 y `2XTUPLE-0K2"
            using A16 A18 A22 A26 A27 A29 sorry
          have A32: "f .FUNCT-1K1 y `2XTUPLE-0K2 =XBOOLE-0R4 G .FUNCT-1K1 y `2XTUPLE-0K2 \\SUBSET-1K6 F .FUNCT-1K1 y `2XTUPLE-0K2"
            using A3 A22 sorry
          have "h .FUNCT-1K1 y `2XTUPLE-0K2 inTARSKIR2 f .FUNCT-1K1 y `2XTUPLE-0K2"
            using A3 A8 A22 sorry
          thus " False "
            using A15 A17 A19 A23 A30 A31 A32 xboole_0_def_5 sorry
        qed
        have A33: "x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2 implies g1 .FUNCT-1K1 x `2XTUPLE-0K2 =HIDDENR1 x `1XTUPLE-0K1 & g2 .FUNCT-1K1 x `2XTUPLE-0K2 =HIDDENR1 y `1XTUPLE-0K1"
          using A18 A20 A21 sorry
        have A34: "g1 .FUNCT-1K1 y `2XTUPLE-0K2 =HIDDENR1 y `1XTUPLE-0K1"
          using A15 A17 A19 A20 A22 sorry
        have A35: "g1 .FUNCT-1K1 y `2XTUPLE-0K2 =XBOOLE-0R4 h .FUNCT-1K1 y `2XTUPLE-0K2"
          using A15 A17 A18 A19 A22 A28 A33 sorry
        have A36: "f .FUNCT-1K1 y `2XTUPLE-0K2 =XBOOLE-0R4 G .FUNCT-1K1 y `2XTUPLE-0K2 \\SUBSET-1K6 F .FUNCT-1K1 y `2XTUPLE-0K2"
          using A3 A22 sorry
        have "h .FUNCT-1K1 y `2XTUPLE-0K2 inTARSKIR2 f .FUNCT-1K1 y `2XTUPLE-0K2"
          using A3 A8 A22 sorry
        thus " False "
          using A23 A34 A35 A36 xboole_0_def_5 sorry
      qed "sorry"
      thus "f1 be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    have "rngFUNCT-1K2 f1 c=TARSKIR1 productCARD-3K4 G"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f1 implies x inHIDDENR3 productCARD-3K4 G"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 f1"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A37: "y inHIDDENR3 domRELAT-1K1 f1"and A38: "x =HIDDENR1 f1 .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A39: "f1 .FUNCT-1K1 y =XBOOLE-0R4 g"and A40: "?P(y,g)"
          using A11 A37 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 G implies g .FUNCT-1K1 x inTARSKIR2 G .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A41: "x inHIDDENR3 domRELAT-1K1 G"
          then obtain Gx Fx where 
            [ty]:"Gx be CardinalCARD-1M1" and GxDef:"Gx = G .FUNCT-1K1 x" and
            [ty]:"Fx be CardinalCARD-1M1" and FxDef:"Fx = F .FUNCT-1K1 x"
            using A1 card_3_def_1 sorry
          have A42: "Fx inTARSKIR2 Gx"
            using A1 A2 A41 sorry
          have A43: "y `2XTUPLE-0K2 =HIDDENR1 x implies g .FUNCT-1K1 x =HIDDENR1 y `1XTUPLE-0K1"
            using A1 A40 A41 sorry
          have A44: "y `2XTUPLE-0K2 <>HIDDENR2 x implies g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
            using A1 A40 A41 sorry
          have A45: "h .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
            using A1 A3 A8 A41 sorry
          have A46: "f .FUNCT-1K1 x =XBOOLE-0R4 Gx \\SUBSET-1K6 Fx"
            using A1 A3 A41 sorry
          have A47: "y `1XTUPLE-0K1 inHIDDENR3 F .FUNCT-1K1 y `2XTUPLE-0K2"
            using A11 A37 card_3_th_22 sorry
          have "Fx c=ORDINAL1R1 Gx"
            using A42 card_1_th_3 sorry
          thus "g .FUNCT-1K1 x inTARSKIR2 G .FUNCT-1K1 x"
            using A43 A44 A45 A46 A47 sorry
        qed "sorry"
        thus "x inHIDDENR3 productCARD-3K4 G"
          using A1 A38 A39 A40 card_3_def_5 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f1 c=TARSKIR1 productCARD-3K4 G"
        using tarski_def_3 sorry
    qed
    then have A48: "SumCARD-3K6 F c=ORDINAL1R1 ProductCARD-3K7 G"
      using A11 A12 card_1_th_10 sorry
    have "SumCARD-3K6 F =XBOOLE-0R4 ProductCARD-3K7 G implies  False "
    proof(rule impI)
      assume "SumCARD-3K6 F =XBOOLE-0R4 ProductCARD-3K7 G"
      then have "(UnionCARD-3K3 disjoinCARD-3K2 F,productCARD-3K4 G)are-equipotentWELLORD2R2"
        using card_1_th_5 sorry
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        "f be one-to-oneFUNCT-1V2"and A49: "domRELAT-1K1 f =XBOOLE-0R4 UnionCARD-3K3 disjoinCARD-3K2 F"and A50: "rngFUNCT-1K2 f =XBOOLE-0R4 productCARD-3K4 G"
         sorry
      let ?f = "\<lambda>Lamb1. G .FUNCT-1K1 Lamb1 \\SUBSET-1K6 piCARD-3K5(f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 Lamb1),Lamb1)"
      obtain K where
        [ty]:"K be FunctionFUNCT-1M1" and 
        A51: "domRELAT-1K1 K =XBOOLE-0R4 domRELAT-1K1 F & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies K .FUNCT-1K1 x =XBOOLE-0R4 ?f(x))"
        using funct_1_sch_3 sorry
      have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 K implies  False "
      proof(rule impI)
        assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 K"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A52: "x inHIDDENR3 domRELAT-1K1 F"and A53: "{}XBOOLE-0K1 =XBOOLE-0R4 K .FUNCT-1K1 x"
          using A51 funct_1_def_3 sorry
        have 
          [ty]:"x be setHIDDENM2"
          using tarski_th_1 sorry
        have A54: "K .FUNCT-1K1 x =XBOOLE-0R4 G .FUNCT-1K1 x \\SUBSET-1K6 piCARD-3K5(f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 x),x)"
          using A51 A52 sorry
        obtain Fx Gx where 
          [ty]:"Fx be CardinalCARD-1M1" and FxDef:"Fx = F .FUNCT-1K1 x" and
          [ty]:"Gx be CardinalCARD-1M1" and GxDef:"Gx = G .FUNCT-1K1 x"
          using A1 A52 card_3_def_1 sorry
        have A55: "cardCARD-1K1 (piCARD-3K5(f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 x),x)) c=ORDINAL1R1 cardCARD-1K1 (f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 x))"
          using card_3_th_20 sorry
        have A56: "cardCARD-1K1 (f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 x)) c=ORDINAL1R1 cardCARD-1K1 (disjoinCARD-3K2 F .FUNCT-1K1 x)"
          using card_1_th_67 sorry
        have "cardCARD-1K1 (disjoinCARD-3K2 F .FUNCT-1K1 x) =XBOOLE-0R4 Fx"
          using A52 card_3_th_29 sorry
        then have A57: "cardCARD-1K1 (piCARD-3K5(f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 x),x)) c=ORDINAL1R1 Fx"
          using A55 A56 sorry
        have A58: "Fx inTARSKIR2 Gx"
          using A2 A52 sorry
        have "cardCARD-1K1 Gx =XBOOLE-0R4 Gx"
           sorry
        thus " False "
          using A53 A54 A57 A58 card_1_th_68 ordinal1_th_12 sorry
      qed
      then have A59: "productCARD-3K4 K <>HIDDENR2 {}XBOOLE-0K1"
        using card_3_th_26 sorry
      let ?t = "the ElementSUBSET-1M1-of productCARD-3K4 K"
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A60: "?t =XBOOLE-0R4 g"and "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 K"and A61: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 K implies g .FUNCT-1K1 x inTARSKIR2 K .FUNCT-1K1 x"
        using A59 card_3_def_5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 K implies K .FUNCT-1K1 x c=TARSKIR1 G .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 K"
        then have "K .FUNCT-1K1 x =XBOOLE-0R4 G .FUNCT-1K1 x \\SUBSET-1K6 piCARD-3K5(f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 x),x)"
          using A51 sorry
        thus "K .FUNCT-1K1 x c=TARSKIR1 G .FUNCT-1K1 x"
           sorry
      qed "sorry"
      then have "productCARD-3K4 K c=TARSKIR1 productCARD-3K4 G"
        using A1 A51 card_3_th_27 sorry
      then have "?t inTARSKIR2 productCARD-3K4 G"
        using A59 sorry
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A62: "y inHIDDENR3 domRELAT-1K1 f"and A63: "?t =XBOOLE-0R4 f .FUNCT-1K1 y"
        using A50 funct_1_def_3 sorry
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A64: "y inHIDDENR3 X"and A65: "X inTARSKIR2 rngFUNCT-1K2 (disjoinCARD-3K2 F)"
        using A49 A62 tarski_def_4 sorry
      obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A66: "x inHIDDENR3 domRELAT-1K1 (disjoinCARD-3K2 F)"and A67: "X =XBOOLE-0R4 disjoinCARD-3K2 F .FUNCT-1K1 x"
        using A65 funct_1_def_3 sorry
      have 
        [ty]:"x be setHIDDENM2"
        using tarski_th_1 sorry
      have "g inTARSKIR2 f .:FUNCT-1K5 X"
        using A60 A62 A63 A64 funct_1_def_6 sorry
      then have A68: "g .FUNCT-1K1 x inTARSKIR2 piCARD-3K5(f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 x),x)"
        using A67 card_3_def_6 sorry
      have A69: "x inTARSKIR2 domRELAT-1K1 F"
        using A66 card_3_def_3 sorry
      have A70: " not g .FUNCT-1K1 x inTARSKIR2 G .FUNCT-1K1 x \\SUBSET-1K6 piCARD-3K5(f .:FUNCT-1K5 (disjoinCARD-3K2 F .FUNCT-1K1 x),x)"
        using A68 xboole_0_def_5 sorry
      have "g .FUNCT-1K1 x inTARSKIR2 K .FUNCT-1K1 x"
        using A51 A61 A69 sorry
      thus " False "
        using A51 A69 A70 sorry
    qed
    thus "SumCARD-3K6 F inTARSKIR2 ProductCARD-3K7 G"
      using A48 card_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem card_3_sch_2:
  fixes Xf0 Ff1 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( for y be objectHIDDENM1 holds y inHIDDENR3 f .FUNCT-1K1 x iff y inHIDDENR3 Ff1(x) & Pp2(x,y)))"
  proof-
    have " ex tVar19 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar19 =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 tVar19 .FUNCT-1K1 x &  not (y inHIDDENR3 Ff1(x) & Pp2(x,y))) &  not ((y inHIDDENR3 Ff1(x) & Pp2(x,y)) &  not y inHIDDENR3 tVar19 .FUNCT-1K1 x)))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st A =HIDDENR1 Lamb2 & ( for y be objectHIDDENM1 holds y inHIDDENR3 A iff y inHIDDENR3 Ff1(Lamb1) & Pp2(Lamb1,y))"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex y be objectHIDDENM1 st ?Q(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex tVar17 be objectHIDDENM1 st  ex tVar18 be setHIDDENM2 st tVar18 =XBOOLE-0R4 tVar17 & ( for y be objectHIDDENM1 holds y inHIDDENR3 tVar18 iff y inHIDDENR3 Ff1(x) & Pp2(x,y)))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 Xf0"
          let ?R = "\<lambda>Lamb1. Pp2(x,Lamb1)"
          obtain Y where
            [ty]:"Y be setHIDDENM2" and 
            A2: " for y be objectHIDDENM1 holds y inHIDDENR3 Y iff y inHIDDENR3 Ff1(x) & ?R(y)"
            using xboole_0_sch_1 sorry
          show " ex tVar17 be objectHIDDENM1 st  ex tVar18 be setHIDDENM2 st tVar18 =XBOOLE-0R4 tVar17 & ( for y be objectHIDDENM1 holds y inHIDDENR3 tVar18 iff y inHIDDENR3 Ff1(x) & Pp2(x,y))"
          proof(rule bexI[of _ "Y"])
            obtain A where 
              [ty]:"A be setHIDDENM2" and ADef:"A = Y"
               sorry
            show " ex tVar18 be setHIDDENM2 st tVar18 =XBOOLE-0R4 Y & ( for y be objectHIDDENM1 holds y inHIDDENR3 tVar18 iff y inHIDDENR3 Ff1(x) & Pp2(x,y))"
            proof(rule bexI[of _ "A"])
              show "A =XBOOLE-0R4 Y & ( for y be objectHIDDENM1 holds y inHIDDENR3 A iff y inHIDDENR3 Ff1(x) & Pp2(x,y))"
                using A2 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 Xf0"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ?Q(x,f .FUNCT-1K1 x)"
        using classes1_sch_1 A1 sorry
      show " ex tVar19 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar19 =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 tVar19 .FUNCT-1K1 x &  not (y inHIDDENR3 Ff1(x) & Pp2(x,y))) &  not ((y inHIDDENR3 Ff1(x) & Pp2(x,y)) &  not y inHIDDENR3 tVar19 .FUNCT-1K1 x)))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
        show "domRELAT-1K1 f =XBOOLE-0R4 Xf0"
          using A3 sorry
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 Xf0"
        then obtain A where
          [ty]:"A be setHIDDENM2" and 
          A5: "A =XBOOLE-0R4 f .FUNCT-1K1 x"and A6: " for y be objectHIDDENM1 holds y inHIDDENR3 A iff y inHIDDENR3 Ff1(x) & Pp2(x,y)"
          using A4 sorry
        show " for y be objectHIDDENM1 holds  not (y inHIDDENR3 f .FUNCT-1K1 x &  not (y inHIDDENR3 Ff1(x) & Pp2(x,y))) &  not ((y inHIDDENR3 Ff1(x) & Pp2(x,y)) &  not y inHIDDENR3 f .FUNCT-1K1 x)"
          using A5 A6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mlemma card_3_lm_1:
" for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds x inHIDDENR3 fieldRELAT-1K3 R implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R or [TARSKIK4 y,x ] inHIDDENR3 R)"
proof-
  have " for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds x inHIDDENR3 fieldRELAT-1K3 R implies  not ( for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 R &  not [TARSKIK4 y,x ] inHIDDENR3 R)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "x inHIDDENR3 fieldRELAT-1K3 R"
    then have "x inHIDDENR3 domRELAT-1K1 R or x inHIDDENR3 rngRELAT-1K2 R"
      using xboole_0_def_3 sorry
    thus " not ( for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 R &  not [TARSKIK4 y,x ] inHIDDENR3 R)"
      using xtuple_0_def_12 xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_42:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (omegaORDINAL1K4)"
proof-
  have " for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (omegaORDINAL1K4)"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X be finiteFINSET-1V1"
    then have " ex n be NatORDINAL1M6 st cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K4 n"
      using card_1_th_48 sorry
    thus "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (omegaORDINAL1K4)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_43:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds cardCARD-1K1 A inTARSKIR2 cardCARD-1K1 B implies A inTARSKIR2 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds cardCARD-1K1 A inTARSKIR2 cardCARD-1K1 B &  not A inTARSKIR2 B implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "cardCARD-1K1 A inTARSKIR2 cardCARD-1K1 B"
      and A2: " not A inTARSKIR2 B"
    have " not cardCARD-1K1 B c=ORDINAL1R1 cardCARD-1K1 A"
      using A1 card_1_th_4 sorry
    thus " False "
      using A2 card_1_th_11 ordinal1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_44:
" for A be OrdinalORDINAL1M3 holds  for M be CardinalCARD-1M1 holds cardCARD-1K1 A inTARSKIR2 M implies A inTARSKIR2 M"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for M be CardinalCARD-1M1 holds  not (cardCARD-1K1 A inTARSKIR2 M &  not A inTARSKIR2 M)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    have "cardCARD-1K1 M =XBOOLE-0R4 M"
       sorry
    thus " not (cardCARD-1K1 A inTARSKIR2 M &  not A inTARSKIR2 M)"
      using card_3_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_45:
" for X be setHIDDENM2 holds X be c=-linearORDINAL1V6 implies ( ex Y be setHIDDENM2 st (Y c=TARSKIR1 X & unionTARSKIK3 Y =XBOOLE-0R4 unionTARSKIK3 X) & ( for Z be setHIDDENM2 holds Z c=TARSKIR1 Y & Z <>HIDDENR2 {}XBOOLE-0K1 implies ( ex Z1 be setHIDDENM2 st Z1 inTARSKIR2 Z & ( for Z2 be setHIDDENM2 holds Z2 inTARSKIR2 Z implies Z1 c=TARSKIR1 Z2))))"
proof-
  have " for X be setHIDDENM2 holds X be c=-linearORDINAL1V6 implies ( ex Z be setHIDDENM2 st Z c=TARSKIR1 X & (unionTARSKIK3 Z =XBOOLE-0R4 unionTARSKIK3 X & ( for Z be setHIDDENM2 holds  not ((Z c=TARSKIR1 Z &  not Z <>HIDDENR2 {}XBOOLE-0K1) & ( for Z1 be setHIDDENM2 holds  not (Z1 inTARSKIR2 Z & ( for Z2 be setHIDDENM2 holds  not (Z2 inTARSKIR2 Z &  not Z1 c=TARSKIR1 Z2))))))))"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X be c=-linearORDINAL1V6"
    obtain R where
      [ty]:"R be RelationRELAT-1M1" and 
      A2: "R well-ordersWELLORD1R2 X"
      using wellord2_th_17 sorry
    have A3: "R  |-2WELLORD1K2 X be well-orderingWELLORD1V2"
      using A2 wellord2_th_16 sorry
    have A4: "fieldRELAT-1K3 (R  |-2WELLORD1K2 X) =XBOOLE-0R4 X"
      using A2 wellord2_th_16 sorry
    have "(R  |-2WELLORD1K2 X,RelInclWELLORD2K1 (order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X))are-isomorphicWELLORD1R4"
      using A3 wellord2_def_2 sorry
    then have "(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X),R  |-2WELLORD1K2 X)are-isomorphicWELLORD1R4"
      using wellord1_th_40 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A5: "f is-isomorphism-ofWELLORD1R3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X),R  |-2WELLORD1K2 X)"
       sorry
    have "fieldRELAT-1K3 (RelInclWELLORD2K1 (order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X)) =XBOOLE-0R4 order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X"
      using wellord2_def_1 sorry
    then have A6: "domRELAT-1K1 f =XBOOLE-0R4 order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X"
      using A5 sorry
    have A7: "rngFUNCT-1K2 f =XBOOLE-0R4 X"
      using A4 A5 sorry
    let ?P = "\<lambda>Lamb1.  for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A & Lamb1 =HIDDENR1 A implies f .FUNCT-1K1 B c=TARSKIR1 f .FUNCT-1K1 A"
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A8: " for x be setHIDDENM2 holds x inTARSKIR2 Y iff x inTARSKIR2 domRELAT-1K1 f & ?P(x)"
      using xfamily_sch_1 sorry
    obtain Z where 
      [ty]:"Z be setHIDDENM2" and ZDef:"Z = f .:FUNCT-1K5 Y"
       sorry
    show " ex Z be setHIDDENM2 st Z c=TARSKIR1 X & (unionTARSKIK3 Z =XBOOLE-0R4 unionTARSKIK3 X & ( for Z be setHIDDENM2 holds  not ((Z c=TARSKIR1 Z &  not Z <>HIDDENR2 {}XBOOLE-0K1) & ( for Z1 be setHIDDENM2 holds  not (Z1 inTARSKIR2 Z & ( for Z2 be setHIDDENM2 holds  not (Z2 inTARSKIR2 Z &  not Z1 c=TARSKIR1 Z2)))))))"
    proof(rule bexI[of _ "Z"],rule conjMI)
      show "Z c=TARSKIR1 X"
        using A7 relat_1_th_111 sorry
      have "unionTARSKIK3 Z c=TARSKIR1 unionTARSKIK3 X & (unionTARSKIK3 X c=TARSKIR1 unionTARSKIK3 Z & ( for V be setHIDDENM2 holds V c=TARSKIR1 Z & V <>HIDDENR2 {}XBOOLE-0K1 implies ( ex Z1 be setHIDDENM2 st Z1 inTARSKIR2 V & ( for Z2 be setHIDDENM2 holds Z2 inTARSKIR2 V implies Z1 c=TARSKIR1 Z2))))"
      proof(rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
        show "unionTARSKIK3 Z c=TARSKIR1 unionTARSKIK3 X"
          using A7 relat_1_th_111 zfmisc_1_th_77 sorry
        show "unionTARSKIK3 X c=TARSKIR1 unionTARSKIK3 Z"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 X implies x inHIDDENR3 unionTARSKIK3 Z"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 unionTARSKIK3 X"
            then obtain Z1 where
              [ty]:"Z1 be setHIDDENM2" and 
              A9: "x inHIDDENR3 Z1"and A10: "Z1 inTARSKIR2 X"
              using tarski_def_4 sorry
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A11: "y inHIDDENR3 domRELAT-1K1 f"and A12: "Z1 =XBOOLE-0R4 f .FUNCT-1K1 y"
              using A7 A10 funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A6 A11 sorry
            let ?P = "\<lambda>Lamb1. Lamb1 c=ORDINAL1R1 y & x inHIDDENR3 f .FUNCT-1K1 Lamb1"
            have A13: " ex A be OrdinalORDINAL1M3 st ?P(A)"
              using A9 A12 sorry
            obtain A where
              [ty]:"A be OrdinalORDINAL1M3" and 
              A14: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
              using ordinal1_sch_1 A13 sorry
            have A15: "A inTARSKIR2 domRELAT-1K1 f"
              using A6 A11 A14 ordinal1_th_12 sorry
            have " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B & A =XBOOLE-0R4 B implies f .FUNCT-1K1 C c=TARSKIR1 f .FUNCT-1K1 B"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix B assume [ty]: "B be OrdinalORDINAL1M3"
              fix C assume [ty]: "C be OrdinalORDINAL1M3"
              assume A16: "C inTARSKIR2 B"
                and A17: "A =XBOOLE-0R4 B"
              have A18: "C inTARSKIR2 domRELAT-1K1 f"
                using A6 A11 A14 A16 A17 ordinal1_th_10 sorry
              have A19: " not C c=ORDINAL1R1 y or  not x inHIDDENR3 f .FUNCT-1K1 C"
                using A14 A16 A17 ordinal1_th_5 sorry
              have A20: "f .FUNCT-1K1 A inTARSKIR2 X"
                using A7 A15 funct_1_def_3 sorry
              have "f .FUNCT-1K1 C inTARSKIR2 X"
                using A7 A18 funct_1_def_3 sorry
              then have "(f .FUNCT-1K1 C,f .FUNCT-1K1 A)are-c=-comparableXBOOLE-0R3"
                using A1 A20 sorry
              then have "f .FUNCT-1K1 C c=TARSKIR1 f .FUNCT-1K1 A or f .FUNCT-1K1 A c=TARSKIR1 f .FUNCT-1K1 C"
                 sorry
              thus "f .FUNCT-1K1 C c=TARSKIR1 f .FUNCT-1K1 B"
                using A14 A16 A17 A19 ordinal1_def_2 sorry
            qed "sorry"
            then have "A inTARSKIR2 Y"
              using A8 A15 sorry
            then have "f .FUNCT-1K1 A inTARSKIR2 Z"
              using A15 funct_1_def_6 sorry
            thus "x inHIDDENR3 unionTARSKIK3 Z"
              using A14 tarski_def_4 sorry
          qed "sorry"
          thus "unionTARSKIK3 X c=TARSKIR1 unionTARSKIK3 Z"
            using tarski_def_3 sorry
        qed
        fix V assume [ty]: "V be setHIDDENM2"
        assume A21: "V c=TARSKIR1 Z"
          and A22: "V <>HIDDENR2 {}XBOOLE-0K1"
        let ?x = "the ElementSUBSET-1M1-of V"
        have "?x inTARSKIR2 Z"
          using A21 A22 sorry
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A23: "y inHIDDENR3 domRELAT-1K1 f"and A24: "y inHIDDENR3 Y"and A25: "?x =XBOOLE-0R4 f .FUNCT-1K1 y"
          using funct_1_def_6 sorry
        have 
          [ty]:"y be OrdinalORDINAL1M3"
          using A6 A23 sorry
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 Y & f .FUNCT-1K1 Lamb1 inTARSKIR2 V"
        have "y =XBOOLE-0R4 y"
           sorry
        then have A26: " ex A be OrdinalORDINAL1M3 st ?P(A)"
          using A22 A24 A25 sorry
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A27: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
          using ordinal1_sch_1 A26 sorry
        obtain Z1 where 
          [ty]:"Z1 be setHIDDENM2" and Z1Def:"Z1 = f .FUNCT-1K1 A"
           sorry
        show " ex Z1 be setHIDDENM2 st Z1 inTARSKIR2 V & ( for Z2 be setHIDDENM2 holds Z2 inTARSKIR2 V implies Z1 c=TARSKIR1 Z2)"
        proof(rule bexI[of _ "Z1"],rule conjMI,rule ballI,rule impI)
          show "Z1 inTARSKIR2 V"
            using A27 sorry
          fix Z2 assume [ty]: "Z2 be setHIDDENM2"
          assume A28: "Z2 inTARSKIR2 V"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A29: "y inHIDDENR3 domRELAT-1K1 f"and A30: "y inHIDDENR3 Y"and A31: "Z2 =XBOOLE-0R4 f .FUNCT-1K1 y"
            using A21 funct_1_def_6 sorry
          have 
            [ty]:"y be OrdinalORDINAL1M3"
            using A6 A29 sorry
          have "A c<XBOOLE-0R2 y iff A c=ORDINAL1R1 y & A <>HIDDENR2 y"
             sorry
          then have "A =XBOOLE-0R4 y or A inTARSKIR2 y"
            using A27 A28 A30 A31 ordinal1_th_11 sorry
          thus "Z1 c=TARSKIR1 Z2"
            using A8 A30 A31 sorry
        qed "sorry"
      qed "sorry"
      thus "unionTARSKIK3 Z =XBOOLE-0R4 unionTARSKIK3 X & ( for Z be setHIDDENM2 holds  not ((Z c=TARSKIR1 Z &  not Z <>HIDDENR2 {}XBOOLE-0K1) & ( for Z1 be setHIDDENM2 holds  not (Z1 inTARSKIR2 Z & ( for Z2 be setHIDDENM2 holds  not (Z2 inTARSKIR2 Z &  not Z1 c=TARSKIR1 Z2))))))"
        using xboole_0_def_10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_46:
" for M be CardinalCARD-1M1 holds  for X be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 X implies cardCARD-1K1 Z inTARSKIR2 M) & X be c=-linearORDINAL1V6 implies cardCARD-1K1 (unionTARSKIK3 X) c=ORDINAL1R1 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for X be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 X implies cardCARD-1K1 Z inTARSKIR2 M) & X be c=-linearORDINAL1V6 implies cardCARD-1K1 (unionTARSKIK3 X) c=ORDINAL1R1 M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for Z be setHIDDENM2 holds Z inTARSKIR2 X implies cardCARD-1K1 Z inTARSKIR2 M"
      and A2: "X be c=-linearORDINAL1V6"
    obtain XX where
      [ty]:"XX be setHIDDENM2" and 
      A3: "XX c=TARSKIR1 X"and A4: "unionTARSKIK3 XX =XBOOLE-0R4 unionTARSKIK3 X"and A5: " for Z be setHIDDENM2 holds Z c=TARSKIR1 XX & Z <>HIDDENR2 {}XBOOLE-0K1 implies ( ex Z1 be setHIDDENM2 st Z1 inTARSKIR2 Z & ( for Z2 be setHIDDENM2 holds Z2 inTARSKIR2 Z implies Z1 c=TARSKIR1 Z2))"
      using A2 card_3_th_45 sorry
    have A6: " for Z1 be setHIDDENM2 holds  for Z2 be setHIDDENM2 holds Z1 inTARSKIR2 XX & Z2 inTARSKIR2 XX implies Z1 c=TARSKIR1 Z2 or Z2 c=TARSKIR1 Z1"
      using A2 A3 xboole_0_def_9 sorry
    obtain R where
      [ty]:"R be RelationRELAT-1M1" and 
      A7: "R well-ordersWELLORD1R2 unionTARSKIK3 X"
      using wellord2_th_17 sorry
    have A8: "R is-reflexive-inRELAT-2R1 unionTARSKIK3 X"
      using A7 sorry
    have A9: "R is-transitive-inRELAT-2R8 unionTARSKIK3 X"
      using A7 sorry
    have A10: "R is-antisymmetric-inRELAT-2R4 unionTARSKIK3 X"
      using A7 sorry
    have A11: "R is-connected-inRELAT-2R6 unionTARSKIK3 X"
      using A7 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. ( ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & Lamb1 inHIDDENR3 Z1) &  not Lamb2 inHIDDENR3 Z1) or ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (Lamb1 inHIDDENR3 Z1 iff Lamb2 inHIDDENR3 Z1)) & [TARSKIK4 Lamb1,Lamb2 ] inHIDDENR3 R"
    obtain Q where
      [ty]:"Q be RelationRELAT-1M1" and 
      A12: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Q iff (x inHIDDENR3 unionTARSKIK3 X & y inHIDDENR3 unionTARSKIK3 X) & ?P(x,y)"
      using relat_1_sch_1 sorry
    have A13: "fieldRELAT-1K3 Q =XBOOLE-0R4 unionTARSKIK3 X"
    proof-
      have "fieldRELAT-1K3 Q c=TARSKIR1 unionTARSKIK3 X & unionTARSKIK3 X c=TARSKIR1 fieldRELAT-1K3 Q"
      proof(rule conjMI)
        show "fieldRELAT-1K3 Q c=TARSKIR1 unionTARSKIK3 X"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 Q implies x inHIDDENR3 unionTARSKIK3 X"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 fieldRELAT-1K3 Q"
            then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 Q or [TARSKIK4 y,x ] inHIDDENR3 Q"
              using card_3_lm_1 sorry
            thus "x inHIDDENR3 unionTARSKIK3 X"
              using A12 sorry
          qed "sorry"
          thus "fieldRELAT-1K3 Q c=TARSKIR1 unionTARSKIK3 X"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 X implies x inHIDDENR3 fieldRELAT-1K3 Q"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A14: "x inHIDDENR3 unionTARSKIK3 X"
          then have A15: "[TARSKIK4 x,x ] inHIDDENR3 R"
            using A8 sorry
          have " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (x inHIDDENR3 Z1 iff x inHIDDENR3 Z1)"
             sorry
          then have "[TARSKIK4 x,x ] inHIDDENR3 Q"
            using A12 A14 A15 sorry
          thus "x inHIDDENR3 fieldRELAT-1K3 Q"
            using relat_1_th_15 sorry
        qed "sorry"
        thus "unionTARSKIK3 X c=TARSKIR1 fieldRELAT-1K3 Q"
          using tarski_def_3 sorry
      qed
      thus "fieldRELAT-1K3 Q =XBOOLE-0R4 unionTARSKIK3 X"
        using xboole_0_def_10 sorry
    qed
    have A16: "Q be reflexiveRELAT-2V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 Q implies [TARSKIK4 x,x ] inHIDDENR3 Q"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A17: "x inHIDDENR3 fieldRELAT-1K3 Q"
        then have A18: "[TARSKIK4 x,x ] inHIDDENR3 R"
          using A8 A13 sorry
        have " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (x inHIDDENR3 Z1 iff x inHIDDENR3 Z1)"
           sorry
        thus "[TARSKIK4 x,x ] inHIDDENR3 Q"
          using A12 A13 A17 A18 sorry
      qed "sorry"
      thus "Q be reflexiveRELAT-2V1"
        using relat_2_def_1 relat_2_def_9 sorry
    qed
    have A19: "Q be transitiveRELAT-2V8"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 Q & (y inHIDDENR3 fieldRELAT-1K3 Q & (z inHIDDENR3 fieldRELAT-1K3 Q & ([TARSKIK4 x,y ] inHIDDENR3 Q & [TARSKIK4 y,z ] inHIDDENR3 Q))) implies [TARSKIK4 x,z ] inHIDDENR3 Q"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A20: "x inHIDDENR3 fieldRELAT-1K3 Q"
          and A21: "y inHIDDENR3 fieldRELAT-1K3 Q"
          and A22: "z inHIDDENR3 fieldRELAT-1K3 Q"
          and A23: "[TARSKIK4 x,y ] inHIDDENR3 Q"
          and A24: "[TARSKIK4 y,z ] inHIDDENR3 Q"
        have A25: "( ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & x inHIDDENR3 Z1) &  not y inHIDDENR3 Z1) implies (( ex Z2 be setHIDDENM2 st (Z2 inTARSKIR2 XX & y inHIDDENR3 Z2) &  not z inHIDDENR3 Z2) implies [TARSKIK4 x,z ] inHIDDENR3 Q)"
        proof(rule impI,rule impI)
          assume Given: " ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & x inHIDDENR3 Z1) &  not y inHIDDENR3 Z1"
          then obtain Z1 where
            [ty]:"Z1 be setHIDDENM2" and 
            A26: "Z1 inTARSKIR2 XX"and A27: "x inHIDDENR3 Z1"and A28: " not y inHIDDENR3 Z1"
             sorry
          assume Given: " ex Z2 be setHIDDENM2 st (Z2 inTARSKIR2 XX & y inHIDDENR3 Z2) &  not z inHIDDENR3 Z2"
          then obtain Z2 where
            [ty]:"Z2 be setHIDDENM2" and 
            A29: "Z2 inTARSKIR2 XX"and A30: "y inHIDDENR3 Z2"and A31: " not z inHIDDENR3 Z2"
             sorry
          have "Z1 c=TARSKIR1 Z2 or Z2 c=TARSKIR1 Z1"
            using A6 A26 A29 sorry
          thus "[TARSKIK4 x,z ] inHIDDENR3 Q"
            using A12 A13 A20 A22 A27 A28 A29 A30 A31 sorry
        qed
        have A32: "( ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & x inHIDDENR3 Z1) &  not y inHIDDENR3 Z1) implies (( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (y inHIDDENR3 Z1 iff z inHIDDENR3 Z1)) & [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 Q)"
        proof(rule impI,rule impMI ,rule impI)
          assume Given: " ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & x inHIDDENR3 Z1) &  not y inHIDDENR3 Z1"
          then obtain Z1 where
            [ty]:"Z1 be setHIDDENM2" and 
            A33: "Z1 inTARSKIR2 XX"and A34: "x inHIDDENR3 Z1"and A35: " not y inHIDDENR3 Z1"
             sorry
          assume A36: " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (y inHIDDENR3 Z1 iff z inHIDDENR3 Z1)"
            and "[TARSKIK4 y,z ] inHIDDENR3 R"
          have " not z inHIDDENR3 Z1"
            using A33 A35 A36 sorry
          thus "[TARSKIK4 x,z ] inHIDDENR3 Q"
            using A12 A13 A20 A22 A33 A34 sorry
        qed
        have A37: "( ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & y inHIDDENR3 Z1) &  not z inHIDDENR3 Z1) implies (( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (x inHIDDENR3 Z1 iff y inHIDDENR3 Z1)) & [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,z ] inHIDDENR3 Q)"
        proof(rule impI,rule impMI ,rule impI)
          assume Given: " ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & y inHIDDENR3 Z1) &  not z inHIDDENR3 Z1"
          then obtain Z1 where
            [ty]:"Z1 be setHIDDENM2" and 
            A38: "Z1 inTARSKIR2 XX"and A39: "y inHIDDENR3 Z1"and A40: " not z inHIDDENR3 Z1"
             sorry
          assume A41: " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (x inHIDDENR3 Z1 iff y inHIDDENR3 Z1)"
            and "[TARSKIK4 x,y ] inHIDDENR3 R"
          have "x inHIDDENR3 Z1"
            using A38 A39 A41 sorry
          thus "[TARSKIK4 x,z ] inHIDDENR3 Q"
            using A12 A13 A20 A22 A38 A40 sorry
        qed
        have "( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (x inHIDDENR3 Z1 iff y inHIDDENR3 Z1)) & ([TARSKIK4 x,y ] inHIDDENR3 R & (( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (y inHIDDENR3 Z1 iff z inHIDDENR3 Z1)) & [TARSKIK4 y,z ] inHIDDENR3 R)) implies [TARSKIK4 x,z ] inHIDDENR3 Q"
        proof(rule impMI ,rule impMI ,rule impMI ,rule impI)
          assume A42: " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (x inHIDDENR3 Z1 iff y inHIDDENR3 Z1)"
            and A43: "[TARSKIK4 x,y ] inHIDDENR3 R"
            and A44: " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (y inHIDDENR3 Z1 iff z inHIDDENR3 Z1)"
            and A45: "[TARSKIK4 y,z ] inHIDDENR3 R"
          have A46: "[TARSKIK4 x,z ] inHIDDENR3 R"
            using A9 A13 A20 A21 A22 A43 A45 sorry
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 XX implies (x inHIDDENR3 Z iff z inHIDDENR3 Z)"
          proof(rule ballI,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            assume A47: "Z inTARSKIR2 XX"
            then have "x inHIDDENR3 Z iff y inHIDDENR3 Z"
              using A42 sorry
            thus "x inHIDDENR3 Z iff z inHIDDENR3 Z"
              using A44 A47 sorry
          qed "sorry"
          thus "[TARSKIK4 x,z ] inHIDDENR3 Q"
            using A12 A13 A20 A22 A46 sorry
        qed
        thus "[TARSKIK4 x,z ] inHIDDENR3 Q"
          using A12 A23 A24 A25 A32 A37 sorry
      qed "sorry"
      thus "Q be transitiveRELAT-2V8"
        using relat_2_def_8 relat_2_def_16 sorry
    qed
    have A48: "Q be antisymmetricRELAT-2V4"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 Q & (y inHIDDENR3 fieldRELAT-1K3 Q & ([TARSKIK4 x,y ] inHIDDENR3 Q & [TARSKIK4 y,x ] inHIDDENR3 Q)) implies x =HIDDENR1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A49: "x inHIDDENR3 fieldRELAT-1K3 Q"
          and A50: "y inHIDDENR3 fieldRELAT-1K3 Q"
          and A51: "[TARSKIK4 x,y ] inHIDDENR3 Q"
          and A52: "[TARSKIK4 y,x ] inHIDDENR3 Q"
        have A53: "( ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & x inHIDDENR3 Z1) &  not y inHIDDENR3 Z1) or ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (x inHIDDENR3 Z1 iff y inHIDDENR3 Z1)) & [TARSKIK4 x,y ] inHIDDENR3 R"
          using A12 A51 sorry
        have A54: "( ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & y inHIDDENR3 Z1) &  not x inHIDDENR3 Z1) or ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 XX implies (y inHIDDENR3 Z1 iff x inHIDDENR3 Z1)) & [TARSKIK4 y,x ] inHIDDENR3 R"
          using A12 A52 sorry
        have "( ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & x inHIDDENR3 Z1) &  not y inHIDDENR3 Z1) implies (( ex Z2 be setHIDDENM2 st (Z2 inTARSKIR2 XX & y inHIDDENR3 Z2) &  not x inHIDDENR3 Z2) implies x =HIDDENR1 y)"
        proof(rule impI,rule impI)
          assume Given: " ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & x inHIDDENR3 Z1) &  not y inHIDDENR3 Z1"
          then obtain Z1 where
            [ty]:"Z1 be setHIDDENM2" and 
            A55: "Z1 inTARSKIR2 XX"and A56: "x inHIDDENR3 Z1"and A57: " not y inHIDDENR3 Z1"
             sorry
          assume Given: " ex Z2 be setHIDDENM2 st (Z2 inTARSKIR2 XX & y inHIDDENR3 Z2) &  not x inHIDDENR3 Z2"
          then obtain Z2 where
            [ty]:"Z2 be setHIDDENM2" and 
            A58: "Z2 inTARSKIR2 XX"and A59: "y inHIDDENR3 Z2"and A60: " not x inHIDDENR3 Z2"
             sorry
          have "Z1 c=TARSKIR1 Z2 or Z2 c=TARSKIR1 Z1"
            using A6 A55 A58 sorry
          thus "x =HIDDENR1 y"
            using A56 A57 A59 A60 sorry
        qed
        thus "x =HIDDENR1 y"
          using A10 A13 A49 A50 A53 A54 sorry
      qed "sorry"
      thus "Q be antisymmetricRELAT-2V4"
        using relat_2_def_4 relat_2_def_12 sorry
    qed
    have A61: "Q be connectedRELAT-2V6"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 Q & (y inHIDDENR3 fieldRELAT-1K3 Q & x <>HIDDENR2 y) implies  not ( not [TARSKIK4 x,y ] inHIDDENR3 Q &  not [TARSKIK4 y,x ] inHIDDENR3 Q)"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A62: "x inHIDDENR3 fieldRELAT-1K3 Q"
          and A63: "y inHIDDENR3 fieldRELAT-1K3 Q"
          and A64: "x <>HIDDENR2 y"
        have "( for Z be setHIDDENM2 holds Z inTARSKIR2 XX implies (x inHIDDENR3 Z iff y inHIDDENR3 Z)) implies  not ( not [TARSKIK4 x,y ] inHIDDENR3 Q &  not [TARSKIK4 y,x ] inHIDDENR3 Q)"
        proof(rule impI)
          assume A65: " for Z be setHIDDENM2 holds Z inTARSKIR2 XX implies (x inHIDDENR3 Z iff y inHIDDENR3 Z)"
          have A66: "[TARSKIK4 x,y ] inHIDDENR3 R or [TARSKIK4 y,x ] inHIDDENR3 R"
            using A11 A13 A62 A63 A64 sorry
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 XX implies (y inHIDDENR3 Z iff x inHIDDENR3 Z)"
            using A65 sorry
          thus " not ( not [TARSKIK4 x,y ] inHIDDENR3 Q &  not [TARSKIK4 y,x ] inHIDDENR3 Q)"
            using A12 A13 A62 A63 A65 A66 sorry
        qed
        thus " not ( not [TARSKIK4 x,y ] inHIDDENR3 Q &  not [TARSKIK4 y,x ] inHIDDENR3 Q)"
          using A12 A13 A62 A63 sorry
      qed "sorry"
      thus "Q be connectedRELAT-2V6"
        using relat_2_def_6 relat_2_def_14 sorry
    qed
    have "Q be well-foundedWELLORD1V1"
    proof-
      have " for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 Q & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar22 be objectHIDDENM1 st tVar22 inHIDDENR3 Y & Q -SegWELLORD1K1 tVar22 missesXBOOLE-0R1 Y)"
      proof(rule ballI,rule impMI ,rule impI)
        fix Y assume [ty]: "Y be setHIDDENM2"
        assume A67: "Y c=TARSKIR1 fieldRELAT-1K3 Q"
          and A68: "Y <>HIDDENR2 {}XBOOLE-0K1"
        let ?P = "\<lambda>Lamb1. Lamb1 /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
        obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A69: " for x be setHIDDENM2 holds x inTARSKIR2 Z iff x inTARSKIR2 XX & ?P(x)"
          using xfamily_sch_1 sorry
        have A70: "Z c=TARSKIR1 XX"
          using A69 sorry
        let ?x = "the ElementSUBSET-1M1-of Y"
        have "?x inTARSKIR2 unionTARSKIK3 XX"
          using A4 A13 A67 A68 sorry
        then obtain Z1 where
          [ty]:"Z1 be setHIDDENM2" and 
          A71: "?x inTARSKIR2 Z1"and A72: "Z1 inTARSKIR2 XX"
          using tarski_def_4 sorry
        have "Z1 /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
          using A68 A71 xboole_0_def_4 sorry
        then have "Z <>HIDDENR2 {}XBOOLE-0K1"
          using A69 A72 sorry
        then obtain Z1 where
          [ty]:"Z1 be setHIDDENM2" and 
          A73: "Z1 inTARSKIR2 Z"and A74: " for Z2 be setHIDDENM2 holds Z2 inTARSKIR2 Z implies Z1 c=TARSKIR1 Z2"
          using A5 A70 sorry
        have A75: "Z1 inTARSKIR2 XX"
          using A69 A73 sorry
        have A76: "Z1 /\\XBOOLE-0K3 Y c=TARSKIR1 Z1"
          using xboole_1_th_17 sorry
        have A77: "Z1 c=TARSKIR1 unionTARSKIK3 X"
          using A3 A75 zfmisc_1_th_74 sorry
        have "Z1 /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
          using A69 A73 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A78: "x inHIDDENR3 Z1 /\\XBOOLE-0K3 Y"and A79: " for y be objectHIDDENM1 holds y inHIDDENR3 Z1 /\\XBOOLE-0K3 Y implies [TARSKIK4 x,y ] inHIDDENR3 R"
          using A7 A76 A77 wellord1_th_5 xboole_1_th_1 sorry
        show " ex tVar22 be objectHIDDENM1 st tVar22 inHIDDENR3 Y & Q -SegWELLORD1K1 tVar22 missesXBOOLE-0R1 Y"
        proof(rule bexI[of _ "x"],rule conjMI)
          show "x inHIDDENR3 Y"
            using A78 xboole_0_def_4 sorry
          have "Q -SegWELLORD1K1 x /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1 implies  False "
          proof(rule impI)
            assume A80: "Q -SegWELLORD1K1 x /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
            let ?y = "the ElementSUBSET-1M1-of Q -SegWELLORD1K1 x /\\XBOOLE-0K3 Y"
            have A81: "x inHIDDENR3 Z1"
              using A78 xboole_0_def_4 sorry
            have A82: "?y inTARSKIR2 Q -SegWELLORD1K1 x"
              using A80 xboole_0_def_4 sorry
            have A83: "?y inTARSKIR2 Y"
              using A80 xboole_0_def_4 sorry
            have A84: "?y <>HIDDENR2 x"
              using A82 wellord1_th_1 sorry
            have A85: "[TARSKIK4 ?y,x ] inHIDDENR3 Q"
              using A82 wellord1_th_1 sorry
            have A86: "( ex Z2 be setHIDDENM2 st (Z2 inTARSKIR2 XX & the ElementSUBSET-1M1-of Q -SegWELLORD1K1 x /\\XBOOLE-0K3 Y inTARSKIR2 Z2) &  not x inHIDDENR3 Z2) implies  False "
            proof(rule impI)
              assume Given: " ex Z2 be setHIDDENM2 st (Z2 inTARSKIR2 XX & ?y inTARSKIR2 Z2) &  not x inHIDDENR3 Z2"
              then obtain Z2 where
                [ty]:"Z2 be setHIDDENM2" and 
                A87: "Z2 inTARSKIR2 XX"and A88: "?y inTARSKIR2 Z2"and A89: " not x inHIDDENR3 Z2"
                 sorry
              have "Z2 /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
                using A83 A88 xboole_0_def_4 sorry
              then have "Z2 inTARSKIR2 Z"
                using A69 A87 sorry
              then have "Z1 c=TARSKIR1 Z2"
                using A74 sorry
              thus " False "
                using A81 A89 sorry
            qed
            then have A90: "?y inTARSKIR2 Z1"
              using A12 A75 A81 A85 sorry
            have A91: "[TARSKIK4 ?y,x ] inHIDDENR3 R"
              using A12 A85 A86 sorry
            have "?y inTARSKIR2 Z1 /\\XBOOLE-0K3 Y"
              using A83 A90 xboole_0_def_4 sorry
            then have A92: "[TARSKIK4 x,?y ] inHIDDENR3 R"
              using A79 sorry
            have A93: "x inHIDDENR3 unionTARSKIK3 X"
              using A12 A85 sorry
            have "?y inTARSKIR2 unionTARSKIK3 X"
              using A12 A85 sorry
            thus " False "
              using A10 A84 A91 A92 A93 sorry
          qed
          thus "Q -SegWELLORD1K1 x missesXBOOLE-0R1 Y"
            using xboole_0_def_7 sorry
        qed "sorry"
      qed "sorry"
      thus "Q be well-foundedWELLORD1V1"
        using wellord1_def_2 sorry
    qed
    then have "Q be well-orderingWELLORD1V2"
      using A16 A19 A48 A61 sorry
    then have "(Q,RelInclWELLORD2K1 (order-type-ofWELLORD2K2 Q))are-isomorphicWELLORD1R4"
      using wellord2_def_2 sorry
    then have "(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 Q),Q)are-isomorphicWELLORD1R4"
      using wellord1_th_40 sorry
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A94: "g is-isomorphism-ofWELLORD1R3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 Q),Q)"
       sorry
    have A95: "fieldRELAT-1K3 (RelInclWELLORD2K1 (order-type-ofWELLORD2K2 Q)) =XBOOLE-0R4 order-type-ofWELLORD2K2 Q"
      using wellord2_def_1 sorry
    then have A96: "domRELAT-1K1 g =XBOOLE-0R4 order-type-ofWELLORD2K2 Q"
      using A94 sorry
    have A97: "rngFUNCT-1K2 g =XBOOLE-0R4 unionTARSKIK3 X"
      using A13 A94 sorry
    have A98: "g be one-to-oneFUNCT-1V2"
      using A94 sorry
    have A99: " for Z be setHIDDENM2 holds  for x be objectHIDDENM1 holds Z inTARSKIR2 XX & x inHIDDENR3 Z implies Q -SegWELLORD1K1 x c=TARSKIR1 Z"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix Z assume [ty]: "Z be setHIDDENM2"
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A100: "Z inTARSKIR2 XX"
        and A101: "x inHIDDENR3 Z"
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Q -SegWELLORD1K1 x implies y inHIDDENR3 Z"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 Q -SegWELLORD1K1 x"
        then have A102: "[TARSKIK4 y,x ] inHIDDENR3 Q"
          using wellord1_th_1 sorry
        have "( ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & y inHIDDENR3 Z1) &  not x inHIDDENR3 Z1) implies y inHIDDENR3 Z"
        proof(rule impI)
          assume Given: " ex Z1 be setHIDDENM2 st (Z1 inTARSKIR2 XX & y inHIDDENR3 Z1) &  not x inHIDDENR3 Z1"
          then obtain Z1 where
            [ty]:"Z1 be setHIDDENM2" and 
            A103: "Z1 inTARSKIR2 XX"and A104: "y inHIDDENR3 Z1"and A105: " not x inHIDDENR3 Z1"
             sorry
          have "Z1 c=TARSKIR1 Z or Z c=TARSKIR1 Z1"
            using A6 A100 A103 sorry
          thus "y inHIDDENR3 Z"
            using A101 A104 A105 sorry
        qed
        thus "y inHIDDENR3 Z"
          using A12 A100 A101 A102 sorry
      qed "sorry"
      thus "Q -SegWELLORD1K1 x c=TARSKIR1 Z"
        using tarski_def_3 sorry
    qed "sorry"
    have A106: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 order-type-ofWELLORD2K2 Q implies cardCARD-1K1 A =XBOOLE-0R4 cardCARD-1K1 (Q -SegWELLORD1K1 (g .FUNCT-1K1 A))"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A107: "A inTARSKIR2 order-type-ofWELLORD2K2 Q"
      have "(A,Q -SegWELLORD1K1 (g .FUNCT-1K1 A))are-equipotentWELLORD2R2"
      proof-
        obtain f where 
          [ty]:"f be setHIDDENM2" and fDef:"f = g  |RELAT-1K8 A"
           sorry
        have " ex f be setHIDDENM2 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 A) & proj2XTUPLE-0K13 f =HIDDENR1 Q -SegWELLORD1K1 (g .FUNCT-1K1 A)"
        proof(rule bexI[of _ "f"],rule conjMI)
          have "A c=TARSKIR1 domRELAT-1K1 g"
            using A96 A107 ordinal1_def_2 sorry
          thus A108: "f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 A"
            using A98 funct_1_th_52 relat_1_th_62 sorry
          have "rngFUNCT-1K2 f c=TARSKIR1 Q -SegWELLORD1K1 (g .FUNCT-1K1 A) & Q -SegWELLORD1K1 (g .FUNCT-1K1 A) c=TARSKIR1 proj2XTUPLE-0K13 f"
          proof(rule conjMI)
            show "rngFUNCT-1K2 f c=TARSKIR1 Q -SegWELLORD1K1 (g .FUNCT-1K1 A)"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 Q -SegWELLORD1K1 (g .FUNCT-1K1 A)"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 f"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A109: "y inHIDDENR3 domRELAT-1K1 f"and A110: "x =HIDDENR1 f .FUNCT-1K1 y"
                  using funct_1_def_3 sorry
                obtain B where 
                  [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = y"
                  using A108 A109 sorry
                have A111: "B inTARSKIR2 order-type-ofWELLORD2K2 Q"
                  using A107 A108 A109 ordinal1_th_10 sorry
                have "B c=ORDINAL1R1 A"
                  using A108 A109 ordinal1_def_2 sorry
                then have A112: "[TARSKIK4 B,A ] inHIDDENR3 RelInclWELLORD2K1 (order-type-ofWELLORD2K2 Q)"
                  using A107 A111 wellord2_def_1 sorry
                have A113: "x =HIDDENR1 g .FUNCT-1K1 B"
                  using A109 A110 funct_1_th_47 sorry
                obtain BB where 
                  [ty]:"BB be setHIDDENM2" and BBDef:"BB = B"
                   sorry
                have " not BB inTARSKIR2 BB"
                   sorry
                then have A114: "A <>HIDDENR2 B"
                  using A108 A109 sorry
                have A115: "[TARSKIK4 x,g .FUNCT-1K1 A ] inHIDDENR3 Q"
                  using A94 A112 A113 sorry
                have "x <>HIDDENR2 g .FUNCT-1K1 A"
                  using A96 A98 A107 A111 A113 A114 sorry
                thus "x inHIDDENR3 Q -SegWELLORD1K1 (g .FUNCT-1K1 A)"
                  using A115 wellord1_th_1 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 f c=TARSKIR1 Q -SegWELLORD1K1 (g .FUNCT-1K1 A)"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 Q -SegWELLORD1K1 (g .FUNCT-1K1 A) implies x inHIDDENR3 proj2XTUPLE-0K13 f"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A116: "x inHIDDENR3 Q -SegWELLORD1K1 (g .FUNCT-1K1 A)"
              then have A117: "[TARSKIK4 x,g .FUNCT-1K1 A ] inHIDDENR3 Q"
                using wellord1_th_1 sorry
              then have "x inHIDDENR3 unionTARSKIK3 X"
                using A12 sorry
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A118: "y inHIDDENR3 domRELAT-1K1 g"and A119: "x =HIDDENR1 g .FUNCT-1K1 y"
                using A97 funct_1_def_3 sorry
              obtain B where 
                [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = y"
                using A96 A118 sorry
              have "[TARSKIK4 B,A ] inHIDDENR3 RelInclWELLORD2K1 (order-type-ofWELLORD2K2 Q)"
                using A94 A95 A107 A117 A118 A119 sorry
              then have A120: "B c=ORDINAL1R1 A"
                using A96 A107 A118 wellord2_def_1 sorry
              have "B <>HIDDENR2 A"
                using A116 A119 wellord1_th_1 sorry
              then have "B c<XBOOLE-0R2 A"
                using A120 sorry
              thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
                using A118 A119 funct_1_th_50 ordinal1_th_11 sorry
            qed "sorry"
            thus "Q -SegWELLORD1K1 (g .FUNCT-1K1 A) c=TARSKIR1 proj2XTUPLE-0K13 f"
              using tarski_def_3 sorry
          qed
          thus "proj2XTUPLE-0K13 f =HIDDENR1 Q -SegWELLORD1K1 (g .FUNCT-1K1 A)"
            using xboole_0_def_10 sorry
        qed "sorry"
        thus "(A,Q -SegWELLORD1K1 (g .FUNCT-1K1 A))are-equipotentWELLORD2R2"
          using wellord2_def_4 sorry
      qed
      thus "cardCARD-1K1 A =XBOOLE-0R4 cardCARD-1K1 (Q -SegWELLORD1K1 (g .FUNCT-1K1 A))"
        using card_1_th_5 sorry
    qed "sorry"
    have A121: "order-type-ofWELLORD2K2 Q c=ORDINAL1R1 M"
    proof-
      have " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 order-type-ofWELLORD2K2 Q implies x inTARSKIR2 M"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be OrdinalORDINAL1M3"
        assume A122: "x inTARSKIR2 order-type-ofWELLORD2K2 Q"
        obtain A where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
           sorry
        have "g .FUNCT-1K1 x inTARSKIR2 unionTARSKIK3 X"
          using A96 A97 A122 funct_1_def_3 sorry
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A123: "g .FUNCT-1K1 x inTARSKIR2 Z"and A124: "Z inTARSKIR2 XX"
          using A4 tarski_def_4 sorry
        have A125: "cardCARD-1K1 (Q -SegWELLORD1K1 (g .FUNCT-1K1 x)) c=ORDINAL1R1 cardCARD-1K1 Z"
          using A99 A123 A124 card_1_th_11 sorry
        have A126: "cardCARD-1K1 (Q -SegWELLORD1K1 (g .FUNCT-1K1 x)) =XBOOLE-0R4 cardCARD-1K1 A"
          using A106 A122 sorry
        have "cardCARD-1K1 (Q -SegWELLORD1K1 (g .FUNCT-1K1 x)) inTARSKIR2 M"
          using A1 A3 A124 A125 ordinal1_th_12 sorry
        thus "x inTARSKIR2 M"
          using A126 card_3_th_44 sorry
      qed "sorry"
      thus "order-type-ofWELLORD2K2 Q c=ORDINAL1R1 M"
        using ordinal1_def_5 sorry
    qed
    have "(order-type-ofWELLORD2K2 Q,unionTARSKIK3 X)are-equipotentWELLORD2R2"
      using A96 A97 A98 sorry
    then have A127: "cardCARD-1K1 (order-type-ofWELLORD2K2 Q) =XBOOLE-0R4 cardCARD-1K1 (unionTARSKIK3 X)"
      using card_1_th_5 sorry
    have "cardCARD-1K1 M =XBOOLE-0R4 M"
       sorry
    thus "cardCARD-1K1 (unionTARSKIK3 X) c=ORDINAL1R1 M"
      using A121 A127 card_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem card_3_cl_6:
  mlet "f be FunctionFUNCT-1M1"
"cluster productCARD-3K4 f as-term-is functionalFUNCT-1V6"
proof
(*coherence*)
  show "productCARD-3K4 f be functionalFUNCT-1V6"
  proof-
    let ?d = "productCARD-3K4 f"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 f implies x be setHIDDENM2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 ?d"
      then have " ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
        using card_3_def_5 sorry
      thus "x be setHIDDENM2"
         sorry
    qed "sorry"
    thus "productCARD-3K4 f be functionalFUNCT-1V6"
      using funct_1_def_13 sorry
  qed
qed "sorry"

mtheorem card_3_cl_7:
  mlet "A be setHIDDENM2", "B be with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2"
"cluster note-that non-emptyFUNCT-1V4 for FunctionFUNCT-2M1-of(A,B)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(A,B) holds it be non-emptyFUNCT-1V4"
  proof-
    have " for f be FunctionFUNCT-2M1-of(A,B) holds f be non-emptyFUNCT-1V4"
    proof(rule ballI)
      fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
      have " not {}XBOOLE-0K1 inTARSKIR2 rngRELSET-1K2\<^bsub>(B)\<^esub> f"
      proof-
        show " not {}XBOOLE-0K1 inTARSKIR2 rngRELSET-1K2\<^bsub>(B)\<^esub> f"
           sorry
      qed
      thus "f be non-emptyFUNCT-1V4"
        using relat_1_def_9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_cl_8:
  mlet "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
"cluster productCARD-3K4 f as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "productCARD-3K4 f be  non emptyXBOOLE-0V1"
  proof-
    have " not productCARD-3K4 f be emptyXBOOLE-0V1"
    proof-
      have " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      thus " not productCARD-3K4 f be emptyXBOOLE-0V1"
        using card_3_th_26 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_th_47:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds a <>HIDDENR2 b implies productCARD-3K4 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) =XBOOLE-0R4 {TARSKIK1 (a,b)-->FUNCT-4K6(c,d) }"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be setHIDDENM2"
  fix b assume [ty]: "b be setHIDDENM2"
  fix c assume [ty]: "c be setHIDDENM2"
  fix d assume [ty]: "d be setHIDDENM2"
  assume A1: "a <>HIDDENR2 b"
  let ?X = "{TARSKIK1 (a,b)-->FUNCT-4K6(c,d) }"
  let ?f = "(a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})"
  have A2: "domRELAT-1K1 ?f =XBOOLE-0R4 {TARSKIK2 a,b }"
    using funct_4_th_62 sorry
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 {TARSKIK1 (a,b)-->FUNCT-4K6(c,d) } implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d}))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) implies g .FUNCT-1K1 x inTARSKIR2 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})).FUNCT-1K1 x))) & (( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d}))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) implies g .FUNCT-1K1 x inTARSKIR2 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})).FUNCT-1K1 x)) implies x inHIDDENR3 {TARSKIK1 (a,b)-->FUNCT-4K6(c,d) })"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 {TARSKIK1 (a,b)-->FUNCT-4K6(c,d) } implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d}))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) implies g .FUNCT-1K1 x inTARSKIR2 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})).FUNCT-1K1 x))"
    proof-
      have "x inHIDDENR3 {TARSKIK1 (a,b)-->FUNCT-4K6(c,d) } implies ( ex g be setHIDDENM2 st x =HIDDENR1 g & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) implies g .FUNCT-1K1 x inTARSKIR2 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})).FUNCT-1K1 x)))"
      proof(rule impI)
        assume A3: "x inHIDDENR3 ?X"
        obtain g where 
          [ty]:"g be setHIDDENM2" and gDef:"g = (a,b)-->FUNCT-4K6(c,d)"
           sorry
        show " ex g be setHIDDENM2 st x =HIDDENR1 g & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) implies g .FUNCT-1K1 x inTARSKIR2 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})).FUNCT-1K1 x))"
        proof(rule bexI[of _ "g"],rule conjMI,rule conjMI,rule ballI,rule impI)
          show "x =HIDDENR1 g"
            using A3 tarski_def_1 sorry
          show "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d}))"
            using A2 funct_4_th_62 sorry
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 ?f"
          then have A4: "x =HIDDENR1 a or x =HIDDENR1 b"
            using A2 tarski_def_2 sorry
          have A5: "g .FUNCT-1K1 a =XBOOLE-0R4 c"
            using A1 funct_4_th_63 sorry
          have A6: "?f .FUNCT-1K1 a =XBOOLE-0R4 {TARSKIK1 c}"
            using A1 funct_4_th_63 sorry
          have A7: "g .FUNCT-1K1 b =XBOOLE-0R4 d"
            using funct_4_th_63 sorry
          have "?f .FUNCT-1K1 b =XBOOLE-0R4 {TARSKIK1 d}"
            using funct_4_th_63 sorry
          thus "g .FUNCT-1K1 x inTARSKIR2 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})).FUNCT-1K1 x"
            using A4 A5 A6 A7 tarski_def_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ?f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ?f implies g .FUNCT-1K1 x inTARSKIR2 ?f .FUNCT-1K1 x)"
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A8: "x =HIDDENR1 g"and A9: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ?f"and A10: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ?f implies g .FUNCT-1K1 x inTARSKIR2 ?f .FUNCT-1K1 x"
       sorry
    have A11: "a inTARSKIR2 domRELAT-1K1 ?f"
      using A2 tarski_def_2 sorry
    have A12: "b inTARSKIR2 domRELAT-1K1 ?f"
      using A2 tarski_def_2 sorry
    have A13: "g .FUNCT-1K1 a inTARSKIR2 ?f .FUNCT-1K1 a"
      using A10 A11 sorry
    have A14: "g .FUNCT-1K1 b inTARSKIR2 ?f .FUNCT-1K1 b"
      using A10 A12 sorry
    have A15: "?f .FUNCT-1K1 a =XBOOLE-0R4 {TARSKIK1 c}"
      using A1 funct_4_th_63 sorry
    have A16: "?f .FUNCT-1K1 b =XBOOLE-0R4 {TARSKIK1 d}"
      using funct_4_th_63 sorry
    have A17: "g .FUNCT-1K1 a =XBOOLE-0R4 c"
      using A13 A15 tarski_def_1 sorry
    have "g .FUNCT-1K1 b =XBOOLE-0R4 d"
      using A14 A16 tarski_def_1 sorry
    then have "g =FUNCT-1R1 (a,b)-->FUNCT-4K6(c,d)"
      using A2 A9 A17 funct_4_th_66 sorry
    thus "x inHIDDENR3 {TARSKIK1 (a,b)-->FUNCT-4K6(c,d) }"
      using A8 tarski_def_1 sorry
  qed "sorry"
  thus "productCARD-3K4 ((a,b)-->FUNCT-4K6({TARSKIK1 c},{TARSKIK1 d})) =XBOOLE-0R4 {TARSKIK1 (a,b)-->FUNCT-4K6(c,d) }"
    using card_3_def_5 sorry
qed "sorry"

mtheorem card_3_th_48:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 productCARD-3K4 f implies x be FunctionFUNCT-1M1"
   sorry

(*begin*)
reserve A, B for "setHIDDENM2"
mdef card_3_def_9 ("sproductCARD-3K8  _ " [164]164 ) where
  mlet "f be FunctionFUNCT-1M1"
"func sproductCARD-3K8 f \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 VarFor1 & ( for g be FunctionFUNCT-1M1 holds  not ((x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 g &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))))) &  not ( not ( for g be FunctionFUNCT-1M1 holds  not ((x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 g &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)))) &  not x inHIDDENR3 VarFor1)))"
      proof-
        let ?P = "\<lambda>Lamb1.  ex g be FunctionFUNCT-1M1 st (Lamb1 =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
        obtain A where
          [ty]:"A be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 A iff x inHIDDENR3 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f)) & ?P(x)"
          using xboole_0_sch_1 sorry
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 A implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))) & (( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)) implies x inHIDDENR3 A)"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 A implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
            using A1 sorry
          assume Given: " ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A2: "x =HIDDENR1 g"and A3: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
             sorry
          have "rngFUNCT-1K2 g c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 f)"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 rngFUNCT-1K2 g"
              then obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A5: "z inHIDDENR3 domRELAT-1K1 g"and A6: "y =HIDDENR1 g .FUNCT-1K1 z"
                using funct_1_def_3 sorry
              have A7: "g .FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
                using A4 A5 sorry
              have "f .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
                using A3 A5 funct_1_def_3 sorry
              thus "y inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
                using A6 A7 tarski_def_4 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 g c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 f)"
              using tarski_def_3 sorry
          qed
          then have "x inHIDDENR3 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
            using A2 A3 partfun1_def_3 sorry
          thus "x inHIDDENR3 A"
            using A1 A2 A3 A4 sorry
        qed "sorry"
        thus " not ( for VarFor1 be setHIDDENM2 holds  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 VarFor1 & ( for g be FunctionFUNCT-1M1 holds  not ((x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 g &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))))) &  not ( not ( for g be FunctionFUNCT-1M1 holds  not ((x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 g &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)))) &  not x inHIDDENR3 VarFor1)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
    proof-
      have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 A iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 xc inTARSKIR2 f .FUNCT-1K1 xc))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 B iff ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for xc be objectHIDDENM1 holds xc inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 xc inTARSKIR2 f .FUNCT-1K1 xc))) implies A =HIDDENR1 B"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1.  ex g be FunctionFUNCT-1M1 st (Lamb1 =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
        fix A assume [ty]: "A be setHIDDENM2"
        fix B assume [ty]: "B be setHIDDENM2"
        assume A8: " for x be objectHIDDENM1 holds x inHIDDENR3 A iff ?P(x)"
          and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 B iff ?P(x)"
        show "A =HIDDENR1 B"
          using xboole_0_sch_2 A8 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem card_3_cl_9:
  mlet "f be FunctionFUNCT-1M1"
"cluster sproductCARD-3K8 f as-term-is functionalFUNCT-1V6\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "sproductCARD-3K8 f be functionalFUNCT-1V6\<bar> non emptyXBOOLE-0V1"
  proof-
    have "sproductCARD-3K8 f be functionalFUNCT-1V6 &  not sproductCARD-3K8 f be emptyXBOOLE-0V1"
    proof-
      let ?P = "\<lambda>Lamb1.  ex g be FunctionFUNCT-1M1 st (Lamb1 =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
      obtain A where
        [ty]:"A be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 A iff x inHIDDENR3 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f)) & ?P(x)"
        using xboole_0_sch_1 sorry
      have "{}XBOOLE-0K1 be PartFuncPARTFUN1M1-of(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
        using relset_1_th_12 sorry
      then have A2: "{}XBOOLE-0K1 inTARSKIR2 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
        using partfun1_th_45 sorry
      have A3: "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 domRELAT-1K1 f"
         sorry
      have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ({}XBOOLE-0K1) implies {}XBOOLE-0K1 .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x be FunctionFUNCT-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 A"
        then have " ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
          using A1 sorry
        thus "x be FunctionFUNCT-1M1"
           sorry
      qed "sorry"
      then have 
        [ty]:"A be functionalFUNCT-1V6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
        using A1 A2 A3 A4 funct_1_def_13 sorry
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 A implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))) & (( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)) implies x inHIDDENR3 A)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 A implies ( ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
          using A1 sorry
        assume Given: " ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A5: "x =HIDDENR1 g"and A6: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
           sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 f)"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 g"
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A8: "z inHIDDENR3 domRELAT-1K1 g"and A9: "y =HIDDENR1 g .FUNCT-1K1 z"
              using funct_1_def_3 sorry
            have A10: "g .FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
              using A7 A8 sorry
            have "f .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
              using A6 A8 funct_1_def_3 sorry
            thus "y inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
              using A9 A10 tarski_def_4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 g c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 f)"
            using tarski_def_3 sorry
        qed
        then have "x inHIDDENR3 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
          using A5 A6 partfun1_def_3 sorry
        thus "x inHIDDENR3 A"
          using A1 A5 A6 A7 sorry
      qed "sorry"
      thus "sproductCARD-3K8 f be functionalFUNCT-1V6 &  not sproductCARD-3K8 f be emptyXBOOLE-0V1"
        using card_3_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_th_49:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g inTARSKIR2 sproductCARD-3K8 f implies domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g inTARSKIR2 sproductCARD-3K8 f implies domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 g &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "g inTARSKIR2 sproductCARD-3K8 f"
    then have " ex h be FunctionFUNCT-1M1 st (g =FUNCT-1R1 h & domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
      using card_3_def_9 sorry
    thus "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 g &  not g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_50:
" for f be FunctionFUNCT-1M1 holds {}XBOOLE-0K1 inTARSKIR2 sproductCARD-3K8 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds {}XBOOLE-0K1 inTARSKIR2 sproductCARD-3K8 f"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 domRELAT-1K1 f"
       sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ({}XBOOLE-0K1) implies {}XBOOLE-0K1 .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
       sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 sproductCARD-3K8 f"
      using A1 card_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_cl_10:
  mlet "f be FunctionFUNCT-1M1"
"cluster emptyXBOOLE-0V1 for ElementSUBSET-1M1-of sproductCARD-3K8 f"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of sproductCARD-3K8 f st it be emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be ElementSUBSET-1M1-of sproductCARD-3K8 f holds  not VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "{}XBOOLE-0K1 inTARSKIR2 sproductCARD-3K8 f"
        using card_3_th_50 sorry
      thus " not ( for VarFor1 be ElementSUBSET-1M1-of sproductCARD-3K8 f holds  not VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_th_51:
" for f be FunctionFUNCT-1M1 holds productCARD-3K4 f c=TARSKIR1 sproductCARD-3K8 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds productCARD-3K4 f c=TARSKIR1 sproductCARD-3K8 f"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 f implies x inHIDDENR3 sproductCARD-3K8 f"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 productCARD-3K4 f"
      then have " ex g be FunctionFUNCT-1M1 st (x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
        using card_3_def_5 sorry
      thus "x inHIDDENR3 sproductCARD-3K8 f"
        using card_3_def_9 sorry
    qed "sorry"
    thus "productCARD-3K4 f c=TARSKIR1 sproductCARD-3K8 f"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_52:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 sproductCARD-3K8 f implies x be PartFuncPARTFUN1M1-of(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 sproductCARD-3K8 f implies x be PartFuncPARTFUN1M1-of(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "x inHIDDENR3 sproductCARD-3K8 f"
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A1: "x =HIDDENR1 g"and A2: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
      using card_3_def_9 sorry
    have "rngFUNCT-1K2 g c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 f)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 g"
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A4: "z inHIDDENR3 domRELAT-1K1 g"and A5: "y =HIDDENR1 g .FUNCT-1K1 z"
          using funct_1_def_3 sorry
        have A6: "g .FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
          using A3 A4 sorry
        have "f .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
          using A2 A4 funct_1_def_3 sorry
        thus "y inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 f)"
          using A5 A6 tarski_def_4 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 g c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 f)"
        using tarski_def_3 sorry
    qed
    thus "x be PartFuncPARTFUN1M1-of(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
      using A1 A2 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_53:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 f & h inTARSKIR2 sproductCARD-3K8 f implies g +*FUNCT-4K1 h inTARSKIR2 productCARD-3K4 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g inTARSKIR2 productCARD-3K4 f implies (h inTARSKIR2 sproductCARD-3K8 f implies g +*FUNCT-4K1 h inTARSKIR2 productCARD-3K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "g inTARSKIR2 productCARD-3K4 f"
    then have A2: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
      using card_3_th_9 sorry
    assume A3: "h inTARSKIR2 sproductCARD-3K8 f"
    then have A4: "domRELAT-1K1 g \\/XBOOLE-0K2 domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
      using A2 card_3_th_49 xboole_1_th_12 sorry
    then have A5: "domRELAT-1K1 (g +*FUNCT-4K1 h) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_4_def_1 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 domRELAT-1K1 f"
      have A7: "(domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h)\\/XBOOLE-0K2 domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
        using A4 xboole_1_th_39 sorry
      have "x inHIDDENR3 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h & (x inHIDDENR3 domRELAT-1K1 f & (g +*FUNCT-4K1 h).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) or x inHIDDENR3 domRELAT-1K1 h & (x inHIDDENR3 domRELAT-1K1 h implies (g +*FUNCT-4K1 h).FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x)"
      proof-
        show "x inHIDDENR3 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h & (x inHIDDENR3 domRELAT-1K1 f & (g +*FUNCT-4K1 h).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) or x inHIDDENR3 domRELAT-1K1 h & (x inHIDDENR3 domRELAT-1K1 h implies (g +*FUNCT-4K1 h).FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x)"
        proof-
          have cases: "x inHIDDENR3 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h or x inHIDDENR3 domRELAT-1K1 h"
            using A6 A7 xboole_0_def_3 sorry
          have case1: "x inHIDDENR3 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h implies x inHIDDENR3 domRELAT-1K1 f & (g +*FUNCT-4K1 h).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          proof(rule impI)
            assume A8: "x inHIDDENR3 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h"
            then have " not x inHIDDENR3 domRELAT-1K1 h"
              using xboole_0_def_5 sorry
            thus "x inHIDDENR3 domRELAT-1K1 f & (g +*FUNCT-4K1 h).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
              using A2 A8 funct_4_th_11 sorry
          qed
          have case2: "x inHIDDENR3 domRELAT-1K1 h implies (g +*FUNCT-4K1 h).FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
          proof(rule impI)
            assume "x inHIDDENR3 domRELAT-1K1 h"
            thus "(g +*FUNCT-4K1 h).FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
              using funct_4_th_13 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using A1 A3 card_3_th_9 card_3_th_49 sorry
    qed "sorry"
    thus "g +*FUNCT-4K1 h inTARSKIR2 productCARD-3K4 f"
      using A5 card_3_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_54:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1 implies (g inTARSKIR2 sproductCARD-3K8 f iff ( ex h be FunctionFUNCT-1M1 st h inTARSKIR2 productCARD-3K4 f & g c=RELAT-1R2 h))"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1 implies (g inTARSKIR2 sproductCARD-3K8 f implies ( ex h be FunctionFUNCT-1M1 st h inTARSKIR2 productCARD-3K4 f & g c=RELAT-1R2 h)) & (( ex h be FunctionFUNCT-1M1 st h inTARSKIR2 productCARD-3K4 f & g c=RELAT-1R2 h) implies g inTARSKIR2 sproductCARD-3K8 f)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1"
    show "g inTARSKIR2 sproductCARD-3K8 f implies ( ex h be FunctionFUNCT-1M1 st h inTARSKIR2 productCARD-3K4 f & g c=RELAT-1R2 h)"
    proof-
      have "g inTARSKIR2 sproductCARD-3K8 f implies ( ex tVar25 be FunctionFUNCT-1M1 st tVar25 inTARSKIR2 productCARD-3K4 f & g c=RELAT-1R2 tVar25)"
      proof(rule impI)
        assume A2: "g inTARSKIR2 sproductCARD-3K8 f"
        let ?k = "the ElementSUBSET-1M1-of productCARD-3K4 f"
        obtain k where 
          [ty]:"k be FunctionFUNCT-1M1" and kDef:"k = ?k"
           sorry
        show " ex tVar25 be FunctionFUNCT-1M1 st tVar25 inTARSKIR2 productCARD-3K4 f & g c=RELAT-1R2 tVar25"
        proof(rule bexI[of _ "k +*FUNCT-4K1 g"],rule conjMI)
          show "k +*FUNCT-4K1 g inTARSKIR2 productCARD-3K4 f"
            using A1 A2 card_3_th_53 sorry
          show "g c=RELAT-1R2 k +*FUNCT-4K1 g"
            using funct_4_th_25 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex h be FunctionFUNCT-1M1 st h inTARSKIR2 productCARD-3K4 f & g c=RELAT-1R2 h"
    then obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A3: "h inTARSKIR2 productCARD-3K4 f"and A4: "g c=RELAT-1R2 h"
       sorry
    have A5: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
      using A3 card_3_th_9 sorry
    have A6: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 h"
      using A4 relat_1_th_11 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 domRELAT-1K1 g"
      then have "g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
        using A4 grfunc_1_th_2 sorry
      thus "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using A3 A5 A6 A7 card_3_th_9 sorry
    qed "sorry"
    thus "g inTARSKIR2 sproductCARD-3K8 f"
      using A5 A6 card_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_55:
" for f be FunctionFUNCT-1M1 holds sproductCARD-3K8 f c=TARSKIR1 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
proof-
  have " for f be FunctionFUNCT-1M1 holds sproductCARD-3K8 f c=TARSKIR1 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 sproductCARD-3K8 f implies x inHIDDENR3 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 sproductCARD-3K8 f"
      then have "x be PartFuncPARTFUN1M1-of(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
        using card_3_th_52 sorry
      thus "x inHIDDENR3 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
        using partfun1_th_45 sorry
    qed "sorry"
    thus "sproductCARD-3K8 f c=TARSKIR1 PFuncsPARTFUN1K4(domRELAT-1K1 f,unionTARSKIK3 (rngFUNCT-1K2 f))"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_56:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies sproductCARD-3K8 f c=TARSKIR1 sproductCARD-3K8 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies sproductCARD-3K8 f c=TARSKIR1 sproductCARD-3K8 g"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f c=RELAT-1R2 g"
    then have A2: "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
      using grfunc_1_th_2 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 sproductCARD-3K8 f implies y inHIDDENR3 sproductCARD-3K8 g"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 sproductCARD-3K8 f"
      then obtain h where
        [ty]:"h be FunctionFUNCT-1M1" and 
        A3: "y =HIDDENR1 h"and A4: "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 f"and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using card_3_def_9 sorry
      have A6: "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 g"
        using A2 A4 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A7: "x inHIDDENR3 domRELAT-1K1 h"
        then have "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          using A1 A4 grfunc_1_th_2 sorry
        thus "h .FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x"
          using A5 A7 sorry
      qed "sorry"
      thus "y inHIDDENR3 sproductCARD-3K8 g"
        using A3 A6 card_3_def_9 sorry
    qed "sorry"
    thus "sproductCARD-3K8 f c=TARSKIR1 sproductCARD-3K8 g"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_57:
"sproductCARD-3K8 {}XBOOLE-0K1 =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have Cut2218: "sproductCARD-3K8 {}XBOOLE-0K1 c=TARSKIR1 PFuncsPARTFUN1K4({}XBOOLE-0K1,{}XBOOLE-0K1)"
    using card_3_th_55 relat_1_th_38 zfmisc_1_th_2 sorry
  have "sproductCARD-3K8 {}XBOOLE-0K1 c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 } & {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 sproductCARD-3K8 {}XBOOLE-0K1"
  proof(rule conjMI)
    show "sproductCARD-3K8 {}XBOOLE-0K1 c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
      using partfun1_th_48 Cut2218 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies x inHIDDENR3 sproductCARD-3K8 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
      then have "x =HIDDENR1 {}XBOOLE-0K1"
        using tarski_def_1 sorry
      thus "x inHIDDENR3 sproductCARD-3K8 {}XBOOLE-0K1"
        using card_3_th_50 sorry
    qed "sorry"
    thus "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 sproductCARD-3K8 {}XBOOLE-0K1"
      using tarski_def_3 sorry
  qed
  thus "sproductCARD-3K8 {}XBOOLE-0K1 =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
    using xboole_0_def_10 sorry
qed

mtheorem card_3_th_58:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds PFuncsPARTFUN1K4(A,B) =XBOOLE-0R4 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds PFuncsPARTFUN1K4(A,B) =XBOOLE-0R4 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    have "A =XBOOLE-0R4 {}XBOOLE-0K1 & PFuncsPARTFUN1K4(A,B) =XBOOLE-0R4 sproductCARD-3K8 (A -->FUNCOP-1K7 B) or A <>HIDDENR2 {}XBOOLE-0K1 & (A <>HIDDENR2 {}XBOOLE-0K1 implies PFuncsPARTFUN1K4(A,B) c=TARSKIR1 sproductCARD-3K8 (A -->FUNCOP-1K7 B) & sproductCARD-3K8 (A -->FUNCOP-1K7 B) c=TARSKIR1 PFuncsPARTFUN1K4(A,B))"
    proof-
      show "A =XBOOLE-0R4 {}XBOOLE-0K1 & PFuncsPARTFUN1K4(A,B) =XBOOLE-0R4 sproductCARD-3K8 (A -->FUNCOP-1K7 B) or A <>HIDDENR2 {}XBOOLE-0K1 & (A <>HIDDENR2 {}XBOOLE-0K1 implies PFuncsPARTFUN1K4(A,B) c=TARSKIR1 sproductCARD-3K8 (A -->FUNCOP-1K7 B) & sproductCARD-3K8 (A -->FUNCOP-1K7 B) c=TARSKIR1 PFuncsPARTFUN1K4(A,B))"
      proof-
        have cases: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies PFuncsPARTFUN1K4(A,B) =XBOOLE-0R4 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
        proof(rule impI)
          assume A1: "A =XBOOLE-0R4 {}XBOOLE-0K1"
          then have "A -->FUNCOP-1K7 B =FUNCT-2R1\<^bsub>(A,{TARSKIK1 B},{}XBOOLE-0K1,{TARSKIK1 B})\<^esub> {}XBOOLE-0K1 -->FUNCOP-1K7 B"
             sorry
          thus "PFuncsPARTFUN1K4(A,B) =XBOOLE-0R4 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
            using A1 card_3_th_57 partfun1_th_48 sorry
        qed
        have case2: "A <>HIDDENR2 {}XBOOLE-0K1 implies PFuncsPARTFUN1K4(A,B) c=TARSKIR1 sproductCARD-3K8 (A -->FUNCOP-1K7 B) & sproductCARD-3K8 (A -->FUNCOP-1K7 B) c=TARSKIR1 PFuncsPARTFUN1K4(A,B)"
        proof(rule impI,rule conjMI)
          assume "A <>HIDDENR2 {}XBOOLE-0K1"
          then have A2: "rngRELSET-1K2\<^bsub>({TARSKIK1 B})\<^esub> (A -->FUNCOP-1K7 B) =XBOOLE-0R4 {TARSKIK1 B}"
            using funcop_1_th_8 sorry
          have A3: "domRELSET-1K1\<^bsub>(A)\<^esub> (A -->FUNCOP-1K7 B) =XBOOLE-0R4 A"
            using funcop_1_th_13 sorry
          have A4: "B =XBOOLE-0R4 unionTARSKIK3 (rngRELSET-1K2\<^bsub>({TARSKIK1 B})\<^esub> (A -->FUNCOP-1K7 B))"
            using A2 zfmisc_1_th_25 sorry
          show "PFuncsPARTFUN1K4(A,B) c=TARSKIR1 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 PFuncsPARTFUN1K4(A,B) implies x inHIDDENR3 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 PFuncsPARTFUN1K4(A,B)"
              then obtain f where
                [ty]:"f be FunctionFUNCT-1M1" and 
                A5: "x =HIDDENR1 f"and A6: "domRELAT-1K1 f c=TARSKIR1 A"and A7: "rngFUNCT-1K2 f c=TARSKIR1 B"
                using partfun1_def_3 sorry
              have A8: "domRELAT-1K1 f c=TARSKIR1 domRELSET-1K1\<^bsub>(A)\<^esub> (A -->FUNCOP-1K7 B)"
                using A6 funcop_1_th_13 sorry
              have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 (A -->FUNCOP-1K7 B).FUNCT-1K1 x"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A9: "x inHIDDENR3 domRELAT-1K1 f"
                then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
                  using funct_1_def_3 sorry
                then have "f .FUNCT-1K1 x inTARSKIR2 B"
                  using A7 sorry
                thus "f .FUNCT-1K1 x inTARSKIR2 (A -->FUNCOP-1K7 B).FUNCT-1K1 x"
                  using A6 A9 funcop_1_th_7 sorry
              qed "sorry"
              thus "x inHIDDENR3 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
                using A5 A8 card_3_def_9 sorry
            qed "sorry"
            thus "PFuncsPARTFUN1K4(A,B) c=TARSKIR1 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
              using tarski_def_3 sorry
          qed
          show "sproductCARD-3K8 (A -->FUNCOP-1K7 B) c=TARSKIR1 PFuncsPARTFUN1K4(A,B)"
            using A3 A4 card_3_th_55 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "PFuncsPARTFUN1K4(A,B) =XBOOLE-0R4 sproductCARD-3K8 (A -->FUNCOP-1K7 B)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_59:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds sproductCARD-3K8 f =XBOOLE-0R4 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,B) holds sproductCARD-3K8 f =XBOOLE-0R4 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,B)"
    let ?X = "{x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }"
    have "sproductCARD-3K8 f c=TARSKIR1 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }) & sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }) c=TARSKIR1 sproductCARD-3K8 f"
    proof(rule conjMI)
      show "sproductCARD-3K8 f c=TARSKIR1 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
      proof-
        have "sproductCARD-3K8 f c=TARSKIR1 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 sproductCARD-3K8 f implies x inHIDDENR3 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 sproductCARD-3K8 f"
            then obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A1: "x =HIDDENR1 g"and A2: "domRELAT-1K1 g c=TARSKIR1 domRELSET-1K1\<^bsub>(A)\<^esub> f"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
              using card_3_def_9 sorry
            have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 {x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A5: "x inHIDDENR3 domRELAT-1K1 g"
              then obtain a where 
                [ty]:"a be ElementSUBSET-1M1-of A" and aDef:"a = x"
                using A2 funct_2_def_1 sorry
              have "f .FUNCT-2K3\<^bsub>(A,B)\<^esub> a <>HIDDENR2 {}XBOOLE-0K1"
                using A3 A5 sorry
              thus "x inHIDDENR3 {x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }"
                 sorry
            qed "sorry"
            have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> f /\\SUBSET-1K8\<^bsub>(A)\<^esub> ({x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A7: "x inHIDDENR3 domRELAT-1K1 g"
              then have "x inHIDDENR3 ?X"
                using A4 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> f /\\SUBSET-1K8\<^bsub>(A)\<^esub> ({x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
                using A2 A7 xboole_0_def_4 sorry
            qed "sorry"
            have A8: "domRELAT-1K1 g c=TARSKIR1 domRELSET-1K1\<^bsub>(A)\<^esub> (f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ?X)"
            proof-
              have "domRELAT-1K1 g c=TARSKIR1 domRELSET-1K1\<^bsub>(A)\<^esub> (f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }))"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> (f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }))"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 domRELAT-1K1 g"
                  then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> f /\\SUBSET-1K8\<^bsub>(A)\<^esub> ?X"
                    using A6 sorry
                  thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> (f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }))"
                    using relat_1_th_61 sorry
                qed "sorry"
                thus "domRELAT-1K1 g c=TARSKIR1 domRELSET-1K1\<^bsub>(A)\<^esub> (f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }))"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })).FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A9: "x inHIDDENR3 domRELAT-1K1 g"
              then have "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
                using A3 sorry
              thus "g .FUNCT-1K1 x inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A : f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })).FUNCT-1K1 x"
                using A6 A9 funct_1_th_48 sorry
            qed "sorry"
            thus "x inHIDDENR3 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
              using A1 A8 card_3_def_9 sorry
          qed "sorry"
          thus "sproductCARD-3K8 f c=TARSKIR1 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      show "sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 }) c=TARSKIR1 sproductCARD-3K8 f"
        using card_3_th_56 relat_1_th_59 sorry
    qed
    thus "sproductCARD-3K8 f =XBOOLE-0R4 sproductCARD-3K8 f  |PARTFUN1K2\<^bsub>(A,B)\<^esub> ({x where x be ElementSUBSET-1M1-of A :  not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> x <>HIDDENR2 {}XBOOLE-0K1 })"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_60:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x implies x .-->FUNCOP-1K17 y inTARSKIR2 sproductCARD-3K8 f"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x implies x .-->FUNCOP-1K17 y inTARSKIR2 sproductCARD-3K8 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
      and A2: "y inHIDDENR3 f .FUNCT-1K1 x"
    have "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) =XBOOLE-0R4 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    then have A3: "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) c=TARSKIR1 domRELAT-1K1 f"
      using A1 zfmisc_1_th_31 sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) implies (x .-->FUNCOP-1K17 y).FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y)"
      then have "z =HIDDENR1 x"
        using tarski_def_1 sorry
      thus "(x .-->FUNCOP-1K17 y).FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
        using A2 funcop_1_th_72 sorry
    qed "sorry"
    thus "x .-->FUNCOP-1K17 y inTARSKIR2 sproductCARD-3K8 f"
      using A3 card_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_61:
" for f be FunctionFUNCT-1M1 holds sproductCARD-3K8 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 } iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (sproductCARD-3K8 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 } implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1)) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1) implies sproductCARD-3K8 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 })"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "sproductCARD-3K8 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 } implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1)"
    proof-
      have "sproductCARD-3K8 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 } implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x <>HIDDENR2 {}XBOOLE-0K1 implies  False ))"
      proof(rule impI,rule ballI,rule impI,rule impI)
        assume A1: "sproductCARD-3K8 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domRELAT-1K1 f"
        assume A3: "f .FUNCT-1K1 x <>HIDDENR2 {}XBOOLE-0K1"
        let ?y = "the ElementSUBSET-1M1-of f .FUNCT-1K1 x"
        have "x .-->FUNCOP-1K17 ?y inTARSKIR2 sproductCARD-3K8 f"
          using A2 A3 card_3_th_60 sorry
        thus " False "
          using A1 tarski_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 {}XBOOLE-0K1"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 sproductCARD-3K8 f implies x =HIDDENR1 {}XBOOLE-0K1) & (x =HIDDENR1 {}XBOOLE-0K1 implies x inHIDDENR3 sproductCARD-3K8 f)"
    proof(rule ballI,rule conjMI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 sproductCARD-3K8 f implies x =HIDDENR1 {}XBOOLE-0K1"
      proof-
        have "x inHIDDENR3 sproductCARD-3K8 f implies (x <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
        proof(rule impI,rule impI)
          assume "x inHIDDENR3 sproductCARD-3K8 f"
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A5: "x =HIDDENR1 g"and A6: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"and A7: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 y"
            using card_3_def_9 sorry
          assume A8: "x <>HIDDENR2 {}XBOOLE-0K1"
          let ?y = "the ElementSUBSET-1M1-of domRELAT-1K1 g"
          have A9: "f .FUNCT-1K1 ?y <>HIDDENR2 {}XBOOLE-0K1"
            using A5 A7 A8 sorry
          have "?y inTARSKIR2 domRELAT-1K1 f"
            using A5 A6 A8 sorry
          thus " False "
            using A4 A9 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      show "x =HIDDENR1 {}XBOOLE-0K1 implies x inHIDDENR3 sproductCARD-3K8 f"
        using card_3_th_50 sorry
    qed "sorry"
    thus "sproductCARD-3K8 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_62:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds A c=TARSKIR1 sproductCARD-3K8 f & ( for h1 be FunctionFUNCT-1M1 holds  for h2 be FunctionFUNCT-1M1 holds h1 inTARSKIR2 A & h2 inTARSKIR2 A implies h1 toleratesPARTFUN1R1 h2) implies unionTARSKIK3 A inTARSKIR2 sproductCARD-3K8 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds A c=TARSKIR1 sproductCARD-3K8 f & ( for h1 be FunctionFUNCT-1M1 holds  for h2 be FunctionFUNCT-1M1 holds h1 inTARSKIR2 A & h2 inTARSKIR2 A implies h1 toleratesPARTFUN1R1 h2) implies unionTARSKIK3 A inTARSKIR2 sproductCARD-3K8 f"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    assume A1: "A c=TARSKIR1 sproductCARD-3K8 f"
      and A2: " for h1 be FunctionFUNCT-1M1 holds  for h2 be FunctionFUNCT-1M1 holds h1 inTARSKIR2 A & h2 inTARSKIR2 A implies h1 toleratesPARTFUN1R1 h2"
    obtain g where 
      [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = unionTARSKIK3 A"
      using A1 A2 partfun1_th_78 sorry
    have A3: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELAT-1K1 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 g"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "[TARSKIK4 x,y ] inHIDDENR3 g"
          using xtuple_0_def_12 sorry
        obtain h where
          [ty]:"h be setHIDDENM2" and 
          A5: "[TARSKIK4 x,y ] inHIDDENR3 h"and A6: "h inTARSKIR2 A"
          using A4 tarski_def_4 sorry
        have 
          [ty]:"h be FunctionFUNCT-1M1"
          using A1 A6 sorry
        have A7: "x inHIDDENR3 domRELAT-1K1 h"
          using A5 xtuple_0_def_12 sorry
        have "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 f"
          using A1 A6 card_3_th_49 sorry
        thus "x inHIDDENR3 domRELAT-1K1 f"
          using A7 sorry
      qed "sorry"
      thus "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 g"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A8: "[TARSKIK4 x,y ] inHIDDENR3 g"
        using xtuple_0_def_12 sorry
      obtain h where
        [ty]:"h be setHIDDENM2" and 
        A9: "[TARSKIK4 x,y ] inHIDDENR3 h"and A10: "h inTARSKIR2 A"
        using A8 tarski_def_4 sorry
      have 
        [ty]:"h be FunctionFUNCT-1M1"
        using A1 A10 sorry
      have A11: "x inHIDDENR3 domRELAT-1K1 h"
        using A9 xtuple_0_def_12 sorry
      have "h .FUNCT-1K1 x =HIDDENR1 y"
        using A9 funct_1_th_1 sorry
      also have "... = g .FUNCT-1K1 x"
        using A8 funct_1_th_1 sorry
      finally have "h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
         sorry
      thus "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using A1 A10 A11 card_3_th_49 sorry
    qed "sorry"
    thus "unionTARSKIK3 A inTARSKIR2 sproductCARD-3K8 f"
      using A3 card_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_63:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (g toleratesPARTFUN1R1 h & g inTARSKIR2 sproductCARD-3K8 f) & h inTARSKIR2 sproductCARD-3K8 f implies g \\/XBOOLE-0K2 h inTARSKIR2 sproductCARD-3K8 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g toleratesPARTFUN1R1 h & (g inTARSKIR2 sproductCARD-3K8 f & h inTARSKIR2 sproductCARD-3K8 f) implies g \\/XBOOLE-0K2 h inTARSKIR2 sproductCARD-3K8 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "g toleratesPARTFUN1R1 h"
      and A2: "g inTARSKIR2 sproductCARD-3K8 f"
      and A3: "h inTARSKIR2 sproductCARD-3K8 f"
    have A4: "{TARSKIK2 g,h } c=TARSKIR1 sproductCARD-3K8 f"
      using A2 A3 zfmisc_1_th_32 sorry
    have A5: " for h1 be FunctionFUNCT-1M1 holds  for h2 be FunctionFUNCT-1M1 holds h1 inTARSKIR2 {TARSKIK2 g,h } & h2 inTARSKIR2 {TARSKIK2 g,h } implies h1 toleratesPARTFUN1R1 h2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix h1 assume [ty]: "h1 be FunctionFUNCT-1M1"
      fix h2 assume [ty]: "h2 be FunctionFUNCT-1M1"
      assume A6: "h1 inTARSKIR2 {TARSKIK2 g,h }"
        and A7: "h2 inTARSKIR2 {TARSKIK2 g,h }"
      have A8: "h1 =FUNCT-1R1 g or h1 =FUNCT-1R1 h"
        using A6 tarski_def_2 sorry
      have "h2 =FUNCT-1R1 g or h2 =FUNCT-1R1 h"
        using A7 tarski_def_2 sorry
      thus "h1 toleratesPARTFUN1R1 h2"
        using A1 A8 sorry
    qed "sorry"
    have "unionTARSKIK3 {TARSKIK2 g,h } =XBOOLE-0R4 g \\/XBOOLE-0K2 h"
      using zfmisc_1_th_75 sorry
    thus "g \\/XBOOLE-0K2 h inTARSKIR2 sproductCARD-3K8 f"
      using A4 A5 card_3_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_64:
" for f be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds x c=TARSKIR1 h & h inTARSKIR2 sproductCARD-3K8 f implies x inTARSKIR2 sproductCARD-3K8 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds x c=TARSKIR1 h & h inTARSKIR2 sproductCARD-3K8 f implies x inTARSKIR2 sproductCARD-3K8 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be setHIDDENM2"
    assume A1: "x c=TARSKIR1 h"
      and A2: "h inTARSKIR2 sproductCARD-3K8 f"
    obtain g where 
      [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = x"
      using A1 sorry
    have A3: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 h"
      using A1 grfunc_1_th_2 sorry
    have "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 f"
      using A2 card_3_th_49 sorry
    then have A4: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
      using A3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 domRELAT-1K1 g"
      then have "h .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using A2 A3 card_3_th_49 sorry
      thus "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using A1 A5 grfunc_1_th_2 sorry
    qed "sorry"
    thus "x inTARSKIR2 sproductCARD-3K8 f"
      using A4 card_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_65:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds g inTARSKIR2 sproductCARD-3K8 f implies g  |RELAT-1K8 A inTARSKIR2 sproductCARD-3K8 f"
  using card_3_th_64 relat_1_th_59 sorry

mtheorem card_3_th_66:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds g inTARSKIR2 sproductCARD-3K8 f implies g  |RELAT-1K8 A inTARSKIR2 sproductCARD-3K8 f  |RELAT-1K8 A"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds g inTARSKIR2 sproductCARD-3K8 f implies g  |RELAT-1K8 A inTARSKIR2 sproductCARD-3K8 f  |RELAT-1K8 A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    have A1: "domRELAT-1K1 (g  |RELAT-1K8 A) =XBOOLE-0R4 domRELAT-1K1 g /\\XBOOLE-0K3 A"
      using relat_1_th_61 sorry
    have A2: "domRELAT-1K1 (f  |RELAT-1K8 A) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 A"
      using relat_1_th_61 sorry
    assume A3: "g inTARSKIR2 sproductCARD-3K8 f"
    then have A4: "domRELAT-1K1 (g  |RELAT-1K8 A) c=TARSKIR1 domRELAT-1K1 (f  |RELAT-1K8 A)"
      using A1 A2 card_3_th_49 xboole_1_th_26 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (g  |RELAT-1K8 A) implies (g  |RELAT-1K8 A).FUNCT-1K1 x inTARSKIR2 (f  |RELAT-1K8 A).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 domRELAT-1K1 (g  |RELAT-1K8 A)"
      then have A6: "(g  |RELAT-1K8 A).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using funct_1_th_47 sorry
      have A7: "(f  |RELAT-1K8 A).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A4 A5 funct_1_th_47 sorry
      have "x inHIDDENR3 domRELAT-1K1 g"
        using A1 A5 xboole_0_def_4 sorry
      thus "(g  |RELAT-1K8 A).FUNCT-1K1 x inTARSKIR2 (f  |RELAT-1K8 A).FUNCT-1K1 x"
        using A3 A6 A7 card_3_th_49 sorry
    qed "sorry"
    thus "g  |RELAT-1K8 A inTARSKIR2 sproductCARD-3K8 f  |RELAT-1K8 A"
      using A4 card_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_67:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds h inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g) implies ( ex f9 be FunctionFUNCT-1M1 st  ex g9 be FunctionFUNCT-1M1 st (f9 inTARSKIR2 sproductCARD-3K8 f & g9 inTARSKIR2 sproductCARD-3K8 g) & h =FUNCT-1R1 f9 +*FUNCT-4K1 g9)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds h inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g) implies ( ex tVar26 be FunctionFUNCT-1M1 st  ex tVar27 be FunctionFUNCT-1M1 st tVar26 inTARSKIR2 sproductCARD-3K8 f & (tVar27 inTARSKIR2 sproductCARD-3K8 g & h =FUNCT-1R1 tVar26 +*FUNCT-4K1 tVar27))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "h inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g)"
    show " ex tVar26 be FunctionFUNCT-1M1 st  ex tVar27 be FunctionFUNCT-1M1 st tVar26 inTARSKIR2 sproductCARD-3K8 f & (tVar27 inTARSKIR2 sproductCARD-3K8 g & h =FUNCT-1R1 tVar26 +*FUNCT-4K1 tVar27)"
    proof(rule bexI[of _ "h  |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g)"])
      show " ex tVar27 be FunctionFUNCT-1M1 st h  |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g) inTARSKIR2 sproductCARD-3K8 f & (tVar27 inTARSKIR2 sproductCARD-3K8 g & h =FUNCT-1R1 h  |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g) +*FUNCT-4K1 tVar27)"
      proof(rule bexI[of _ "h  |RELAT-1K8 domRELAT-1K1 g"],rule conjMI,rule conjMI)
        have A2: "h  |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g) inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g) |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g)"
          using A1 card_3_th_66 sorry
        have "sproductCARD-3K8 (f +*FUNCT-4K1 g) |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g) c=TARSKIR1 sproductCARD-3K8 f"
          using card_3_th_56 funct_4_th_24 sorry
        thus "h  |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g) inTARSKIR2 sproductCARD-3K8 f"
          using A2 sorry
        have "(f +*FUNCT-4K1 g) |RELAT-1K8 domRELAT-1K1 g =FUNCT-1R1 g"
          using funct_4_th_23 sorry
        thus "h  |RELAT-1K8 domRELAT-1K1 g inTARSKIR2 sproductCARD-3K8 g"
          using A1 card_3_th_66 sorry
        have "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 (f +*FUNCT-4K1 g)"
          using A1 card_3_th_49 sorry
        then have "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
          using funct_4_def_1 sorry
        then have "domRELAT-1K1 h c=TARSKIR1 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g)\\/XBOOLE-0K2 domRELAT-1K1 g"
          using xboole_1_th_39 sorry
        thus "h =FUNCT-1R1 h  |RELAT-1K8 (domRELAT-1K1 f \\SUBSET-1K6 domRELAT-1K1 g) +*FUNCT-4K1 h  |RELAT-1K8 domRELAT-1K1 g"
          using funct_4_th_70 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_68:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for f9 be FunctionFUNCT-1M1 holds  for g9 be FunctionFUNCT-1M1 holds (domRELAT-1K1 g missesXBOOLE-0R1 domRELAT-1K1 f9 \\SUBSET-1K6 domRELAT-1K1 g9 & f9 inTARSKIR2 sproductCARD-3K8 f) & g9 inTARSKIR2 sproductCARD-3K8 g implies f9 +*FUNCT-4K1 g9 inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for f9 be FunctionFUNCT-1M1 holds  for g9 be FunctionFUNCT-1M1 holds domRELAT-1K1 g missesXBOOLE-0R1 domRELAT-1K1 f9 \\SUBSET-1K6 domRELAT-1K1 g9 & (f9 inTARSKIR2 sproductCARD-3K8 f & g9 inTARSKIR2 sproductCARD-3K8 g) implies f9 +*FUNCT-4K1 g9 inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-1M1"
    fix g9 assume [ty]: "g9 be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 g missesXBOOLE-0R1 domRELAT-1K1 f9 \\SUBSET-1K6 domRELAT-1K1 g9"
      and A2: "f9 inTARSKIR2 sproductCARD-3K8 f"
      and A3: "g9 inTARSKIR2 sproductCARD-3K8 g"
    let ?h = "f9 +*FUNCT-4K1 g9"
    have A4: "domRELAT-1K1 f9 c=TARSKIR1 domRELAT-1K1 f"
      using A2 card_3_th_49 sorry
    have A5: "domRELAT-1K1 g9 c=TARSKIR1 domRELAT-1K1 g"
      using A3 card_3_th_49 sorry
    then have A6: "domRELAT-1K1 f9 \\/XBOOLE-0K2 domRELAT-1K1 g9 c=TARSKIR1 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
      using A4 xboole_1_th_13 sorry
    have A7: "domRELAT-1K1 ?h =XBOOLE-0R4 domRELAT-1K1 f9 \\/XBOOLE-0K2 domRELAT-1K1 g9"
      using funct_4_def_1 sorry
    then have A8: "domRELAT-1K1 ?h c=TARSKIR1 domRELAT-1K1 (f +*FUNCT-4K1 g)"
      using A6 funct_4_def_1 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ?h implies ?h .FUNCT-1K1 x inTARSKIR2 (f +*FUNCT-4K1 g).FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f9 +*FUNCT-4K1 g9) implies (f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 (f +*FUNCT-4K1 g).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A9: "x inHIDDENR3 domRELAT-1K1 ?h"
        then have "x inHIDDENR3 domRELAT-1K1 (f +*FUNCT-4K1 g)"
          using A8 sorry
        then have A10: "x inHIDDENR3 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
          using funct_4_def_1 sorry
        have "x inHIDDENR3 (domRELAT-1K1 f9 \\SUBSET-1K6 domRELAT-1K1 g9)\\/XBOOLE-0K2 domRELAT-1K1 g9"
          using A7 A9 xboole_1_th_39 sorry
        then have A11: "x inHIDDENR3 domRELAT-1K1 f9 \\SUBSET-1K6 domRELAT-1K1 g9 or x inHIDDENR3 domRELAT-1K1 g9"
          using xboole_0_def_3 sorry
        have "x inHIDDENR3 domRELAT-1K1 g & (f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x or  not x inHIDDENR3 domRELAT-1K1 g & ( not x inHIDDENR3 domRELAT-1K1 g implies (f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
        proof-
          show "x inHIDDENR3 domRELAT-1K1 g & (f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x or  not x inHIDDENR3 domRELAT-1K1 g & ( not x inHIDDENR3 domRELAT-1K1 g implies (f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
          proof-
            have cases: "x inHIDDENR3 domRELAT-1K1 g or  not x inHIDDENR3 domRELAT-1K1 g"
               sorry
            have case1: "x inHIDDENR3 domRELAT-1K1 g implies (f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x"
            proof(rule impI)
              assume A12: "x inHIDDENR3 domRELAT-1K1 g"
              then have "?h .FUNCT-1K1 x =XBOOLE-0R4 g9 .FUNCT-1K1 x"
                using A1 A7 A9 A11 funct_4_def_1 xboole_0_th_3 sorry
              thus "(f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x"
                using A1 A3 A11 A12 card_3_th_49 xboole_0_th_3 sorry
            qed
            have case2: " not x inHIDDENR3 domRELAT-1K1 g implies (f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
            proof(rule impI)
              assume " not x inHIDDENR3 domRELAT-1K1 g"
              then have A13: " not x inHIDDENR3 domRELAT-1K1 g9"
                using A5 sorry
              then have A14: "?h .FUNCT-1K1 x =XBOOLE-0R4 f9 .FUNCT-1K1 x"
                using A7 A9 funct_4_def_1 sorry
              have "x inHIDDENR3 domRELAT-1K1 f9"
                using A7 A9 A13 xboole_0_def_3 sorry
              thus "(f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
                using A2 A14 card_3_th_49 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "(f9 +*FUNCT-4K1 g9).FUNCT-1K1 x inTARSKIR2 (f +*FUNCT-4K1 g).FUNCT-1K1 x"
          using A10 funct_4_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f9 +*FUNCT-4K1 g9 inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g)"
      using A8 card_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_69:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for f9 be FunctionFUNCT-1M1 holds  for g9 be FunctionFUNCT-1M1 holds (domRELAT-1K1 f9 missesXBOOLE-0R1 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 g9 & f9 inTARSKIR2 sproductCARD-3K8 f) & g9 inTARSKIR2 sproductCARD-3K8 g implies f9 +*FUNCT-4K1 g9 inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for f9 be FunctionFUNCT-1M1 holds  for g9 be FunctionFUNCT-1M1 holds domRELAT-1K1 f9 missesXBOOLE-0R1 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 g9 implies  not ((f9 inTARSKIR2 sproductCARD-3K8 f & g9 inTARSKIR2 sproductCARD-3K8 g) &  not f9 +*FUNCT-4K1 g9 inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-1M1"
    fix g9 assume [ty]: "g9 be FunctionFUNCT-1M1"
    assume "domRELAT-1K1 f9 missesXBOOLE-0R1 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 g9"
    then have "domRELAT-1K1 g missesXBOOLE-0R1 domRELAT-1K1 f9 \\SUBSET-1K6 domRELAT-1K1 g9"
      using xboole_1_th_81 sorry
    thus " not ((f9 inTARSKIR2 sproductCARD-3K8 f & g9 inTARSKIR2 sproductCARD-3K8 g) &  not f9 +*FUNCT-4K1 g9 inTARSKIR2 sproductCARD-3K8 (f +*FUNCT-4K1 g))"
      using card_3_th_68 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_70:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g inTARSKIR2 sproductCARD-3K8 f & h inTARSKIR2 sproductCARD-3K8 f implies g +*FUNCT-4K1 h inTARSKIR2 sproductCARD-3K8 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g inTARSKIR2 sproductCARD-3K8 f & h inTARSKIR2 sproductCARD-3K8 f implies g +*FUNCT-4K1 h inTARSKIR2 sproductCARD-3K8 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "g inTARSKIR2 sproductCARD-3K8 f"
      and A2: "h inTARSKIR2 sproductCARD-3K8 f"
    have A3: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
      using A1 card_3_th_49 sorry
    have "domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 f"
      using A2 card_3_th_49 sorry
    then have "domRELAT-1K1 g \\/XBOOLE-0K2 domRELAT-1K1 h c=TARSKIR1 domRELAT-1K1 f"
      using A3 xboole_1_th_8 sorry
    then have A4: "domRELAT-1K1 (g +*FUNCT-4K1 h) c=TARSKIR1 domRELAT-1K1 f"
      using funct_4_def_1 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 h) implies (g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 (g +*FUNCT-4K1 h)"
      then have "x inHIDDENR3 domRELAT-1K1 g \\/XBOOLE-0K2 domRELAT-1K1 h"
        using funct_4_def_1 sorry
      then have A5: "x inHIDDENR3 (domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h)\\/XBOOLE-0K2 domRELAT-1K1 h"
        using xboole_1_th_39 sorry
      have "(g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
      proof-
        show "(g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        proof-
          have cases: "x inHIDDENR3 domRELAT-1K1 h or x inHIDDENR3 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h"
            using A5 xboole_0_def_3 sorry
          have case1: "x inHIDDENR3 domRELAT-1K1 h implies (g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
          proof(rule impI)
            assume A6: "x inHIDDENR3 domRELAT-1K1 h"
            then have "h .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
              using A2 card_3_th_49 sorry
            thus "(g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
              using A6 funct_4_th_13 sorry
          qed
          have case2: "x inHIDDENR3 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h implies (g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
          proof(rule impI)
            assume A7: "x inHIDDENR3 domRELAT-1K1 g \\SUBSET-1K6 domRELAT-1K1 h"
            then have A8: "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
              using A1 card_3_th_49 sorry
            have " not x inHIDDENR3 domRELAT-1K1 h"
              using A7 xboole_0_def_5 sorry
            thus "(g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
              using A8 funct_4_th_11 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(g +*FUNCT-4K1 h).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "g +*FUNCT-4K1 h inTARSKIR2 sproductCARD-3K8 f"
      using A4 card_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_71:
" for f be FunctionFUNCT-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ((x1 inTARSKIR2 domRELAT-1K1 f & y1 inTARSKIR2 f .FUNCT-1K1 x1) & x2 inTARSKIR2 domRELAT-1K1 f) & y2 inTARSKIR2 f .FUNCT-1K1 x2 implies (x1,x2)-->FUNCT-4K6(y1,y2) inTARSKIR2 sproductCARD-3K8 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds x1 inTARSKIR2 domRELAT-1K1 f & y1 inTARSKIR2 f .FUNCT-1K1 x1 implies (x2 inTARSKIR2 domRELAT-1K1 f & y2 inTARSKIR2 f .FUNCT-1K1 x2 implies (x1,x2)-->FUNCT-4K6(y1,y2) inTARSKIR2 sproductCARD-3K8 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix y1 assume [ty]: "y1 be setHIDDENM2"
    fix y2 assume [ty]: "y2 be setHIDDENM2"
    assume A1: "x1 inTARSKIR2 domRELAT-1K1 f"
      and A2: "y1 inTARSKIR2 f .FUNCT-1K1 x1"
    have A3: "x1 .-->FUNCOP-1K17 y1 inTARSKIR2 sproductCARD-3K8 f"
      using A1 A2 card_3_th_60 sorry
    assume A4: "x2 inTARSKIR2 domRELAT-1K1 f"
      and A5: "y2 inTARSKIR2 f .FUNCT-1K1 x2"
    have A6: "x2 .-->FUNCOP-1K17 y2 inTARSKIR2 sproductCARD-3K8 f"
      using A4 A5 card_3_th_60 sorry
    have "(x1,x2)-->FUNCT-4K6(y1,y2) =FUNCT-1R1 (x1 .-->FUNCOP-1K17 y1)+*FUNCT-4K1 (x2 .-->FUNCOP-1K17 y2)"
      using funct_4_def_4 sorry
    thus "(x1,x2)-->FUNCT-4K6(y1,y2) inTARSKIR2 sproductCARD-3K8 f"
      using A3 A6 card_3_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef card_3_def_10 ("with-common-domainCARD-3V2" 70 ) where
"attr with-common-domainCARD-3V2 for setHIDDENM2 means
  (\<lambda>IT.  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f inTARSKIR2 IT & g inTARSKIR2 IT implies domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g)"..

mtheorem card_3_cl_11:
"cluster with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex A be setHIDDENM2 st A be with-common-domainCARD-3V2 & (A be functionalFUNCT-1V6 &  not A be emptyXBOOLE-0V1)"
    proof-
      let ?h = "the FunctionFUNCT-1M1"
      obtain A where 
        [ty]:"A be setHIDDENM2" and ADef:"A = {TARSKIK1 ?h}"
         sorry
      show " ex A be setHIDDENM2 st A be with-common-domainCARD-3V2 & (A be functionalFUNCT-1V6 &  not A be emptyXBOOLE-0V1)"
      proof(rule bexI[of _ "A"],rule conjMI,rule conjMI)
        have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f inTARSKIR2 A & g inTARSKIR2 A implies domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix f assume [ty]: "f be FunctionFUNCT-1M1"
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume A1: "f inTARSKIR2 A"
            and A2: "g inTARSKIR2 A"
          have "f =FUNCT-1R1 ?h"
            using A1 tarski_def_1 sorry
          thus "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
            using A2 tarski_def_1 sorry
        qed "sorry"
        thus "A be with-common-domainCARD-3V2"
           sorry
        show "A be functionalFUNCT-1V6"
           sorry
        show " not A be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_cl_12:
  mlet "f be FunctionFUNCT-1M1"
"cluster {TARSKIK1 f} as-term-is with-common-domainCARD-3V2"
proof
(*coherence*)
  show "{TARSKIK1 f} be with-common-domainCARD-3V2"
  proof-
    have " for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds g inTARSKIR2 {TARSKIK1 f} implies  not (h inTARSKIR2 {TARSKIK1 f} &  not domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h)"
    proof(rule ballI,rule ballI,rule impI)
      fix g assume [ty]: "g be FunctionFUNCT-1M1"
      fix h assume [ty]: "h be FunctionFUNCT-1M1"
      assume "g inTARSKIR2 {TARSKIK1 f}"
      then have "g =FUNCT-1R1 f"
        using tarski_def_1 sorry
      thus " not (h inTARSKIR2 {TARSKIK1 f} &  not domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h)"
        using tarski_def_1 sorry
    qed "sorry"
    thus "{TARSKIK1 f} be with-common-domainCARD-3V2"
      using card_3_def_10 sorry
  qed
qed "sorry"

mdef card_3_def_11 ("DOMCARD-3K9  _ " [164]164 ) where
  mlet "X be functionalFUNCT-1V6\<bar>setHIDDENM2"
"func DOMCARD-3K9 X \<rightarrow> setHIDDENM2 equals
  meetSETFAM-1K1 ({domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  })"
proof-
  (*coherence*)
    show "meetSETFAM-1K1 ({domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  }) be setHIDDENM2"
       sorry
qed "sorry"

mlemma card_3_lm_2:
" for X be functionalFUNCT-1V6\<bar>with-common-domainCARD-3V2\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 X implies domRELAT-1K1 f =XBOOLE-0R4 DOMCARD-3K9 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be functionalFUNCT-1V6\<bar>with-common-domainCARD-3V2\<bar>setHIDDENM2"
  let ?A = "{domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  }"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  assume A1: "f inTARSKIR2 X"
  then have "domRELAT-1K1 f inTARSKIR2 ?A"
     sorry
  then have A2: "{TARSKIK1 domRELAT-1K1 f } c=TARSKIR1 ?A"
    using zfmisc_1_th_31 sorry
  have "?A c=TARSKIR1 {TARSKIK1 domRELAT-1K1 f }"
  proof-
    have "{domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  } c=TARSKIR1 {TARSKIK1 domRELAT-1K1 f }"
    proof-
      have " for e be objectHIDDENM1 holds e inHIDDENR3 {domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  } implies e inHIDDENR3 {TARSKIK1 domRELAT-1K1 f }"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 ?A"
        then obtain g where
          [ty]:"g be ElementSUBSET-1M1-of X" and 
          A3: "e =HIDDENR1 domRELAT-1K1 g"
           sorry
        have "e =HIDDENR1 domRELAT-1K1 f"
          using A3 card_3_def_10 A1 sorry
        thus "e inHIDDENR3 {TARSKIK1 domRELAT-1K1 f }"
          using tarski_def_1 sorry
      qed "sorry"
      thus "{domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  } c=TARSKIR1 {TARSKIK1 domRELAT-1K1 f }"
        using tarski_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  then have "?A =XBOOLE-0R4 {TARSKIK1 domRELAT-1K1 f }"
    using A2 sorry
  thus "domRELAT-1K1 f =XBOOLE-0R4 DOMCARD-3K9 X"
    using setfam_1_th_10 sorry
qed "sorry"

mtheorem card_3_th_72:
" for X be with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2 holds X =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 } implies DOMCARD-3K9 X =XBOOLE-0R4 {}XBOOLE-0K1"
proof(rule ballI,rule impI)
  fix X assume [ty]: "X be with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2"
  assume A1: "X =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  have "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
    using tarski_def_1 sorry
  thus "DOMCARD-3K9 X =XBOOLE-0R4 {}XBOOLE-0K1"
    using A1 card_3_lm_2 relat_1_th_38 sorry
qed "sorry"

mtheorem card_3_cl_13:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster DOMCARD-3K9 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "DOMCARD-3K9 X be emptyXBOOLE-0V1"
  proof-
    let ?A = "{domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  }"
    have A1: "?A c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
    proof-
      have "{domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  } c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
      proof-
        have " for e be objectHIDDENM1 holds e inHIDDENR3 {domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  } implies e inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        proof(rule ballI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          assume "e inHIDDENR3 ?A"
          then have " ex f be ElementSUBSET-1M1-of X st e =HIDDENR1 domRELAT-1K1 f"
             sorry
          then have "e =HIDDENR1 domRELAT-1K1 ({}XBOOLE-0K1)"
            using subset_1_def_1 sorry
          thus "e inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
            using tarski_def_1 sorry
        qed "sorry"
        thus "{domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  } c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 ?A"
    proof-
      have "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 {domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  }"
      proof-
        have " for e be objectHIDDENM1 holds e inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies e inHIDDENR3 {domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  }"
        proof(rule ballI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          assume "e inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
          then have "e =HIDDENR1 {}XBOOLE-0K1"
            using tarski_def_1 sorry
          then have "e =HIDDENR1 domRELAT-1K1 ({}XBOOLE-0K1)"
             sorry
          then have "e =HIDDENR1 domRELAT-1K1 (the ElementSUBSET-1M1-of X)"
            using subset_1_def_1 sorry
          thus "e inHIDDENR3 {domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  }"
             sorry
        qed "sorry"
        thus "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 {domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have "?A =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      using A1 sorry
    thus "DOMCARD-3K9 X be emptyXBOOLE-0V1"
      using setfam_1_th_10 sorry
  qed
qed "sorry"

(*begin*)
mdef card_3_def_12 ("product\<inverse>CARD-3K10  _ " [228]228 ) where
  mlet "S be functionalFUNCT-1V6\<bar>setHIDDENM2"
"func product\<inverse>CARD-3K10 S \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 it implies it .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 it implies it .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i))"
    proof-
      have " ex tVar29 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar29 =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds  not (i inTARSKIR2 domRELAT-1K1 tVar29 &  not tVar29 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)))"
      proof-
        show " ex tVar29 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar29 =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds  not (i inTARSKIR2 domRELAT-1K1 tVar29 &  not tVar29 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)))"
        proof-
          have cases: "S =XBOOLE-0R4 {}XBOOLE-0K1 or S <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          have case1: "S =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar29 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar29 =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds  not (i inTARSKIR2 domRELAT-1K1 tVar29 &  not tVar29 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i))))"
          proof(rule impI)
            assume A1: "S =XBOOLE-0R4 {}XBOOLE-0K1"
            show " ex tVar29 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar29 =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds  not (i inTARSKIR2 domRELAT-1K1 tVar29 &  not tVar29 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)))"
            proof(rule bexI[of _ "{}XBOOLE-0K1"])
              show "domRELAT-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds  not (i inTARSKIR2 domRELAT-1K1 ({}XBOOLE-0K1) &  not {}XBOOLE-0K1 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)))"
                using A1 sorry
            qed "sorry"
          qed
          have case2: "S <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar31 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar31 =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 tVar31 implies tVar31 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)))"
          proof(rule impI)
            assume "S <>HIDDENR2 {}XBOOLE-0K1"
            then obtain S1 where 
              [ty]:"S1 be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2" and S1Def:"S1 = S"
               sorry
            let ?D = "{domRELAT-1K1 f where f be ElementSUBSET-1M1-of S1 :  True  }"
            let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st A =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 piCARD-3K5(S,A)"
            have A2: " for e be objectHIDDENM1 holds e inHIDDENR3 meetSETFAM-1K1 ?D implies ( ex u be objectHIDDENM1 st ?P(e,u))"
            proof-
              have " for e be objectHIDDENM1 holds e inHIDDENR3 meetSETFAM-1K1 ({domRELAT-1K1 f where f be ElementSUBSET-1M1-of S1 :  True  }) implies ( ex u be setHIDDENM2 st  ex A be setHIDDENM2 st A =HIDDENR1 e & u =HIDDENR1 piCARD-3K5(S,A))"
              proof(rule ballI,rule impI)
                fix e assume [ty]: "e be objectHIDDENM1"
                obtain A where 
                  [ty]:"A be setHIDDENM2" and ADef:"A = e"
                  using tarski_th_1 sorry
                assume "e inHIDDENR3 meetSETFAM-1K1 ?D"
                obtain u where 
                  [ty]:"u be setHIDDENM2" and uDef:"u = piCARD-3K5(S,A)"
                   sorry
                show " ex u be setHIDDENM2 st  ex A be setHIDDENM2 st A =HIDDENR1 e & u =HIDDENR1 piCARD-3K5(S,A)"
                proof(rule bexI[of _ "u"])
                  show " ex A be setHIDDENM2 st A =HIDDENR1 e & u =HIDDENR1 piCARD-3K5(S,A)"
                     sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain g where
              [ty]:"g be FunctionFUNCT-1M1" and 
              A3: "domRELAT-1K1 g =XBOOLE-0R4 meetSETFAM-1K1 ?D"and A4: " for e be objectHIDDENM1 holds e inHIDDENR3 meetSETFAM-1K1 ?D implies ?P(e,g .FUNCT-1K1 e)"
              using classes1_sch_1 A2 sorry
            show " ex tVar31 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar31 =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 tVar31 implies tVar31 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i))"
            proof(rule bexI[of _ "g"],rule conjMI,rule ballI,rule impI)
              show "domRELAT-1K1 g =XBOOLE-0R4 DOMCARD-3K9 S"
                using A3 sorry
              fix i assume [ty]: "i be setHIDDENM2"
              assume "i inTARSKIR2 domRELAT-1K1 g"
              then have "?P(i,g .FUNCT-1K1 i)"
                using A3 A4 sorry
              thus "g .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)"
                 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i))) & (domRELAT-1K1 it2 =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 DOMCARD-3K9 S & (( for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)) & (domRELAT-1K1 g =XBOOLE-0R4 DOMCARD-3K9 S & ( for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 g implies g .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)))) implies f =FUNCT-1R1 g"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f assume [ty]: "f be FunctionFUNCT-1M1"
        fix g assume [ty]: "g be FunctionFUNCT-1M1"
        assume A5: "domRELAT-1K1 f =XBOOLE-0R4 DOMCARD-3K9 S"
          and A6: " for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)"
          and A7: "domRELAT-1K1 g =XBOOLE-0R4 DOMCARD-3K9 S"
          and A8: " for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 g implies g .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A9: "x inHIDDENR3 domRELAT-1K1 f"
            then have "f .FUNCT-1K1 x =HIDDENR1 piCARD-3K5(S,x)"
              using A6 sorry
            also have "... = g .FUNCT-1K1 x"
              using A5 A7 A9 A8 sorry
            finally show "f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f =FUNCT-1R1 g"
          using A5 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

(*\$CT*)
mtheorem card_3_th_74:
" for S be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2 holds  for i be setHIDDENM2 holds i inTARSKIR2 domRELAT-1K1 (product\<inverse>CARD-3K10 S) implies product\<inverse>CARD-3K10 S .FUNCT-1K1 i =XBOOLE-0R4 {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  }"
proof(rule ballI,rule ballI,rule impI)
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2"
  fix i assume [ty]: "i be setHIDDENM2"
  assume A1: "i inTARSKIR2 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
  have "( for x be objectHIDDENM1 holds x inHIDDENR3 product\<inverse>CARD-3K10 S .FUNCT-1K1 i implies x inHIDDENR3 {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  }) & {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  } c=TARSKIR1 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
  proof(rule conjMI)
    show " for x be objectHIDDENM1 holds x inHIDDENR3 product\<inverse>CARD-3K10 S .FUNCT-1K1 i implies x inHIDDENR3 {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
      then have "x inHIDDENR3 piCARD-3K5(S,i)"
        using A1 card_3_def_12 sorry
      then have " ex f be FunctionFUNCT-1M1 st f inTARSKIR2 S & x =HIDDENR1 f .FUNCT-1K1 i"
        using card_3_def_6 sorry
      thus "x inHIDDENR3 {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  }"
         sorry
    qed "sorry"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  } implies x inHIDDENR3 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  }"
      then have " ex f be ElementSUBSET-1M1-of S st x =HIDDENR1 f .FUNCT-1K1 i"
         sorry
      then have "x inHIDDENR3 piCARD-3K5(S,i)"
        using card_3_def_6 sorry
      thus "x inHIDDENR3 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
        using A1 card_3_def_12 sorry
    qed "sorry"
    thus "{f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  } c=TARSKIR1 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
      using tarski_def_3 sorry
  qed
  thus "product\<inverse>CARD-3K10 S .FUNCT-1K1 i =XBOOLE-0R4 {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  }"
    using tarski_def_3 xboole_0_def_10 sorry
qed "sorry"

mdef card_3_def_13 ("product-likeCARD-3V3" 70 ) where
"attr product-likeCARD-3V3 for setHIDDENM2 means
  (\<lambda>S.  ex f be FunctionFUNCT-1M1 st S =XBOOLE-0R4 productCARD-3K4 f)"..

mtheorem card_3_cl_14:
  mlet "f be FunctionFUNCT-1M1"
"cluster productCARD-3K4 f as-term-is product-likeCARD-3V3"
proof
(*coherence*)
  show "productCARD-3K4 f be product-likeCARD-3V3"
     sorry
qed "sorry"

mtheorem card_3_cl_15:
"cluster product-likeCARD-3V3 also-is functionalFUNCT-1V6\<bar>with-common-domainCARD-3V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be product-likeCARD-3V3 implies it be functionalFUNCT-1V6\<bar>with-common-domainCARD-3V2"
  proof-
    have " for S be setHIDDENM2 holds  not (S be product-likeCARD-3V3 &  not (S be functionalFUNCT-1V6 & S be with-common-domainCARD-3V2))"
    proof(rule ballI)
      fix S assume [ty]: "S be setHIDDENM2"
      have "( ex f be FunctionFUNCT-1M1 st S =XBOOLE-0R4 productCARD-3K4 f) implies S be functionalFUNCT-1V6 & S be with-common-domainCARD-3V2"
      proof(rule impI,rule conjMI)
        assume Given: " ex f be FunctionFUNCT-1M1 st S =XBOOLE-0R4 productCARD-3K4 f"
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A1: "S =XBOOLE-0R4 productCARD-3K4 f"
           sorry
        show "S be functionalFUNCT-1V6"
          using A1 sorry
        have " for h be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds h inTARSKIR2 S & g inTARSKIR2 S implies domRELAT-1K1 h =HIDDENR1 domRELAT-1K1 g"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix h assume [ty]: "h be FunctionFUNCT-1M1"
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume A2: "h inTARSKIR2 S"
            and A3: "g inTARSKIR2 S"
          have "domRELAT-1K1 h =HIDDENR1 domRELAT-1K1 f"
            using A1 A2 card_3_th_9 sorry
          also have "... = domRELAT-1K1 g"
            using A1 A3 card_3_th_9 sorry
          finally show "domRELAT-1K1 h =HIDDENR1 domRELAT-1K1 g"
             sorry
        qed "sorry"
        thus "S be with-common-domainCARD-3V2"
          using card_3_def_10 sorry
      qed
      thus " not (S be product-likeCARD-3V3 &  not (S be functionalFUNCT-1V6 & S be with-common-domainCARD-3V2))"
        using card_3_def_13 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_cl_16:
"cluster product-likeCARD-3V3\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be product-likeCARD-3V3\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar32 be setHIDDENM2 st tVar32 be product-likeCARD-3V3 &  not tVar32 be emptyXBOOLE-0V1"
    proof-
      let ?B = "the with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2"
      let ?f = "the FunctionFUNCT-2M1-of(0ORDINAL1K5,?B)"
      show " ex tVar32 be setHIDDENM2 st tVar32 be product-likeCARD-3V3 &  not tVar32 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "productCARD-3K4 ?f"])
        show "productCARD-3K4 (the FunctionFUNCT-2M1-of(0ORDINAL1K5,the with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2)) be product-likeCARD-3V3 &  not productCARD-3K4 (the FunctionFUNCT-2M1-of(0ORDINAL1K5,the with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2)) be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CT 2*)
mtheorem card_3_th_77:
" for S be functionalFUNCT-1V6\<bar>with-common-domainCARD-3V2\<bar>setHIDDENM2 holds S c=TARSKIR1 productCARD-3K4 (product\<inverse>CARD-3K10 S)"
proof(rule ballI)
  fix S assume [ty]: "S be functionalFUNCT-1V6\<bar>with-common-domainCARD-3V2\<bar>setHIDDENM2"
  have " for f be objectHIDDENM1 holds f inHIDDENR3 S implies f inHIDDENR3 productCARD-3K4 (product\<inverse>CARD-3K10 S)"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be objectHIDDENM1"
    assume A1: "f inHIDDENR3 S"
    then have 
      [ty]:"f be ElementSUBSET-1M1-of S"
       sorry
    have A2: "domRELAT-1K1 f =HIDDENR1 DOMCARD-3K9 S"
      using A1 card_3_lm_2 sorry
    also have "... = domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
      using card_3_def_12 sorry
    finally have "domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 (product\<inverse>CARD-3K10 S) implies f .FUNCT-1K1 i inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
      then have "product\<inverse>CARD-3K10 S .FUNCT-1K1 i =XBOOLE-0R4 piCARD-3K5(S,i)"
        using card_3_def_12 sorry
      thus "f .FUNCT-1K1 i inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
        using A1 card_3_def_6 sorry
    qed "sorry"
    thus "f inHIDDENR3 productCARD-3K4 (product\<inverse>CARD-3K10 S)"
      using A2 card_3_th_9 sorry
  qed "sorry"
  thus "S c=TARSKIR1 productCARD-3K4 (product\<inverse>CARD-3K10 S)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem card_3_th_78:
" for S be  non emptyXBOOLE-0V1\<bar>product-likeCARD-3V3\<bar>setHIDDENM2 holds S =XBOOLE-0R4 productCARD-3K4 (product\<inverse>CARD-3K10 S)"
proof(rule ballI)
  fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>product-likeCARD-3V3\<bar>setHIDDENM2"
  have "S c=TARSKIR1 productCARD-3K4 (product\<inverse>CARD-3K10 S) & productCARD-3K4 (product\<inverse>CARD-3K10 S) c=TARSKIR1 S"
  proof(rule conjMI)
    show "S c=TARSKIR1 productCARD-3K4 (product\<inverse>CARD-3K10 S)"
      using card_3_th_77 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 (product\<inverse>CARD-3K10 S) implies x inHIDDENR3 S"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 productCARD-3K4 (product\<inverse>CARD-3K10 S)"
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A1: "x =HIDDENR1 g"and A2: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"and A3: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (product\<inverse>CARD-3K10 S) implies g .FUNCT-1K1 z inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 z"
        using card_3_def_5 sorry
      obtain p where
        [ty]:"p be FunctionFUNCT-1M1" and 
        A4: "S =XBOOLE-0R4 productCARD-3K4 p"
        using card_3_def_13 sorry
      let ?s = "the ElementSUBSET-1M1-of S"
      have A5: "domRELAT-1K1 g =HIDDENR1 DOMCARD-3K9 S"
        using A2 card_3_def_12 sorry
      also have "... = domRELAT-1K1 ?s"
        using card_3_lm_2 sorry
      also have "... = domRELAT-1K1 p"
        using A4 card_3_th_9 sorry
      finally have "domRELAT-1K1 g =HIDDENR1 domRELAT-1K1 p"
         sorry
      have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 p implies g .FUNCT-1K1 z inTARSKIR2 p .FUNCT-1K1 z"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A6: "z inHIDDENR3 domRELAT-1K1 p"
        then have "g .FUNCT-1K1 z inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 z"
          using A2 A3 A5 sorry
        then have "g .FUNCT-1K1 z inTARSKIR2 piCARD-3K5(S,z)"
          using A2 A5 A6 card_3_def_12 sorry
        then have " ex f be FunctionFUNCT-1M1 st f inTARSKIR2 S & g .FUNCT-1K1 z =XBOOLE-0R4 f .FUNCT-1K1 z"
          using card_3_def_6 sorry
        thus "g .FUNCT-1K1 z inTARSKIR2 p .FUNCT-1K1 z"
          using A4 A6 card_3_th_9 sorry
      qed "sorry"
      thus "x inHIDDENR3 S"
        using A1 A4 A5 card_3_th_9 sorry
    qed "sorry"
    thus "productCARD-3K4 (product\<inverse>CARD-3K10 S) c=TARSKIR1 S"
      using tarski_def_3 sorry
  qed
  thus "S =XBOOLE-0R4 productCARD-3K4 (product\<inverse>CARD-3K10 S)"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem card_3_th_79:
" for f be FunctionFUNCT-1M1 holds  for s be ElementSUBSET-1M1-of productCARD-3K4 f holds  for t be ElementSUBSET-1M1-of productCARD-3K4 f holds  for A be setHIDDENM2 holds s +*FUNCT-4K1 t  |RELAT-1K8 A be ElementSUBSET-1M1-of productCARD-3K4 f"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix s assume [ty]: "s be ElementSUBSET-1M1-of productCARD-3K4 f"
  fix t assume [ty]: "t be ElementSUBSET-1M1-of productCARD-3K4 f"
  fix A assume [ty]: "A be setHIDDENM2"
  show "s +*FUNCT-4K1 t  |RELAT-1K8 A be ElementSUBSET-1M1-of productCARD-3K4 f"
  proof-
    have cases: "f be non-emptyFUNCT-1V4 or  not f be non-emptyFUNCT-1V4"
       sorry
    have case1: "f be non-emptyFUNCT-1V4 implies s +*FUNCT-4K1 t  |RELAT-1K8 A be ElementSUBSET-1M1-of productCARD-3K4 f"
    proof(rule impI)
      assume "f be non-emptyFUNCT-1V4"
      then have "productCARD-3K4 f <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      then have A1: "t inTARSKIR2 productCARD-3K4 f"
         sorry
      have "productCARD-3K4 f c=TARSKIR1 sproductCARD-3K8 f"
        using card_3_th_51 sorry
      thus "s +*FUNCT-4K1 t  |RELAT-1K8 A be ElementSUBSET-1M1-of productCARD-3K4 f"
        using A1 card_3_th_53 card_3_th_65 sorry
    qed
    have case2: " not f be non-emptyFUNCT-1V4 implies s +*FUNCT-4K1 t  |RELAT-1K8 A be ElementSUBSET-1M1-of productCARD-3K4 f"
    proof(rule impI)
      assume " not f be non-emptyFUNCT-1V4"
      then have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
         sorry
      then have A2: "productCARD-3K4 f =XBOOLE-0R4 {}XBOOLE-0K1"
        using card_3_th_26 sorry
      have "t =FUNCT-1R1 {}XBOOLE-0K1"
        using A2 subset_1_def_1 sorry
      then have "t  |RELAT-1K8 A =FUNCT-1R1 {}XBOOLE-0K1"
         sorry
      thus "s +*FUNCT-4K1 t  |RELAT-1K8 A be ElementSUBSET-1M1-of productCARD-3K4 f"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem card_3_th_80:
" for f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds  for p be ElementSUBSET-1M1-of sproductCARD-3K8 f holds  ex s be ElementSUBSET-1M1-of productCARD-3K4 f st p c=RELAT-1R2 s"
proof-
  have " for f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds  for p be ElementSUBSET-1M1-of sproductCARD-3K8 f holds  ex tVar33 be ElementSUBSET-1M1-of productCARD-3K4 f st p c=RELAT-1R2 tVar33"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of sproductCARD-3K8 f"
    let ?h = "the ElementSUBSET-1M1-of productCARD-3K4 f"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of productCARD-3K4 f" and sDef:"s = ?h +*FUNCT-4K1 p"
      using card_3_th_53 sorry
    show " ex tVar33 be ElementSUBSET-1M1-of productCARD-3K4 f st p c=RELAT-1R2 tVar33"
    proof(rule bexI[of _ "s"])
      show "p c=RELAT-1R2 s"
        using funct_4_th_25 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_81:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds g inTARSKIR2 productCARD-3K4 f implies g  |RELAT-1K8 A inTARSKIR2 sproductCARD-3K8 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds g inTARSKIR2 productCARD-3K4 f implies g  |RELAT-1K8 A inTARSKIR2 sproductCARD-3K8 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    have A1: "productCARD-3K4 f c=TARSKIR1 sproductCARD-3K8 f"
      using card_3_th_51 sorry
    assume "g inTARSKIR2 productCARD-3K4 f"
    thus "g  |RELAT-1K8 A inTARSKIR2 sproductCARD-3K8 f"
      using A1 card_3_th_64 relat_1_th_59 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax CARD_3K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _  |CARD-3K11\<^bsub>'( _ ')\<^esub>  _ " [200,0,200]200)
translations "g  |CARD-3K11\<^bsub>(f)\<^esub> X" \<rightharpoonup> "g  |RELAT-1K8 X"

mtheorem card_3_add_1:
  mlet "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1", "g be ElementSUBSET-1M1-of productCARD-3K4 f", "X be setHIDDENM2"
"cluster g  |RELAT-1K8 X as-term-is ElementSUBSET-1M1-of sproductCARD-3K8 f"
proof
(*coherence*)
  show "g  |RELAT-1K8 X be ElementSUBSET-1M1-of sproductCARD-3K8 f"
    using card_3_th_81 sorry
qed "sorry"

mtheorem card_3_th_82:
" for f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds  for s be ElementSUBSET-1M1-of productCARD-3K4 f holds  for ss be ElementSUBSET-1M1-of productCARD-3K4 f holds  for A be setHIDDENM2 holds (ss +*FUNCT-4K1 s  |CARD-3K11\<^bsub>(f)\<^esub> A) |RELAT-1K8 A =FUNCT-1R1 s  |CARD-3K11\<^bsub>(f)\<^esub> A"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
  fix s assume [ty]: "s be ElementSUBSET-1M1-of productCARD-3K4 f"
  fix ss assume [ty]: "ss be ElementSUBSET-1M1-of productCARD-3K4 f"
  fix A assume [ty]: "A be setHIDDENM2"
  have "domRELAT-1K1 s =HIDDENR1 domRELAT-1K1 f"
    using card_3_th_9 sorry
  also have "... = domRELAT-1K1 ss"
    using card_3_th_9 sorry
  finally have "domRELAT-1K1 s =HIDDENR1 domRELAT-1K1 ss"
     sorry
  then have "A /\\XBOOLE-0K3 domRELAT-1K1 ss c=TARSKIR1 A /\\XBOOLE-0K3 domRELAT-1K1 s"
     sorry
  thus "(ss +*FUNCT-4K1 s  |CARD-3K11\<^bsub>(f)\<^esub> A) |RELAT-1K8 A =FUNCT-1R1 s  |CARD-3K11\<^bsub>(f)\<^esub> A"
    using funct_4_th_88 sorry
qed "sorry"

mtheorem card_3_th_83:
" for M be FunctionFUNCT-1M1 holds  for x be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inTARSKIR2 productCARD-3K4 M implies x *FUNCT-1K3 g inTARSKIR2 productCARD-3K4 (M *FUNCT-1K3 g)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix M assume [ty]: "M be FunctionFUNCT-1M1"
  fix x assume [ty]: "x be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  assume A1: "x inTARSKIR2 productCARD-3K4 M"
  let ?xg = "x *FUNCT-1K3 g"
  let ?Mg = "M *FUNCT-1K3 g"
  have A2: " ex gg be FunctionFUNCT-1M1 st (x =FUNCT-1R1 gg & domRELAT-1K1 gg =XBOOLE-0R4 domRELAT-1K1 M) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 M implies gg .FUNCT-1K1 x inTARSKIR2 M .FUNCT-1K1 x)"
    using A1 card_3_def_5 sorry
  then have A3: "domRELAT-1K1 ?xg =XBOOLE-0R4 domRELAT-1K1 ?Mg"
    using relat_1_th_163 sorry
  have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (M *FUNCT-1K3 g) implies (x *FUNCT-1K3 g).FUNCT-1K1 y inTARSKIR2 (M *FUNCT-1K3 g).FUNCT-1K1 y"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A4: "y inHIDDENR3 domRELAT-1K1 ?Mg"
    then have A5: "y inHIDDENR3 domRELAT-1K1 g"
      using funct_1_th_11 sorry
    have A6: "g .FUNCT-1K1 y inTARSKIR2 domRELAT-1K1 M"
      using A4 funct_1_th_11 sorry
    have A7: "?xg .FUNCT-1K1 y =XBOOLE-0R4 x .FUNCT-1K1 (g .FUNCT-1K1 y)"
      using A5 funct_1_th_13 sorry
    have "?Mg .FUNCT-1K1 y =XBOOLE-0R4 M .FUNCT-1K1 (g .FUNCT-1K1 y)"
      using A5 funct_1_th_13 sorry
    thus "(x *FUNCT-1K3 g).FUNCT-1K1 y inTARSKIR2 (M *FUNCT-1K3 g).FUNCT-1K1 y"
      using A2 A6 A7 sorry
  qed "sorry"
  thus "x *FUNCT-1K3 g inTARSKIR2 productCARD-3K4 (M *FUNCT-1K3 g)"
    using A3 card_3_def_5 sorry
qed "sorry"

mtheorem card_3_th_84:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 iff cardCARD-1K1 X inTARSKIR2 omegaORDINAL1K4"
  using card_3_th_42 sorry

reserve A, B for "OrdinalORDINAL1M3"
mtheorem card_3_th_85:
" for A be OrdinalORDINAL1M3 holds A be infiniteFINSET-1V2 iff omegaORDINAL1K4 c=ORDINAL1R1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  not ( not A be infiniteFINSET-1V2 &  not omegaORDINAL1K4 c=ORDINAL1R1 A) &  not (omegaORDINAL1K4 c=ORDINAL1R1 A & A be infiniteFINSET-1V2)"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "omegaORDINAL1K4 c=ORDINAL1R1 A iff  not A inTARSKIR2 omegaORDINAL1K4"
      using ordinal1_th_16 sorry
    thus " not ( not A be infiniteFINSET-1V2 &  not omegaORDINAL1K4 c=ORDINAL1R1 A) &  not (omegaORDINAL1K4 c=ORDINAL1R1 A & A be infiniteFINSET-1V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_86:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds N be finiteFINSET-1V1 &  not M be finiteFINSET-1V1 implies N inTARSKIR2 M & N c=ORDINAL1R1 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds N be finiteFINSET-1V1 &  not M be finiteFINSET-1V1 implies N inTARSKIR2 M & N c=ORDINAL1R1 M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "N be finiteFINSET-1V1"
      and A2: " not M be finiteFINSET-1V1"
    have A3: "N inTARSKIR2 omegaORDINAL1K4"
      using A1 card_1_th_61 sorry
    have "omegaORDINAL1K4 c=ORDINAL1R1 M"
      using A2 card_3_th_85 sorry
    thus "N inTARSKIR2 M"
      using A3 sorry
    show "N c=ORDINAL1R1 M"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_87:
" for X be setHIDDENM2 holds  not X be finiteFINSET-1V1 iff ( ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4)"
proof-
  have " for X be setHIDDENM2 holds ( not X be finiteFINSET-1V1 implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4)) & (( ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4) implies  not X be finiteFINSET-1V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    show " not X be finiteFINSET-1V1 implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4)"
    proof-
      have " not X be finiteFINSET-1V1 implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4)"
      proof(rule impI)
        assume " not X be finiteFINSET-1V1"
        then have " not cardCARD-1K1 X inTARSKIR2 omegaORDINAL1K4"
           sorry
        then have A1: "omegaORDINAL1K4 c=ORDINAL1R1 cardCARD-1K1 X"
          using card_1_th_4 sorry
        have "(cardCARD-1K1 X,X)are-equipotentWELLORD2R2"
          using card_1_def_2 sorry
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A2: "f be one-to-oneFUNCT-1V2"and A3: "domRELAT-1K1 f =XBOOLE-0R4 cardCARD-1K1 X"and A4: "rngFUNCT-1K2 f =XBOOLE-0R4 X"
           sorry
        obtain Y where 
          [ty]:"Y be setHIDDENM2" and YDef:"Y = f .:FUNCT-1K5 omegaORDINAL1K4"
           sorry
        show " ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4"
        proof(rule bexI[of _ "Y"],rule conjMI)
          show "Y c=TARSKIR1 X"
            using A4 relat_1_th_111 sorry
          have "(omegaORDINAL1K4,Y)are-equipotentWELLORD2R2"
          proof-
            have "(f  |RELAT-1K8 omegaORDINAL1K4 be one-to-oneFUNCT-1V2 & proj1XTUPLE-0K12 (f  |RELAT-1K8 omegaORDINAL1K4) =HIDDENR1 omegaORDINAL1K4) & proj2XTUPLE-0K13 (f  |RELAT-1K8 omegaORDINAL1K4) =HIDDENR1 Y"
            proof-
              show "(f  |RELAT-1K8 omegaORDINAL1K4 be one-to-oneFUNCT-1V2 & proj1XTUPLE-0K12 (f  |RELAT-1K8 omegaORDINAL1K4) =HIDDENR1 omegaORDINAL1K4) & proj2XTUPLE-0K13 (f  |RELAT-1K8 omegaORDINAL1K4) =HIDDENR1 Y"
                using A1 A2 A3 funct_1_th_52 relat_1_th_62 relat_1_th_115 sorry
            qed
            thus "(omegaORDINAL1K4,Y)are-equipotentWELLORD2R2"
              using bexI[of _ "f  |RELAT-1K8 omegaORDINAL1K4"] wellord2_def_4 sorry
          qed
          thus "cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4"
            using card_1_def_2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4"
    then obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A5: "Y c=TARSKIR1 X"and A6: "cardCARD-1K1 Y =XBOOLE-0R4 omegaORDINAL1K4"
       sorry
    show " not X be finiteFINSET-1V1"
      using A5 A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_88:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y iff nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y implies nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y) & (nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y & cardCARD-1K1 X <>HIDDENR2 cardCARD-1K1 Y implies  not  True )"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y implies nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
      using card_1_th_16 sorry
    assume A1: "nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
      and A2: "cardCARD-1K1 X <>HIDDENR2 cardCARD-1K1 Y"
    have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Y or cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X"
      using A2 ordinal1_th_14 sorry
    then have "nextcardCARD-1K2 X c=ORDINAL1R1 cardCARD-1K1 Y & cardCARD-1K1 Y inTARSKIR2 nextcardCARD-1K2 Y or nextcardCARD-1K2 Y c=ORDINAL1R1 cardCARD-1K1 X & cardCARD-1K1 X inTARSKIR2 nextcardCARD-1K2 X"
      using card_1_def_3 sorry
    thus " not  True "
      using A1 ordinal1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_89:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds nextcardCARD-1K2 N =XBOOLE-0R4 nextcardCARD-1K2 M implies M =XBOOLE-0R4 N"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not (nextcardCARD-1K2 N =XBOOLE-0R4 nextcardCARD-1K2 M &  not M =XBOOLE-0R4 N)"
  proof(rule ballI,rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: "cardCARD-1K1 N =XBOOLE-0R4 N"
       sorry
    have "cardCARD-1K1 M =XBOOLE-0R4 M"
       sorry
    thus " not (nextcardCARD-1K2 N =XBOOLE-0R4 nextcardCARD-1K2 M &  not M =XBOOLE-0R4 N)"
      using A1 card_3_th_88 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_90:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds N inTARSKIR2 M iff nextcardCARD-1K2 N c=ORDINAL1R1 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not (N inTARSKIR2 M &  not nextcardCARD-1K2 N c=ORDINAL1R1 M) &  not (nextcardCARD-1K2 N c=ORDINAL1R1 M &  not N inTARSKIR2 M)"
  proof(rule ballI,rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: "N inTARSKIR2 nextcardCARD-1K2 N"
      using card_1_th_18 sorry
    have "cardCARD-1K1 N =XBOOLE-0R4 N"
       sorry
    thus " not (N inTARSKIR2 M &  not nextcardCARD-1K2 N c=ORDINAL1R1 M) &  not (nextcardCARD-1K2 N c=ORDINAL1R1 M &  not N inTARSKIR2 M)"
      using A1 card_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_91:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds N inTARSKIR2 nextcardCARD-1K2 M iff N c=ORDINAL1R1 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not (N inTARSKIR2 nextcardCARD-1K2 M &  not N c=ORDINAL1R1 M) &  not (N c=ORDINAL1R1 M &  not N inTARSKIR2 nextcardCARD-1K2 M)"
  proof(rule ballI,rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: " not N c=ORDINAL1R1 M iff M inTARSKIR2 N"
      using card_1_th_4 sorry
    have "N inTARSKIR2 nextcardCARD-1K2 M iff  not nextcardCARD-1K2 M c=ORDINAL1R1 N"
      using card_1_th_4 sorry
    thus " not (N inTARSKIR2 nextcardCARD-1K2 M &  not N c=ORDINAL1R1 M) &  not (N c=ORDINAL1R1 M &  not N inTARSKIR2 nextcardCARD-1K2 M)"
      using A1 card_3_th_90 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_92:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M be finiteFINSET-1V1 & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies N be finiteFINSET-1V1"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M be finiteFINSET-1V1 & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies N be finiteFINSET-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "M be finiteFINSET-1V1"
      and A2: "N c=ORDINAL1R1 M or N inTARSKIR2 M"
    have "N c=ORDINAL1R1 M"
      using A2 card_1_th_3 sorry
    thus "N be finiteFINSET-1V1"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_3_def_14 ("countableCARD-3V4" 70 ) where
"attr countableCARD-3V4 for setHIDDENM2 means
  (\<lambda>X. cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4)"..

mdef card_3_def_15 ("denumerableCARD-3V5" 70 ) where
"attr denumerableCARD-3V5 for setHIDDENM2 means
  (\<lambda>X. cardCARD-1K1 X =XBOOLE-0R4 omegaORDINAL1K4)"..

mtheorem card_3_cl_17:
"cluster denumerableCARD-3V5 also-is countableCARD-3V4\<bar>infiniteFINSET-1V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be denumerableCARD-3V5 implies it be countableCARD-3V4\<bar>infiniteFINSET-1V2"
     sorry
qed "sorry"

mtheorem card_3_cl_18:
"cluster countableCARD-3V4\<bar>infiniteFINSET-1V2 also-is denumerableCARD-3V5 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be countableCARD-3V4\<bar>infiniteFINSET-1V2 implies it be denumerableCARD-3V5"
  proof-
    have " for X be setHIDDENM2 holds  not ((X be countableCARD-3V4 &  not X be infiniteFINSET-1V2) &  not X be denumerableCARD-3V5)"
    proof(rule ballI)
      fix X assume [ty]: "X be setHIDDENM2"
      have "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4 implies (X be infiniteFINSET-1V2 implies X be denumerableCARD-3V5)"
      proof(rule impI,rule impI)
        assume A1: "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4"
        assume "X be infiniteFINSET-1V2"
        then have Cut3108: "omegaORDINAL1K4 c=ORDINAL1R1 cardCARD-1K1 X"
          using card_3_th_85 sorry
        have "cardCARD-1K1 X =XBOOLE-0R4 omegaORDINAL1K4"
        proof-
          show "cardCARD-1K1 X =XBOOLE-0R4 omegaORDINAL1K4"
            using A1 Cut3108 sorry
        qed
        thus "X be denumerableCARD-3V5"
          using card_3_def_15 sorry
      qed
      thus " not ((X be countableCARD-3V4 &  not X be infiniteFINSET-1V2) &  not X be denumerableCARD-3V5)"
        using card_3_def_14 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_cl_19:
"cluster finiteFINSET-1V1 also-is countableCARD-3V4 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be finiteFINSET-1V1 implies it be countableCARD-3V4"
     sorry
qed "sorry"

mtheorem card_3_cl_20:
"cluster omegaORDINAL1K4 as-term-is denumerableCARD-3V5"
proof
(*coherence*)
  show "omegaORDINAL1K4 be denumerableCARD-3V5"
     sorry
qed "sorry"

mtheorem card_3_cl_21:
"cluster denumerableCARD-3V5 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be denumerableCARD-3V5"
  proof-
    have " ex tVar36 be setHIDDENM2 st tVar36 be denumerableCARD-3V5"
    proof-
      show " ex tVar36 be setHIDDENM2 st tVar36 be denumerableCARD-3V5"
      proof(rule bexI[of _ "omegaORDINAL1K4"])
        show "omegaORDINAL1K4 be denumerableCARD-3V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_th_93:
" for X be setHIDDENM2 holds X be countableCARD-3V4 iff ( ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4 & X c=TARSKIR1 rngFUNCT-1K2 f)"
  using card_1_th_12 card_1_th_47 sorry

mtheorem card_3_cl_22:
  mlet "X be countableCARD-3V4\<bar>setHIDDENM2"
"cluster note-that countableCARD-3V4 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be countableCARD-3V4"
  proof-
    have " for Y be SubsetSUBSET-1M2-of X holds Y be countableCARD-3V4"
    proof(rule ballI)
      fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
      have A1: "cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 X"
        using card_1_th_11 sorry
      have Cut3143: "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4"
        using card_3_def_14 sorry
      have "cardCARD-1K1 Y c=ORDINAL1R1 omegaORDINAL1K4"
      proof-
        show "cardCARD-1K1 Y c=ORDINAL1R1 omegaORDINAL1K4"
          using A1 Cut3143 sorry
      qed
      thus "Y be countableCARD-3V4"
        using card_3_def_14 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma card_3_lm_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X & X be countableCARD-3V4 implies Y be countableCARD-3V4"
   sorry

mtheorem card_3_th_94:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be countableCARD-3V4 implies X /\\XBOOLE-0K3 Y be countableCARD-3V4"
  using card_3_lm_3 xboole_1_th_17 sorry

mtheorem card_3_th_95:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be countableCARD-3V4 implies X \\SUBSET-1K6 Y be countableCARD-3V4"
   sorry

mtheorem card_3_th_96:
" for A be  non emptyXBOOLE-0V1\<bar>countableCARD-3V4\<bar>setHIDDENM2 holds  ex f be FunctionFUNCT-2M1-of(omegaORDINAL1K4,A) st rngRELSET-1K2\<^bsub>(A)\<^esub> f =XBOOLE-0R4 A"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>countableCARD-3V4\<bar>setHIDDENM2 holds  ex tVar37 be FunctionFUNCT-2M1-of(omegaORDINAL1K4,A) st rngRELSET-1K2\<^bsub>(A)\<^esub> tVar37 =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>countableCARD-3V4\<bar>setHIDDENM2"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4"and A2: "A c=TARSKIR1 rngFUNCT-1K2 f"
      using card_3_th_93 sorry
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A3: "x inHIDDENR3 A"
      using xboole_0_def_1 sorry
    let ?F = "f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)"
    have A4: "rngFUNCT-1K2 ?F =XBOOLE-0R4 A & domRELAT-1K1 ?F =XBOOLE-0R4 omegaORDINAL1K4"
    proof-
      have "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 A & domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 omegaORDINAL1K4"
      proof-
        have A5: "f \<inverse>FUNCT-1K6 A c=TARSKIR1 omegaORDINAL1K4"
          using A1 relat_1_th_132 sorry
        have A6: "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) =XBOOLE-0R4 omegaORDINAL1K4 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 A"
          using A1 relat_1_th_61 sorry
        show "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 A & domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 omegaORDINAL1K4"
        proof-
          have cases: "omegaORDINAL1K4 =XBOOLE-0R4 f \<inverse>FUNCT-1K6 A or omegaORDINAL1K4 <>HIDDENR2 f \<inverse>FUNCT-1K6 A"
             sorry
          have case1: "omegaORDINAL1K4 =XBOOLE-0R4 f \<inverse>FUNCT-1K6 A implies rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 A & domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 omegaORDINAL1K4"
          proof(rule impI,rule conjMI)
            assume A7: "omegaORDINAL1K4 =XBOOLE-0R4 f \<inverse>FUNCT-1K6 A"
            then have A8: "omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A =XBOOLE-0R4 {}XBOOLE-0K1"
              using xboole_1_th_37 sorry
            then have "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x) =XBOOLE-0R4 {}XBOOLE-0K1"
               sorry
            then have "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)"
               sorry
            then have "?F =RELAT-1R1 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A \\/XBOOLE-0K2 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)"
              using funct_4_th_31 sorry
            then have "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) \\/XBOOLE-0K2 rngRELSET-1K2\<^bsub>({TARSKIK1 x})\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)"
              using relat_1_th_12 sorry
            also have "... = rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) \\/XBOOLE-0K2 {}XBOOLE-0K1"
              using A8 sorry
            also have "... = f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 A"
              using relat_1_th_115 sorry
            also have "... = A"
              using A2 funct_1_th_77 sorry
            finally show "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 A"
               sorry
            have "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) \\/XBOOLE-0K2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)"
              using funct_4_def_1 sorry
            also have "... = domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) \\/XBOOLE-0K2 {}XBOOLE-0K1"
              using A8 sorry
            also have "... = omegaORDINAL1K4"
              using A6 A7 sorry
            finally show "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 omegaORDINAL1K4"
               sorry
          qed
          have case2: "omegaORDINAL1K4 <>HIDDENR2 f \<inverse>FUNCT-1K6 A implies rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 A & domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 omegaORDINAL1K4"
          proof(rule impI,rule conjMI)
            assume "omegaORDINAL1K4 <>HIDDENR2 f \<inverse>FUNCT-1K6 A"
            then have A9: "omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A be  non emptyXBOOLE-0V1"
              using A5 xboole_1_th_37 sorry
            have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x) =XBOOLE-0R4 omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A"
              using funcop_1_th_13 sorry
            then have "?F =RELAT-1R1 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A \\/XBOOLE-0K2 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)"
              using A6 funct_4_th_31 xboole_1_th_89 sorry
            then have "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) \\/XBOOLE-0K2 rngRELSET-1K2\<^bsub>({TARSKIK1 x})\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)"
              using relat_1_th_12 sorry
            also have "... = rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) \\/XBOOLE-0K2 {TARSKIK1 x}"
              using A9 funcop_1_th_8 sorry
            also have "... = f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 A \\/XBOOLE-0K2 {TARSKIK1 x}"
              using relat_1_th_115 sorry
            also have "... = A \\/XBOOLE-0K2 {TARSKIK1 x}"
              using A2 funct_1_th_77 sorry
            also have "... = A"
              using A3 zfmisc_1_th_40 sorry
            finally show "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 A"
               sorry
            have "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A) \\/XBOOLE-0K2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A)\<^esub> (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)"
              using funct_4_def_1 sorry
            also have "... = omegaORDINAL1K4 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 A \\/XBOOLE-0K2 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A)"
              using A6 funcop_1_th_13 sorry
            also have "... = omegaORDINAL1K4"
              using xboole_1_th_51 sorry
            finally show "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 A +*FUNCT-4K1 (omegaORDINAL1K4 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 A -->FUNCOP-1K7 x)) =HIDDENR1 omegaORDINAL1K4"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain F where 
      [ty]:"F be FunctionFUNCT-2M1-of(omegaORDINAL1K4,A)" and FDef:"F = ?F"
      using funct_2_def_1 relset_1_th_4 sorry
    show " ex tVar37 be FunctionFUNCT-2M1-of(omegaORDINAL1K4,A) st rngRELSET-1K2\<^bsub>(A)\<^esub> tVar37 =XBOOLE-0R4 A"
    proof(rule bexI[of _ "F"])
      show "rngRELSET-1K2\<^bsub>(A)\<^esub> F =XBOOLE-0R4 A"
        using A4 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_97:
" for f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds  for g be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds  for x be ElementSUBSET-1M1-of productCARD-3K4 f holds  for y be ElementSUBSET-1M1-of productCARD-3K4 g holds x +*FUNCT-4K1 y inTARSKIR2 productCARD-3K4 (f +*FUNCT-4K1 g)"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
  fix g assume [ty]: "g be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of productCARD-3K4 f"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of productCARD-3K4 g"
  have A1: "domRELAT-1K1 x =XBOOLE-0R4 domRELAT-1K1 f"
    using card_3_th_9 sorry
  have A2: "domRELAT-1K1 y =XBOOLE-0R4 domRELAT-1K1 g"
    using card_3_th_9 sorry
  then have A3: "domRELAT-1K1 (x +*FUNCT-4K1 y) =XBOOLE-0R4 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
    using A1 funct_4_def_1 sorry
  have A4: "domRELAT-1K1 (f +*FUNCT-4K1 g) =XBOOLE-0R4 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
    using funct_4_def_1 sorry
  have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (f +*FUNCT-4K1 g) implies (x +*FUNCT-4K1 y).FUNCT-1K1 z inTARSKIR2 (f +*FUNCT-4K1 g).FUNCT-1K1 z"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    assume A5: "z inHIDDENR3 domRELAT-1K1 (f +*FUNCT-4K1 g)"
    then have "z inHIDDENR3 domRELAT-1K1 g or  not z inHIDDENR3 domRELAT-1K1 g & z inHIDDENR3 domRELAT-1K1 f"
      using A4 xboole_0_def_3 sorry
    then have "((x +*FUNCT-4K1 y).FUNCT-1K1 z =XBOOLE-0R4 x .FUNCT-1K1 z & (f +*FUNCT-4K1 g).FUNCT-1K1 z =XBOOLE-0R4 f .FUNCT-1K1 z) & x .FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z or ((x +*FUNCT-4K1 y).FUNCT-1K1 z =XBOOLE-0R4 y .FUNCT-1K1 z & (f +*FUNCT-4K1 g).FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) & y .FUNCT-1K1 z inTARSKIR2 g .FUNCT-1K1 z"
      using A1 A2 A4 A5 card_3_th_9 funct_4_def_1 sorry
    thus "(x +*FUNCT-4K1 y).FUNCT-1K1 z inTARSKIR2 (f +*FUNCT-4K1 g).FUNCT-1K1 z"
       sorry
  qed "sorry"
  thus "x +*FUNCT-4K1 y inTARSKIR2 productCARD-3K4 (f +*FUNCT-4K1 g)"
    using A3 A4 card_3_th_9 sorry
qed "sorry"

mtheorem card_3_th_98:
" for f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds  for g be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds  for x be ElementSUBSET-1M1-of productCARD-3K4 (f +*FUNCT-4K1 g) holds x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 g inTARSKIR2 productCARD-3K4 g"
proof(rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
  fix g assume [ty]: "g be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of productCARD-3K4 (f +*FUNCT-4K1 g)"
  have A1: "domRELAT-1K1 x =XBOOLE-0R4 domRELAT-1K1 (f +*FUNCT-4K1 g)"
    using card_3_th_9 sorry
  have A2: "domRELAT-1K1 (f +*FUNCT-4K1 g) =XBOOLE-0R4 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
    using funct_4_def_1 sorry
  then have A3: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 x"
    using A1 xboole_1_th_7 sorry
  have A4: "domRELAT-1K1 (x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 g) =XBOOLE-0R4 domRELAT-1K1 g"
    using A1 A2 relat_1_th_62 xboole_1_th_7 sorry
  have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 g) implies (x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 g).FUNCT-1K1 z inTARSKIR2 g .FUNCT-1K1 z"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    assume A5: "z inHIDDENR3 domRELAT-1K1 (x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 g)"
    then have A6: "(x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 g).FUNCT-1K1 z =XBOOLE-0R4 x .FUNCT-1K1 z"
      using funct_1_th_47 sorry
    have "(f +*FUNCT-4K1 g).FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z"
      using A4 A5 funct_4_th_13 sorry
    thus "(x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 g).FUNCT-1K1 z inTARSKIR2 g .FUNCT-1K1 z"
      using A1 A3 A4 A5 A6 card_3_th_9 sorry
  qed "sorry"
  thus "x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 g inTARSKIR2 productCARD-3K4 g"
    using A4 card_3_th_9 sorry
qed "sorry"

mtheorem card_3_th_99:
" for f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds  for g be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 holds f toleratesPARTFUN1R1 g implies ( for x be ElementSUBSET-1M1-of productCARD-3K4 (f +*FUNCT-4K1 g) holds x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 f inTARSKIR2 productCARD-3K4 f)"
proof(rule ballI,rule ballI,rule impI,rule ballI)
  fix f assume [ty]: "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
  fix g assume [ty]: "g be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
  assume A1: "f toleratesPARTFUN1R1 g"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of productCARD-3K4 (f +*FUNCT-4K1 g)"
  have A2: "domRELAT-1K1 x =XBOOLE-0R4 domRELAT-1K1 (f +*FUNCT-4K1 g)"
    using card_3_th_9 sorry
  have A3: "domRELAT-1K1 (f +*FUNCT-4K1 g) =XBOOLE-0R4 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
    using funct_4_def_1 sorry
  then have A4: "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 x"
    using A2 xboole_1_th_7 sorry
  have A5: "domRELAT-1K1 (x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
    using A2 A3 relat_1_th_62 xboole_1_th_7 sorry
  have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 f) implies (x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 f).FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    assume A6: "z inHIDDENR3 domRELAT-1K1 (x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 f)"
    then have A7: "(x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 f).FUNCT-1K1 z =XBOOLE-0R4 x .FUNCT-1K1 z"
      using funct_1_th_47 sorry
    have "(f +*FUNCT-4K1 g).FUNCT-1K1 z =XBOOLE-0R4 f .FUNCT-1K1 z"
      using A1 A5 A6 funct_4_th_15 sorry
    thus "(x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 f).FUNCT-1K1 z inTARSKIR2 f .FUNCT-1K1 z"
      using A2 A4 A5 A6 A7 card_3_th_9 sorry
  qed "sorry"
  thus "x  |CARD-3K11\<^bsub>(f +*FUNCT-4K1 g)\<^esub> domRELAT-1K1 f inTARSKIR2 productCARD-3K4 f"
    using A5 card_3_th_9 sorry
qed "sorry"

mtheorem card_3_th_100:
" for S be with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 S implies domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
proof-
  have " for S be with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 S implies domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
  proof(rule ballI,rule ballI,rule impI)
    fix S assume [ty]: "S be with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f inTARSKIR2 S"
    have "domRELAT-1K1 f =HIDDENR1 DOMCARD-3K9 S"
      using A1 card_3_lm_2 sorry
    also have "... = domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
      using card_3_def_12 sorry
    finally show "domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_101:
" for S be functionalFUNCT-1V6\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for i be setHIDDENM2 holds f inTARSKIR2 S & i inTARSKIR2 domRELAT-1K1 (product\<inverse>CARD-3K10 S) implies f .FUNCT-1K1 i inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
proof-
  have " for S be functionalFUNCT-1V6\<bar>setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for i be setHIDDENM2 holds F inTARSKIR2 S implies (i inTARSKIR2 domRELAT-1K1 (product\<inverse>CARD-3K10 S) implies F .FUNCT-1K1 i inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix S assume [ty]: "S be functionalFUNCT-1V6\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix i assume [ty]: "i be setHIDDENM2"
    assume A1: "F inTARSKIR2 S"
    assume "i inTARSKIR2 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
    then have "product\<inverse>CARD-3K10 S .FUNCT-1K1 i =XBOOLE-0R4 {f .FUNCT-1K1 i where f be ElementSUBSET-1M1-of S :  True  }"
      using A1 card_3_th_74 sorry
    thus "F .FUNCT-1K1 i inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_102:
" for S be with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for i be setHIDDENM2 holds f inTARSKIR2 S & i inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 i inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix S assume [ty]: "S be with-common-domainCARD-3V2\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix i assume [ty]: "i be setHIDDENM2"
  assume A1: "f inTARSKIR2 S"
    and A2: "i inTARSKIR2 domRELAT-1K1 f"
  have "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (product\<inverse>CARD-3K10 S)"
    using A1 card_3_th_100 sorry
  thus "f .FUNCT-1K1 i inTARSKIR2 product\<inverse>CARD-3K10 S .FUNCT-1K1 i"
    using A1 A2 card_3_th_101 sorry
qed "sorry"

mtheorem card_3_cl_23:
  mlet "X be with-common-domainCARD-3V2\<bar>setHIDDENM2"
"cluster note-that with-common-domainCARD-3V2 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be with-common-domainCARD-3V2"
    using card_3_def_10 sorry
qed "sorry"

mdef card_3_def_16 ("projCARD-3K12'( _ , _ ')" [0,0]228 ) where
  mlet "f be FunctionFUNCT-1M1", "x be objectHIDDENM1"
"func projCARD-3K12(f,x) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 productCARD-3K4 f & ( for y be FunctionFUNCT-1M1 holds y inTARSKIR2 domRELAT-1K1 it implies it .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 productCARD-3K4 f & ( for y be FunctionFUNCT-1M1 holds y inTARSKIR2 domRELAT-1K1 it implies it .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x)"
    proof-
      have " ex tVar39 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar39 =XBOOLE-0R4 productCARD-3K4 f & ( for y be FunctionFUNCT-1M1 holds  not (y inTARSKIR2 domRELAT-1K1 tVar39 &  not tVar39 .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for g be FunctionFUNCT-1M1 holds Lamb1 =HIDDENR1 g implies Lamb2 =HIDDENR1 g .FUNCT-1K1 x"
        have A1: " for q be objectHIDDENM1 holds q inHIDDENR3 productCARD-3K4 f implies ( ex y be objectHIDDENM1 st  for g be FunctionFUNCT-1M1 holds q =HIDDENR1 g implies y =HIDDENR1 g .FUNCT-1K1 x)"
        proof(rule ballI,rule impI)
          fix q assume [ty]: "q be objectHIDDENM1"
          assume "q inHIDDENR3 productCARD-3K4 f"
          then obtain q1 where 
            [ty]:"q1 be FunctionFUNCT-1M1" and q1Def:"q1 = q"
             sorry
          obtain y where 
            [ty]:"y be objectHIDDENM1" and yDef:"y = q1 .FUNCT-1K1 x"
             sorry
          show " ex y be objectHIDDENM1 st  for g be FunctionFUNCT-1M1 holds q =HIDDENR1 g implies y =HIDDENR1 g .FUNCT-1K1 x"
          proof(rule bexI[of _ "y"])
            show " for g be FunctionFUNCT-1M1 holds q =HIDDENR1 g implies y =HIDDENR1 g .FUNCT-1K1 x"
               sorry
          qed "sorry"
        qed "sorry"
        obtain F where
          [ty]:"F be FunctionFUNCT-1M1" and 
          A2: "domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 f & ( for a be objectHIDDENM1 holds a inHIDDENR3 productCARD-3K4 f implies ?P(a,F .FUNCT-1K1 a))"
          using classes1_sch_1 A1 sorry
        show " ex tVar39 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar39 =XBOOLE-0R4 productCARD-3K4 f & ( for y be FunctionFUNCT-1M1 holds  not (y inTARSKIR2 domRELAT-1K1 tVar39 &  not tVar39 .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x))"
        proof(rule bexI[of _ "F"])
          show "domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 f & ( for y be FunctionFUNCT-1M1 holds  not (y inTARSKIR2 domRELAT-1K1 F &  not F .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x))"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 productCARD-3K4 f & ( for y be FunctionFUNCT-1M1 holds y inTARSKIR2 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 productCARD-3K4 f & ( for y be FunctionFUNCT-1M1 holds y inTARSKIR2 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
    proof-
      have " for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 f & (( for y be FunctionFUNCT-1M1 holds y inTARSKIR2 domRELAT-1K1 F implies F .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x) & (domRELAT-1K1 G =XBOOLE-0R4 productCARD-3K4 f & ( for y be FunctionFUNCT-1M1 holds y inTARSKIR2 domRELAT-1K1 G implies G .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x))) implies F =HIDDENR1 G"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix F assume [ty]: "F be FunctionFUNCT-1M1"
        fix G assume [ty]: "G be FunctionFUNCT-1M1"
        assume A3: "domRELAT-1K1 F =XBOOLE-0R4 productCARD-3K4 f"
          and A4: " for y be FunctionFUNCT-1M1 holds y inTARSKIR2 domRELAT-1K1 F implies F .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x"
          and A5: "domRELAT-1K1 G =XBOOLE-0R4 productCARD-3K4 f"
          and A6: " for y be FunctionFUNCT-1M1 holds y inTARSKIR2 domRELAT-1K1 G implies G .FUNCT-1K1 y =XBOOLE-0R4 y .FUNCT-1K1 x"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 productCARD-3K4 f implies F .FUNCT-1K1 y =HIDDENR1 G .FUNCT-1K1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A7: "y inHIDDENR3 productCARD-3K4 f"
          then obtain x1 where 
            [ty]:"x1 be FunctionFUNCT-1M1" and x1Def:"x1 = y"
             sorry
          have "F .FUNCT-1K1 y =HIDDENR1 x1 .FUNCT-1K1 x"
            using A3 A4 A7 sorry
          also have "... = G .FUNCT-1K1 y"
            using A5 A6 A7 sorry
          finally show "F .FUNCT-1K1 y =HIDDENR1 G .FUNCT-1K1 y"
             sorry
        qed "sorry"
        thus "F =HIDDENR1 G"
          using A3 A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem card_3_cl_24:
  mlet "f be FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster projCARD-3K12(f,x) as-term-is productCARD-3K4 f -definedRELAT-1V4"
proof
(*coherence*)
  show "projCARD-3K12(f,x) be productCARD-3K4 f -definedRELAT-1V4"
    using card_3_def_16 sorry
qed "sorry"

mtheorem card_3_cl_25:
  mlet "f be FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster projCARD-3K12(f,x) as-term-is totalPARTFUN1V1\<^bsub>(productCARD-3K4 f)\<^esub>"
proof
(*coherence*)
  show "projCARD-3K12(f,x) be totalPARTFUN1V1\<^bsub>(productCARD-3K4 f)\<^esub>"
    using card_3_def_16 sorry
qed "sorry"

mtheorem card_3_cl_26:
  mlet "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
"cluster note-that f -compatibleFUNCT-1V7 for ElementSUBSET-1M1-of productCARD-3K4 f"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of productCARD-3K4 f holds it be f -compatibleFUNCT-1V7"
  proof-
    have " for e be ElementSUBSET-1M1-of productCARD-3K4 f holds e be f -compatibleFUNCT-1V7"
    proof(rule ballI)
      fix e assume [ty]: "e be ElementSUBSET-1M1-of productCARD-3K4 f"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 e implies e .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 e"
        then have "x inHIDDENR3 domRELAT-1K1 f"
          using card_3_th_9 sorry
        thus "e .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
          using card_3_th_9 sorry
      qed "sorry"
      thus "e be f -compatibleFUNCT-1V7"
        using funct_1_def_14 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_cl_27:
  mlet "I be setHIDDENM2", "f be I -definedRELAT-1V4\<bar>non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
"cluster note-that I -definedRELAT-1V4 for ElementSUBSET-1M1-of productCARD-3K4 f"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of productCARD-3K4 f holds it be I -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem card_3_cl_28:
  mlet "f be FunctionFUNCT-1M1"
"cluster note-that f -compatibleFUNCT-1V7 for ElementSUBSET-1M1-of sproductCARD-3K8 f"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of sproductCARD-3K8 f holds it be f -compatibleFUNCT-1V7"
    using card_3_th_49 sorry
qed "sorry"

mtheorem card_3_cl_29:
  mlet "I be setHIDDENM2", "f be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
"cluster note-that I -definedRELAT-1V4 for ElementSUBSET-1M1-of sproductCARD-3K8 f"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of sproductCARD-3K8 f holds it be I -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem card_3_cl_30:
  mlet "I be setHIDDENM2", "f be totalPARTFUN1V1\<^bsub>(I)\<^esub>\<bar>I -definedRELAT-1V4\<bar>non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
"cluster note-that totalPARTFUN1V1\<^bsub>(I)\<^esub> for ElementSUBSET-1M1-of productCARD-3K4 f"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of productCARD-3K4 f holds it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
  proof-
    have " for e be ElementSUBSET-1M1-of productCARD-3K4 f holds e be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
    proof(rule ballI)
      fix e assume [ty]: "e be ElementSUBSET-1M1-of productCARD-3K4 f"
      have "domRELSET-1K1\<^bsub>(I)\<^esub> e =HIDDENR1 I"
      proof-
        have "domRELSET-1K1\<^bsub>(I)\<^esub> e =HIDDENR1 domRELSET-1K1\<^bsub>(I)\<^esub> f"
          using card_3_th_9 sorry
        also have "... = I"
          using partfun1_def_2 sorry
        finally show "domRELSET-1K1\<^bsub>(I)\<^esub> e =HIDDENR1 I"
           sorry
      qed
      thus "e be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
        using partfun1_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_3_th_103:
" for I be setHIDDENM2 holds  for f be non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for p be f -compatibleFUNCT-1V7\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds p inTARSKIR2 sproductCARD-3K8 f"
proof(rule ballI,rule ballI,rule ballI)
  fix I assume [ty]: "I be setHIDDENM2"
  fix f assume [ty]: "f be non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
  fix p assume [ty]: "p be f -compatibleFUNCT-1V7\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
  have A1: "domRELSET-1K1\<^bsub>(I)\<^esub> p c=TARSKIR1 domRELSET-1K1\<^bsub>(I)\<^esub> f"
    using funct_1_th_105 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(I)\<^esub> p implies p .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    using funct_1_def_14 sorry
  thus "p inTARSKIR2 sproductCARD-3K8 f"
    using A1 card_3_def_9 sorry
qed "sorry"

mtheorem card_3_th_104:
" for I be setHIDDENM2 holds  for f be non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for p be f -compatibleFUNCT-1V7\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  ex s be ElementSUBSET-1M1-of productCARD-3K4 f st p c=RELAT-1R2 s"
proof-
  have " for I be setHIDDENM2 holds  for f be non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for p be f -compatibleFUNCT-1V7\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  ex tVar40 be ElementSUBSET-1M1-of productCARD-3K4 f st p c=RELAT-1R2 tVar40"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix f assume [ty]: "f be non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    fix p assume [ty]: "p be f -compatibleFUNCT-1V7\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    have 
      [ty]:"p be ElementSUBSET-1M1-of sproductCARD-3K8 f"
      using card_3_th_103 sorry
    let ?h = "the ElementSUBSET-1M1-of productCARD-3K4 f"
    obtain s where 
      [ty]:"s be ElementSUBSET-1M1-of productCARD-3K4 f" and sDef:"s = ?h +*FUNCT-4K1 p"
      using card_3_th_53 sorry
    show " ex tVar40 be ElementSUBSET-1M1-of productCARD-3K4 f st p c=RELAT-1R2 tVar40"
    proof(rule bexI[of _ "s"])
      show "p c=RELAT-1R2 s"
        using funct_4_th_25 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_cl_31:
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2", "a be setHIDDENM2"
"cluster X -->FUNCOP-1K7 a as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "X -->FUNCOP-1K7 a be infiniteFINSET-1V2"
     sorry
qed "sorry"

mtheorem card_3_cl_32:
"cluster infiniteFINSET-1V2 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be infiniteFINSET-1V2"
  proof-
    have " ex tVar41 be FunctionFUNCT-1M1 st  not tVar41 be infiniteFINSET-1V2"
    proof-
      show " ex tVar41 be FunctionFUNCT-1M1 st  not tVar41 be infiniteFINSET-1V2"
      proof(rule bexI[of _ "omegaORDINAL1K4 -->FUNCOP-1K7 0ORDINAL1K5"])
        show " not omegaORDINAL1K4 -->FUNCOP-1K7 0ORDINAL1K5 be infiniteFINSET-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma card_3_lm_4:
" for R be RelationRELAT-1M1 holds fieldRELAT-1K3 R be finiteFINSET-1V1 implies R be finiteFINSET-1V1"
proof-
  have " for R be RelationRELAT-1M1 holds fieldRELAT-1K3 R be finiteFINSET-1V1 implies R be finiteFINSET-1V1"
  proof(rule ballI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "fieldRELAT-1K3 R be finiteFINSET-1V1"
    then obtain A where 
      [ty]:"A be finiteFINSET-1V1\<bar>setHIDDENM2" and ADef:"A = fieldRELAT-1K3 R"
       sorry
    have "R c=RELAT-1R2 [:ZFMISC-1K2 A,A :]"
    proof-
      have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 y,z ] inHIDDENR3 R implies [TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 A,A :]"
      proof(rule ballI,rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A1: "[TARSKIK4 y,z ] inHIDDENR3 R"
        then have A2: "z inHIDDENR3 fieldRELAT-1K3 R"
          using relat_1_th_15 sorry
        have "y inHIDDENR3 fieldRELAT-1K3 R"
          using A1 relat_1_th_15 sorry
        thus "[TARSKIK4 y,z ] inHIDDENR3 [:ZFMISC-1K2 A,A :]"
          using A2 zfmisc_1_th_87 sorry
      qed "sorry"
      thus "R c=RELAT-1R2 [:ZFMISC-1K2 A,A :]"
        using relat_1_def_3 sorry
    qed
    thus "R be finiteFINSET-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_cl_33:
  mlet "R be infiniteFINSET-1V2\<bar>RelationRELAT-1M1"
"cluster fieldRELAT-1K3 R as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "fieldRELAT-1K3 R be infiniteFINSET-1V2"
    using card_3_lm_4 sorry
qed "sorry"

mtheorem card_3_cl_34:
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"cluster RelInclWELLORD2K1 X as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "RelInclWELLORD2K1 X be infiniteFINSET-1V2"
    using card_1_th_63 sorry
qed "sorry"

mtheorem card_3_th_105:
" for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds (R,S)are-isomorphicWELLORD1R4 & R be finiteFINSET-1V1 implies S be finiteFINSET-1V1"
proof-
  have " for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds  not (((R,S)are-isomorphicWELLORD1R4 & R be finiteFINSET-1V1) &  not S be finiteFINSET-1V1)"
  proof(rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    have "( ex F be FunctionFUNCT-1M1 st F is-isomorphism-ofWELLORD1R3(R,S)) implies (R be finiteFINSET-1V1 implies S be finiteFINSET-1V1)"
    proof(rule impI,rule impI)
      assume Given: " ex F be FunctionFUNCT-1M1 st F is-isomorphism-ofWELLORD1R3(R,S)"
      then obtain F where
        [ty]:"F be FunctionFUNCT-1M1" and 
        A1: "F is-isomorphism-ofWELLORD1R3(R,S)"
         sorry
      assume "R be finiteFINSET-1V1"
      then have "fieldRELAT-1K3 R be finiteFINSET-1V1"
         sorry
      then have "domRELAT-1K1 F be finiteFINSET-1V1"
        using A1 sorry
      then have "rngFUNCT-1K2 F be finiteFINSET-1V1"
        using finset_1_th_8 sorry
      then have "fieldRELAT-1K3 S be finiteFINSET-1V1"
        using A1 sorry
      thus "S be finiteFINSET-1V1"
         sorry
    qed
    thus " not (((R,S)are-isomorphicWELLORD1R4 & R be finiteFINSET-1V1) &  not S be finiteFINSET-1V1)"
      using wellord1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_3_th_106:
"product\<inverse>CARD-3K10 {TARSKIK1 {}XBOOLE-0K1 } =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have "domRELAT-1K1 (product\<inverse>CARD-3K10 {TARSKIK1 {}XBOOLE-0K1 }) =HIDDENR1 DOMCARD-3K9 {TARSKIK1 {}XBOOLE-0K1 }"
    using card_3_def_12 sorry
  also have "... = {}XBOOLE-0K1"
    using card_3_th_72 sorry
  finally have "domRELAT-1K1 (product\<inverse>CARD-3K10 {TARSKIK1 {}XBOOLE-0K1 }) =HIDDENR1 {}XBOOLE-0K1"
     sorry
  thus "product\<inverse>CARD-3K10 {TARSKIK1 {}XBOOLE-0K1 } =FUNCT-1R1 {}XBOOLE-0K1"
     sorry
qed

mtheorem card_3_th_107:
" for I be setHIDDENM2 holds  for f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for s be f -compatibleFUNCT-1V7\<bar>ManySortedSetPBOOLEM1-of I holds s inTARSKIR2 productCARD-3K4 f"
proof(rule ballI,rule ballI,rule ballI)
  fix I assume [ty]: "I be setHIDDENM2"
  fix f assume [ty]: "f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
  fix s assume [ty]: "s be f -compatibleFUNCT-1V7\<bar>ManySortedSetPBOOLEM1-of I"
  have A1: "domRELSET-1K1\<^bsub>(I)\<^esub> s =HIDDENR1 I"
    using partfun1_def_2 sorry
  also have "... = domRELSET-1K1\<^bsub>(I)\<^esub> f"
    using partfun1_def_2 sorry
  finally have "domRELSET-1K1\<^bsub>(I)\<^esub> s =HIDDENR1 domRELSET-1K1\<^bsub>(I)\<^esub> f"
     sorry
  then have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(I)\<^esub> f implies s .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    using funct_1_def_14 sorry
  thus "s inTARSKIR2 productCARD-3K4 f"
    using A1 card_3_th_9 sorry
qed "sorry"

mtheorem card_3_cl_35:
  mlet "I be setHIDDENM2", "f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
"cluster note-that totalPARTFUN1V1\<^bsub>(I)\<^esub> for ElementSUBSET-1M1-of productCARD-3K4 f"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of productCARD-3K4 f holds it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
     sorry
qed "sorry"

mdef card_3_def_17 ("downCARD-3K13\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,164]164 ) where
  mlet "I be setHIDDENM2", "f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I", "M be f -compatibleFUNCT-1V7\<bar>ManySortedSetPBOOLEM1-of I"
"func downCARD-3K13\<^bsub>(I,f)\<^esub> M \<rightarrow> ElementSUBSET-1M1-of productCARD-3K4 f equals
  M"
proof-
  (*coherence*)
    show "M be ElementSUBSET-1M1-of productCARD-3K4 f"
      using card_3_th_107 sorry
qed "sorry"

mtheorem card_3_th_108:
" for X be functionalFUNCT-1V6\<bar>with-common-domainCARD-3V2\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f inTARSKIR2 X implies domRELAT-1K1 f =XBOOLE-0R4 DOMCARD-3K9 X"
  using card_3_lm_2 sorry

mtheorem card_3_th_109:
" for x be objectHIDDENM1 holds  for X be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2 holds ( for f be FunctionFUNCT-1M1 holds f inTARSKIR2 X implies x inHIDDENR3 domRELAT-1K1 f) implies x inHIDDENR3 DOMCARD-3K9 X"
proof(rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be objectHIDDENM1"
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2"
  assume A1: " for f be FunctionFUNCT-1M1 holds f inTARSKIR2 X implies x inHIDDENR3 domRELAT-1K1 f"
  let ?A = "{domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  }"
  obtain Y where
    [ty]:"Y be objectHIDDENM1" and 
    A2: "Y inHIDDENR3 X"
    using xboole_0_def_1 sorry
  have 
    [ty]:"Y be FunctionFUNCT-1M1"
    using A2 sorry
  have A3: "domRELAT-1K1 Y inTARSKIR2 ?A"
    using A2 sorry
  have " for Y be setHIDDENM2 holds Y inTARSKIR2 ?A implies x inHIDDENR3 Y"
  proof-
    have " for Y be setHIDDENM2 holds Y inTARSKIR2 {domRELAT-1K1 f where f be ElementSUBSET-1M1-of X :  True  } implies x inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix Y assume [ty]: "Y be setHIDDENM2"
      assume "Y inTARSKIR2 ?A"
      then have " ex f be ElementSUBSET-1M1-of X st Y =XBOOLE-0R4 domRELAT-1K1 f"
         sorry
      thus "x inHIDDENR3 Y"
        using A1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "x inHIDDENR3 DOMCARD-3K9 X"
    using A3 setfam_1_def_1 sorry
qed "sorry"

theorem card_3_sch_3:
  fixes Xf0 Ff1 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for x be setHIDDENM2 holds x inTARSKIR2 Xf0 implies ( for y be setHIDDENM2 holds y inTARSKIR2 f .FUNCT-1K1 x iff y inTARSKIR2 Ff1(x) & Pp2(x,y)))"
  proof-
    have " ex tVar42 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar42 =XBOOLE-0R4 Xf0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Xf0 &  not ( for y be setHIDDENM2 holds  not (y inTARSKIR2 tVar42 .FUNCT-1K1 x &  not (y inTARSKIR2 Ff1(x) & Pp2(x,y))) &  not ((y inTARSKIR2 Ff1(x) & Pp2(x,y)) &  not y inTARSKIR2 tVar42 .FUNCT-1K1 x))))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Xf0"and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( for y be objectHIDDENM1 holds y inHIDDENR3 f .FUNCT-1K1 x iff y inHIDDENR3 Ff1(x) & Pp2(x,y))"
        using card_3_sch_2 sorry
      show " ex tVar42 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar42 =XBOOLE-0R4 Xf0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Xf0 &  not ( for y be setHIDDENM2 holds  not (y inTARSKIR2 tVar42 .FUNCT-1K1 x &  not (y inTARSKIR2 Ff1(x) & Pp2(x,y))) &  not ((y inTARSKIR2 Ff1(x) & Pp2(x,y)) &  not y inTARSKIR2 tVar42 .FUNCT-1K1 x))))"
      proof(rule bexI[of _ "f"])
        show "domRELAT-1K1 f =XBOOLE-0R4 Xf0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Xf0 &  not ( for y be setHIDDENM2 holds  not (y inTARSKIR2 f .FUNCT-1K1 x &  not (y inTARSKIR2 Ff1(x) & Pp2(x,y))) &  not ((y inTARSKIR2 Ff1(x) & Pp2(x,y)) &  not y inTARSKIR2 f .FUNCT-1K1 x))))"
          using A1 A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

syntax CARD_3V6 :: "Ty" ("uncountableCARD-3V6" 70)
translations "uncountableCARD-3V6" \<rightharpoonup> " non countableCARD-3V4"

mtheorem card_3_cl_36:
"cluster uncountableCARD-3V6 also-is  non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be uncountableCARD-3V6 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

end
