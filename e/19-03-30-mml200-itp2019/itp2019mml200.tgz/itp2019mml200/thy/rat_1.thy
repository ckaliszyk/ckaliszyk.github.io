theory rat_1
  imports arytm_3 int_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x for "objectHIDDENM1"
reserve a, b for "RealXREAL-0M1"
reserve k, k1, i1, j1, w for "NatNAT-1M1"
reserve m, m1, n, n1 for "IntegerINT-1M1"
mlemma rat_1_lm_1:
"omegaORDINAL1K4 c=TARSKIR1 (({[TARSKIK4 c,d ] where c be ElementSUBSET-1M1-of omegaORDINAL1K4, d be ElementSUBSET-1M1-of omegaORDINAL1K4 : (c,d)are-coprimeARYTM-3R1 & d <>HIDDENR2 {}ARYTM-3K12 })\\SUBSET-1K6 ({[TARSKIK4 k,\<one>\<^sub>M ] where k be ElementSUBSET-1M1-of omegaORDINAL1K4 :  True  }))\\/XBOOLE-0K2 omegaORDINAL1K4"
  using xboole_1_th_7 sorry

mlemma rat_1_lm_2:
" for i1 be NatNAT-1M1 holds  for j1 be NatNAT-1M1 holds quotientARYTM-3K9(i1,j1) =XBOOLE-0R4 i1 /XCMPLX-0K7 j1"
proof-
  have " for i1 be NatNAT-1M1 holds  for j1 be NatNAT-1M1 holds quotientARYTM-3K9(i1,j1) =HIDDENR1 i1 /XCMPLX-0K7 j1"
  proof(rule ballI,rule ballI)
    fix i1 assume [ty]: "i1 be NatNAT-1M1"
    fix j1 assume [ty]: "j1 be NatNAT-1M1"
    let ?x = "quotientARYTM-3K9(i1,j1)"
    show "quotientARYTM-3K9(i1,j1) =HIDDENR1 i1 /XCMPLX-0K7 j1"
    proof-
      have cases: "j1 =XBOOLE-0R4 {}ARYTM-3K12 or j1 <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "j1 =XBOOLE-0R4 {}ARYTM-3K12 implies quotientARYTM-3K9(i1,j1) =HIDDENR1 i1 /XCMPLX-0K7 j1"
      proof(rule impI)
        assume A1: "j1 =XBOOLE-0R4 {}ARYTM-3K12"
        then have "quotientARYTM-3K9(i1,j1) =HIDDENR1 {}ARYTM-3K12"
          using arytm_3_def_10 sorry
        also have "... = i1 /XCMPLX-0K7 j1"
          using A1 sorry
        finally show "quotientARYTM-3K9(i1,j1) =HIDDENR1 i1 /XCMPLX-0K7 j1"
           sorry
      qed
      have case2: "j1 <>HIDDENR2 0NUMBERSK6 implies quotientARYTM-3K9(i1,j1) =XBOOLE-0R4 i1 /XCMPLX-0K7 j1"
      proof(rule impI)
        assume A2: "j1 <>HIDDENR2 0NUMBERSK6"
        have "+ARYTM-0K1(InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),oppARYTM-0K3 (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))) =XBOOLE-0R4 0NUMBERSK6"
          using arytm_0_def_3 sorry
        then have A3: "oppARYTM-0K3 (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)) =XBOOLE-0R4 0NUMBERSK6"
          using arytm_0_th_11 sorry
        obtain y where 
          [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and yDef:"y = \<one>\<^sub>M"
          using numbers_th_19 sorry
        have "j1 *XCMPLX-0K3 j1 \<inverse>XCMPLX-0K5 =XBOOLE-0R4 \<one>\<^sub>M"
          using A2 xcmplx_0_def_7 sorry
        then obtain x1 x2 y1 y2 where
          [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A4: "j1 =XBOOLE-0R4 [*ARYTM-0K5 x1,x2 *]"and A5: "j1 \<inverse>XCMPLX-0K5 =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A6: "y =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
          using xcmplx_0_def_5 sorry
        have A7: "j1 inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have "+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) =XBOOLE-0R4 0NUMBERSK6"
          using A6 arytm_0_th_24 sorry
        then have A8: "\<one>\<^sub>M =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)))"
          using A6 arytm_0_def_5 sorry
        also have "... = +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)))"
          using A4 arytm_0_th_12 arytm_0_th_24 A7 sorry
        also have "... =  *ARYTM-0K2(x1,y1)"
          using A3 arytm_0_th_11 sorry
        finally have "\<one>\<^sub>M =HIDDENR1  *ARYTM-0K2(x1,y1)"
           sorry
        have "j1 inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "x2 =XBOOLE-0R4 0NUMBERSK6"
          using A4 arytm_0_th_24 sorry
        then have A9: "j1 =XBOOLE-0R4 x1"
          using A4 arytm_0_def_5 sorry
        then have "x1 inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_12 sorry
        then obtain xx where 
          [ty]:"xx be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and xxDef:"xx = x1"
          using rat_1_lm_1 sorry
        obtain yy where
          [ty]:"yy be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A10: "xx *'ARYTM-3K11 yy =XBOOLE-0R4 oneARYTM-3K13"
          using A2 A9 arytm_3_th_54 sorry
        obtain xx1 yy1 where 
          [ty]:"xx1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and xx1Def:"xx1 = xx" and
          [ty]:"yy1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and yy1Def:"yy1 = yy"
          using arytm_2_th_1 sorry
        have A11: " ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (xx1 =XBOOLE-0R4 x9 & yy1 =XBOOLE-0R4 y9) & xx1 *'ARYTM-2K8 yy1 =XBOOLE-0R4 x9 *'ARYTM-3K11 y9"
          using arytm_2_th_21 sorry
        have 
          [ty]:"xx1 be ElementSUBSET-1M1-of REALNUMBERSK2" and
          [ty]:"yy1 be ElementSUBSET-1M1-of REALNUMBERSK2"
          using arytm_0_th_1 sorry
        have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (xx1 =XBOOLE-0R4 x9 & yy1 =XBOOLE-0R4 y9) &  *ARYTM-0K2(xx1,yy1) =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
          using arytm_0_def_2 sorry
        then have A12: "yy =XBOOLE-0R4 y1"
          using A2 A9 A8 A10 A11 arytm_0_th_18 sorry
        then have A13: "y1 inTARSKIR2 RAT+ARYTM-3K5"
           sorry
        have "j1 \<inverse>XCMPLX-0K5 inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "y2 =XBOOLE-0R4 0NUMBERSK6"
          using A5 arytm_0_th_24 sorry
        then have A14: "j1 \<inverse>XCMPLX-0K5 =HIDDENR1 y1"
          using A5 arytm_0_def_5 sorry
        have A15: "j1 inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_12 sorry
        then obtain a b where 
          [ty]:"a be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and aDef:"a = ?x" and
          [ty]:"b be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and bDef:"b = j1"
          using rat_1_lm_1 sorry
        obtain x91 x92 y91 y92 where
          [ty]:"x91 be ElementSUBSET-1M1-of REALNUMBERSK2" "x92 be ElementSUBSET-1M1-of REALNUMBERSK2" "y91 be ElementSUBSET-1M1-of REALNUMBERSK2" "y92 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A16: "i1 =XBOOLE-0R4 [*ARYTM-0K5 x91,x92 *]"and A17: "j1 \<inverse>XCMPLX-0K5 =HIDDENR1 [*ARYTM-0K5 y91,y92 *]"and A18: "i1 *XCMPLX-0K3 j1 \<inverse>XCMPLX-0K5 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x91,y91),oppARYTM-0K3 ( *ARYTM-0K2(x92,y92))),+ARYTM-0K1( *ARYTM-0K2(x91,y92), *ARYTM-0K2(x92,y91)) *]"
          using xcmplx_0_def_5 sorry
        have "i1 *XCMPLX-0K3 j1 \<inverse>XCMPLX-0K5 inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have A19: "+ARYTM-0K1( *ARYTM-0K2(x91,y92), *ARYTM-0K2(x92,y91)) =XBOOLE-0R4 0NUMBERSK6"
          using A18 arytm_0_th_24 sorry
        have "x1 inTARSKIR2 omegaORDINAL1K4"
          using A9 ordinal1_def_12 sorry
        then obtain x19 y19 where
          [ty]:"x19 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y19 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A20: "x1 =XBOOLE-0R4 x19"and A21: "y1 =XBOOLE-0R4 y19"and A22: " *ARYTM-0K2(x1,y1) =XBOOLE-0R4 x19 *'ARYTM-2K8 y19"
          using A13 arytm_0_def_2 arytm_2_th_1 arytm_2_th_2 sorry
        have A23: " ex x199 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y199 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x19 =XBOOLE-0R4 x199 & y19 =XBOOLE-0R4 y199) & x19 *'ARYTM-2K8 y19 =XBOOLE-0R4 x199 *'ARYTM-3K11 y199"
          using A9 A12 A15 A20 A21 rat_1_lm_1 arytm_2_th_21 sorry
        have "j1 \<inverse>XCMPLX-0K5 inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have A24: "y92 =XBOOLE-0R4 0NUMBERSK6"
          using A17 arytm_0_th_24 sorry
        then have "j1 \<inverse>XCMPLX-0K5 =HIDDENR1 y91"
          using A17 arytm_0_def_5 sorry
        then have A25: "i1 *XCMPLX-0K3 j1 \<inverse>XCMPLX-0K5 =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x91,y1),oppARYTM-0K3 ( *ARYTM-0K2(x92,InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))))"
          using A14 A18 A24 A19 arytm_0_def_5 sorry
        also have "... = +ARYTM-0K1( *ARYTM-0K2(x91,y1),InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))"
          using A3 arytm_0_th_12 sorry
        also have "... =  *ARYTM-0K2(x91,y1)"
          using arytm_0_th_11 sorry
        finally have "i1 *XCMPLX-0K3 j1 \<inverse>XCMPLX-0K5 =HIDDENR1  *ARYTM-0K2(x91,y1)"
           sorry
        have "i1 inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "x92 =XBOOLE-0R4 0NUMBERSK6"
          using A16 arytm_0_th_24 sorry
        then have A26: "i1 =XBOOLE-0R4 x91"
          using A16 arytm_0_def_5 sorry
        then have A27: "x91 inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_12 sorry
        then have "x91 inTARSKIR2 RAT+ARYTM-3K5"
          using rat_1_lm_1 sorry
        then obtain x9 y9 where
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A28: "x91 =XBOOLE-0R4 x9"and A29: "y1 =XBOOLE-0R4 y9"and A30: "i1 *XCMPLX-0K3 j1 \<inverse>XCMPLX-0K5 =XBOOLE-0R4 x9 *'ARYTM-2K8 y9"
          using A25 A13 arytm_0_def_2 arytm_2_th_1 sorry
        obtain x99 y99 where
          [ty]:"x99 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "y99 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A31: "x9 =XBOOLE-0R4 x99"and A32: "y9 =XBOOLE-0R4 y99"and A33: "i1 *XCMPLX-0K3 j1 \<inverse>XCMPLX-0K5 =XBOOLE-0R4 x99 *'ARYTM-3K11 y99"
          using A27 A12 A28 A29 A30 rat_1_lm_1 arytm_2_th_21 sorry
        have "a *'ARYTM-3K11 b =HIDDENR1 (quotientARYTM-3K9(i1,j1))*'ARYTM-3K11 (quotientARYTM-3K9(j1,oneARYTM-3K13))"
          using arytm_3_th_40 sorry
        also have "... = quotientARYTM-3K9(i1 *^ORDINAL3K9 j1,j1 *^ORDINAL3K9 oneARYTM-3K13)"
          using arytm_3_th_49 sorry
        also have "... = (quotientARYTM-3K9(i1,oneARYTM-3K13))*'ARYTM-3K11 (quotientARYTM-3K9(j1,j1))"
          using arytm_3_th_49 sorry
        also have "... = (quotientARYTM-3K9(i1,oneARYTM-3K13))*'ARYTM-3K11 (oneARYTM-3K13)"
          using A2 arytm_3_th_41 sorry
        also have "... = quotientARYTM-3K9(i1,oneARYTM-3K13)"
          using arytm_3_th_53 sorry
        also have "... = i1"
          using arytm_3_th_40 sorry
        also have "... = x99 *'ARYTM-3K11 (oneARYTM-3K13)"
          using A26 A28 A31 arytm_3_th_53 sorry
        also have "... = (x99 *'ARYTM-3K11 y99)*'ARYTM-3K11 b"
          using A9 A8 A29 A32 A20 A21 A22 A23 arytm_3_th_52 sorry
        finally have "a *'ARYTM-3K11 b =HIDDENR1 (x99 *'ARYTM-3K11 y99)*'ARYTM-3K11 b"
           sorry
        thus "quotientARYTM-3K9(i1,j1) =XBOOLE-0R4 i1 /XCMPLX-0K7 j1"
          using A2 A33 arytm_3_th_56 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rat_1_lm_3:
" for a be RealXREAL-0M1 holds  for Z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds Z9 =XBOOLE-0R4 0NUMBERSK6 implies ( for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x9 =HIDDENR1 a implies Z9 -ARYTM-1K2 x9 =HIDDENR1 -XCMPLX-0K4 a)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds Z9 =XBOOLE-0R4 0NUMBERSK6 implies ( for xx be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds xx =HIDDENR1 a implies Z9 -ARYTM-1K2 xx =HIDDENR1 -XCMPLX-0K4 a)"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z9 assume [ty]: "Z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A0: "Z9 =XBOOLE-0R4 0NUMBERSK6"
    fix xx assume [ty]: "xx be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "xx =HIDDENR1 a"
    show "Z9 -ARYTM-1K2 xx =HIDDENR1 -XCMPLX-0K4 a"
    proof-
      have cases: "xx =XBOOLE-0R4 0NUMBERSK6 or xx <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "xx =XBOOLE-0R4 0NUMBERSK6 implies Z9 -ARYTM-1K2 xx =HIDDENR1 -XCMPLX-0K4 a"
      proof(rule impI)
        assume "xx =XBOOLE-0R4 0NUMBERSK6"
        thus "Z9 -ARYTM-1K2 xx =HIDDENR1 -XCMPLX-0K4 a"
          using A0 A1 arytm_1_th_18 sorry
      qed
      have case2: "xx <>HIDDENR2 0NUMBERSK6 implies Z9 -ARYTM-1K2 xx =HIDDENR1 -XCMPLX-0K4 a"
      proof(rule impI)
        assume A2: "xx <>HIDDENR2 0NUMBERSK6"
        let ?b = "Z9 -ARYTM-1K2 xx"
        have A3: "Z9 <='ARYTM-2R1 xx"
          using A0 arytm_1_th_6 sorry
        then have " not xx <='ARYTM-2R1 Z9"
          using A0 A2 arytm_1_th_4 sorry
        then have A4: "?b =HIDDENR1 [TARSKIK4 {}ARYTM-3K12,xx -'ARYTM-1K1 Z9 ]"
          using arytm_1_def_2 sorry
        have "Z9 -ARYTM-1K2 xx =HIDDENR1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] implies  False "
        proof(rule impI)
          assume "?b =HIDDENR1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ]"
          then have "xx -'ARYTM-1K1 Z9 =XBOOLE-0R4 0NUMBERSK6"
            using A4 xtuple_0_th_1 sorry
          thus " False "
            using A0 A2 A3 arytm_1_th_10 sorry
        qed
        then have A5: " not ?b inTARSKIR2 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
          using tarski_def_1 sorry
        have A6: "xx -'ARYTM-1K1 Z9 =HIDDENR1 (xx -'ARYTM-1K1 Z9)+ARYTM-2K7 Z9"
          using A0 arytm_2_def_8 sorry
        also have "... = xx"
          using A3 arytm_1_def_1 sorry
        finally have "xx -'ARYTM-1K1 Z9 =HIDDENR1 xx"
           sorry
        have "0NUMBERSK6 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        then have A7: "?b inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A4 zfmisc_1_th_87 sorry
        then have "?b inTARSKIR2 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using xboole_0_def_3 sorry
        then obtain b where 
          [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = ?b"
          using A5 numbers_def_1 xboole_0_def_5 sorry
        obtain x1 x2 y1 y2 where
          [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A8: "a =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A9: "b =XBOOLE-0R4 [*ARYTM-0K5 y1,y2 *]"and A10: "a +XCMPLX-0K2 b =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
          using xcmplx_0_def_4 sorry
        have "a +XCMPLX-0K2 b inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "+ARYTM-0K1(x2,y2) =XBOOLE-0R4 0NUMBERSK6"
          using A10 arytm_0_th_24 sorry
        then have A11: "a +XCMPLX-0K2 b =XBOOLE-0R4 +ARYTM-0K1(x1,y1)"
          using A10 arytm_0_def_5 sorry
        have "a inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "x2 =XBOOLE-0R4 0NUMBERSK6"
          using A8 arytm_0_th_24 sorry
        then have A12: "a =HIDDENR1 x1"
          using A8 arytm_0_def_5 sorry
        have "y2 =XBOOLE-0R4 0NUMBERSK6"
          using A9 arytm_0_th_24 sorry
        then have A13: "b =XBOOLE-0R4 y1"
          using A9 arytm_0_def_5 sorry
        then obtain x9 y9 where
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A14: "x1 =XBOOLE-0R4 x9"and A15: "y1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A16: "+ARYTM-0K1(x1,y1) =XBOOLE-0R4 x9 -ARYTM-1K2 y9"
          using A1 A7 A12 arytm_0_def_1 sorry
        have "y9 =XBOOLE-0R4 xx -'ARYTM-1K1 Z9"
          using A4 A13 A15 xtuple_0_th_1 sorry
        then have "a +XCMPLX-0K2 b =XBOOLE-0R4 0NUMBERSK6"
          using A1 A12 A11 A14 A16 A6 arytm_1_th_18 sorry
        thus "Z9 -ARYTM-1K2 xx =HIDDENR1 -XCMPLX-0K4 a"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rat_1_lm_4:
" for x be objectHIDDENM1 holds x inHIDDENR3 RATNUMBERSK4 implies ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n)"
proof-
  have " for x be objectHIDDENM1 holds x inHIDDENR3 RATNUMBERSK4 implies ( ex tVar1 be IntegerINT-1M1 st  ex tVar2 be IntegerINT-1M1 st x =HIDDENR1 tVar1 /XCMPLX-0K7 tVar2)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 RATNUMBERSK4"
    show " ex tVar1 be IntegerINT-1M1 st  ex tVar2 be IntegerINT-1M1 st x =HIDDENR1 tVar1 /XCMPLX-0K7 tVar2"
    proof-
      have cases: "x inHIDDENR3 RAT+ARYTM-3K5 or x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },RAT+ARYTM-3K5 :]"
        using A1 numbers_def_3 xboole_0_def_3 sorry
      have case1: "x inHIDDENR3 RAT+ARYTM-3K5 implies ( ex tVar1 be IntegerINT-1M1 st  ex tVar2 be IntegerINT-1M1 st x =HIDDENR1 tVar1 /XCMPLX-0K7 tVar2)"
      proof(rule impI)
        assume "x inHIDDENR3 RAT+ARYTM-3K5"
        then have 
          [ty]:"x be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
           sorry
        show " ex tVar1 be IntegerINT-1M1 st  ex tVar2 be IntegerINT-1M1 st x =HIDDENR1 tVar1 /XCMPLX-0K7 tVar2"
        proof(rule bexI[of _ "numeratorARYTM-3K6 x"])
          show " ex tVar2 be IntegerINT-1M1 st x =HIDDENR1 numeratorARYTM-3K6 x /XCMPLX-0K7 tVar2"
          proof(rule bexI[of _ "denominatorARYTM-3K7 x"])
            have "quotientARYTM-3K9(numeratorARYTM-3K6 x,denominatorARYTM-3K7 x) =XBOOLE-0R4 x"
              using arytm_3_th_39 sorry
            thus "x =HIDDENR1 numeratorARYTM-3K6 x /XCMPLX-0K7 denominatorARYTM-3K7 x"
              using rat_1_lm_2 sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },RAT+ARYTM-3K5 :] implies ( ex m be objectHIDDENM1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st x =HIDDENR1 m /XCMPLX-0K7 n)"
      proof(rule impI)
        assume A2: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },RAT+ARYTM-3K5 :]"
        have A3: " not x inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
          using A1 numbers_def_3 xboole_0_def_5 sorry
        obtain x1 x2 where
          [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
          A4: "x1 inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A5: "x2 inHIDDENR3 RAT+ARYTM-3K5"and A6: "x =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using A2 zfmisc_1_th_84 sorry
        have 
          [ty]:"x2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
          using A5 sorry
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x2"
          using arytm_2_th_1 sorry
        have "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"
          using A4 A6 tarski_def_1 sorry
        then have A7: "x2 <>HIDDENR2 0NUMBERSK6"
          using A3 tarski_def_1 sorry
        obtain m where 
          [ty]:"m be objectHIDDENM1" and mDef:"m = -XCMPLX-0K4 numeratorARYTM-3K6 x2"
           sorry
        show " ex m be objectHIDDENM1 st  ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st x =HIDDENR1 m /XCMPLX-0K7 n"
        proof(rule bexI[of _ "m"])
          obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of omegaORDINAL1K4" and nDef:"n = denominatorARYTM-3K7 x2"
             sorry
          show " ex n be ElementSUBSET-1M1-of omegaORDINAL1K4 st x =HIDDENR1 m /XCMPLX-0K7 n"
          proof(rule bexI[of _ "n"])
            obtain Z9 where 
              [ty]:"Z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and Z9Def:"Z9 = 0NUMBERSK6"
              using arytm_2_th_2 sorry
            have A8: "x2 =HIDDENR1 quotientARYTM-3K9(numeratorARYTM-3K6 x2,denominatorARYTM-3K7 x2)"
              using arytm_3_th_39 sorry
            also have "... = numeratorARYTM-3K6 x2 /XCMPLX-0K7 n"
              using rat_1_lm_2 sorry
            finally have "x2 =HIDDENR1 numeratorARYTM-3K6 x2 /XCMPLX-0K7 n"
               sorry
            have "x1 =HIDDENR1 0NUMBERSK6"
              using A4 tarski_def_1 sorry
            then have "x =HIDDENR1 Z9 -ARYTM-1K2 x9"
              using A6 A7 arytm_1_th_19 sorry
            also have "... = -XCMPLX-0K4 numeratorARYTM-3K6 x2 /XCMPLX-0K7 n"
              using A8 rat_1_lm_3 sorry
            also have "... = m /XCMPLX-0K7 n"
               sorry
            finally show "x =HIDDENR1 m /XCMPLX-0K7 n"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rat_1_lm_5:
" for x be objectHIDDENM1 holds  for w be NatNAT-1M1 holds  for m be IntegerINT-1M1 holds x =HIDDENR1 m /XCMPLX-0K7 w implies x inHIDDENR3 RATNUMBERSK4"
proof-
  have " for x be objectHIDDENM1 holds  for w be NatNAT-1M1 holds  for m be IntegerINT-1M1 holds x =HIDDENR1 m /XCMPLX-0K7 w implies x inHIDDENR3 RATNUMBERSK4"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix w assume [ty]: "w be NatNAT-1M1"
    fix m assume [ty]: "m be IntegerINT-1M1"
    obtain Z9 where 
      [ty]:"Z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and Z9Def:"Z9 = 0NUMBERSK6"
      using arytm_2_th_2 sorry
    have A1: "m be ElementSUBSET-1M1-of INTINT-1K1"
      using int_1_def_2 sorry
    assume A2: "x =HIDDENR1 m /XCMPLX-0K7 w"
    then have "x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have A3: " not x inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      using numbers_def_1 xboole_0_def_5 sorry
    have 
      [ty]:"w be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    show "x inHIDDENR3 RATNUMBERSK4"
    proof-
      have cases: "(w =XBOOLE-0R4 0NUMBERSK6 or ( ex k be NatNAT-1M1 st m =HIDDENR1 k)) or w <>HIDDENR2 0NUMBERSK6 & ( for k be NatNAT-1M1 holds m <>HIDDENR2 k)"
         sorry
      have case1: "w =XBOOLE-0R4 0NUMBERSK6 implies x inHIDDENR3 RATNUMBERSK4"
      proof(rule impI)
        assume "w =XBOOLE-0R4 0NUMBERSK6"
        then have "x =HIDDENR1 m *XCMPLX-0K3 (0NUMBERSK6)\<inverse>XCMPLX-0K5"
          using A2 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally have "x =HIDDENR1 0NUMBERSK6"
           sorry
        then have "x inHIDDENR3 RAT+ARYTM-3K5 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },RAT+ARYTM-3K5 :]"
          using rat_1_lm_1 xboole_0_def_3 sorry
        thus "x inHIDDENR3 RATNUMBERSK4"
          using A3 numbers_def_3 xboole_0_def_5 sorry
      qed
      have case2: "( ex k be NatNAT-1M1 st m =HIDDENR1 k) implies x inHIDDENR3 RATNUMBERSK4"
      proof(rule impI)
        assume " ex k be NatNAT-1M1 st m =HIDDENR1 k"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A4: "m =HIDDENR1 k"
           sorry
        have "x =HIDDENR1 quotientARYTM-3K9(k,w)"
          using A2 A4 rat_1_lm_2 sorry
        then have "x inHIDDENR3 RAT+ARYTM-3K5 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },RAT+ARYTM-3K5 :]"
          using xboole_0_def_3 sorry
        thus "x inHIDDENR3 RATNUMBERSK4"
          using A3 numbers_def_3 xboole_0_def_5 sorry
      qed
      have case3: "w <>HIDDENR2 0NUMBERSK6 & ( for k be NatNAT-1M1 holds m <>HIDDENR2 k) implies x inHIDDENR3 RATNUMBERSK4"
      proof(rule impMI ,rule impI)
        assume A5: "w <>HIDDENR2 0NUMBERSK6"
          and A6: " for k be NatNAT-1M1 holds m <>HIDDENR2 k"
        obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A7: "m =HIDDENR1 -XCMPLX-0K4 k"
          using A1 A6 int_1_def_1 sorry
        have A8: "k /XCMPLX-0K7 w =XBOOLE-0R4 quotientARYTM-3K9(k,w)"
          using rat_1_lm_2 sorry
        then have "k /XCMPLX-0K7 w inTARSKIR2 RAT+ARYTM-3K5"
           sorry
        then obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = k /XCMPLX-0K7 w"
          using arytm_2_th_1 sorry
        have A9: "0NUMBERSK6 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        have A10: "x =HIDDENR1 -XCMPLX-0K4 k /XCMPLX-0K7 w"
          using A2 A7 sorry
        have "m <>HIDDENR2 0NUMBERSK6"
          using A6 sorry
        then have A11: "x9 <>HIDDENR2 0NUMBERSK6"
          using A2 A5 A10 xcmplx_1_th_50 sorry
        have "x =HIDDENR1 Z9 -ARYTM-1K2 x9"
          using A10 rat_1_lm_3 sorry
        also have "... = [TARSKIK4 0NUMBERSK6,x9 ]"
          using A11 arytm_1_th_19 sorry
        finally have "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"
           sorry
        then have "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },RAT+ARYTM-3K5 :]"
          using A8 A9 zfmisc_1_th_87 sorry
        then have "x inHIDDENR3 RAT+ARYTM-3K5 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },RAT+ARYTM-3K5 :]"
          using xboole_0_def_3 sorry
        thus "x inHIDDENR3 RATNUMBERSK4"
          using A3 numbers_def_3 xboole_0_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rat_1_lm_6:
" for x be objectHIDDENM1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds x =HIDDENR1 m /XCMPLX-0K7 n implies x inHIDDENR3 RATNUMBERSK4"
proof-
  have " for x be objectHIDDENM1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds x =HIDDENR1 m /XCMPLX-0K7 n implies x inHIDDENR3 RATNUMBERSK4"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix m assume [ty]: "m be IntegerINT-1M1"
    fix n assume [ty]: "n be IntegerINT-1M1"
    assume A1: "x =HIDDENR1 m /XCMPLX-0K7 n"
    have "n be ElementSUBSET-1M1-of INTINT-1K1"
      using int_1_def_2 sorry
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A2: "n =HIDDENR1 k or n =HIDDENR1 -XCMPLX-0K4 k"
      using int_1_def_1 sorry
    show "x inHIDDENR3 RATNUMBERSK4"
    proof-
      have cases: "n =HIDDENR1 k or n =HIDDENR1 -XCMPLX-0K4 k"
        using A2 sorry
      have case1: "n =HIDDENR1 k implies x inHIDDENR3 RATNUMBERSK4"
      proof(rule impI)
        assume "n =HIDDENR1 k"
        thus "x inHIDDENR3 RATNUMBERSK4"
          using A1 rat_1_lm_5 sorry
      qed
      have case2: "n =HIDDENR1 -XCMPLX-0K4 k implies x inHIDDENR3 RATNUMBERSK4"
      proof(rule impI)
        assume "n =HIDDENR1 -XCMPLX-0K4 k"
        then have "x =HIDDENR1 (-XCMPLX-0K4 m)/XCMPLX-0K7 k"
          using A1 xcmplx_1_th_192 sorry
        thus "x inHIDDENR3 RATNUMBERSK4"
          using rat_1_lm_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RAT_1K1("RATRAT-1K1" 355) where
  "RATRAT-1K1 \<equiv> RATNUMBERSK4"

mtheorem rat_1_def_1:
"redefine func RATRAT-1K1 \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n)"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 RATRAT-1K1 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n))"
  proof-
    have " for R be setHIDDENM2 holds (R =XBOOLE-0R4 RATNUMBERSK4 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 R iff ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n))) & (( for x be objectHIDDENM1 holds x inHIDDENR3 R iff ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n)) implies R =HIDDENR1 RATNUMBERSK4)"
    proof(rule ballI,rule conjMI,rule impI)
      fix R assume [ty]: "R be setHIDDENM2"
      show "R =XBOOLE-0R4 RATNUMBERSK4 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 R iff ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n))"
        using rat_1_lm_4 rat_1_lm_6 sorry
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 R iff ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n)"
      have "R c=TARSKIR1 RATNUMBERSK4 & RATNUMBERSK4 c=TARSKIR1 R"
      proof(rule conjMI)
        show "R c=TARSKIR1 RATNUMBERSK4"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 R implies x inHIDDENR3 RATNUMBERSK4"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 R"
            then have " ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n"
              using A1 sorry
            thus "x inHIDDENR3 RATNUMBERSK4"
              using rat_1_lm_6 sorry
          qed "sorry"
          thus "R c=TARSKIR1 RATNUMBERSK4"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 RATNUMBERSK4 implies x inHIDDENR3 R"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 RATNUMBERSK4"
          then have " ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st x =HIDDENR1 m /XCMPLX-0K7 n"
            using rat_1_lm_4 sorry
          thus "x inHIDDENR3 R"
            using A1 sorry
        qed "sorry"
        thus "RATNUMBERSK4 c=TARSKIR1 R"
          using tarski_def_3 sorry
      qed
      thus "R =HIDDENR1 RATNUMBERSK4"
        using xboole_0_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef rat_1_def_2 ("rationalRAT-1V1" 70 ) where
"attr rationalRAT-1V1 for objectHIDDENM1 means
  (\<lambda>r. r inHIDDENR3 RATRAT-1K1)"..

mtheorem rat_1_cl_1:
"cluster rationalRAT-1V1 for RealXREAL-0M1"
proof
(*existence*)
  show " ex it be RealXREAL-0M1 st it be rationalRAT-1V1"
  proof-
    have " ex x be setHIDDENM2 st x be rationalRAT-1V1"
    proof-
      obtain a b where 
        [ty]:"a be IntegerINT-1M1" and aDef:"a = 0NUMBERSK6" and
        [ty]:"b be IntegerINT-1M1" and bDef:"b = \<one>\<^sub>M"
         sorry
      obtain x where 
        [ty]:"x be setHIDDENM2" and xDef:"x = a /XCMPLX-0K7 b"
         sorry
      show " ex x be setHIDDENM2 st x be rationalRAT-1V1"
      proof(rule bexI[of _ "x"])
        have "x inTARSKIR2 RATRAT-1K1"
        proof-
          show "x inTARSKIR2 RATRAT-1K1"
            using rat_1_def_1 sorry
        qed
        thus "x be rationalRAT-1V1"
          using rat_1_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rat_1_cl_2:
"cluster rationalRAT-1V1 for numberORDINAL1M2"
proof
(*existence*)
  show " ex it be numberORDINAL1M2 st it be rationalRAT-1V1"
  proof-
    have " ex x be setHIDDENM2 st x be rationalRAT-1V1"
    proof-
      obtain a b where 
        [ty]:"a be IntegerINT-1M1" and aDef:"a = 0NUMBERSK6" and
        [ty]:"b be IntegerINT-1M1" and bDef:"b = \<one>\<^sub>M"
         sorry
      obtain x where 
        [ty]:"x be setHIDDENM2" and xDef:"x = a /XCMPLX-0K7 b"
         sorry
      show " ex x be setHIDDENM2 st x be rationalRAT-1V1"
      proof(rule bexI[of _ "x"])
        have "x inTARSKIR2 RATRAT-1K1"
        proof-
          show "x inTARSKIR2 RATRAT-1K1"
            using rat_1_def_1 sorry
        qed
        thus "x be rationalRAT-1V1"
          using rat_1_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax RAT_1M1 :: "Ty" ("RationalRAT-1M1" 70)
translations "RationalRAT-1M1" \<rightharpoonup> "rationalRAT-1V1\<bar>NumberORDINAL1M1"

mtheorem rat_1_th_1:
" for x be objectHIDDENM1 holds x inHIDDENR3 RATRAT-1K1 implies ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st n <>HIDDENR2 0NUMBERSK6 & x =HIDDENR1 m /XCMPLX-0K7 n)"
proof-
  have " for x be objectHIDDENM1 holds x inHIDDENR3 RATRAT-1K1 implies  not ( for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  not ( not n <>HIDDENR2 0NUMBERSK6 & x =HIDDENR1 m /XCMPLX-0K7 n))"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 RATRAT-1K1"
    show " not ( for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  not ( not n <>HIDDENR2 0NUMBERSK6 & x =HIDDENR1 m /XCMPLX-0K7 n))"
    proof-
      have cases: "x =HIDDENR1 0NUMBERSK6 or x <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "x =HIDDENR1 0NUMBERSK6 implies  not ( for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  not ( not n <>HIDDENR2 0NUMBERSK6 & x =HIDDENR1 m /XCMPLX-0K7 n))"
      proof(rule impI)
        assume "x =HIDDENR1 0NUMBERSK6"
        then have "x =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 \<one>\<^sub>M"
           sorry
        thus " not ( for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  not ( not n <>HIDDENR2 0NUMBERSK6 & x =HIDDENR1 m /XCMPLX-0K7 n))"
           sorry
      qed
      have case2: "x <>HIDDENR2 0NUMBERSK6 implies ( ex tVar7 be IntegerINT-1M1 st  ex tVar8 be IntegerINT-1M1 st (tVar8 =HIDDENR1 0NUMBERSK6 implies  False ) & x =HIDDENR1 tVar7 /XCMPLX-0K7 tVar8)"
      proof(rule impI)
        assume A2: "x <>HIDDENR2 0NUMBERSK6"
        obtain m n where
          [ty]:"m be IntegerINT-1M1" "n be IntegerINT-1M1" and 
          A3: "x =HIDDENR1 m /XCMPLX-0K7 n"
          using A1 rat_1_def_1 sorry
        show " ex tVar7 be IntegerINT-1M1 st  ex tVar8 be IntegerINT-1M1 st (tVar8 =HIDDENR1 0NUMBERSK6 implies  False ) & x =HIDDENR1 tVar7 /XCMPLX-0K7 tVar8"
        proof(rule bexI[of _ "m"])
          show " ex tVar8 be IntegerINT-1M1 st (tVar8 =HIDDENR1 0NUMBERSK6 implies  False ) & x =HIDDENR1 m /XCMPLX-0K7 tVar8"
          proof(rule bexI[of _ "n"],rule conjMI)
            show "n =HIDDENR1 0NUMBERSK6 implies  False "
            proof(rule impI)
              assume "n =HIDDENR1 0NUMBERSK6"
              then have "n \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
                 sorry
              thus " False "
                using A2 A3 sorry
            qed
            show "x =HIDDENR1 m /XCMPLX-0K7 n"
              using A3 sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_2:
" for x be objectHIDDENM1 holds x be rationalRAT-1V1 implies ( ex m be IntegerINT-1M1 st  ex n be IntegerINT-1M1 st n <>HIDDENR2 0NUMBERSK6 & x =HIDDENR1 m /XCMPLX-0K7 n)"
  using rat_1_th_1 sorry

mtheorem rat_1_cl_3:
"cluster rationalRAT-1V1 also-is realXREAL-0V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be rationalRAT-1V1 implies it be realXREAL-0V1"
    using numbers_th_12 sorry
qed "sorry"

mtheorem rat_1_th_3:
" for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds m /XCMPLX-0K7 n be rationalRAT-1V1"
  using rat_1_def_1 sorry

mtheorem rat_1_cl_4:
"cluster integerINT-1V1 also-is rationalRAT-1V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be integerINT-1V1 implies it be rationalRAT-1V1"
  proof-
    have " for x be objectHIDDENM1 holds x be integerINT-1V1 implies x be rationalRAT-1V1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x be integerINT-1V1"
      then have 
        [ty]:"x be IntegerINT-1M1"
         sorry
      have "x =HIDDENR1 x /XCMPLX-0K7 \<one>\<^sub>M"
         sorry
      thus "x be rationalRAT-1V1"
        using rat_1_th_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve p, q for "RationalRAT-1M1"
mtheorem rat_1_cl_5:
  mlet "p be RationalRAT-1M1", "q be RationalRAT-1M1"
"cluster p *XCMPLX-0K3 q as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show "p *XCMPLX-0K3 q be rationalRAT-1V1"
  proof-
    obtain m2 n2 where
      [ty]:"m2 be IntegerINT-1M1" "n2 be IntegerINT-1M1" and 
      "n2 <>HIDDENR2 0NUMBERSK6"and A1: "q =HIDDENR1 m2 /XCMPLX-0K7 n2"
      using rat_1_th_2 sorry
    obtain m1 n1 where
      [ty]:"m1 be IntegerINT-1M1" "n1 be IntegerINT-1M1" and 
      "n1 <>HIDDENR2 0NUMBERSK6"and A2: "p =HIDDENR1 m1 /XCMPLX-0K7 n1"
      using rat_1_th_2 sorry
    have "p *XCMPLX-0K3 q =XBOOLE-0R4 (m1 *XCMPLX-0K3 m2)/XCMPLX-0K7 (n1 *XCMPLX-0K3 n2)"
      using A2 A1 xcmplx_1_th_76 sorry
    thus "p *XCMPLX-0K3 q be rationalRAT-1V1"
      using rat_1_th_3 sorry
  qed
qed "sorry"

mtheorem rat_1_cl_6:
  mlet "p be RationalRAT-1M1", "q be RationalRAT-1M1"
"cluster p +XCMPLX-0K2 q as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show "p +XCMPLX-0K2 q be rationalRAT-1V1"
  proof-
    obtain m2 n2 where
      [ty]:"m2 be IntegerINT-1M1" "n2 be IntegerINT-1M1" and 
      A3: "n2 <>HIDDENR2 0NUMBERSK6"and A4: "q =HIDDENR1 m2 /XCMPLX-0K7 n2"
      using rat_1_th_2 sorry
    obtain m1 n1 where
      [ty]:"m1 be IntegerINT-1M1" "n1 be IntegerINT-1M1" and 
      A5: "n1 <>HIDDENR2 0NUMBERSK6"and A6: "p =HIDDENR1 m1 /XCMPLX-0K7 n1"
      using rat_1_th_2 sorry
    have "p +XCMPLX-0K2 q =XBOOLE-0R4 (m1 *XCMPLX-0K3 n2 +XCMPLX-0K2 m2 *XCMPLX-0K3 n1)/XCMPLX-0K7 (n1 *XCMPLX-0K3 n2)"
      using A5 A6 A3 A4 xcmplx_1_th_116 sorry
    thus "p +XCMPLX-0K2 q be rationalRAT-1V1"
      using rat_1_th_3 sorry
  qed
qed "sorry"

mtheorem rat_1_cl_7:
  mlet "p be RationalRAT-1M1", "q be RationalRAT-1M1"
"cluster p -XCMPLX-0K6 q as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show "p -XCMPLX-0K6 q be rationalRAT-1V1"
  proof-
    obtain m2 n2 where
      [ty]:"m2 be IntegerINT-1M1" "n2 be IntegerINT-1M1" and 
      A7: "n2 <>HIDDENR2 0NUMBERSK6"and A8: "q =HIDDENR1 m2 /XCMPLX-0K7 n2"
      using rat_1_th_2 sorry
    obtain m1 n1 where
      [ty]:"m1 be IntegerINT-1M1" "n1 be IntegerINT-1M1" and 
      A9: "n1 <>HIDDENR2 0NUMBERSK6"and A10: "p =HIDDENR1 m1 /XCMPLX-0K7 n1"
      using rat_1_th_2 sorry
    have "p -XCMPLX-0K6 q =XBOOLE-0R4 (m1 *XCMPLX-0K3 n2 -XCMPLX-0K6 m2 *XCMPLX-0K3 n1)/XCMPLX-0K7 (n1 *XCMPLX-0K3 n2)"
      using A9 A10 A7 A8 xcmplx_1_th_130 sorry
    thus "p -XCMPLX-0K6 q be rationalRAT-1V1"
      using rat_1_th_3 sorry
  qed
qed "sorry"

mtheorem rat_1_cl_8:
  mlet "p be RationalRAT-1M1", "q be RationalRAT-1M1"
"cluster p /XCMPLX-0K7 q as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show "p /XCMPLX-0K7 q be rationalRAT-1V1"
  proof-
    obtain m1 n1 where
      [ty]:"m1 be IntegerINT-1M1" "n1 be IntegerINT-1M1" and 
      "n1 <>HIDDENR2 0NUMBERSK6"and A11: "p =HIDDENR1 m1 /XCMPLX-0K7 n1"
      using rat_1_th_2 sorry
    obtain m2 n2 where
      [ty]:"m2 be IntegerINT-1M1" "n2 be IntegerINT-1M1" and 
      "n2 <>HIDDENR2 0NUMBERSK6"and A12: "q =HIDDENR1 m2 /XCMPLX-0K7 n2"
      using rat_1_th_2 sorry
    have "p /XCMPLX-0K7 q =HIDDENR1 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (m2 /XCMPLX-0K7 n2))"
      using A12 sorry
    also have "... = p *XCMPLX-0K3 ((\<one>\<^sub>M *XCMPLX-0K3 n2)/XCMPLX-0K7 m2)"
      using xcmplx_1_th_77 sorry
    also have "... = (m1 *XCMPLX-0K3 n2)/XCMPLX-0K7 (n1 *XCMPLX-0K3 m2)"
      using A11 xcmplx_1_th_76 sorry
    finally have "p /XCMPLX-0K7 q =HIDDENR1 (m1 *XCMPLX-0K3 n2)/XCMPLX-0K7 (n1 *XCMPLX-0K3 m2)"
       sorry
    thus "p /XCMPLX-0K7 q be rationalRAT-1V1"
      using rat_1_th_3 sorry
  qed
qed "sorry"

mtheorem rat_1_cl_9:
  mlet "p be RationalRAT-1M1"
"cluster -XCMPLX-0K4 p as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show "-XCMPLX-0K4 p be rationalRAT-1V1"
  proof-
    obtain m n where
      [ty]:"m be IntegerINT-1M1" "n be IntegerINT-1M1" and 
      "n <>HIDDENR2 0NUMBERSK6"and A1: "p =HIDDENR1 m /XCMPLX-0K7 n"
      using rat_1_th_2 sorry
    have "-XCMPLX-0K4 p =HIDDENR1 (-XCMPLX-0K4 m)/XCMPLX-0K7 n"
      using A1 sorry
    thus "-XCMPLX-0K4 p be rationalRAT-1V1"
       sorry
  qed
qed "sorry"

mtheorem rat_1_cl_10:
  mlet "p be RationalRAT-1M1"
"cluster p \<inverse>XCMPLX-0K5 as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show "p \<inverse>XCMPLX-0K5 be rationalRAT-1V1"
  proof-
    have "p \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p"
       sorry
    thus "p \<inverse>XCMPLX-0K5 be rationalRAT-1V1"
       sorry
  qed
qed "sorry"

(*\$CT 3*)
mtheorem rat_1_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies ( ex p be RationalRAT-1M1 st a <XXREAL-0R3 p & p <XXREAL-0R3 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies ( ex tVar9 be RationalRAT-1M1 st a <XXREAL-0R3 tVar9 & tVar9 <XXREAL-0R3 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    let ?d = "b -XCMPLX-0K6 a"
    let ?m = "[\\INT-1K2 ?d \<inverse>XCMPLX-0K5/] +XCMPLX-0K2 \<one>\<^sub>M"
    let ?l = "[\\INT-1K2 ?m *XCMPLX-0K3 a /] +XCMPLX-0K2 \<one>\<^sub>M"
    let ?p = "?l /XCMPLX-0K7 ?m"
    assume "a <XXREAL-0R3 b"
    then have A1: "a -XCMPLX-0K6 a <XXREAL-0R3 b -XCMPLX-0K6 a"
      using xreal_1_th_9 sorry
    then have A2: "0NUMBERSK6 <XXREAL-0R3 ?m"
      using int_1_th_29 sorry
    have "?d \<inverse>XCMPLX-0K5 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 ?d \<inverse>XCMPLX-0K5/]"
      using int_1_def_6 sorry
    then have "?d \<inverse>XCMPLX-0K5 <XXREAL-0R3 [\\INT-1K2 ?d \<inverse>XCMPLX-0K5/] +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_19 sorry
    then have "?d \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?d <XXREAL-0R3 ?m *XCMPLX-0K3 ?d"
      using A1 xreal_1_th_68 sorry
    then have A3: "\<one>\<^sub>M <XXREAL-0R3 ?m *XCMPLX-0K3 ?d"
      using A1 xcmplx_0_def_7 sorry
    show " ex tVar9 be RationalRAT-1M1 st a <XXREAL-0R3 tVar9 & tVar9 <XXREAL-0R3 b"
    proof(rule bexI[of _ "?p"],rule conjMI)
      have A4: "0NUMBERSK6 <>HIDDENR2 ?m"
        using A1 int_1_th_29 sorry
      have "?m *XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 [\\INT-1K2 ?m *XCMPLX-0K3 a /]"
        using int_1_def_6 sorry
      then have "?m *XCMPLX-0K3 a <XXREAL-0R3 [\\INT-1K2 ?m *XCMPLX-0K3 a /] +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_19 sorry
      then have "?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (?m *XCMPLX-0K3 a) <XXREAL-0R3 ?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?l"
        using A2 xreal_1_th_68 sorry
      then have "(?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?m)*XCMPLX-0K3 a <XXREAL-0R3 ?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?l"
         sorry
      then have "\<one>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 ?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?l"
        using A4 xcmplx_0_def_7 sorry
      thus "a <XXREAL-0R3 ([\\INT-1K2 ([\\INT-1K2 (b -XCMPLX-0K6 a)\<inverse>XCMPLX-0K5/] +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 a /] +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ([\\INT-1K2 (b -XCMPLX-0K6 a)\<inverse>XCMPLX-0K5/] +XCMPLX-0K2 \<one>\<^sub>M)"
         sorry
      have "[\\INT-1K2 ?m *XCMPLX-0K3 a /] <=XXREAL-0R1 ?m *XCMPLX-0K3 a"
        using int_1_def_6 sorry
      then have "[\\INT-1K2 ?m *XCMPLX-0K3 a /] +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 ?m *XCMPLX-0K3 a +XCMPLX-0K2 ?m *XCMPLX-0K3 ?d"
        using A3 xreal_1_th_8 sorry
      then have "?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?l <XXREAL-0R3 ?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (?m *XCMPLX-0K3 b)"
        using A2 xreal_1_th_68 sorry
      then have "?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?l <XXREAL-0R3 (?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?m)*XCMPLX-0K3 b"
         sorry
      then have "?m \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?l <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 b"
        using A4 xcmplx_0_def_7 sorry
      thus "([\\INT-1K2 ([\\INT-1K2 (b -XCMPLX-0K6 a)\<inverse>XCMPLX-0K5/] +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 a /] +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 ([\\INT-1K2 (b -XCMPLX-0K6 a)\<inverse>XCMPLX-0K5/] +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 b"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_8:
" for p be RationalRAT-1M1 holds  ex m be IntegerINT-1M1 st  ex k be NatNAT-1M1 st k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k"
proof-
  have " for p be RationalRAT-1M1 holds  not ( for m be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not ( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k))"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    obtain m n where
      [ty]:"m be IntegerINT-1M1" "n be IntegerINT-1M1" and 
      A1: "n <>HIDDENR2 0NUMBERSK6"and A2: "p =HIDDENR1 m /XCMPLX-0K7 n"
      using rat_1_th_2 sorry
    show " not ( for m be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not ( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k))"
    proof-
      have cases: "0NUMBERSK6 <XXREAL-0R3 n or n <XXREAL-0R3 0NUMBERSK6"
        using A1 sorry
      have case1: "0NUMBERSK6 <XXREAL-0R3 n implies  not ( for m be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not ( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k))"
      proof(rule impI)
        assume "0NUMBERSK6 <XXREAL-0R3 n"
        then have "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using int_1_th_3 sorry
        thus " not ( for m be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not ( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k))"
          using A1 A2 sorry
      qed
      have case2: "n <XXREAL-0R3 0NUMBERSK6 implies  not ( for m be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not ( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k))"
      proof(rule impI)
        assume A3: "n <XXREAL-0R3 0NUMBERSK6"
        have A4: "p =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4 m)/XCMPLX-0K7 n"
          using A2 sorry
        also have "... = (-XCMPLX-0K4 m)/XCMPLX-0K7 (-XCMPLX-0K4 n)"
          using xcmplx_1_th_188 sorry
        finally have "p =HIDDENR1 (-XCMPLX-0K4 m)/XCMPLX-0K7 (-XCMPLX-0K4 n)"
           sorry
        have A5: "-XCMPLX-0K4 n <>HIDDENR2 0NUMBERSK6"
          using A1 sorry
        have "-XCMPLX-0K4 n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A3 int_1_th_3 sorry
        thus " not ( for m be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not ( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k))"
          using A4 A5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_9:
" for p be RationalRAT-1M1 holds  ex m be IntegerINT-1M1 st  ex k be NatNAT-1M1 st (k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k) & ( for n be IntegerINT-1M1 holds  for w be NatNAT-1M1 holds w <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 w implies k <=XXREAL-0R1 w)"
proof-
  have " for p be RationalRAT-1M1 holds  ex tVar10 be IntegerINT-1M1 st  ex tVar11 be NatNAT-1M1 st tVar11 <>HIDDENR2 0NUMBERSK6 & (tVar10 /XCMPLX-0K7 tVar11 =HIDDENR1 p & ( for n be IntegerINT-1M1 holds  for w be NatNAT-1M1 holds  not (( not w <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 w) &  not tVar11 <=XXREAL-0R1 w)))"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 0NUMBERSK6 & ( ex m1 be IntegerINT-1M1 st p =HIDDENR1 m1 /XCMPLX-0K7 Lamb1)"
    have " ex m be IntegerINT-1M1 st  ex k be NatNAT-1M1 st k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k"
      using rat_1_th_8 sorry
    then have A1: " ex l be NatNAT-1M1 st ?P(l)"
       sorry
    have " ex k1 be NatNAT-1M1 st ?P(k1) & ( for l1 be NatNAT-1M1 holds ?P(l1) implies k1 <=XXREAL-0R1 l1)"
      using nat_1_sch_5 A1 sorry
    then obtain k1 where
      [ty]:"k1 be NatNAT-1M1" and 
      A2: "k1 <>HIDDENR2 0NUMBERSK6"and A3: " ex m1 be IntegerINT-1M1 st p =HIDDENR1 m1 /XCMPLX-0K7 k1"and A4: " for l1 be NatNAT-1M1 holds l1 <>HIDDENR2 0NUMBERSK6 & ( ex n1 be IntegerINT-1M1 st p =HIDDENR1 n1 /XCMPLX-0K7 l1) implies k1 <=XXREAL-0R1 l1"
       sorry
    have 
      [ty]:"k1 be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    obtain m1 where
      [ty]:"m1 be IntegerINT-1M1" and 
      A5: "p =HIDDENR1 m1 /XCMPLX-0K7 k1"and A6: " for l1 be NatNAT-1M1 holds l1 <>HIDDENR2 0NUMBERSK6 & ( ex n1 be IntegerINT-1M1 st p =HIDDENR1 n1 /XCMPLX-0K7 l1) implies k1 <=XXREAL-0R1 l1"
      using A3 A4 sorry
    show " ex tVar10 be IntegerINT-1M1 st  ex tVar11 be NatNAT-1M1 st tVar11 <>HIDDENR2 0NUMBERSK6 & (tVar10 /XCMPLX-0K7 tVar11 =HIDDENR1 p & ( for n be IntegerINT-1M1 holds  for w be NatNAT-1M1 holds  not (( not w <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 w) &  not tVar11 <=XXREAL-0R1 w)))"
    proof(rule bexI[of _ "m1"])
      show " ex tVar11 be NatNAT-1M1 st tVar11 <>HIDDENR2 0NUMBERSK6 & (m1 /XCMPLX-0K7 tVar11 =HIDDENR1 p & ( for n be IntegerINT-1M1 holds  for w be NatNAT-1M1 holds  not (( not w <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 w) &  not tVar11 <=XXREAL-0R1 w)))"
      proof(rule bexI[of _ "k1"],rule conjMI,rule conjMI)
        show "k1 <>HIDDENR2 0NUMBERSK6"
          using A2 sorry
        show "m1 /XCMPLX-0K7 k1 =HIDDENR1 p"
          using A5 sorry
        show " for n be IntegerINT-1M1 holds  for w be NatNAT-1M1 holds  not (( not w <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 w) &  not k1 <=XXREAL-0R1 w)"
          using A6 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rat_1_def_3 ("denominatorRAT-1K2  _ " [250]250 ) where
  mlet "p be RationalRAT-1M1"
"func denominatorRAT-1K2 p \<rightarrow> NatNAT-1M1 means
  \<lambda>it. (it <>HIDDENR2 0NUMBERSK6 & ( ex m be IntegerINT-1M1 st p =HIDDENR1 m /XCMPLX-0K7 it)) & ( for n be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 k implies it <=XXREAL-0R1 k)"
proof-
  (*existence*)
    show " ex it be NatNAT-1M1 st (it <>HIDDENR2 0NUMBERSK6 & ( ex m be IntegerINT-1M1 st p =HIDDENR1 m /XCMPLX-0K7 it)) & ( for n be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 k implies it <=XXREAL-0R1 k)"
    proof-
      have " ex IT be ElementSUBSET-1M1-of NATNUMBERSK1 st ( not IT <>HIDDENR2 0NUMBERSK6 &  not ( for m be IntegerINT-1M1 holds  not p =HIDDENR1 m /XCMPLX-0K7 IT)) & ( for n be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not (( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 k) &  not IT <=XXREAL-0R1 k))"
      proof-
        obtain m k where
          [ty]:"m be IntegerINT-1M1" "k be NatNAT-1M1" and 
          A1: "k <>HIDDENR2 0NUMBERSK6"and A2: "p =HIDDENR1 m /XCMPLX-0K7 k"and A3: " for n be IntegerINT-1M1 holds  for w be NatNAT-1M1 holds w <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 w implies k <=XXREAL-0R1 w"
          using rat_1_th_9 sorry
        have 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        obtain IT where 
          [ty]:"IT be ElementSUBSET-1M1-of NATNUMBERSK1" and ITDef:"IT = k"
           sorry
        show " ex IT be ElementSUBSET-1M1-of NATNUMBERSK1 st ( not IT <>HIDDENR2 0NUMBERSK6 &  not ( for m be IntegerINT-1M1 holds  not p =HIDDENR1 m /XCMPLX-0K7 IT)) & ( for n be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not (( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 k) &  not IT <=XXREAL-0R1 k))"
        proof(rule bexI[of _ "IT"])
          show "( not IT <>HIDDENR2 0NUMBERSK6 &  not ( for m be IntegerINT-1M1 holds  not p =HIDDENR1 m /XCMPLX-0K7 IT)) & ( for n be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not (( not k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 k) &  not IT <=XXREAL-0R1 k))"
            using A1 A2 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds ((it1 <>HIDDENR2 0NUMBERSK6 & ( ex m be IntegerINT-1M1 st p =HIDDENR1 m /XCMPLX-0K7 it1)) & ( for n be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 k implies it1 <=XXREAL-0R1 k)) & ((it2 <>HIDDENR2 0NUMBERSK6 & ( ex m be IntegerINT-1M1 st p =HIDDENR1 m /XCMPLX-0K7 it2)) & ( for n be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n /XCMPLX-0K7 k implies it2 <=XXREAL-0R1 k)) implies it1 =HIDDENR1 it2"
    proof-
      have " for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & (( ex m be IntegerINT-1M1 st p =HIDDENR1 m /XCMPLX-0K7 k) & (( for m1 be IntegerINT-1M1 holds  for k1 be NatNAT-1M1 holds k1 <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m1 /XCMPLX-0K7 k1 implies k <=XXREAL-0R1 k1) & (l <>HIDDENR2 0NUMBERSK6 & (( ex n be IntegerINT-1M1 st p =HIDDENR1 n /XCMPLX-0K7 l) & ( for n1 be IntegerINT-1M1 holds  for k1 be NatNAT-1M1 holds k1 <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n1 /XCMPLX-0K7 k1 implies l <=XXREAL-0R1 k1))))) implies k =HIDDENR1 l"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        fix l assume [ty]: "l be NatNAT-1M1"
        assume A4: "k <>HIDDENR2 0NUMBERSK6"
          and A5: " ex m be IntegerINT-1M1 st p =HIDDENR1 m /XCMPLX-0K7 k"
          and A6: " for m1 be IntegerINT-1M1 holds  for k1 be NatNAT-1M1 holds k1 <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m1 /XCMPLX-0K7 k1 implies k <=XXREAL-0R1 k1"
          and A7: "l <>HIDDENR2 0NUMBERSK6"
          and A8: " ex n be IntegerINT-1M1 st p =HIDDENR1 n /XCMPLX-0K7 l"
          and A9: " for n1 be IntegerINT-1M1 holds  for k1 be NatNAT-1M1 holds k1 <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 n1 /XCMPLX-0K7 k1 implies l <=XXREAL-0R1 k1"
        have A10: "l <=XXREAL-0R1 k"
          using A4 A5 A9 sorry
        have "k <=XXREAL-0R1 l"
          using A6 A7 A8 sorry
        thus "k =HIDDENR1 l"
          using A10 xxreal_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef rat_1_def_4 ("numeratorRAT-1K3  _ " [250]250 ) where
  mlet "p be RationalRAT-1M1"
"func numeratorRAT-1K3 p \<rightarrow> IntegerINT-1M1 equals
  denominatorRAT-1K2 p *XCMPLX-0K3 p"
proof-
  (*coherence*)
    show "denominatorRAT-1K2 p *XCMPLX-0K3 p be IntegerINT-1M1"
    proof-
      have A1: "denominatorRAT-1K2 p <>HIDDENR2 0NUMBERSK6"
        using rat_1_def_3 sorry
      have " ex m be IntegerINT-1M1 st p =HIDDENR1 m /XCMPLX-0K7 denominatorRAT-1K2 p"
        using rat_1_def_3 sorry
      thus "denominatorRAT-1K2 p *XCMPLX-0K3 p be IntegerINT-1M1"
        using A1 xcmplx_1_th_87 sorry
    qed
qed "sorry"

mtheorem rat_1_th_10:
" for p be RationalRAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 denominatorRAT-1K2 p"
proof-
  have " for p be RationalRAT-1M1 holds  not 0NUMBERSK6 <XXREAL-0R3 denominatorRAT-1K2 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "0NUMBERSK6 <>HIDDENR2 denominatorRAT-1K2 p"
      using rat_1_def_3 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 denominatorRAT-1K2 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_cl_11:
  mlet "p be RationalRAT-1M1"
"cluster denominatorRAT-1K2 p as-term-is positiveXXREAL-0V2"
proof
(*coherence*)
  show "denominatorRAT-1K2 p be positiveXXREAL-0V2"
    using rat_1_th_10 sorry
qed "sorry"

mtheorem rat_1_th_11:
" for p be RationalRAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 denominatorRAT-1K2 p"
proof-
  have " for p be RationalRAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 denominatorRAT-1K2 p"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 denominatorRAT-1K2 p"
      using nat_1_th_13 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 denominatorRAT-1K2 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_12:
" for p be RationalRAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
   sorry

mtheorem rat_1_th_13:
" for p be RationalRAT-1M1 holds \<one>\<^sub>M >=XXREAL-0R2 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
proof-
  have " for p be RationalRAT-1M1 holds \<one>\<^sub>M >=XXREAL-0R2 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "\<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <=XXREAL-0R1 denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
      using rat_1_th_11 xreal_1_th_64 sorry
    thus "\<one>\<^sub>M >=XXREAL-0R2 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
      using xcmplx_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_14:
" for p be RationalRAT-1M1 holds numeratorRAT-1K3 p =HIDDENR1 0NUMBERSK6 iff p =HIDDENR1 0NUMBERSK6"
  using xcmplx_1_th_6 sorry

mtheorem rat_1_th_15:
" for p be RationalRAT-1M1 holds p =HIDDENR1 numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p & p =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
proof-
  have " for p be RationalRAT-1M1 holds numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p =HIDDENR1 p & p =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
  proof(rule ballI,rule conjMI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    let ?x = "denominatorRAT-1K2 p"
    have "numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p =HIDDENR1 p *XCMPLX-0K3 (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5)"
       sorry
    also have "... = p *XCMPLX-0K3 \<one>\<^sub>M"
      using xcmplx_0_def_7 sorry
    also have "... = p"
       sorry
    finally show "numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p =HIDDENR1 p"
       sorry
    thus "p =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_16:
" for p be RationalRAT-1M1 holds p <>HIDDENR2 0NUMBERSK6 implies denominatorRAT-1K2 p =XBOOLE-0R4 numeratorRAT-1K3 p /XCMPLX-0K7 p"
proof-
  have " for p be RationalRAT-1M1 holds p <>HIDDENR2 0NUMBERSK6 implies denominatorRAT-1K2 p =XBOOLE-0R4 numeratorRAT-1K3 p /XCMPLX-0K7 p"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have A1: "(p \<inverse>XCMPLX-0K5 *XCMPLX-0K3 p)*XCMPLX-0K3 denominatorRAT-1K2 p =XBOOLE-0R4 p \<inverse>XCMPLX-0K5 *XCMPLX-0K3 numeratorRAT-1K3 p"
       sorry
    assume "p <>HIDDENR2 0NUMBERSK6"
    then have "\<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p =XBOOLE-0R4 p \<inverse>XCMPLX-0K5 *XCMPLX-0K3 numeratorRAT-1K3 p"
      using A1 xcmplx_0_def_7 sorry
    thus "denominatorRAT-1K2 p =XBOOLE-0R4 numeratorRAT-1K3 p /XCMPLX-0K7 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_17:
" for p be RationalRAT-1M1 holds p be IntegerINT-1M1 implies denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M & numeratorRAT-1K3 p =HIDDENR1 p"
proof-
  have " for p be RationalRAT-1M1 holds p be IntegerINT-1M1 implies denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M & numeratorRAT-1K3 p =HIDDENR1 p"
  proof(rule ballI,rule impI,rule conjMI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume "p be IntegerINT-1M1"
    then obtain m where 
      [ty]:"m be IntegerINT-1M1" and mDef:"m = p"
       sorry
    have "p =HIDDENR1 m /XCMPLX-0K7 \<one>\<^sub>M"
       sorry
    then have A1: "denominatorRAT-1K2 p <=XXREAL-0R1 \<one>\<^sub>M"
      using rat_1_def_3 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 denominatorRAT-1K2 p"
      using rat_1_th_11 sorry
    thus "denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 xxreal_0_th_1 sorry
    thus "numeratorRAT-1K3 p =HIDDENR1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_18:
" for p be RationalRAT-1M1 holds numeratorRAT-1K3 p =HIDDENR1 p or denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M implies p be IntegerINT-1M1"
proof-
  have " for p be RationalRAT-1M1 holds numeratorRAT-1K3 p =HIDDENR1 p or denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M implies p be IntegerINT-1M1"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "numeratorRAT-1K3 p =HIDDENR1 p or denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M"
    show "p be IntegerINT-1M1"
    proof-
      have cases: "numeratorRAT-1K3 p =HIDDENR1 p or denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M"
        using A1 sorry
      have case1: "numeratorRAT-1K3 p =HIDDENR1 p implies p be IntegerINT-1M1"
      proof(rule impI)
        assume "numeratorRAT-1K3 p =HIDDENR1 p"
        thus "p be IntegerINT-1M1"
           sorry
      qed
      have case2: "denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M implies p be IntegerINT-1M1"
      proof(rule impI)
        assume "denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M"
        then have "numeratorRAT-1K3 p =HIDDENR1 p"
           sorry
        thus "p be IntegerINT-1M1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_19:
" for p be RationalRAT-1M1 holds numeratorRAT-1K3 p =HIDDENR1 p iff denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M"
  using rat_1_th_17 sorry

mtheorem rat_1_th_20:
" for p be RationalRAT-1M1 holds (numeratorRAT-1K3 p =HIDDENR1 p or denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M) & 0NUMBERSK6 <=XXREAL-0R1 p implies p be ElementSUBSET-1M1-of NATNUMBERSK1"
proof-
  have " for p be RationalRAT-1M1 holds (numeratorRAT-1K3 p =HIDDENR1 p or denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M) & 0NUMBERSK6 <=XXREAL-0R1 p implies p be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof(rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "numeratorRAT-1K3 p =HIDDENR1 p or denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 p"
    have "p be IntegerINT-1M1"
      using A1 rat_1_th_18 sorry
    thus "p be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A2 int_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_21:
" for p be RationalRAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 denominatorRAT-1K2 p iff  not p be integerINT-1V1"
proof-
  have " for p be RationalRAT-1M1 holds  not ( not \<one>\<^sub>M <XXREAL-0R3 denominatorRAT-1K2 p & p be integerINT-1V1) &  not ( not p be integerINT-1V1 & \<one>\<^sub>M <XXREAL-0R3 denominatorRAT-1K2 p)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have " not p be IntegerINT-1M1 implies denominatorRAT-1K2 p >XXREAL-0R4 \<one>\<^sub>M"
    proof(rule impI)
      assume A1: " not p be IntegerINT-1M1"
      have "denominatorRAT-1K2 p >=XXREAL-0R2 \<one>\<^sub>M"
        using rat_1_th_11 sorry
      thus "denominatorRAT-1K2 p >XXREAL-0R4 \<one>\<^sub>M"
        using A1 rat_1_th_18 xxreal_0_th_1 sorry
    qed
    thus " not ( not \<one>\<^sub>M <XXREAL-0R3 denominatorRAT-1K2 p & p be integerINT-1V1) &  not ( not p be integerINT-1V1 & \<one>\<^sub>M <XXREAL-0R3 denominatorRAT-1K2 p)"
      using rat_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rat_1_lm_7:
"\<one>\<^sub>M \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M"
   sorry

mtheorem rat_1_th_22:
" for p be RationalRAT-1M1 holds \<one>\<^sub>M >XXREAL-0R4 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 iff  not p be integerINT-1V1"
proof-
  have " for p be RationalRAT-1M1 holds  not ( not \<one>\<^sub>M >XXREAL-0R4 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 & p be integerINT-1V1) &  not ( not p be integerINT-1V1 & \<one>\<^sub>M >XXREAL-0R4 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have A1: "denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M"
      using rat_1_th_13 sorry
    have " not p be IntegerINT-1M1 implies denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
    proof(rule impI)
      assume " not p be IntegerINT-1M1"
      then have "denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <>HIDDENR2 \<one>\<^sub>M"
        using rat_1_lm_7 rat_1_th_18 sorry
      thus "denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
        using A1 xxreal_0_th_1 sorry
    qed
    thus " not ( not \<one>\<^sub>M >XXREAL-0R4 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 & p be integerINT-1V1) &  not ( not p be integerINT-1V1 & \<one>\<^sub>M >XXREAL-0R4 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5)"
      using rat_1_lm_7 rat_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_23:
" for p be RationalRAT-1M1 holds numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p iff p =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for p be RationalRAT-1M1 holds (numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p implies p =HIDDENR1 \<one>\<^sub>M) &  not (p =HIDDENR1 \<one>\<^sub>M &  not numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p)"
  proof(rule ballI,rule conjMI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    show "numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p implies p =HIDDENR1 \<one>\<^sub>M"
    proof(rule impI)
      assume "numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p"
      then have "numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p =XBOOLE-0R4 \<one>\<^sub>M"
        using xcmplx_1_th_60 sorry
      thus "p =HIDDENR1 \<one>\<^sub>M"
        using rat_1_th_15 sorry
    qed
    show " not (p =HIDDENR1 \<one>\<^sub>M &  not numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_24:
" for p be RationalRAT-1M1 holds numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p iff p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for p be RationalRAT-1M1 holds (numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p implies p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) &  not (p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p)"
  proof(rule ballI,rule conjMI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    show "numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p implies p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    proof(rule impI)
      assume "numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p"
      then have "p =HIDDENR1 (-XCMPLX-0K4 denominatorRAT-1K2 p)/XCMPLX-0K7 denominatorRAT-1K2 p"
        using rat_1_th_15 sorry
      also have "... = -XCMPLX-0K4 denominatorRAT-1K2 p /XCMPLX-0K7 denominatorRAT-1K2 p"
         sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
        using xcmplx_1_th_60 sorry
      finally show "p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
         sorry
    qed
    show " not (p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_25:
" for p be RationalRAT-1M1 holds -XCMPLX-0K4 numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p iff p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for p be RationalRAT-1M1 holds  not (-XCMPLX-0K4 numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p &  not p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) &  not (p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not -XCMPLX-0K4 numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "-XCMPLX-0K4 numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p iff numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p"
       sorry
    thus " not (-XCMPLX-0K4 numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p &  not p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M) &  not (p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not -XCMPLX-0K4 numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p)"
      using rat_1_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_26:
" for m be IntegerINT-1M1 holds  for p be RationalRAT-1M1 holds m <>HIDDENR2 0NUMBERSK6 implies p =HIDDENR1 (numeratorRAT-1K3 p *XCMPLX-0K3 m)/XCMPLX-0K7 (denominatorRAT-1K2 p *XCMPLX-0K3 m)"
proof-
  have " for m be IntegerINT-1M1 holds  for p be RationalRAT-1M1 holds m <>HIDDENR2 0NUMBERSK6 implies p =HIDDENR1 (numeratorRAT-1K3 p *XCMPLX-0K3 m)/XCMPLX-0K7 (denominatorRAT-1K2 p *XCMPLX-0K3 m)"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be IntegerINT-1M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume "m <>HIDDENR2 0NUMBERSK6"
    then have "numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p =XBOOLE-0R4 (numeratorRAT-1K3 p *XCMPLX-0K3 m)/XCMPLX-0K7 (denominatorRAT-1K2 p *XCMPLX-0K3 m)"
      using xcmplx_1_th_91 sorry
    thus "p =HIDDENR1 (numeratorRAT-1K3 p *XCMPLX-0K3 m)/XCMPLX-0K7 (denominatorRAT-1K2 p *XCMPLX-0K3 m)"
      using rat_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_27:
" for k be NatNAT-1M1 holds  for m be IntegerINT-1M1 holds  for p be RationalRAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k implies ( ex w be NatNAT-1M1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 w & k =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 w)"
proof-
  have " for k be NatNAT-1M1 holds  for m be IntegerINT-1M1 holds  for p be RationalRAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & p =HIDDENR1 m /XCMPLX-0K7 k implies ( ex tVar13 be NatNAT-1M1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 tVar13 & k =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 tVar13)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be IntegerINT-1M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "k <>HIDDENR2 0NUMBERSK6"
      and A2: "p =HIDDENR1 m /XCMPLX-0K7 k"
    have A3: "p *XCMPLX-0K3 k =HIDDENR1 m"
      using A1 A2 xcmplx_1_th_87 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 k"
    have A5: " for l be NatNAT-1M1 holds ?P(l) implies l <=XXREAL-0R1 k"
    proof-
      have " for l be NatNAT-1M1 holds l *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 k implies ( not l <=XXREAL-0R1 k implies  False )"
      proof(rule ballI,rule impI,rule impI)
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 denominatorRAT-1K2 p"
          using nat_1_th_13 sorry
        then have A6: "k *XCMPLX-0K3 \<one>\<^sub>M <=XXREAL-0R1 k *XCMPLX-0K3 denominatorRAT-1K2 p"
          using nat_1_th_4 sorry
        fix l assume [ty]: "l be NatNAT-1M1"
        assume A7: "l *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 k"
        assume " not l <=XXREAL-0R1 k"
        then have "k *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 l *XCMPLX-0K3 denominatorRAT-1K2 p"
          using xreal_1_th_68 sorry
        thus " False "
          using A7 A6 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: "\<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 k"
      using A1 A2 rat_1_def_3 sorry
    then have A9: " ex l1 be NatNAT-1M1 st ?P(l1)"
       sorry
    obtain l where
      [ty]:"l be NatNAT-1M1" and 
      A10: "?P(l)"and A11: " for l1 be NatNAT-1M1 holds ?P(l1) implies l1 <=XXREAL-0R1 l"
      using nat_1_sch_6 A5 A9 sorry
    have 
      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    show " ex tVar13 be NatNAT-1M1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 tVar13 & k =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 tVar13"
    proof(rule bexI[of _ "l"],rule conjMI)
      have A12: "0NUMBERSK6 <>HIDDENR2 l"
        using A8 A11 sorry
      then have A13: "l *XCMPLX-0K3 denominatorRAT-1K2 p <>HIDDENR2 0NUMBERSK6"
        using xcmplx_1_th_6 sorry
      have A14: "l *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 k implies  False "
      proof(rule impI)
        assume A15: "l *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 k"
        then have "0NUMBERSK6 +XCMPLX-0K2 l *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 k"
           sorry
        then have "0NUMBERSK6 <=XXREAL-0R1 k -XCMPLX-0K6 l *XCMPLX-0K3 denominatorRAT-1K2 p"
          using xreal_1_th_20 sorry
        then obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1" and xDef:"x = k -XCMPLX-0K6 l *XCMPLX-0K3 denominatorRAT-1K2 p"
          using int_1_th_3 sorry
        have A16: "0NUMBERSK6 <>HIDDENR2 x"
          using A15 sorry
        have "m /XCMPLX-0K7 k =XBOOLE-0R4 (numeratorRAT-1K3 p *XCMPLX-0K3 l)/XCMPLX-0K7 (l *XCMPLX-0K3 denominatorRAT-1K2 p)"
          using A2 A12 rat_1_th_26 sorry
        then have "p =HIDDENR1 (m -XCMPLX-0K6 numeratorRAT-1K3 p *XCMPLX-0K3 l)/XCMPLX-0K7 x"
          using A2 A13 A15 xcmplx_1_th_123 sorry
        then have "denominatorRAT-1K2 p <=XXREAL-0R1 k -XCMPLX-0K6 l *XCMPLX-0K3 denominatorRAT-1K2 p"
          using A16 rat_1_def_3 sorry
        then have "l *XCMPLX-0K3 denominatorRAT-1K2 p +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 k"
          using xreal_1_th_19 sorry
        then have "(l +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 k"
           sorry
        then have "l +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 l"
          using A11 sorry
        thus " False "
          using nat_1_th_13 sorry
      qed
      then have "k =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 l"
        using A10 xxreal_0_th_1 sorry
      then have "m =HIDDENR1 (numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)*XCMPLX-0K3 (denominatorRAT-1K2 p *XCMPLX-0K3 l)"
        using A3 rat_1_th_15 sorry
      also have "... = ((numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)*XCMPLX-0K3 denominatorRAT-1K2 p)*XCMPLX-0K3 l"
         sorry
      also have "... = numeratorRAT-1K3 p *XCMPLX-0K3 l"
        using xcmplx_1_th_87 sorry
      finally show "m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 l"
         sorry
      show "k =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 l"
        using A10 A14 xxreal_0_th_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_28:
" for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  for p be RationalRAT-1M1 holds p =HIDDENR1 m /XCMPLX-0K7 n & n <>HIDDENR2 0NUMBERSK6 implies ( ex m1 be IntegerINT-1M1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 m1 & n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 m1)"
proof-
  have " for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds  for p be RationalRAT-1M1 holds p =HIDDENR1 m /XCMPLX-0K7 n & n <>HIDDENR2 0NUMBERSK6 implies ( ex y be objectHIDDENM1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 y & n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 y)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix m assume [ty]: "m be IntegerINT-1M1"
    fix n assume [ty]: "n be IntegerINT-1M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "p =HIDDENR1 m /XCMPLX-0K7 n"
      and A2: "n <>HIDDENR2 0NUMBERSK6"
    show " ex y be objectHIDDENM1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 y & n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 y"
    proof-
      have cases: "n <XXREAL-0R3 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 n"
        using A2 sorry
      have case1: "n <XXREAL-0R3 0NUMBERSK6 implies ( ex y be objectHIDDENM1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 y & n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 y)"
      proof(rule impI)
        assume "n <XXREAL-0R3 0NUMBERSK6"
        then obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1" and xDef:"x = -XCMPLX-0K4 n"
          using int_1_th_3 sorry
        have A3: "p =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4 m)/XCMPLX-0K7 n"
          using A1 sorry
        also have "... = (-XCMPLX-0K4 m)/XCMPLX-0K7 x"
          using xcmplx_1_th_188 sorry
        finally have "p =HIDDENR1 (-XCMPLX-0K4 m)/XCMPLX-0K7 x"
           sorry
        have "x <>HIDDENR2 0NUMBERSK6"
          using A2 sorry
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A4: "-XCMPLX-0K4 m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 k"and A5: "x =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 k"
          using A3 rat_1_th_27 sorry
        obtain y where 
          [ty]:"y be objectHIDDENM1" and yDef:"y = -XCMPLX-0K4 k"
           sorry
        show " ex y be objectHIDDENM1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 y & n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 y"
        proof(rule bexI[of _ "y"],rule conjMI)
          have "m =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p *XCMPLX-0K3 k"
            using A4 sorry
          also have "... = numeratorRAT-1K3 p *XCMPLX-0K3 y"
             sorry
          finally show "m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 y"
             sorry
          have "n =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p *XCMPLX-0K3 k"
            using A5 sorry
          also have "... = denominatorRAT-1K2 p *XCMPLX-0K3 y"
             sorry
          finally show "n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 y"
             sorry
        qed "sorry"
      qed
      have case2: "0NUMBERSK6 <XXREAL-0R3 n implies ( ex tVar15 be IntegerINT-1M1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 tVar15 & n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 tVar15)"
      proof(rule impI)
        assume "0NUMBERSK6 <XXREAL-0R3 n"
        then obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1" and xDef:"x = n"
          using int_1_th_3 sorry
        obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A6: "m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 k"and A7: "x =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 k"
          using A1 A2 rat_1_th_27 sorry
        obtain y where 
          [ty]:"y be IntegerINT-1M1" and yDef:"y = k"
           sorry
        show " ex tVar15 be IntegerINT-1M1 st m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 tVar15 & n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 tVar15"
        proof(rule bexI[of _ "y"])
          show "m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 y & n =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 y"
            using A6 A7 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_29:
" for p be RationalRAT-1M1 holds  not ( ex w be NatNAT-1M1 st \<one>\<^sub>M <XXREAL-0R3 w & ( ex m be IntegerINT-1M1 st  ex k be NatNAT-1M1 st numeratorRAT-1K3 p =HIDDENR1 m *XCMPLX-0K3 w & denominatorRAT-1K2 p =XBOOLE-0R4 k *XCMPLX-0K3 w))"
proof-
  have " for p be RationalRAT-1M1 holds  not ( for w be NatNAT-1M1 holds  not ( not \<one>\<^sub>M <XXREAL-0R3 w &  not ( for m be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not (numeratorRAT-1K3 p =HIDDENR1 m *XCMPLX-0K3 w & denominatorRAT-1K2 p =XBOOLE-0R4 k *XCMPLX-0K3 w)))) implies  False "
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume " not ( for w be NatNAT-1M1 holds  not ( not \<one>\<^sub>M <XXREAL-0R3 w &  not ( for m be IntegerINT-1M1 holds  for k be NatNAT-1M1 holds  not (numeratorRAT-1K3 p =HIDDENR1 m *XCMPLX-0K3 w & denominatorRAT-1K2 p =XBOOLE-0R4 k *XCMPLX-0K3 w))))"
    then obtain w where
      [ty]:"w be NatNAT-1M1" and 
      A1: "\<one>\<^sub>M <XXREAL-0R3 w"and A2: " ex m be IntegerINT-1M1 st  ex k be NatNAT-1M1 st numeratorRAT-1K3 p =HIDDENR1 m *XCMPLX-0K3 w & denominatorRAT-1K2 p =XBOOLE-0R4 k *XCMPLX-0K3 w"
       sorry
    obtain m k where
      [ty]:"m be IntegerINT-1M1" "k be NatNAT-1M1" and 
      A3: "numeratorRAT-1K3 p =HIDDENR1 m *XCMPLX-0K3 w"and A4: "denominatorRAT-1K2 p =XBOOLE-0R4 k *XCMPLX-0K3 w"
      using A2 sorry
    have A5: "p =HIDDENR1 (m *XCMPLX-0K3 w)/XCMPLX-0K7 (k *XCMPLX-0K3 w)"
      using A3 A4 rat_1_th_15 sorry
    also have "... = (m /XCMPLX-0K7 k)*XCMPLX-0K3 (w /XCMPLX-0K7 w)"
      using xcmplx_1_th_76 sorry
    also have "... = (m /XCMPLX-0K7 k)*XCMPLX-0K3 \<one>\<^sub>M"
      using A1 xcmplx_1_th_60 sorry
    also have "... = m /XCMPLX-0K7 k"
       sorry
    finally have "p =HIDDENR1 m /XCMPLX-0K7 k"
       sorry
    have A6: "k <>HIDDENR2 0NUMBERSK6"
      using A4 sorry
    then have "k *XCMPLX-0K3 \<one>\<^sub>M <XXREAL-0R3 k *XCMPLX-0K3 w"
      using A1 xreal_1_th_68 sorry
    thus " False "
      using A4 A6 A5 rat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_30:
" for k be NatNAT-1M1 holds  for m be IntegerINT-1M1 holds  for p be RationalRAT-1M1 holds (p =HIDDENR1 m /XCMPLX-0K7 k & k <>HIDDENR2 0NUMBERSK6) &  not ( ex w be NatNAT-1M1 st \<one>\<^sub>M <XXREAL-0R3 w & ( ex m1 be IntegerINT-1M1 st  ex k1 be NatNAT-1M1 st m =HIDDENR1 m1 *XCMPLX-0K3 w & k =XBOOLE-0R4 k1 *XCMPLX-0K3 w)) implies k =XBOOLE-0R4 denominatorRAT-1K2 p & m =HIDDENR1 numeratorRAT-1K3 p"
proof-
  have " for k be NatNAT-1M1 holds  for m be IntegerINT-1M1 holds  for p be RationalRAT-1M1 holds p =HIDDENR1 m /XCMPLX-0K7 k & (k <>HIDDENR2 0NUMBERSK6 &  not ( ex w be NatNAT-1M1 st \<one>\<^sub>M <XXREAL-0R3 w & ( ex m1 be IntegerINT-1M1 st  ex k1 be NatNAT-1M1 st m =HIDDENR1 m1 *XCMPLX-0K3 w & k =XBOOLE-0R4 k1 *XCMPLX-0K3 w))) implies k =XBOOLE-0R4 denominatorRAT-1K2 p & m =HIDDENR1 numeratorRAT-1K3 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be IntegerINT-1M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "p =HIDDENR1 m /XCMPLX-0K7 k"
      and A2: "k <>HIDDENR2 0NUMBERSK6"
      and A3: " not ( ex w be NatNAT-1M1 st \<one>\<^sub>M <XXREAL-0R3 w & ( ex m1 be IntegerINT-1M1 st  ex k1 be NatNAT-1M1 st m =HIDDENR1 m1 *XCMPLX-0K3 w & k =XBOOLE-0R4 k1 *XCMPLX-0K3 w))"
    obtain w where
      [ty]:"w be NatNAT-1M1" and 
      A4: "m =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 w"and A5: "k =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 w"
      using A1 A2 rat_1_th_27 sorry
    have "0NUMBERSK6 <XXREAL-0R3 w"
      using A2 A5 sorry
    then have A6: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 w"
      using nat_1_th_13 sorry
    have "w <=XXREAL-0R1 \<one>\<^sub>M"
      using A3 A4 A5 sorry
    then have A7: "w =XBOOLE-0R4 \<one>\<^sub>M"
      using A6 xxreal_0_th_1 sorry
    thus "k =XBOOLE-0R4 denominatorRAT-1K2 p"
      using A5 sorry
    show "m =HIDDENR1 numeratorRAT-1K3 p"
      using A4 A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_31:
" for p be RationalRAT-1M1 holds p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M iff numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p"
proof-
  have " for p be RationalRAT-1M1 holds (p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p) & (numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p implies p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M)"
  proof(rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    show "p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p"
    proof(rule impI)
      assume "p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
      then have "numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
        using rat_1_th_15 sorry
      then have "(numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)*XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 denominatorRAT-1K2 p"
        using xreal_1_th_68 sorry
      thus "numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p"
        using xcmplx_1_th_87 sorry
    qed
    assume "numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p"
    then have "numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <XXREAL-0R3 ((-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 denominatorRAT-1K2 p)*XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
      using xreal_1_th_68 sorry
    then have "numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5)"
       sorry
    then have "numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M"
      using xcmplx_0_def_7 sorry
    thus "p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
      using rat_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_32:
" for p be RationalRAT-1M1 holds p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M iff numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
proof-
  have " for p be RationalRAT-1M1 holds (p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p) & (numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p implies p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M)"
  proof(rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    show "p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
    proof(rule impI)
      assume A2: "p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
      show "numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
      proof-
        have cases: "p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M or p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
          using A2 xxreal_0_th_1 sorry
        have case1: "p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
        proof(rule impI)
          assume "p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
          thus "numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
             sorry
        qed
        have case2: "p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
        proof(rule impI)
          assume "p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
          thus "numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
            using rat_1_th_31 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    assume A3: "numeratorRAT-1K3 p <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
    show "p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    proof-
      have cases: "numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p or numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p"
        using A3 xxreal_0_th_1 sorry
      have case1: "numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p implies p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
      proof(rule impI)
        assume "numeratorRAT-1K3 p =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p"
        thus "p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
          using rat_1_th_24 sorry
      qed
      have case2: "numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p implies p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
      proof(rule impI)
        assume "numeratorRAT-1K3 p <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p"
        thus "p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
          using rat_1_th_31 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_33:
" for p be RationalRAT-1M1 holds p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M iff denominatorRAT-1K2 p <XXREAL-0R3 -XCMPLX-0K4 numeratorRAT-1K3 p"
proof-
  have " for p be RationalRAT-1M1 holds  not ( not p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M & denominatorRAT-1K2 p <XXREAL-0R3 -XCMPLX-0K4 numeratorRAT-1K3 p) &  not ( not denominatorRAT-1K2 p <XXREAL-0R3 -XCMPLX-0K4 numeratorRAT-1K3 p & p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "denominatorRAT-1K2 p <XXREAL-0R3 -XCMPLX-0K4 numeratorRAT-1K3 p iff -XCMPLX-0K4 (-XCMPLX-0K4 numeratorRAT-1K3 p) <XXREAL-0R3 -XCMPLX-0K4 denominatorRAT-1K2 p"
      using xreal_1_th_24 sorry
    thus " not ( not p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M & denominatorRAT-1K2 p <XXREAL-0R3 -XCMPLX-0K4 numeratorRAT-1K3 p) &  not ( not denominatorRAT-1K2 p <XXREAL-0R3 -XCMPLX-0K4 numeratorRAT-1K3 p & p <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M)"
      using rat_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_34:
" for p be RationalRAT-1M1 holds p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M iff denominatorRAT-1K2 p <=XXREAL-0R1 -XCMPLX-0K4 numeratorRAT-1K3 p"
proof-
  have " for p be RationalRAT-1M1 holds  not (p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M &  not denominatorRAT-1K2 p <=XXREAL-0R1 -XCMPLX-0K4 numeratorRAT-1K3 p) &  not (denominatorRAT-1K2 p <=XXREAL-0R1 -XCMPLX-0K4 numeratorRAT-1K3 p &  not p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "denominatorRAT-1K2 p <=XXREAL-0R1 -XCMPLX-0K4 numeratorRAT-1K3 p iff -XCMPLX-0K4 (-XCMPLX-0K4 numeratorRAT-1K3 p) <=XXREAL-0R1 -XCMPLX-0K4 denominatorRAT-1K2 p"
      using xreal_1_th_24 sorry
    thus " not (p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M &  not denominatorRAT-1K2 p <=XXREAL-0R1 -XCMPLX-0K4 numeratorRAT-1K3 p) &  not (denominatorRAT-1K2 p <=XXREAL-0R1 -XCMPLX-0K4 numeratorRAT-1K3 p &  not p <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M)"
      using rat_1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_35:
" for p be RationalRAT-1M1 holds p <XXREAL-0R3 \<one>\<^sub>M iff numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p"
proof-
  have " for p be RationalRAT-1M1 holds  not ( not p <XXREAL-0R3 \<one>\<^sub>M & numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p) &  not ( not numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p & p <XXREAL-0R3 \<one>\<^sub>M)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have A3: "numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p implies p <XXREAL-0R3 \<one>\<^sub>M"
    proof(rule impI)
      assume "numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p"
      then have "numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <XXREAL-0R3 denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
        using xreal_1_th_68 sorry
      then have "numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
        using xcmplx_0_def_7 sorry
      thus "p <XXREAL-0R3 \<one>\<^sub>M"
        using rat_1_th_15 sorry
    qed
    have "p <XXREAL-0R3 \<one>\<^sub>M implies numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p"
    proof(rule impI)
      assume "p <XXREAL-0R3 \<one>\<^sub>M"
      then have "numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p <XXREAL-0R3 \<one>\<^sub>M"
        using rat_1_th_15 sorry
      then have "(numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)*XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p"
        using xreal_1_th_68 sorry
      thus "numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p"
        using xcmplx_1_th_87 sorry
    qed
    thus " not ( not p <XXREAL-0R3 \<one>\<^sub>M & numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p) &  not ( not numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p & p <XXREAL-0R3 \<one>\<^sub>M)"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_36:
" for p be RationalRAT-1M1 holds p <=XXREAL-0R1 \<one>\<^sub>M iff numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p"
proof-
  have " for p be RationalRAT-1M1 holds  not (p <=XXREAL-0R1 \<one>\<^sub>M &  not numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p) &  not (numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p &  not p <=XXREAL-0R1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have A1: "p <=XXREAL-0R1 \<one>\<^sub>M implies numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p"
    proof(rule impI)
      assume A2: "p <=XXREAL-0R1 \<one>\<^sub>M"
      show "numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p"
      proof-
        have cases: "p =HIDDENR1 \<one>\<^sub>M or p <XXREAL-0R3 \<one>\<^sub>M"
          using A2 xxreal_0_th_1 sorry
        have case1: "p =HIDDENR1 \<one>\<^sub>M implies numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p"
        proof(rule impI)
          assume "p =HIDDENR1 \<one>\<^sub>M"
          thus "numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p"
             sorry
        qed
        have case2: "p <XXREAL-0R3 \<one>\<^sub>M implies numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p"
        proof(rule impI)
          assume "p <XXREAL-0R3 \<one>\<^sub>M"
          thus "numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p"
            using rat_1_th_35 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have "numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p implies p <=XXREAL-0R1 \<one>\<^sub>M"
    proof(rule impI)
      assume A3: "numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p"
      show "p <=XXREAL-0R1 \<one>\<^sub>M"
      proof-
        have cases: "numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p or numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p"
          using A3 xxreal_0_th_1 sorry
        have case1: "numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p implies p <=XXREAL-0R1 \<one>\<^sub>M"
        proof(rule impI)
          assume "numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 p"
          thus "p <=XXREAL-0R1 \<one>\<^sub>M"
            using rat_1_th_23 sorry
        qed
        have case2: "numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p implies p <=XXREAL-0R1 \<one>\<^sub>M"
        proof(rule impI)
          assume "numeratorRAT-1K3 p <XXREAL-0R3 denominatorRAT-1K2 p"
          thus "p <=XXREAL-0R1 \<one>\<^sub>M"
            using rat_1_th_35 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (p <=XXREAL-0R1 \<one>\<^sub>M &  not numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p) &  not (numeratorRAT-1K3 p <=XXREAL-0R1 denominatorRAT-1K2 p &  not p <=XXREAL-0R1 \<one>\<^sub>M)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_37:
" for p be RationalRAT-1M1 holds p <XXREAL-0R3 0NUMBERSK6 iff numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for p be RationalRAT-1M1 holds  not ( not p <XXREAL-0R3 0NUMBERSK6 & numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6) &  not ( not numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6 & p <XXREAL-0R3 0NUMBERSK6)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "p <XXREAL-0R3 0NUMBERSK6 implies numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6"
    proof(rule impI)
      assume "p <XXREAL-0R3 0NUMBERSK6"
      then have "numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p <XXREAL-0R3 0NUMBERSK6"
        using rat_1_th_15 sorry
      thus "numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6"
         sorry
    qed
    thus " not ( not p <XXREAL-0R3 0NUMBERSK6 & numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6) &  not ( not numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6 & p <XXREAL-0R3 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_38:
" for p be RationalRAT-1M1 holds p <=XXREAL-0R1 0NUMBERSK6 iff numeratorRAT-1K3 p <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for p be RationalRAT-1M1 holds  not (p <=XXREAL-0R1 0NUMBERSK6 &  not numeratorRAT-1K3 p <=XXREAL-0R1 0NUMBERSK6) &  not (numeratorRAT-1K3 p <=XXREAL-0R1 0NUMBERSK6 &  not p <=XXREAL-0R1 0NUMBERSK6)"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "numeratorRAT-1K3 p <=XXREAL-0R1 0NUMBERSK6 implies p <=XXREAL-0R1 0NUMBERSK6"
    proof(rule impI)
      assume A1: "numeratorRAT-1K3 p <=XXREAL-0R1 0NUMBERSK6"
      show "p <=XXREAL-0R1 0NUMBERSK6"
      proof-
        have cases: "numeratorRAT-1K3 p =HIDDENR1 0NUMBERSK6 or numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6"
          using A1 sorry
        have case1: "numeratorRAT-1K3 p =HIDDENR1 0NUMBERSK6 implies p <=XXREAL-0R1 0NUMBERSK6"
        proof(rule impI)
          assume "numeratorRAT-1K3 p =HIDDENR1 0NUMBERSK6"
          thus "p <=XXREAL-0R1 0NUMBERSK6"
            using rat_1_th_14 sorry
        qed
        have case2: "numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6 implies p <=XXREAL-0R1 0NUMBERSK6"
        proof(rule impI)
          assume "numeratorRAT-1K3 p <XXREAL-0R3 0NUMBERSK6"
          thus "p <=XXREAL-0R1 0NUMBERSK6"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (p <=XXREAL-0R1 0NUMBERSK6 &  not numeratorRAT-1K3 p <=XXREAL-0R1 0NUMBERSK6) &  not (numeratorRAT-1K3 p <=XXREAL-0R1 0NUMBERSK6 &  not p <=XXREAL-0R1 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_39:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a <XXREAL-0R3 p iff a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  not ( not a <XXREAL-0R3 p & a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p) &  not ( not a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p & a <XXREAL-0R3 p)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    have A3: "a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p implies a <XXREAL-0R3 p"
    proof(rule impI)
      assume "a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p"
      then have "(a *XCMPLX-0K3 denominatorRAT-1K2 p)*XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5 <XXREAL-0R3 numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
        using xreal_1_th_68 sorry
      then have "a *XCMPLX-0K3 (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5) <XXREAL-0R3 numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
         sorry
      then have "a *XCMPLX-0K3 \<one>\<^sub>M <XXREAL-0R3 numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 p \<inverse>XCMPLX-0K5"
        using xcmplx_0_def_7 sorry
      thus "a <XXREAL-0R3 p"
        using rat_1_th_15 sorry
    qed
    show " not ( not a <XXREAL-0R3 p & a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p) &  not ( not a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p & a <XXREAL-0R3 p)"
      using A3 xreal_1_th_68 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_40:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a <=XXREAL-0R1 p iff a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  not (a <=XXREAL-0R1 p &  not a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p) &  not (a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p &  not a <=XXREAL-0R1 p)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    have A2: "a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p implies a <=XXREAL-0R1 p"
    proof(rule impI)
      assume A3: "a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p"
      show "a <=XXREAL-0R1 p"
      proof-
        have cases: "a *XCMPLX-0K3 denominatorRAT-1K2 p =HIDDENR1 numeratorRAT-1K3 p or a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p"
          using A3 xxreal_0_th_1 sorry
        have case1: "a *XCMPLX-0K3 denominatorRAT-1K2 p =HIDDENR1 numeratorRAT-1K3 p implies a <=XXREAL-0R1 p"
        proof(rule impI)
          assume "a *XCMPLX-0K3 denominatorRAT-1K2 p =HIDDENR1 numeratorRAT-1K3 p"
          then have "p =HIDDENR1 (a *XCMPLX-0K3 denominatorRAT-1K2 p)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p)"
            using rat_1_th_15 sorry
          also have "... = (a /XCMPLX-0K7 \<one>\<^sub>M)*XCMPLX-0K3 (denominatorRAT-1K2 p /XCMPLX-0K7 denominatorRAT-1K2 p)"
             sorry
          also have "... = a"
            using xcmplx_1_th_60 sorry
          finally have "p =HIDDENR1 a"
             sorry
          thus "a <=XXREAL-0R1 p"
             sorry
        qed
        have case2: "a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p implies a <=XXREAL-0R1 p"
        proof(rule impI)
          assume "a *XCMPLX-0K3 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 p"
          thus "a <=XXREAL-0R1 p"
            using rat_1_th_39 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have "a <=XXREAL-0R1 p implies numeratorRAT-1K3 p >=XXREAL-0R2 a *XCMPLX-0K3 denominatorRAT-1K2 p"
    proof(rule impI)
      assume A4: "a <=XXREAL-0R1 p"
      show "numeratorRAT-1K3 p >=XXREAL-0R2 a *XCMPLX-0K3 denominatorRAT-1K2 p"
      proof-
        have cases: "a =HIDDENR1 p or a <XXREAL-0R3 p"
          using A4 xxreal_0_th_1 sorry
        have case1: "a =HIDDENR1 p implies numeratorRAT-1K3 p >=XXREAL-0R2 a *XCMPLX-0K3 denominatorRAT-1K2 p"
        proof(rule impI)
          assume "a =HIDDENR1 p"
          thus "numeratorRAT-1K3 p >=XXREAL-0R2 a *XCMPLX-0K3 denominatorRAT-1K2 p"
             sorry
        qed
        have case2: "a <XXREAL-0R3 p implies a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p"
        proof(rule impI)
          assume "a <XXREAL-0R3 p"
          thus "a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p"
            using rat_1_th_39 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (a <=XXREAL-0R1 p &  not a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p) &  not (a *XCMPLX-0K3 denominatorRAT-1K2 p <=XXREAL-0R1 numeratorRAT-1K3 p &  not a <=XXREAL-0R1 p)"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_41:
" for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds denominatorRAT-1K2 p =XBOOLE-0R4 denominatorRAT-1K2 q & numeratorRAT-1K3 p =HIDDENR1 numeratorRAT-1K3 q implies p =HIDDENR1 q"
proof-
  have " for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds denominatorRAT-1K2 p =XBOOLE-0R4 denominatorRAT-1K2 q & numeratorRAT-1K3 p =HIDDENR1 numeratorRAT-1K3 q implies p =HIDDENR1 q"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    assume A1: "denominatorRAT-1K2 p =XBOOLE-0R4 denominatorRAT-1K2 q"
      and A2: "numeratorRAT-1K3 p =HIDDENR1 numeratorRAT-1K3 q"
    have "p =HIDDENR1 numeratorRAT-1K3 q /XCMPLX-0K7 denominatorRAT-1K2 q"
      using A1 A2 rat_1_th_15 sorry
    also have "... = q"
      using rat_1_th_15 sorry
    finally show "p =HIDDENR1 q"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_42:
" for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds p <XXREAL-0R3 q iff numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 q <XXREAL-0R3 numeratorRAT-1K3 q *XCMPLX-0K3 denominatorRAT-1K2 p"
proof-
  have " for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds  not ( not p <XXREAL-0R3 q & numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 q <XXREAL-0R3 numeratorRAT-1K3 q *XCMPLX-0K3 denominatorRAT-1K2 p) &  not ( not numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 q <XXREAL-0R3 numeratorRAT-1K3 q *XCMPLX-0K3 denominatorRAT-1K2 p & p <XXREAL-0R3 q)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    have "p <XXREAL-0R3 q iff numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p <XXREAL-0R3 q"
      using rat_1_th_15 sorry
    then have "p <XXREAL-0R3 q iff numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p <XXREAL-0R3 numeratorRAT-1K3 q /XCMPLX-0K7 denominatorRAT-1K2 q"
      using rat_1_th_15 sorry
    thus " not ( not p <XXREAL-0R3 q & numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 q <XXREAL-0R3 numeratorRAT-1K3 q *XCMPLX-0K3 denominatorRAT-1K2 p) &  not ( not numeratorRAT-1K3 p *XCMPLX-0K3 denominatorRAT-1K2 q <XXREAL-0R3 numeratorRAT-1K3 q *XCMPLX-0K3 denominatorRAT-1K2 p & p <XXREAL-0R3 q)"
      using xreal_1_th_102 xreal_1_th_106 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_43:
" for p be RationalRAT-1M1 holds denominatorRAT-1K2 (-XCMPLX-0K4 p) =XBOOLE-0R4 denominatorRAT-1K2 p & numeratorRAT-1K3 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p"
proof-
  have " for p be RationalRAT-1M1 holds denominatorRAT-1K2 p =XBOOLE-0R4 denominatorRAT-1K2 (-XCMPLX-0K4 p) & numeratorRAT-1K3 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p"
  proof(rule ballI,rule conjMI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have A2: "p =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4 p)"
       sorry
    also have "... = -XCMPLX-0K4 numeratorRAT-1K3 (-XCMPLX-0K4 p) /XCMPLX-0K7 denominatorRAT-1K2 (-XCMPLX-0K4 p)"
      using rat_1_th_15 sorry
    also have "... = (-XCMPLX-0K4 numeratorRAT-1K3 (-XCMPLX-0K4 p))/XCMPLX-0K7 denominatorRAT-1K2 (-XCMPLX-0K4 p)"
       sorry
    finally have "p =HIDDENR1 (-XCMPLX-0K4 numeratorRAT-1K3 (-XCMPLX-0K4 p))/XCMPLX-0K7 denominatorRAT-1K2 (-XCMPLX-0K4 p)"
       sorry
    obtain w where
      [ty]:"w be NatNAT-1M1" and 
      "-XCMPLX-0K4 numeratorRAT-1K3 (-XCMPLX-0K4 p) =HIDDENR1 numeratorRAT-1K3 p *XCMPLX-0K3 w"and A3: "denominatorRAT-1K2 (-XCMPLX-0K4 p) =XBOOLE-0R4 denominatorRAT-1K2 p *XCMPLX-0K3 w"
      using A2 rat_1_th_27 sorry
    have "-XCMPLX-0K4 p =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p"
      using rat_1_th_15 sorry
    also have "... = (-XCMPLX-0K4 numeratorRAT-1K3 p)/XCMPLX-0K7 denominatorRAT-1K2 p"
       sorry
    finally have "-XCMPLX-0K4 p =HIDDENR1 (-XCMPLX-0K4 numeratorRAT-1K3 p)/XCMPLX-0K7 denominatorRAT-1K2 p"
       sorry
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: "-XCMPLX-0K4 numeratorRAT-1K3 p =HIDDENR1 numeratorRAT-1K3 (-XCMPLX-0K4 p) *XCMPLX-0K3 k"and A5: "denominatorRAT-1K2 p =XBOOLE-0R4 denominatorRAT-1K2 (-XCMPLX-0K4 p) *XCMPLX-0K3 k"
      using rat_1_th_27 sorry
    have "denominatorRAT-1K2 p =HIDDENR1 (denominatorRAT-1K2 p *XCMPLX-0K3 w)*XCMPLX-0K3 k"
      using A5 A3 sorry
    also have "... = denominatorRAT-1K2 p *XCMPLX-0K3 (w *XCMPLX-0K3 k)"
       sorry
    finally have "denominatorRAT-1K2 p =HIDDENR1 denominatorRAT-1K2 p *XCMPLX-0K3 (w *XCMPLX-0K3 k)"
       sorry
    then have A6: "k =XBOOLE-0R4 \<one>\<^sub>M"
      using nat_1_th_15 xcmplx_1_th_7 sorry
    thus "denominatorRAT-1K2 p =XBOOLE-0R4 denominatorRAT-1K2 (-XCMPLX-0K4 p)"
      using A5 sorry
    show "numeratorRAT-1K3 (-XCMPLX-0K4 p) =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p"
      using A4 A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_44:
" for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 p & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p iff numeratorRAT-1K3 q =HIDDENR1 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 numeratorRAT-1K3 p"
proof-
  have " for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds  not (( not 0NUMBERSK6 <XXREAL-0R3 p & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p) &  not (numeratorRAT-1K3 q =HIDDENR1 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 numeratorRAT-1K3 p)) &  not ((numeratorRAT-1K3 q =HIDDENR1 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 numeratorRAT-1K3 p) &  not ( not 0NUMBERSK6 <XXREAL-0R3 p & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p))"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    have A1: "0NUMBERSK6 <XXREAL-0R3 p & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p implies numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 q & denominatorRAT-1K2 p =HIDDENR1 numeratorRAT-1K3 q"
    proof(rule impMI ,rule impI)
      let ?x = "denominatorRAT-1K2 p"
      assume A2: "0NUMBERSK6 <XXREAL-0R3 p"
        and A3: "q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p"
      have A4: "q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)"
        using A3 rat_1_th_15 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p)/XCMPLX-0K7 numeratorRAT-1K3 p"
        using xcmplx_1_th_77 sorry
      also have "... = denominatorRAT-1K2 p /XCMPLX-0K7 numeratorRAT-1K3 p"
         sorry
      finally have "q =HIDDENR1 denominatorRAT-1K2 p /XCMPLX-0K7 numeratorRAT-1K3 p"
         sorry
      obtain y where 
        [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1" and yDef:"y = numeratorRAT-1K3 p"
        using A2 int_1_th_3 sorry
      have A5: " not ( ex k be NatNAT-1M1 st \<one>\<^sub>M <XXREAL-0R3 k & ( ex m be IntegerINT-1M1 st  ex w be NatNAT-1M1 st ?x =XBOOLE-0R4 m *XCMPLX-0K3 k & y =XBOOLE-0R4 w *XCMPLX-0K3 k))"
      proof-
        have " not ( for k be NatNAT-1M1 holds  not ( not \<one>\<^sub>M <XXREAL-0R3 k &  not ( for m be IntegerINT-1M1 holds  for w be NatNAT-1M1 holds  not (denominatorRAT-1K2 p =XBOOLE-0R4 m *XCMPLX-0K3 k & y =XBOOLE-0R4 w *XCMPLX-0K3 k)))) implies  False "
        proof(rule impI)
          assume " not ( for k be NatNAT-1M1 holds  not ( not \<one>\<^sub>M <XXREAL-0R3 k &  not ( for m be IntegerINT-1M1 holds  for w be NatNAT-1M1 holds  not (denominatorRAT-1K2 p =XBOOLE-0R4 m *XCMPLX-0K3 k & y =XBOOLE-0R4 w *XCMPLX-0K3 k))))"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A6: "\<one>\<^sub>M <XXREAL-0R3 k"and A7: " ex m be IntegerINT-1M1 st  ex w be NatNAT-1M1 st ?x =XBOOLE-0R4 m *XCMPLX-0K3 k & y =XBOOLE-0R4 w *XCMPLX-0K3 k"
             sorry
          obtain m w where
            [ty]:"m be IntegerINT-1M1" "w be NatNAT-1M1" and 
            A8: "?x =XBOOLE-0R4 m *XCMPLX-0K3 k"and A9: "y =XBOOLE-0R4 w *XCMPLX-0K3 k"
            using A7 sorry
          have " not 0NUMBERSK6 <=XXREAL-0R1 m implies  False "
          proof(rule impI)
            assume " not 0NUMBERSK6 <=XXREAL-0R1 m"
            then have "m *XCMPLX-0K3 k <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 m"
              using A6 xreal_1_th_69 sorry
            thus " False "
              using A8 sorry
          qed
          then obtain z where 
            [ty]:"z be ElementSUBSET-1M1-of NATNUMBERSK1" and zDef:"z = m"
            using int_1_th_3 sorry
          have "denominatorRAT-1K2 p =XBOOLE-0R4 z *XCMPLX-0K3 k"
            using A8 sorry
          thus " False "
            using A6 A9 rat_1_th_29 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "0NUMBERSK6 <>HIDDENR2 numeratorRAT-1K3 p"
        using A2 rat_1_th_38 sorry
      thus "numeratorRAT-1K3 p =HIDDENR1 denominatorRAT-1K2 q & denominatorRAT-1K2 p =HIDDENR1 numeratorRAT-1K3 q"
        using A4 A5 rat_1_th_30 sorry
    qed
    have "numeratorRAT-1K3 q =HIDDENR1 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 numeratorRAT-1K3 p implies 0NUMBERSK6 <XXREAL-0R3 p & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p"
    proof(rule impMI ,rule impI,rule conjMI)
      assume A10: "numeratorRAT-1K3 q =HIDDENR1 denominatorRAT-1K2 p"
        and A11: "denominatorRAT-1K2 q =HIDDENR1 numeratorRAT-1K3 p"
      show "0NUMBERSK6 <XXREAL-0R3 p"
        using A11 sorry
      have "q =HIDDENR1 (\<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p)/XCMPLX-0K7 numeratorRAT-1K3 p"
        using A10 A11 rat_1_th_15 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)"
        using xcmplx_1_th_77 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 p"
        using rat_1_th_15 sorry
      finally show "q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p"
         sorry
    qed
    thus " not (( not 0NUMBERSK6 <XXREAL-0R3 p & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p) &  not (numeratorRAT-1K3 q =HIDDENR1 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 numeratorRAT-1K3 p)) &  not ((numeratorRAT-1K3 q =HIDDENR1 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 numeratorRAT-1K3 p) &  not ( not 0NUMBERSK6 <XXREAL-0R3 p & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rat_1_th_45:
" for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds p <XXREAL-0R3 0NUMBERSK6 & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p iff numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p"
proof-
  have " for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds  not (( not p <XXREAL-0R3 0NUMBERSK6 & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p) &  not (numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p)) &  not ((numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p) &  not ( not p <XXREAL-0R3 0NUMBERSK6 & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p))"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    have A1: "p <XXREAL-0R3 0NUMBERSK6 & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p implies numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p"
    proof(rule impMI ,rule impI)
      let ?s = "-XCMPLX-0K4 q"
      let ?r = "-XCMPLX-0K4 p"
      assume A2: "p <XXREAL-0R3 0NUMBERSK6"
        and A3: "q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p"
      have A4: "?s =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ?r"
        using A3 xcmplx_1_th_188 sorry
      have A5: "0NUMBERSK6 <XXREAL-0R3 ?r"
        using A2 xreal_1_th_58 sorry
      then have "numeratorRAT-1K3 ?s =HIDDENR1 denominatorRAT-1K2 ?r"
        using A4 rat_1_th_44 sorry
      then have "-XCMPLX-0K4 numeratorRAT-1K3 q =HIDDENR1 denominatorRAT-1K2 ?r"
        using rat_1_th_43 sorry
      then have A6: "-XCMPLX-0K4 (-XCMPLX-0K4 numeratorRAT-1K3 q) =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p"
        using rat_1_th_43 sorry
      have "denominatorRAT-1K2 ?s =HIDDENR1 numeratorRAT-1K3 ?r"
        using A5 A4 rat_1_th_44 sorry
      then have "denominatorRAT-1K2 q =HIDDENR1 numeratorRAT-1K3 ?r"
        using rat_1_th_43 sorry
      thus "numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p"
        using A6 rat_1_th_43 sorry
    qed
    have "numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p implies p <XXREAL-0R3 0NUMBERSK6 & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p"
    proof(rule impMI ,rule impI,rule conjMI)
      assume A7: "numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p"
        and A8: "denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p"
      show "p <XXREAL-0R3 0NUMBERSK6"
        using A8 sorry
      have "q =HIDDENR1 (-XCMPLX-0K4 denominatorRAT-1K2 p)/XCMPLX-0K7 (-XCMPLX-0K4 numeratorRAT-1K3 p)"
        using A7 A8 rat_1_th_15 sorry
      also have "... = -XCMPLX-0K4 denominatorRAT-1K2 p /XCMPLX-0K7 (-XCMPLX-0K4 numeratorRAT-1K3 p)"
         sorry
      also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 denominatorRAT-1K2 p /XCMPLX-0K7 numeratorRAT-1K3 p)"
        using xcmplx_1_th_188 sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 denominatorRAT-1K2 p)/XCMPLX-0K7 numeratorRAT-1K3 p"
         sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)"
        using xcmplx_1_th_77 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 p"
        using rat_1_th_15 sorry
      finally show "q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p"
         sorry
    qed
    thus " not (( not p <XXREAL-0R3 0NUMBERSK6 & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p) &  not (numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p)) &  not ((numeratorRAT-1K3 q =HIDDENR1 -XCMPLX-0K4 denominatorRAT-1K2 p & denominatorRAT-1K2 q =HIDDENR1 -XCMPLX-0K4 numeratorRAT-1K3 p) &  not ( not p <XXREAL-0R3 0NUMBERSK6 & q =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 p))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
